const APP = '/home/claude/hsc-bio/dist/hsc-biology.html';
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 360, height: 800 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(400);
  const ids = await p.evaluate(c => APP.LESSONS.filter(l => l.ch === c).map(l => l.id), process.argv[2] || 'p1c3');
  const bad = [];
  for (const id of ids) {
    await p.evaluate(id => { const l = APP.LESSONS.find(x => x.id === id); APP.setCh(l.ch); APP.go('lesson', { id }); }, id);
    await p.waitForTimeout(300); await p.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await p.waitForTimeout(500);
    const r = await p.evaluate(() => { const w = document.documentElement.clientWidth; const o = []; document.querySelectorAll('.fig *').forEach(e => { const b = e.getBoundingClientRect(); if (b.right > w + 1 && !e.closest('.table-wrap,.fk-eq,.fwall-f,.katex')) o.push(e.className && e.className.baseVal !== undefined ? e.tagName : (e.className || e.tagName)); }); const km = [...document.querySelectorAll('.txd, .txd .txp')].filter(k => !k.closest('.fig') && !k.classList.contains('txw') && k.scrollWidth > k.clientWidth + 2).map(k => k.textContent.slice(0, 40)); return { sw: document.documentElement.scrollWidth, w, o: [...new Set(o)].slice(0, 5), km }; });
    if (r.sw > r.w || r.o.length || r.km.length) bad.push([id, r]);
  }
  console.log(JSON.stringify(bad), 'errs', errs.length);
  await b.close();
})();
