/* node tools/qa/lesshot.js <lessonId> [out.png] [skin] [scrollY] — phone screenshot of one lesson page (2x) */
const APP = require('path').resolve(__dirname, '../../dist/hsc-biology.html');
const { chromium } = require('playwright');
(async () => {
  const [id, out = `les_${process.argv[2]}.png`, skin = 'glass', sy = '0', h = '1600'] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: +h }, deviceScaleFactor: 2 });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(400);
  await p.evaluate(([id, skin]) => { document.documentElement.setAttribute('data-skin', skin); const l = APP.LESSONS.find(x => x.id === id); APP.setCh(l.ch); APP.go('lesson', { id }); }, [id, skin]);
  await p.waitForTimeout(500);
  await p.evaluate(y => window.scrollTo(0, +y), sy); await p.waitForTimeout(1600);
  await p.screenshot({ path: out });
  console.log('errs', errs);
  await b.close();
})();
