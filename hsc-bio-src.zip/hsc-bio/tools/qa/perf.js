/* কম শক্তির ফোনের অনুকরণে (CPU 6x ধীর, DPR 2, 390px) প্রতিটি চিত্রের ফ্রেম-রেট মাপা */
const APP = require('path').resolve(__dirname, '../../dist/hsc-biology.html');
const { chromium } = require('playwright');
const keys = JSON.parse(process.argv[2]), acts = process.argv[3] ? JSON.parse(process.argv[3]) : {}, rate = +(process.env.CPU || 6);
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(300);
  const cdp = await p.context().newCDPSession(p); await cdp.send('Emulation.setCPUThrottlingRate', { rate });
  const out = [];
  for (const k of keys) {
    await p.evaluate(k => { if (window._cl) try { window._cl(); } catch (e) { } const old = document.getElementById('fs'); if (old) old.remove(); const v = VIS[k]; const d = document.createElement('div'); d.id = 'fs'; d.style.cssText = 'position:fixed;inset:0;z-index:9999;overflow:auto;background:var(--bg);padding:12px'; d.innerHTML = `<figure class="fig"><div class="fig-body">${v.html()}</div></figure>`; document.body.appendChild(d); window._cl = (FK.guardOut && FK.guardOut(d), v.mount(d.querySelector('.fig-body'))); }, k);
    for (const a of (acts[k] || [])) { if (a.startsWith('wait:')) await p.waitForTimeout(+a.slice(5)); else await p.click('#fs ' + a).catch(() => { }); }
    await p.waitForTimeout(400);
    const r = await p.evaluate(() => new Promise(res => { const ts = []; let last = performance.now(); const end = last + 2500; const f = t => { ts.push(t - last); last = t; if (t < end) requestAnimationFrame(f); else { ts.sort((a, b) => a - b); const avg = ts.reduce((s, x) => s + x, 0) / ts.length; res({ fps: Math.round(1000 / avg), p90: Math.round(ts[Math.floor(ts.length * .9)]) }); } }; requestAnimationFrame(f); }));
    const st = await p.evaluate(() => { const a = FK._sc || []; const S = a[a.length - 1]; return S && document.getElementById('fs').contains(S.cv) ? JSON.stringify(S.stat()) : '-'; });
    out.push([k, r.fps, r.p90]); console.log(k.padEnd(16), 'fps', String(r.fps).padStart(3), ' p90', r.p90, 'ms', st);
  }
  await b.close();
})();
