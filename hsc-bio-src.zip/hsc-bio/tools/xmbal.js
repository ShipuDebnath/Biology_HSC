// rebalance lesson xm answer positions greedily against chapter-wide counts. usage: node xmbal.js <ch>
const fs=require('fs'),path=require('path');const ch=process.argv[2];const dir=path.join('src/chapters',ch,'content');
const q=s=>"'"+s.replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/\n/g,'\\n')+"'";
const enc=v=>Array.isArray(v)?'['+v.map(enc).join(', ')+']':typeof v==='number'?String(v):q(v);
const MULTI=/^i ও ii$|^i, ii ও iii$/;
const files=fs.readdirSync(dir).filter(x=>x.endsWith('.js')).sort();
// global counts from section mcq lines + multi xm
const cnt=[0,0,0,0];const xmLines=[];
for(const f of files){const L=fs.readFileSync(path.join(dir,f),'utf8').split('\n');
 L.forEach((ln,i)=>{const m=/^(\s*)(\[.*\])(,?)\s*$/.exec(ln);if(m&&/\], [0-3], '[emh]', /.test(ln)){try{const a=eval(m[2]);cnt[a[2]]++}catch(e){}}
  const x=/^(\s*xm: )(\[.*\])(,?)\s*$/.exec(ln);if(x)xmLines.push([f,i,x]);});}
const store={};
for(const [f,i,x] of xmLines){const arr=eval(x[2]);for(const a of arr){if(a[1].some(o=>MULTI.test(o)))cnt[a[2]]++;}}
for(const [f,i,x] of xmLines){const arr=eval(x[2]);
 for(const a of arr){if(a[1].some(o=>MULTI.test(o)))continue;const tgt=cnt.indexOf(Math.min(...cnt));
  const ans=a[1][a[2]],oth=a[1].filter((_,j)=>j!==a[2]);oth.splice(tgt,0,ans);a[1]=oth;a[2]=tgt;cnt[tgt]++;}
 store[f]=store[f]||fs.readFileSync(path.join(dir,f),'utf8').split('\n');store[f][i]=x[1]+enc(arr)+x[3];}
for(const f in store)fs.writeFileSync(path.join(dir,f),store[f].join('\n'));console.log('dist',cnt);
