/* ═══════════════════════════════════════════════════════════════════
   visuals1 — রক্ত ও রক্তরস: bloodComp, bloodSmear, plasmaComp, capExchange
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B24, PI = Math.PI;
const sm = (p, c, k) => B.smooth(p, c, k), f1 = v => (+v).toFixed(1);

/* কাচের পরীক্ষানল: x, y (মুখ), w, h; ভেতরের স্তর fill(g, clipId) */
const tube = (g, C, x, y, w, h, inner) => { const r = w / 2, d = `M${x} ${y}V${y + h - r}A${r} ${r} 0 0 0 ${x + w} ${y + h - r}V${y}Z`;
  const cp = B.clip(g, 'tb' + x + '_' + y, d), gi = E('g', { 'clip-path': cp }, g); inner(gi);
  E('path', { d, fill: 'none', stroke: FK.alpha(C.fg, .55), 'stroke-width': 1.4 }, g);
  E('path', { d: `M${x + 3.5} ${y + 6}V${y + h - r - 4}`, stroke: '#fff', 'stroke-width': 2.2, opacity: .55, 'stroke-linecap': 'round' }, g);
  E('rect', { x: x - 4, y: y - 4, width: w + 8, height: 5, rx: 2, fill: FK.alpha(C.fg, .2), stroke: FK.alpha(C.fg, .5), 'stroke-width': .8 }, g); return d; };

/* ═════════ রক্তের উপাদান — কেন্দ্রাতিগ যন্ত্রে ঘোরানো রক্ত ═════════ */
const HCT = { m: [45, 'পুরুষ', 'সুস্থ প্রাপ্তবয়স্ক পুরুষ', 'হেমাটোক্রিট (PCV) প্রায় 40–50% — রক্তের প্রায় 45% লোহিত কণিকা, 55% রক্তরস।'], f: [40, 'নারী', 'সুস্থ প্রাপ্তবয়স্ক নারী', 'হেমাটোক্রিট প্রায় 36–44% — ইস্ট্রোজেন ও মাসিকের রক্তক্ষরণের কারণে পুরুষের চেয়ে কম।'], a: [28, 'রক্তস্বল্পতা', 'রক্তস্বল্পতা (অ্যানিমিয়া)', 'লোহিত কণিকার স্তর পাতলা — লৌহ, ফলিক অ্যাসিড বা B<sub>12</sub> এর অভাব, রক্তক্ষরণ বা থ্যালাসেমিয়ায়।'], p: [60, 'পলিসাইথেমিয়া', 'পলিসাইথেমিয়া', 'লোহিত কণিকা অস্বাভাবিক বেশি — উঁচু পাহাড়ে বসবাস, পানিশূন্যতা বা অস্থিমজ্জার রোগে; রক্ত ঘন হয়ে প্রবাহ ধীর হয়।'] };
V.bloodComp = Object.assign({}, B.seg({
  id: 'bcp', t: 'রক্তের উপাদান — হেমাটোক্রিট নল', H: 300, def: 'm',
  cap: 'জমাট-রোধী (অ্যান্টিকোয়াগুলেন্ট) মেশানো রক্ত পরীক্ষানলে নিয়ে কেন্দ্রাতিগ যন্ত্রে ঘোরালে তিনটি স্তর হয়: ওপরে হালকা হলুদ রক্তরস (প্রায় 55%), মাঝে পাতলা সাদাটে "বাফি কোট" — শ্বেত কণিকা ও অণুচক্রিকা (1% এর কম), নিচে ঘন লাল লোহিত কণিকা (প্রায় 45%)। লোহিত কণিকার স্তরের শতকরা ভাগকে হেমাটোক্রিট বা প্যাকড সেল ভলিউম (PCV) বলে। চালাও চাপলে ঘোরানো ও স্তর আলাদা হওয়া দেখাবে।',
  types: Object.fromEntries(Object.entries(HCT).map(([k, v]) => [k, [v[1], v[2], v[3]]])),
  art(g, C, ty) {
    E('rect', { x: 8, y: 8, width: 344, height: 284, rx: 10, fill: FK.alpha(C.fg, .02), stroke: C.ln }, g);
    /* ডান পাশে তিনটি বিবর্ধিত বৃত্ত */
    const ins = (cx, cy, r, f) => { const cp = B.clip(g, 'bi' + cy, `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`), gi = E('g', { 'clip-path': cp }, g); f(gi); E('circle', { cx, cy, r, fill: 'none', stroke: FK.alpha(C.fg, .6), 'stroke-width': 1.2 }, g); };
    ins(262, 70, 40, gi => { E('rect', { x: 220, y: 28, width: 84, height: 84, fill: '#f6e6a6' }, gi); for (let i = 0; i < 26; i++) { const x = 226 + B.rnd(i) * 74, y = 36 + B.rnd(i + 40) * 70; if (i % 4 === 0) E('path', { d: B.ellD(x, y, 3.2, 2, i * 20), fill: '#d79a3a', stroke: '#9b6418', 'stroke-width': .4 }, gi); else if (i % 4 === 1) E('path', { d: `M${f1(x)} ${f1(y)}l2 3l2 -3M${f1(x + 2)} ${f1(y + 3)}v3`, stroke: '#6a7fc4', 'stroke-width': 1, fill: 'none' }, gi); else E('circle', { cx: f1(x), cy: f1(y), r: 1.1, fill: i % 2 ? '#4a9b6a' : '#b14a6a' }, gi); } });
    ins(262, 164, 36, gi => { E('rect', { x: 220, y: 120, width: 84, height: 84, fill: '#f3ead8' }, gi); B.wbc(gi, 250, 156, 13, 'neu', { seed: 4 }); B.wbc(gi, 280, 176, 10, 'lym', { seed: 7 }); [[276, 142], [238, 182], [286, 156], [262, 186], [246, 134]].forEach(([x, y], i) => B.plt(gi, x, y, 2.6, i + 2)); });
    ins(262, 250, 36, gi => { E('rect', { x: 220, y: 210, width: 84, height: 84, fill: '#9b2b22' }, gi); for (let j = 0; j < 6; j++) for (let i = 0; i < 6; i++) B.rbcFace(gi, 228 + i * 14 + (j % 2) * 7, 218 + j * 13, 7.2, { sy: .78, rot: (i * 17 + j * 31) % 40 - 20 }); });
    [['রক্তরস', 'পানি, আমিষ, লবণ, পুষ্টি, হরমোন', 70], ['বাফি কোট', 'শ্বেত কণিকা + অণুচক্রিকা', 164], ['লোহিত কণিকা', 'ঠাসাঠাসি দ্বি-অবতল চাকতি', 250]].forEach(([a, b2, y]) => { B.tx(g, 348, y - 46 + (y === 70 ? 2 : 6), a, { fs: 10.5, a: 'end', w: 600 }); });
  },
  anim(g, C, ty, t) {
    const hct = HCT[ty][0], X0 = 70, Y0 = 34, Wt = 46, Ht = 236, run = 6, u = t ? Math.min(1, ((t % (run + 3)) / run)) : 1;
    /* ঘোরার সময় নল হালকা কাঁপে */
    const spin = t && (t % (run + 3)) < run * .8;
    const top = Y0 + 14, bot = Y0 + Ht, L = bot - top, rbcTop = top + L * (1 - hct / 100), buf = 3;
    const gt = E('g', { transform: spin ? `rotate(${f1(Math.sin(t * 40) * 1.2)} ${X0 + Wt / 2} ${Y0})` : null }, g);
    tube(gt, C, X0, Y0, Wt, Ht, gi => {
      /* মিশ্র রক্ত থেকে ধীরে স্তর আলাদা */
      const k = FK.ease(u), front = top + (rbcTop - top) * k;
      E('rect', { x: X0, y: top, width: Wt, height: L, fill: '#8f2a22' }, gi);
      E('rect', { x: X0, y: top, width: Wt, height: front - top, fill: B.lin(gi, 'fat', 90) , opacity: .95 }, gi);
      E('rect', { x: X0, y: top, width: Wt, height: front - top, fill: '#f3d885', opacity: .65 }, gi);
      if (k > .6) E('rect', { x: X0, y: front - buf, width: Wt, height: buf + 1, fill: '#f1ece0', opacity: (k - .6) / .4 }, gi);
      E('rect', { x: X0, y: front, width: Wt, height: bot - front + 20, fill: B.lin(gi, 'art', 0, { rev: true }) }, gi);
      if (k < 1) for (let i = 0; i < 14; i++) E('circle', { cx: f1(X0 + 6 + B.rnd(i) * (Wt - 12)), cy: f1(front - 4 - B.rnd(i + 9) * 18 * (1 - k)), r: 1.6, fill: '#a3362b', opacity: 1 - k }, gi);
    });
    /* মাপকাঠি ও শতকরা */
    for (let p = 0; p <= 100; p += 10) { const y = bot - L * p / 100; E('path', { d: `M${X0 + Wt + 4} ${f1(y)}h${p % 50 ? 4 : 8}`, stroke: C.mu, 'stroke-width': .8 }, g); if (p % 50 === 0) T(g, X0 + Wt + 15, y + 3.5, p + '%', { fs: 8.5, c: C.mu }); }
    if (u >= 1) { const ry = (rbcTop + bot) / 2, py = (top + rbcTop) / 2;
      B.tx(g, X0 - 6, py, (100 - hct) + '%', { fs: 13, a: 'end', w: 650, c: '#b08a16' }); B.tx(g, X0 - 6, ry, hct + '%', { fs: 13, a: 'end', w: 650, c: '#a3261c' }); B.tx(g, X0 - 6, rbcTop + 2, '<1%', { fs: 8.5, a: 'end', c: C.mu });
      [[py, 70], [rbcTop, 164], [ry, 250]].forEach(([y, iy]) => E('path', { d: `M${X0 + Wt + 30} ${f1(y)}C${190} ${f1(y)} ${200} ${iy} ${222} ${iy}`, stroke: FK.alpha(C.fg, .4), 'stroke-width': .8, fill: 'none', 'stroke-dasharray': '3 2' }, g)); }
    else B.tx(g, X0 + Wt / 2, Y0 - 12, 'ঘুরছে… প্রায় 3000 rpm', { fs: 9.5, a: 'middle', c: C.mu });
  }
}));

/* ═════════ রক্তের প্রলেপ (স্মিয়ার) — লিশম্যান রঞ্জন ═════════ */
const SM = (() => { const out = []; for (let j = 0; j < 9; j++) for (let i = 0; i < 12; i++) { const x = 16 + i * 29 + (j % 2) * 14 + (B.rnd(i * 7 + j) - .5) * 10, y = 16 + j * 34 + (B.rnd(i + j * 13) - .5) * 10; out.push([x, y, 10.5 + B.rnd(i * 3 + j * 5) * 1.6, B.rnd(i + j) * 180]); } return out; })();
const WB = [['neu', 92, 92, 15], ['lym', 252, 76, 11.5], ['mon', 274, 222, 18], ['eos', 104, 238, 15.5], ['bas', 186, 156, 13.5]];
V.bloodSmear = Object.assign({ t: 'রক্তের প্রলেপ — অণুবীক্ষণে দেখা কণিকা', k: ['2d', 'anim', 'int', 'quiz'], cap: 'লিশম্যান রঞ্জনে রঞ্জিত রক্তের পাতলা প্রলেপ (তেল-নিমজ্জন লেন্স, প্রায় 1000 গুণ)। গোলাপি দ্বি-অবতল লোহিত কণিকার মাঝখান ফ্যাকাশে; নিউক্লিয়াস নেই। প্রতি 600–700টি লোহিত কণিকায় মাত্র প্রায় 1টি শ্বেত কণিকা — এখানে বোঝার সুবিধার জন্য পাঁচ ধরনের শ্বেত কণিকা একসাথে দেখানো হয়েছে। বেগুনি ছোট টুকরোগুলো অণুচক্রিকা। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 330, label: 'রক্তের প্রলেপ', idle: true,
  art(g, C, part) {
    E('rect', { x: 0, y: 0, width: 360, height: 330, rx: 12, fill: '#f7ecea' }, g);
    const rb = part('rbc'); SM.forEach(([x, y, r, a]) => { if (WB.some(([, wx, wy, wr]) => Math.hypot(x - wx, y - wy) < wr + r * .7)) return; B.rbcFace(rb, x, y, r, { sy: .93, rot: a, tone: 'pale' }); });
    WB.forEach(([ty, x, y, r], i) => B.wbc(part(ty), x, y, r, ty, { seed: i * 5 + 2 }));
    const pl = part('plt'); [[150, 40], [322, 120], [40, 160], [226, 292], [152, 282], [330, 300], [212, 108]].forEach(([x, y], i) => B.plt(pl, x, y, 3, i + 1));
    B.scale(g, C, 300, 318, 40, '10 µm');
  },
  idle(g, C, t) { /* অণুবীক্ষণে ফোকাস খোঁজা — একটি হালকা বৃত্ত ঘুরে ঘুরে প্রতিটি শ্বেত কণিকায় থামে */
    const n = WB.length, k = (t * .25) % n, i = Math.floor(k), u = k - i, a = WB[i], b = WB[(i + 1) % n], e = u < .7 ? 0 : FK.ease((u - .7) / .3), x = a[1] + (b[1] - a[1]) * e, y = a[2] + (b[2] - a[2]) * e, r = (u < .7 ? a[3] : a[3] + (b[3] - a[3]) * e) + 6;
    E('circle', { cx: f1(x), cy: f1(y), r: f1(r), fill: 'none', stroke: '#1f6fb2', 'stroke-width': 1.6, 'stroke-dasharray': '4 3', opacity: .8 }, g); },
  parts: [
    { id: 'rbc', bn: 'লোহিত রক্তকণিকা (এরিথ্রোসাইট)', lb: 'লোহিত কণিকা', en: 'Erythrocyte', fn: 'ব্যাস প্রায় 7.5–8 µm, নিউক্লিয়াসহীন দ্বি-অবতল চাকতি; হিমোগ্লোবিনে ভরা — O<sub>2</sub> ও কিছু CO<sub>2</sub> বহন। প্রতি মাইক্রোলিটারে পুরুষে প্রায় 50 লক্ষ, নারীতে প্রায় 45 লক্ষ।', a: [134, 300], l: [72, 322], an: 'end' },
    { id: 'neu', bn: 'নিউট্রোফিল', en: 'Neutrophil', fn: 'সবচেয়ে বেশি (শ্বেত কণিকার 40–70%); 3–5 খণ্ডের নিউক্লিয়াস, সূক্ষ্ম হালকা দানা; ব্যাকটেরিয়া ভক্ষণে প্রথম সাড়া দেয়।', a: [92, 78], l: [60, 30], an: 'middle' },
    { id: 'lym', bn: 'লিম্ফোসাইট', en: 'Lymphocyte', fn: 'দ্বিতীয় সর্বাধিক (20–40%); বড় গোল গাঢ় নিউক্লিয়াস, চারপাশে সরু আকাশি সাইটোপ্লাজম; B কোষ অ্যান্টিবডি তৈরি করে, T কোষ সংক্রমিত কোষ ধ্বংস করে।', a: [252, 66], l: [290, 26], an: 'middle' },
    { id: 'mon', bn: 'মনোসাইট', en: 'Monocyte', fn: 'সবচেয়ে বড় (12–20 µm), 2–8%; বৃক্কাকার নিউক্লিয়াস, ধূসর-নীল সাইটোপ্লাজম; টিস্যুতে গিয়ে ম্যাক্রোফেজ হয়ে বড় কণা ও মৃত কোষ ভক্ষণ করে।', a: [274, 206], l: [320, 176], an: 'middle' },
    { id: 'eos', bn: 'ইওসিনোফিল', en: 'Eosinophil', fn: '1–4%; দুই খণ্ডের নিউক্লিয়াস, কমলা-লাল মোটা দানা (অম্লীয় রঞ্জক ইওসিনে রঞ্জিত); পরজীবী কৃমি ও অ্যালার্জিতে বাড়ে।', a: [104, 222], l: [54, 196], an: 'middle' },
    { id: 'bas', bn: 'বেসোফিল', en: 'Basophil', fn: 'সবচেয়ে কম (1% এর কম); গাঢ় বেগুনি মোটা দানায় নিউক্লিয়াস ঢাকা; হিস্টামিন ও হেপারিন ছাড়ে — প্রদাহ ও অ্যালার্জিতে ভূমিকা।', a: [186, 144], l: [178, 112], an: 'middle' },
    { id: 'plt', bn: 'অণুচক্রিকা (থ্রম্বোসাইট)', lb: 'অণুচক্রিকা', en: 'Platelet', fn: 'মেগাক্যারিওসাইটের সাইটোপ্লাজমের 2–4 µm টুকরো, নিউক্লিয়াস নেই; প্রতি মাইক্রোলিটারে 1.5–4.5 লক্ষ; রক্ত জমাট বাঁধায়।', a: [226, 292], l: [250, 322], an: 'start' }
  ]
}));

/* ═════════ রক্তরসের উপাদান ═════════ */
const PL = [['পানি', 91.5, '#7fb3e0'], ['আমিষ', 7, '#d79a3a'], ['অন্যান্য দ্রব', 1.5, '#8b6fc2']];
const PR = [['অ্যালবুমিন', 54, '#e2b04a', '3.5–5 g/dL', 'যকৃতে তৈরি; অভিস্রবণ চাপ (অনকোটিক) বজায় রাখে, ফ্যাটি অ্যাসিড, বিলিরুবিন, ওষুধ ও হরমোন বহন করে'], ['গ্লোবিউলিন', 38, '#6a8fd0', '2–3.5 g/dL', 'α ও β গ্লোবিউলিন লৌহ, তামা ও চর্বি বহন করে; γ গ্লোবিউলিন = অ্যান্টিবডি (রোগ প্রতিরোধ)'], ['ফাইব্রিনোজেন', 7, '#c4583f', '0.2–0.4 g/dL', 'যকৃতে তৈরি; রক্ত জমাট বাঁধার সময় অদ্রবণীয় ফাইব্রিন সুতায় পরিণত হয়'], ['অন্যান্য', 1, '#9a9a9a', '', 'এনজাইম, হরমোন (আমিষ জাতীয়) ইত্যাদি']];
V.plasmaComp = Object.assign({}, B.seg({
  id: 'plc', t: 'রক্তরস ও এর আমিষ', H: 290, def: 'cmp',
  cap: 'রক্তরস (প্লাজমা) রক্তের তরল অংশ — প্রায় 91–92% পানি, প্রায় 7% আমিষ এবং প্রায় 1–2% অন্যান্য দ্রব (Na<sup>+</sup>, Cl<sup>−</sup>, HCO<sub>3</sub><sup>−</sup>, গ্লুকোজ, অ্যামাইনো অ্যাসিড, ইউরিয়া, হরমোন, দ্রবীভূত O<sub>2</sub> ও CO<sub>2</sub>)। শতকরা হিসাব আমিষের ক্ষেত্রে মোট রক্তরস-আমিষের ভাগ (Tortora অনুসারে)। ধরন বেছে নাও, বিবর্ধিত বৃত্তে চালাও চাপো।',
  types: { cmp: ['উপাদান', 'রক্তরসের উপাদান', 'পানি দ্রাবক হিসেবে সব বহন করে ও তাপ ছড়ায়; লবণ অভিস্রবণ ও pH (7.35–7.45) ঠিক রাখে।'], pro: ['আমিষ', 'রক্তরসের আমিষ (মোট প্রায় 6–8 g/dL)', 'অ্যালবুমিন প্রায় 54%, গ্লোবিউলিন প্রায় 38%, ফাইব্রিনোজেন প্রায় 7%।'], ser: ['সিরাম', 'সিরাম = রক্তরস − জমাট বাঁধার উপাদান', 'রক্ত জমাট বাঁধতে দিলে ফাইব্রিনোজেন ফাইব্রিনে পরিণত হয়ে কণিকাসহ জমাট (ক্লট) তৈরি করে; ওপরের স্বচ্ছ হলুদ তরলটি সিরাম — এতে ফাইব্রিনোজেন নেই। রোগনির্ণয়ের অনেক পরীক্ষা সিরামে করা হয়।'] },
  art(g, C, ty) {
    E('rect', { x: 8, y: 8, width: 344, height: 274, rx: 10, fill: FK.alpha(C.fg, .02), stroke: C.ln }, g);
    if (ty === 'cmp' || ty === 'pro') { const D = ty === 'cmp' ? PL : PR; let y = 26; const X0 = 24, Wb = 150;
      B.tx(g, X0, 22, ty === 'cmp' ? 'রক্তরসের গঠন (%)' : 'রক্তরসের আমিষ (মোট আমিষের %)', { fs: 10, w: 600 });
      let acc = 0; D.forEach(([n, p, col], i) => { const h = Math.max(4, p / 100 * 230); E('rect', { x: X0, y: 32 + acc, width: 36, height: h, fill: col, stroke: FK.alpha('#000', .25), 'stroke-width': .6 }, g);
        const yy = 32 + acc + h / 2, ly = ty === 'cmp' ? [120, 214, 250][i] : [90, 190, 226, 254][i];
        E('path', { d: `M${X0 + 38} ${f1(yy)}L${X0 + 50} ${ly - 4}h4`, stroke: C.mu, 'stroke-width': .8, fill: 'none' }, g);
        B.tx(g, X0 + 56, ly, `${n} — ${p}%`, { fs: 9.8, w: 600 }); if (ty === 'pro' && D[i][3]) B.tx(g, X0 + 56, ly + 12, D[i][3], { fs: 8.6, c: C.mu }); acc += h; });
      if (ty === 'cmp') ['লবণ (প্রায় 0.9%) — Na<sup>+</sup>, Cl<sup>−</sup>, HCO<sub>3</sub><sup>−</sup>', 'গ্লুকোজ, অ্যামাইনো অ্যাসিড, লিপিড', 'ইউরিয়া, হরমোন, O<sub>2</sub>, CO<sub>2</sub>'].forEach((s, i) => B.tx(g, X0 + 56, 264 + i * 11, s, { fs: 8.4, c: C.mu }));
    } else {
      /* জমাট বাঁধা রক্তের নল ও রক্তরসের নল পাশাপাশি */
      [[44, 'রক্তরস', false], [124, 'সিরাম', true]].forEach(([x, s, clot]) => { tube(g, C, x, 46, 40, 196, gi => { E('rect', { x, y: 60, width: 40, height: 200, fill: '#f3d885', opacity: .9 }, gi);
        if (clot) { const d = sm([[x - 2, 150], [x + 10, 144], [x + 22, 150], [x + 34, 143], [x + 44, 150], [x + 44, 260], [x - 2, 260]], true); E('path', { d, fill: B.lin(gi, 'art', 0, { rev: true }) }, gi); for (let i = 0; i < 18; i++) E('path', { d: `M${x + B.rnd(i) * 40} ${150 + B.rnd(i + 5) * 100}l${8 - B.rnd(i + 2) * 16} ${6 + B.rnd(i + 3) * 8}`, stroke: '#f2d6c8', 'stroke-width': .6, opacity: .6 }, gi); }
        else { E('rect', { x, y: 150, width: 40, height: 110, fill: B.lin(gi, 'art', 0, { rev: true }) }, gi); E('rect', { x, y: 147, width: 40, height: 3, fill: '#f1ece0' }, gi); } });
        B.tx(g, x + 20, 260, clot ? 'জমাট রক্ত' : 'জমাট-রোধী মিশ্রিত', { fs: 9, a: 'middle', c: C.mu }); B.tx(g, x + 20, 38, s, { fs: 10.5, a: 'middle', w: 650 }); });
      B.tx(g, 24, 276, 'রক্তরসে ফাইব্রিনোজেন আছে; সিরামে নেই', { fs: 9.5, w: 600 });
    }
  },
  anim(g, C, ty, t) {
    /* বিবর্ধিত বৃত্ত: রক্তরসের অণু */
    const cx = ty === 'ser' ? 268 : 282, cy = 140, r = ty === 'ser' ? 76 : 62;
    const cp = B.clip(g, 'plz' + ty, `M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`), gi = E('g', { 'clip-path': cp }, g);
    E('rect', { x: cx - r, y: cy - r, width: 2 * r, height: 2 * r, fill: '#f8edc4' }, gi);
    const mv = (i, sp) => [cx - r + ((B.rnd(i) * 2 * r + t * sp * (6 + B.rnd(i + 2) * 6)) % (2 * r)), cy - r + ((B.rnd(i + 30) * 2 * r + Math.sin(t * .7 + i) * 6) + 2 * r) % (2 * r)];
    let dw = ''; for (let i = 0; i < 46; i++) { const [x, y] = mv(i + 100, 1.6); dw += B.ellD(x, y, 1.5, 1.2, 0); } E('path', { d: dw, fill: '#9cc4e8', opacity: .8 }, gi);
    const nA = 14, nG = 9, nF = ty === 'ser' ? 0 : 2;
    for (let i = 0; i < nA; i++) { const [x, y] = mv(i, 1); E('path', { d: B.ellD(x, y, 5.2, 3.4, (i * 40 + t * 20) % 180), fill: '#e7b552', stroke: '#a77a1c', 'stroke-width': .6 }, gi); }
    for (let i = 0; i < nG; i++) { const [x, y] = mv(i + 50, .8), a = (i * 50 + t * 15) * PI / 180, c = Math.cos(a), s = Math.sin(a); const Y = (u, v) => `${f1(x + u * c - v * s)} ${f1(y + u * s + v * c)}`; E('path', { d: `M${Y(0, 6)}L${Y(0, 0)}L${Y(-5, -5)}M${Y(0, 0)}L${Y(5, -5)}`, stroke: '#4f74bd', 'stroke-width': 2.4, 'stroke-linecap': 'round', fill: 'none' }, gi); }
    for (let i = 0; i < nF; i++) { const [x, y] = mv(i + 80, .5); E('path', { d: `M${f1(x - 16)} ${f1(y)}h32`, stroke: '#c4583f', 'stroke-width': 3, 'stroke-linecap': 'round' }, gi); E('path', { d: `M${f1(x - 16)} ${f1(y)}h3M${f1(x + 13)} ${f1(y)}h3M${f1(x - 1.5)} ${f1(y)}h3`, stroke: '#8e2f1d', 'stroke-width': 5, 'stroke-linecap': 'round' }, gi); }
    for (let i = 0; i < 8; i++) { const [x, y] = mv(i + 140, 1.3); B.hexU(gi, x, y, 3, '#3f9a5a', { sw: .8 }); }
    E('circle', { cx, cy, r, fill: 'none', stroke: FK.alpha(C.fg, .6), 'stroke-width': 1.2 }, g);
    const lg = [['অ্যালবুমিন', '#c48a1c'], ['অ্যান্টিবডি (γ গ্লোবিউলিন)', '#4f74bd'], ...(nF ? [['ফাইব্রিনোজেন', '#c4583f']] : []), ['গ্লুকোজ', '#3f9a5a'], ['পানি', '#5f9cd2']];
    lg.forEach(([s, c], i) => B.tx(g, ty === 'ser' ? 200 : 352, ty === 'ser' ? 236 + i * 11 : 214 + i * 12, s, { fs: 8.6, a: ty === 'ser' ? 'start' : 'end', c, w: 600 }));
  }
}));

/* ═════════ কৈশিকনালিতে তরলের আদান-প্রদান ও লসিকা তৈরি ═════════ */
const CX = { n: [30, 4.2, 1, 'স্বাভাবিক', 'স্বাভাবিক অবস্থা', 'ধমনি প্রান্তে কৈশিক চাপ বেশি থাকায় তরল বেরিয়ে যায়, শিরা প্রান্তে অভিস্রবণ (অনকোটিক) চাপ বেশি হওয়ায় বেশিরভাগ ফেরত আসে; বাকি প্রায় 10% লসিকানালি নেয়।'],
  a: [30, 2, 1, 'অ্যালবুমিন কম', 'অ্যালবুমিন কম (অপুষ্টি, যকৃৎ বা বৃক্কের রোগ)', 'রক্তরসের অনকোটিক চাপ কমে — শিরা প্রান্তে তরল কম ফেরে, টিস্যুতে পানি জমে শোথ (ইডিমা) হয়; প্রোটিনের অভাবে শিশুর কোয়াশিয়রকরে পেট-পা ফোলে।'],
  h: [44, 4.2, 1, 'উচ্চ কৈশিক চাপ', 'শিরায় চাপ বাড়লে (হার্ট ফেইলিউর)', 'হৃৎপিণ্ড ঠিকমতো রক্ত পাম্প করতে না পারলে শিরায় রক্ত জমে কৈশিক চাপ বাড়ে — পুরো দৈর্ঘ্যে বেশি তরল বেরোয়, পা ও ফুসফুসে শোথ হয়।'],
  l: [30, 4.2, .15, 'লসিকানালি বন্ধ', 'লসিকানালি বন্ধ (ফাইলেরিয়া)', 'ফাইলেরিয়া কৃমি (Wuchereria bancrofti, মশাবাহিত) লসিকানালি বন্ধ করলে অতিরিক্ত তরল টিস্যুতে জমে থাকে — পা ও অণ্ডকোষ ফুলে গোদ (এলিফ্যান্টিয়াসিস); বাংলাদেশের উত্তরাঞ্চলে একসময় ব্যাপক ছিল।'] };
const starling = (pa, alb) => { const pv = pa - 20, pic = 28 * alb / 4.2, pif = -3, piif = 8; return { pv, pic, at: x => (pa + (pv - pa) * x) - pif - (pic - piif) }; };
V.capExchange = Object.assign({}, B.seg({
  id: 'cxe', t: 'কৈশিকনালিতে তরলের আদান-প্রদান ও লসিকা তৈরি', H: 300, def: 'n',
  sl: [{ k: 'pa', l: 'ধমনি প্রান্তে কৈশিক চাপ', min: 20, max: 50, step: 1, val: 30, unit: ' mmHg' }, { k: 'alb', l: 'রক্তরসের অ্যালবুমিন', min: 1.5, max: 5, step: .1, val: 4.2, unit: ' g/dL', d: 1 }],
  cap: 'কৈশিকনালির প্রাচীর এক স্তর এন্ডোথেলিয়াম — পানি ও ছোট অণু পার হয়, কিন্তু আমিষ প্রায় পার হয় না। দুই বিপরীত বল: কৈশিক রক্তচাপ (তরল ঠেলে বের করে) এবং রক্তরসের আমিষের অনকোটিক চাপ (প্রায় 28 mmHg, তরল টেনে ফেরায়)। Guyton এর হিসাবে ধমনি প্রান্তে নিট বহিঃপ্রবাহ চাপ প্রায় +13 mmHg, শিরা প্রান্তে নিট অন্তঃপ্রবাহ প্রায় −7 mmHg; ছেঁকে বের হওয়া তরলের প্রায় 90% ফেরে, প্রায় 10% লসিকা হয় — দিনে প্রায় 2–3 লিটার। স্লাইডার বা ধরন বদলাও।',
  types: Object.fromEntries(Object.entries(CX).map(([k, v]) => [k, [v[3], v[4], v[5]]])),
  more(ty, ctx) { const s = starling(ctx.v.pa, ctx.v.alb), a = s.at(0), b = s.at(1); return `<div class="small">ধমনি প্রান্তে নিট চাপ <b>${a > 0 ? '+' : ''}${a.toFixed(0)}</b> mmHg (বাইরে), শিরা প্রান্তে <b>${b > 0 ? '+' : ''}${b.toFixed(0)}</b> mmHg ${b < 0 ? '(ভেতরে)' : '(তবুও বাইরে!)'}; রক্তরসের অনকোটিক চাপ প্রায় ${s.pic.toFixed(0)} mmHg।</div>`; },
  art(g, C, ty, ctx) {
    if (ctx._ty !== ty) { ctx._ty = ty; ctx.v.pa = CX[ty][0]; ctx.v.alb = CX[ty][1]; const r = ctx.root; [['pa', CX[ty][0]], ['alb', CX[ty][1]]].forEach(([k, v]) => { const el = r.querySelector(`[data-sl="${k}"]`); if (el) { el.value = v; el.dispatchEvent(new Event('input')); } }); }
    const s = starling(ctx.v.pa, ctx.v.alb), lym = CX[ty][2];
    let ex = 0; for (let i = 0; i <= 20; i++) ex += s.at(i / 20); ex /= 21; const edema = Math.max(0, Math.min(1, (ex - 6 * lym) / 6));
    /* টিস্যুর কোষ (ইডিমায় ফাঁক বাড়ে) */
    const tis = B.TS('sub'); E('rect', { x: 8, y: 8, width: 344, height: 284, rx: 10, fill: FK.alpha('#bfe0f2', .25 + edema * .45), stroke: C.ln }, g);
    let dC = '', dN = ''; const gap = 1 + edema * .3;
    for (let j = 0; j < 2; j++) for (let i = 0; i < 9; i++) { const y = j ? 246 : 54, x = 30 + i * 38 + (j ? 16 : 0); if (j === 0 && i > 0 && i < 9 && y < 70 && x > 40 && x < 330 && false) continue;
      dC += sm([[x - 15 / gap, y - 12 / gap], [x + 15 / gap, y - 13 / gap], [x + 17 / gap, y + 11 / gap], [x - 14 / gap, y + 13 / gap]], true, .6); dN += B.ellD(x, y, 4.5, 3.6, i * 20); }
    E('path', { d: dC, fill: B.TS('cyt').lt, stroke: B.TS('cyt').dk, 'stroke-width': .6 }, g); E('path', { d: dN, fill: B.TS('nuc').c }, g);
    /* লসিকা কৈশিকনালি (অন্ধ প্রান্ত, ওপরে) */
    const ly = B.TS('lym'); E('path', { d: 'M60 96Q60 84 72 84H352V112H72Q60 112 60 100Z', fill: ly.lt, stroke: ly.dk, 'stroke-width': 1 }, g);
    for (let x = 76; x < 350; x += 26) E('path', { d: `M${x} 112l8 -6M${x} 84l8 6`, stroke: ly.dk, 'stroke-width': 1, opacity: lym < .5 ? .3 : .9 }, g);
    if (lym < .5) { E('path', { d: 'M300 80v36', stroke: '#8a5a2a', 'stroke-width': 3 }, g); B.tx(g, 300, 76, 'বাধা', { fs: 8.5, a: 'middle', c: '#8a5a2a', w: 600 }); }
    B.tx(g, 70, 79, 'লসিকা কৈশিকনালি', { fs: 9, c: ly.dk, w: 600 });
    /* রক্ত কৈশিকনালি */
    const sv = ctx.svg; if (!sv._cxg) { sv._cxg = 'cxg' + Math.random().toString(36).slice(2, 8); let dd = [...sv.children].find(c => c.tagName === 'defs'); if (!dd) { dd = E('defs', {}, sv); sv.insertBefore(dd, sv.firstChild); } const gr = E('linearGradient', { id: sv._cxg, x1: 0, x2: 1, y1: 0, y2: 0 }, dd); E('stop', { offset: 0, 'stop-color': '#d1473a' }, gr); E('stop', { offset: 1, 'stop-color': '#6b4a9a' }, gr); }
    E('path', { d: 'M8 150H352V194H8Z', fill: `url(#${sv._cxg})`, opacity: .9 }, g); E('path', { d: 'M8 150H352M8 194H352', stroke: '#7a2a24', 'stroke-width': 1.6 }, g);
    for (let x = 20; x < 352; x += 22) E('path', { d: `M${x} 150h18M${x + 11} 194h18`, stroke: '#f5d5cf', 'stroke-width': .7 }, g);
    B.tx(g, 14, 142, 'ধমনিকা প্রান্ত', { fs: 9.5, c: '#b33', w: 600 }); B.tx(g, 346, 142, 'শিরাকা প্রান্ত', { fs: 9.5, a: 'end', c: '#5a3d8a', w: 600 });
    /* নিট চাপের তীর */
    for (let i = 0; i <= 6; i++) { const x = 34 + i * 49, v = s.at(i / 6), L = Math.min(34, Math.abs(v) * 2.2); if (L < 2) continue; const up = v > 0;
      [[150, -1], [194, 1]].forEach(([y0, dir]) => { const y1 = up ? y0 + dir * L : y0, y2 = up ? y0 : y0 + dir * L; B.carrow(g, `M${x} ${up ? y0 : y0 + dir * L}V${up ? y0 + dir * L : y0 + dir * 2}`, up ? '#2c7fbf' : '#e07a1f', { w: 2.2, s: 5 }); });
      T(g, x, 175, (v > 0 ? '+' : '') + v.toFixed(0), { fs: 9, a: 'middle', c: '#fff', w: 650 }); }
    B.tx(g, 180, 287, edema > .25 ? 'টিস্যুতে তরল জমছে — শোথ (ইডিমা)' : 'নীল তীর: বাইরে (ছাঁকন) · কমলা তীর: ভেতরে (পুনঃশোষণ)', { fs: 9.5, a: 'middle', w: 600, c: edema > .25 ? '#b04a1a' : C.fg });
  },
  anim(g, C, ty, t, ctx) {
    const s = starling(ctx.v.pa, ctx.v.alb), lym = CX[ty][2];
    for (let i = 0; i < 9; i++) { const x = 20 + ((i * 40 + t * 22) % 330); B.rbcFace(g, x, 172 + Math.sin(i * 2 + t) * 6, 6, { sy: .7, tone: x > 200 ? 'v' : null }); }
    /* তরলের কণা: বাইরে যায়, কিছু ফেরে, কিছু লসিকায় */
    for (let i = 0; i < 16; i++) { const u = ((t * .35 + i / 16) % 1), x0 = 30 + (i % 8) * 40, v = s.at((x0 - 20) / 320); let x = x0, y;
      if (v > 0) { y = 150 - u * 34; if (i % 3 === 0 && u > .5) { y = 116 - (u - .5) * 30 * lym; } }
      else { y = 116 + u * 34; }
      E('circle', { cx: f1(x), cy: f1(y), r: 2, fill: '#2c7fbf', opacity: .8 }, g); }
    for (let i = 0; i < 6; i++) { const x = 80 + ((t * 30 * lym + i * 46) % 270); E('circle', { cx: f1(x), cy: 98, r: 2, fill: '#c9b25a' }, g); }
  }
}));
})();
