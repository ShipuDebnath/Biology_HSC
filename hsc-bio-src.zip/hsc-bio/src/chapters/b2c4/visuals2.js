/* ═══════════════════════════════════════════════════════════════════
   visuals2 — রক্তকণিকা: rbcStruct, wbcTypes, diapedesis, hematopoiesis, rbcLife
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B24, PI = Math.PI;
const sm = (p, c, k) => B.smooth(p, c, k), f1 = v => (+v).toFixed(1);

/* Evans–Fung সমীকরণ: লোহিত কণিকার পুরুত্ব (µm), ρ = r/R */
const rbcZ = rho => { const q = 1 - rho * rho; return q <= 0 ? 0 : .5 * Math.sqrt(q) * (.81 + 7.83 * rho * rho - 4.39 * rho ** 4); };  /* অর্ধেক পুরুত্ব; Evans & Fung 1972, R = 3.91 µm */

V.rbcStruct = Object.assign({}, B.seg({
  id: 'rbs', t: 'লোহিত রক্তকণিকার গঠন', H: 280, def: 'face',
  cap: 'লোহিত কণিকা নিউক্লিয়াস, মাইটোকন্ড্রিয়া ও রাইবোজোমহীন দ্বি-অবতল চাকতি — ব্যাস প্রায় 7.8 µm, কিনারায় পুরুত্ব প্রায় 2.6 µm, মাঝখানে মাত্র প্রায় 0.8 µm (Evans ও Fung এর পরিমাপ)। এ আকৃতিতে আয়তনের তুলনায় তল বেশি — O<sub>2</sub> দ্রুত ব্যাপিত হয়, আর নমনীয় ঝিল্লির কারণে কণিকাটি নিজের চেয়ে সরু (3–5 µm) কৈশিকনালিতেও বেঁকে ঢুকতে পারে। মাইটোকন্ড্রিয়া না থাকায় নিজে বহন করা O<sub>2</sub> খরচ করে না — শক্তি পায় অবাত গ্লাইকোলাইসিসে।',
  types: { face: ['সামনে থেকে', 'দ্বি-অবতল চাকতি', 'ঘোরালে মাঝখানের অবতল অংশ দেখা যায়। সাধারণ অণুবীক্ষণে এ কারণেই মাঝখানটা ফ্যাকাশে দেখায়।'], cs: ['প্রস্থচ্ছেদ', 'প্রস্থচ্ছেদের মাপ', 'কিনারা মোটা, মাঝখান পাতলা — ডাম্বেলের মতো প্রস্থচ্ছেদ। কোনো বিন্দুই তল থেকে প্রায় 1.3 µm এর বেশি দূরে নয় — ব্যাপনের পথ ছোট।'], cap: ['কৈশিকনালিতে', 'সরু কৈশিকনালিতে বেঁকে চলা', 'কৈশিকনালির ভেতরের ব্যাস প্রায় 5 µm — লোহিত কণিকা প্যারাশুট বা ঘণ্টার আকৃতি নিয়ে এক সারিতে চলে এবং বেরিয়ে আবার আগের আকার ফিরে পায়। পুরোনো কণিকা নমনীয়তা হারালে প্লীহার সরু পথে আটকে ধ্বংস হয়।'], hb: ['হিমোগ্লোবিন', 'হিমোগ্লোবিন অণু', 'চারটি গ্লোবিন শিকল (2টি α, 2টি β), প্রতিটিতে একটি হিম গ্রুপ, যার কেন্দ্রে Fe<sup>2+</sup>; প্রতিটি Fe<sup>2+</sup> একটি O<sub>2</sub> অণু বাঁধে, তাই এক হিমোগ্লোবিন 4টি O<sub>2</sub> বহন করে। একটি O<sub>2</sub> বাঁধলে বাকিগুলো সহজে বাঁধে (সহযোগী বন্ধন)। একটি লোহিত কণিকায় প্রায় 28 কোটি হিমোগ্লোবিন অণু থাকে।', 'স্বাভাবিক হিমোগ্লোবিন: পুরুষে প্রায় 13.5–17.5 g/dL, নারীতে প্রায় 12–15.5 g/dL।'] },
  art(g, C, ty) { E('rect', { x: 8, y: 8, width: 344, height: 264, rx: 10, fill: FK.alpha(C.fg, .02), stroke: C.ln }, g);
    if (ty === 'cs') { const k = 19, cx = 180, cy = 132, R = 3.91; let up = [], dn = [];
      for (let i = 0; i <= 60; i++) { const rho = -1 + i / 30, z = rbcZ(Math.abs(rho)); up.push([cx + rho * R * k, cy - z * k]); dn.push([cx + rho * R * k, cy + z * k]); }
      const d = 'M' + up.map(p => p.map(f1).join(' ')).join('L') + 'L' + dn.reverse().map(p => p.map(f1).join(' ')).join('L') + 'Z';
      E('path', { d, fill: B.lin(g, 'art', 90), stroke: B.TS('art').dk, 'stroke-width': 1.2 }, g);
      const dim = (x0, y0, x1, y1, s, lx, ly, a) => { E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: C.fg, 'stroke-width': .9, 'marker-end': B.mk(g, C.fg, 5), 'marker-start': B.mk(g, C.fg, 5) }, g); B.tx(g, lx, ly, s, { fs: 10.5, a: a || 'middle', w: 600 }); };
      dim(cx - R * k, 220, cx + R * k, 220, '7.8 µm', cx, 238); const zr = rbcZ(.7);
      dim(cx + .7 * R * k + 34, cy - zr * k, cx + .7 * R * k + 34, cy + zr * k, '2.6 µm', cx + .7 * R * k + 40, cy + 4, 'start');
      E('path', { d: `M${cx + .7 * R * k} ${f1(cy - zr * k)}h38M${cx + .7 * R * k} ${f1(cy + zr * k)}h38`, stroke: C.mu, 'stroke-width': .6, 'stroke-dasharray': '2 2' }, g);
      dim(cx, cy - 46, cx, cy - rbcZ(0) * k - 1, '', 0, 0); dim(cx, cy + 46, cx, cy + rbcZ(0) * k + 1, '', 0, 0); B.tx(g, cx + 6, cy - 50, '0.8 µm', { fs: 10.5, w: 600 });
      B.tx(g, 30, 34, 'প্রস্থচ্ছেদ (লম্বালম্বি কেটে)', { fs: 10, c: C.mu }); }
  },
  anim(g, C, ty, t) {
    if (ty === 'face') { const cx = 180, cy = 136, R = 92, sy = .32 + .68 * (.5 + .5 * Math.cos(t * .9)), a = -18;
      B.rbcFace(g, cx, cy, R, { sy, rot: a, sw: 1.2 });
      /* অবতলের ছায়া ও আলো (কাত হলে) */
      if (sy < .95) { E('path', { d: B.ellD(cx, cy, R * .52, R * .52 * sy, a), fill: 'none', stroke: FK.alpha('#7a2a20', .35 * (1 - sy)), 'stroke-width': 6 * (1 - sy) + 1 }, g); }
      B.tx(g, cx, 262, sy > .9 ? 'ওপর থেকে — মাঝখান ফ্যাকাশে' : 'কাত করে দেখা — দুই পাশ ভেতরে ঢোকানো', { fs: 10, a: 'middle', c: C.mu });
      B.tx(g, 26, 34, 'নিউক্লিয়াস নেই', { fs: 9.5, c: C.mu }); B.tx(g, 334, 34, 'ব্যাস প্রায় 7.8 µm', { fs: 9.5, a: 'end', c: C.mu }); }
    else if (ty === 'cap') { const y0 = 104, y1 = 160, en = B.TS('muc');
      E('path', { d: `M8 ${y0 - 14}H352V${y0}H8ZM8 ${y1}H352V${y1 + 14}H8Z`, fill: en.lt, stroke: en.dk, 'stroke-width': .8 }, g);
      for (let x = 20; x < 352; x += 54) { E('path', { d: B.ellD(x + 20, y0 - 7, 12, 3.4, 0) + B.ellD(x + 46, y1 + 7, 12, 3.4, 0), fill: B.TS('nuc').c }, g); }
      E('rect', { x: 8, y: y0, width: 344, height: y1 - y0, fill: '#f7e6c6', opacity: .7 }, g);
      for (let i = 0; i < 5; i++) { const x = ((t * 46 + i * 84) % 430) - 40, cy = (y0 + y1) / 2;
        /* প্যারাশুট আকৃতি: সামনে গোল, পেছনে অবতল */
        const d = `M${f1(x + 16)} ${cy}C${f1(x + 16)} ${cy - 30} ${f1(x - 18)} ${cy - 30} ${f1(x - 14)} ${cy - 24}Q${f1(x - 4)} ${cy} ${f1(x - 14)} ${cy + 24}C${f1(x - 18)} ${cy + 30} ${f1(x + 16)} ${cy + 30} ${f1(x + 16)} ${cy}Z`;
        E('path', { d, fill: B.lin(g, 'art', 0), stroke: B.TS('art').dk, 'stroke-width': .9 }, g); }
      /* বাইরে স্বাভাবিক আকৃতি */
      B.rbcFace(g, 70, 222, 26, { sy: .95 }); B.tx(g, 70, 262, 'নালির বাইরে', { fs: 9.5, a: 'middle', c: C.mu });
      B.tx(g, 180, 82, 'কৈশিকনালি — ভেতরের ব্যাস প্রায় 5 µm', { fs: 10, a: 'middle', w: 600 }); B.tx(g, 180, 200, 'কৈশিকনালির প্রাচীর — এক স্তর এন্ডোথেলিয়াম', { fs: 9.5, a: 'middle', c: C.mu });
      B.carrow(g, 'M250 232h70', B.TS('art').dk, { w: 1.6 }); B.tx(g, 285, 226, 'প্রবাহ', { fs: 9, a: 'middle', c: C.mu }); }
    else if (ty === 'hb') { const cx = 160, cy = 140, ph = (t * .5) % 5, nb = Math.min(4, Math.floor(ph * 1.2));
      const sub = [[-40, -36, 'α', '#e07a76', 20], [42, -34, 'β', '#c98d5a', 200], [-42, 38, 'β', '#c98d5a', 80], [40, 40, 'α', '#e07a76', 260]];
      sub.forEach(([dx, dy, n, col, a], i) => { const x = cx + dx * (1 - .04 * nb), y = cy + dy * (1 - .04 * nb); const pts = Array.from({ length: 9 }, (_, j) => { const q = j / 9 * 2 * PI, r = 44 + 7 * Math.sin(q * 3 + i) + 4 * Math.cos(q * 2 + a); return [x + r * Math.cos(q), y + r * .86 * Math.sin(q)]; });
        E('path', { d: sm(pts, true, .55), fill: FK.alpha(col, .85), stroke: FK.alpha('#4a2a20', .6), 'stroke-width': 1 }, g);
        /* হিম: সমতল চাকতি */
        const hx = x + dx * .22, hy = y + dy * .2; E('path', { d: B.ellD(hx, hy, 12, 5, a * .3), fill: '#7b2d2d', stroke: '#3d1414', 'stroke-width': .8 }, g); E('circle', { cx: f1(hx), cy: f1(hy), r: 3.2, fill: '#e9a13b', stroke: '#8a5a12', 'stroke-width': .6 }, g);
        if (i < nb) { E('circle', { cx: f1(hx - 4), cy: f1(hy - 9), r: 4, fill: '#d33', stroke: '#fff', 'stroke-width': .8 }, g); E('circle', { cx: f1(hx + 4), cy: f1(hy - 9), r: 4, fill: '#d33', stroke: '#fff', 'stroke-width': .8 }, g); }
        B.tx(g, x + dx * .55, y + dy * .62 + 4, n, { fs: 14, a: 'middle', w: 700, c: '#fff', halo: FK.alpha('#000', .35) }); });
      for (let i = nb; i < 4; i++) { const u = (ph * 1.2) % 1, x = 330 - (i - nb) * 22 - (i === nb ? u * 60 : 0), y = 60 + i * 50; E('circle', { cx: f1(x - 4), cy: f1(y), r: 4, fill: '#d33' }, g); E('circle', { cx: f1(x + 4), cy: f1(y), r: 4, fill: '#d33' }, g); }
      B.tx(g, 300, 252, `বাঁধা O<sub>2</sub>: ${nb}/4`, { fs: 11, a: 'middle', w: 650 }); B.tx(g, 300, 36, 'O<sub>2</sub>', { fs: 11, a: 'middle', c: '#c33', w: 650 });
      B.tx(g, 26, 260, 'কমলা বিন্দু = Fe<sup>2+</sup> (হিম গ্রুপের কেন্দ্রে)', { fs: 9.5, c: C.mu }); }
  }
}));

/* ═════════ শ্বেত কণিকার পাঁচ ধরন ═════════ */
const WT = { neu: ['নিউট্রোফিল', 'দানাদার', '40–70%', '10–12 µm', '3–5 খণ্ড', 'রক্তে প্রায় 6–12 ঘণ্টা, টিস্যুতে 1–2 দিন', 'ব্যাকটেরিয়া ভক্ষণ (ফ্যাগোসাইটোসিস) — সংক্রমণের জায়গায় প্রথম পৌঁছায়; মৃত নিউট্রোফিল জমেই পুঁজ হয়।'],
  eos: ['ইওসিনোফিল', 'দানাদার', '1–4%', '10–12 µm', '2 খণ্ড', 'রক্তে কয়েক ঘণ্টা, টিস্যুতে কয়েক দিন', 'পরজীবী কৃমির গায়ে বিষাক্ত দানার আমিষ ছাড়ে; অ্যালার্জির প্রদাহ নিয়ন্ত্রণে ভূমিকা — কৃমি সংক্রমণ ও হাঁপানিতে সংখ্যা বাড়ে।'],
  bas: ['বেসোফিল', 'দানাদার', '0.5–1%', '8–10 µm', '2–3 খণ্ড (দানায় ঢাকা)', 'কয়েক দিন', 'হিস্টামিন (রক্তনালি প্রসারণ ও প্রদাহ) এবং হেপারিন (জমাট-রোধী) ছাড়ে; অ্যালার্জি প্রতিক্রিয়ায় অংশ নেয়।'],
  lym: ['লিম্ফোসাইট', 'অদানাদার', '20–40%', '6–14 µm', 'বড় গোল', 'কয়েক সপ্তাহ থেকে বহু বছর (স্মৃতি কোষ)', 'B লিম্ফোসাইট প্লাজমা কোষ হয়ে অ্যান্টিবডি তৈরি করে; T লিম্ফোসাইট ভাইরাস-আক্রান্ত ও ক্যান্সার কোষ ধ্বংস করে — নির্দিষ্ট (অর্জিত) রোগ প্রতিরোধ।'],
  mon: ['মনোসাইট', 'অদানাদার', '2–8%', '12–20 µm (বৃহত্তম)', 'বৃক্কাকার বা ঘোড়ার খুরের মতো', 'রক্তে 1–3 দিন, তারপর টিস্যুতে ম্যাক্রোফেজ হয়ে মাসের পর মাস', 'টিস্যুতে ঢুকে বড় ম্যাক্রোফেজে পরিণত হয় — জীবাণু, মৃত কোষ ও আবর্জনা ভক্ষণ করে এবং অ্যান্টিজেন লিম্ফোসাইটের কাছে উপস্থাপন করে।'] };
V.wbcTypes = Object.assign({}, B.seg({
  id: 'wbt', t: 'শ্বেত রক্তকণিকার প্রকারভেদ', H: 280, def: 'neu',
  cap: 'শ্বেত কণিকা (লিউকোসাইট) নিউক্লিয়াসযুক্ত, বর্ণহীন ও অ্যামিবার মতো চলতে পারে; প্রতি মাইক্রোলিটারে প্রায় 4,000–11,000টি। সাইটোপ্লাজমে রঞ্জিত দানা থাকলে দানাদার (গ্র্যানুলোসাইট — নিউট্রোফিল, ইওসিনোফিল, বেসোফিল), না থাকলে অদানাদার (অ্যাগ্র্যানুলোসাইট — লিম্ফোসাইট, মনোসাইট)। শতকরা ভাগ, আকার ও কাল Tortora ও Guyton অনুসারে। চালাও চাপলে কণিকার কাজ দেখাবে।',
  types: Object.fromEntries(Object.entries(WT).map(([k, v]) => [k, [v[0], `${v[0]} (${v[1]})`, v[6], `মোট শ্বেত কণিকার ${v[2]} · ব্যাস ${v[3]} · নিউক্লিয়াস ${v[4]} · আয়ু ${v[5]}`]])),
  art(g, C, ty) { E('rect', { x: 8, y: 8, width: 344, height: 264, rx: 10, fill: '#f7ecea', stroke: C.ln }, g);
    [[316, 40], [334, 236], [28, 250], [30, 40]].forEach(([x, y], i) => B.rbcFace(g, x, y, 15, { tone: 'pale', rot: i * 40 }));
    const w = WT[ty]; [['শতকরা', w[2]], ['ব্যাস', w[3]], ['ধরন', w[1]]].forEach(([a, b], i) => { B.tx(g, 252, 92 + i * 34, a, { fs: 9, c: C.mu }); B.tx(g, 252, 106 + i * 34, b, { fs: 11, w: 650 }); });
    B.tx(g, 28, 270, 'তুলনার জন্য পাশে লোহিত কণিকা (7.8 µm)', { fs: 8.6, c: C.mu }); },
  anim(g, C, ty, t) { const cx = 126, cy = 140, R = ty === 'mon' ? 78 : ty === 'lym' ? 56 : ty === 'bas' ? 58 : 66, p = (t * .35) % 1;
    if (ty === 'neu') { /* ব্যাকটেরিয়া ধরে ফেলা */ const ex = cx + R * .78, ey = cy - R * .55, bx = ex + 34 - Math.min(1, p / .55) * 34, by = ey - 18 + Math.min(1, p / .55) * 18, w = p < .55 ? 0 : Math.min(1, (p - .55) / .3);
      B.wbc(g, cx, cy, R, 'neu', { seed: 4 });
      if (w > 0) [-1, 1].forEach(sd => E('path', { d: sm([[ex - sd * 12, ey + sd * 14], [ex + 6 + sd * 6 * w, ey + sd * (22 - 8 * w)], [ex + 18 + 6 * w, ey + sd * (16 - 13 * w)], [ex + 10, ey + sd * 4]], true, .6), fill: '#efd9e6', stroke: '#b78aa8', 'stroke-width': .7 }, g));
      if (p < .88) E('path', { d: `M${f1(bx + 2)} ${f1(by)}h16`, stroke: '#3f7f3f', 'stroke-width': 7, 'stroke-linecap': 'round' }, g);
      else { E('circle', { cx: f1(ex - 12), cy: f1(ey + 10), r: 12, fill: '#fbf3f7', stroke: '#b78aa8' }, g); E('path', { d: `M${f1(ex - 19)} ${f1(ey + 10)}h14`, stroke: '#3f7f3f', 'stroke-width': 6, 'stroke-linecap': 'round' }, g); for (let i = 0; i < 5; i++) E('circle', { cx: f1(ex - 12 + 15 * Math.cos(i * 1.3)), cy: f1(ey + 10 + 15 * Math.sin(i * 1.3)), r: 2.6, fill: '#c79ec4' }, g); }
      B.tx(g, 300, 252, p < .88 ? 'ফ্যাগোসাইটোসিস' : 'ফ্যাগোসোম + লাইসোজোম', { fs: 10, a: 'middle', c: '#3f7f3f', w: 650 }); }
    else if (ty === 'lym') { B.wbc(g, cx, cy, R, 'lym', { seed: 7 }); for (let i = 0; i < 6; i++) { const u = (p + i / 6) % 1, a = -1 + i * .4, x = cx + Math.cos(a) * (R + u * 80), y = cy + Math.sin(a) * (R + u * 80) * .8, an = a * 57 + 90, c = Math.cos(an * PI / 180), s = Math.sin(an * PI / 180), Y = (q, v) => `${f1(x + q * c - v * s)} ${f1(y + q * s + v * c)}`;
      E('path', { d: `M${Y(0, 7)}L${Y(0, 0)}L${Y(-6, -6)}M${Y(0, 0)}L${Y(6, -6)}`, stroke: '#4f74bd', 'stroke-width': 2.6, 'stroke-linecap': 'round', fill: 'none', opacity: 1 - u * .5 }, g); }
      B.tx(g, 300, 252, 'অ্যান্টিবডি (B কোষ → প্লাজমা কোষ)', { fs: 9.5, a: 'middle', c: '#4f74bd', w: 650 }); }
    else if (ty === 'mon') { const k = .9 + .1 * Math.sin(t * 1.5); B.wbc(g, cx, cy, R * k, 'mon', { seed: 3 }); B.tx(g, 300, 252, 'টিস্যুতে → ম্যাক্রোফেজ', { fs: 10, a: 'middle', c: '#5a5f8a', w: 650 }); }
    else if (ty === 'eos') { B.wbc(g, cx, cy, R, 'eos', { seed: 2 }); E('path', { d: `M${cx + 66} ${cy + 80}q30 -40 60 -10t70 -20`, stroke: '#d8b890', 'stroke-width': 12, fill: 'none', 'stroke-linecap': 'round' }, g);
      for (let i = 0; i < 8; i++) { const u = (p + i / 8) % 1; E('circle', { cx: f1(cx + 50 + u * 60), cy: f1(cy + 40 + u * 30 + Math.sin(i) * 8), r: 3, fill: '#e2694a', opacity: 1 - u * .6 }, g); } B.tx(g, 300, 252, 'কৃমির গায়ে বিষাক্ত দানা', { fs: 9.5, a: 'middle', c: '#b4442b', w: 650 }); }
    else { B.wbc(g, cx, cy, R, 'bas', { seed: 5 }); for (let i = 0; i < 12; i++) { const u = (p + i / 12) % 1, a = i * .52; E('circle', { cx: f1(cx + Math.cos(a) * (R + u * 50)), cy: f1(cy + Math.sin(a) * (R + u * 50)), r: 2.2, fill: '#2e1650', opacity: 1 - u }, g); } B.tx(g, 300, 252, 'হিস্টামিন ও হেপারিন', { fs: 10, a: 'middle', c: '#2e1650', w: 650 }); }
  }
}));

/* ═════════ ডায়াপেডেসিস ও ফ্যাগোসাইটোসিস ═════════ */
V.diapedesis = Object.assign({ t: 'শ্বেত কণিকার ডায়াপেডেসিস ও ফ্যাগোসাইটোসিস', k: ['2d', 'anim', 'steps'], cap: 'সংক্রমণের জায়গায় টিস্যু ও জীবাণু রাসায়নিক সংকেত (কেমোকাইন) ছাড়ে। নিউট্রোফিল রক্তনালির প্রাচীর ঘেঁষে গড়িয়ে চলে, আটকে যায়, এন্ডোথেলিয়াল কোষের ফাঁক দিয়ে আকৃতি বদলে বেরিয়ে আসে (ডায়াপেডেসিস), সংকেতের উৎসের দিকে এগিয়ে যায় (কেমোট্যাক্সিস) এবং জীবাণু গিলে ধ্বংস করে। ধাপে চাপ দাও।' }, BK.steps({
  W: 360, H: 260, label: 'ডায়াপেডেসিস', dur: 3.2,
  stages: [
    { t: 'প্রান্তে সরে গড়ানো', en: 'Margination & rolling', d: 'প্রদাহে রক্তনালি প্রসারিত হয়ে প্রবাহ ধীর হয়; নিউট্রোফিল নালির কিনারায় সরে এন্ডোথেলিয়ামের সিলেক্টিন অণুর সাথে হালকা আটকে গড়িয়ে চলে।' },
    { t: 'দৃঢ়ভাবে আটকে যাওয়া', en: 'Firm adhesion', d: 'নিউট্রোফিলের ইন্টিগ্রিন অণু এন্ডোথেলিয়ামের আসঞ্জন অণুর সাথে শক্ত করে যুক্ত হয় — কণিকা থেমে যায় ও চ্যাপ্টা হয়।' },
    { t: 'ডায়াপেডেসিস', en: 'Transmigration', d: 'দুটি এন্ডোথেলিয়াল কোষের সংযোগের ফাঁক দিয়ে কণিকাটি আকৃতি বদলে চিপে টিস্যুতে বেরিয়ে আসে।' },
    { t: 'কেমোট্যাক্সিস', en: 'Chemotaxis', d: 'জীবাণু ও ক্ষতিগ্রস্ত কোষের রাসায়নিক সংকেতের ঘনত্ব যেদিকে বেশি, ক্ষণপদ বাড়িয়ে সেদিকে এগোয়।' },
    { t: 'ফ্যাগোসাইটোসিস', en: 'Phagocytosis', d: 'ক্ষণপদ দিয়ে জীবাণু ঘিরে গিলে ফ্যাগোসোম তৈরি করে; লাইসোজোমের এনজাইম ও বিষাক্ত অক্সিজেন যৌগ জীবাণু ধ্বংস করে।' }
  ],
  draw(g, C, s, u) {
    const en = B.TS('muc'), yW = 96;
    E('rect', { x: 8, y: 8, width: 344, height: yW - 8, fill: '#f4d9cf' }, g); E('rect', { x: 8, y: yW + 10, width: 344, height: 146, fill: '#fbf1e2' }, g);
    for (let x = 8; x < 352; x += 48) { const gap = x === 152 && s >= 2; E('path', { d: `M${x + (gap ? 6 : 1)} ${yW}H${x + 47}V${yW + 10}H${x + (gap ? 6 : 1)}Z`, fill: en.c, stroke: en.dk, 'stroke-width': .6 }, g); E('path', { d: B.ellD(x + 24, yW + 5, 9, 2.6, 0), fill: B.TS('nuc').c }, g); }
    B.tx(g, 16, 22, 'রক্তনালির ভেতর', { fs: 9.5, c: '#a03a2a', w: 600 }); B.tx(g, 16, 250, 'টিস্যু (সংক্রমণের জায়গা)', { fs: 9.5, c: C.mu, w: 600 });
    for (let i = 0; i < 6; i++) B.rbcFace(g, ((i * 64 + (s < 2 ? u * 40 : 20)) % 360), 34 + (i % 3) * 14, 9, { sy: .55 });
    /* জীবাণু ও সংকেতের বৃত্ত */
    const bx = 270, by = 200; for (let r = 18; r < 90; r += 18) E('circle', { cx: bx, cy: by, r, fill: 'none', stroke: '#3f7f3f', 'stroke-width': .6, opacity: .45 - r / 250, 'stroke-dasharray': '2 3' }, g);
    const bac = s < 4 || u < .7; if (bac) [[262, 194], [282, 206], [270, 214]].forEach(([x, y], i) => E('path', { d: `M${x - 6} ${y}h12`, stroke: '#3f7f3f', 'stroke-width': 6, 'stroke-linecap': 'round', transform: `rotate(${i * 50} ${x} ${y})` }, g));
    let x, y, sx = 1, sy = 1;
    if (s === 0) { x = 40 + u * 90; y = 78; } else if (s === 1) { x = 130 + u * 26; y = 82; sx = 1 + u * .25; sy = 1 - u * .25; }
    else if (s === 2) { x = 176; y = 82 + u * 46; sx = 1 - Math.sin(u * PI) * .4; sy = 1 + Math.sin(u * PI) * .3; }
    else if (s === 3) { x = 176 + u * 70; y = 128 + u * 56; } else { x = 248; y = 188; }
    E('g', {}, g); const gw = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${f1(sx)} ${f1(sy)}) translate(${f1(-x)} ${f1(-y)})` }, g); B.wbc(gw, x, y, 18, 'neu', { seed: 4 });
    if (s === 3) E('path', { d: `M${f1(x + 12)} ${f1(y + 4)}q10 2 16 10`, stroke: '#efd9e6', 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g);
    if (s === 4) { E('path', { d: sm([[248, 176], [266, 176 - u * 8], [292, 196], [276, 222], [250, 204]], false), stroke: '#efd9e6', 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round', opacity: .95 }, g); if (u >= .7) { E('circle', { cx: 252, cy: 192, r: 7, fill: '#fff', stroke: '#b78aa8' }, g); E('circle', { cx: 252, cy: 192, r: 2.5, fill: '#3f7f3f' }, g); } }
    if (s >= 2) B.tx(g, 152, 122, 'কোষ-সংযোগের ফাঁক', { fs: 8.6, a: 'end', c: C.mu });
  }
}));

/* ═════════ রক্তকণিকা তৈরি (হিমাটোপয়েসিস) ═════════ */
const HN = { hsc: [180, 52], cmp: [106, 118], clp: [292, 118], pe: [36, 186], mk: [92, 186], mb: [160, 186], mo: [232, 186], lb: [306, 186], ret: [36, 244], rbc: [36, 300], plt: [92, 290], neu: [138, 296], eos: [178, 296], bas: [216, 296], mon: [258, 296], lym: [312, 296] };
const HL = [['hsc', 'cmp'], ['hsc', 'clp'], ['cmp', 'pe'], ['cmp', 'mk'], ['cmp', 'mb'], ['cmp', 'mo'], ['clp', 'lb'], ['pe', 'ret'], ['ret', 'rbc'], ['mk', 'plt'], ['mb', 'neu'], ['mb', 'eos'], ['mb', 'bas'], ['mo', 'mon'], ['lb', 'lym']];
V.hematopoiesis = Object.assign({ t: 'রক্তকণিকা তৈরি — হিমাটোপয়েসিস', k: ['2d', 'anim', 'int', 'quiz'], cap: 'প্রাপ্তবয়স্কে সব রক্তকণিকা তৈরি হয় চ্যাপ্টা ও লম্বা অস্থির প্রান্তের লাল অস্থিমজ্জায় (স্টার্নাম, পাঁজর, কশেরুকা, শ্রোণি, ফিমার ও হিউমেরাসের মাথা); ভ্রূণে যকৃৎ ও প্লীহায়। একই বহুক্ষম স্টেম কোষ থেকে দুটি ধারা: মায়েলয়েড ধারা (লোহিত কণিকা, অণুচক্রিকা, দানাদার কণিকা, মনোসাইট) ও লিম্ফয়েড ধারা (লিম্ফোসাইট)। প্রতি সেকেন্ডে প্রায় 20–30 লক্ষ নতুন লোহিত কণিকা তৈরি হয়। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 352, label: 'হিমাটোপয়েসিস', idle: true,
  art(g, C, part) { E('rect', { x: 0, y: 0, width: 360, height: 352, rx: 12, fill: FK.alpha(B.TS('art').lt, .12) }, g);
    HL.forEach(([a, b]) => { const [x0, y0] = HN[a], [x1, y1] = HN[b]; E('path', { d: `M${x0} ${y0 + 12}C${x0} ${(y0 + y1) / 2} ${x1} ${(y0 + y1) / 2} ${x1} ${y1 - 12}`, stroke: FK.alpha(C.fg, .35), 'stroke-width': 1.2, fill: 'none', 'marker-end': B.mk(g, FK.alpha(C.fg, .5), 5) }, g); });
    const blast = (p, x, y, r, cyt, nc) => { E('circle', { cx: x, cy: y, r, fill: cyt, stroke: FK.alpha('#000', .3), 'stroke-width': .7 }, p); B.nuc(p, x, y, r * .62, r * .58, 0, {}); E('circle', { cx: x + r * .2, cy: y - r * .1, r: r * .12, fill: '#9aa6e6', opacity: .9 }, p); };
    blast(part('hsc'), ...HN.hsc, 15, '#cfe0f4'); blast(part('cmp'), ...HN.cmp, 12, '#d6dcf2'); blast(part('clp'), ...HN.clp, 12, '#d0e4f4');
    blast(part('pe'), ...HN.pe, 11, '#9fb6e2'); const mk = part('mk'); E('circle', { cx: HN.mk[0], cy: HN.mk[1], r: 17, fill: '#e9d3ea', stroke: '#9a73b8', 'stroke-width': .8 }, mk); [[-6, -4, 5], [3, -6, 5], [6, 3, 5], [-3, 6, 5], [-1, 0, 4]].forEach(([dx, dy, r]) => B.nuc(mk, HN.mk[0] + dx, HN.mk[1] + dy, r, r * .8, dx * 9, { chr: false }));
    blast(part('mb'), ...HN.mb, 11, '#c8d2ee'); blast(part('mo'), ...HN.mo, 11, '#cfd6ea'); blast(part('lb'), ...HN.lb, 10, '#bcd6f0');
    const rt = part('ret'); E('circle', { cx: HN.ret[0], cy: HN.ret[1], r: 9, fill: '#e0a8a8', stroke: '#a05050', 'stroke-width': .7 }, rt); E('path', { d: `M${HN.ret[0] - 4} ${HN.ret[1] - 2}l3 2l2 -3l3 3`, stroke: '#4a5ab0', 'stroke-width': .8, fill: 'none' }, rt); E('circle', { cx: HN.ret[0] + 12, cy: HN.ret[1] + 4, r: 3.4, fill: B.TS('nuc').c }, rt);
    B.rbcFace(part('rbc'), ...HN.rbc, 10); const pl = part('plt'); [[-6, -3], [5, -5], [0, 5], [8, 4]].forEach(([dx, dy], i) => B.plt(pl, HN.plt[0] + dx, HN.plt[1] + dy, 2.6, i));
    ['neu', 'eos', 'bas', 'mon', 'lym'].forEach((k, i) => B.wbc(part(k), ...HN[k], k === 'mon' ? 14 : k === 'lym' ? 10 : 12, k, { seed: i + 2 }));
    B.tx(g, 180, 318, '', { fs: 1 }); },
  idle(g, C, t) { HL.forEach(([a, b], i) => { const u = (t * .4 + i * .13) % 1, [x0, y0] = HN[a], [x1, y1] = HN[b]; const q = 1 - u, Y0 = y0 + 12, Y1 = y1 - 12, ym = (Y0 + Y1) / 2;
    const x = q * q * q * x0 + 3 * q * q * u * x0 + 3 * q * u * u * x1 + u * u * u * x1, y = q * q * q * Y0 + 3 * q * q * u * ym + 3 * q * u * u * ym + u * u * u * Y1; E('circle', { cx: f1(x), cy: f1(y), r: 2.2, fill: '#c0392b', opacity: .8 }, g); }); },
  parts: [
    { id: 'hsc', bn: 'বহুক্ষম হিমাটোপয়েটিক স্টেম কোষ', lb: 'স্টেম কোষ', en: 'Hematopoietic stem cell', fn: 'লাল অস্থিমজ্জার স্ব-নবায়নক্ষম কোষ — বিভাজিত হয়ে নিজের সংখ্যা ঠিক রাখে এবং সব ধরনের রক্তকণিকার জন্ম দেয়।', a: [180, 38], l: [180, 16], an: 'middle' },
    { id: 'cmp', bn: 'মায়েলয়েড পূর্বসূরি কোষ', lb: 'মায়েলয়েড ধারা', en: 'Common myeloid progenitor', fn: 'লোহিত কণিকা, অণুচক্রিকা, দানাদার কণিকা ও মনোসাইটের পূর্বসূরি।', a: [94, 112], l: [44, 96], an: 'middle' },
    { id: 'clp', bn: 'লিম্ফয়েড পূর্বসূরি কোষ', lb: 'লিম্ফয়েড ধারা', en: 'Common lymphoid progenitor', fn: 'B, T ও NK লিম্ফোসাইটের পূর্বসূরি; T কোষ পরিণত হয় থাইমাসে।', a: [304, 112], l: [318, 92], an: 'middle' },
    { id: 'pe', bn: 'প্রো-এরিথ্রোব্লাস্ট', lb: 'এরিথ্রোব্লাস্ট', en: 'Proerythroblast', fn: 'বৃক্কের এরিথ্রোপয়েটিন হরমোনের উদ্দীপনায় বিভাজিত হয়ে ক্রমে হিমোগ্লোবিন জমায়, আকারে ছোট হয়।', a: [36, 176], l: [36, 158], an: 'middle' },
    { id: 'ret', bn: 'রেটিকুলোসাইট', en: 'Reticulocyte', fn: 'নিউক্লিয়াস বের করে দেওয়া তরুণ লোহিত কণিকা — রাইবোজোমের জালিকা থাকে; রক্তে 1–2 দিনে পূর্ণ লোহিত কণিকা হয়।', a: [52, 248], l: [76, 232], an: 'start' },
    { id: 'rbc', bn: 'লোহিত কণিকা', en: 'Erythrocyte', fn: 'আয়ু প্রায় 120 দিন।', a: [36, 300], l: [36, 330], an: 'middle' },
    { id: 'mk', bn: 'মেগাক্যারিওসাইট', en: 'Megakaryocyte', fn: 'অস্থিমজ্জার বৃহৎ বহুখণ্ড নিউক্লিয়াসের কোষ (50–100 µm) — এর সাইটোপ্লাজম টুকরো হয়ে অণুচক্রিকা তৈরি হয়; একটি থেকে কয়েক হাজার।', a: [100, 172], l: [124, 150], an: 'start' },
    { id: 'plt', bn: 'অণুচক্রিকা', en: 'Platelets', fn: 'আয়ু প্রায় 8–10 দিন; থ্রম্বোপয়েটিন হরমোন (যকৃৎ) তৈরি নিয়ন্ত্রণ করে।', a: [92, 300], l: [92, 330], an: 'middle' },
    { id: 'mb', bn: 'মায়েলোব্লাস্ট', en: 'Myeloblast', fn: 'নিউট্রোফিল, ইওসিনোফিল ও বেসোফিলের পূর্বসূরি।', a: [168, 194], l: [196, 232], an: 'start' },
    { id: 'mo', bn: 'মনোব্লাস্ট', en: 'Monoblast', fn: 'মনোসাইটের পূর্বসূরি।', a: [240, 180], l: [254, 156], an: 'start' },
    { id: 'lb', bn: 'লিম্ফোব্লাস্ট', en: 'Lymphoblast', fn: 'লিম্ফোসাইটের পূর্বসূরি।', a: [306, 176], l: [330, 156], an: 'middle' },
    { id: 'neu', bn: 'নিউট্রোফিল', en: 'Neutrophil', fn: 'দানাদার — ভক্ষক।', a: [138, 308], l: [140, 330], an: 'middle' },
    { id: 'eos', bn: 'ইওসিনোফিল', en: 'Eosinophil', fn: 'দানাদার — পরজীবী ও অ্যালার্জি।', a: [178, 284], l: [196, 262], an: 'middle' },
    { id: 'bas', bn: 'বেসোফিল', en: 'Basophil', fn: 'দানাদার — হিস্টামিন ও হেপারিন।', a: [216, 308], l: [222, 330], an: 'middle' },
    { id: 'mon', bn: 'মনোসাইট', en: 'Monocyte', fn: 'অদানাদার — টিস্যুতে ম্যাক্রোফেজ।', a: [262, 284], l: [272, 258], an: 'middle' },
    { id: 'lym', bn: 'লিম্ফোসাইট (B, T, NK)', lb: 'লিম্ফোসাইট', en: 'Lymphocytes', fn: 'অদানাদার — অর্জিত রোগ প্রতিরোধ।', a: [312, 308], l: [310, 330], an: 'middle' }
  ]
}));

/* ═════════ লোহিত কণিকার জীবনচক্র ═════════ */
const RL = [[64, 72], [180, 52], [298, 92], [300, 214], [180, 282], [56, 214]];
V.rbcLife = Object.assign({ t: 'লোহিত কণিকার জীবনচক্র ও বিলিরুবিন', k: ['2d', 'anim', 'int', 'quiz'], cap: 'বৃক্ক রক্তে O<sub>2</sub> কম টের পেলে এরিথ্রোপয়েটিন হরমোন ছাড়ে → লাল অস্থিমজ্জায় লোহিত কণিকা তৈরি বাড়ে (লৌহ, ফলিক অ্যাসিড ও ভিটামিন B<sub>12</sub> লাগে)। প্রায় 120 দিন পর পুরোনো, অনমনীয় কণিকা প্লীহা ও যকৃতের ম্যাক্রোফেজে ভক্ষিত হয়: গ্লোবিন → অ্যামাইনো অ্যাসিড; হিম → লৌহ (ট্রান্সফেরিনে করে অস্থিমজ্জায় ফেরে বা ফেরিটিন হিসেবে জমে) + বিলিভারডিন → বিলিরুবিন → যকৃৎ → পিত্ত → অন্ত্রে স্টারকোবিলিন (মলের রং) ও ইউরোবিলিন (মূত্রের রং)। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 320, label: 'লোহিত কণিকার জীবনচক্র', idle: true,
  art(g, C, part) { E('rect', { x: 0, y: 0, width: 360, height: 320, rx: 12, fill: FK.alpha(C.fg, .02) }, g);
    const path = sm(RL, true, .5); E('path', { d: path, fill: 'none', stroke: FK.alpha('#c0392b', .35), 'stroke-width': 8, 'stroke-linecap': 'round' }, g);
    /* অস্থিমজ্জা: ফিমারের মাথার প্রস্থচ্ছেদ */
    const bm = part('bm'), bo = B.TS('bone'); E('path', { d: sm([[30, 96], [38, 52], [64, 40], [92, 52], [96, 80], [84, 100], [78, 130], [52, 130], [46, 104]], true), fill: B.vol(bm, 'bone'), stroke: bo.dk }, bm); E('path', { d: sm([[46, 92], [52, 60], [70, 54], [84, 66], [80, 88], [70, 100], [66, 124], [58, 124], [56, 100]], true), fill: '#c9584a', stroke: '#8a2a20', 'stroke-width': .6 }, bm);
    for (let i = 0; i < 14; i++) E('circle', { cx: 54 + B.rnd(i) * 28, cy: 62 + B.rnd(i + 9) * 50, r: 1.4, fill: '#f6d6c8', opacity: .8 }, bm);
    /* বৃক্ক */
    const kd = part('kid'); E('path', { d: sm([[182, 28], [200, 36], [208, 58], [202, 82], [184, 96], [164, 90], [158, 76], [168, 64], [160, 50], [166, 34]], true, .55), fill: B.vol(kd, 'liv', { cx: .4, cy: .3 }), stroke: B.TS('liv').dk }, kd);
    /* রক্তনালিতে কণিকা */
    const bl = part('blood'); E('path', { d: 'M262 76q24 -10 50 6t36 34', stroke: B.TS('art').dk, 'stroke-width': 18, fill: 'none', 'stroke-linecap': 'round' }, bl); E('path', { d: 'M262 76q24 -10 50 6t36 34', stroke: '#f2cfc6', 'stroke-width': 15, fill: 'none', 'stroke-linecap': 'round' }, bl); [[276, 74], [300, 78], [322, 92], [338, 108]].forEach(([x, y], i) => B.rbcFace(bl, x, y, 6, { sy: .7, rot: i * 30 }));
    /* প্লীহা */
    const sp = part('spl'); E('path', { d: sm([[278, 200], [300, 188], [330, 196], [340, 222], [326, 246], [298, 248], [280, 232], [288, 216]], true), fill: B.vol(sp, 'port', { cx: .4, cy: .3 }), stroke: B.TS('port').dk }, sp);
    /* যকৃৎ ও পিত্ত */
    const lv = part('liv'); E('path', { d: sm([[130, 262], [166, 250], [220, 254], [236, 270], [214, 290], [170, 298], [134, 290]], true), fill: B.vol(lv, 'liv'), stroke: B.TS('liv').dk }, lv); E('path', { d: B.ellD(190, 296, 9, 6, 20), fill: B.TS('gb').c, stroke: B.TS('gb').dk }, lv);
    /* অন্ত্র */
    const it = part('int'); B.tube(it, sm([[24, 236], [40, 252], [70, 246], [92, 262], [70, 286], [40, 282], [30, 300]]), 12, 'int');
    const fe = part('fe'); B.tx(fe, 42, 314, '', { fs: 1 });
    /* তীর ও লেখা */
    [['এরিথ্রোপয়েটিন', 118, 50, -14], ['O<sub>2</sub> কম → সংকেত', 230, 44, 0], ['120 দিন', 330, 154, 0], ['হিমোগ্লোবিন ভাঙে', 264, 274, 0], ['বিলিরুবিন → পিত্ত', 108, 248, 0], ['লৌহ ফেরে (ট্রান্সফেরিন)', 180, 172, 0]].forEach(([s, x, y]) => B.tx(g, x, y, s, { fs: 9.2, a: 'middle', c: C.mu, w: 560 }));
    E('path', { d: 'M270 230Q180 140 92 102', stroke: '#b57a1c', 'stroke-width': 1.3, fill: 'none', 'stroke-dasharray': '4 3', 'marker-end': B.mk(g, '#b57a1c', 6) }, g);
  },
  idle(g, C, t) { const D = B.dense(RL, 10, true); D.push(D[0]); const f = B.along(D); for (let i = 0; i < 5; i++) { const u = (t * .06 + i / 5) % 1, [x, y] = f(u);
    if (u > .55 && u < .9) E('circle', { cx: f1(x), cy: f1(y), r: 3, fill: u < .7 ? '#7fa52e' : '#b8892a', stroke: '#fff', 'stroke-width': .6 }, g); else B.rbcFace(g, x, y, 5.5, { sy: .8, tone: u > .45 && u <= .55 ? 'v' : null }); }
    const u = (t * .3) % 1; E('circle', { cx: f1(270 - u * 178), cy: f1(230 - u * 128 + Math.sin(u * PI) * -40), r: 2.6, fill: '#b57a1c' }, g); },
  parts: [
    { id: 'bm', bn: 'লাল অস্থিমজ্জা', en: 'Red bone marrow', fn: 'এখানে প্রায় 5–7 দিনে প্রো-এরিথ্রোব্লাস্ট থেকে রেটিকুলোসাইট তৈরি হয়।', a: [66, 86], l: [36, 20], an: 'middle' },
    { id: 'kid', bn: 'বৃক্ক — এরিথ্রোপয়েটিন', lb: 'বৃক্ক', en: 'Kidney (EPO)', fn: 'রক্তে O<sub>2</sub> কমলে (রক্তক্ষরণ, উঁচু পাহাড়) বৃক্ক এরিথ্রোপয়েটিন (EPO) হরমোন ছাড়ে; দীর্ঘস্থায়ী বৃক্ক রোগে EPO কমায় রক্তস্বল্পতা হয়।', a: [178, 60], l: [180, 116], an: 'middle' },
    { id: 'blood', bn: 'রক্তে সঞ্চালন', lb: 'রক্তপ্রবাহে', en: 'Circulation', fn: 'প্রায় 120 দিন ধরে সারা দেহে O<sub>2</sub> বহন; নিউক্লিয়াস না থাকায় নিজেকে মেরামত করতে পারে না।', a: [300, 78], l: [318, 40], an: 'middle' },
    { id: 'spl', bn: 'প্লীহা — লোহিত কণিকার কবরস্থান', lb: 'প্লীহা', en: 'Spleen', fn: 'প্লীহার সরু ফাঁকে পুরোনো অনমনীয় কণিকা আটকে যায় এবং ম্যাক্রোফেজ সেগুলো ভক্ষণ করে; যকৃতের কুপফার কোষও একই কাজ করে।', a: [312, 222], l: [326, 268], an: 'middle' },
    { id: 'liv', bn: 'যকৃৎ', en: 'Liver', fn: 'রক্তের বিলিরুবিন (অসংযুক্ত) গ্রহণ করে গ্লুকুরোনিক অ্যাসিডের সাথে যুক্ত করে পিত্তে পাঠায়; লৌহ ফেরিটিন রূপে জমা রাখে। বিলিরুবিন জমলে জন্ডিস।', a: [184, 270], l: [262, 304], an: 'middle' },
    { id: 'int', bn: 'অন্ত্র', en: 'Intestine', fn: 'অন্ত্রের ব্যাকটেরিয়া বিলিরুবিনকে ইউরোবিলিনোজেনে পরিণত করে — বেশিরভাগ স্টারকোবিলিন হয়ে মল বাদামি করে, কিছু শোষিত হয়ে ইউরোবিলিন হিসেবে মূত্র হলুদ করে।', a: [60, 260], l: [30, 214], an: 'middle' }
  ]
}));
})();
