/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §১০.১ যৌন প্রজনন, পরাগরেণু, পুং ও স্ত্রী গ্যামেটোফাইট
   flowerParts  : ফুলের প্রজনন অংশ — লম্বচ্ছেদ, পুংকেশর, গর্ভকেশর (চাপ দিলে নাম ও কাজ)
   antherTS     : পরাগধানীর প্রস্থচ্ছেদ — কচি ও পরিণত (স্তরগুলোতে চাপ দাও)
   pollenGrain  : পরাগরেণুর গঠন — দ্বিকোষী ও ত্রিকোষী (এক্সাইন, ইনটাইন, জনন ছিদ্র)
   microGameto  : মাইক্রোস্পোরোজেনেসিস ও পুংগ্যামেটোফাইটের বিকাশ — ধাপে ধাপে
   ovule        : ডিম্বকের গঠন — অ্যানাট্রপাস ও অর্থোট্রপাস (অংশে চাপ দাও)
   megaGameto   : মেগাস্পোরোজেনেসিস ও স্ত্রীগ্যামেটোফাইট (ভ্রূণথলি) — পলিগোনাম ধরন, ধাপে ধাপে
   embryoSac    : পরিণত ভ্রূণথলি — ৮ নিউক্লিয়াস, ৭ কোষ; সেকেন্ডারি নিউক্লিয়াস
   cmpMaleFemale : পুংগ্যামেটোফাইট বনাম স্ত্রীগ্যামেটোফাইট
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B10;
const PI = Math.PI, ch = B.ch, cl = B.cl, rnd = B.rnd, node = B.node, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
/* চাপ দেওয়া বিন্দুর সবচেয়ে কাছের অংশ (hot: [[key, x, y], …]) */
const hot = (H, x, y, r = 30) => { let best = null, bd = r; H.forEach(([k, hx, hy]) => { const d = Math.hypot(x - hx, y - hy); if (d < bd) { bd = d; best = k; } }); return best; };
const Rm = () => BK.ramp(6), Rf = () => BK.ramp(3), Rn = () => BK.ramp(2), R2n = () => BK.ramp(10), R3n = () => BK.ramp(7), Re = () => BK.ramp(0);
/* নিউক্লিয়াসসহ কোষ */
const nuc = (g, x, y, r, R, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.c, stroke: R.dk, 'stroke-width': 1, opacity: o.op != null ? o.op : 1 }, g); if (o.nl !== false) E('circle', { cx: x - r * .3, cy: y - r * .3, r: Math.max(1, r * .28), fill: R.dk, opacity: .55 }, g); };
const ploid = (g, x, y, s, R, w = 34) => B.chip(g, x, y, s, R, { w, h: 16, fs: 9 });

/* ═════════ ১. ফুলের প্রজনন অংশ ═════════ */
const FPinfo = {
  ped: ['বৃন্ত (পেডিসেল)', 'ফুলকে কাণ্ডের সাথে যুক্ত রাখে।'],
  thal: ['পুষ্পাক্ষ (থ্যালামাস)', 'বৃন্তের শীর্ষের স্ফীত অংশ — এর ওপর চারটি স্তবক সাজানো থাকে।'],
  sep: ['বৃতি (বৃত্যংশ)', 'সবচেয়ে বাইরের সবুজ স্তবক — কুঁড়ি অবস্থায় ফুলকে রক্ষা করে। আনুষঙ্গিক স্তবক।'],
  pet: ['দলমণ্ডল (পাপড়ি)', 'রঙিন, সুগন্ধি — পতঙ্গ আকর্ষণ করে পরাগায়নে সাহায্য করে। আনুষঙ্গিক স্তবক।'],
  fil: ['পুংদণ্ড (ফিলামেন্ট)', 'পুংকেশরের সরু দণ্ড — পরাগধানীকে ধরে রাখে ও পানি-খাদ্য পৌঁছায়।'],
  ant: ['পরাগধানী (অ্যান্থার)', 'পুংকেশরের শীর্ষের থলি — সাধারণত চারটি পরাগথলিতে (মাইক্রোস্পোরাঞ্জিয়াম) মিয়োসিসে পরাগরেণু তৈরি হয়। পুংকেশর = মাইক্রোস্পোরোফিল; সব পুংকেশর মিলে পুংস্তবক (অ্যান্ড্রোসিয়াম)।'],
  con: ['যোজনী (কানেকটিভ)', 'পরাগধানীর দুই খণ্ডকে যুক্ত রাখে; এর মাঝ দিয়ে ভাস্কুলার বান্ডল যায়।'],
  stg: ['গর্ভমুণ্ড (স্টিগমা)', 'গর্ভকেশরের শীর্ষ — আঠালো বা রোমশ, পরাগরেণু গ্রহণ করে; উপযুক্ত পরাগরেণু এখানে অঙ্কুরিত হয়।'],
  sty: ['গর্ভদণ্ড (স্টাইল)', 'গর্ভমুণ্ড ও গর্ভাশয়ের মাঝের সরু নল — এর ভেতর দিয়ে পরাগনালি গর্ভাশয়ে নামে।'],
  ova: ['গর্ভাশয় (ওভারি)', 'গর্ভকেশরের স্ফীত গোড়া — ভেতরে অমরা (প্লাসেন্টা) থেকে ডিম্বক জন্মায়। নিষেকের পর ফলে পরিণত হয়। গর্ভকেশর = মেগাস্পোরোফিল; সব মিলে স্ত্রীস্তবক (গাইনোসিয়াম)।'],
  ovl: ['ডিম্বক (ওভিউল)', 'মেগাস্পোরাঞ্জিয়াম — এর নিউসেলাসে ভ্রূণথলি (স্ত্রীগ্যামেটোফাইট) তৈরি হয়। নিষেকের পর বীজে পরিণত হয়।'],
  pla: ['অমরা (প্লাসেন্টা)', 'গর্ভাশয়ের যে অংশে ডিম্বক ডিম্বকনাভি দিয়ে যুক্ত থাকে।'],
  pol: ['পরাগরেণু', 'পুংগ্যামেটোফাইটের প্রথম কোষ — এটি গর্ভমুণ্ডে পড়লে (পরাগায়ন) নালি তৈরি করে।']
};
const FPhot = {
  ls: [['stg', 180, 66], ['sty', 180, 112], ['ova', 206, 172], ['ovl', 180, 172], ['ant', 126, 92], ['fil', 146, 150], ['pet', 80, 132], ['sep', 112, 206], ['thal', 180, 206], ['ped', 180, 244], ['ant', 234, 92], ['fil', 214, 150], ['pet', 280, 132], ['sep', 248, 206]],
  sta: [['ant', 180, 74], ['con', 180, 112], ['fil', 180, 196], ['pol', 254, 64]],
  pis: [['stg', 180, 40], ['sty', 180, 86], ['ova', 236, 186], ['ovl', 196, 186], ['pla', 180, 210], ['pol', 160, 30]]
};
V.flowerParts = Object.assign({}, B.seg({
  id: 'fp', t: 'ফুল — প্রজননের অঙ্গ', H: 262, def: 'ls',
  cap: 'ফুল হলো প্রজননের জন্য রূপান্তরিত বিটপ। চারটি স্তবক — বৃতি ও দলমণ্ডল (আনুষঙ্গিক) এবং পুংস্তবক ও স্ত্রীস্তবক (অত্যাবশ্যক বা প্রজনন স্তবক)। যেকোনো অংশে চাপ দিলে নাম ও কাজ দেখাবে।',
  types: {
    ls: ['লম্বচ্ছেদ', 'একটি দ্বিলিঙ্গ (উভলিঙ্গ) ফুলের লম্বচ্ছেদ', 'পুংকেশর (পুং প্রজনন অঙ্গ) ও গর্ভকেশর (স্ত্রী প্রজনন অঙ্গ) একই ফুলে আছে। একলিঙ্গ ফুলে (লাউ, কুমড়া, পেঁপে) এর একটি থাকে না।'],
    sta: ['পুংকেশর', 'পুংকেশর (মাইক্রোস্পোরোফিল)', 'পুংদণ্ড + পরাগধানী; পরাগধানী দুই খণ্ড (দ্বিখণ্ডক), প্রতি খণ্ডে দুটি পরাগথলি — মোট চারটি।'],
    pis: ['গর্ভকেশর', 'গর্ভকেশর (মেগাস্পোরোফিল)', 'গর্ভমুণ্ড + গর্ভদণ্ড + গর্ভাশয়; গর্ভাশয়ের ভেতরে অমরায় ডিম্বক।']
  },
  art(g, C, ty, ctx) {
    const sel = ctx.sel, hl = k => sel === k, Rg = BK.ramp(10), Rp = BK.ramp(8), Ra = Rm(), Rc = Rf();
    const sw = k => hl(k) ? 2.6 : 1.1;
    if (ty === 'ls') {
      E('path', { d: 'M174 262V212H186V262Z', fill: Rg.c, stroke: Rg.dk, 'stroke-width': sw('ped') }, g);
      E('path', { d: 'M150 214Q180 196 210 214Q200 222 180 222Q160 222 150 214Z', fill: Rg.lt, stroke: Rg.dk, 'stroke-width': sw('thal') }, g);
      [-1, 1].forEach(s => {
        E('path', { d: `M${180 + s * 22} 212Q${180 + s * 70} 214 ${180 + s * 84} 188Q${180 + s * 56} 200 ${180 + s * 24} 204Z`, fill: Rg.c, stroke: Rg.dk, 'stroke-width': sw('sep') }, g);
        E('path', { d: `M${180 + s * 20} 204Q${180 + s * 64} 190 ${180 + s * 112} 110Q${180 + s * 120} 86 ${180 + s * 96} 92Q${180 + s * 56} 140 ${180 + s * 18} 196Z`, fill: FK.alpha(Rp.c, .55), stroke: Rp.dk, 'stroke-width': sw('pet') }, g);
        [[38, 54], [56, 42]].forEach(([dx, dh]) => {
          E('path', { d: `M${180 + s * 14} 204Q${180 + s * dx * .6} 150 ${180 + s * dx} ${110 - dh * .2}`, stroke: Ra.dk, 'stroke-width': hl('fil') ? 3 : 1.8, fill: 'none' }, g);
          E('ellipse', { cx: 180 + s * dx, cy: 100 - dh * .2, rx: 7, ry: 12, fill: Ra.c, stroke: Ra.dk, 'stroke-width': sw('ant') }, g);
        });
      });
      E('ellipse', { cx: 180, cy: 174, rx: 28, ry: 32, fill: FK.alpha(Rc.c, .35), stroke: Rc.dk, 'stroke-width': sw('ova') }, g);
      E('path', { d: 'M180 144V82', stroke: Rc.dk, 'stroke-width': hl('sty') ? 7 : 5, 'stroke-linecap': 'round' }, g);
      E('ellipse', { cx: 180, cy: 74, rx: 13, ry: 7, fill: Rc.lt, stroke: Rc.dk, 'stroke-width': sw('stg') }, g);
      E('path', { d: 'M180 148V200', stroke: Rc.dk, 'stroke-width': 1.2 }, g);
      [156, 172, 188].forEach(y => [-1, 1].forEach(s => E('ellipse', { cx: 180 + s * 9, cy: y, rx: 6, ry: 4.5, fill: hl('ovl') ? Rc.c : '#fff', stroke: Rc.dk }, g)));
      T(g, 180, 22, 'দ্বিলিঙ্গ ফুলের লম্বচ্ছেদ', { fs: 11, a: 'middle', w: 600, c: C.mu });
    } else if (ty === 'sta') {
      E('path', { d: 'M180 252V128', stroke: Ra.dk, 'stroke-width': hl('fil') ? 7 : 5, 'stroke-linecap': 'round' }, g);
      [-1, 1].forEach(s => [0, 1].forEach(j => E('ellipse', { cx: 180 + s * (16 + j * 14), cy: 82 + (j ? 6 : 0), rx: 14, ry: 42 - j * 6, fill: FK.alpha(Ra.c, j ? .5 : .75), stroke: Ra.dk, 'stroke-width': sw('ant') }, g)));
      E('rect', { x: 174, y: 42, width: 12, height: 86, rx: 5, fill: Ra.lt, stroke: Ra.dk, 'stroke-width': sw('con') }, g);
      for (let i = 0; i < 12; i++) E('circle', { cx: 150 + (i % 4) * 4 + (i > 5 ? 56 : 0), cy: 60 + Math.floor((i % 6) / 2) * 20, r: 2.6, fill: Ra.dk, opacity: .7 }, g);
      T(g, 180, 22, 'পরাগধানী: ২ খণ্ড × ২ পরাগথলি = ৪', { fs: 11, a: 'middle', w: 600, c: C.mu });
    } else {
      E('ellipse', { cx: 180, cy: 186, rx: 66, ry: 54, fill: FK.alpha(Rc.c, .3), stroke: Rc.dk, 'stroke-width': sw('ova') }, g);
      E('path', { d: 'M180 134V54', stroke: Rc.dk, 'stroke-width': hl('sty') ? 9 : 7, 'stroke-linecap': 'round' }, g);
      E('path', { d: 'M156 46Q168 30 180 40Q192 30 204 46Q192 52 180 48Q168 52 156 46Z', fill: Rc.lt, stroke: Rc.dk, 'stroke-width': sw('stg') }, g);
      E('rect', { x: 174, y: 146, width: 12, height: 82, rx: 4, fill: FK.alpha(Rc.dk, .25), stroke: Rc.dk, 'stroke-width': sw('pla') }, g);
      [160, 186, 212].forEach(y => [-1, 1].forEach(s => { E('path', { d: `M${180 + s * 6} ${y}h${s * 8}`, stroke: Rc.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: 180 + s * 24, cy: y, rx: 11, ry: 8, fill: hl('ovl') ? Rc.c : '#fff', stroke: Rc.dk }, g); E('ellipse', { cx: 180 + s * 26, cy: y, rx: 4, ry: 5, fill: Rc.lt, stroke: Rc.dk, 'stroke-width': .7 }, g); }));
      T(g, 300, 120, 'গর্ভাশয়ের', { fs: 9.5, a: 'middle', c: C.mu }); T(g, 300, 132, 'লম্বচ্ছেদ', { fs: 9.5, a: 'middle', c: C.mu });
    }
    if (sel) { const h = FPhot[ty].find(p => p[0] === sel); if (h) { E('circle', { cx: h[1], cy: h[2], r: 15, fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 2, 'stroke-dasharray': '4 3' }, g); T(g, h[1], h[2] - 20, FPinfo[sel][0].split(' (')[0], { fs: 10.5, a: 'middle', w: 650, c: BK.ramp(4).ink }); } }
  },
  anim(g, C, ty, t) {
    if (!t) return; const Ra = Rm();
    const src = ty === 'ls' ? [[126, 92], [234, 92]] : ty === 'sta' ? [[196, 70], [164, 70]] : [[100, 20], [260, 20]], dst = ty === 'pis' ? [180, 40] : ty === 'ls' ? [180, 72] : null;
    for (let i = 0; i < 6; i++) {
      const u = (t * .22 + i / 6) % 1, [sx, sy] = src[i % 2];
      const x = dst ? sx + (dst[0] - sx) * u + Math.sin(u * 9 + i) * 6 : sx + (i % 2 ? -1 : 1) * u * 90, y = dst ? sy + (dst[1] - sy) * u - Math.sin(u * PI) * 24 : sy - u * 40 + u * u * 120;
      E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 2.6, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .6, opacity: 1 - u * .5 }, g);
    }
  },
  tap(x, y, ty, ctx) { const k = hot(FPhot[ty], x, y, 34); ctx.sel = k; if (!k) return ctx.def(); const [n, d] = FPinfo[k]; return `<b>${n}</b> — ${d}`; }
}));

/* ═════════ ২. পরাগধানীর প্রস্থচ্ছেদ ═════════ */
const ANL = [[104, 86], [256, 86], [104, 172], [256, 172]], ANr = 40;
const ANinfo = {
  epi: ['বহিস্ত্বক (এপিডার্মিস)', 'সবচেয়ে বাইরের এক স্তর কোষ — সুরক্ষা দেয়।'],
  end: ['এন্ডোথেসিয়াম', 'বহিস্ত্বকের নিচের স্তর; কোষপ্রাচীরে আঁশের মতো তন্তুময় স্থূলীকরণ (α-সেলুলোজ, সামান্য লিগনিন) থাকে — শুকিয়ে সংকুচিত হয়ে পরাগধানী ফাটাতে (বিদারণ) সাহায্য করে।'],
  mid: ['মধ্যস্তর', '২–৩ স্তর পাতলা প্রাচীরের কোষ — খাদ্য জমা রাখে; পরাগধানী পরিণত হওয়ার সময় নষ্ট হয়ে যায়।'],
  tap: ['ট্যাপেটাম', 'সবচেয়ে ভেতরের পুষ্টিদায়ক স্তর — কোষ বড়, ঘন সাইটোপ্লাজম, প্রায়ই বহুনিউক্লিয়াসযুক্ত বা পলিপ্লয়েড। বিকাশমান পরাগরেণুকে খাদ্য দেয়, এক্সাইনের স্পোরোপোলেনিন ও পরাগরেণুর আঠালো আবরণ (পোলেনকিট) তৈরিতে অংশ নেয়; পরিণত অবস্থায় নষ্ট হয়।'],
  spo: ['স্পোরোজেনাস টিস্যু / মাইক্রোস্পোর মাতৃকোষ (2n)', 'পরাগথলির কেন্দ্রের কোষগুলো — প্রতিটি মাইক্রোস্পোর মাতৃকোষ মিয়োসিসে চারটি হ্যাপ্লয়েড মাইক্রোস্পোর (টেট্রাড) তৈরি করে।'],
  pol: ['পরাগরেণু (n)', 'পরিণত পরাগথলিতে টেট্রাড আলাদা হয়ে অসংখ্য পরাগরেণু তৈরি হয়।'],
  con: ['যোজনী (কানেকটিভ)', 'দুই খণ্ডের মাঝে — কেন্দ্রে ভাস্কুলার বান্ডল।'],
  sto: ['স্টোমিয়াম', 'দুই পরাগথলির মাঝের পাতলা কোষের সারি — পরিণত অবস্থায় এখানে ফেটে পরাগরেণু বেরিয়ে আসে।']
};
const anLayer = (x, y) => {
  if (Math.abs(x - 180) < 26 && y > 70 && y < 190) return 'con';
  for (const [cx, cy] of ANL) { const d = Math.hypot(x - cx, y - cy); if (d <= ANr + 4) return d > ANr - 4 ? 'epi' : d > ANr - 9 ? 'end' : d > ANr - 15 ? 'mid' : d > ANr - 21 ? 'tap' : 'in'; }
  if ((Math.abs(x - 104) < 18 || Math.abs(x - 256) < 18) && Math.abs(y - 129) < 12) return 'sto';
  return null;
};
V.antherTS = Object.assign({}, B.seg({
  id: 'at', t: 'পরাগধানীর প্রস্থচ্ছেদ', H: 262, def: 'young',
  cap: 'পরাগধানী দ্বিখণ্ডক, প্রতিটি খণ্ডে দুটি পরাগথলি (মাইক্রোস্পোরাঞ্জিয়াম) — প্রস্থচ্ছেদে প্রজাপতির মতো চারটি লোব। প্রাচীরের চার স্তর: বহিস্ত্বক, এন্ডোথেসিয়াম, মধ্যস্তর ও ট্যাপেটাম। কোনো স্তরে চাপ দাও।',
  types: {
    young: ['কচি', 'কচি পরাগধানী', 'প্রাচীরের চারটি স্তরই অক্ষত; কেন্দ্রে স্পোরোজেনাস টিস্যু থেকে মাইক্রোস্পোর মাতৃকোষ (2n)।'],
    mature: ['পরিণত', 'পরিণত পরাগধানী (বিদারণ)', 'মধ্যস্তর ও ট্যাপেটাম নষ্ট; একই খণ্ডের দুই পরাগথলির মাঝের প্রাচীর ভেঙে এক প্রকোষ্ঠ; এন্ডোথেসিয়ামের টানে স্টোমিয়াম বরাবর ফেটে পরাগরেণু বেরোয়।']
  },
  art(g, C, ty, ctx) {
    const Ra = Rm(), Rt = BK.ramp(8), Rw = BK.ramp(11), sel = ctx.sel, mat = ty === 'mature';
    E('path', { d: 'M180 64Q140 30 90 44Q52 58 60 98Q62 128 60 160Q56 206 104 216Q150 222 180 196Q210 222 256 216Q304 206 300 160Q298 128 300 98Q308 58 270 44Q220 30 180 64Z', fill: FK.alpha(Rw.c, .14), stroke: 'none' }, g);
    E('rect', { x: 158, y: 70, width: 44, height: 118, rx: 18, fill: FK.alpha(Rw.c, .3), stroke: sel === 'con' ? BK.ramp(4).c : Rw.dk, 'stroke-width': sel === 'con' ? 2.4 : 1 }, g);
    E('circle', { cx: 180, cy: 129, r: 10, fill: BK.ramp(10).lt, stroke: BK.ramp(10).dk }, g); E('circle', { cx: 180, cy: 125, r: 4, fill: BK.ramp(4).c, opacity: .7 }, g);
    ANL.forEach(([cx, cy], i) => {
      const hs = k => sel === k ? BK.ramp(4).c : null;
      E('circle', { cx, cy, r: ANr, fill: Rw.lt, stroke: hs('epi') || Rw.dk, 'stroke-width': hs('epi') ? 2.6 : 1.2 }, g);
      E('circle', { cx, cy, r: ANr - 6.5, fill: 'none', stroke: hs('end') || Ra.dk, 'stroke-width': 5, 'stroke-dasharray': '1.6 2.4', opacity: hs('end') ? 1 : .75 }, g);
      if (!mat) {
        E('circle', { cx, cy, r: ANr - 12, fill: 'none', stroke: hs('mid') || C.mu, 'stroke-width': hs('mid') ? 3 : 4, opacity: .5 }, g);
        E('circle', { cx, cy, r: ANr - 18, fill: 'none', stroke: hs('tap') || Rt.c, 'stroke-width': 5, opacity: .85 }, g);
        for (let k = 0; k < 14; k++) { const a = k / 14 * PI * 2; E('circle', { cx: cx + (ANr - 18) * Math.cos(a), cy: cy + (ANr - 18) * Math.sin(a), r: 1.2, fill: Rt.dk }, g); }
        for (let k = 0; k < 7; k++) { const a = k / 7 * PI * 2 + i, rr = k ? 11 : 0; nuc(g, cx + rr * Math.cos(a), cy + rr * Math.sin(a), 5, R2n(), { fill: FK.alpha(R2n().c, sel === 'spo' ? .8 : .45) }); }
      } else {
        E('circle', { cx, cy, r: ANr - 10, fill: '#fff', opacity: .55 }, g);
        for (let k = 0; k < 16; k++) { const a = rnd(k + i * 20) * PI * 2, rr = 4 + rnd(k * 3 + i) * (ANr - 18); E('circle', { cx: cx + rr * Math.cos(a), cy: cy + rr * Math.sin(a), r: 3.6, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .7, opacity: sel === 'pol' ? 1 : .85 }, g); }
      }
    });
    if (mat) [104, 256].forEach(x => { E('rect', { x: x - 16, y: 116, width: 32, height: 26, fill: '#fff', opacity: .7 }, g); E('path', { d: `M${x + (x < 180 ? -42 : 42)} 129h${x < 180 ? 8 : -8}`, stroke: sel === 'sto' ? BK.ramp(4).c : C.fg, 'stroke-width': 2 }, g); });
    else [104, 256].forEach(x => E('path', { d: `M${x} 126v6`, stroke: Rw.dk, 'stroke-width': 3 }, g));
    T(g, 180, 22, mat ? 'মধ্যস্তর ও ট্যাপেটাম নেই — বিদারণ' : 'চার স্তরের প্রাচীর ও মাতৃকোষ', { fs: 10.5, a: 'middle', w: 600, c: C.mu });
    T(g, 180, 250, 'যোজনী', { fs: 9.5, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    if (!t) return; const Ra = Rm();
    if (ty === 'mature') { for (let i = 0; i < 8; i++) { const u = (t * .25 + i / 8) % 1, s = i % 2 ? 1 : -1, x0 = s < 0 ? 62 : 298; E('circle', { cx: x0 + s * u * 50, cy: 129 + Math.sin(u * 6 + i) * 14 - u * 30, r: 3, fill: Ra.c, opacity: 1 - u }, g); } return; }
    ANL.forEach(([cx, cy]) => { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx, cy, r: ANr - 18, fill: 'none', stroke: BK.ramp(8).c, 'stroke-width': 1.5 + k * 1.5, opacity: .35 }, g); });
  },
  tap(x, y, ty, ctx) {
    let k = anLayer(x, y); if (k === 'in') k = ty === 'mature' ? 'pol' : 'spo';
    if (ty === 'mature' && (k === 'mid' || k === 'tap')) { ctx.sel = k; return `<b>${ANinfo[k][0]}</b> — পরিণত পরাগধানীতে এ স্তরটি নষ্ট হয়ে গেছে। ${ANinfo[k][1]}`; }
    ctx.sel = k; if (!k) return ctx.def(); return `<b>${ANinfo[k][0]}</b> — ${ANinfo[k][1]}`;
  }
}));

/* ═════════ ৩. পরাগরেণু ═════════ */
const PGc = [156, 136], PGr = 86;
const PGinfo = {
  exi: ['এক্সাইন (বহিঃত্বক)', 'শক্ত বাইরের স্তর — স্পোরোপোলেনিন দিয়ে তৈরি, যা সবচেয়ে প্রতিরোধী জৈব পদার্থগুলোর একটি: উচ্চ তাপ, তীব্র অ্যাসিড-ক্ষার ও এনজাইমে নষ্ট হয় না। তাই পরাগরেণু জীবাশ্ম হিসেবে লক্ষ বছর টিকে থাকে (প্যালিনোলজি)। এর নকশা (কাঁটা, জালি) প্রজাতিভেদে আলাদা।'],
  int: ['ইনটাইন (অন্তঃত্বক)', 'পাতলা ভেতরের স্তর — সেলুলোজ ও পেকটিন দিয়ে তৈরি; অঙ্কুরোদগমে জনন ছিদ্র দিয়ে বেরিয়ে পরাগনালি গঠন করে।'],
  gp: ['জনন ছিদ্র (জার্ম পোর)', 'এক্সাইন যেখানে নেই বা খুব পাতলা — এখান দিয়ে পরাগনালি বের হয়। দ্বিবীজপত্রীতে সাধারণত ৩টি (ট্রাইকোলপেট), একবীজপত্রীতে ১টি।'],
  veg: ['নালিকোষ / অঙ্গজ কোষ', 'বড় কোষ, বড় অনিয়মিত নিউক্লিয়াস (নালি নিউক্লিয়াস), প্রচুর খাদ্য — পরাগনালি তৈরি ও বৃদ্ধি নিয়ন্ত্রণ করে।'],
  gen: ['জনন কোষ', 'ছোট, মাকুর মতো কোষ, নালিকোষের ভেতরে ভাসে — মাইটোসিসে দুটি পুংগ্যামেট (শুক্রাণু) তৈরি করে।'],
  sp: ['দুটি পুংগ্যামেট (n)', 'জনন কোষের মাইটোসিসে তৈরি — একটি ডিম্বাণুর সাথে (সিনগ্যামি), অন্যটি দুটি পোলার নিউক্লিয়াসের সাথে (ত্রি-মিলন) মিলিত হয়।']
};
V.pollenGrain = Object.assign({}, B.seg({
  id: 'pg', t: 'পরাগরেণুর গঠন', H: 262, def: 'two',
  cap: 'পরাগরেণু হলো মাইক্রোস্পোর এবং পুংগ্যামেটোফাইটের প্রথম অবস্থা (n)। দুই স্তরের প্রাচীর — বাইরে এক্সাইন, ভেতরে ইনটাইন। প্রায় ৭০% আবৃতবীজী উদ্ভিদে দ্বিকোষী অবস্থায় ছড়ায়, বাকিগুলোতে (যেমন ধান, গম, সরিষা) ত্রিকোষী অবস্থায়। অংশে চাপ দাও।',
  types: {
    two: ['দ্বিকোষী', 'দ্বিকোষী পরাগরেণু (ছড়ানোর সময়)', 'নালিকোষ + জনন কোষ; জনন কোষ পরে পরাগনালিতে বিভাজিত হয়।'],
    three: ['ত্রিকোষী', 'ত্রিকোষী পরাগরেণু', 'নালিকোষ + দুটি পুংগ্যামেট — জনন কোষ পরাগরেণুর ভেতরেই বিভাজিত হয়েছে।']
  },
  art(g, C, ty, ctx) {
    const [cx, cy] = PGc, Ra = Rm(), Rn_ = Rn(), sel = ctx.sel, hs = k => sel === k ? BK.ramp(4).c : null;
    const pores = [-PI / 2, PI / 6, 5 * PI / 6];
    let d = ''; const n = 72;
    for (let i = 0; i <= n; i++) { const a = i / n * PI * 2, near = pores.some(p => Math.abs(((a - p + 3 * PI) % (2 * PI)) - PI) < .16), r = near ? PGr - 6 : PGr + (i % 2 ? 6 : 0); d += (i ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(1) + ' ' + (cy + r * Math.sin(a)).toFixed(1); }
    E('path', { d: d + 'Z', fill: Ra.lt, stroke: hs('exi') || Ra.dk, 'stroke-width': hs('exi') ? 2.4 : 1.3 }, g);
    E('circle', { cx, cy, r: PGr - 9, fill: FK.alpha(Ra.c, .12), stroke: hs('int') || BK.ramp(11).dk, 'stroke-width': hs('int') ? 3 : 1.6 }, g);
    pores.forEach(p => E('circle', { cx: cx + (PGr - 4) * Math.cos(p), cy: cy + (PGr - 4) * Math.sin(p), r: 8, fill: '#fff', stroke: hs('gp') || Ra.dk, 'stroke-width': hs('gp') ? 2.4 : 1 }, g));
    B.blob(g, cx + 14, cy + 22, 22, { fill: FK.alpha(Rn_.c, sel === 'veg' ? .75 : .5), stroke: Rn_.dk, n: 9, j: .3, seed: 3 });
    lab(g, cx + 4, cy + 30, 30, 236, 'নালি নিউক্লিয়াস', C, { fs: 10.5, a: 'start' });
    if (ty === 'two') { E('ellipse', { cx: cx - 26, cy: cy - 22, rx: 24, ry: 12, transform: `rotate(-24 ${cx - 26} ${cy - 22})`, fill: FK.alpha(BK.ramp(3).c, sel === 'gen' ? .7 : .35), stroke: BK.ramp(3).dk, 'stroke-width': hs('gen') ? 2.4 : 1.1 }, g); E('ellipse', { cx: cx - 26, cy: cy - 22, rx: 10, ry: 6, transform: `rotate(-24 ${cx - 26} ${cy - 22})`, fill: BK.ramp(3).c }, g); }
    else [[-36, -26], [-12, -38]].forEach(([dx, dy]) => { E('ellipse', { cx: cx + dx, cy: cy + dy, rx: 13, ry: 8, fill: FK.alpha(BK.ramp(3).c, sel === 'sp' ? .8 : .45), stroke: BK.ramp(3).dk, 'stroke-width': hs('sp') ? 2.4 : 1.1 }, g); E('circle', { cx: cx + dx, cy: cy + dy, r: 4.5, fill: BK.ramp(3).dk }, g); });
    lab(g, cx + 82, cy + 40, 300, 214, 'এক্সাইন', C, { fs: 10.5 }); lab(g, cx + 60, cy + 46, 300, 236, 'ইনটাইন', C, { fs: 10.5 });
    lab(g, cx, cy - PGr + 4, 296, 30, 'জনন ছিদ্র', C, { fs: 10.5 });
    lab(g, cx - 40, cy - 30, 40, 36, ty === 'two' ? 'জনন কোষ' : '২ পুংগ্যামেট', C, { fs: 10.5, a: 'start' });
    ploid(g, 300, 120, 'n', Rn_, 30); T(g, 300, 142, 'সব কোষ হ্যাপ্লয়েড', { fs: 9, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    if (!t) return; const [cx, cy] = PGc, u = (t * .15) % 1, p = PI / 6, L = 10 + u * 60, x0 = cx + (PGr - 4) * Math.cos(p), y0 = cy + (PGr - 4) * Math.sin(p);
    const R = BK.ramp(11); E('path', { d: `M${x0} ${y0}q${L * .5} ${L * .2} ${L * .7} ${L * .9}`, stroke: R.dk, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round', opacity: .5 }, g);
    E('path', { d: `M${x0} ${y0}q${L * .5} ${L * .2} ${L * .7} ${L * .9}`, stroke: R.lt, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round', opacity: .9 }, g);
    if (u > .1) T(g, x0 + 36, y0 + 64, 'পরাগনালি (ইনটাইন)', { fs: 9, c: R.ink });
  },
  tap(x, y, ty, ctx) {
    const [cx, cy] = PGc, d = Math.hypot(x - cx, y - cy), a = Math.atan2(y - cy, x - cx);
    let k = null;
    if (d > PGr - 14 && d < PGr + 14) k = [-PI / 2, PI / 6, 5 * PI / 6].some(p => Math.abs(((a - p + 3 * PI) % (2 * PI)) - PI) < .25) ? 'gp' : d > PGr - 6 ? 'exi' : 'int';
    else if (d <= PGr - 14) k = Math.hypot(x - (cx + 14), y - (cy + 22)) < 26 ? 'veg' : (x < cx + 4 && y < cy + 4) ? (ty === 'two' ? 'gen' : 'sp') : 'veg';
    ctx.sel = k; if (!k) return ctx.def(); return `<b>${PGinfo[k][0]}</b> — ${PGinfo[k][1]}`;
  }
}));

/* ═════════ ৪. পুংগ্যামেটোফাইটের বিকাশ ═════════ */
const wallC = (g, x, y, r, R, fill) => E('circle', { cx: x, cy: y, r, fill: fill || FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': 1.4 }, g);
V.microGameto = Object.assign({ t: 'মাইক্রোস্পোরোজেনেসিস ও পুংগ্যামেটোফাইটের বিকাশ', k: ['anim', 'steps'], cap: 'পরাগথলির মাইক্রোস্পোর মাতৃকোষ (2n) মিয়োসিসে চারটি মাইক্রোস্পোর (n) তৈরি করে — মাইক্রোস্পোরোজেনেসিস। প্রতিটি মাইক্রোস্পোর মাইটোসিসে পুংগ্যামেটোফাইটে পরিণত হয় — মাইক্রোগ্যামেটোজেনেসিস। পরিণত পুংগ্যামেটোফাইট মাত্র তিনটি কোষ/নিউক্লিয়াস: নালি নিউক্লিয়াস + দুটি পুংগ্যামেট।' }, BK.steps({
  W: 360, H: 240, label: 'পুংগ্যামেটোফাইটের বিকাশ', dur: 2.8,
  stages: [
    { t: 'মাইক্রোস্পোর মাতৃকোষ', en: 'Microspore mother cell (2n)', d: 'পরাগথলির স্পোরোজেনাস টিস্যুর প্রতিটি কোষ মাইক্রোস্পোর মাতৃকোষ (পোলেন মাদার সেল) হিসেবে কাজ করে — ডিপ্লয়েড (2n)।' },
    { t: 'মিয়োসিস → টেট্রাড', en: 'Meiosis — microspore tetrad', d: 'মিয়োসিসে চারটি হ্যাপ্লয়েড (n) মাইক্রোস্পোর তৈরি হয়ে টেট্রাড আকারে (সাধারণত চতুস্তলকীয়) একসাথে থাকে।' },
    { t: 'মাইক্রোস্পোর আলাদা — পরাগরেণু', en: 'Free microspore', d: 'টেট্রাড ভেঙে প্রতিটি মাইক্রোস্পোর আলাদা হয়, এক্সাইন ও ইনটাইন তৈরি হয় — এটিই পরাগরেণু, পুংগ্যামেটোফাইটের প্রথম কোষ। নিউক্লিয়াস প্রাচীরের দিকে সরে যায় (বড় কোষগহ্বর)।' },
    { t: 'প্রথম মাইটোসিস (অসম)', en: 'Pollen mitosis I', d: 'অসম মাইটোসিসে বড় নালিকোষ (অঙ্গজ কোষ) ও ছোট জনন কোষ তৈরি হয় — দ্বিকোষী পরাগরেণু; অধিকাংশ উদ্ভিদে এ অবস্থায় পরাগধানী থেকে ছড়ায়।' },
    { t: 'অঙ্কুরোদগম — পরাগনালি', en: 'Germination on stigma', d: 'গর্ভমুণ্ডে পড়ে পরাগরেণু পানি ও শর্করা শোষণ করে; ইনটাইন জনন ছিদ্র দিয়ে বেরিয়ে পরাগনালি গঠন করে। নালি নিউক্লিয়াস নালির অগ্রভাগে যায়।' },
    { t: 'দ্বিতীয় মাইটোসিস — দুই পুংগ্যামেট', en: 'Pollen mitosis II', d: 'জনন কোষ নালিতে নেমে মাইটোসিসে দুটি পুংগ্যামেট (n) তৈরি করে। পরিণত পুংগ্যামেটোফাইট = পরাগরেণু + পরাগনালি, যাতে ১টি নালি নিউক্লিয়াস ও ২টি পুংগ্যামেট।' }
  ],
  draw(g, C, s, u) {
    const Ra = Rm(), R2 = R2n(), Rn_ = Rn(), R3 = BK.ramp(3), k = u;
    if (s === 0) { wallC(g, 180, 118, 60, R2); nuc(g, 180, 118, 22 + 2 * Math.sin(k * 6), R2, { fill: FK.alpha(R2.c, .7) }); ploid(g, 180, 210, '2n', R2); T(g, 180, 32, 'মাতৃকোষ', { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    if (s === 1) { const sp = 6 + 22 * k; wallC(g, 180, 118, 64, R2, FK.alpha(R2.c, .08)); [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => { wallC(g, 180 + a * sp, 118 + b * sp, 26, Rn_); nuc(g, 180 + a * sp, 118 + b * sp, 8, Rn_); }); ploid(g, 180, 210, '4 × n', Rn_, 48); T(g, 180, 32, 'মিয়োসিস: ১ → ৪', { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    if (s === 2) { [70, 140, 220, 290].forEach((x, i) => { const y = 118 + (i % 2 ? 10 : -10) * k; wallC(g, x, y, 30, Ra, Ra.lt); E('circle', { cx: x, cy: y, r: 25, fill: 'none', stroke: BK.ramp(11).dk }, g); nuc(g, x - 14 * k, y, 8, Rn_); }); T(g, 180, 32, '৪টি পরাগরেণু (মাইক্রোস্পোর)', { fs: 11, a: 'middle', w: 600, c: C.fg }); ploid(g, 180, 210, 'n', Rn_, 30); return; }
    if (s === 3) { wallC(g, 180, 118, 70, Ra, Ra.lt); E('circle', { cx: 180, cy: 118, r: 63, fill: 'none', stroke: BK.ramp(11).dk }, g); E('path', { d: `M126 ${118 - 40 * k}Q${150} 118 126 ${118 + 40 * k}`, stroke: C.fg, 'stroke-width': 1.4, fill: 'none', opacity: k }, g); nuc(g, 200, 124, 16, Rn_); nuc(g, 134, 118, 8, R3); T(g, 200, 152, 'নালিকোষ', { fs: 10, a: 'middle', c: Rn_.ink }); T(g, 100, 80, 'জনন কোষ', { fs: 10, a: 'middle', c: R3.ink }); T(g, 180, 32, 'দ্বিকোষী পরাগরেণু', { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    const L = s === 4 ? 30 + 120 * k : 150, Rw = BK.ramp(11);
    E('rect', { x: 20, y: 46, width: 320, height: 18, rx: 6, fill: FK.alpha(R3.c, .18) }, g); T(g, 28, 40, 'গর্ভমুণ্ড', { fs: 9.5, c: R3.ink });
    wallC(g, 70, 54, 26, Ra, Ra.lt);
    E('path', { d: `M84 72Q100 ${72 + L * .5} ${100 + L} ${80 + L * .55}`, stroke: Rw.dk, 'stroke-width': 10, fill: 'none', 'stroke-linecap': 'round', opacity: .35 }, g);
    E('path', { d: `M84 72Q100 ${72 + L * .5} ${100 + L} ${80 + L * .55}`, stroke: Rw.lt, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g);
    nuc(g, 96 + L, 78 + L * .55, 6, Rn_); T(g, 106 + L, 98 + L * .55, 'নালি নিউক্লিয়াস', { fs: 9.5, a: 'end', c: Rn_.ink });
    const bz = q => { const r = 1 - q; return [r * r * 84 + 2 * r * q * 100 + q * q * (100 + L), r * r * 72 + 2 * r * q * (72 + L * .5) + q * q * (80 + L * .55)]; };
    if (s === 4) { const [a, b] = bz(.4); nuc(g, a, b, 6, R3); }
    else { const sp = .04 + .08 * k, [a1, b1] = bz(.66 - sp), [a2, b2] = bz(.66 + sp); nuc(g, a1, b1, 5, R3); nuc(g, a2, b2, 5, R3); T(g, a1 - 6, b1 + 26, '২ পুংগ্যামেট (n)', { fs: 10, a: 'end', c: R3.ink }); }
    T(g, 180, 220, s === 4 ? 'পরাগনালি বৃদ্ধি' : 'পরিণত পুংগ্যামেটোফাইট: ১ নালি নিউক্লিয়াস + ২ পুংগ্যামেট', { fs: 10.5, a: 'middle', w: 600, c: C.fg });
  }
}));

/* ═════════ ৫. ডিম্বক ═════════ */
const OVinfo = {
  fun: ['ডিম্বকনাভিরজ্জু / বৃন্ত (ফানিকুলাস)', 'ডিম্বককে অমরার সাথে যুক্ত রাখে; এর ভেতর দিয়ে ভাস্কুলার বান্ডল খাদ্য পৌঁছায়।'],
  hil: ['ডিম্বকনাভি (হাইলাম)', 'যেখানে ফানিকুলাস ডিম্বকের দেহের সাথে মেলে — বীজে এটি দাগ হিসেবে থাকে।'],
  rap: ['রেফি', 'অ্যানাট্রপাস ডিম্বকে ফানিকুলাস ডিম্বকের দেহের সাথে লম্বালম্বি জুড়ে যে শিরার মতো উঁচু অংশ গঠন করে।'],
  cha: ['ডিম্বকমূল (চ্যালাজা)', 'ডিম্বকের যে প্রান্তে আবরণী ও নিউসেলাস একসাথে মিলেছে — ডিম্বকরন্ধ্রের বিপরীত দিকে।'],
  oi: ['বহিঃত্বক (বাইরের আবরণী)', 'দুটি আবরণীর বাইরেরটি — নিষেকের পর বীজত্বকের টেস্টা তৈরি করে।'],
  ii: ['অন্তঃত্বক (ভেতরের আবরণী)', 'ভেতরের আবরণী — নিষেকের পর বীজত্বকের টেগমেন তৈরি করে।'],
  mic: ['ডিম্বকরন্ধ্র (মাইক্রোপাইল)', 'আবরণীর শীর্ষের ছোট ছিদ্র — সাধারণত এ পথে পরাগনালি ঢোকে (পোরোগ্যামি); বীজে পানি শোষণের পথ।'],
  nuc: ['নিউসেলাস (ভ্রূণপোষক টিস্যু)', 'আবরণীর ভেতরের প্যারেনকাইমা টিস্যু (2n) — মেগাস্পোরাঞ্জিয়ামের মূল দেহ; বিকাশমান ভ্রূণথলিকে খাদ্য দেয়। কিছু বীজে অবশিষ্ট নিউসেলাস খাদ্য হিসেবে থাকে — পেরিস্পার্ম (গোলমরিচ)।'],
  es: ['ভ্রূণথলি (এমব্রায়ো স্যাক)', 'স্ত্রীগ্যামেটোফাইট (n) — সাধারণত ৮ নিউক্লিয়াস, ৭ কোষ; ডিম্বকরন্ধ্রের দিকে ডিম্বাণু যন্ত্র।']
};
/* স্থানীয় স্থানাঙ্কে সরল ডিম্বক: ডিম্বকরন্ধ্র ওপরে (y কম), চ্যালাজা নিচে */
const ovBody = (g, C, x, y, sel, flip) => {
  const Rc = Rf(), Rw = BK.ramp(11), Rn_ = Rn(), H = c => sel === c ? BK.ramp(4).c : null, s = flip ? -1 : 1;
  const P = (dx, dy) => [x + dx, y + s * dy];
  const shell = (rx, ry, gap) => { const [x0, y0] = P(-gap, -ry * .96), [x1, y1] = P(gap, -ry * .96), [xb, yb] = P(0, ry); return `M${x0} ${y0}A${rx} ${ry} 0 1 ${flip ? 1 : 0} ${xb} ${yb}A${rx} ${ry} 0 1 ${flip ? 1 : 0} ${x1} ${y1}`; };
  E('path', { d: shell(62, 92, 7), fill: FK.alpha(Rw.c, .35), stroke: H('oi') || Rw.dk, 'stroke-width': H('oi') ? 2.6 : 1.4 }, g);
  E('path', { d: shell(52, 82, 7), fill: FK.alpha(Rw.lt, .9), stroke: H('ii') || Rw.dk, 'stroke-width': H('ii') ? 2.6 : 1.2 }, g);
  const [nx, ny] = P(0, 6); E('ellipse', { cx: nx, cy: ny, rx: 42, ry: 70, fill: FK.alpha(R2n().c, sel === 'nuc' ? .4 : .2), stroke: H('nuc') || R2n().dk, 'stroke-width': H('nuc') ? 2.4 : 1 }, g);
  const [ex, ey] = P(0, -18); E('ellipse', { cx: ex, cy: ey, rx: 18, ry: 40, fill: FK.alpha(Rn_.c, sel === 'es' ? .5 : .25), stroke: H('es') || Rn_.dk, 'stroke-width': H('es') ? 2.4 : 1.2 }, g);
  [[0, -50, 5], [-7, -44, 4], [7, -44, 4], [-4, -18, 3.5], [4, -16, 3.5], [0, 10, 3.5], [-7, 14, 3.5], [7, 14, 3.5]].forEach(([dx, dy, r], i) => { const [a, b] = P(dx, dy); nuc(g, a, b, r, i === 0 ? Rc : Rn_, { nl: false }); });
  const [mx, my] = P(0, -100); E('path', { d: `M${mx} ${my}v${s * 14}`, stroke: H('mic') || C.fg, 'stroke-width': H('mic') ? 3 : 1.4, 'stroke-dasharray': '3 2' }, g);
  const [cx_, cy_] = P(0, 84); E('ellipse', { cx: cx_, cy: cy_, rx: 22, ry: 8, fill: FK.alpha(Rw.dk, H('cha') ? .5 : .25), stroke: H('cha') || 'none', 'stroke-width': 2 }, g);
};
V.ovule = Object.assign({}, B.seg({
  id: 'ov', t: 'ডিম্বকের গঠন', H: 270, def: 'ana',
  cap: 'ডিম্বক (মেগাস্পোরাঞ্জিয়াম) ফানিকুলাস দিয়ে অমরায় যুক্ত। মূল দেহ নিউসেলাস, চারপাশে এক বা দুই আবরণী; আবরণীর মুখে ডিম্বকরন্ধ্র, বিপরীত প্রান্তে চ্যালাজা; নিউসেলাসের ভেতরে ভ্রূণথলি। অংশে চাপ দাও।',
  types: {
    ana: ['অ্যানাট্রপাস', 'অ্যানাট্রপাস (উল্টানো) ডিম্বক', 'ডিম্বকের দেহ ১৮০° উল্টে যায় — ডিম্বকরন্ধ্র ফানিকুলাসের কাছে নিচের দিকে থাকে; ফানিকুলাস দেহের সাথে জুড়ে রেফি গঠন করে। আবৃতবীজী উদ্ভিদের প্রায় ৮০% গোত্রে এ ধরন — সবচেয়ে সাধারণ।'],
    ortho: ['অর্থোট্রপাস', 'অর্থোট্রপাস (সোজা) ডিম্বক', 'ফানিকুলাস, চ্যালাজা ও ডিম্বকরন্ধ্র একই সরলরেখায় — ডিম্বকরন্ধ্র ওপরে। উদাহরণ: Polygonum, পান (Piper), অধিকাংশ নগ্নবীজী।'],
    camp: ['ক্যাম্পাইলোট্রপাস', 'ক্যাম্পাইলোট্রপাস (বাঁকা) ডিম্বক', 'ডিম্বকের দেহ নিজেই বাঁকা (বৃক্কাকার) — ডিম্বকরন্ধ্র ফানিকুলাসের কাছে আসে, ভ্রূণথলি কিছুটা বাঁকা। উদাহরণ: মটর ও শিম গোত্র, সরিষা (Brassicaceae)।']
  },
  art(g, C, ty, ctx) {
    const sel = ctx.sel, Rw = BK.ramp(11), H = c => sel === c ? BK.ramp(4).c : null;
    E('rect', { x: 0, y: 252, width: 360, height: 18, fill: FK.alpha(Rf().c, .22) }, g); T(g, 12, 264, 'অমরা', { fs: 9.5, c: Rf().ink });
    if (ty === 'ortho') {
      E('path', { d: 'M180 252V224', stroke: H('fun') || Rw.dk, 'stroke-width': H('fun') ? 12 : 9, 'stroke-linecap': 'round' }, g);
      ovBody(g, C, 180, 128, sel, false);
      lab(g, 180, 26, 250, 18, 'ডিম্বকরন্ধ্র', C, { fs: 10.5 }); lab(g, 198, 212, 270, 234, 'চ্যালাজা', C, { fs: 10.5 }); lab(g, 184, 240, 110, 240, 'ফানিকুলাস', C, { fs: 10.5 });
    } else if (ty === 'ana') {
      E('path', { d: 'M98 252Q100 236 130 226', stroke: H('fun') || Rw.dk, 'stroke-width': H('fun') ? 12 : 9, fill: 'none', 'stroke-linecap': 'round' }, g);
      ovBody(g, C, 200, 128, sel, true);
      E('path', { d: 'M134 220Q124 130 160 44', stroke: H('rap') || Rw.dk, 'stroke-width': H('rap') ? 9 : 7, fill: 'none', 'stroke-linecap': 'round', opacity: .8 }, g);
      E('circle', { cx: 134, cy: 222, r: 6, fill: H('hil') || Rw.dk }, g);
      lab(g, 200, 230, 280, 244, 'ডিম্বকরন্ধ্র', C, { fs: 10.5 }); lab(g, 200, 44, 270, 18, 'চ্যালাজা', C, { fs: 10.5 }); lab(g, 130, 130, 40, 120, 'রেফি', C, { fs: 10.5 }); lab(g, 134, 222, 40, 210, 'হাইলাম', C, { fs: 10.5 });
    } else {
      const Rc = Rf(), Rn_ = Rn();
      E('path', { d: 'M150 252V222', stroke: H('fun') || Rw.dk, 'stroke-width': H('fun') ? 12 : 9, 'stroke-linecap': 'round' }, g);
      const bean = (k, at) => E('path', Object.assign({ d: `M${150 - 10 * k} ${216 + 6 * k}C${60 - 40 * k} ${210 + 20 * k} ${50 - 40 * k} ${40 - 30 * k} ${180} ${40 - 30 * k}C${300 + 40 * k} ${40 - 30 * k} ${310 + 40 * k} ${200 + 20 * k} ${196 + 10 * k} ${212 + 6 * k}C${186} ${180 - 10 * k} ${160} ${180 - 10 * k} ${150 - 10 * k} ${216 + 6 * k}Z` }, at), g);
      bean(.5, { fill: FK.alpha(Rw.c, .35), stroke: H('oi') || Rw.dk, 'stroke-width': H('oi') ? 2.6 : 1.4 }); bean(.2, { fill: FK.alpha(Rw.lt, .9), stroke: H('ii') || Rw.dk, 'stroke-width': H('ii') ? 2.6 : 1.2 }); bean(-.15, { fill: FK.alpha(R2n().c, sel === 'nuc' ? .4 : .2), stroke: H('nuc') || R2n().dk });
      E('path', { d: 'M170 186Q130 150 170 104Q210 80 234 120', stroke: H('es') || Rn_.dk, 'stroke-width': 20, fill: 'none', 'stroke-linecap': 'round', opacity: .25 }, g);
      E('path', { d: 'M170 186Q130 150 170 104Q210 80 234 120', stroke: H('es') || Rn_.dk, 'stroke-width': 1.2, fill: 'none' }, g);
      nuc(g, 172, 180, 5, Rc, { nl: false }); nuc(g, 182, 172, 4, Rn_, { nl: false }); nuc(g, 162, 172, 4, Rn_, { nl: false }); nuc(g, 168, 116, 3.5, Rn_, { nl: false }); nuc(g, 232, 124, 3.5, Rn_, { nl: false });
      E('path', { d: 'M174 194v14', stroke: H('mic') || C.fg, 'stroke-width': H('mic') ? 3 : 1.4, 'stroke-dasharray': '3 2' }, g);
      lab(g, 174, 206, 250, 240, 'ডিম্বকরন্ধ্র', C, { fs: 10.5 }); lab(g, 300, 120, 316, 70, 'চ্যালাজা', C, { fs: 10.5 }); lab(g, 150, 236, 70, 240, 'ফানিকুলাস', C, { fs: 10.5 });
      E('ellipse', { cx: 296, cy: 124, rx: 8, ry: 18, fill: FK.alpha(Rw.dk, H('cha') ? .5 : .25) }, g);
    }
  },
  anim(g, C, ty, t) { if (!t) return; const R = Rm(), u = (t * .25) % 1, p = ty === 'ortho' ? [[180, -10], [180, 34]] : ty === 'ana' ? [[200, 280], [200, 222]] : [[174, 260], [174, 196]], x = p[0][0], y = p[0][1] + (p[1][1] - p[0][1]) * u; E('path', { d: `M${x} ${p[0][1]}L${x} ${y}`, stroke: BK.ramp(11).c, 'stroke-width': 3, opacity: .6 }, g); E('circle', { cx: x, cy: y, r: 3, fill: R.c }, g); },
  tap(x, y, ty, ctx) {
    const H = ty === 'ortho' ? [['mic', 180, 26], ['es', 180, 110], ['nuc', 222, 150], ['ii', 128, 128], ['oi', 116, 128], ['cha', 180, 212], ['fun', 180, 240]]
      : ty === 'ana' ? [['mic', 200, 228], ['es', 200, 146], ['nuc', 242, 110], ['ii', 250, 130], ['oi', 262, 130], ['cha', 200, 44], ['rap', 132, 130], ['hil', 134, 222], ['fun', 104, 244]]
      : [['mic', 174, 204], ['es', 200, 96], ['nuc', 180, 150], ['oi', 60, 120], ['ii', 76, 120], ['cha', 296, 124], ['fun', 150, 240]];
    const k = hot(H, x, y, 26); ctx.sel = k; if (!k) return ctx.def(); return `<b>${OVinfo[k][0]}</b> — ${OVinfo[k][1]}`;
  }
}));

/* ═════════ ৬. স্ত্রীগ্যামেটোফাইটের বিকাশ ═════════ */
V.megaGameto = Object.assign({ t: 'মেগাস্পোরোজেনেসিস ও ভ্রূণথলির বিকাশ (পলিগোনাম ধরন)', k: ['anim', 'steps'], cap: 'নিউসেলাসের একটি মেগাস্পোর মাতৃকোষ (2n) মিয়োসিসে চারটি মেগাস্পোর (n) তৈরি করে, তিনটি নষ্ট হয় — মেগাস্পোরোজেনেসিস। কার্যকর মেগাস্পোরের নিউক্লিয়াস তিনবার মাইটোসিসে ৮টি নিউক্লিয়াস হয় এবং ৭ কোষের ভ্রূণথলি গঠিত হয় — একটিমাত্র মেগাস্পোর থেকে বলে একে মনোস্পোরিক বা পলিগোনাম ধরন বলে (প্রায় ৭০% আবৃতবীজীতে)।' }, BK.steps({
  W: 360, H: 250, label: 'ভ্রূণথলির বিকাশ', dur: 2.8,
  stages: [
    { t: 'মেগাস্পোর মাতৃকোষ', en: 'Megaspore mother cell (2n)', d: 'নিউসেলাসের ডিম্বকরন্ধ্রের দিকের একটি আর্কিস্পোরিয়াল কোষ বড় হয়ে মেগাস্পোর মাতৃকোষে পরিণত হয় (2n)।' },
    { t: 'মিয়োসিস → রৈখিক টেট্রাড', en: 'Linear tetrad', d: 'মিয়োসিসে চারটি হ্যাপ্লয়েড মেগাস্পোর তৈরি হয় — একটির ওপরে আরেকটি সারিবদ্ধ (রৈখিক টেট্রাড)।' },
    { t: 'তিনটি নষ্ট, একটি কার্যকর', en: 'Functional megaspore', d: 'ডিম্বকরন্ধ্রের দিকের তিনটি মেগাস্পোর নষ্ট হয়; চ্যালাজার দিকের একটি কার্যকর মেগাস্পোর বড় হয় — এটিই স্ত্রীগ্যামেটোফাইটের প্রথম কোষ।' },
    { t: '১ম মাইটোসিস: ২ নিউক্লিয়াস', en: 'Two-nucleate', d: 'নিউক্লিয়াস বিভাজিত হয়ে দুটি নিউক্লিয়াস দুই মেরুতে যায়; মাঝে বড় কোষগহ্বর। (নিউক্লিয়াস বিভাজনের সাথে কোষ বিভাজন হয় না — মুক্ত নিউক্লিয়াস বিভাজন।)' },
    { t: '২য় ও ৩য় মাইটোসিস: ৮ নিউক্লিয়াস', en: 'Eight-nucleate', d: 'আরও দুবার বিভাজনে প্রতিটি মেরুতে চারটি করে মোট আটটি নিউক্লিয়াস।' },
    { t: 'ভ্রূণথলি গঠন: ৭ কোষ, ৮ নিউক্লিয়াস', en: 'Mature embryo sac', d: 'প্রতিটি মেরু থেকে একটি করে নিউক্লিয়াস কেন্দ্রে এসে দুটি পোলার নিউক্লিয়াস হয় (কেন্দ্রীয় কোষ)। ডিম্বকরন্ধ্রের দিকের তিনটি → ডিম্বাণু যন্ত্র (১ ডিম্বাণু + ২ সহকারী কোষ), চ্যালাজার দিকের তিনটি → প্রতিপাদ কোষ। মোট ৭ কোষ, ৮ নিউক্লিয়াস।' }
  ],
  draw(g, C, s, u) {
    const Rc = Rf(), Rn_ = Rn(), R2 = R2n(), k = u, cx = 180;
    E('ellipse', { cx, cy: 128, rx: 140, ry: 96, fill: FK.alpha(R2.c, .14), stroke: R2.dk }, g); T(g, 40, 30, 'নিউসেলাস (2n)', { fs: 10, c: R2.ink }); T(g, 330, 132, 'চ্যালাজা →', { fs: 9.5, a: 'end', c: C.mu }); T(g, 30, 132, '← ডিম্বকরন্ধ্র', { fs: 9.5, c: C.mu });
    if (s === 0) { E('rect', { x: cx - 30, y: 100, width: 60, height: 56, rx: 12, fill: FK.alpha(R2.c, .5), stroke: R2.dk }, g); nuc(g, cx, 128, 14 + Math.sin(k * 6), R2); ploid(g, cx, 186, '2n', R2); return; }
    if (s === 1 || s === 2) {
      const sp = s === 1 ? 4 + 4 * k : 8;
      for (let i = 0; i < 4; i++) { const x = cx - 66 + i * (40 + sp * .5), dead = s === 2 && i < 3, op = dead ? 1 - .75 * k : 1, w = s === 2 && i === 3 ? 34 + 26 * k : 34; E('rect', { x: x - w / 2 + (s === 2 && i === 3 ? 13 * k : 0), y: 108, width: w, height: 40, rx: 8, fill: FK.alpha((dead ? C.mu : Rn_.c), .4), stroke: dead ? C.mu : Rn_.dk, opacity: op }, g); nuc(g, x + (s === 2 && i === 3 ? 13 * k : 0), 128, 7, dead ? BK.ramp(9) : Rn_, { op }); }
      ploid(g, cx, 186, '4 × n', Rn_, 48); if (s === 2) T(g, cx - 40, 96, 'নষ্ট হচ্ছে', { fs: 10, a: 'middle', c: C.mu }); if (s === 2) T(g, cx + 72, 96, 'কার্যকর', { fs: 10, a: 'middle', w: 600, c: Rn_.ink }); return;
    }
    const W = s === 3 ? 90 + 20 * k : 110;
    E('ellipse', { cx, cy: 128, rx: W, ry: 44, fill: FK.alpha(Rn_.c, .16), stroke: Rn_.dk, 'stroke-width': 1.4 }, g);
    if (s === 3) { const d = 20 + 60 * k; nuc(g, cx - d, 128, 7, Rn_); nuc(g, cx + d, 128, 7, Rn_); T(g, cx, 132, 'কোষগহ্বর', { fs: 9.5, a: 'middle', c: C.mu }); return; }
    if (s === 4) { const L = [[-80, -14], [-80, 14], [-94, 0], [-64, 0]], sp = k; L.forEach(([dx, dy]) => { nuc(g, cx + dx * (.9 + .1 * sp), 128 + dy * sp, 6, Rn_); nuc(g, cx - dx * (.9 + .1 * sp), 128 + dy * sp, 6, Rn_); }); ploid(g, cx, 196, '8 নিউক্লিয়াস (n)', Rn_, 104); return; }
    const egg = [cx - 64, 128], syn = [[cx - 82, 112], [cx - 82, 144]], pol = [[cx - 10 * k - 2, 128], [cx + 10 * k + 2, 128]], ant = [[cx + 80, 112], [cx + 88, 128], [cx + 80, 144]];
    E('ellipse', { cx: egg[0], cy: egg[1], rx: 14, ry: 11, fill: FK.alpha(Rc.c, .5), stroke: Rc.dk }, g); nuc(g, egg[0], egg[1], 5, Rc);
    syn.forEach(([x, y]) => { E('ellipse', { cx: x, cy: y, rx: 10, ry: 9, fill: FK.alpha(Rn_.c, .35), stroke: Rn_.dk }, g); nuc(g, x, y, 3.5, Rn_); });
    pol.forEach(([x, y]) => nuc(g, x, y, 6, BK.ramp(7)));
    ant.forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 8, fill: FK.alpha(BK.ramp(9).c, .3), stroke: BK.ramp(9).dk }, g); nuc(g, x, y, 3.2, BK.ramp(9)); });
    T(g, cx - 80, 200, 'ডিম্বাণু যন্ত্র', { fs: 10, a: 'middle', w: 600, c: Rc.ink }); T(g, cx, 186, '২ পোলার নিউক্লিয়াস', { fs: 10, a: 'middle', w: 600, c: BK.ramp(7).ink }); T(g, cx + 88, 200, 'প্রতিপাদ কোষ', { fs: 10, a: 'middle', w: 600, c: BK.ramp(9).ink });
    T(g, cx, 238, '৭ কোষ, ৮ নিউক্লিয়াস — সব n', { fs: 11, a: 'middle', w: 650, c: C.fg });
  }
}));

/* ═════════ ৭. পরিণত ভ্রূণথলি ═════════ */
const ESinfo = {
  egg: ['ডিম্বাণু (n)', 'স্ত্রীগ্যামেট — ডিম্বকরন্ধ্রের দিকে দুই সহকারী কোষের মাঝে, নিচের দিকে ঝুলে থাকে; একটি পুংগ্যামেটের সাথে মিলে জাইগোট (2n) → ভ্রূণ।'],
  syn: ['সহকারী কোষ (সিনারজিড, n)', 'ডিম্বাণুর দুই পাশে দুটি; ডিম্বকরন্ধ্রের দিকে আঙুলের মতো প্রাচীর-স্থূলীকরণ (ফিলিফর্ম যন্ত্র) থাকে — রাসায়নিক সংকেত দিয়ে পরাগনালিকে আকর্ষণ করে; পরাগনালি একটি সহকারী কোষে ঢুকে পুংগ্যামেট ছাড়ে, পরে সেটি নষ্ট হয়।'],
  pol: ['দুটি পোলার নিউক্লিয়াস (n + n)', 'কেন্দ্রীয় কোষের দুটি নিউক্লিয়াস — নিষেকের আগে বা সময় মিলে সেকেন্ডারি নিউক্লিয়াস (2n) হয়; দ্বিতীয় পুংগ্যামেটের সাথে মিলে প্রাথমিক সস্য নিউক্লিয়াস (3n) — ত্রি-মিলন।'],
  sec: ['সেকেন্ডারি নিউক্লিয়াস (2n)', 'দুটি পোলার নিউক্লিয়াসের মিলনে তৈরি ডিপ্লয়েড নিউক্লিয়াস — পুংগ্যামেটের সাথে মিলে 3n সস্য নিউক্লিয়াস।'],
  ant: ['প্রতিপাদ কোষ (অ্যান্টিপোডাল, n)', 'চ্যালাজার দিকে তিনটি কোষ — নিউসেলাস থেকে খাদ্য শোষণে সাহায্য করে বলে ধারণা; নিষেকের আগে বা পরে নষ্ট হয়।'],
  cen: ['কেন্দ্রীয় কোষ', 'ভ্রূণথলির সবচেয়ে বড় কোষ, বড় কোষগহ্বরযুক্ত — দুটি পোলার নিউক্লিয়াস ধারণ করে; নিষেকের পর সস্যে পরিণত হয়।'],
  fil: ['ফিলিফর্ম যন্ত্র', 'সহকারী কোষের ডিম্বকরন্ধ্রীয় প্রান্তের আঙুলের মতো প্রাচীর-ভাঁজ — পরাগনালিকে পথ দেখায়।']
};
V.embryoSac = Object.assign({}, B.seg({
  id: 'es', t: 'পরিণত ভ্রূণথলি (স্ত্রীগ্যামেটোফাইট)', H: 250, def: 'mature',
  cap: 'পরিণত ভ্রূণথলি আবৃতবীজী উদ্ভিদের স্ত্রীগ্যামেটোফাইট — মাত্র ৭টি কোষ ও ৮টি নিউক্লিয়াস: ডিম্বাণু যন্ত্র (ডিম্বাণু + ২ সহকারী কোষ), কেন্দ্রীয় কোষ (২ পোলার নিউক্লিয়াস), ৩ প্রতিপাদ কোষ। কোষে চাপ দাও।',
  types: {
    mature: ['৮ নিউক্লিয়াস', 'পরিণত ভ্রূণথলি — ৭ কোষ, ৮ নিউক্লিয়াস', 'সব নিউক্লিয়াস হ্যাপ্লয়েড (n)।'],
    sec: ['সেকেন্ডারি নিউক্লিয়াস', 'পোলার নিউক্লিয়াস মিলনের পর — ৭ কোষ, ৭ নিউক্লিয়াস', 'দুটি পোলার নিউক্লিয়াস মিলে সেকেন্ডারি নিউক্লিয়াস (2n) — নিষেকের জন্য প্রস্তুত ভ্রূণথলি।']
  },
  art(g, C, ty, ctx) {
    const Rc = Rf(), Rn_ = Rn(), R7 = BK.ramp(7), R9 = BK.ramp(9), sel = ctx.sel, H = k => sel === k ? BK.ramp(4).c : null;
    E('path', { d: 'M40 125C40 60 110 40 200 44C290 48 330 80 330 125C330 170 290 202 200 206C110 210 40 190 40 125Z', fill: FK.alpha(Rn_.c, sel === 'cen' ? .26 : .1), stroke: H('cen') || Rn_.dk, 'stroke-width': H('cen') ? 2.6 : 1.4 }, g);
    E('path', { d: 'M40 125h-24', stroke: C.fg, 'stroke-width': 1.4, 'stroke-dasharray': '3 2' }, g); T(g, 12, 112, 'ডিম্বকরন্ধ্র', { fs: 9.5, c: C.mu }); T(g, 352, 128, 'চ্যালাজা', { fs: 9.5, a: 'end', c: C.mu });
    [[90, 98], [90, 152]].forEach(([x, y]) => { E('path', { d: `M${x - 30} ${y}C${x - 34} ${y - 18} ${x + 14} ${y - 24} ${x + 20} ${y}C${x + 14} ${y + 24} ${x - 34} ${y + 18} ${x - 30} ${y}Z`, fill: FK.alpha(Rn_.c, sel === 'syn' ? .6 : .3), stroke: H('syn') || Rn_.dk, 'stroke-width': H('syn') ? 2.4 : 1.1 }, g); nuc(g, x - 4, y, 5, Rn_); for (let i = 0; i < 4; i++) E('path', { d: `M${x - 30} ${y - 6 + i * 4}h-8`, stroke: H('fil') || Rn_.dk, 'stroke-width': 1.4 }, g); });
    E('path', { d: 'M70 125C70 104 104 102 124 112C138 120 138 130 124 138C104 148 70 146 70 125Z', fill: FK.alpha(Rc.c, sel === 'egg' ? .7 : .45), stroke: H('egg') || Rc.dk, 'stroke-width': H('egg') ? 2.6 : 1.2 }, g); nuc(g, 112, 125, 8, Rc);
    if (ty === 'mature') [[190, 120], [212, 132]].forEach(([x, y]) => nuc(g, x, y, 9, R7, { fill: sel === 'pol' ? R7.dk : R7.c }));
    else nuc(g, 202, 126, 12, R2n(), { fill: sel === 'sec' ? R2n().dk : R2n().c });
    [[300, 96], [312, 125], [300, 154]].forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 15, fill: FK.alpha(R9.c, sel === 'ant' ? .55 : .28), stroke: H('ant') || R9.dk, 'stroke-width': H('ant') ? 2.4 : 1 }, g); nuc(g, x, y, 5, R9); });
    T(g, 100, 224, 'ডিম্বাণু যন্ত্র', { fs: 10.5, a: 'middle', w: 600, c: Rc.ink }); T(g, 202, 168, ty === 'mature' ? 'পোলার নিউক্লিয়াস (n+n)' : 'সেকেন্ডারি নিউক্লিয়াস (2n)', { fs: 10, a: 'middle', w: 600, c: ty === 'mature' ? R7.ink : R2n().ink }); T(g, 300, 224, 'প্রতিপাদ কোষ', { fs: 10.5, a: 'middle', w: 600, c: R9.ink });
    T(g, 202, 240, ty === 'mature' ? '৭ কোষ · ৮ নিউক্লিয়াস' : '৭ কোষ · ৭ নিউক্লিয়াস', { fs: 11, a: 'middle', w: 650, c: C.fg });
  },
  anim(g, C, ty, t) { if (!t) return; const k = .5 + .5 * Math.sin(t * 2.2); E('circle', { cx: 202, cy: 126, r: 18 + 6 * k, fill: 'none', stroke: ty === 'mature' ? BK.ramp(7).c : BK.ramp(10).c, 'stroke-width': 1.6, opacity: .6 - .4 * k }, g); for (let i = 0; i < 3; i++) { const u = (t * .3 + i / 3) % 1; E('circle', { cx: 8 + u * 30, cy: 125, r: 2.4, fill: BK.ramp(11).c, opacity: 1 - u }, g); } },
  tap(x, y, ty, ctx) {
    const H = [['egg', 108, 125], ['syn', 84, 98], ['syn', 84, 152], ['fil', 56, 98], ['fil', 56, 152], [ty === 'mature' ? 'pol' : 'sec', 202, 126], ['ant', 300, 96], ['ant', 312, 125], ['ant', 300, 154], ['cen', 250, 70], ['cen', 250, 180]];
    const k = hot(H, x, y, 26); ctx.sel = k; if (!k) return ctx.def(); return `<b>${ESinfo[k][0]}</b> — ${ESinfo[k][1]}`;
  }
}));

/* ═════════ তুলনা ═════════ */
V.cmpMaleFemale = cmp('পুংগ্যামেটোফাইট বনাম স্ত্রীগ্যামেটোফাইট', 'দুটিই হ্যাপ্লয়েড, ক্ষুদ্র ও স্পোরোফাইটের ওপর নির্ভরশীল — আবৃতবীজী উদ্ভিদে গ্যামেটোফাইট সবচেয়ে সংক্ষিপ্ত।', 'পুংগ্যামেটোফাইট', 'স্ত্রীগ্যামেটোফাইট', [
  ['প্রথম কোষ', 'মাইক্রোস্পোর (পরাগরেণু)', 'কার্যকর মেগাস্পোর'],
  ['উৎপত্তিস্থল', 'পরাগধানীর পরাগথলি', 'ডিম্বকের নিউসেলাস'],
  ['মাতৃকোষ থেকে কার্যকর রেণু', 'চারটিই কার্যকর (টেট্রাড)', 'চারটির একটি কার্যকর, তিনটি নষ্ট'],
  ['মাইটোসিস', 'দুটি (১ম পরাগরেণুতে, ২য় সাধারণত পরাগনালিতে)', 'তিনটি মুক্ত নিউক্লিয়াস বিভাজন'],
  ['পরিণত অবস্থা', '৩ নিউক্লিয়াস: ১ নালি নিউক্লিয়াস + ২ পুংগ্যামেট', '৭ কোষ, ৮ নিউক্লিয়াস (ভ্রূণথলি)'],
  ['গ্যামেট', 'দুটি পুংগ্যামেট', 'একটি ডিম্বাণু'],
  ['স্থানান্তর', 'বাতাস, পতঙ্গ ইত্যাদির মাধ্যমে গর্ভমুণ্ডে যায় (পরাগায়ন)', 'ডিম্বকের ভেতরে স্থির থাকে'],
  ['প্রাচীর', 'এক্সাইন (স্পোরোপোলেনিন) ও ইনটাইন', 'পাতলা প্রাচীর, নিউসেলাসে আবৃত']
]);
})();
