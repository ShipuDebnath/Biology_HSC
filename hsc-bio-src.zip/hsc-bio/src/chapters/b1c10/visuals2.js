/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §১০.২ পরাগায়ন, নিষেক, দ্বিনিষেক, নিষেকের পরিণতি, বীজ ও ফল
   pollinationTypes : স্ব-পরাগায়ন (অটোগ্যামি, গেইটোনোগ্যামি) ও পর-পরাগায়ন (জেনোগ্যামি)
   pollinators      : পরাগায়নের মাধ্যম — বায়ু, পতঙ্গ, পানি, পাখি, বাদুড়; ফুলের অভিযোজন
   outcross         : পর-পরাগায়নের কৌশল — একলিঙ্গতা, ভিন্নকালপক্বতা, হারকোগ্যামি, হেটারোস্টাইলি, স্ব-অসঙ্গতি
   pollenTube       : পরাগনালির প্রবেশপথ — পোরোগ্যামি, চ্যালাজোগ্যামি, মেসোগ্যামি (অ্যানিমেশন)
   dblFert          : দ্বিনিষেক — ধাপে ধাপে (সিনগ্যামি ও ত্রি-মিলন)
   postFert         : নিষেকের পর গর্ভাশয় ও ডিম্বকের পরিবর্তন (সারিতে চাপ দাও)
   embryoDev        : দ্বিবীজপত্রী ভ্রূণের বিকাশ (Capsella) ও সস্য — ধাপে ধাপে
   seedTypes        : বীজের গঠন — ছোলা/শিম (দ্বিবীজপত্রী, অসস্য), ভুট্টা (একবীজপত্রী, সস্যল)
   cmpSelfCross, cmpFertDouble, cmpAnemoEnto, cmpSeedDM : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B10;
const PI = Math.PI, ch = B.ch, cl = B.cl, rnd = B.rnd, node = B.node, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const hot = (H, x, y, r = 30) => { let best = null, bd = r; H.forEach(([k, hx, hy]) => { const d = Math.hypot(x - hx, y - hy); if (d < bd) { bd = d; best = k; } }); return best; };
const nuc = (g, x, y, r, R, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.c, stroke: R.dk, 'stroke-width': 1, opacity: o.op != null ? o.op : 1 }, g); if (o.nl !== false && r > 3) E('circle', { cx: x - r * .3, cy: y - r * .3, r: r * .28, fill: R.dk, opacity: .55 }, g); };
const ploid = (g, x, y, s, R, w = 34) => B.chip(g, x, y, s, R, { w, h: 16, fs: 9 });
const qb = (p0, p1, p2, q) => { const r = 1 - q; return [r * r * p0[0] + 2 * r * q * p1[0] + q * q * p2[0], r * r * p0[1] + 2 * r * q * p1[1] + q * q * p2[1]]; };

/* সরল ফুল (ওপর থেকে নয়, পাশ থেকে) */
const flower = (g, x, y, s, o = {}) => {
  const Rp = BK.ramp(o.pc != null ? o.pc : 8), Ra = BK.ramp(6), Rc = BK.ramp(3);
  [-1, 1].forEach(d => E('path', { d: `M${x} ${y}Q${x + d * 22 * s} ${y - 6 * s} ${x + d * 26 * s} ${y - 30 * s}Q${x + d * 10 * s} ${y - 26 * s} ${x} ${y}Z`, fill: FK.alpha(Rp.c, .6), stroke: Rp.dk, 'stroke-width': 1 }, g));
  if (o.male !== false) [-1, 1].forEach(d => { E('path', { d: `M${x + d * 3 * s} ${y}L${x + d * 10 * s} ${y - 26 * s}`, stroke: Ra.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: x + d * 10 * s, cy: y - 28 * s, rx: 3 * s, ry: 4.5 * s, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .8 }, g); });
  if (o.fem !== false) { E('path', { d: `M${x} ${y}V${y - (o.sty || 32) * s}`, stroke: Rc.dk, 'stroke-width': 2.2 }, g); E('ellipse', { cx: x, cy: y - (o.sty || 32) * s, rx: 5 * s, ry: 3 * s, fill: Rc.lt, stroke: Rc.dk }, g); E('ellipse', { cx: x, cy: y + 4 * s, rx: 6 * s, ry: 6 * s, fill: FK.alpha(Rc.c, .4), stroke: Rc.dk }, g); }
};
const plant = (g, x, base, top, fl) => { const R = BK.ramp(10); E('path', { d: `M${x} ${base}V${top}`, stroke: R.dk, 'stroke-width': 3 }, g); fl.forEach(([dx, y]) => { E('path', { d: `M${x} ${y + 16}Q${x + dx * .5} ${y + 12} ${x + dx} ${y + 4}`, stroke: R.dk, 'stroke-width': 2, fill: 'none' }, g); }); for (let i = 0; i < 3; i++) { const y = base - 20 - i * 26, sd = i % 2 ? 1 : -1; E('path', { d: `M${x} ${y}q${sd * 14} -10 ${sd * 30} -4q${-sd * 14} 8 ${-sd * 30} 4Z`, fill: R.c, stroke: R.dk }, g); } };

/* ═════════ ১. পরাগায়নের প্রকার ═════════ */
const PLfl = { a: [90, 104], b: [146, 150], c: [270, 112] };
const PLpath = { auto: [[84, 76], [78, 60], [90, 72]], geito: [[96, 76], [130, 40], [146, 118]], xeno: [[96, 76], [190, 20], [270, 80]] };
V.pollinationTypes = Object.assign({}, B.seg({
  id: 'pt', t: 'পরাগায়নের প্রকারভেদ', H: 250, def: 'auto',
  cap: 'পরাগধানী থেকে পরাগরেণু গর্ভমুণ্ডে স্থানান্তরকে পরাগায়ন বলে। একই ফুলে বা একই গাছের অন্য ফুলে হলে স্ব-পরাগায়ন, একই প্রজাতির ভিন্ন গাছের ফুলে হলে পর-পরাগায়ন। ধরন বদলে পরাগরেণুর পথ দেখো।',
  types: {
    auto: ['অটোগ্যামি', 'স্ব-পরাগায়ন: অটোগ্যামি', 'একই ফুলের পরাগরেণু সেই ফুলেরই গর্ভমুণ্ডে পড়ে — দ্বিলিঙ্গ ফুলে, পুংকেশর ও গর্ভকেশর একসাথে পরিণত হলে (সমকালপক্বতা)। চরম রূপ — ক্লিস্টোগ্যামি: ফুল না ফুটেই (বন্ধ অবস্থায়) পরাগায়ন, যেমন কানশিরা (Commelina), চিনাবাদামের মাটির নিচের ফুল, ধান-গম-মটরে প্রায় স্ব-পরাগায়ন।', 'সুবিধা: মাধ্যম লাগে না, প্রজাতির বিশুদ্ধতা থাকে, পরাগরেণুর অপচয় কম। অসুবিধা: বৈচিত্র্য কমে, ক্রমে দুর্বলতা (অন্তঃপ্রজনন অবনতি) আসতে পারে।'],
    geito: ['গেইটোনোগ্যামি', 'স্ব-পরাগায়ন: গেইটোনোগ্যামি', 'একই গাছের এক ফুলের পরাগরেণু অন্য ফুলের গর্ভমুণ্ডে — জিনগতভাবে স্ব-পরাগায়ন (একই জিনোটাইপ), কিন্তু কাজের দিক থেকে পর-পরাগায়নের মতো মাধ্যম (পতঙ্গ, বায়ু) লাগে। যেমন ভুট্টা, লাউ-কুমড়া (একই গাছে পুং ও স্ত্রী ফুল)।'],
    xeno: ['জেনোগ্যামি', 'পর-পরাগায়ন: জেনোগ্যামি', 'একই প্রজাতির ভিন্ন গাছের ফুলের মধ্যে পরাগায়ন — জিনগত বৈচিত্র্যপূর্ণ সন্তান। বায়ু, পতঙ্গ, পানি, পাখি বা বাদুড় মাধ্যম হিসেবে লাগে। একলিঙ্গবাসী (ডায়োসিয়াস) উদ্ভিদে — পেঁপে, তাল, খেজুর — একমাত্র উপায়।', 'সুবিধা: নতুন বৈশিষ্ট্য, সংকর সবলতা, অভিযোজন ক্ষমতা বাড়ে। অসুবিধা: মাধ্যমের ওপর নির্ভর, পরাগরেণুর অপচয় বেশি।']
  },
  art(g, C, ty) {
    E('rect', { x: 0, y: 226, width: 360, height: 24, fill: FK.alpha(BK.ramp(11).c, .35) }, g);
    plant(g, 118, 226, 70, [[-28, 100], [28, 146]]); plant(g, 270, 226, 100, [[0, 108]]);
    flower(g, 90, 104, 1); flower(g, 146, 150, 1, { pc: 8 }); flower(g, 270, 112, 1, { pc: 1 });
    T(g, 118, 244, 'গাছ ১', { fs: 10, a: 'middle', c: C.mu }); T(g, 270, 244, 'গাছ ২ (একই প্রজাতি)', { fs: 10, a: 'middle', c: C.mu });
    const P = PLpath[ty]; E('path', { d: `M${P[0][0]} ${P[0][1]}Q${P[1][0]} ${P[1][1]} ${P[2][0]} ${P[2][1]}`, stroke: BK.ramp(6).c, 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '4 3' }, g);
    const lbl = { auto: 'একই ফুলে', geito: 'একই গাছের ভিন্ন ফুলে', xeno: 'ভিন্ন গাছের ফুলে' }[ty];
    T(g, 180, 20, `${ty === 'xeno' ? 'পর-পরাগায়ন' : 'স্ব-পরাগায়ন'} — ${lbl}`, { fs: 11.5, a: 'middle', w: 650, c: ty === 'xeno' ? BK.ramp(0).ink : BK.ramp(6).ink });
  },
  anim(g, C, ty, t) {
    if (!t) return; const P = PLpath[ty], Ra = BK.ramp(6);
    for (let i = 0; i < 4; i++) { const u = (t * .35 + i / 4) % 1, [x, y] = qb(P[0], P[1], P[2], u); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 3, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .6 }, g); }
    if (ty !== 'auto') { const u = (t * .35) % 1, [x, y] = qb(P[0], P[1], P[2], u); E('path', { d: `M${x - 7} ${y - 5}q4 -6 7 0q3 -6 7 0`, stroke: BK.ramp(9).dk, 'stroke-width': 1.2, fill: 'none' }, g); E('ellipse', { cx: x, cy: y, rx: 4, ry: 2.6, fill: BK.ramp(6).dk }, g); }
  }
}));

/* ═════════ ২. পরাগায়নের মাধ্যম ═════════ */
const AGt = {
  anemo: ['বায়ু', 'বায়ুপরাগী ফুল (অ্যানিমোফিলি)', 'ধান, গম, ভুট্টা, আখ, ঘাস, তাল-খেজুর। ফুল ছোট, বর্ণহীন, গন্ধ ও মধু নেই; পরাগরেণু অসংখ্য, হালকা, শুষ্ক, মসৃণ (কখনো বায়ুথলিযুক্ত — পাইন); পুংদণ্ড লম্বা, পরাগধানী দোদুল্যমান (সর্বমুখ); গর্ভমুণ্ড বড়, পালকের মতো বা শাখান্বিত — বাতাস থেকে পরাগরেণু ছেঁকে নেয়।'],
  ento: ['পতঙ্গ', 'পতঙ্গপরাগী ফুল (এন্টোমোফিলি)', 'সরিষা, সূর্যমুখী, কুমড়া, আম, জবা। ফুল বড়, উজ্জ্বল রঙিন, সুগন্ধি, মধুগ্রন্থিযুক্ত (মধুকোষ); ছোট ফুল একত্রে পুষ্পমঞ্জরিতে (সূর্যমুখী); পরাগরেণু আঠালো, অমসৃণ বা কাঁটাযুক্ত — পতঙ্গের গায়ে লেগে যায়; গর্ভমুণ্ড আঠালো। মৌমাছি অতিবেগুনি রং দেখে — অনেক ফুলে "মধু-নির্দেশক রেখা" থাকে।'],
  hydro: ['পানি', 'পানিপরাগী ফুল (হাইড্রোফিলি)', 'পাতাশেওলা (Vallisneria), ঝাঁঝি (Hydrilla), Zostera। Vallisneria তে পুং ফুল ভেঙে পানির ওপর ভাসে; স্ত্রী ফুল লম্বা প্যাঁচানো বৃন্তে পানির উপরিতলে ওঠে — ভাসমান পুং ফুল স্ত্রী ফুলের কাছে এসে পরাগায়ন ঘটায়, তারপর বৃন্ত প্যাঁচিয়ে স্ত্রী ফুল পানির নিচে নামে। ফুল ছোট, পরাগরেণু পানিতে নষ্ট হয় না (মিউসিলেজ আবরণ)।'],
  ornitho: ['পাখি', 'পাখিপরাগী ফুল (অর্নিথোফিলি)', 'শিমুল, মাদার (Erythrina), পলাশ, কলা। ফুল বড়, শক্ত, উজ্জ্বল লাল-কমলা (পাখি লাল দেখে, গন্ধ কম বোঝে) — তাই প্রায় গন্ধহীন; প্রচুর পাতলা মধু; মধুপায়ী পাখি (মৌটুসি, বুলবুলি, দোয়েল) মধু খেতে গিয়ে মাথা-ঠোঁটে পরাগরেণু নেয়।'],
  chiro: ['বাদুড়', 'বাদুড়পরাগী ফুল (কাইরোপটেরোফিলি)', 'Kigelia (সসেজ গাছ), বাওবাব (Adansonia), বন্য কলা। ফুল রাতে ফোটে, বড় ও শক্ত, ম্লান সাদা বা ক্রিম রং, তীব্র গন্ধ (মৃদু পচা ফলের মতো), প্রচুর মধু ও পরাগরেণু; গাছের বাইরের দিকে লম্বা বৃন্তে ঝোলে — বাদুড় সহজে পৌঁছায়।']
};
V.pollinators = Object.assign({}, B.seg({
  id: 'pa', t: 'পর-পরাগায়নের মাধ্যম ও ফুলের অভিযোজন', H: 250, def: 'anemo',
  cap: 'পর-পরাগায়নে পরাগরেণু বহন করে কোনো মাধ্যম — অজীবজ (বায়ু, পানি) বা জীবজ (পতঙ্গ, পাখি, বাদুড়, শামুক ইত্যাদি)। প্রতিটি মাধ্যমের জন্য ফুলের গঠনে বিশেষ অভিযোজন দেখা যায়। ধরন বদলাও।',
  types: Object.fromEntries(Object.entries(AGt).map(([k, v]) => [k, v])),
  art(g, C, ty) {
    const Rg = BK.ramp(10), Ra = BK.ramp(6);
    if (ty === 'anemo') {
      E('rect', { x: 0, y: 228, width: 360, height: 22, fill: FK.alpha(BK.ramp(11).c, .35) }, g);
      [[90, 1], [250, 0]].forEach(([x, male]) => { E('path', { d: `M${x} 228V${male ? 40 : 80}`, stroke: Rg.dk, 'stroke-width': 4 }, g); for (let i = 0; i < 3; i++) E('path', { d: `M${x} ${210 - i * 40}q${i % 2 ? 40 : -40} -20 ${i % 2 ? 56 : -56} -6`, stroke: Rg.c, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, g); });
      for (let i = 0; i < 6; i++) { const y = 44 + i * 9; E('path', { d: `M90 ${y}l${i % 2 ? 14 : -14} 6`, stroke: Ra.dk, 'stroke-width': 1.2 }, g); E('ellipse', { cx: 90 + (i % 2 ? 16 : -16), cy: y + 9, rx: 3, ry: 6, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .6 }, g); }
      T(g, 90, 30, 'পুং মঞ্জরি — দোদুল্যমান পরাগধানী', { fs: 9.5, a: 'middle', c: Ra.ink });
      for (let i = 0; i < 9; i++) E('path', { d: `M250 ${140 + i * 4}q${20 + i} -${4 + i} ${34 + i * 1.5} ${-2 + i}`, stroke: BK.ramp(3).c, 'stroke-width': 1.2, fill: 'none' }, g);
      E('rect', { x: 242, y: 136, width: 16, height: 46, rx: 6, fill: Rg.lt, stroke: Rg.dk }, g); T(g, 300, 196, 'পালকের মতো গর্ভমুণ্ড (ভুট্টার "চুল")', { fs: 9.5, a: 'middle', c: BK.ramp(3).ink });
    } else if (ty === 'ento') {
      const cx = 140, cy = 140; for (let i = 0; i < 12; i++) { const a = i / 12 * PI * 2; E('ellipse', { cx: cx + 44 * Math.cos(a), cy: cy + 44 * Math.sin(a), rx: 26, ry: 11, transform: `rotate(${a * 180 / PI} ${cx + 44 * Math.cos(a)} ${cy + 44 * Math.sin(a)})`, fill: BK.ramp(6).lt, stroke: BK.ramp(6).dk }, g); }
      E('circle', { cx, cy, r: 30, fill: FK.alpha(BK.ramp(2).dk, .6), stroke: BK.ramp(2).dk }, g); for (let i = 0; i < 30; i++) { const a = i * 2.4, r = 3 + Math.sqrt(i) * 4.6; E('circle', { cx: cx + r * Math.cos(a), cy: cy + r * Math.sin(a), r: 1.8, fill: BK.ramp(6).c }, g); }
      T(g, 140, 226, 'উজ্জ্বল রং, মধু, সুগন্ধ, আঠালো পরাগরেণু', { fs: 10, a: 'middle', c: C.mu });
    } else if (ty === 'hydro') {
      const Rw = BK.ramp(5); E('rect', { x: 0, y: 92, width: 360, height: 158, fill: FK.alpha(Rw.c, .18) }, g); E('path', { d: 'M0 92q20 -6 40 0t40 0t40 0t40 0t40 0t40 0t40 0t40 0t40 0', stroke: Rw.dk, fill: 'none', 'stroke-width': 1.4 }, g);
      E('rect', { x: 0, y: 236, width: 360, height: 14, fill: FK.alpha(BK.ramp(11).c, .5) }, g);
      E('path', { d: 'M230 236c-14 -14 14 -28 0 -42s14 -28 0 -42s14 -28 0 -42s6 -14 2 -18', stroke: Rg.dk, 'stroke-width': 2, fill: 'none' }, g);
      E('path', { d: 'M226 92l6 -8l6 8Z', fill: BK.ramp(3).lt, stroke: BK.ramp(3).dk }, g); T(g, 232, 76, 'স্ত্রী ফুল', { fs: 10, a: 'middle', c: BK.ramp(3).ink });
      [40, 90, 130].forEach(x => { for (let i = 0; i < 4; i++) E('path', { d: `M${x} 236q${(i - 1.5) * 10} -30 ${(i - 1.5) * 14} -60`, stroke: Rg.c, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, g); });
      T(g, 100, 150, 'পুং ফুল ভেঙে ভেসে ওঠে', { fs: 10, a: 'middle', c: Ra.ink }); T(g, 180, 30, 'পাতাশেওলা (Vallisneria)', { fs: 11, a: 'middle', w: 600, c: C.fg });
    } else if (ty === 'ornitho') {
      E('path', { d: 'M60 240Q120 150 150 110', stroke: BK.ramp(11).dk, 'stroke-width': 6, fill: 'none' }, g);
      for (let i = 0; i < 5; i++) { const a = -PI / 2 + (i - 2) * .5; E('path', { d: `M150 110q${50 * Math.cos(a) - 10} ${50 * Math.sin(a)} ${66 * Math.cos(a)} ${66 * Math.sin(a)}q-8 10 ${-66 * Math.cos(a)} ${-66 * Math.sin(a)}Z`, fill: BK.ramp(4).c, stroke: BK.ramp(4).dk }, g); }
      for (let i = 0; i < 5; i++) E('path', { d: `M150 110L${140 + i * 6} 50`, stroke: Ra.dk, 'stroke-width': 1.2 }, g);
      T(g, 90, 226, 'শিমুল — বড়, লাল, প্রচুর মধু, গন্ধহীন', { fs: 10, a: 'middle', c: C.mu });
    } else {
      E('path', { d: 'M60 0V60', stroke: BK.ramp(11).dk, 'stroke-width': 5 }, g); E('path', { d: 'M60 60Q90 90 120 120', stroke: BK.ramp(11).dk, 'stroke-width': 2.4, fill: 'none' }, g);
      E('path', { d: 'M104 120C100 150 140 170 150 140C160 120 130 106 104 120Z', fill: '#f3ead7', stroke: BK.ramp(9).dk }, g);
      E('circle', { cx: 300, cy: 40, r: 16, fill: '#e8e3c0' }, g); E('circle', { cx: 306, cy: 36, r: 14, fill: C.sf }, g); T(g, 300, 72, 'রাতে ফোটে', { fs: 10, a: 'middle', c: C.mu });
      T(g, 130, 226, 'ঝুলন্ত, ম্লান সাদা, তীব্র গন্ধ', { fs: 10, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return; const Ra = BK.ramp(6);
    if (ty === 'anemo') { for (let i = 0; i < 10; i++) { const u = (t * .25 + i / 10) % 1; E('circle', { cx: 100 + u * 150, cy: 70 + Math.sin(u * 7 + i) * 14 + u * 80, r: 2.2, fill: Ra.c, opacity: 1 - u * .6 }, g); } for (let i = 0; i < 3; i++) { const u = (t * .4 + i / 3) % 1; E('path', { d: `M${10 + u * 300} ${110 + i * 16}h30`, stroke: C.mu, 'stroke-width': 1.4, opacity: .5 * (1 - u) }, g); } return; }
    if (ty === 'ento') { const a = t * .9, x = 140 + 70 * Math.cos(a), y = 140 + 50 * Math.sin(a) - 6; [-1, 1].forEach(s => E('ellipse', { cx: x + s * 6, cy: y - 7, rx: 7, ry: 4 + 2 * Math.abs(Math.sin(t * 30)), fill: 'rgba(200,220,255,.7)', stroke: C.mu, 'stroke-width': .6 }, g)); E('ellipse', { cx: x, cy: y, rx: 10, ry: 6, fill: BK.ramp(6).c, stroke: '#222', 'stroke-width': 1 }, g); for (let i = -1; i <= 1; i++) E('path', { d: `M${x + i * 4} ${y - 5}v10`, stroke: '#222', 'stroke-width': 1.6 }, g); E('circle', { cx: x + 4, cy: y + 7, r: 2, fill: Ra.dk }, g); T(g, 300, 60, 'মৌমাছির পায়ে', { fs: 9.5, a: 'middle', c: Ra.ink }); T(g, 300, 72, 'পরাগরেণু', { fs: 9.5, a: 'middle', c: Ra.ink }); return; }
    if (ty === 'hydro') { for (let i = 0; i < 4; i++) { const u = (t * .12 + i / 4) % 1, x = 60 + u * 170, y = 90 + Math.sin(t * 2 + i) * 2; E('path', { d: `M${x - 5} ${y}l5 -6l5 6Z`, fill: Ra.lt, stroke: Ra.dk }, g); } return; }
    if (ty === 'ornitho') { const u = (Math.sin(t * .8) + 1) / 2, x = 250 - u * 70, y = 70 + u * 10; E('ellipse', { cx: x, cy: y, rx: 16, ry: 9, fill: BK.ramp(10).c, stroke: BK.ramp(10).dk }, g); E('path', { d: `M${x - 16} ${y - 2}l-18 2l18 2Z`, fill: '#333' }, g); E('path', { d: `M${x} ${y - 6}q10 ${-14 * Math.abs(Math.sin(t * 20))} 18 -4`, stroke: BK.ramp(10).dk, 'stroke-width': 3, fill: 'none' }, g); E('circle', { cx: x - 8, cy: y - 3, r: 1.6, fill: '#000' }, g); return; }
    const u = (Math.sin(t * .7) + 1) / 2, x = 300 - u * 140, y = 120 + Math.sin(t * 3) * 8, f = Math.sin(t * 14) * 10; E('path', { d: `M${x} ${y}q-18 ${-10 - f} -36 ${-4 - f}q8 8 4 14q-6 -6 -14 0q20 0 46 -10Zm0 0q18 ${-10 - f} 36 ${-4 - f}q-8 8 -4 14q6 -6 14 0q-20 0 -46 -10Z`, fill: '#3b3340' }, g); E('circle', { cx: x, cy: y - 2, r: 5, fill: '#3b3340' }, g);
  }
}));

/* ═════════ ৩. পর-পরাগায়নের কৌশল ═════════ */
V.outcross = Object.assign({}, B.seg({
  id: 'oc', t: 'পর-পরাগায়ন নিশ্চিত করার কৌশল', H: 250, def: 'uni',
  cap: 'অনেক উদ্ভিদ স্ব-পরাগায়ন এড়িয়ে পর-পরাগায়ন নিশ্চিত করতে বিশেষ কৌশল নিয়েছে — এতে জিনগত বৈচিত্র্য বাড়ে। ধরন বদলাও।',
  types: {
    uni: ['একলিঙ্গতা', 'একলিঙ্গতা (ডাইক্লিনি)', 'ফুল একলিঙ্গ। সহবাসী (মনোসিয়াস) — একই গাছে পুং ও স্ত্রী ফুল: ভুট্টা, লাউ, কুমড়া (গেইটোনোগ্যামি সম্ভব); ভিন্নবাসী (ডায়োসিয়াস) — আলাদা গাছে: পেঁপে, তাল, খেজুর, পটল (স্ব-পরাগায়ন অসম্ভব)।'],
    dicho: ['ভিন্নকালপক্বতা', 'ভিন্নকালপক্বতা (ডাইকোগ্যামি)', 'দ্বিলিঙ্গ ফুলে পরাগধানী ও গর্ভমুণ্ড ভিন্ন সময়ে পরিণত হয়। পুংপূর্বপক্বতা (প্রোটান্ড্রি) — পরাগধানী আগে: সূর্যমুখী, জবা, Salvia; স্ত্রীপূর্বপক্বতা (প্রোটোগাইনি) — গর্ভমুণ্ড আগে: আতা (Annona), Magnolia, Aristolochia।'],
    herko: ['হারকোগ্যামি', 'হারকোগ্যামি (গঠনগত বাধা)', 'দ্বিলিঙ্গ ফুলে পরাগধানী ও গর্ভমুণ্ডের মাঝে শারীরিক বাধা — আকন্দ (Calotropis) ও অর্কিডে পরাগরেণু পোলিনিয়াম নামের পিণ্ডে আটকে থাকে, কেবল পতঙ্গ তুলে নিতে পারে।'],
    het: ['হেটারোস্টাইলি', 'হেটারোস্টাইলি (ভিন্নদৈর্ঘ্য গর্ভদণ্ড)', 'একই প্রজাতির কিছু গাছের ফুলে গর্ভদণ্ড লম্বা ও পুংকেশর খাটো (পিন), অন্যগুলোতে উল্টো (থ্রাম) — পতঙ্গের দেহের একই উচ্চতায় পরাগধানী ও বিপরীত ধরনের গর্ভমুণ্ড থাকে, ফলে পিন ↔ থ্রাম পরাগায়ন হয়। Primula, Oxalis, তিসি (Linum)।'],
    si: ['স্ব-অসঙ্গতি', 'স্ব-অসঙ্গতি (সেলফ-ইনকম্প্যাটিবিলিটি)', 'একই গাছের পরাগরেণু গর্ভমুণ্ডে পড়লেও অঙ্কুরিত হয় না বা পরাগনালি গর্ভদণ্ডে থেমে যায় — S-জিনের একই অ্যালিল থাকলে গর্ভমুণ্ড/গর্ভদণ্ড তাকে "চিনে" প্রত্যাখ্যান করে। তামাক, মুলা, বাঁধাকপি, চা, আপেল।']
  },
  art(g, C, ty) {
    const Ra = BK.ramp(6), Rc = BK.ramp(3), Rg = BK.ramp(10);
    if (ty === 'uni') {
      E('rect', { x: 0, y: 226, width: 360, height: 24, fill: FK.alpha(BK.ramp(11).c, .35) }, g);
      plant(g, 90, 226, 80, [[-26, 100], [26, 150]]); flower(g, 64, 104, 1, { fem: false }); flower(g, 116, 154, 1, { male: false, pc: 6 });
      plant(g, 230, 226, 90, [[0, 104]]); plant(g, 310, 226, 90, [[0, 104]]); flower(g, 230, 108, 1, { fem: false, pc: 1 }); flower(g, 310, 108, 1, { male: false, pc: 1 });
      T(g, 90, 244, 'সহবাসী (লাউ)', { fs: 10, a: 'middle', c: C.mu }); T(g, 270, 244, 'ভিন্নবাসী (পেঁপে)', { fs: 10, a: 'middle', c: C.mu });
      T(g, 230, 66, 'পুং গাছ', { fs: 10, a: 'middle', c: Ra.ink }); T(g, 310, 66, 'স্ত্রী গাছ', { fs: 10, a: 'middle', c: Rc.ink });
    } else if (ty === 'dicho') {
      const X = d => 70 + d * 26; [0, 2, 4, 6, 8, 10].forEach(d => T(g, X(d), 40, `দিন ${d}`, { fs: 9, a: 'middle', c: C.mu }));
      [['পুংপূর্বপক্বতা', 70, [0, 4], [6, 10]], ['স্ত্রীপূর্বপক্বতা', 160, [6, 10], [0, 4]]].forEach(([n, y, an, st]) => {
        T(g, 20, y - 18, n, { fs: 11, w: 650, c: C.fg });
        E('rect', { x: X(an[0]), y: y - 8, width: X(an[1]) - X(an[0]), height: 14, rx: 7, fill: Ra.c }, g); T(g, X(an[1]) + 4, y + 3, 'পরাগধানী পক্ব', { fs: 9.5, c: Ra.ink });
        E('rect', { x: X(st[0]), y: y + 12, width: X(st[1]) - X(st[0]), height: 14, rx: 7, fill: Rc.c }, g); T(g, st[0] ? X(st[0]) - 4 : X(st[1]) + 4, y + 23, 'গর্ভমুণ্ড গ্রহণক্ষম', { fs: 9.5, a: st[0] ? 'end' : 'start', c: Rc.ink });
      });
      T(g, 180, 232, 'দুটি একসাথে প্রস্তুত থাকে না — নিজের পরাগে নিষেক হয় না', { fs: 10, a: 'middle', c: C.mu });
    } else if (ty === 'herko') {
      E('path', { d: 'M180 230V150', stroke: Rg.dk, 'stroke-width': 3 }, g);
      for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * PI * 2; E('ellipse', { cx: 180 + 46 * Math.cos(a), cy: 110 + 46 * Math.sin(a), rx: 26, ry: 14, transform: `rotate(${a * 180 / PI} ${180 + 46 * Math.cos(a)} ${110 + 46 * Math.sin(a)})`, fill: BK.ramp(3).lt, stroke: BK.ramp(3).dk }, g); }
      E('path', { d: 'M156 96L180 76L204 96L204 128L180 146L156 128Z', fill: '#fff', stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g); T(g, 180, 116, 'গর্ভমুণ্ড-চাকতি', { fs: 9, a: 'middle', c: Rc.ink });
      [[150, 90], [210, 90]].forEach(([x, y], i) => { E('path', { d: `M${180} 80Q${x} ${y - 20} ${x} ${y}`, stroke: Ra.dk, fill: 'none' }, g); E('ellipse', { cx: x, cy: y + 12, rx: 6, ry: 12, fill: Ra.c, stroke: Ra.dk }, g); });
      T(g, 180, 200, 'আকন্দ — পোলিনিয়াম (পরাগপিণ্ড)', { fs: 10.5, a: 'middle', w: 600, c: C.fg }); T(g, 180, 216, 'পতঙ্গের পায়ে আটকে উঠে যায়', { fs: 9.5, a: 'middle', c: C.mu });
    } else if (ty === 'het') {
      const fl = (x, pin) => { const sty = pin ? 120 : 60, an = pin ? 70 : 128; E('path', { d: `M${x - 20} 220Q${x - 24} 120 ${x - 14} 70H${x + 14}Q${x + 24} 120 ${x + 20} 220Z`, fill: FK.alpha(BK.ramp(8).c, .25), stroke: BK.ramp(8).dk }, g); E('path', { d: `M${x} 214V${214 - sty}`, stroke: Rc.dk, 'stroke-width': 2.6 }, g); E('circle', { cx: x, cy: 214 - sty, r: 6, fill: Rc.lt, stroke: Rc.dk }, g); [-1, 1].forEach(s => { E('path', { d: `M${x + s * 10} 214V${214 - an}`, stroke: Ra.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: x + s * 10, cy: 214 - an - 6, rx: 4, ry: 7, fill: Ra.c, stroke: Ra.dk }, g); }); T(g, x, 240, pin ? 'পিন (লম্বা গর্ভদণ্ড)' : 'থ্রাম (খাটো গর্ভদণ্ড)', { fs: 10, a: 'middle', w: 600, c: C.fg }); };
      fl(110, true); fl(250, false);
      E('path', { d: 'M126 140Q180 120 236 140', stroke: C.mu, fill: 'none', 'stroke-dasharray': '3 3' }, g); E('path', { d: 'M126 86Q180 70 236 86', stroke: C.mu, fill: 'none', 'stroke-dasharray': '3 3' }, g);
    } else {
      E('path', { d: 'M150 40Q150 60 168 70V230H192V70Q210 60 210 40Z', fill: FK.alpha(Rc.c, .2), stroke: Rc.dk }, g); T(g, 180, 30, 'গর্ভমুণ্ড ও গর্ভদণ্ড (S1 S2)', { fs: 10, a: 'middle', w: 600, c: Rc.ink });
      [[160, 'S1', 4], [200, 'S3', 0]].forEach(([x, s, c]) => { E('circle', { cx: x, cy: 44, r: 8, fill: Ra.lt, stroke: Ra.dk }, g); T(g, x, 47, s, { fs: 8, a: 'middle', w: 650, c: Ra.ink }); });
      T(g, 90, 80, 'নিজের পরাগ (S1)', { fs: 10, a: 'middle', c: BK.ramp(4).ink }); T(g, 280, 80, 'অন্য গাছের পরাগ (S3)', { fs: 10, a: 'middle', c: BK.ramp(0).ink });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'si') { const u = (t * .2) % 1; E('path', { d: `M160 52V${52 + Math.min(u, .25) * 160}`, stroke: BK.ramp(4).c, 'stroke-width': 3 }, g); if (u > .25) T(g, 120, 110, 'নালি থেমে গেল', { fs: 10, a: 'middle', w: 600, c: BK.ramp(4).ink }); E('path', { d: `M200 52Q200 120 186 ${52 + u * 176}`, stroke: BK.ramp(0).c, 'stroke-width': 3, fill: 'none' }, g); return; }
    if (ty === 'het') { const u = (t * .3) % 1, x = 110 + u * 140, y = 140 - Math.sin(u * PI) * 20; E('ellipse', { cx: x, cy: y, rx: 9, ry: 5, fill: BK.ramp(6).c, stroke: '#222' }, g); return; }
    if (ty === 'dicho') { const X = d => 70 + d * 26, d = (t * 1.2) % 11; E('path', { d: `M${X(d)} 48V196`, stroke: C.fg, 'stroke-width': 1.4, 'stroke-dasharray': '3 2' }, g); return; }
    if (ty === 'herko') { const u = (t * .25) % 1, x = 150 - u * 110, y = 102 - u * 40; E('ellipse', { cx: x, cy: y, rx: 5, ry: 10, fill: BK.ramp(6).c, opacity: 1 - u }, g); return; }
    const u = (t * .3) % 1, [x, y] = qb([230, 84], [270, 30], [310, 80], u); E('circle', { cx: x, cy: y, r: 3, fill: BK.ramp(6).c }, g);
  }
}));

/* ═════════ ৪. পরাগনালির প্রবেশপথ ═════════ */
const PTp = { poro: [[180, 34], [184, 120], [204, 222]], chal: [[180, 34], [150, 160], [210, 120]], meso: [[180, 34], [176, 140], [244, 170]] };
V.pollenTube = Object.assign({}, B.seg({
  id: 'ptb', t: 'পরাগনালির অঙ্কুরোদগম ও ডিম্বকে প্রবেশ', H: 260, def: 'poro',
  cap: 'গর্ভমুণ্ডে পরাগরেণু অঙ্কুরিত হয়ে পরাগনালি তৈরি করে, যা গর্ভদণ্ডের ভেতর দিয়ে নেমে ডিম্বকে ঢোকে — আবিষ্কার: অ্যামিসি (1824)। সহকারী কোষের রাসায়নিক সংকেত (কেমোট্রপিজম) নালিকে পথ দেখায়। ডিম্বকের তিন পথে প্রবেশ সম্ভব। চালাও চাপলে নালি বাড়বে।',
  types: {
    poro: ['পোরোগ্যামি', 'পোরোগ্যামি — ডিম্বকরন্ধ্র দিয়ে', 'সবচেয়ে সাধারণ — অধিকাংশ আবৃতবীজী উদ্ভিদে।'],
    chal: ['চ্যালাজোগ্যামি', 'চ্যালাজোগ্যামি — চ্যালাজা দিয়ে', 'পরাগনালি চ্যালাজা প্রান্ত দিয়ে ঢোকে — ঝাউ (Casuarina) এ প্রথম দেখান ট্রয়েব (1891)।'],
    meso: ['মেসোগ্যামি', 'মেসোগ্যামি — আবরণী ভেদ করে', 'পরাগনালি ডিম্বকের পাশের আবরণী বা ফানিকুলাস ভেদ করে ঢোকে — কুমড়া (Cucurbita), Pistacia।']
  },
  art(g, C, ty) {
    const Rc = BK.ramp(3), Rw = BK.ramp(11), Ra = BK.ramp(6);
    E('path', { d: 'M150 24Q180 10 210 24Q200 34 192 40V112Q290 120 290 192Q290 252 180 252Q70 252 70 192Q70 120 168 112V40Q160 34 150 24Z', fill: FK.alpha(Rc.c, .14), stroke: Rc.dk, 'stroke-width': 1.3 }, g);
    E('circle', { cx: 180, cy: 22, r: 8, fill: Ra.lt, stroke: Ra.dk }, g); T(g, 228, 22, 'পরাগরেণু', { fs: 9.5, c: Ra.ink }); T(g, 108, 70, 'গর্ভদণ্ড', { fs: 9.5, a: 'middle', c: Rc.ink }); T(g, 300, 120, 'গর্ভাশয়', { fs: 9.5, a: 'end', c: Rc.ink });
    const cx = 204, cy = 178, flip = ty === 'chal';
    E('path', { d: `M${cx - 60} 250Q${cx - 66} ${cy} ${cx - 40} ${cy}`, stroke: Rw.dk, 'stroke-width': 7, fill: 'none' }, g);
    E('ellipse', { cx, cy, rx: 44, ry: 34, fill: FK.alpha(Rw.c, .35), stroke: Rw.dk }, g); E('ellipse', { cx, cy, rx: 32, ry: 24, fill: FK.alpha(BK.ramp(10).c, .2), stroke: BK.ramp(10).dk }, g);
    E('ellipse', { cx, cy, rx: 18, ry: 10, fill: FK.alpha(BK.ramp(2).c, .3), stroke: BK.ramp(2).dk }, g);
    const mx = ty === 'chal' ? cx + 44 : cx, my = ty === 'chal' ? cy : cy + 34; void flip;
    E('path', { d: `M${cx} ${cy + 26}V${cy + 38}`, stroke: C.fg, 'stroke-width': 1.4, 'stroke-dasharray': '2 2' }, g); T(g, cx + 6, cy + 50, 'ডিম্বকরন্ধ্র', { fs: 9, c: C.mu });
    T(g, cx + 50, cy - 30, 'চ্যালাজা', { fs: 9, c: C.mu }); T(g, cx - 92, 240, 'ফানিকুলাস', { fs: 9, c: C.mu }); void mx; void my;
  },
  anim(g, C, ty, t) {
    const P = { poro: [[180, 30], [190, 130], [130, 236], [204, 214]], chal: [[180, 30], [186, 110], [250, 140], [222, 178]], meso: [[180, 30], [186, 120], [150, 186], [174, 192]] }[ty];
    const u = t ? cl(((t * .22) % 1.25)) : 1, pts = []; for (let i = 0; i <= 40; i++) { const q = i / 40 * u, r = 1 - q; pts.push([r * r * r * P[0][0] + 3 * r * r * q * P[1][0] + 3 * r * q * q * P[2][0] + q * q * q * P[3][0], r * r * r * P[0][1] + 3 * r * r * q * P[1][1] + 3 * r * q * q * P[2][1] + q * q * q * P[3][1]]); }
    B.poly(g, pts, { stroke: BK.ramp(6).dk, 'stroke-width': 4.5, 'stroke-linecap': 'round', opacity: .5 }); B.poly(g, pts, { stroke: BK.ramp(6).lt, 'stroke-width': 2.4, 'stroke-linecap': 'round' });
    const tip = pts[pts.length - 1]; E('circle', { cx: tip[0], cy: tip[1], r: 3.4, fill: BK.ramp(3).c }, g);
    if (u >= 1) T(g, 180, 248, 'নালি ভ্রূণথলিতে পৌঁছেছে', { fs: 10.5, a: 'middle', w: 650, c: BK.ramp(0).ink });
  }
}));

/* ═════════ ৫. দ্বিনিষেক ═════════ */
V.dblFert = Object.assign({ t: 'দ্বিনিষেক (ডাবল ফার্টিলাইজেশন)', k: ['anim', 'steps'], cap: 'আবৃতবীজী উদ্ভিদের অনন্য বৈশিষ্ট্য — একটি পুংগ্যামেট ডিম্বাণুর সাথে (সিনগ্যামি → জাইগোট 2n), অন্যটি দুটি পোলার নিউক্লিয়াস বা সেকেন্ডারি নিউক্লিয়াসের সাথে (ত্রি-মিলন → প্রাথমিক সস্য নিউক্লিয়াস 3n) মিলিত হয়। আবিষ্কার: নাওয়াসচিন (1898, Lilium ও Fritillaria)।' }, BK.steps({
  W: 360, H: 240, label: 'দ্বিনিষেক', dur: 3,
  stages: [
    { t: 'পরাগনালি ভ্রূণথলিতে', en: 'Pollen tube enters a synergid', d: 'পরাগনালি ডিম্বকরন্ধ্র দিয়ে ঢুকে ফিলিফর্ম যন্ত্র ভেদ করে একটি সহকারী কোষে প্রবেশ করে।' },
    { t: 'নালি ফেটে দুই পুংগ্যামেট মুক্ত', en: 'Release of male gametes', d: 'নালির অগ্রভাগ ফেটে দুটি পুংগ্যামেট ও নালি নিউক্লিয়াস সহকারী কোষে মুক্ত হয়; সহকারী কোষটি নষ্ট হতে থাকে।' },
    { t: 'সিনগ্যামি → জাইগোট (2n)', en: 'Syngamy', d: 'প্রথম পুংগ্যামেট (n) ডিম্বাণুর (n) সাথে মিলে জাইগোট (2n) তৈরি করে — এটিই প্রকৃত নিষেক; জাইগোট থেকে ভ্রূণ।' },
    { t: 'ত্রি-মিলন → সস্য নিউক্লিয়াস (3n)', en: 'Triple fusion', d: 'দ্বিতীয় পুংগ্যামেট (n) দুটি পোলার নিউক্লিয়াসের (n + n) সাথে মিলে প্রাথমিক সস্য নিউক্লিয়াস (PEN, 3n) — তিনটি নিউক্লিয়াসের মিলন, তাই ত্রি-মিলন; এ থেকে সস্য (এন্ডোস্পার্ম)।' },
    { t: 'ফল: জাইগোট + সস্য নিউক্লিয়াস', en: 'Fertilized embryo sac', d: 'দুটি মিলন — সিনগ্যামি + ত্রি-মিলন = দ্বিনিষেক। সহকারী ও প্রতিপাদ কোষ নষ্ট হয়; জাইগোট ভ্রূণে, PEN সস্যে, ডিম্বক বীজে পরিণত হয়।' }
  ],
  draw(g, C, s, u) {
    const Rc = BK.ramp(3), Rn_ = BK.ramp(2), R7 = BK.ramp(7), R9 = BK.ramp(9), R2 = BK.ramp(10), Ra = BK.ramp(6), k = u;
    E('path', { d: 'M40 120C40 60 110 40 200 44C290 48 330 80 330 120C330 162 290 196 200 200C110 204 40 182 40 120Z', fill: FK.alpha(Rn_.c, .1), stroke: Rn_.dk, 'stroke-width': 1.3 }, g);
    const tubeL = s === 0 ? k : 1; E('path', { d: `M0 120H${10 + 76 * tubeL}`, stroke: BK.ramp(11).dk, 'stroke-width': 9, 'stroke-linecap': 'round', opacity: .35 }, g); E('path', { d: `M0 120H${10 + 76 * tubeL}`, stroke: BK.ramp(11).lt, 'stroke-width': 6, 'stroke-linecap': 'round' }, g);
    const synOp = s >= 1 ? 1 - .6 * (s === 1 ? k : 1) : 1;
    [[88, 96], [88, 146]].forEach(([x, y], i) => { E('ellipse', { cx: x, cy: y, rx: 22, ry: 15, fill: FK.alpha(Rn_.c, .3), stroke: Rn_.dk, opacity: i === 0 ? synOp : (s === 4 ? .4 : 1) }, g); nuc(g, x - 2, y, 4, Rn_, { op: i === 0 ? synOp : 1 }); });
    const egg = [116, 121], pol = [[196, 116], [214, 128]], ant = [[300, 92], [312, 120], [300, 148]];
    ant.forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 13, fill: FK.alpha(R9.c, .25), stroke: R9.dk, opacity: s === 4 ? .35 : 1 }, g); nuc(g, x, y, 4, R9, { op: s === 4 ? .35 : 1 }); });
    let g1, g2;
    if (s === 0) { g1 = [10 + 70 * k, 116]; g2 = [4 + 70 * k, 124]; }
    else if (s === 1) { g1 = [80 + 10 * k, 92 + 8 * k]; g2 = [80 + 10 * k, 104 + 6 * k]; }
    else if (s === 2) { g1 = [90 + (egg[0] - 90) * k, 100 + (egg[1] - 100) * k]; g2 = [90, 110]; }
    else if (s === 3) { g1 = null; g2 = [90 + (205 - 90) * k, 110 + (122 - 110) * k]; }
    else { g1 = null; g2 = null; }
    const zyg = s >= 3 || (s === 2 && k > .85), pen = s === 4 || (s === 3 && k > .85);
    E('ellipse', { cx: egg[0], cy: egg[1], rx: zyg ? 18 : 15, ry: zyg ? 14 : 12, fill: zyg ? FK.alpha(R2.c, .55) : FK.alpha(Rc.c, .45), stroke: zyg ? R2.dk : Rc.dk }, g); nuc(g, egg[0], egg[1], zyg ? 7 : 6, zyg ? R2 : Rc);
    if (pen) nuc(g, 205, 122, 11, R7, { fill: R7.dk }); else pol.forEach(([x, y]) => nuc(g, x, y, 8, R7));
    [g1, g2].forEach(p => { if (p) { E('ellipse', { cx: p[0], cy: p[1], rx: 6, ry: 4, fill: Ra.c, stroke: Ra.dk }, g); } });
    if (zyg) ploid(g, egg[0], 172, 'জাইগোট 2n', R2, 72); if (pen) ploid(g, 205, 152, 'PEN 3n', R7, 60);
    if (s <= 1) { T(g, 116, 186, 'ডিম্বাণু (n)', { fs: 10, a: 'middle', c: Rc.ink }); T(g, 205, 160, 'পোলার নিউক্লিয়াস (n+n)', { fs: 10, a: 'middle', c: R7.ink }); }
    T(g, 180, 228, ['পরাগনালি ডিম্বকরন্ধ্র দিয়ে ঢুকছে', '২ পুংগ্যামেট (n) মুক্ত', 'n + n → 2n (সিনগ্যামি)', 'n + n + n → 3n (ত্রি-মিলন)', 'সিনগ্যামি + ত্রি-মিলন = দ্বিনিষেক'][s], { fs: 11, a: 'middle', w: 650, c: C.fg });
  }
}));

/* ═════════ ৬. নিষেকের পরিণতি ═════════ */
const PF = {
  ovary: [['গর্ভাশয়', 'ফল', 'নিষেকের উদ্দীপনায় (হরমোন, বিশেষত অক্সিন ও জিবেরেলিন) গর্ভাশয় বড় হয়ে ফলে পরিণত হয়।'], ['গর্ভাশয়ের প্রাচীর', 'ফলত্বক (পেরিকার্প)', 'ফলত্বক তিন স্তর: বহিঃত্বক (এপিকার্প), মধ্যত্বক (মেসোকার্প), অন্তঃত্বক (এন্ডোকার্প) — আমে আঁটির শক্ত আবরণ অন্তঃত্বক।'], ['ডিম্বক', 'বীজ', 'প্রতিটি নিষিক্ত ডিম্বক একটি বীজে পরিণত হয়।'], ['বৃতি', 'সাধারণত ঝরে যায়', 'কিছু ফলে থেকে যায় (স্থায়ী বৃতি) — বেগুন, টমেটো, পেয়ারা (শীর্ষে)।'], ['দলমণ্ডল', 'ঝরে যায়', 'কাজ শেষ — পরাগায়নের পর শুকিয়ে ঝরে।'], ['পুংকেশর', 'ঝরে যায়', 'পরাগরেণু ছাড়ার পর শুকিয়ে যায়।'], ['গর্ভমুণ্ড ও গর্ভদণ্ড', 'শুকিয়ে যায়', 'সাধারণত শুকিয়ে যায়; কিছু ফলে শুকনো অবশেষ লেগে থাকে (যেমন ভুট্টার মোচার "চুল")।'], ['পুষ্পাক্ষ', 'কখনো ফলের অংশ', 'অপ্রকৃত ফলে পুষ্পাক্ষ রসালো হয় — আপেল, নাশপাতি; কাজুবাদামে পুষ্পবৃন্ত।']],
  ovule: [['ডিম্বক', 'বীজ', 'নিষিক্ত ডিম্বক সমস্ত অংশসহ বীজে পরিণত হয়।'], ['বহিঃত্বক', 'বীজত্বকের টেস্টা', 'শক্ত, পুরু বাইরের বীজত্বক।'], ['অন্তঃত্বক', 'বীজত্বকের টেগমেন', 'পাতলা ভেতরের বীজত্বক (কখনো নষ্ট হয়)।'], ['ডিম্বকরন্ধ্র', 'বীজরন্ধ্র (মাইক্রোপাইল)', 'অঙ্কুরোদগমের সময় এ পথে পানি ঢোকে, ভ্রূণমূল বের হয়।'], ['ফানিকুলাস ও হাইলাম', 'বীজবৃন্ত ও বীজনাভি (হাইলাম)', 'বীজের গায়ে হাইলাম দাগ হিসেবে থাকে।'], ['নিউসেলাস', 'সাধারণত শোষিত; কখনো পেরিস্পার্ম', 'অবশিষ্ট নিউসেলাস খাদ্য হিসেবে থাকলে পেরিস্পার্ম — গোলমরিচ, শাপলা (Nymphaea)।'], ['জাইগোট (2n)', 'ভ্রূণ', 'ভ্রূণমূল, ভ্রূণমুকুল, বীজপত্র ও বীজপত্রাবকাশ।'], ['প্রাথমিক সস্য নিউক্লিয়াস (3n)', 'সস্য (এন্ডোস্পার্ম)', 'বিকাশমান ভ্রূণের খাদ্য; অসস্য বীজে (ছোলা, শিম) বীজপত্র শোষণ করে নেয়, সস্যল বীজে (ধান, ভুট্টা, রেড়ি) থেকে যায়।'], ['সহকারী ও প্রতিপাদ কোষ', 'নষ্ট হয়ে যায়', 'নিষেকের পর ভূমিকা শেষ।']]
};
const PFy = i => 46 + i * 22.5;
V.postFert = Object.assign({}, B.seg({
  id: 'pf', t: 'নিষেকের পরিণতি — ফুল থেকে ফল, ডিম্বক থেকে বীজ', H: ty => 52 + PF[ty].length * 22.5, def: 'ovary',
  cap: 'নিষেকের পর ফুলের বিভিন্ন অংশে পরিবর্তন আসে: গর্ভাশয় ফলে, ডিম্বক বীজে, জাইগোট ভ্রূণে, সস্য নিউক্লিয়াস সস্যে পরিণত হয়। কোনো সারিতে চাপ দিলে ব্যাখ্যা দেখাবে।',
  types: { ovary: ['গর্ভাশয় → ফল', 'গর্ভাশয় ও ফুলের অংশের পরিবর্তন', 'বৃতি, দলমণ্ডল, পুংকেশর সাধারণত ঝরে যায়; গর্ভাশয় বড় হয়ে ফল।'], ovule: ['ডিম্বক → বীজ', 'ডিম্বকের অংশের পরিবর্তন', 'ডিম্বকের প্রতিটি অংশ বীজের নির্দিষ্ট অংশে পরিণত হয়।'] },
  art(g, C, ty, ctx) {
    const rows = PF[ty], sel = ctx.sel, Rb = ty === 'ovary' ? BK.ramp(3) : BK.ramp(2), Ra = ty === 'ovary' ? BK.ramp(4) : BK.ramp(0);
    T(g, 86, 26, 'নিষেকের আগে', { fs: 10.5, a: 'middle', w: 650, c: Rb.ink }); T(g, 274, 26, 'নিষেকের পরে', { fs: 10.5, a: 'middle', w: 650, c: Ra.ink });
    rows.forEach(([a, b], i) => {
      const y = PFy(i), on = sel === i, gone = /ঝরে|শুকিয়ে|নষ্ট/.test(b);
      E('rect', { x: 10, y: y - 9, width: 152, height: 19, rx: 9, fill: FK.alpha(Rb.c, on ? .4 : .14), stroke: on ? Rb.dk : 'none' }, g); T(g, 86, y + 4, a, { fs: 10, a: 'middle', w: 600, c: Rb.ink });
      E('rect', { x: 198, y: y - 9, width: 152, height: 19, rx: 9, fill: gone ? FK.alpha(C.mu, .12) : FK.alpha(Ra.c, on ? .4 : .14), stroke: on ? Ra.dk : 'none' }, g); T(g, 274, y + 4, b, { fs: 9.6, a: 'middle', w: 600, c: gone ? C.mu : Ra.ink });
      E('path', { d: `M164 ${y}H192`, stroke: gone ? C.mu : C.fg, 'stroke-width': 1.2, 'stroke-dasharray': gone ? '2 2' : null }, g); E('path', { d: `M196 ${y}l-5 -3v6Z`, fill: gone ? C.mu : C.fg }, g);
    });
  },
  anim(g, C, ty, t) { if (!t) return; PF[ty].forEach((r, i) => { if (/ঝরে|শুকিয়ে|নষ্ট/.test(r[1])) return; const u = (t * .5 + i * .13) % 1; E('circle', { cx: 164 + u * 30, cy: PFy(i), r: 2.4, fill: BK.ramp(6).c }, g); }); },
  tap(x, y, ty, ctx) { const i = Math.round((y - 46) / 22.5), rows = PF[ty]; if (i < 0 || i >= rows.length || Math.abs(y - PFy(i)) > 11) { ctx.sel = null; return ctx.def(); } ctx.sel = i; const [a, b, d] = rows[i]; return `<b>${a} → ${b}</b> — ${d}`; }
}));

/* ═════════ ৭. ভ্রূণের বিকাশ ═════════ */
V.embryoDev = Object.assign({ t: 'দ্বিবীজপত্রী ভ্রূণের বিকাশ (Capsella) ও সস্য', k: ['anim', 'steps'], cap: 'জাইগোট কিছুক্ষণ বিশ্রামের পর বিভাজিত হয় — ডিম্বকরন্ধ্রের দিকের বেসাল কোষ থেকে সাসপেন্সর (ভ্রূণধর), অন্য প্রান্তের শীর্ষ কোষ থেকে ভ্রূণের দেহ। সাধারণত সস্য নিউক্লিয়াস আগে বিভাজিত হয়ে সস্য তৈরি করে, যা ভ্রূণের খাদ্য।' }, BK.steps({
  W: 360, H: 240, label: 'ভ্রূণের বিকাশ', dur: 2.8,
  stages: [
    { t: 'জাইগোট', en: 'Zygote (2n)', d: 'নিষেকের পর জাইগোট নিজের চারপাশে প্রাচীর তৈরি করে; সস্য নিউক্লিয়াস ইতিমধ্যে বারবার বিভাজিত হচ্ছে (নিউক্লিয়ার সস্য — মুক্ত নিউক্লিয়াস, পরে কোষীয়)।' },
    { t: 'দুই কোষ: বেসাল ও শীর্ষ', en: 'Basal & terminal cell', d: 'জাইগোট আড়াআড়ি বিভাজিত হয় — ডিম্বকরন্ধ্রের দিকে বড় বেসাল কোষ, চ্যালাজার দিকে ছোট শীর্ষ কোষ।' },
    { t: 'সাসপেন্সর ও প্রোএমব্রায়ো', en: 'Suspensor + proembryo (octant)', d: 'বেসাল কোষ থেকে ৬–১০ কোষের সাসপেন্সর — ভ্রূণকে সস্যের গভীরে ঠেলে দেয় ও খাদ্য শোষণ করে; শীর্ষ কোষ থেকে ৮ কোষের অক্ট্যান্ট প্রোএমব্রায়ো।' },
    { t: 'গোলাকার দশা', en: 'Globular stage', d: 'কোষ বিভাজনে গোলাকার ভ্রূণ; বাইরের স্তর প্রোটোডার্ম (ত্বক)। সাসপেন্সরের শেষ কোষ হাইপোফাইসিস — ভ্রূণমূলের শীর্ষ গঠন করে।' },
    { t: 'হৃৎপিণ্ডাকার দশা', en: 'Heart stage', d: 'দুই পাশে দুটি বীজপত্রের উদ্ভব — হৃৎপিণ্ডের মতো আকৃতি; দুই বীজপত্রের মাঝে ভ্রূণমুকুল।' },
    { t: 'পরিণত ভ্রূণ', en: 'Mature embryo', d: 'বীজপত্র লম্বা হয়ে বাঁকে (Capsella তে ডিম্বক বাঁকা — ক্যাম্পাইলোট্রপাস); অংশ: দুটি বীজপত্র, ভ্রূণমুকুল (প্লুমিউল), বীজপত্রাবকাশ (হাইপোকটাইল), ভ্রূণমূল (র‍্যাডিকল)। সাসপেন্সর নষ্ট হয়, সস্য শোষিত হয় (অসস্য বীজ) বা থাকে।' }
  ],
  draw(g, C, s, u) {
    const R2 = BK.ramp(0), R7 = BK.ramp(7), Rs = BK.ramp(2), k = u;
    E('path', { d: 'M30 130C30 60 120 40 210 44C300 48 340 90 340 130C340 176 300 210 210 214C120 218 30 196 30 130Z', fill: FK.alpha(R7.c, .14), stroke: R7.dk }, g); T(g, 300, 34, 'সস্য (3n)', { fs: 10, a: 'middle', c: R7.ink });
    for (let i = 0; i < 18; i++) { const a = rnd(i) * PI * 2, r = 40 + rnd(i + 9) * 50; E('circle', { cx: 220 + r * Math.cos(a), cy: 130 + r * .7 * Math.sin(a), r: 2.6, fill: R7.c, opacity: .6 }, g); }
    T(g, 34, 232, 'ডিম্বকরন্ধ্র', { fs: 9.5, c: C.mu });
    const cell = (x, y, w, h, R, op = .55) => E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: 4, fill: FK.alpha(R.c, op), stroke: R.dk }, g);
    if (s === 0) { E('ellipse', { cx: 70, cy: 130, rx: 16 + 2 * k, ry: 12, fill: FK.alpha(R2.c, .55), stroke: R2.dk }, g); nuc(g, 70, 130, 6, R2); T(g, 70, 160, 'জাইগোট', { fs: 10, a: 'middle', c: R2.ink }); return; }
    if (s === 1) { cell(58, 130, 22, 22, Rs); cell(58 + 22 * (.6 + .4 * k), 130, 16, 18, R2); T(g, 58, 160, 'বেসাল', { fs: 10, a: 'middle', c: Rs.ink }); T(g, 92, 160, 'শীর্ষ', { fs: 10, a: 'middle', c: R2.ink }); return; }
    const sus = n => { for (let i = 0; i < n; i++) cell(46 + i * 14, 130, 14, 12, Rs, .45); return 46 + n * 14; };
    if (s === 2) { const x = sus(Math.round(3 + 4 * k)); for (let i = 0; i < 4; i++) cell(x + 4 + (i % 2) * 12, 124 + Math.floor(i / 2) * 12, 12, 12, R2); T(g, 80, 160, 'সাসপেন্সর', { fs: 10, a: 'middle', c: Rs.ink }); T(g, x + 10, 104, 'প্রোএমব্রায়ো', { fs: 10, a: 'middle', c: R2.ink }); return; }
    const x0 = sus(7);
    if (s === 3) { E('circle', { cx: x0 + 22, cy: 130, r: 18 + 4 * k, fill: FK.alpha(R2.c, .5), stroke: R2.dk, 'stroke-width': 2 }, g); T(g, x0 + 22, 176, 'গোলাকার ভ্রূণ', { fs: 10, a: 'middle', c: R2.ink }); return; }
    if (s === 4) { const L = 14 + 14 * k; E('path', { d: `M${x0} 130C${x0} 108 ${x0 + 18} 104 ${x0 + 26} 112L${x0 + 26 + L} ${104 - L * .4}Q${x0 + 40 + L} ${118} ${x0 + 30} 130Q${x0 + 40 + L} ${142} ${x0 + 26 + L} ${156 + L * .4}L${x0 + 26} 148C${x0 + 18} 156 ${x0} 152 ${x0} 130Z`, fill: FK.alpha(R2.c, .5), stroke: R2.dk, 'stroke-width': 2 }, g); T(g, x0 + 40, 196, 'হৃৎপিণ্ডাকার', { fs: 10, a: 'middle', c: R2.ink }); return; }
    const L = 70, Rg = BK.ramp(10);
    E('path', { d: `M${x0} 130Q${x0} 112 ${x0 + 30} 112H${x0 + L + 40}Q${x0 + L + 110} 112 ${x0 + L + 104} 80`, stroke: Rg.dk, 'stroke-width': 13, fill: 'none', 'stroke-linecap': 'round', opacity: .9 }, g);
    E('path', { d: `M${x0} 130Q${x0} 148 ${x0 + 30} 148H${x0 + L + 40}Q${x0 + L + 110} 148 ${x0 + L + 104} 180`, stroke: Rg.c, 'stroke-width': 13, fill: 'none', 'stroke-linecap': 'round', opacity: .9 }, g);
    E('path', { d: `M${x0 - 8} 130H${x0 + 30}`, stroke: R2.dk, 'stroke-width': 18, 'stroke-linecap': 'round' }, g);
    E('circle', { cx: x0 + 32, cy: 130, r: 5, fill: BK.ramp(6).c }, g);
    T(g, x0 - 6, 162, 'ভ্রূণমূল', { fs: 9.5, a: 'middle', c: R2.ink }); T(g, x0 + 34, 102, 'ভ্রূণমুকুল', { fs: 9.5, a: 'middle', c: BK.ramp(6).ink }); T(g, x0 + L + 80, 64, 'বীজপত্র (২টি)', { fs: 9.5, a: 'middle', c: Rg.ink }); T(g, x0 + 10, 186, 'বীজপত্রাবকাশ', { fs: 9.5, a: 'middle', c: R2.ink });
  }
}));

/* ═════════ ৮. বীজের গঠন ═════════ */
const SDinfo = {
  testa: ['টেস্টা (বীজত্বক)', 'বহিঃত্বক থেকে তৈরি শক্ত বাইরের আবরণ — ভ্রূণকে আঘাত, পোকা ও শুষ্কতা থেকে রক্ষা করে।'],
  hil: ['হাইলাম (বীজনাভি)', 'বীজবৃন্ত যেখানে যুক্ত ছিল — লম্বাটে দাগ।'],
  mic: ['মাইক্রোপাইল (বীজরন্ধ্র)', 'হাইলামের এক প্রান্তে ছোট ছিদ্র — ভেজালে এখান দিয়ে পানি ঢোকে ও চাপ দিলে পানি বের হয়।'],
  cot: ['বীজপত্র (কটিলিডন)', 'ভ্রূণের প্রথম পাতা; অসস্য বীজে মোটা, খাদ্য সঞ্চয় করে (ছোলা, শিম, মটর)।'],
  plu: ['ভ্রূণমুকুল (প্লুমিউল)', 'ভ্রূণের যে প্রান্ত থেকে কাণ্ড ও পাতা তৈরি হয়।'],
  rad: ['ভ্রূণমূল (র‍্যাডিকল)', 'মাইক্রোপাইলের দিকে থাকে — অঙ্কুরোদগমে প্রথম বেরিয়ে প্রধান মূল তৈরি করে।'],
  hyp: ['ভ্রূণকাণ্ড / বীজপত্রাবকাশ', 'বীজপত্রের সংযোগের নিচের অংশ (হাইপোকটাইল) ও ওপরের অংশ (এপিকটাইল)।'],
  per: ['ফলত্বক ও বীজত্বক (একত্রে)', 'ভুট্টার দানা আসলে ফল (ক্যারিওপসিস) — ফলত্বক ও বীজত্বক জুড়ে একটি পাতলা আবরণ।'],
  alu: ['অ্যালিউরন স্তর', 'সস্যের বাইরের প্রোটিনসমৃদ্ধ স্তর — অঙ্কুরোদগমে জিবেরেলিনের সংকেতে α-অ্যামাইলেজ ছেড়ে স্টার্চ ভাঙে।'],
  end: ['সস্য (এন্ডোস্পার্ম, 3n)', 'স্টার্চসমৃদ্ধ খাদ্যভাণ্ডার — একবীজপত্রী সস্যল বীজের সবচেয়ে বড় অংশ।'],
  scu: ['স্কুটেলাম', 'একবীজপত্রী বীজের একমাত্র বীজপত্র — ঢালের মতো, সস্য থেকে খাদ্য শোষণ করে ভ্রূণে দেয়।'],
  col: ['কলিওপটাইল', 'ভ্রূণমুকুলকে ঢেকে রাখা আবরণ — মাটি ভেদ করার সময় রক্ষা করে।'],
  clr: ['কলিওরাইজা', 'ভ্রূণমূলকে ঢেকে রাখা আবরণ।']
};
V.seedTypes = Object.assign({}, B.seg({
  id: 'sd', t: 'বীজের গঠন — দ্বিবীজপত্রী ও একবীজপত্রী', H: 250, def: 'di',
  cap: 'বীজ = বীজত্বক + ভ্রূণ (+ সস্য থাকলে)। সস্য বীজে থাকলে সস্যল বীজ (ধান, ভুট্টা, রেড়ি), বীজপত্র সস্য শোষণ করে নিলে অসস্য বীজ (ছোলা, শিম, মটর)। অংশে চাপ দাও।',
  types: {
    di: ['ছোলা / শিম', 'দ্বিবীজপত্রী অসস্য বীজ (শিম)', 'বীজত্বক (টেস্টা ও টেগমেন), হাইলাম, মাইক্রোপাইল; ভেতরে দুটি মোটা বীজপত্রের মাঝে ভ্রূণাক্ষ (ভ্রূণমুকুল + ভ্রূণমূল)। সস্য নেই — খাদ্য বীজপত্রে।'],
    mono: ['ভুট্টা', 'একবীজপত্রী সস্যল বীজ (ভুট্টার দানা, লম্বচ্ছেদ)', 'ফলত্বক-বীজত্বক জোড়া; বড় সস্য ও অ্যালিউরন স্তর; একটি বীজপত্র (স্কুটেলাম); কলিওপটাইলে ঢাকা ভ্রূণমুকুল, কলিওরাইজায় ঢাকা ভ্রূণমূল।']
  },
  art(g, C, ty, ctx) {
    const sel = ctx.sel, H = k => sel === k ? BK.ramp(4).c : null, Rw = BK.ramp(11), Rg = BK.ramp(10), R7 = BK.ramp(7), R0 = BK.ramp(0);
    if (ty === 'di') {
      E('ellipse', { cx: 110, cy: 128, rx: 74, ry: 52, fill: FK.alpha(BK.ramp(8).c, .35), stroke: H('testa') || BK.ramp(8).dk, 'stroke-width': H('testa') ? 3 : 1.6 }, g);
      E('ellipse', { cx: 110, cy: 84, rx: 22, ry: 6, fill: H('hil') || BK.ramp(9).c }, g); E('circle', { cx: 80, cy: 86, r: 3, fill: H('mic') || '#222' }, g);
      T(g, 110, 200, 'বাইরে থেকে', { fs: 10, a: 'middle', c: C.mu });
      E('path', { d: 'M196 70C196 36 300 36 330 80C350 116 330 190 270 196C220 200 196 160 196 128Z', fill: FK.alpha(Rg.c, sel === 'cot' ? .55 : .3), stroke: H('cot') || Rg.dk, 'stroke-width': H('cot') ? 2.6 : 1.4 }, g);
      E('path', { d: 'M206 72Q214 96 218 128', stroke: H('hyp') || R0.dk, 'stroke-width': 9, 'stroke-linecap': 'round', fill: 'none' }, g);
      E('path', { d: 'M212 66Q200 60 204 52', stroke: H('rad') || R0.dk, 'stroke-width': 7, 'stroke-linecap': 'round', fill: 'none' }, g);
      E('path', { d: 'M218 128q8 -14 18 -10q-6 10 -18 10Zm0 0q-4 -14 6 -20q4 12 -6 20Z', fill: H('plu') || BK.ramp(6).c }, g);
      T(g, 270, 214, 'একটি বীজপত্র সরানো', { fs: 10, a: 'middle', c: C.mu });
    } else {
      E('path', { d: 'M90 30Q180 10 270 30Q330 60 320 150Q300 236 180 238Q60 236 40 150Q30 60 90 30Z', fill: FK.alpha(BK.ramp(6).c, .35), stroke: H('per') || BK.ramp(6).dk, 'stroke-width': H('per') ? 3 : 1.6 }, g);
      E('path', { d: 'M100 40Q180 22 262 40Q314 66 306 148Q290 222 180 224Q72 222 56 150Q48 68 100 40Z', fill: 'none', stroke: H('alu') || BK.ramp(2).c, 'stroke-width': H('alu') ? 6 : 4, opacity: .8 }, g);
      E('path', { d: 'M104 48Q180 32 258 48Q302 72 296 140Q284 168 230 176Q180 150 140 176Q88 170 68 140Q62 72 104 48Z', fill: FK.alpha(R7.c, sel === 'end' ? .55 : .3), stroke: H('end') || R7.dk }, g);
      E('path', { d: 'M140 176Q180 150 230 176Q236 214 180 222Q124 214 140 176Z', fill: FK.alpha(Rg.c, sel === 'scu' ? .55 : .3), stroke: H('scu') || Rg.dk, 'stroke-width': H('scu') ? 2.6 : 1.2 }, g);
      E('path', { d: 'M172 168V214', stroke: R0.dk, 'stroke-width': 8, 'stroke-linecap': 'round' }, g);
      E('ellipse', { cx: 172, cy: 168, rx: 8, ry: 12, fill: 'none', stroke: H('col') || R0.dk, 'stroke-width': H('col') ? 2.6 : 1.4 }, g);
      E('ellipse', { cx: 172, cy: 214, rx: 7, ry: 9, fill: 'none', stroke: H('clr') || R0.dk, 'stroke-width': H('clr') ? 2.6 : 1.4 }, g);
      T(g, 180, 110, 'সস্য', { fs: 12, a: 'middle', w: 650, c: R7.ink });
    }
    if (sel) T(g, 180, 18, SDinfo[sel][0], { fs: 11, a: 'middle', w: 650, c: BK.ramp(4).ink });
  },
  anim(g, C, ty, t) { if (!t) return; const u = (t * .3) % 1; if (ty === 'di') { const x = 80 - 20 * u, y = 86 - 14 * u; E('circle', { cx: x, cy: y, r: 2.2, fill: BK.ramp(5).c, opacity: 1 - u }, g); } else { E('circle', { cx: 180, cy: 190, r: 10 + 30 * u, fill: 'none', stroke: BK.ramp(10).c, opacity: 1 - u }, g); } },
  tap(x, y, ty, ctx) {
    const H = ty === 'di' ? [['testa', 50, 128], ['testa', 170, 128], ['hil', 110, 84], ['mic', 80, 86], ['cot', 290, 120], ['hyp', 214, 100], ['rad', 204, 56], ['plu', 226, 122]]
      : [['per', 324, 120], ['per', 36, 120], ['alu', 304, 150], ['alu', 58, 150], ['end', 180, 100], ['end', 250, 120], ['scu', 210, 196], ['col', 172, 162], ['clr', 172, 218]];
    const k = hot(H, x, y, 24); ctx.sel = k; if (!k) return ctx.def(); return `<b>${SDinfo[k][0]}</b> — ${SDinfo[k][1]}`;
  }
}));

/* ═════════ তুলনা ═════════ */
V.cmpSelfCross = cmp('স্ব-পরাগায়ন বনাম পর-পরাগায়ন', 'জিনগত বৈচিত্র্য ও নির্ভরতার দিক থেকে দুটি বিপরীত কৌশল।', 'স্ব-পরাগায়ন', 'পর-পরাগায়ন', [
  ['সংজ্ঞা', 'একই ফুল বা একই গাছের অন্য ফুলের গর্ভমুণ্ডে', 'একই প্রজাতির ভিন্ন গাছের ফুলের গর্ভমুণ্ডে'],
  ['ফুলের ধরন', 'দ্বিলিঙ্গ (গেইটোনোগ্যামিতে একলিঙ্গও)', 'দ্বিলিঙ্গ বা একলিঙ্গ'],
  ['মাধ্যম', 'অটোগ্যামিতে লাগে না', 'বায়ু, পানি, পতঙ্গ, পাখি ইত্যাদি লাগে'],
  ['পরাগরেণুর পরিমাণ', 'কম লাগে, অপচয় কম', 'বেশি তৈরি হয়, অপচয় বেশি'],
  ['ফুলের আকর্ষণ', 'রং, গন্ধ, মধু অপ্রয়োজনীয়', 'পতঙ্গপরাগী ফুলে রং, গন্ধ, মধু থাকে'],
  ['জিনগত বৈচিত্র্য', 'কম — বিশুদ্ধ লাইন বজায় থাকে', 'বেশি — নতুন বৈশিষ্ট্য ও সংকর সবলতা'],
  ['দীর্ঘমেয়াদি ফল', 'অন্তঃপ্রজনন অবনতি হতে পারে', 'অভিযোজন ক্ষমতা ও প্রজাতির সবলতা বাড়ে'],
  ['উদাহরণ', 'ধান, গম, মটর, কানশিরা (ক্লিস্টোগ্যামি)', 'সরিষা, কুমড়া, পেঁপে, ভুট্টা, সূর্যমুখী']
]);
V.cmpFertDouble = cmp('নিষেক বনাম দ্বিনিষেক', 'প্রতিটি দ্বিনিষেকে একটি সাধারণ নিষেক (সিনগ্যামি) থাকে — সাথে বাড়তি একটি ত্রি-মিলন।', 'নিষেক (সিনগ্যামি)', 'দ্বিনিষেক', [
  ['সংজ্ঞা', 'একটি পুংগ্যামেট ও একটি স্ত্রীগ্যামেটের মিলন', 'একই সাথে দুটি মিলন — সিনগ্যামি ও ত্রি-মিলন'],
  ['অংশগ্রহণকারী নিউক্লিয়াস', '২টি (পুংগ্যামেট + ডিম্বাণু)', '৫টি (২ পুংগ্যামেট + ডিম্বাণু + ২ পোলার নিউক্লিয়াস)'],
  ['উৎপাদ', 'জাইগোট (2n)', 'জাইগোট (2n) ও প্রাথমিক সস্য নিউক্লিয়াস (3n)'],
  ['পরিণতি', 'ভ্রূণ', 'ভ্রূণ ও সস্য'],
  ['বিস্তার', 'সব যৌন প্রজননকারী জীবে', 'শুধু আবৃতবীজী উদ্ভিদে (Ephedra ও Gnetum এ অনুরূপ ঘটনা, তবে সস্য তৈরি হয় না)'],
  ['আবিষ্কার', 'স্ট্রাসবার্গার (1884) — উদ্ভিদে গ্যামেট মিলন', 'নাওয়াসচিন (1898) ও গিনার্ড (1899)']
]);
V.cmpAnemoEnto = cmp('বায়ুপরাগী বনাম পতঙ্গপরাগী ফুল', 'ফুলের গঠন মাধ্যমের সাথে অভিযোজিত।', 'বায়ুপরাগী ফুল', 'পতঙ্গপরাগী ফুল', [
  ['আকার ও রং', 'ছোট, অনাকর্ষণীয়, সাধারণত সবুজাভ', 'বড় বা পুষ্পমঞ্জরিতে, উজ্জ্বল রঙিন'],
  ['গন্ধ ও মধু', 'নেই', 'সুগন্ধি, মধুগ্রন্থি থাকে'],
  ['পরাগরেণু', 'অসংখ্য, হালকা, শুষ্ক, মসৃণ', 'কম, ভারী, আঠালো, কাঁটাযুক্ত'],
  ['পুংকেশর', 'লম্বা পুংদণ্ড, দোদুল্যমান পরাগধানী — ফুলের বাইরে ঝোলে', 'সাধারণত ফুলের ভেতরে'],
  ['গর্ভমুণ্ড', 'বড়, পালকের মতো বা শাখান্বিত, বাইরে বের হয়ে থাকে', 'ছোট, আঠালো, ভেতরে'],
  ['উদাহরণ', 'ধান, গম, ভুট্টা, আখ, তাল', 'সরিষা, সূর্যমুখী, কুমড়া, আম, জবা']
]);
V.cmpSeedDM = cmp('দ্বিবীজপত্রী বনাম একবীজপত্রী বীজ', 'শিম/ছোলা বনাম ভুট্টা — পরীক্ষায় চিত্রসহ পার্থক্য আসে।', 'দ্বিবীজপত্রী (শিম)', 'একবীজপত্রী (ভুট্টা)', [
  ['বীজপত্র', 'দুটি, মোটা ও খাদ্যপূর্ণ', 'একটি — স্কুটেলাম, পাতলা'],
  ['সস্য', 'সাধারণত নেই (অসস্য)', 'বড় সস্য থাকে (সস্যল)'],
  ['অ্যালিউরন স্তর', 'নেই', 'আছে'],
  ['আবরণ', 'বীজত্বক — টেস্টা ও টেগমেন', 'ফলত্বক ও বীজত্বক জোড়া (দানা আসলে ফল)'],
  ['কলিওপটাইল ও কলিওরাইজা', 'নেই', 'আছে'],
  ['হাইলাম ও মাইক্রোপাইল', 'স্পষ্ট দেখা যায়', 'স্পষ্ট নয়']
]);
})();
