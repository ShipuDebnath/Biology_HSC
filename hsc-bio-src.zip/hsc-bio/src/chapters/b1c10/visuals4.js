/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §১০.৪ কৃত্রিম প্রজনন, বিবর্তনে ভূমিকা, অর্থনৈতিক গুরুত্ব; §১০.৫ মানচিত্র
   artProp      : কৃত্রিম অঙ্গজ প্রজনন — শাখা কলম, দাবা কলম, গুটি কলম, জোড় কলম, চোখ কলম (অ্যানিমেশন)
   tissueCulture: টিস্যু কালচার (মাইক্রোপ্রোপাগেশন) — ধাপে ধাপে
   handCross    : কৃত্রিম পরাগায়ন ও সংকরায়ণ — ইমাস্কুলেশন, ব্যাগিং, পরাগায়ন, ট্যাগিং
   domestic     : কৃত্রিম নির্বাচন ও বিবর্তন — বন্য সরিষা থেকে কপি, টিওসিন্টে থেকে ভুট্টা
   cmpNatArt, cmpGraftBud : তুলনা         b1c10map : অধ্যায়ের মানচিত্র
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B10;
const PI = Math.PI, ch = B.ch, cl = B.cl, rnd = B.rnd, node = B.node, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const leaf = (g, x, y, a, L, R, o = {}) => { const c = Math.cos(a), s = Math.sin(a), px = -s, py = c, w = L * (o.w || .34); E('path', { d: `M${x} ${y}Q${x + c * L * .5 + px * w} ${y + s * L * .5 + py * w} ${x + c * L} ${y + s * L}Q${x + c * L * .5 - px * w} ${y + s * L * .5 - py * w} ${x} ${y}Z`, fill: o.fill || R.c, stroke: R.dk, 'stroke-width': 1, opacity: o.op != null ? o.op : 1 }, g); };
const roots = (g, x, y, n, L, op = 1) => { for (let i = 0; i < n; i++) { const a = PI / 2 + (i - (n - 1) / 2) * .5; E('path', { d: `M${x} ${y}q${Math.cos(a) * L * .4} ${L * .5} ${Math.cos(a) * L} ${Math.sin(a) * L}`, stroke: BK.ramp(11).dk, 'stroke-width': 1.3, fill: 'none', opacity: op }, g); } };
const ground = (g, y) => { E('rect', { x: 0, y, width: 360, height: 260 - y, fill: FK.alpha(BK.ramp(11).c, .3) }, g); E('path', { d: `M0 ${y}H360`, stroke: BK.ramp(11).dk, 'stroke-width': 1.4 }, g); };
const branch = (g, pts, w, R) => B.poly(g, pts, { stroke: R.dk, 'stroke-width': w, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' });

/* ═════════ ১. কৃত্রিম অঙ্গজ প্রজনন ═════════ */
V.artProp = Object.assign({}, B.seg({
  id: 'ap', t: 'কৃত্রিম অঙ্গজ প্রজনন (কলম)', H: 260, def: 'cut',
  cap: 'মানুষ নিজের প্রয়োজনে উদ্ভিদের অঙ্গজ অংশ ব্যবহার করে নতুন উদ্ভিদ তৈরি করলে তাকে কৃত্রিম অঙ্গজ প্রজনন বলে — উদ্দেশ্য মাতৃগাছের হুবহু গুণাগুণ বজায় রাখা, তাড়াতাড়ি ফল পাওয়া। চালাও চাপলে প্রক্রিয়াটি দেখাবে।',
  types: {
    cut: ['শাখা কলম', 'শাখা কলম (কাটিং)', 'পরিণত শাখার ১৫–২০ cm লম্বা কয়েক পর্বযুক্ত টুকরা তির্যকভাবে কেটে ভেজা মাটিতে পুঁতলে পর্ব থেকে অস্থানিক মূল ও মুকুল থেকে শাখা গজায় — গোলাপ, জবা, আখ, মেহেদি, কাসাভা। IBA বা NAA (কৃত্রিম অক্সিন) দিলে দ্রুত মূল গজায়।'],
    lay: ['দাবা কলম', 'দাবা কলম (লেয়ারিং)', 'মাতৃগাছের নমনীয় নিচু শাখা বাঁকিয়ে মাঝের অংশের ছাল সামান্য কেটে মাটিতে চাপা দিয়ে রাখা হয়; ঐ অংশে মূল গজালে মাতৃগাছ থেকে কেটে আলাদা করা হয় — জুঁই, লেবু, করমচা, স্ট্রবেরি।'],
    air: ['গুটি কলম', 'গুটি কলম (এয়ার লেয়ারিং)', 'শাখার ২–৩ cm ছাল আংটির মতো তুলে (বলয় ছেদন) ক্ষতস্থানে ভেজা মাটি-গোবরের গুটি বেঁধে পলিথিনে মুড়ে রাখা হয়; ফ্লোয়েম কাটা থাকায় পাতার খাদ্য ও অক্সিন ক্ষতের ওপরে জমে — সেখানে মূল গজায়; ৩০–৬০ দিনে কেটে লাগানো হয় — লিচু, পেয়ারা, লেবু, জামরুল।'],
    graft: ['জোড় কলম', 'জোড় কলম (গ্রাফটিং)', 'ভালো জাতের গাছের শাখা (উপজোড় বা সায়ন) অন্য শক্ত-মূলের গাছের (মূলজোড় বা স্টক) সাথে জোড়া লাগানো হয় — দুটির ক্যাম্বিয়াম মিলে গেলে কলাস তৈরি হয়ে জোড়া লেগে যায়। আম, কাঁঠাল, কুল। প্রকার: ক্লেফট (ফাটল), ভিনিয়ার, ক্লোজ বা অ্যাপ্রোচ (দুটি গাছ পাশাপাশি রেখে)।'],
    bud: ['চোখ কলম', 'চোখ কলম (বাডিং)', 'ভালো জাতের গাছের একটি মুকুল (চোখ) ছালসহ তুলে স্টকের ছালে "T" আকারে চিরে ঢুকিয়ে বেঁধে দেওয়া হয় (T-বাডিং) — গোলাপ, কুল, লেবু, আপেল। একটি সায়ন গাছ থেকে অনেক কলম করা যায়।']
  },
  art(g, C, ty) {
    const Rg = BK.ramp(10), Rw = BK.ramp(11), Rb = BK.ramp(6);
    ground(g, 200);
    if (ty === 'cut') { [[70, 0], [180, 1], [290, 2]].forEach(([x, i]) => { E('path', { d: `M${x - 6} 230L${x - 2} 120H${x + 2}L${x + 6} 230Z`, fill: Rw.c, stroke: Rw.dk }, g); [150, 180].forEach(y => E('path', { d: `M${x - 3} ${y}h6`, stroke: Rw.dk, 'stroke-width': 2 }, g)); }); T(g, 70, 252, 'লাগানো', { fs: 10, a: 'middle', c: C.mu }); T(g, 180, 252, 'মূল গজাচ্ছে', { fs: 10, a: 'middle', c: C.mu }); T(g, 290, 252, 'নতুন গাছ', { fs: 10, a: 'middle', c: C.mu }); }
    if (ty === 'lay') { branch(g, [[60, 200], [60, 70]], 7, Rw); for (let i = 0; i < 3; i++) leaf(g, 60, 80 + i * 28, -PI / 2 + (i % 2 ? .9 : -.9), 30, Rg); E('path', { d: 'M60 150Q120 140 170 214Q210 240 250 200L280 140', stroke: Rw.dk, 'stroke-width': 4, fill: 'none' }, g); E('path', { d: 'M150 204Q170 196 190 204', stroke: BK.ramp(11).dk, 'stroke-width': 10, fill: 'none', opacity: .5 }, g); leaf(g, 280, 140, -1.2, 26, Rg); leaf(g, 280, 140, -2.2, 22, Rg); T(g, 180, 250, 'মাটিচাপা অংশে মূল', { fs: 10, a: 'middle', c: C.mu }); E('rect', { x: 166, y: 208, width: 14, height: 8, fill: BK.ramp(9).c }, g); }
    if (ty === 'air') { ground(g, 230); branch(g, [[90, 230], [90, 50]], 10, Rw); branch(g, [[90, 140], [240, 70]], 5, Rw); for (let i = 0; i < 4; i++) leaf(g, 240 - i * 14, 70 + i * 6, -1.1 - (i % 2) * 1.2, 26, Rg); E('ellipse', { cx: 180, cy: 98, rx: 26, ry: 18, fill: BK.ramp(9).lt, stroke: BK.ramp(9).dk }, g); E('path', { d: 'M156 92l48 12M156 104l48 -12', stroke: BK.ramp(9).dk, 'stroke-width': .8 }, g); T(g, 180, 140, 'গুটি (মাটি + গোবর, পলিথিনে মোড়া)', { fs: 9.5, a: 'middle', c: C.mu }); T(g, 180, 30, 'বলয় ছেদনের ওপরে মূল গজায়', { fs: 10.5, a: 'middle', w: 600, c: C.fg }); }
    if (ty === 'graft') { branch(g, [[180, 240], [180, 140]], 14, Rw); T(g, 198, 186, 'মূলজোড় (স্টক) — দেশি, রোগসহিষ্ণু', { fs: 9.5, c: C.mu }); T(g, 230, 60, 'উপজোড় (সায়ন) — উন্নত জাত', { fs: 9.5, c: C.mu }); }
    if (ty === 'bud') { branch(g, [[120, 240], [120, 40]], 14, Rw); E('path', { d: 'M108 120h24M120 120v34', stroke: '#5a4630', 'stroke-width': 2 }, g); T(g, 150, 116, 'স্টকের ছালে T-চিরা', { fs: 10, c: C.mu }); E('path', { d: 'M260 70L272 70L276 120L256 120Z', fill: Rw.lt, stroke: Rw.dk }, g); E('circle', { cx: 266, cy: 92, r: 5, fill: Rg.c, stroke: Rg.dk }, g); T(g, 266, 140, 'মুকুল (চোখ) ছালসহ', { fs: 10, a: 'middle', c: C.mu }); }
  },
  anim(g, C, ty, t) {
    const u = t ? (t * .16) % 1 : .9, k = FK.ease(cl(u * 1.25)), Rg = BK.ramp(10), Rw = BK.ramp(11);
    if (ty === 'cut') { roots(g, 180, 222, 4, 14 * k + 2, .4 + .6 * k); roots(g, 290, 222, 5, 22); leaf(g, 180, 124, -PI / 2 - .7, 8 + 12 * k, Rg); leaf(g, 180, 124, -PI / 2 + .7, 8 + 12 * k, Rg); [[-PI / 2 - .8, 26], [-PI / 2 + .8, 26], [-PI / 2 - 1.4, 22], [-PI / 2 + 1.4, 22]].forEach(([a, L], i) => leaf(g, 290, 124 + i * 10, a, L, Rg)); return; }
    if (ty === 'lay') { roots(g, 176, 218, 4, 4 + 20 * k, .3 + .7 * k); if (u > .8) { E('path', { d: 'M120 170l12 -10', stroke: BK.ramp(4).c, 'stroke-width': 2.4 }, g); T(g, 126, 150, 'কেটে আলাদা', { fs: 9.5, a: 'middle', c: BK.ramp(4).ink }); } return; }
    if (ty === 'air') { for (let i = 0; i < 5; i++) { const a = PI * (i / 4) + .3; E('path', { d: `M180 98l${Math.cos(a) * 18 * k} ${Math.sin(a) * 12 * k}`, stroke: BK.ramp(11).dk, 'stroke-width': 1.2, opacity: k }, g); } for (let i = 0; i < 3; i++) { const v = (t * .3 + i / 3) % 1; E('circle', { cx: 230 - v * 50, cy: 72 + v * 22, r: 2.4, fill: BK.ramp(7).c, opacity: 1 - v * .5 }, g); } T(g, 250, 100, 'খাদ্য ও অক্সিন নামে', { fs: 9, c: BK.ramp(7).ink }); return; }
    if (ty === 'graft') {
      const y = 70 + 60 * k; E('path', { d: `M174 ${y}L180 ${y + 18}L186 ${y}V${y - 80}H174Z`, fill: Rw.lt, stroke: Rw.dk }, g); for (let i = 0; i < 3; i++) leaf(g, 180, y - 70 + i * 20, -PI / 2 + (i % 2 ? .9 : -.9), 24, Rg);
      E('path', { d: 'M173 140L180 158L187 140', stroke: Rw.dk, fill: 'none', 'stroke-width': 1.4 }, g);
      if (k > .9) { E('rect', { x: 168, y: 128, width: 24, height: 28, rx: 3, fill: FK.alpha(BK.ramp(5).c, .5), stroke: BK.ramp(5).dk }, g); T(g, 120, 146, 'বেঁধে দাও', { fs: 9.5, a: 'middle', c: BK.ramp(5).ink }); T(g, 120, 160, 'ক্যাম্বিয়াম মিলবে', { fs: 9.5, a: 'middle', c: BK.ramp(5).ink }); }
      return;
    }
    const x = 266 - (266 - 120) * k, y = 92 + (134 - 92) * k; E('path', { d: `M${x - 6} ${y - 22}L${x + 6} ${y - 22}L${x + 10} ${y + 28}L${x - 10} ${y + 28}Z`, fill: Rw.lt, stroke: Rw.dk, opacity: .9 }, g); E('circle', { cx: x, cy: y, r: 5, fill: Rg.c, stroke: Rg.dk }, g);
    if (k > .9) { for (let i = 0; i < 4; i++) E('path', { d: `M106 ${116 + i * 10}h28`, stroke: BK.ramp(5).dk, 'stroke-width': 3, opacity: .7 }, g); }
  }
}));

/* ═════════ ২. টিস্যু কালচার ═════════ */
const flask = (g, C, x, y, s = 1) => { E('path', { d: `M${x - 10 * s} ${y - 60 * s}V${y - 34 * s}L${x - 34 * s} ${y}H${x + 34 * s}L${x + 10 * s} ${y - 34 * s}V${y - 60 * s}Z`, fill: FK.alpha(BK.ramp(5).c, .1), stroke: C.fg, 'stroke-width': 1.3 }, g); E('path', { d: `M${x - 26 * s} ${y - 12 * s}H${x + 26 * s}L${x + 34 * s} ${y}H${x - 34 * s}Z`, fill: FK.alpha(BK.ramp(6).c, .45) }, g); E('rect', { x: x - 12 * s, y: y - 66 * s, width: 24 * s, height: 8 * s, rx: 2, fill: '#e5e5e5', stroke: C.mu }, g); };
V.tissueCulture = Object.assign({ t: 'টিস্যু কালচার — মাইক্রোপ্রোপাগেশন', k: ['anim', 'steps'], cap: 'উদ্ভিদকোষের টটিপোটেন্সি (প্রতিটি জীবিত কোষ থেকে পূর্ণাঙ্গ উদ্ভিদ তৈরির ক্ষমতা — হ্যাবারল্যান্ড্ট, 1902) কাজে লাগিয়ে জীবাণুমুক্ত কৃত্রিম পুষ্টি মাধ্যমে অল্প টিস্যু থেকে অসংখ্য একই রকম চারা তৈরি করা যায়। বাংলাদেশে আলু, কলা, আনারস, অর্কিড ও স্ট্রবেরির চারা এভাবে উৎপাদিত হয়।' }, BK.steps({
  W: 360, H: 240, label: 'টিস্যু কালচারের ধাপ', dur: 2.8,
  stages: [
    { t: 'এক্সপ্ল্যান্ট সংগ্রহ', en: 'Explant', d: 'রোগমুক্ত মাতৃগাছ থেকে ছোট টিস্যু — শীর্ষ ভাজক টিস্যু (মেরিস্টেম; ভাইরাসমুক্ত চারার জন্য), পাতা, কাণ্ডের টুকরা, পরাগধানী ইত্যাদি।' },
    { t: 'জীবাণুমুক্তকরণ', en: 'Surface sterilization', d: 'এক্সপ্ল্যান্ট ৭০% ইথানল ও সোডিয়াম হাইপোক্লোরাইট বা মারকিউরিক ক্লোরাইডে ধুয়ে জীবাণুমুক্ত পানিতে ধোয়া হয়; যন্ত্রপাতি অটোক্লেভে (121 °C, 15 lb চাপ, 15–20 মিনিট) ও কাজ ল্যামিনার এয়ার ফ্লো ক্যাবিনেটে।' },
    { t: 'আবাদ মাধ্যমে স্থাপন', en: 'Inoculation on MS medium', d: 'MS (মুরাশিগে ও স্কুগ, 1962) মাধ্যম — খনিজ লবণ, সুক্রোজ, ভিটামিন, অ্যাগার (জমাট বাঁধাতে), হরমোন; pH 5.6–5.8। প্রায় 25 ± 2 °C তাপ ও ১৬ ঘণ্টা আলো।' },
    { t: 'ক্যালাস সৃষ্টি', en: 'Callus', d: 'অক্সিন ও সাইটোকাইনিনের প্রায় সমান অনুপাতে কোষগুলো বিভাজিত হয়ে অবিভেদিত কোষপিণ্ড — ক্যালাস তৈরি করে।' },
    { t: 'অঙ্গ সৃষ্টি — বিটপ ও মূল', en: 'Organogenesis', d: 'সাইটোকাইনিন বেশি → বিটপ (শাখা-পাতা); পরে অক্সিন বেশি মাধ্যমে স্থানান্তর → মূল। ক্যালাস ভেঙে উপ-আবাদে অসংখ্য চারা — অল্প সময়ে লক্ষ চারা সম্ভব।' },
    { t: 'অভ্যস্তকরণ (হার্ডেনিং)', en: 'Hardening & transfer', d: 'চারা ধীরে ধীরে বাইরের আর্দ্রতা ও তাপে অভ্যস্ত করিয়ে (গ্রিনহাউসে) মাঠে লাগানো হয়।' }
  ],
  draw(g, C, s, u) {
    const Rg = BK.ramp(10), Rc = BK.ramp(7), k = u;
    if (s === 0) { E('path', { d: 'M180 230V70', stroke: BK.ramp(11).dk, 'stroke-width': 5 }, g); for (let i = 0; i < 4; i++) { const y = 200 - i * 34, sd = i % 2 ? 1 : -1; E('path', { d: `M180 ${y}q${sd * 30} -14 ${sd * 50} -6q${-sd * 24} 10 ${-sd * 50} 6Z`, fill: Rg.c, stroke: Rg.dk }, g); } E('circle', { cx: 180, cy: 66, r: 8, fill: BK.ramp(6).c, stroke: BK.ramp(6).dk }, g); E('path', { d: `M${200 + 40 * k} 66H214`, stroke: C.fg, 'stroke-width': 1.4 }, g); E('circle', { cx: 210 + 50 * k, cy: 66, r: 6, fill: BK.ramp(6).c }, g); T(g, 270, 50, 'শীর্ষ ভাজক', { fs: 10, a: 'middle', c: BK.ramp(6).ink }); return; }
    if (s === 1) { E('rect', { x: 60, y: 40, width: 240, height: 150, rx: 10, fill: FK.alpha(BK.ramp(5).c, .1), stroke: C.mu }, g); T(g, 180, 32, 'ল্যামিনার এয়ার ফ্লো', { fs: 10, a: 'middle', c: C.mu }); for (let i = 0; i < 6; i++) { const y = 50 + ((k * 140 + i * 24) % 140); E('path', { d: `M80 ${y}h40M150 ${y}h40M220 ${y}h40`, stroke: BK.ramp(5).c, 'stroke-width': 1, opacity: .4 }, g); } E('rect', { x: 150, y: 140, width: 60, height: 34, rx: 6, fill: FK.alpha(BK.ramp(5).c, .3), stroke: BK.ramp(5).dk }, g); E('circle', { cx: 180, cy: 156, r: 5, fill: BK.ramp(6).c }, g); T(g, 180, 214, 'জীবাণুমুক্ত দ্রবণে ধোয়া', { fs: 10.5, a: 'middle', c: C.fg }); return; }
    flask(g, C, 180, 210, 1.6);
    if (s === 2) { E('circle', { cx: 180, cy: 186, r: 5 + 2 * k, fill: BK.ramp(6).c }, g); T(g, 180, 50, 'MS মাধ্যম (অ্যাগার, সুক্রোজ, হরমোন)', { fs: 10.5, a: 'middle', c: C.fg }); return; }
    if (s === 3) { B.blob(g, 180, 180, 8 + 18 * k, { fill: Rc.lt, stroke: Rc.dk, n: 11, j: .35, seed: 4 }); T(g, 180, 50, 'ক্যালাস — অক্সিন ≈ সাইটোকাইনিন', { fs: 10.5, a: 'middle', c: C.fg }); return; }
    if (s === 4) { B.blob(g, 180, 184, 22, { fill: Rc.lt, stroke: Rc.dk, n: 11, j: .35, seed: 4 }); for (let i = 0; i < 4; i++) { const x = 160 + i * 14, h = 10 + 30 * k * (0.7 + .3 * rnd(i)); E('path', { d: `M${x} 172V${172 - h}`, stroke: Rg.dk, 'stroke-width': 2 }, g); leaf(g, x, 172 - h, -2.2, 10 + 4 * k, Rg); leaf(g, x, 172 - h, -.9, 10 + 4 * k, Rg); } T(g, 180, 50, 'সাইটোকাইনিন বেশি → বিটপ; অক্সিন বেশি → মূল', { fs: 10.5, a: 'middle', c: C.fg }); return; }
    for (let i = 0; i < 3; i++) { const x = 100 + i * 80; E('path', { d: `M${x - 22} 200H${x + 22}L${x + 16} 232H${x - 16}Z`, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk }, g); E('path', { d: `M${x} 200V${170 - 20 * k}`, stroke: Rg.dk, 'stroke-width': 2.4 }, g); leaf(g, x, 170 - 20 * k, -2.3, 22, Rg); leaf(g, x, 170 - 20 * k, -.8, 22, Rg); leaf(g, x, 190, -2.6, 18, Rg); }
    T(g, 180, 50, 'গ্রিনহাউসে টবে — তারপর মাঠে', { fs: 10.5, a: 'middle', c: C.fg });
  }
}));

/* ═════════ ৩. কৃত্রিম পরাগায়ন ও সংকরায়ণ ═════════ */
const hflower = (g, C, x, y, o = {}) => {
  const Rp = BK.ramp(8), Ra = BK.ramp(6), Rc = BK.ramp(3);
  E('path', { d: `M${x} ${y + 80}V${y + 10}`, stroke: BK.ramp(10).dk, 'stroke-width': 3 }, g);
  [-1, 1].forEach(d => E('path', { d: `M${x} ${y + 10}Q${x + d * 40} ${y} ${x + d * 44} ${y - 40}Q${x + d * 16} ${y - 34} ${x} ${y + 10}Z`, fill: FK.alpha(Rp.c, .5), stroke: Rp.dk }, g));
  if (!o.emas) [-1, 1].forEach(d => [0, 1].forEach(j => { const sx = x + d * (8 + j * 9), sy = y - 26 - j * 6; E('path', { d: `M${x + d * 3} ${y + 8}L${sx} ${sy}`, stroke: Ra.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: sx, cy: sy - 5, rx: 3.4, ry: 6, fill: Ra.c, stroke: Ra.dk }, g); }));
  else [-1, 1].forEach(d => [0, 1].forEach(j => E('path', { d: `M${x + d * 3} ${y + 8}L${x + d * (5 + j * 4)} ${y - 2}`, stroke: Ra.dk, 'stroke-width': 1.4 }, g)));
  E('path', { d: `M${x} ${y + 10}V${y - 40}`, stroke: Rc.dk, 'stroke-width': 2.6 }, g); E('ellipse', { cx: x, cy: y - 42, rx: 7, ry: 4, fill: o.pol ? Ra.c : Rc.lt, stroke: Rc.dk }, g); E('ellipse', { cx: x, cy: y + 14, rx: 8, ry: 8, fill: FK.alpha(Rc.c, .4), stroke: Rc.dk }, g);
};
const bag = (g, C, x, y, op = 1) => { E('path', { d: `M${x - 44} ${y + 30}Q${x - 52} ${y - 60} ${x} ${y - 70}Q${x + 52} ${y - 60} ${x + 44} ${y + 30}Z`, fill: FK.alpha('#ffffff', .55 * op), stroke: C.mu, 'stroke-width': 1.4, 'stroke-dasharray': '4 3', opacity: op }, g); E('path', { d: `M${x - 10} ${y + 34}h20`, stroke: C.fg, 'stroke-width': 3, opacity: op }, g); };
V.handCross = Object.assign({ t: 'কৃত্রিম পরাগায়ন ও সংকরায়ণ', k: ['anim', 'steps'], cap: 'দুটি ভিন্ন গুণের জাতের মধ্যে সংকরায়ণে মানুষ নিজে পরাগায়ন ঘটায় — উদ্ভিদ প্রজননের মূল কৌশল। স্ত্রী জনিতা থেকে পুংকেশর সরানো (ইমাস্কুলেশন) ও ব্যাগিং অনাকাঙ্ক্ষিত পরাগ ঠেকায়।' }, BK.steps({
  W: 360, H: 240, label: 'সংকরায়ণের ধাপ', dur: 3,
  stages: [
    { t: 'জনিতা নির্বাচন', en: 'Select parents', d: 'কাঙ্ক্ষিত বৈশিষ্ট্যের দুটি জাত বাছাই — যেমন একটি উচ্চফলনশীল, অন্যটি রোগ বা লবণসহিষ্ণু। একটি স্ত্রী জনিতা, অন্যটি পুং জনিতা।' },
    { t: 'ইমাস্কুলেশন', en: 'Emasculation', d: 'স্ত্রী জনিতার দ্বিলিঙ্গ ফুল কুঁড়ি অবস্থায় (পরাগধানী ফাটার আগে) সাবধানে ফরসেপ দিয়ে পুংকেশর সরানো হয় — যাতে স্ব-পরাগায়ন না হয়। একলিঙ্গ ফুলে দরকার হয় না।' },
    { t: 'ব্যাগিং', en: 'Bagging', d: 'ইমাস্কুলেশনের পরপর ফুলটি বাটার পেপার বা কাপড়ের ব্যাগে ঢেকে দেওয়া হয় — বাইরের অনাকাঙ্ক্ষিত পরাগরেণু ঢুকতে পারে না।' },
    { t: 'কৃত্রিম পরাগায়ন', en: 'Dusting pollen', d: 'গর্ভমুণ্ড গ্রহণক্ষম হলে পুং জনিতার পরিণত পরাগরেণু তুলি দিয়ে বা পরাগধানী ঘষে গর্ভমুণ্ডে দেওয়া হয়; সাথে সাথে আবার ব্যাগ।' },
    { t: 'ট্যাগিং ও বীজ সংগ্রহ', en: 'Tagging', d: 'জনিতার নাম, তারিখ লেখা ট্যাগ লাগানো হয়; ফল পাকলে সংকর (F1) বীজ সংগ্রহ। পরের প্রজন্মে নির্বাচন চালিয়ে নতুন জাত — যেমন ব্রি ও বিনার বহু ধানের জাত।' }
  ],
  draw(g, C, s, u) {
    const k = u, Ra = BK.ramp(6);
    if (s === 0) { hflower(g, C, 110, 110); hflower(g, C, 250, 110, {}); T(g, 110, 222, 'স্ত্রী জনিতা', { fs: 10.5, a: 'middle', w: 600, c: BK.ramp(3).ink }); T(g, 250, 222, 'পুং জনিতা', { fs: 10.5, a: 'middle', w: 600, c: Ra.ink }); T(g, 110, 30, 'উচ্চফলনশীল', { fs: 10, a: 'middle', c: C.mu }); T(g, 250, 30, 'রোগসহিষ্ণু', { fs: 10, a: 'middle', c: C.mu }); return; }
    if (s === 1) { hflower(g, C, 150, 110, { emas: k > .6 }); const fx = 150 + 60 * k, fy = 80 - 30 * k; E('path', { d: `M${fx + 70} ${fy - 40}L${fx + 4} ${fy}M${fx + 74} ${fy - 34}L${fx + 6} ${fy + 4}`, stroke: '#888', 'stroke-width': 2 }, g); if (k > .6) for (let i = 0; i < 4; i++) E('ellipse', { cx: 260 + i * 12, cy: 200, rx: 3.4, ry: 6, fill: Ra.c, opacity: .7 }, g); T(g, 270, 222, 'সরানো পুংকেশর', { fs: 10, a: 'middle', c: C.mu }); return; }
    if (s === 2) { hflower(g, C, 180, 110, { emas: true }); bag(g, C, 180, 110, k); return; }
    if (s === 3) { hflower(g, C, 150, 110, { emas: true, pol: k > .7 }); bag(g, C, 150, 110, .25); const bx = 290 - 132 * k, by = 40 + 28 * k; E('path', { d: `M${bx + 50} ${by - 30}L${bx + 4} ${by}`, stroke: BK.ramp(9).dk, 'stroke-width': 3 }, g); E('ellipse', { cx: bx, cy: by + 2, rx: 6, ry: 4, fill: Ra.c }, g); T(g, 300, 222, 'তুলিতে পরাগরেণু', { fs: 10, a: 'middle', c: Ra.ink }); return; }
    hflower(g, C, 150, 110, { emas: true, pol: true }); bag(g, C, 150, 110, 1); E('path', { d: 'M170 170L230 196', stroke: C.fg }, g); E('rect', { x: 226, y: 186, width: 100, height: 34, rx: 4, fill: '#fffbe6', stroke: C.fg, transform: `rotate(${4 * Math.sin(k * 6)} 226 186)` }, g); T(g, 276, 200, 'ক × খ', { fs: 10, a: 'middle', w: 650, c: '#333' }); T(g, 276, 214, '১২/০৩', { fs: 9, a: 'middle', c: '#333' });
  }
}));

/* ═════════ ৪. কৃত্রিম নির্বাচন ও বিবর্তন ═════════ */
const DMb = [['বাঁধাকপি', 'শীর্ষ মুকুল বড়', 'cab'], ['ফুলকপি', 'পুষ্পমঞ্জরি', 'cau'], ['ব্রকলি', 'পুষ্পমুকুল ও কাণ্ড', 'bro'], ['ওলকপি', 'কাণ্ড স্ফীত', 'kol'], ['কেল / পাতাকপি', 'পাতা বড়', 'kal'], ['ব্রাসেলস স্প্রাউট', 'কাক্ষিক মুকুল', 'brs']];
V.domestic = Object.assign({}, B.seg({
  id: 'dm', t: 'কৃত্রিম নির্বাচন — বিবর্তনে কৃত্রিম প্রজননের ভূমিকা', H: 260, def: 'bras',
  cap: 'মানুষ হাজার বছর ধরে কাঙ্ক্ষিত বৈশিষ্ট্যের গাছ বেছে বেছে প্রজনন করিয়েছে (কৃত্রিম নির্বাচন) — এতে অল্প সময়ে বন্য পূর্বপুরুষ থেকে সম্পূর্ণ নতুন চেহারার জাত তৈরি হয়েছে। ডারউইন এ ঘটনাকে প্রাকৃতিক নির্বাচনের প্রমাণ হিসেবে ব্যবহার করেন (On the Origin of Species, 1859)।',
  types: {
    bras: ['বন্য সরিষা → কপি', 'একটি বন্য প্রজাতি থেকে ছয়টি সবজি', 'বন্য Brassica oleracea (ভূমধ্যসাগরীয় উপকূলের বন্য বাঁধাকপি) থেকে ভিন্ন ভিন্ন অঙ্গ বড় করার নির্বাচনে বাঁধাকপি, ফুলকপি, ব্রকলি, ওলকপি, কেল ও ব্রাসেলস স্প্রাউট — সবগুলো এখনো একই প্রজাতি এবং পরস্পর সংকরায়ণযোগ্য।'],
    maize: ['টিওসিন্টে → ভুট্টা', 'টিওসিন্টে থেকে ভুট্টা', 'মেক্সিকোর বন্য ঘাস টিওসিন্টে (Zea mays ssp. parviglumis) — ছোট মোচায় ৫–১২টি শক্ত খোসায় ঢাকা দানা। প্রায় ৯০০০ বছর ধরে নির্বাচনে আজকের বড় মোচা, ৫০০–১০০০ খোলা দানা — মাত্র কয়েকটি প্রধান জিনের পরিবর্তনে (যেমন tb1, tga1)।'],
    wheat: ['সংকর → গম', 'সংকরায়ণ ও পলিপ্লয়েডি — রুটির গম', 'রুটির গম (Triticum aestivum, 6n = 42) তিনটি বন্য ঘাসের প্রাকৃতিক ও কৃষিজ সংকর থেকে: AA (T. urartu) × BB (Aegilops speltoides পরিবারের) → AABB (ইমার গম, 4n) × DD (Aegilops tauschii) → AABBDD। সংকরায়ণের পর ক্রোমোসোম দ্বিগুণ হওয়ায় নতুন প্রজাতির উদ্ভব — বিবর্তনের এক সরাসরি উদাহরণ।']
  },
  art(g, C, ty) {
    const Rg = BK.ramp(10), R7 = BK.ramp(7), Ra = BK.ramp(6);
    if (ty === 'bras') {
      const cx = 180, cy = 128; E('path', { d: `M${cx} ${cy + 26}V${cy - 20}`, stroke: Rg.dk, 'stroke-width': 3 }, g); for (let i = 0; i < 4; i++) leaf(g, cx, cy + 16 - i * 10, -PI / 2 + (i % 2 ? .9 : -.9), 20, Rg); E('circle', { cx, cy: cy - 26, r: 4, fill: BK.ramp(6).c }, g);
      T(g, cx, cy + 46, 'বন্য Brassica oleracea', { fs: 10, a: 'middle', w: 650, c: C.fg });
      DMb.forEach(([n, d, k], i) => {
        const a = -PI / 2 + i / 6 * PI * 2, x = cx + 138 * Math.cos(a) * .95, y = cy + 92 * Math.sin(a);
        E('path', { d: `M${cx + 40 * Math.cos(a)} ${cy + 30 * Math.sin(a)}L${x - 26 * Math.cos(a)} ${y - 20 * Math.sin(a)}`, stroke: C.mu, 'stroke-dasharray': '3 3' }, g);
        if (k === 'cab') { E('circle', { cx: x, cy: y, r: 13, fill: Rg.lt, stroke: Rg.dk }, g); E('path', { d: `M${x - 9} ${y}q9 -10 18 0`, stroke: Rg.dk, fill: 'none' }, g); }
        if (k === 'cau') { E('circle', { cx: x, cy: y, r: 12, fill: '#f6f1df', stroke: '#b9ad84' }, g); for (let j = 0; j < 5; j++) E('circle', { cx: x - 6 + j * 3, cy: y - 3 + (j % 2) * 5, r: 3, fill: '#efe6c4' }, g); leaf(g, x - 10, y + 8, PI * .85, 12, Rg); leaf(g, x + 10, y + 8, PI * .15, 12, Rg); }
        if (k === 'bro') { E('path', { d: `M${x} ${y + 14}V${y}`, stroke: Rg.dk, 'stroke-width': 4 }, g); for (let j = 0; j < 5; j++) E('circle', { cx: x - 8 + j * 4, cy: y - 4 + (j % 2) * 3, r: 4.5, fill: Rg.dk }, g); }
        if (k === 'kol') { E('circle', { cx: x, cy: y + 2, r: 11, fill: BK.ramp(3).lt, stroke: BK.ramp(3).dk }, g); leaf(g, x, y - 8, -2.2, 14, Rg); leaf(g, x, y - 8, -.9, 14, Rg); }
        if (k === 'kal') { leaf(g, x, y + 12, -1.2, 26, Rg, { w: .5 }); leaf(g, x, y + 12, -1.9, 26, Rg, { w: .5 }); }
        if (k === 'brs') { E('path', { d: `M${x} ${y + 16}V${y - 14}`, stroke: Rg.dk, 'stroke-width': 3 }, g); for (let j = 0; j < 4; j++) E('circle', { cx: x + (j % 2 ? 5 : -5), cy: y + 10 - j * 7, r: 3.6, fill: Rg.c, stroke: Rg.dk }, g); }
        T(g, x, y + (Math.sin(a) > .3 ? 32 : -18), n, { fs: 10, a: 'middle', w: 650, c: C.fg });
      });
    } else if (ty === 'maize') {
      E('path', { d: 'M70 70V160', stroke: Rg.dk, 'stroke-width': 2 }, g); for (let i = 0; i < 6; i++) E('path', { d: `M64 ${80 + i * 13}l6 -5l6 5l-6 7Z`, fill: R7.lt, stroke: R7.dk }, g);
      T(g, 70, 186, 'টিওসিন্টে', { fs: 11, a: 'middle', w: 650, c: C.fg }); T(g, 70, 202, '৫–১২ শক্ত দানা', { fs: 9.5, a: 'middle', c: C.mu });
      E('path', { d: 'M266 40C246 60 244 180 266 210C288 180 286 60 266 40Z', fill: BK.ramp(6).lt, stroke: Ra.dk }, g); for (let r = 0; r < 14; r++) for (let c = 0; c < 4; c++) E('circle', { cx: 256 + c * 7, cy: 58 + r * 11, r: 3.2, fill: Ra.c }, g);
      E('path', { d: 'M266 210C230 200 226 120 240 80M266 210C302 200 306 120 292 80', stroke: Rg.c, 'stroke-width': 3, fill: 'none' }, g);
      T(g, 266, 236, 'আধুনিক ভুট্টা — শত শত দানা', { fs: 10.5, a: 'middle', w: 650, c: C.fg });
      E('path', { d: 'M110 120H220', stroke: C.mu, 'stroke-width': 2 }, g); E('path', { d: 'M224 120l-8 -4v8Z', fill: C.mu }, g); T(g, 165, 110, 'প্রায় ৯০০০ বছর নির্বাচন', { fs: 9.5, a: 'middle', c: C.mu });
    } else {
      const box = (x, y, s, sub, R) => { E('rect', { x: x - 46, y: y - 16, width: 92, height: 32, rx: 8, fill: FK.alpha(R.c, .2), stroke: R.dk }, g); T(g, x, y - 1, s, { fs: 10.5, a: 'middle', w: 650, c: R.ink }); T(g, x, y + 11, sub, { fs: 8.6, a: 'middle', c: C.mu }); };
      box(70, 50, 'AA (2n=14)', 'T. urartu', BK.ramp(2)); box(190, 50, 'BB (2n=14)', 'Aegilops-জাতীয়', BK.ramp(5)); box(130, 130, 'AABB (4n=28)', 'ইমার / পাস্তা গম', BK.ramp(3)); box(290, 130, 'DD (2n=14)', 'Ae. tauschii', BK.ramp(0)); box(210, 210, 'AABBDD (6n=42)', 'রুটির গম', BK.ramp(6));
      [[70, 66, 120, 114], [190, 66, 140, 114], [130, 146, 200, 194], [290, 146, 220, 194]].forEach(([a, b, c, d]) => { E('path', { d: `M${a} ${b}L${c} ${d}`, stroke: C.fg, 'stroke-width': 1.3 }, g); });
      T(g, 60, 104, 'সংকর + ক্রোমোসোম', { fs: 9, a: 'middle', c: C.mu }); T(g, 60, 116, 'দ্বিগুণ', { fs: 9, a: 'middle', c: C.mu }); T(g, 330, 186, 'প্রায় ৮–১০ হাজার', { fs: 9, a: 'end', c: C.mu }); T(g, 330, 198, 'বছর আগে', { fs: 9, a: 'end', c: C.mu });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return; const u = (t * .3) % 1;
    if (ty === 'bras') { const i = Math.floor((t * .4) % 6), a = -PI / 2 + i / 6 * PI * 2, x = 180 + 138 * Math.cos(a) * .95, y = 128 + 92 * Math.sin(a); E('circle', { cx: x, cy: y, r: 20 + 4 * Math.sin(t * 4), fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2 }, g); return; }
    if (ty === 'maize') { E('circle', { cx: 110 + u * 110, cy: 120, r: 4, fill: BK.ramp(6).c }, g); return; }
    const P = [[70, 66], [130, 114], [130, 146], [210, 194]], [x, y] = B.along(P, u); E('circle', { cx: x, cy: y, r: 4, fill: BK.ramp(6).c }, g);
  }
}));

/* ═════════ তুলনা ═════════ */
V.cmpNatArt = cmp('প্রাকৃতিক বনাম কৃত্রিম অঙ্গজ প্রজনন', 'দুটিতেই মাতৃগাছের অনুরূপ সন্তান — পার্থক্য মানুষের হস্তক্ষেপে।', 'প্রাকৃতিক অঙ্গজ প্রজনন', 'কৃত্রিম অঙ্গজ প্রজনন', [
  ['সংঘটন', 'প্রকৃতিতে নিজে নিজে ঘটে', 'মানুষ পরিকল্পিতভাবে ঘটায়'],
  ['অঙ্গ', 'রূপান্তরিত মূল, কাণ্ড, পাতা (কন্দ, রাইজোম, রানার)', 'সাধারণ শাখা, মুকুল, টিস্যু'],
  ['পদ্ধতি', 'অঙ্গটি মাতৃগাছ থেকে আলাদা হয়ে নতুন গাছ', 'কাটিং, লেয়ারিং, গুটি, জোড়, চোখ কলম, টিস্যু কালচার'],
  ['উদ্দেশ্য', 'প্রজাতির বিস্তার ও টিকে থাকা', 'উন্নত জাত সংরক্ষণ, তাড়াতাড়ি ফল, বীজহীন ফসলের চাষ'],
  ['উদাহরণ', 'আলু, আদা, পেঁয়াজ, থানকুনি, পাথরকুচি', 'আমের জোড় কলম, লিচুর গুটি কলম, গোলাপের শাখা কলম, কলার টিস্যু কালচার']
]);
V.cmpGraftBud = cmp('জোড় কলম বনাম চোখ কলম', 'দুটিতেই স্টক ও সায়নের ক্যাম্বিয়াম মিলতে হয়।', 'জোড় কলম (গ্রাফটিং)', 'চোখ কলম (বাডিং)', [
  ['সায়ন', 'কয়েকটি মুকুলযুক্ত একটি শাখা', 'ছালসহ একটি মুকুল (চোখ)'],
  ['সায়ন গাছের ব্যবহার', 'এক শাখায় একটি কলম', 'এক শাখা থেকে অনেক কলম — সাশ্রয়ী'],
  ['পদ্ধতি', 'ক্লেফট, ভিনিয়ার, অ্যাপ্রোচ ইত্যাদি', 'T-বাডিং, প্যাচ বাডিং'],
  ['স্টকের পুরুত্ব', 'মাঝারি বা মোটা', 'কচি, ছাল সহজে আলগা হয় এমন'],
  ['উদাহরণ', 'আম, কাঁঠাল, কুল', 'গোলাপ, কুল, লেবু, আপেল']
]);

/* ═════════ অধ্যায়ের মানচিত্র ═════════ */
V.b1c10map = Object.assign({ t: 'অধ্যায় ১০ এর মানচিত্র', k: ['mind', 'int'], cap: 'উদ্ভিদ প্রজনন এক নজরে — যৌন প্রজনন (গ্যামেটোফাইট, পরাগায়ন, দ্বিনিষেক, বীজ-ফল), অযৌন প্রজনন ও অ্যাপোমিক্সিস, কৃত্রিম প্রজনন। যেকোনো শাখায় চাপ দিলে পাঠে যাবে।' }, BK.mind({
  t: 'উদ্ভিদ প্রজনন', d: 'নতুন উদ্ভিদ সৃষ্টির প্রক্রিয়া।',
  c: [
    { t: 'গ্যামেটোফাইট', d: 'পরাগরেণু ও ভ্রূণথলি।', c: [{ t: 'যৌন প্রজনন', id: 'b1c10s1a' }, { t: 'পরাগরেণু', id: 'b1c10s1b' }, { t: 'পুংগ্যামেটোফাইট', id: 'b1c10s1c' }, { t: 'স্ত্রীগ্যামেটোফাইট', id: 'b1c10s1d' }] },
    { t: 'পরাগায়ন ও নিষেক', d: 'দ্বিনিষেক ও বীজ-ফল।', c: [{ t: 'পরাগায়ন', id: 'b1c10s2a' }, { t: 'নিষেক', id: 'b1c10s2b' }, { t: 'নিষেক বনাম দ্বিনিষেক', id: 'b1c10s2c' }, { t: 'বীজ ও ফল', id: 'b1c10s2e' }] },
    { t: 'অযৌন প্রজনন', d: 'অঙ্গজ ও অ্যাপোমিক্সিস।', c: [{ t: 'অঙ্গজ প্রজনন', id: 'b1c10s3a' }, { t: 'অপুংজনি', id: 'b1c10s3b' }, { t: 'অ্যাপোস্পোরি', id: 'b1c10s3d' }, { t: 'অ্যাপোগ্যামি', id: 'b1c10s3e' }] },
    { t: 'কৃত্রিম প্রজনন', d: 'কলম, টিস্যু কালচার, সংকরায়ণ।', c: [{ t: 'কৃত্রিম প্রজনন', id: 'b1c10s4a' }, { t: 'বিবর্তনে ভূমিকা', id: 'b1c10s4b' }, { t: 'অর্থনৈতিক গুরুত্ব', id: 'b1c10s4c' }] }
  ]
}, { colW: 112 }));
})();
