/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §১০.৩ অযৌন প্রজনন, অঙ্গজ প্রজনন, অপুংজনি, অ্যাপোস্পোরি, অ্যাপোগ্যামি, পলিএমব্রায়োনি
   asexTypes  : অযৌন প্রজননের ধরন — বিভাজন, খণ্ডায়ন, মুকুলোদগম, রেণু, অঙ্গজ
   vegProp    : প্রাকৃতিক অঙ্গজ প্রজনন — মূল, ভূনিম্নস্থ কাণ্ড, অর্ধবায়বীয় কাণ্ড, পাতা (চাপ দিলে উদাহরণ)
   lifeLoop   : জনুক্রম ও তার শর্টকাট — স্বাভাবিক, অপুংজনি, অ্যাপোস্পোরি, অ্যাপোগ্যামি
   polyEmb    : পলিএমব্রায়োনি ও অ্যাপোমিক্সিস — নিউসেলার ভ্রূণ (লেবু), ক্লিভেজ, একাধিক ভ্রূণথলি
   cmpParthSex, cmpAsexSex, cmpAposApog : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B10;
const PI = Math.PI, ch = B.ch, cl = B.cl, rnd = B.rnd, node = B.node, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const nuc = (g, x, y, r, R, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.c, stroke: R.dk, 'stroke-width': 1, opacity: o.op != null ? o.op : 1 }, g); if (o.nl !== false && r > 3) E('circle', { cx: x - r * .3, cy: y - r * .3, r: r * .28, fill: R.dk, opacity: .55 }, g); };
const ground = (g, y = 120) => { E('rect', { x: 0, y, width: 360, height: 250 - y, fill: FK.alpha(BK.ramp(11).c, .3) }, g); E('path', { d: `M0 ${y}H360`, stroke: BK.ramp(11).dk, 'stroke-width': 1.4 }, g); };
const leaf = (g, x, y, a, L, R, o = {}) => { const c = Math.cos(a), s = Math.sin(a), px = -s, py = c, w = L * (o.w || .32); E('path', { d: `M${x} ${y}Q${x + c * L * .5 + px * w} ${y + s * L * .5 + py * w} ${x + c * L} ${y + s * L}Q${x + c * L * .5 - px * w} ${y + s * L * .5 - py * w} ${x} ${y}Z`, fill: o.fill || R.c, stroke: R.dk, 'stroke-width': 1 }, g); };
const sprout = (g, x, y, h, R) => { E('path', { d: `M${x} ${y}V${y - h}`, stroke: R.dk, 'stroke-width': 2.4 }, g); leaf(g, x, y - h, -PI / 2 - .7, h * .7, R); leaf(g, x, y - h, -PI / 2 + .7, h * .7, R); };
const roots = (g, x, y, n = 4, L = 22) => { for (let i = 0; i < n; i++) { const a = PI / 2 + (i - (n - 1) / 2) * .45; E('path', { d: `M${x} ${y}q${Math.cos(a) * L * .4} ${L * .5} ${Math.cos(a) * L} ${Math.sin(a) * L}`, stroke: BK.ramp(11).dk, 'stroke-width': 1.2, fill: 'none' }, g); } };

/* ═════════ ১. অযৌন প্রজননের ধরন ═════════ */
V.asexTypes = Object.assign({}, B.seg({
  id: 'ax', t: 'অযৌন প্রজননের বিভিন্ন উপায়', H: 230, def: 'fis',
  cap: 'গ্যামেট সৃষ্টি ও নিষেক ছাড়া একটি জীব থেকে নতুন জীব সৃষ্টিকে অযৌন প্রজনন বলে — মাইটোসিস নির্ভর, তাই সন্তান মাতৃজীবের হুবহু অনুরূপ (ক্লোন)। ধরন বদলাও।',
  types: {
    fis: ['বিভাজন', 'দ্বিবিভাজন (ফিশন)', 'এককোষী জীব দুই ভাগে ভাগ হয় — ব্যাকটেরিয়া, ইস্ট (কিছু), অ্যামিবা।'],
    frag: ['খণ্ডায়ন', 'খণ্ডায়ন (ফ্র্যাগমেন্টেশন)', 'সূত্রাকার দেহ কয়েক খণ্ডে ভেঙে প্রতিটি খণ্ড নতুন জীব — Spirogyra, Ulothrix, কিছু ছত্রাক ও মস।'],
    bud: ['মুকুলোদগম', 'মুকুলোদগম (বাডিং)', 'দেহ থেকে ছোট মুকুল বেরিয়ে বড় হয়ে আলাদা হয় — ইস্ট (Saccharomyces), হাইড্রা।'],
    spore: ['রেণু', 'রেণু উৎপাদন (স্পোর)', 'রেণুস্থলীতে মাইটোসিসে অসংখ্য রেণু তৈরি হয়, ছড়িয়ে নতুন জীব — Mucor, Penicillium (কনিডিয়া), Chlamydomonas (জুস্পোর)।'],
    veg: ['অঙ্গজ', 'অঙ্গজ প্রজনন', 'উচ্চ উদ্ভিদের মূল, কাণ্ড বা পাতার অংশ থেকে নতুন উদ্ভিদ — আলু, আদা, পাথরকুচি। পরের চিত্রে বিস্তারিত।']
  },
  art(g, C, ty) {
    const R = ty === 'veg' ? BK.ramp(10) : ty === 'spore' ? BK.ramp(9) : BK.ramp(0);
    if (ty === 'frag') { for (let i = 0; i < 12; i++) { const x = 30 + i * 25; E('rect', { x, y: 104, width: 24, height: 22, rx: 4, fill: FK.alpha(BK.ramp(10).c, .35), stroke: BK.ramp(10).dk }, g); E('path', { d: `M${x + 4} 108q8 6 16 0t0 14`, stroke: BK.ramp(10).dk, fill: 'none' }, g); } T(g, 180, 200, 'সূত্র ভেঙে খণ্ড → প্রতিটি নতুন সূত্র', { fs: 10.5, a: 'middle', c: C.mu }); return; }
    if (ty === 'spore') { E('path', { d: 'M180 220V110', stroke: R.dk, 'stroke-width': 2 }, g); E('circle', { cx: 180, cy: 90, r: 26, fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.6 }, g); for (let i = 0; i < 14; i++) E('circle', { cx: 180 + (rnd(i) - .5) * 34, cy: 90 + (rnd(i + 5) - .5) * 34, r: 2.6, fill: R.dk }, g); T(g, 230, 70, 'রেণুস্থলী', { fs: 10, c: R.ink }); E('path', { d: 'M0 220H360', stroke: BK.ramp(11).dk }, g); return; }
    if (ty === 'veg') { ground(g, 130); E('ellipse', { cx: 180, cy: 170, rx: 44, ry: 28, fill: BK.ramp(6).lt, stroke: BK.ramp(6).dk }, g); [[156, 160], [190, 150], [206, 176]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 3, fill: BK.ramp(6).dk }, g)); T(g, 180, 222, 'আলুর চোখ (মুকুল) থেকে নতুন গাছ', { fs: 10.5, a: 'middle', c: C.mu }); return; }
  },
  anim(g, C, ty, t) {
    const u = t ? (t * .25) % 1 : .5, k = FK.ease(cl(u * 1.4)), R = BK.ramp(0);
    if (ty === 'fis') { const d = 36 * k; [-1, 1].forEach(s => { E('ellipse', { cx: 180 + s * d, cy: 115, rx: 40 - 8 * k, ry: 26, fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4 }, g); E('path', { d: `M${180 + s * d - 14} 115q14 -8 28 0`, stroke: BK.ramp(3).dk, 'stroke-width': 2, fill: 'none' }, g); }); T(g, 180, 200, '১ → ২ (মাইটোসিস)', { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    if (ty === 'bud') { E('ellipse', { cx: 160, cy: 115, rx: 44, ry: 34, fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4 }, g); nuc(g, 156, 115, 9, BK.ramp(3)); const r = 6 + 22 * k; E('circle', { cx: 204 + r * .8, cy: 100 - r * .2, r, fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4 }, g); if (k > .5) nuc(g, 204 + r * .8, 100 - r * .2, 5, BK.ramp(3)); T(g, 180, 200, 'ইস্টের মুকুল', { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    if (ty === 'frag') { for (let i = 0; i < 3; i++) E('path', { d: `M${80 + i * 100} 100v30`, stroke: BK.ramp(4).c, 'stroke-width': 2, 'stroke-dasharray': '3 2', opacity: k }, g); return; }
    if (ty === 'spore') { for (let i = 0; i < 10; i++) { const v = (t * .3 + i / 10) % 1, a = i / 10 * PI * 2; E('circle', { cx: 180 + Math.cos(a) * (28 + v * 110), cy: 90 + Math.sin(a) * (20 + v * 60) + v * 40, r: 2.4, fill: BK.ramp(9).c, opacity: 1 - v }, g); } return; }
    sprout(g, 190, 150, 10 + 40 * k, BK.ramp(10));
  }
}));

/* ═════════ ২. প্রাকৃতিক অঙ্গজ প্রজনন ═════════ */
const VPt = {
  root: ['মূল', 'রূপান্তরিত মূল', 'কন্দাল মূলের গায়ের মুকুল থেকে নতুন গাছ — মিষ্টি আলু, ডালিয়া, শতমূলী; কিছু গাছের মূল থেকে মুকুল (মূলজ মুকুল) — পেয়ারা, কামিনী (Murraya)।'],
  under: ['ভূনিম্নস্থ কাণ্ড', 'মাটির নিচের রূপান্তরিত কাণ্ড', 'খাদ্য জমা করে, পর্ব-পর্বমধ্য ও মুকুল (চোখ) থাকে — কন্দ (টিউবার): আলু; রাইজোম: আদা, হলুদ; কন্দ-গুঁড়ি (কর্ম): ওলকচু, মানকচু; কন্দ (বাল্ব): পেঁয়াজ, রসুন।'],
  sub: ['অর্ধবায়বীয় কাণ্ড', 'অর্ধবায়বীয় (মাটির ওপর-নিচ) কাণ্ড', 'রানার: থানকুনি, দূর্বা — মাটির ওপর লম্বা পর্বমধ্য, পর্ব থেকে মূল ও পাতা; স্টোলন: কচু — বাঁকা হয়ে মাটি ছোঁয়; সাকার: চন্দ্রমল্লিকা, কলা, পুদিনা — মাটির নিচ থেকে তির্যকভাবে উঠে আসে; অফসেট: কচুরিপানা, টোপাপানা — ছোট মোটা পর্বমধ্য, পানিতে।'],
  leaf: ['পাতা', 'পাতা থেকে প্রজনন', 'পাথরকুচির (Bryophyllum) পাতার কিনারার খাঁজে অস্থানিক মুকুল থেকে চারা; বেগোনিয়ার পাতা কেটে মাটিতে রাখলে শিরা থেকে চারা।']
};
const VPhot = {
  root: [['মিষ্টি আলুর কন্দাল মূল', 'কন্দাল মূলের গায়ে অস্থানিক মুকুল; লতা ছেঁটেও লাগানো যায়।', 130, 170]],
  under: [['আলু — কন্দ', 'স্ফীত কাণ্ডের "চোখ" প্রতিটি একটি কাক্ষিক মুকুল।', 60, 170], ['আদা — রাইজোম', 'অনুভূমিক, শল্কপত্রযুক্ত পর্ব ও মুকুল।', 160, 160], ['ওলকচু — কর্ম', 'খাড়া, গোলাকার, শীর্ষে মুকুল।', 250, 170], ['পেঁয়াজ — বাল্ব', 'ছোট চাকতির মতো কাণ্ড ঘিরে রসালো শল্কপত্র।', 320, 170]],
  sub: [['থানকুনি — রানার', 'মাটির ওপর লতানো; প্রতিটি পর্বে মূল ও পাতা।', 90, 112], ['কচুরিপানা — অফসেট', 'পানিতে ভাসমান; ছোট মোটা পর্বমধ্য।', 280, 100], ['চন্দ্রমল্লিকা — সাকার', 'মাটির নিচের পর্ব থেকে উঠে আসা শাখা।', 190, 140]],
  leaf: [['পাথরকুচি — পত্রাশ্রয়ী মুকুল', 'পাতার কিনারার খাঁজে মুকুল থেকে চারা; পাতা মাটিতে পড়লে নতুন গাছ।', 180, 110]]
};
V.vegProp = Object.assign({}, B.seg({
  id: 'vp', t: 'প্রাকৃতিক অঙ্গজ প্রজনন', H: 250, def: 'under',
  cap: 'উচ্চ শ্রেণির উদ্ভিদের মূল, কাণ্ড বা পাতা — অর্থাৎ অঙ্গজ অংশ থেকে নতুন উদ্ভিদ সৃষ্টিকে অঙ্গজ প্রজনন বলে। প্রকৃতিতে নিজে নিজে ঘটলে প্রাকৃতিক, মানুষ ঘটালে কৃত্রিম অঙ্গজ প্রজনন। ধরন বদলাও, গাছে চাপ দাও।',
  types: VPt,
  art(g, C, ty, ctx) {
    const Rg = BK.ramp(10), Rb = BK.ramp(6), Rw = BK.ramp(11), sel = ctx.sel;
    if (ty === 'root') { ground(g, 100); E('path', { d: 'M180 100V60', stroke: Rg.dk, 'stroke-width': 3 }, g); leaf(g, 180, 60, -2.3, 30, Rg, { w: .5 }); leaf(g, 180, 60, -.8, 30, Rg, { w: .5 }); [[130, 170, -.4], [236, 176, .5]].forEach(([x, y, a]) => { E('path', { d: `M180 104Q${(x + 180) / 2} ${y - 50} ${x} ${y}`, stroke: Rw.dk, 'stroke-width': 2, fill: 'none' }, g); E('ellipse', { cx: x, cy: y, rx: 34, ry: 16, transform: `rotate(${a * 57} ${x} ${y})`, fill: BK.ramp(8).lt, stroke: BK.ramp(8).dk }, g); roots(g, x + 30, y + 8, 3, 14); }); sprout(g, 130, 156, 46, Rg); T(g, 180, 238, 'কন্দাল মূল (মিষ্টি আলু)', { fs: 10.5, a: 'middle', c: C.mu }); }
    if (ty === 'under') {
      ground(g, 120);
      E('ellipse', { cx: 60, cy: 170, rx: 30, ry: 20, fill: Rb.lt, stroke: Rb.dk }, g); [[48, 162], [70, 160], [62, 180]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 2.6, fill: Rb.dk }, g)); sprout(g, 70, 152, 50, Rg);
      E('path', { d: 'M120 166Q140 152 160 162Q178 150 200 164Q186 176 160 172Q140 180 120 166Z', fill: BK.ramp(6).c, stroke: BK.ramp(6).dk }, g); for (let i = 0; i < 4; i++) E('path', { d: `M${128 + i * 18} 160v12`, stroke: BK.ramp(6).dk, 'stroke-width': .8 }, g); sprout(g, 196, 156, 54, Rg); roots(g, 150, 174, 3, 14);
      E('ellipse', { cx: 250, cy: 172, rx: 22, ry: 18, fill: FK.alpha(Rw.c, .5), stroke: Rw.dk }, g); sprout(g, 250, 154, 46, Rg); roots(g, 250, 190, 4, 16);
      E('path', { d: 'M320 150C300 156 302 190 320 192C338 190 340 156 320 150Z', fill: BK.ramp(8).lt, stroke: BK.ramp(8).dk }, g); E('path', { d: 'M320 150C310 158 312 186 320 190', stroke: BK.ramp(8).dk, fill: 'none' }, g); E('rect', { x: 310, y: 190, width: 20, height: 5, fill: Rw.dk }, g); roots(g, 320, 196, 5, 14); E('path', { d: 'M320 150V80', stroke: Rg.dk, 'stroke-width': 3 }, g); E('path', { d: 'M318 120Q304 90 300 70M322 120Q334 92 342 74', stroke: Rg.c, 'stroke-width': 3, fill: 'none' }, g);
      [['আলু', 60], ['আদা', 160], ['ওলকচু', 250], ['পেঁয়াজ', 320]].forEach(([n, x]) => T(g, x, 232, n, { fs: 10.5, a: 'middle', w: 600, c: C.fg }));
    }
    if (ty === 'sub') {
      ground(g, 120); E('rect', { x: 230, y: 92, width: 130, height: 28, fill: FK.alpha(BK.ramp(5).c, .3) }, g);
      E('path', { d: 'M20 118Q60 108 90 118T160 118', stroke: Rg.dk, 'stroke-width': 2.4, fill: 'none' }, g); [20, 90, 160].forEach(x => { roots(g, x, 120, 3, 12); E('path', { d: `M${x} 118V100`, stroke: Rg.dk, 'stroke-width': 1.6 }, g); E('circle', { cx: x, cy: 94, r: 9, fill: Rg.c, stroke: Rg.dk }, g); });
      E('path', { d: 'M190 200Q192 160 190 124', stroke: Rg.dk, 'stroke-width': 2.4, fill: 'none' }, g); E('path', { d: 'M150 200H230', stroke: Rw.dk, 'stroke-width': 4 }, g); sprout(g, 190, 124, 30, Rg);
      [250, 300].forEach((x, i) => { E('ellipse', { cx: x, cy: 98, rx: 10, ry: 8, fill: BK.ramp(5).lt, stroke: BK.ramp(5).dk }, g); leaf(g, x, 92, -PI / 2 - .5, 22, Rg, { w: .6 }); leaf(g, x, 92, -PI / 2 + .5, 22, Rg, { w: .6 }); roots(g, x, 106, 4, 14); }); E('path', { d: 'M260 98H290', stroke: Rg.dk, 'stroke-width': 2 }, g);
      T(g, 90, 232, 'রানার (থানকুনি)', { fs: 10, a: 'middle', c: C.fg }); T(g, 190, 232, 'সাকার', { fs: 10, a: 'middle', c: C.fg }); T(g, 290, 232, 'অফসেট (কচুরিপানা)', { fs: 10, a: 'middle', c: C.fg });
    }
    if (ty === 'leaf') {
      ground(g, 196);
      const L = [[110, 120], [180, 96], [250, 120]]; E('path', { d: 'M80 140Q180 40 280 140Q180 190 80 140Z', fill: FK.alpha(Rg.c, .55), stroke: Rg.dk, 'stroke-width': 1.6 }, g);
      for (let i = 0; i < 7; i++) { const u = i / 6, x = 84 + u * 192, y = 140 - Math.sin(u * PI) * 50 * (1 - .1); sprout(g, x, y - 2, 12, Rg); roots(g, x, y + 2, 2, 8); }
      T(g, 180, 222, 'পাথরকুচি পাতার কিনারায় চারা', { fs: 10.5, a: 'middle', c: C.mu }); void L;
    }
    if (sel != null) { const h = VPhot[ty][sel]; if (h) E('circle', { cx: h[2], cy: h[3], r: 26, fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 2, 'stroke-dasharray': '4 3' }, g); }
  },
  anim(g, C, ty, t) { if (!t) return; const k = (Math.sin(t * 1.4) + 1) / 2; VPhot[ty].forEach(h => E('circle', { cx: h[2], cy: h[3], r: 6 + 3 * k, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 1.4, opacity: .4 + .4 * k }, g)); },
  tap(x, y, ty, ctx) { let bi = null, bd = 40; VPhot[ty].forEach((h, i) => { const d = Math.hypot(x - h[2], y - h[3]); if (d < bd) { bd = d; bi = i; } }); ctx.sel = bi; if (bi == null) return ctx.def(); const h = VPhot[ty][bi]; return `<b>${h[0]}</b> — ${h[1]}`; }
}));

/* ═════════ ৩. জনুক্রম ও শর্টকাট ═════════ */
const LLn = { sp: [180, 40], mmc: [284, 92], spo: [284, 180], gam: [180, 222], gmt: [76, 180], zyg: [76, 92] };
const LLlab = { sp: ['স্পোরোফাইট', '2n'], mmc: ['রেণু মাতৃকোষ', '2n'], spo: ['রেণু (মেগাস্পোর)', 'n'], gam: ['গ্যামেটোফাইট (ভ্রূণথলি)', 'n'], gmt: ['ডিম্বাণু + পুংগ্যামেট', 'n'], zyg: ['জাইগোট', '2n'] };
const LLorder = ['sp', 'mmc', 'spo', 'gam', 'gmt', 'zyg'];
const LLedge = { 'sp-mmc': 'রেণুস্থলী', 'mmc-spo': 'মিয়োসিস', 'spo-gam': 'মাইটোসিস', 'gam-gmt': 'গ্যামেট সৃষ্টি', 'gmt-zyg': 'নিষেক', 'zyg-sp': 'মাইটোসিস' };
const LLskip = {
  parth: { from: 'gmt', to: 'sp', via: [70, 40], txt: 'নিষেক ছাড়াই ডিম্বাণু → ভ্রূণ', skip: ['gmt-zyg', 'zyg-sp'] },
  apos: { from: 'mmc', to: 'gam', via: [246, 214], txt: 'মিয়োসিস ও রেণু ছাড়াই দেহকোষ → গ্যামেটোফাইট (2n)', skip: ['mmc-spo', 'spo-gam'] },
  apog: { from: 'gam', to: 'sp', via: [150, 120], txt: 'গ্যামেট ও নিষেক ছাড়াই গ্যামেটোফাইটের কোষ → স্পোরোফাইট', skip: ['gam-gmt', 'gmt-zyg', 'zyg-sp'] }
};
V.lifeLoop = Object.assign({}, B.seg({
  id: 'll', t: 'জনুক্রম ও অযৌন জননের শর্টকাট', H: 250, def: 'norm',
  cap: 'যৌন জীবনচক্রে দুটি "বড় ধাপ" — মিয়োসিস (2n → n) ও নিষেক (n → 2n)। অপুংজনি, অ্যাপোস্পোরি ও অ্যাপোগ্যামি এর কোনো একটি বা দুটি ধাপ এড়িয়ে যায় — এগুলোকে একত্রে অ্যাপোমিক্সিস বলা হয় (যৌন অঙ্গ থাকা সত্ত্বেও যৌন মিলন ছাড়া প্রজনন)। ধরন বদলে কোন ধাপ বাদ পড়ল দেখো।',
  types: {
    norm: ['স্বাভাবিক', 'স্বাভাবিক যৌন জীবনচক্র (জনুক্রম)', 'স্পোরোফাইট (2n) → মিয়োসিস → রেণু (n) → গ্যামেটোফাইট (n) → গ্যামেট → নিষেক → জাইগোট (2n) → স্পোরোফাইট। আবৃতবীজীতে গ্যামেটোফাইট খুব ক্ষুদ্র (ভ্রূণথলি, পরাগরেণু)।'],
    parth: ['অপুংজনি', 'অপুংজনি (পার্থেনোজেনেসিস)', 'অনিষিক্ত ডিম্বাণু থেকে সরাসরি ভ্রূণ — হ্যাপ্লয়েড (ডিম্বাণু n হলে, যেমন Solanum nigrum কিছু ক্ষেত্রে) অথবা ডিপ্লয়েড (অ্যাপোস্পোরির ফলে ডিম্বাণু 2n হলে)। প্রাণীতে: মৌমাছির পুরুষ (ড্রোন)। উদ্ভিদে: Taraxacum (ড্যান্ডেলিয়ন), Parthenium — ডিপ্লয়েড অপুংজনি।'],
    apos: ['অ্যাপোস্পোরি', 'অ্যাপোস্পোরি', 'স্পোরোফাইটের কোনো দেহকোষ (2n, যেমন নিউসেলাস বা আবরণীর কোষ) মিয়োসিস ও রেণু সৃষ্টি ছাড়াই সরাসরি গ্যামেটোফাইট তৈরি করে — ফলে গ্যামেটোফাইট ডিপ্লয়েড। ফার্নে (Pteridium, Athyrium) পাতা থেকে প্রোথ্যালাস; আবৃতবীজীতে Hieracium, Ranunculus।'],
    apog: ['অ্যাপোগ্যামি', 'অ্যাপোগ্যামি', 'গ্যামেটোফাইটের ডিম্বাণু ছাড়া অন্য কোনো কোষ (সহকারী, প্রতিপাদ কোষ বা প্রোথ্যালাসের দেহকোষ) গ্যামেট সৃষ্টি ও নিষেক ছাড়াই সরাসরি স্পোরোফাইট (ভ্রূণ) তৈরি করে। ফার্নে (Dryopteris, Pteris) প্রথম দেখান ফারলো (1874); আবৃতবীজীতে কিছু Allium (সহকারী কোষ থেকে), Alchemilla।']
  },
  art(g, C, ty) {
    const sk = LLskip[ty], off = sk ? sk.skip : [];
    LLorder.forEach((a, i) => { const b = LLorder[(i + 1) % 6], key = a + '-' + b, [x1, y1] = LLn[a], [x2, y2] = LLn[b], mx = (x1 + x2) / 2 + (x1 + x2 - 360) * .08, my = (y1 + y2) / 2 + (y1 + y2 - 250) * .08, gone = off.includes(key);
      E('path', { d: `M${x1} ${y1}Q${mx} ${my} ${x2} ${y2}`, stroke: gone ? C.mu : C.fg, 'stroke-width': gone ? 1 : 1.6, fill: 'none', 'stroke-dasharray': gone ? '3 4' : null, opacity: gone ? .5 : 1 }, g);
      T(g, mx + (mx < 180 ? -4 : 4), my + (my < 125 ? -4 : 12), LLedge[key], { fs: 9.5, a: mx < 160 ? 'end' : mx > 200 ? 'start' : 'middle', c: gone ? C.mu : (key === 'mmc-spo' || key === 'gmt-zyg' ? BK.ramp(4).ink : C.mu), w: key === 'mmc-spo' || key === 'gmt-zyg' ? 650 : 400 }); });
    LLorder.forEach(k => { const [x, y] = LLn[k], [n, p] = LLlab[k]; let pl = p; if (ty === 'apos' && (k === 'gam' || k === 'gmt')) pl = '2n'; const R = pl === '2n' ? BK.ramp(10) : BK.ramp(2), gone = sk && ((ty === 'apos' && k === 'spo') || (ty === 'apog' && (k === 'gmt' || k === 'zyg')) || (ty === 'parth' && k === 'zyg'));
      E('rect', { x: x - 46, y: y - 15, width: 92, height: 30, rx: 10, fill: FK.alpha(R.c, gone ? .06 : .2), stroke: gone ? C.mu : R.dk, 'stroke-dasharray': gone ? '3 3' : null }, g); T(g, x, y - 1, n, { fs: n.length > 14 ? 8.6 : 9.8, a: 'middle', w: 600, c: gone ? C.mu : R.ink }); T(g, x, y + 11, pl, { fs: 9, a: 'middle', w: 650, c: gone ? C.mu : R.ink }); });
    if (sk) { const [x1, y1] = LLn[sk.from], [x2, y2] = LLn[sk.to]; E('path', { d: `M${x1} ${y1}Q${sk.via[0]} ${sk.via[1]} ${x2} ${y2}`, stroke: BK.ramp(8).c, 'stroke-width': 3, fill: 'none' }, g); T(g, 180, 128, sk.txt, { fs: 10, a: 'middle', w: 650, c: BK.ramp(8).ink }); }
  },
  anim(g, C, ty, t) {
    if (!t) return; const sk = LLskip[ty];
    if (sk) { const u = (t * .3) % 1, [x1, y1] = LLn[sk.from], [x2, y2] = LLn[sk.to], r = 1 - u, x = r * r * x1 + 2 * r * u * sk.via[0] + u * u * x2, y = r * r * y1 + 2 * r * u * sk.via[1] + u * u * y2; E('circle', { cx: x, cy: y, r: 5, fill: BK.ramp(8).c, stroke: '#fff', 'stroke-width': 1.4 }, g); return; }
    const u = (t * .12) % 1, i = Math.floor(u * 6), q = u * 6 - i, a = LLorder[i], b = LLorder[(i + 1) % 6], [x1, y1] = LLn[a], [x2, y2] = LLn[b], mx = (x1 + x2) / 2 + (x1 + x2 - 360) * .08, my = (y1 + y2) / 2 + (y1 + y2 - 250) * .08, r = 1 - q;
    E('circle', { cx: r * r * x1 + 2 * r * q * mx + q * q * x2, cy: r * r * y1 + 2 * r * q * my + q * q * y2, r: 5, fill: BK.ramp(6).c, stroke: '#fff', 'stroke-width': 1.4 }, g);
  }
}));

/* ═════════ ৪. পলিএমব্রায়োনি ═════════ */
V.polyEmb = Object.assign({}, B.seg({
  id: 'pe', t: 'পলিএমব্রায়োনি (বহুভ্রূণতা)', H: 240, def: 'nuc',
  cap: 'একটি বীজে একাধিক ভ্রূণ থাকলে তাকে পলিএমব্রায়োনি বলে — প্রথম দেখান লিউয়েনহুক (1719, কমলালেবুর বীজে)। সাধারণত একটি ভ্রূণ যৌন (জাইগোটিক), বাকিগুলো অযৌন — মাতৃগাছের হুবহু অনুরূপ। ধরন বদলাও।',
  types: {
    nuc: ['নিউসেলার', 'অস্থানিক ভ্রূণ — নিউসেলাস থেকে', 'ভ্রূণথলির বাইরের নিউসেলাস বা আবরণীর দেহকোষ (2n) বিভাজিত হয়ে ভ্রূণথলিতে ঢুকে ভ্রূণ হয় — লেবু, কমলা (Citrus), আম (কিছু জাত), জাম। এগুলো মাতৃগাছের ক্লোন — তাই রোগমুক্ত, একই গুণের চারা পেতে উদ্যানবিদ্যায় কাজে লাগে।'],
    cleav: ['ক্লিভেজ', 'জাইগোট/প্রোএমব্রায়োর বিভাজন (ক্লিভেজ)', 'প্রোএমব্রায়ো ভেঙে একাধিক ভ্রূণ — সবগুলো যৌন এবং পরস্পরের অনুরূপ (যমজের মতো)। নগ্নবীজীতে (Pinus) সাধারণ; আবৃতবীজীতে অর্কিড (Eulophia)।'],
    multi: ['একাধিক ভ্রূণথলি', 'একটি ডিম্বকে একাধিক ভ্রূণথলি', 'একই ডিম্বকে একাধিক ভ্রূণথলি তৈরি হয়ে প্রতিটিতে ভ্রূণ — Citrus, Casuarina। অথবা সহকারী বা প্রতিপাদ কোষ থেকে ভ্রূণ (অ্যাপোগ্যামি)।']
  },
  art(g, C, ty) {
    const Rw = BK.ramp(11), R2 = BK.ramp(10), Rn_ = BK.ramp(2), Re = BK.ramp(0), Rp = BK.ramp(8);
    E('ellipse', { cx: 180, cy: 124, rx: 150, ry: 96, fill: FK.alpha(Rw.c, .3), stroke: Rw.dk, 'stroke-width': 1.6 }, g); E('ellipse', { cx: 180, cy: 124, rx: 132, ry: 80, fill: FK.alpha(R2.c, .18), stroke: R2.dk }, g); T(g, 58, 40, 'নিউসেলাস (2n)', { fs: 10, c: R2.ink });
    const sacs = ty === 'multi' ? [[130, 124], [230, 124]] : [[180, 124]];
    sacs.forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: ty === 'multi' ? 44 : 90, ry: 46, fill: FK.alpha(BK.ramp(7).c, .2), stroke: Rn_.dk }, g));
    T(g, 180, 232, ty === 'nuc' ? 'সবুজ = যৌন ভ্রূণ, গোলাপি = নিউসেলার (অযৌন) ভ্রূণ' : ty === 'cleav' ? 'একটি প্রোএমব্রায়ো → কয়েকটি যমজ ভ্রূণ' : 'প্রতিটি ভ্রূণথলিতে একটি ভ্রূণ', { fs: 10, a: 'middle', c: C.mu });
    void Re; void Rp;
  },
  anim(g, C, ty, t) {
    const u = t ? (t * .2) % 1 : .7, k = FK.ease(cl(u * 1.3)), Re = BK.ramp(0), Rp = BK.ramp(8);
    const emb = (x, y, r, R) => { E('circle', { cx: x, cy: y, r, fill: FK.alpha(R.c, .55), stroke: R.dk, 'stroke-width': 1.4 }, g); E('path', { d: `M${x - r} ${y}h${-r * .8}`, stroke: R.dk, 'stroke-width': 2 }, g); };
    if (ty === 'nuc') { emb(130, 124, 14, Re); [[210, 90], [236, 140], [180, 160]].forEach(([x, y], i) => { const sx = x + (x - 180) * .9 * (1 - k), sy = y + (y - 124) * 1.0 * (1 - k); emb(sx, sy, 6 + 8 * k, Rp); }); return; }
    if (ty === 'cleav') { const d = 22 * k; [[-1, -1], [1, -1], [0, 1]].forEach(([a, b]) => emb(180 + a * d, 124 + b * d * .8, 14 - 4 * k, Re)); return; }
    emb(130, 124, 10 + 4 * k, Re); emb(230, 124, 10 + 4 * k, Re);
  }
}));

/* ═════════ তুলনা ═════════ */
V.cmpParthSex = cmp('পার্থেনোজেনেসিস বনাম যৌন জনন', 'অপুংজনিতে ডিম্বাণু আছে, কিন্তু পুংগ্যামেটের সাথে মিলন নেই।', 'পার্থেনোজেনেসিস (অপুংজনি)', 'যৌন জনন', [
  ['নিষেক', 'হয় না — অনিষিক্ত ডিম্বাণু থেকে ভ্রূণ', 'পুং ও স্ত্রীগ্যামেটের মিলন (নিষেক) ঘটে'],
  ['প্রয়োজনীয় গ্যামেট', 'শুধু স্ত্রীগ্যামেট', 'পুং ও স্ত্রী — দুই ধরনের গ্যামেট'],
  ['সন্তানের ক্রোমোসোম', 'হ্যাপ্লয়েড বা ডিপ্লয়েড (মাতৃসম)', 'ডিপ্লয়েড — পিতা-মাতা দুজনের জিন'],
  ['বৈচিত্র্য', 'প্রায় নেই — মাতৃগাছের অনুরূপ', 'জিন পুনর্বিন্যাসে বৈচিত্র্য থাকে'],
  ['পরাগায়ন', 'প্রয়োজন নেই (কখনো উদ্দীপনা হিসেবে লাগে)', 'প্রয়োজন'],
  ['উদাহরণ', 'Taraxacum, Parthenium; মৌমাছির ড্রোন', 'অধিকাংশ উদ্ভিদ ও প্রাণী']
]);
V.cmpAsexSex = cmp('অযৌন প্রজনন বনাম যৌন প্রজনন', 'অযৌন প্রজনন দ্রুত ও নির্ভরযোগ্য; যৌন প্রজনন ধীর কিন্তু বৈচিত্র্যময়।', 'অযৌন প্রজনন', 'যৌন প্রজনন', [
  ['গ্যামেট', 'সৃষ্টি হয় না', 'পুং ও স্ত্রীগ্যামেট সৃষ্টি হয়'],
  ['নিষেক', 'নেই', 'আছে'],
  ['কোষ বিভাজন', 'শুধু মাইটোসিস', 'মিয়োসিস (গ্যামেট বা রেণু সৃষ্টিতে) ও মাইটোসিস'],
  ['জনিতা', 'একটি জীব যথেষ্ট', 'সাধারণত দুটি (বা একই উদ্ভিদের দুই অঙ্গ)'],
  ['সন্তান', 'মাতৃজীবের হুবহু অনুরূপ (ক্লোন)', 'পিতা-মাতা থেকে ভিন্ন — বৈচিত্র্যপূর্ণ'],
  ['গতি ও সংখ্যা', 'দ্রুত, অল্প সময়ে অনেক', 'তুলনামূলক ধীর'],
  ['বিবর্তনে ভূমিকা', 'কম — নতুন বৈশিষ্ট্য আসে কেবল মিউটেশনে', 'বেশি — নতুন জিন-সমন্বয়, অভিযোজন'],
  ['উদাহরণ', 'আলু, আদা, পাথরকুচি, ইস্টের মুকুলোদগম', 'ধান, আম, সরিষা — বীজ দিয়ে বংশবৃদ্ধি']
]);
V.cmpAposApog = cmp('অ্যাপোস্পোরি বনাম অ্যাপোগ্যামি', 'একটি মিয়োসিস এড়ায়, অন্যটি নিষেক এড়ায়।', 'অ্যাপোস্পোরি', 'অ্যাপোগ্যামি', [
  ['সংজ্ঞা', 'স্পোরোফাইটের দেহকোষ থেকে রেণু ছাড়াই সরাসরি গ্যামেটোফাইট', 'গ্যামেটোফাইটের কোষ থেকে গ্যামেট ও নিষেক ছাড়াই সরাসরি স্পোরোফাইট'],
  ['বাদ পড়ে', 'মিয়োসিস ও রেণু সৃষ্টি', 'গ্যামেট সৃষ্টি ও নিষেক'],
  ['শুরুর কোষ', 'স্পোরোফাইটের দেহকোষ (2n) — নিউসেলাস, আবরণী, পাতা', 'গ্যামেটোফাইটের কোষ — সহকারী, প্রতিপাদ বা প্রোথ্যালাসের কোষ'],
  ['উৎপাদ', 'ডিপ্লয়েড (2n) গ্যামেটোফাইট', 'স্পোরোফাইট — সাধারণত হ্যাপ্লয়েড (যদি গ্যামেটোফাইট n হয়)'],
  ['উদাহরণ', 'ফার্ন (Pteridium), Hieracium', 'ফার্ন (Dryopteris, Pteris), Allium']
]);
})();
