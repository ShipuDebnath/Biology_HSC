/* ═══════════════════════════════════════════════════════════════════
   visuals0 — অধ্যায় ১০ (উদ্ভিদ প্রজনন) এর সহায়ক B10
   (অধ্যায় ৯ এর B9 থেকে অনুলিপি — অধ্যায় ফাইলগুলো নামের ক্রমে লোড হয়, b1c10 আগে আসে, তাই B9 এর ওপর নির্ভর করা যায় না)
   seg (ধরন বদলানো চিত্র + স্লাইডার + চাপ দিলে তথ্য), gseg (লেখচিত্র), ch / chH (রাসায়নিক সংকেত ও n/2n),
   axes, curve, area, along, poly, ion, dot, blob, lab, chip, mem, node
   রঙের নিয়ম (পুরো অধ্যায়ে এক): পুং অংশ/পরাগরেণু = ৬ অ্যাম্বার, স্ত্রী অংশ/ডিম্বক = ৩ বেগুনি, n (হ্যাপ্লয়েড) = ২ কমলা,
   2n = ১০ সবুজ, 3n (সস্য) = ৭ লাইম, ভ্রূণ = ০ টিল, ত্বক/আবরণ = ১১ জলপাই, পানি = ৫ আকাশি
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B10 = window.B10 = {};
const PI = Math.PI;
const bn = B10.bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const rnd = B10.rnd = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
B10.cl = cl;

/* রাসায়নিক সংকেত */
const tok = s => { const out = [], re = /_\{([^}]*)\}|_(\d+)|\^\{([^}]*)\}|\^(\d*[+\-−])/g; let i = 0, m; while ((m = re.exec(s))) { if (m.index > i) out.push([s.slice(i, m.index), 0]); if (m[1] != null || m[2] != null) out.push([m[1] != null ? m[1] : m[2], 1]); else out.push([(m[3] != null ? m[3] : m[4]).replace('-', '−'), 2]); i = re.lastIndex; } if (i < s.length) out.push([s.slice(i), 0]); return out; };
B10.ch = s => { let off = 0; return tok(s).map(([t, l]) => { const o = l === 1 ? 3.5 : l === 2 ? -5 : 0, dy = o - off; off = o; return `<tspan dy="${dy}"${l ? ' font-size="72%"' : ''}>${t}</tspan>`; }).join(''); };
B10.chH = s => tok(s).map(([t, l]) => l === 1 ? `<sub>${t}</sub>` : l === 2 ? `<sup>${t}</sup>` : t).join('');
const ch = B10.ch, chH = B10.chH;

/* ধরন বদলানো চিত্র
   o: { id, t, k?, cap, W?, H? (সংখ্যা বা ty→সংখ্যা), types:{key:[বোতাম, শিরোনাম, বর্ণনা, নোট?]}, def,
        sl?:[{k,l,min,max,step,val,unit,d}], art(g,C,ty,ctx), anim?(g,C,ty,t,ctx), tap?(x,y,ty,ctx)→html, more?(ty,ctx)→html } */
B10.seg = o => ({
  t: o.t, k: o.k || ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `${Object.keys(o.types).length > 1 ? `<div class="fk-row">${X.seg(o.id, Object.keys(o.types).map(k => [k, o.types[k][0]]), o.def)}</div>` : ''}<div class="fk-stage bk-stage" data-k="st"></div>${(o.sl || []).map(s => `<div class="fk-row">${FK.sl(s.k, s.l, s.min, s.max, s.step, s.val, s.unit || '')}</div>`).join('')}<div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = o.W || 360;
    let ty = o.def, C, svg, ga, gd, tt = 0;
    const ctx = { root, v: {}, sel: o.sel != null ? o.sel : null };
    (o.sl || []).forEach(s => { ctx.v[s.k] = s.val; });
    const defInfo = () => { const a = o.types[ty]; return `<b>${a[1] || a[0]}</b> — ${a[2]}${a[3] ? `<div class="small">${a[3]}</div>` : ''}${o.more ? o.more(ty, ctx) || '' : ''}`; };
    const info = h => { $('info').innerHTML = h; };
    const frame = () => { gd.innerHTML = ''; if (o.anim) o.anim(gd, C, ty, tt, ctx); };
    const redraw = () => { ga.innerHTML = ''; o.art(ga, C, ty, ctx); frame(); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const h = typeof o.H === 'function' ? o.H(ty) : (o.H || 260);
      svg = E('svg', { viewBox: `0 0 ${W} ${h}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.types[ty][1] || o.types[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: h, rx: 12, fill: C.sf }, svg);
      ga = E('g', {}, svg); gd = E('g', { style: 'pointer-events:none' }, svg); ctx.svg = svg; ctx.C = C;
      redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo());
    };
    ctx.info = info; ctx.redraw = redraw; ctx.def = defInfo;
    root.addEventListener('click', e => {
      if (!o.tap || !svg || !svg.contains(e.target)) return;
      const m = svg.getScreenCTM(); if (!m) return; const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const q = p.matrixTransform(m.inverse());
      const h = o.tap(q.x, q.y, ty, ctx); if (h) info(h); redraw();
    });
    (o.sl || []).forEach(s => FK.bindSl(root, s.k, v => { ctx.v[s.k] = v; redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo()); }, s.unit || '', s.d != null ? s.d : 0));
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, o.id, v => { ty = v; tt = 0; ctx.sel = o.sel != null ? o.sel : null; ctx.selInfo = null; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* অক্ষ: b = [x, y, w, h]; o = { xr, yr, lx, ly, xt, yt, xf } → P(u, v) */
B10.axes = (g, C, b, o) => {
  const [x, y, w, h] = b, xr = o.xr, yr = o.yr, P = (u, v) => [x + (u - xr[0]) / (xr[1] - xr[0]) * w, y + h - (v - yr[0]) / (yr[1] - yr[0]) * h];
  (o.yt || []).forEach(t => { const [, py] = P(xr[0], t); E('path', { d: `M${x} ${py}H${x + w}`, stroke: C.ln, 'stroke-width': .6, opacity: .45 }, g); T(g, x - 5, py + 3.5, o.yf ? o.yf(t) : String(t), { fs: 9.5, a: 'end', c: C.mu }); });
  (o.xt || []).forEach(t => { const [px] = P(t, yr[0]); E('path', { d: `M${px} ${y + h}v4`, stroke: C.mu, 'stroke-width': 1 }, g); T(g, px, y + h + 14, o.xf ? o.xf(t) : String(t), { fs: 9.5, a: 'middle', c: C.mu }); });
  E('path', { d: `M${x} ${y - 6}V${y + h}H${x + w + 6}`, stroke: C.fg, 'stroke-width': 1.3, fill: 'none' }, g);
  E('path', { d: `M${x} ${y - 10}l-3.5 7h7z`, fill: C.fg }, g); E('path', { d: `M${x + w + 10} ${y + h}l-7 -3.5v7z`, fill: C.fg }, g);
  if (o.lx) T(g, x + w + 8, y + h + 28, o.lx, { fs: 10.5, a: 'end', c: C.mu });
  if (o.ly) T(g, x + 6, y - 4, o.ly, { fs: 10.5, c: C.mu });
  return P;
};
B10.curve = (g, P, f, a, b, at, n = 64) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } return E('path', Object.assign({ d, fill: 'none', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, at), g); };
B10.area = (g, P, f, a, b, y0, at, n = 48) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } const [xb] = P(b, y0), [xa, ya] = P(a, y0); d += `L${xb} ${ya}L${xa} ${ya}Z`; return E('path', Object.assign({ d, stroke: 'none' }, at), g); };
/* রেখা বরাবর u (০→১) অবস্থানের বিন্দু */
B10.along = (pts, u) => {
  let L = 0; const sg = [];
  for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); sg.push(l); L += l; }
  let d = (((u % 1) + 1) % 1) * L;
  for (let i = 0; i < sg.length; i++) { if (d <= sg[i]) { const k = sg[i] ? d / sg[i] : 0; return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k]; } d -= sg[i]; }
  return pts[pts.length - 1];
};
B10.poly = (g, pts, at) => E('path', Object.assign({ d: pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(''), fill: 'none' }, at), g);
/* আয়ন বা অণুর বল */
B10.ion = (g, x, y, s, R, r = 10, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.lt, stroke: R.dk, 'stroke-width': 1.1, opacity: o.op != null ? o.op : 1 }, g); T(g, x, y + 3.2, ch(s), { fs: o.fs || 8.5, a: 'middle', w: 650, c: R.ink }); };
B10.dot = (g, x, y, r, c, op = 1) => E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r, fill: c, opacity: op }, g);
B10.blob = (g, x, y, r, o = {}) => {
  const n = o.n || 7, sd = o.seed || 1; let d = '';
  for (let i = 0; i <= n; i++) { const a = i / n * PI * 2 + (o.rot || 0), rr = r * (1 + (rnd(sd * 31 + (i % n)) - .5) * (o.j != null ? o.j : .16)); d += (i ? 'L' : 'M') + (x + rr * Math.cos(a)).toFixed(1) + ' ' + (y + rr * Math.sin(a)).toFixed(1); }
  return E('path', { d: d + 'Z', fill: o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || 1, 'stroke-linejoin': 'round' }, g);
};
/* লেবেল রেখা ও লেখা */
B10.lab = (g, ax, ay, lx, ly, s, C, o = {}) => {
  E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': .9, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2, fill: C.fg }, g);
  const an = o.a || (lx < ax ? 'end' : 'start'); T(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 4, s, { fs: o.fs || 11, a: an, w: 560, c: o.c || C.fg });
};
/* চিপ (গোল কোণের লেবেল) */
B10.chip = (g, x, y, s, R, o = {}) => { const w = o.w || 60, h = o.h || 18; E('rect', { x: x - (o.a === 'start' ? 0 : w / 2), y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.c, 'stroke-width': 1 }, g); T(g, x + (o.a === 'start' ? w / 2 : 0), y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
/* ঝিল্লি (দ্বিস্তরী লিপিড) — অনুভূমিক */
B10.mem = (g, C, x0, x1, y, o = {}) => {
  const R = o.R || BK.ramp(2), sp = o.sp || 9, gaps = o.gaps || [];
  E('rect', { x: x0, y: y - 8, width: x1 - x0, height: 16, fill: FK.alpha(R.c, .14) }, g);
  let d = '';
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; d += `M${x.toFixed(1)} ${y - 5}v3.2M${x.toFixed(1)} ${y + 1.8}v3.2`; }
  E('path', { d, stroke: R.dk, 'stroke-width': 1, opacity: .55 }, g);
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; E('circle', { cx: x, cy: y - 7, r: 3, fill: R.c }, g); E('circle', { cx: x, cy: y + 7, r: 3, fill: R.c }, g); }
};

/* লেখচিত্র-ধরন: o.types[k] = { b, t, d, f, xr, xt, lx, ly, read?(x) → নোট, mk?:[[x, লেখা]] } */
B10.gseg = o => {
  const ty = {}; Object.keys(o.types).forEach(k => { const G = o.types[k]; ty[k] = [G.b, G.t, G.d]; });
  const box = [46, 34, 284, 160];
  return B10.seg({
    id: o.id, t: o.t, cap: o.cap, k: ['graph', 'anim', 'int'], H: 236, def: o.def, types: ty,
    art(g, C, k, ctx) {
      const G = o.types[k], R = BK.ramp(G.c != null ? G.c : 0);
      const P = B10.axes(g, C, box, { xr: G.xr, yr: [0, 1.08], lx: G.lx, ly: G.ly || 'আপেক্ষিক হার', xt: G.xt, yt: [.5, 1], yf: v => v === 1 ? 'সর্বোচ্চ' : '' });
      ctx.P = P; ctx.G = G;
      B10.area(g, P, G.f, G.xr[0], G.xr[1], 0, { fill: FK.alpha(R.c, .13) });
      B10.curve(g, P, G.f, G.xr[0], G.xr[1], { stroke: R.c, 'stroke-width': 3 });
      (G.mk || []).forEach(([xv, s, up, an]) => { const [px, py] = P(xv, G.f(xv)); E('circle', { cx: px, cy: py, r: 3.2, fill: R.dk }, g); T(g, px + (an ? 7 : 0), py + (up ? -9 : 17), s, { fs: 9.8, a: an || 'middle', w: 560, c: R.ink }); });
      if (ctx.sel != null) { const [px, py] = P(ctx.sel, G.f(ctx.sel)), [, pb] = P(ctx.sel, 0), [pa] = P(G.xr[0], 0); E('path', { d: `M${px} ${pb}V${py}H${pa}`, stroke: C.mu, 'stroke-dasharray': '3 3', fill: 'none' }, g); E('circle', { cx: px, cy: py, r: 5, fill: R.c, stroke: C.sf, 'stroke-width': 2 }, g); }
    },
    anim(g, C, k, t, ctx) {
      const G = ctx.G, P = ctx.P; if (!G || !t) return; const R = BK.ramp(G.c != null ? G.c : 0), u = (1 - Math.cos(t * .7)) / 2, xv = G.xr[0] + u * (G.xr[1] - G.xr[0]), [px, py] = P(xv, G.f(xv));
      E('circle', { cx: px, cy: py, r: 9, fill: FK.alpha(R.c, .25) }, g); E('circle', { cx: px, cy: py, r: 4.5, fill: R.dk }, g);
    },
    tap(x, y, k, ctx) {
      const G = ctx.G; if (!G || x < box[0] - 4 || x > box[0] + box[2] + 4 || y > box[1] + box[3] + 6) return null;
      const xv = cl(G.xr[0] + (x - box[0]) / box[2] * (G.xr[1] - G.xr[0]), G.xr[0], G.xr[1]); ctx.sel = xv;
      const v = Math.round(G.f(xv) * 100);
      return `<b>${G.lx}: ${FK.n(xv, G.dp != null ? G.dp : 0)}${G.u || ''}</b> → আপেক্ষিক হার ≈ <b>${v}%</b> (সর্বোচ্চের তুলনায়)${G.read ? `<div class="small">${G.read(xv)}</div>` : ''}<div class="small muted">এটি প্রবণতা বোঝানোর লেখচিত্র — মান উদ্ভিদভেদে বদলায়।</div>`;
    }
  });
};
B10.node = (g, x, y, s, R, w = 64, h = 22, o = {}) => { E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: o.rx != null ? o.rx : 7, fill: o.fill || FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': o.sw || 1.1 }, g); T(g, x, y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
})();
