/* ═══════════════════════════════════════════════════════════════════
   visuals2 — রজঃচক্র ও গ্যামেট: menstrualCycle, pubertyTimeline, spermatogenesis, oogenesis, ovaryLS, fertilization, implantation
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B29, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const preset = (ctx, k, v, dig = 0, unit = '') => { ctx.v[k] = v; const el = ctx.root && ctx.root.querySelector ? ctx.root.querySelector(`[data-sl="${k}"]`) : null; if (el) { el.value = v; const o2 = ctx.root.querySelector(`[data-slo="${k}"]`); if (o2) o2.textContent = FK.n(v, dig) + unit; } };
const gs = (d, m, w) => Math.exp(-Math.pow((d - m) / w, 2));

/* ═════════ রজঃচক্র ═════════ */
const HF = { fsh: d => .2 + .22 * gs(d, 3, 4) + .3 * gs(d, 13.6, 1.2) + .14 * gs(d, 28, 3), lh: d => .12 + .88 * gs(d, 13.8, .9) + .04 * gs(d, 21, 5), est: d => .12 + .78 * gs(d, 12.6, 2.4) + .42 * gs(d, 21, 3.4), prog: d => .04 + .86 * gs(d, 21.5, 3.6) };
const ENDO = d => d <= 5 ? 4 - 3 * (d - 1) / 4 : d <= 14 ? 1 + 7 * (d - 5) / 9 : d <= 24 ? 8 + 4 * (d - 14) / 10 : 12 - 3 * (d - 24) / 4;
const MX0 = 16, MX1 = 344, mx = d => MX0 + (d - 1) / 27 * (MX1 - MX0), EY = 304, ES = 4.4;
const MC = {
  men: ['রজঃস্রাব পর্ব', 'রজঃস্রাব বা মাসিক পর্ব (দিন 1–5)', 'আগের চক্রে গর্ভ না হওয়ায় কর্পাস লুটিয়াম নষ্ট হয়ে প্রোজেস্টেরন ও ইস্ট্রোজেন কমে যায় → এন্ডোমেট্রিয়ামের সর্পিল ধমনি সংকুচিত হয়ে ওপরের স্তর ঝরে পড়ে; রক্ত, শ্লেষ্মা ও কলা যোনিপথে বের হয় (প্রায় 30–80 মিলিলিটার)। FSH একটু বাড়তে থাকে।', 3],
  fol: ['ফলিকুলার পর্ব', 'ফলিকুলার বা প্রলিফারেটিভ পর্ব (দিন 6–13)', 'FSH এর প্রভাবে কয়েকটি ফলিকল বড় হয়, একটি প্রধান হয়ে গ্রাফিয়ান ফলিকলে পরিণত হয়; ফলিকল থেকে ইস্ট্রোজেন বাড়ে → এন্ডোমেট্রিয়াম নতুন করে গড়ে ও পুরু হয়, সার্ভিক্সের শ্লেষ্মা পাতলা হয়।', 10],
  ov: ['ডিম্বপাত', 'ডিম্বপাত (প্রায় দিন 14)', 'উচ্চ ইস্ট্রোজেন ধনাত্মক ফিডব্যাকে LH ও FSH এর হঠাৎ ঢেউ (সার্জ) ঘটায় → প্রায় 24–36 ঘণ্টা পর গ্রাফিয়ান ফলিকল ফেটে গৌণ উওসাইট ফ্যালোপিয়ান নালিতে মুক্ত হয়। ডিম্বাণু প্রায় 12–24 ঘণ্টা নিষেকযোগ্য থাকে।', 14],
  lut: ['লুটিয়াল পর্ব', 'লুটিয়াল বা সিক্রেটরি পর্ব (দিন 15–28)', 'ফাটা ফলিকল LH এর প্রভাবে কর্পাস লুটিয়াম হয়ে প্রোজেস্টেরন (ও কিছু ইস্ট্রোজেন) ক্ষরণ করে → এন্ডোমেট্রিয়াম গ্রন্থিময়, রক্তনালিময় ও নরম হয়ে ভ্রূণ গ্রহণে প্রস্তুত। নিষেক না হলে প্রায় 10–12 দিনে কর্পাস লুটিয়াম নষ্ট হয়, হরমোন কমে, নতুন রজঃস্রাব শুরু।', 21]
};
const oo2 = (g, x, y, r) => { E('circle', { cx: f1(x), cy: f1(y), r: f1(r + 1.6), fill: 'none', stroke: '#e6d0ee', 'stroke-width': 1.6 }, g); E('circle', { cx: f1(x), cy: f1(y), r: f1(r), fill: '#f8f0ff', stroke: '#8a6aa8', 'stroke-width': .6 }, g); E('circle', { cx: f1(x), cy: f1(y), r: f1(r * .36), fill: '#c8b8e8' }, g); };
const follicle = (g, x, y, d) => { /* d অনুযায়ী ডিম্বাশয়ের গঠন */
  if (d < 14) { const r = 5 + (d - 1) / 13 * 15; E('circle', { cx: f1(x), cy: y, r: f1(r + 2), fill: '#e8b090', stroke: '#a05a3a', 'stroke-width': .7 }, g); E('circle', { cx: f1(x), cy: y, r: f1(r), fill: '#f8d8a8' }, g); if (d > 6) E('path', { d: B.ellD(x + r * .18, y - r * .05, r * (.3 + (d - 6) * .05), r * (.27 + (d - 6) * .045), 0), fill: '#fff8e8', stroke: '#d0b080', 'stroke-width': .5 }, g); oo2(g, x - r * .48, y + r * .2, Math.max(2.4, Math.min(6, r * .26))); }
  else if (d < 15) { E('circle', { cx: f1(x), cy: y, r: 21, fill: '#e8b090', stroke: '#a05a3a', 'stroke-width': .7 }, g); E('path', { d: B.ellD(x + 3, y, 14, 13, 0), fill: '#fff8e8', stroke: '#d0b080', 'stroke-width': .5 }, g); E('path', { d: `M${f1(x + 16)} ${y - 12}l12 -6`, stroke: '#c0392b', 'stroke-width': 1.6 }, g); oo2(g, x + 34, y - 20, 6); }
  else { const r = d < 25 ? 15 + (d - 15) * .4 : 19 - (d - 25) * 3; if (d < 25) { B.organ(g, B.ellD(x, y, r, r * .9, 0), 'adc', { sw: .8 }); let fd = ''; for (let i = 0; i < 14; i++) fd += `M${f1(x)} ${y}l${f1(Math.cos(i * .45) * r * .8)} ${f1(Math.sin(i * .45) * r * .72)}`; E('path', { d: fd, stroke: '#b09030', 'stroke-width': .6 }, g); } else E('path', { d: B.ellD(x, y, Math.max(7, r), Math.max(6, r * .8), 15), fill: '#f2eee4', stroke: '#a89a7e', 'stroke-width': .8 }, g); } };
const MCL = { men: 'রজঃস্রাব', fol: 'ফলিকুলার', ov: 'ডিম্বপাত', lut: 'লুটিয়াল' };
V.menstrualCycle = Object.assign({}, B.seg({
  id: 'mens', t: 'রজঃচক্র: হরমোন, ডিম্বাশয় ও জরায়ু', H: 340, def: 'fol', types: Object.fromEntries(Object.entries(MC).map(([k, v]) => [k, v.slice(0, 3)])),
  sl: [{ k: 'd', l: 'চক্রের দিন', min: 1, max: 28, step: 1, val: 10 }],
  cap: 'সাধারণ 28 দিনের চক্র (স্বাভাবিক সীমা প্রায় 21–35 দিন) — দিন 1 = রজঃস্রাবের প্রথম দিন। ওপর থেকে: পিটুইটারির হরমোন (FSH, LH) → ডিম্বাশয়ের পরিবর্তন → ডিম্বাশয়ের হরমোন (ইস্ট্রোজেন, প্রোজেস্টেরন) → এন্ডোমেট্রিয়ামের পুরুত্ব। চক্রের দৈর্ঘ্য ভিন্ন হলেও লুটিয়াল পর্ব প্রায় 14 দিনই থাকে। লেখচিত্রের মান আপেক্ষিক।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; preset(ctx, 'd', MC[ty][3]); }
    B.cacheG(g, 'mcb', gg => { [[14, 'পিটুইটারি হরমোন'], [112, 'ডিম্বাশয়'], [168, 'ডিম্বাশয়ের হরমোন'], [242, 'এন্ডোমেট্রিয়াম']].forEach(([y, n]) => B.tx(gg, MX0, y, n, { fs: 10.4, w: 700, c: C.mu }));
      [[1, 5.5, '#f4c4c4'], [5.5, 13.5, '#d4e8d4'], [13.5, 14.5, '#f4d890'], [14.5, 28, '#ddd4ee']].forEach(([a, b, c]) => E('rect', { x: f1(mx(a)), y: 92, width: f1(mx(b) - mx(a)), height: 7, fill: c }, gg));
      E('path', { d: `M${MX0} 86H${MX1}M${MX0} 226H${MX1}`, stroke: FK.alpha(C.fg, .3), 'stroke-width': .7 }, gg);
      const curve = (f, y0, y1, col, dash) => { let d = ''; for (let i = 0; i <= 108; i++) { const dd = 1 + i / 4; d += (i ? 'L' : 'M') + f1(mx(dd)) + ' ' + f1(y1 - f(dd) * (y1 - y0)); } E('path', { d, stroke: col, 'stroke-width': 2, fill: 'none', 'stroke-dasharray': dash || '' }, gg); };
      curve(HF.fsh, 26, 86, '#2a7a4a'); curve(HF.lh, 26, 86, '#c07a20'); curve(HF.est, 176, 226, '#c0392b'); curve(HF.prog, 176, 226, '#5a3aa8', '5 3');
      B.tx(gg, mx(4), 58, 'FSH', { fs: 10.4, w: 700, c: '#2a7a4a' }); B.tx(gg, mx(15.4), 36, 'LH', { fs: 10.4, w: 700, c: '#c07a20' }); B.tx(gg, mx(7.2), 196, 'ইস্ট্রোজেন', { fs: 10.4, w: 700, c: '#c0392b' }); B.tx(gg, mx(24.6), 182, 'প্রোজেস্টেরন', { fs: 10.4, w: 700, c: '#5a3aa8', a: 'middle' });
      let top = ''; for (let i = 0; i <= 108; i++) { const dd = 1 + i / 4; top += (i ? 'L' : 'M') + f1(mx(dd)) + ' ' + f1(EY - ENDO(dd) * ES); } E('path', { d: top + `L${MX1} ${EY}H${MX0}Z`, fill: B.TS('endm').c, stroke: B.TS('endm').dk, 'stroke-width': .8 }, gg); E('path', { d: `M${MX0} ${EY}H${MX1}V${EY + 7}H${MX0}Z`, fill: B.TS('ut').c, stroke: B.TS('ut').dk, 'stroke-width': .5 }, gg);
      let sp = '', gl = ''; for (let dd = 6.5; dd <= 27.5; dd += 1.4) { const h = ENDO(dd) * ES - 3, x = mx(dd); sp += `M${f1(x)} ${EY}q-3 ${f1(-h / 3)} 0 ${f1(-h * 2 / 3)}t0 ${f1(-h / 3)}`; if (dd > 14) gl += `M${f1(x + 7)} ${EY - 1}q${f1(dd > 17 ? 3 : 1)} ${f1(-h * .4)} 0 ${f1(-h * .85)}`; } E('path', { d: sp, stroke: '#a03040', 'stroke-width': .8, fill: 'none', opacity: .75 }, gg); E('path', { d: gl, stroke: '#7a4a5a', 'stroke-width': 1.1, fill: 'none', opacity: .55 }, gg);
      let bl = ''; for (let dd = 1.2; dd <= 5; dd += .45) bl += B.ellD(mx(dd), EY - ENDO(dd) * ES - 3 - (dd * 7 % 4), 1.8, 2.4, 0); E('path', { d: bl, fill: '#b02030' }, gg);
      for (let d = 1; d <= 28; d += 3) B.tx(gg, mx(d), 326, String(d), { fs: 10, a: 'middle', c: C.mu }); B.tx(gg, MX1, 339, 'দিন →', { fs: 10.4, a: 'end', c: C.mu }); B.tx(gg, mx(28), 326, '28', { fs: 10, a: 'middle', c: C.mu }); });
    const d = ctx.v.d, x = mx(d); follicle(g, Math.min(MX1 - 40, Math.max(MX0 + 24, x)), 134, d); E('path', { d: `M${f1(x)} 22V${EY}`, stroke: FK.alpha('#1a4a8a', .55), 'stroke-width': 1.2, 'stroke-dasharray': '3 2' }, g);
    [[HF.fsh, 26, 86, '#2a7a4a'], [HF.lh, 26, 86, '#c07a20'], [HF.est, 176, 226, '#c0392b'], [HF.prog, 176, 226, '#5a3aa8']].forEach(([f, y0, y1, col]) => E('circle', { cx: f1(x), cy: f1(y1 - f(d) * (y1 - y0)), r: 3.2, fill: col }, g));
    const ph = d <= 5 ? 'রজঃস্রাব' : d < 14 ? 'ফলিকুলার' : d === 14 ? 'ডিম্বপাত' : 'লুটিয়াল'; B.tx(g, MX1, 14, `দিন ${d} — ${ph}`, { fs: 11, a: 'end', w: 700, c: '#1a4a8a' });
    const os = d < 14 ? (d < 7 ? 'বর্ধনশীল ফলিকল' : 'গ্রাফিয়ান ফলিকল গড়ছে') : d === 14 ? 'ফলিকল ফেটে উওসাইট মুক্ত' : d < 25 ? 'কর্পাস লুটিয়াম' : 'কর্পাস লুটিয়াম ক্ষয় হচ্ছে'; B.tx(g, MX1, 112, os, { fs: 10, a: 'end', c: '#8a5a2a' });
    B.tx(g, MX1, 242, `পুরুত্ব ≈ ${FK.n(ENDO(d), 0)} মিমি`, { fs: 10, a: 'end', c: '#994a46' }); },
  anim(g, C, ty, t, ctx) { const d = ctx.v.d || 10, x = Math.min(MX1 - 40, Math.max(MX0 + 24, mx(d))), k = .5 + .5 * Math.sin(t * 3), r = d < 14 ? 5 + (d - 1) / 13 * 15 + 4 : 24; E('circle', { cx: f1(x), cy: 134, r: f1(r + k * 3), fill: 'none', stroke: '#1a4a8a', 'stroke-width': 1, opacity: f1(.6 - k * .4) }, g); }
}));

/* ═════════ বয়ঃসন্ধির পরিবর্তন ═════════ */
const PB = {
  girl: ['মেয়ে', 'মেয়েদের বয়ঃসন্ধি (সাধারণত 8–13 বছরে শুরু)', 'ইস্ট্রোজেনের প্রভাবে স্তনের বৃদ্ধি সাধারণত প্রথম লক্ষণ; তারপর যৌনকেশ, দৈহিক উচ্চতার দ্রুত বৃদ্ধি এবং প্রথম রজঃস্রাব (মেনার্কি, গড়ে প্রায় 12–13 বছরে)। নিতম্ব চওড়া হয়, দেহে চর্বির বিন্যাস বদলায়, ঘাম ও ব্রণ বাড়ে।', [['স্তনের বৃদ্ধি', 8, 13, 10.5], ['যৌনকেশ', 9, 14, 11.5], ['উচ্চতার দ্রুত বৃদ্ধি', 9.5, 14.5, 12], ['প্রথম রজঃস্রাব', 10, 16, 12.7], ['বগলের লোম', 10, 15, 12.5], ['নিতম্ব চওড়া', 10, 16, 13]]],
  boy: ['ছেলে', 'ছেলেদের বয়ঃসন্ধি (সাধারণত 9–14 বছরে শুরু)', 'টেস্টোস্টেরনের প্রভাবে প্রথম লক্ষণ শুক্রাশয়ের আকার বৃদ্ধি; তারপর যৌনকেশ, উচ্চতার দ্রুত বৃদ্ধি (মেয়েদের চেয়ে প্রায় 2 বছর পরে), কণ্ঠস্বর ভারী, প্রথম বীর্যপাত (প্রায়ই ঘুমের মধ্যে — স্বপ্নদোষ, স্বাভাবিক), দাড়ি-গোঁফ ও পেশির বৃদ্ধি।', [['শুক্রাশয় বৃদ্ধি', 9, 14, 11.5], ['যৌনকেশ', 10, 15, 12.5], ['উচ্চতার দ্রুত বৃদ্ধি', 11.5, 16, 13.8], ['প্রথম বীর্যপাত', 12, 15.5, 13.5], ['কণ্ঠস্বর ভারী', 12, 16, 14], ['দাড়ি-গোঁফ', 14, 18, 15.5]]]
};
const AX0 = 122, AX1 = 346, ax = a => AX0 + (a - 8) / 10 * (AX1 - AX0);
V.pubertyTimeline = Object.assign({}, B.seg({
  id: 'pub', t: 'বয়ঃসন্ধিকালের পরিবর্তন ও সময়', H: 256, def: 'girl', types: Object.fromEntries(Object.entries(PB).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'বয়ঃসন্ধিকাল (puberty) হলো শৈশব থেকে প্রজননক্ষম প্রাপ্তবয়সে যাওয়ার সময় — হাইপোথ্যালামাসের GnRH ছন্দে বাড়তে শুরু করলে FSH-LH ও যৌন হরমোন বাড়ে। হালকা দণ্ড স্বাভাবিক বয়সসীমা, গাঢ় বিন্দু গড় বয়স। প্রত্যেকের সময় আলাদা — আগে বা পরে হওয়া সাধারণত স্বাভাবিক; WHO এর সংজ্ঞায় কৈশোর 10–19 বছর।',
  art(g, C, ty) { const rows = PB[ty][3], col = ty === 'girl' ? '#c04a7a' : '#2a6ab0';
    for (let a = 8; a <= 18; a += 2) { E('path', { d: `M${f1(ax(a))} 20V226`, stroke: FK.alpha(C.fg, .1), 'stroke-width': .7 }, g); B.tx(g, ax(a), 240, String(a), { fs: 10, a: 'middle', c: C.mu }); } B.tx(g, AX1, 252, 'বয়স (বছর) →', { fs: 10.4, a: 'end', c: C.mu });
    rows.forEach(([n, a0, a1, m], i) => { const y = 34 + i * 32; B.tx(g, AX0 - 6, y + 4, n, { fs: 10.8, a: 'end', w: 650 }); E('rect', { x: f1(ax(a0)), y: y - 7, width: f1(ax(a1) - ax(a0)), height: 14, rx: 7, fill: FK.alpha(col, .25), stroke: FK.alpha(col, .6), 'stroke-width': .7 }, g); E('circle', { cx: f1(ax(m)), cy: y, r: 5, fill: col }, g); }); },
  anim(g, C, ty, t) { const a = 8 + ((t * .8) % 10), x = ax(a); E('path', { d: `M${f1(x)} 20V226`, stroke: FK.alpha('#1a4a8a', .5), 'stroke-width': 1.2 }, g); T(g, f1(x), 15, FK.n(a, 1) + ' বছর', { fs: 10, a: 'middle', c: '#1a4a8a' }); }
}));

/* ═════════ ক্রোমোজোম সহায়ক (2n = 4: দুই জোড়া) ═════════ */
const CH = [['#c0392b', 10], ['#e0889a', 10], ['#2a6ab0', 6], ['#8ab0e0', 6]];
const chrom = (g, x, y, col, len, dbl) => { const h = len / 2; if (dbl) { E('path', { d: `M${f1(x - 1.1)} ${f1(y - h)}Q${f1(x - .2)} ${f1(y)} ${f1(x - 1.1)} ${f1(y + h)}M${f1(x + 1.1)} ${f1(y - h)}Q${f1(x + .2)} ${f1(y)} ${f1(x + 1.1)} ${f1(y + h)}`, stroke: col, 'stroke-width': 2.2, 'stroke-linecap': 'round', fill: 'none' }, g); E('circle', { cx: f1(x), cy: f1(y), r: 1.1, fill: '#333' }, g); } else E('path', { d: `M${f1(x)} ${f1(y - h)}V${f1(y + h)}`, stroke: col, 'stroke-width': 2.2, 'stroke-linecap': 'round' }, g); };
const cell = (g, x, y, r, set, dbl, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || '#fbe5ee', stroke: o.st || '#b77898', 'stroke-width': .9 }, g); const nr = r * .64; E('circle', { cx: x, cy: y, r: nr, fill: o.nf || '#efe9f8', stroke: '#8a7ab0', 'stroke-width': .5 }, g); const n = set.length, gap = Math.min(nr * 1.5 / Math.max(1, n - 1 || 1), 6.4); set.forEach((ci, i) => { const [col, len] = CH[ci]; chrom(g, x + (n > 1 ? (i - (n - 1) / 2) * gap : 0), y, col, Math.min(nr * 1.5, len * .9) * (len === 10 ? 1 : .62), dbl); }); };
const flag = (g, x, y, s) => { let d = `M${f1(x)} ${y}`; for (let i = 1; i <= 7; i++) d += `q${f1(2.6 * s)} ${f1((i % 2 ? 2.2 : -2.2) * s)} ${f1(5.2 * s)} 0`; E('path', { d, stroke: '#6a5a8a', 'stroke-width': .9, fill: 'none' }, g); E('path', { d: `M${f1(x)} ${y}h${f1(-5 * s)}`, stroke: '#8a6a4a', 'stroke-width': 2.2 }, g); E('path', { d: B.ellD(x - 9 * s, y, 4.2 * s, 2.8 * s, 0), fill: '#5a4a8a', stroke: '#3a2a6a', 'stroke-width': .5 }, g); E('path', { d: B.ellD(x - 11 * s, y, 2.2 * s, 2.4 * s, 0), fill: '#c8c0e8', opacity: .8 }, g); };

/* ═════════ স্পার্মাটোজেনেসিস ═════════ */
const SG = [
  { t: 'সংখ্যাবৃদ্ধি পর্ব', en: 'Multiplication', d: 'সেমিনিফেরাস নালিকার ভিত্তিপর্দার স্পার্মাটোগোনিয়াম (2n) বারবার মাইটোসিসে বিভাজিত হয় — একটি অংশ মূল কোষ হিসেবে থাকে, বাকিগুলো সামনে এগোয়। বয়ঃসন্ধি থেকে আজীবন চলে।' },
  { t: 'বৃদ্ধি পর্ব', en: 'Growth', d: 'স্পার্মাটোগোনিয়াম পুষ্টি জমিয়ে বড় হয়ে প্রাথমিক স্পার্মাটোসাইট (2n) হয়; DNA প্রতিলিপি হয়, প্রতিটি ক্রোমোজোম দুই ক্রোমাটিডের।' },
  { t: 'পরিপক্বতা: মিয়োসিস-I', en: 'Meiosis I', d: 'প্রাথমিক স্পার্মাটোসাইট মিয়োসিস-I এ বিভাজিত হয়ে দুটি গৌণ স্পার্মাটোসাইট (n) — সমসংস্থ ক্রোমোজোম আলাদা হয়, সংখ্যা অর্ধেক; ক্রসিং ওভারে নতুন জিন-সমন্বয়।' },
  { t: 'পরিপক্বতা: মিয়োসিস-II', en: 'Meiosis II', d: 'প্রতিটি গৌণ স্পার্মাটোসাইট মিয়োসিস-II এ দুটি স্পার্মাটিড (n) তৈরি করে — ক্রোমাটিড আলাদা হয়। একটি প্রাথমিক স্পার্মাটোসাইট থেকে 4টি স্পার্মাটিড।' },
  { t: 'স্পার্মিওজেনেসিস', en: 'Spermiogenesis', d: 'বিভাজন ছাড়াই রূপান্তর: গলজি থেকে অ্যাক্রোসোম, সেন্ট্রিওল থেকে লেজ, মাইটোকন্ড্রিয়া মধ্যখণ্ডে, নিউক্লিয়াস ঘন, বাড়তি সাইটোপ্লাজম ঝরে যায় — স্পার্মাটিড শুক্রাণুতে পরিণত হয়।' },
  { t: 'ফলাফল', en: '1 → 4 sperm', d: 'একটি স্পার্মাটোগোনিয়াম (প্রাথমিক স্পার্মাটোসাইট) থেকে 4টি সমান কার্যকর শুক্রাণু (n = 23)। দুই ধরনের: 22 + X ও 22 + Y (সমান সংখ্যায়)। পুরো প্রক্রিয়ায় প্রায় 64–74 দিন; দিনে কয়েক কোটি শুক্রাণু তৈরি হয়।' }
];
V.spermatogenesis = Object.assign({ t: 'স্পার্মাটোজেনেসিস (শুক্রাণু সৃষ্টি)', k: ['2d', 'anim', 'steps'], cap: 'শুক্রাশয়ের সেমিনিফেরাস নালিকায় শুক্রাণু তৈরির প্রক্রিয়া। বোঝার সুবিধায় 2n = 4 (দুই জোড়া ক্রোমোজোম; রং দিয়ে বাবা-মায়ের কাছ থেকে পাওয়া সমসংস্থ জোড়া) দেখানো — মানুষে 2n = 46। প্রতিটি ধাপে নতুন সারি দেখা যায়।' },
  BK.steps({ W: 360, H: 300, label: 'স্পার্মাটোজেনেসিস', dur: 3, stages: SG,
    draw(g, C, s, u) { B.cacheG(g, 'sgb' + s, gg => { const rows = [[34, 'স্পার্মাটোগোনিয়াম (2n)'], [94, 'প্রাথমিক স্পার্মাটোসাইট (2n)'], [154, 'গৌণ স্পার্মাটোসাইট (n)'], [214, 'স্পার্মাটিড (n)'], [270, 'শুক্রাণু (n)']];
      rows.forEach(([y, n], i) => { if (i <= Math.min(s, 4)) B.tx(gg, 8, y + 4, n, { fs: 10.4, w: 650, c: C.mu }); });
      cell(gg, 230, 34, 16, [0, 1, 2, 3], false); if (s === 0) { cell(gg, 196, 34, 12, [0, 1, 2, 3], false, { fill: '#f8eef4' }); cell(gg, 266, 34, 12, [0, 1, 2, 3], false, { fill: '#f8eef4' }); }
      const ln = (x0, y0, x1, y1) => E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: FK.alpha(C.fg, .35), 'stroke-width': 1, 'marker-end': B.mk(gg, FK.alpha(C.fg, .5), 5) }, gg);
      if (s >= 1) { ln(230, 52, 230, 70); cell(gg, 230, 94, 22, [0, 1, 2, 3], true); }
      if (s >= 2) { ln(220, 116, 186, 136); ln(240, 116, 274, 136); cell(gg, 180, 154, 16, [0, 2], true); cell(gg, 280, 154, 16, [1, 3], true); B.tx(gg, 230, 132, 'মিয়োসিস-I', { fs: 9.8, a: 'middle', w: 700, c: '#a8201a' }); }
      if (s >= 3) { [[180, 150], [180, 210], [280, 250], [280, 310]].forEach(([px, x]) => ln(px, 172, x, 198)); [[150, [0, 2]], [210, [0, 2]], [250, [1, 3]], [310, [1, 3]]].forEach(([x, set]) => cell(gg, x, 214, 12, set, false)); B.tx(gg, 230, 192, 'মিয়োসিস-II', { fs: 9.8, a: 'middle', w: 700, c: '#a8201a' }); }
      if (s >= 4) [150, 210, 250, 310].forEach(x => { ln(x, 228, x, 256); flag(gg, x + 6, 270, .8); });
      if (s === 5) { E('rect', { x: 120, y: 284, width: 220, height: 14, rx: 4, fill: FK.alpha('#2a6ab0', .12) }, gg); B.tx(gg, 230, 295, '1 → 4টি কার্যকর শুক্রাণু', { fs: 10.4, a: 'middle', w: 700, c: '#2a5a90' }); } });
      const k = .5 + .5 * Math.sin(u * PI * 4); const ry = [34, 94, 154, 214, 270][Math.min(s, 4)]; E('rect', { x: 120, y: ry - 26, width: 236, height: 52, rx: 8, fill: 'none', stroke: '#2a6ad0', 'stroke-width': 1.4, opacity: f1(.3 + .5 * k) }, g); }
  }));

/* ═════════ উওজেনেসিস ═════════ */
const OG = [
  { t: 'ভ্রূণাবস্থায় সংখ্যাবৃদ্ধি', en: 'Before birth', d: 'মায়ের গর্ভে থাকা মেয়ে ভ্রূণের ডিম্বাশয়ে উওগোনিয়াম (2n) মাইটোসিসে বিভাজিত হয় — প্রায় 20 সপ্তাহে সংখ্যা সর্বোচ্চ প্রায় 60–70 লক্ষ।' },
  { t: 'প্রাথমিক উওসাইট — থেমে থাকা', en: 'Arrest at prophase I', d: 'উওগোনিয়াম বড় হয়ে প্রাথমিক উওসাইট (2n) হয় এবং জন্মের আগেই মিয়োসিস-I এর প্রোফেজে থেমে যায়, প্রাথমিক ফলিকলে ঘেরা থাকে। জন্মের সময় প্রায় 10–20 লক্ষ, বয়ঃসন্ধিতে প্রায় 3–4 লক্ষ থাকে; জীবনে মাত্র প্রায় 400–500টি ডিম্বপাত হয়।' },
  { t: 'বয়ঃসন্ধি: মিয়োসিস-I সম্পূর্ণ', en: 'Meiosis I (each cycle)', d: 'প্রতি রজঃচক্রে LH সার্জের আগে-পরে একটি প্রাথমিক উওসাইট মিয়োসিস-I শেষ করে — অসম বিভাজন: বড় গৌণ উওসাইট (n, প্রায় সব সাইটোপ্লাজম) ও ছোট প্রথম পোলার বডি (n)।' },
  { t: 'ডিম্বপাত — মেটাফেজ-II এ থামা', en: 'Ovulation', d: 'গৌণ উওসাইট মিয়োসিস-II এর মেটাফেজে আবার থেমে যায় এবং এ অবস্থাতেই ডিম্বপাতে মুক্ত হয় — আসলে "ডিম্বাণু" হিসেবে যা বের হয় তা গৌণ উওসাইট।' },
  { t: 'নিষেক: মিয়োসিস-II সম্পূর্ণ', en: 'Meiosis II at fertilization', d: 'শুক্রাণু প্রবেশ করলেই মিয়োসিস-II শেষ হয় — আবার অসম বিভাজন: পরিণত ডিম্বাণু (উওটিড/ওভাম, n) ও দ্বিতীয় পোলার বডি। প্রথম পোলার বডিও বিভাজিত হতে পারে। নিষেক না হলে উওসাইট নষ্ট হয়।' },
  { t: 'ফলাফল', en: '1 → 1 ovum', d: 'একটি প্রাথমিক উওসাইট থেকে মাত্র 1টি কার্যকর ডিম্বাণু ও 2–3টি পোলার বডি (নষ্ট হয়ে যায়)। অসম বিভাজনের উদ্দেশ্য: ভ্রূণের প্রথম কয়েক দিনের জন্য প্রায় সব খাদ্য ও অঙ্গাণু একটি কোষে রাখা। সব ডিম্বাণু 22 + X।' }
];
V.oogenesis = Object.assign({ t: 'উওজেনেসিস (ডিম্বাণু সৃষ্টি)', k: ['2d', 'anim', 'steps'], cap: 'ডিম্বাশয়ে ডিম্বাণু তৈরির প্রক্রিয়া — শুরু হয় ভ্রূণাবস্থায়, মাঝে দীর্ঘ বিরতি, শেষ হয় নিষেকের সময়। এখানেও 2n = 4 দেখানো। কোষের আকার আপেক্ষিক — মানব ডিম্বাণু প্রায় 0.1 মিলিমিটার, দেহের বৃহত্তম কোষ, খালি চোখে প্রায় দেখা যায়।' },
  BK.steps({ W: 360, H: 300, label: 'উওজেনেসিস', dur: 3, stages: OG,
    draw(g, C, s, u) { B.cacheG(g, 'ogb' + s, gg => { const rows = [[34, 'উওগোনিয়াম (2n)'], [100, 'প্রাথমিক উওসাইট (2n)'], [170, 'গৌণ উওসাইট (n)'], [244, 'ডিম্বাণু (n)']];
      const ln = (x0, y0, x1, y1) => E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: FK.alpha(C.fg, .35), 'stroke-width': 1, 'marker-end': B.mk(gg, FK.alpha(C.fg, .5), 5) }, gg);
      rows.forEach(([y, n], i) => { if (i <= [0, 1, 2, 2, 3, 3][s]) B.tx(gg, 8, y + 4, n, { fs: 10.4, w: 650, c: C.mu }); });
      cell(gg, 220, 34, 14, [0, 1, 2, 3], false); if (s === 0) { cell(gg, 188, 34, 11, [0, 1, 2, 3], false, { fill: '#f8eef4' }); cell(gg, 252, 34, 11, [0, 1, 2, 3], false, { fill: '#f8eef4' }); }
      if (s >= 1) { ln(220, 50, 220, 68); E('circle', { cx: 220, cy: 100, r: 36, fill: 'none', stroke: '#e0b070', 'stroke-width': 5, 'stroke-dasharray': '6 3' }, gg); cell(gg, 220, 100, 28, [0, 1, 2, 3], true, { fill: '#fdf0d8' }); B.tx(gg, 300, 100, 'প্রোফেজ-I এ বিরতি', { fs: 9.8, w: 700, c: '#a8601a' }); }
      if (s >= 2) { ln(220, 138, 214, 146); cell(gg, 210, 172, 24, [0, 2], true, { fill: '#fdf0d8' }); cell(gg, 266, 158, 7, [1, 3], true); B.tx(gg, 284, 150, 'প্রথম পোলার বডি', { fs: 9.8, c: C.mu }); }
      if (s === 3) { E('rect', { x: 150, y: 204, width: 200, height: 18, rx: 5, fill: FK.alpha('#c07a20', .12) }, gg); B.tx(gg, 250, 217, 'মেটাফেজ-II এ বিরতি — ডিম্বপাত', { fs: 10.4, a: 'middle', w: 700, c: '#a8601a' }); }
      if (s >= 4) { ln(210, 198, 210, 212); cell(gg, 206, 246, 22, [0, 2], false, { fill: '#fdf0d8' }); cell(gg, 260, 236, 6, [0, 2], false); B.tx(gg, 272, 228, 'দ্বিতীয় পোলার বডি', { fs: 9.8, c: C.mu }); flag(gg, 160, 246, 1); B.tx(gg, 120, 266, 'শুক্রাণু প্রবেশ', { fs: 9.8, c: '#2a5a90' }); }
      if (s === 5) { E('rect', { x: 120, y: 278, width: 230, height: 16, rx: 4, fill: FK.alpha('#c04a7a', .12) }, gg); B.tx(gg, 235, 290, '1 → 1টি ডিম্বাণু + 2–3টি পোলার বডি', { fs: 10.4, a: 'middle', w: 700, c: '#a03a6a' }); } });
      const k = .5 + .5 * Math.sin(u * PI * 4), ry = [34, 100, 170, 170, 244, 244][s]; E('rect', { x: 118, y: ry - 34, width: 238, height: 68, rx: 8, fill: 'none', stroke: '#c04a7a', 'stroke-width': 1.4, opacity: f1(.3 + .5 * k) }, g); }
  }));

/* ═════════ ডিম্বাশয়ের লম্বচ্ছেদ: ফলিকলের বিকাশ ═════════ */
const OC = [180, 152];
const OF = [['prim', 92, 86, 6], ['pri', 120, 58, 11], ['sec', 170, 40, 17], ['ter', 238, 52, 26], ['graaf', 280, 128, 36], ['ovn', 330, 150, 0], ['ch', 258, 222, 22], ['cl', 176, 238, 30], ['ca', 98, 214, 16]];
V.ovaryLS = Object.assign({ t: 'ডিম্বাশয়ের লম্বচ্ছেদ: ফলিকলের বিকাশ', k: ['2d', 'anim', 'int', 'quiz'], cap: 'একটি ডিম্বাশয়ে একসাথে সব ধাপ থাকে না — বোঝার সুবিধায় ঘড়ির কাঁটার দিকে একটি চক্রের সব ধাপ এক ছবিতে দেখানো (পাঠ্যবইয়ের রীতি)। প্রতি চক্রে প্রায় 15–20টি ফলিকল বাড়তে শুরু করলেও সাধারণত একটিই পরিণত হয়ে ডিম্বপাত ঘটায়, বাকিগুলো ক্ষয় (অ্যাট্রেশিয়া) হয়।' },
  BK.diagram({ W: 360, H: 290, label: 'ডিম্বাশয়', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      B.organ(P('cor'), B.ellD(OC[0], OC[1], 156, 116, 0), 'ova', { sw: 1.2, gr: { cx: .4, cy: .35, r: .9 } }); E('path', { d: B.ellD(OC[0], OC[1], 156, 116, 0), fill: 'none', stroke: '#e8d0a0', 'stroke-width': 3, 'stroke-dasharray': '2 1.6' }, P('ge'));
      B.organ(P('med'), B.ellD(OC[0], OC[1] + 6, 62, 38, 0), 'endm', { sw: .6, op: .55 }); [[150, 150], [200, 166], [176, 140]].forEach(([x, y], i) => E('path', { d: `M${x - 20} ${y}q10 -8 20 0t20 0`, stroke: i % 2 ? B.TS('vein').c : B.TS('art').c, 'stroke-width': 2.4, fill: 'none' }, P('med')));
      const oo = (g2, x, y, r) => { E('circle', { cx: x, cy: y, r: r + 2, fill: 'none', stroke: '#f4e0f0', 'stroke-width': 2.4 }, g2); E('circle', { cx: x, cy: y, r, fill: '#f8f0ff', stroke: '#8a6aa8', 'stroke-width': .7 }, g2); E('circle', { cx: x, cy: y, r: r * .35, fill: '#c8b8e8' }, g2); };
      OF.forEach(([k, x, y, r]) => { const gg = P(k);
        if (k === 'prim') { E('circle', { cx: x, cy: y, r, fill: '#fdf6ee', stroke: '#c0a080', 'stroke-width': .7 }, gg); oo(gg, x, y, r * .55); }
        if (k === 'pri') { E('circle', { cx: x, cy: y, r, fill: '#f8d8a8', stroke: '#a0603a', 'stroke-width': .8 }, gg); oo(gg, x, y, r * .45); }
        if (k === 'sec' || k === 'ter' || k === 'graaf') { E('circle', { cx: x, cy: y, r: r + 3, fill: '#e8b090', stroke: '#a05a3a', 'stroke-width': .8 }, gg); E('circle', { cx: x, cy: y, r, fill: '#f8d8a8' }, gg); const ar = k === 'sec' ? r * .35 : r * .66; E('path', { d: B.ellD(x + r * .16, y - r * .05, ar, ar * .9, 0), fill: '#fff8e8', stroke: '#d0b080', 'stroke-width': .5 }, gg); oo(gg, x - r * (k === 'graaf' ? .54 : .4), y + r * .22, Math.min(9, r * .22)); }
        if (k === 'ovn') { E('path', { d: `M${x - 24} ${y - 10}l14 4`, stroke: '#c0392b', 'stroke-width': 1.6 }, gg); oo(gg, x, y, 8); let cr = ''; for (let i = 0; i < 12; i++) cr += B.ellD(x + Math.cos(i * .52) * 13, y + Math.sin(i * .52) * 13, 2, 2, 0); E('path', { d: cr, fill: '#f8d8a8', stroke: '#a0603a', 'stroke-width': .4 }, gg); }
        if (k === 'ch') { E('circle', { cx: x, cy: y, r, fill: '#d87a6a', stroke: '#8a3a2a', 'stroke-width': .8 }, gg); E('circle', { cx: x, cy: y, r: r * .5, fill: '#a83030' }, gg); }
        if (k === 'cl') { B.organ(gg, B.ellD(x, y, r, r * .9, 0), 'adc', { sw: .8 }); let fd = ''; for (let i = 0; i < 16; i++) fd += `M${x} ${y}l${f1(Math.cos(i * .39) * r * .8)} ${f1(Math.sin(i * .39) * r * .72)}`; E('path', { d: fd, stroke: '#c0a040', 'stroke-width': .7 }, gg); }
        if (k === 'ca') E('path', { d: B.ellD(x, y, r, r * .8, 20), fill: '#f6f4ee', stroke: '#b0a890', 'stroke-width': .8 }, gg); });
      E('path', { d: 'M100 72Q150 30 214 40M270 70Q300 92 292 104M300 170Q290 210 276 214M236 236Q214 248 204 244M146 240Q120 234 112 222', stroke: FK.alpha('#1a4a8a', .45), 'stroke-width': 1.2, fill: 'none', 'marker-end': B.mk(g, FK.alpha('#1a4a8a', .6), 5), 'stroke-dasharray': '4 3' }, g);
      hits(this.parts, part, 8); },
    idle(g, C, t) { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx: 330, cy: 150, r: f1(18 + k * 4), fill: 'none', stroke: '#c0392b', 'stroke-width': 1, opacity: f1(.6 - k * .4) }, g); },
    parts: [
      { id: 'prim', bn: 'আদি (প্রিমর্ডিয়াল) ফলিকল', lb: 'আদি ফলিকল', en: 'Primordial follicle', fn: 'প্রাথমিক উওসাইট ঘিরে এক স্তর চ্যাপ্টা কোষ — জন্ম থেকেই থাকে, প্রোফেজ-I এ থেমে।', a: [92, 86], l: [40, 30], an: 'middle' },
      { id: 'pri', bn: 'প্রাথমিক ফলিকল', lb: 'প্রাথমিক ফলিকল', en: 'Primary follicle', fn: 'ঘনক আকৃতির গ্রানুলোসা কোষ, উওসাইটের চারপাশে জোনা পেলুসিডা তৈরি শুরু।', a: [120, 58], l: [120, 14], an: 'middle' },
      { id: 'sec', bn: 'গৌণ ফলিকল', lb: 'গৌণ ফলিকল', en: 'Secondary follicle', fn: 'বহুস্তর গ্রানুলোসা, বাইরে থিকা স্তর; তরলের ছোট ছোট ফাঁক তৈরি হয় — ইস্ট্রোজেন ক্ষরণ শুরু।', a: [170, 40], l: [200, 14], an: 'middle' },
      { id: 'ter', bn: 'তৃতীয় (অ্যান্ট্রাল) ফলিকল', lb: 'অ্যান্ট্রাল ফলিকল', en: 'Tertiary follicle', fn: 'তরলভরা বড় গহ্বর (অ্যান্ট্রাম) — FSH এর প্রভাবে দ্রুত বড় হয়; একটি প্রধান হয়।', a: [238, 52], l: [300, 18], an: 'middle' },
      { id: 'graaf', bn: 'গ্রাফিয়ান (পরিণত) ফলিকল', lb: 'গ্রাফিয়ান ফলিকল', en: 'Graafian follicle', fn: 'প্রায় 18–25 মিলিমিটার — বড় অ্যান্ট্রাম, কিউমুলাস ঢিবিতে গৌণ উওসাইট; ডিম্বাশয়ের তলে ফুলে ওঠে; প্রচুর ইস্ট্রোজেন ক্ষরণ করে। নামটি ডাচ চিকিৎসক রেনিয়ার দ্য গ্রাফের (1672)।', a: [280, 128], l: [324, 64], an: 'middle' },
      { id: 'ovn', bn: 'ডিম্বপাত (গৌণ উওসাইট ও করোনা রেডিয়াটা)', lb: 'ডিম্বপাত', en: 'Ovulation', fn: 'LH সার্জে ফলিকল ফেটে গৌণ উওসাইট (জোনা পেলুসিডা ও করোনা রেডিয়াটা কোষসহ) মুক্ত হয়।', a: [330, 150], l: [330, 196], an: 'middle' },
      { id: 'ch', bn: 'কর্পাস হেমোরেজিকাম', lb: 'কর্পাস হেমোরেজিকাম', en: 'Corpus haemorrhagicum', fn: 'ফাটা ফলিকলে জমাট রক্ত — কয়েক দিনেই কর্পাস লুটিয়ামে পরিণত হয়।', a: [258, 222], l: [300, 276], an: 'middle' },
      { id: 'cl', bn: 'কর্পাস লুটিয়াম (পীতগ্রন্থি)', lb: 'কর্পাস লুটিয়াম', en: 'Corpus luteum', fn: 'লুটেইন রঞ্জকে হলুদ অস্থায়ী অন্তঃক্ষরা গ্রন্থি — প্রোজেস্টেরন ও ইস্ট্রোজেন ক্ষরণ করে; গর্ভ হলে hCG এর প্রভাবে প্রায় 3 মাস টিকে থাকে।', a: [176, 238], l: [176, 284], an: 'middle' },
      { id: 'ca', bn: 'কর্পাস অ্যালবিকান্স', lb: 'কর্পাস অ্যালবিকান্স', en: 'Corpus albicans', fn: 'গর্ভ না হলে নষ্ট কর্পাস লুটিয়ামের সাদা ক্ষতচিহ্ন।', a: [98, 214], l: [60, 270], an: 'middle' },
      { id: 'ge', bn: 'জনন আবরণী (বাইরের স্তর)', lb: 'জনন আবরণী', en: 'Germinal epithelium', fn: 'ডিম্বাশয়ের বাইরের এক স্তর ঘনক কোষ (নাম বিভ্রান্তিকর — এখান থেকে ডিম্বাণু তৈরি হয় না)।', a: [24, 152], l: [14, 120], an: 'start' },
      { id: 'med', bn: 'মেডালা (রক্তনালি)', lb: 'মেডালা', en: 'Medulla', fn: 'কেন্দ্রের আলগা যোজক কলা — রক্তনালি, লসিকা ও স্নায়ু।', a: [180, 158], l: [14, 186], an: 'start' },
      { id: 'cor', bn: 'কর্টেক্স (স্ট্রোমা)', lb: 'কর্টেক্স', en: 'Cortex', fn: 'বাইরের ঘন অংশ — ফলিকলগুলো এখানে থাকে।', a: [120, 130], l: [14, 154], an: 'start' }
    ]
  }));

/* ═════════ নিষেক ═════════ */
const FZ = [
  { t: 'শুক্রাণুর যাত্রা ও ক্যাপাসিটেশন', en: 'Capacitation', d: 'বীর্যপাতের কয়েক কোটি শুক্রাণুর মাত্র কয়েকশো ফ্যালোপিয়ান নালির অ্যাম্পুলায় পৌঁছায়। স্ত্রী জননপথে প্রায় কয়েক ঘণ্টায় শুক্রাণুর ঝিল্লি বদলে নিষেকক্ষম হয় (ক্যাপাসিটেশন)। শুক্রাণু প্রায় 2–3 দিন বাঁচে।' },
  { t: 'করোনা রেডিয়াটা পেরোনো', en: 'Corona radiata', d: 'শুক্রাণু ডিম্বাণুর চারপাশের ফলিকল কোষের স্তর (করোনা রেডিয়াটা) ঠেলে ও এনজাইমে পথ করে ঢোকে।' },
  { t: 'অ্যাক্রোসোম বিক্রিয়া', en: 'Acrosome reaction', d: 'জোনা পেলুসিডার ZP3 গ্লাইকোপ্রোটিনে বসলে অ্যাক্রোসোম ফেটে অ্যাক্রোসিন ইত্যাদি এনজাইম ছাড়ে — জোনায় সরু পথ তৈরি হয় (প্রজাতিনির্দিষ্ট চেনাজানা)।' },
  { t: 'ঝিল্লি মিলন ও কর্টিক্যাল বিক্রিয়া', en: 'Fusion, block to polyspermy', d: 'একটি শুক্রাণুর ঝিল্লি উওসাইটের ঝিল্লিতে মিশে নিউক্লিয়াস ভেতরে ঢোকে; সাথে সাথে কর্টিক্যাল দানা এনজাইম ছেড়ে জোনাকে শক্ত করে — অন্য শুক্রাণু আর ঢুকতে পারে না (বহুশুক্রাণু প্রবেশ রোধ)।' },
  { t: 'মিয়োসিস-II সম্পূর্ণ', en: 'Meiosis II completes', d: 'শুক্রাণু প্রবেশের উদ্দীপনায় গৌণ উওসাইট মিয়োসিস-II শেষ করে পরিণত ডিম্বাণু ও দ্বিতীয় পোলার বডি তৈরি করে।' },
  { t: 'জাইগোট (2n)', en: 'Zygote', d: 'পুরুষ ও স্ত্রী প্রোনিউক্লিয়াস কাছে এসে মিলে যায় (অ্যাম্ফিমিক্সিস) — 46 ক্রোমোজোমের জাইগোট; লিঙ্গ নির্ধারিত (XX মেয়ে, XY ছেলে) এবং প্রথম বিভাজন শুরু হয়।' }
];
V.fertilization = Object.assign({ t: 'নিষেক: শুক্রাণু ও ডিম্বাণুর মিলন', k: ['2d', 'anim', 'steps'], cap: 'হ্যাপ্লয়েড শুক্রাণু (n) ও ডিম্বাণুর (n) নিউক্লিয়াসের মিলনে ডিপ্লয়েড জাইগোট (2n) সৃষ্টিকে নিষেক বলে। মানুষে অন্তঃনিষেক — সাধারণত ডিম্বপাতের 12–24 ঘণ্টার মধ্যে ফ্যালোপিয়ান নালির অ্যাম্পুলায়। চিত্রে আকার আপেক্ষিক — উওসাইট শুক্রাণুর মাথার চেয়ে প্রায় 20 গুণ চওড়া।' },
  BK.steps({ W: 360, H: 280, label: 'নিষেক', dur: 3, stages: FZ,
    draw(g, C, s, u) { const cx = 190, cy = 140;
      B.cacheG(g, 'fzb', gg => { let q = 0; const rnd = () => B.rnd(++q); let cr = ''; [[101, 30, 10, 6.6], [115, 34, 9, 5.6]].forEach(([R0, n, a1, a2], k) => { for (let i = 0; i < n; i++) { const a = (i + k * .5 + (rnd() - .5) * .4) / n * 2 * PI, r = R0 + (rnd() - .5) * 4; cr += B.ellD(cx + Math.cos(a) * r, cy + Math.sin(a) * r, a1 * (.8 + rnd() * .4), a2 * (.8 + rnd() * .4), a * 57 + (rnd() - .5) * 40); } }); E('path', { d: cr, fill: '#f6d4a4', stroke: '#b07a50', 'stroke-width': .4 }, gg); });
      B.cacheG(g, 'fzo' + Math.min(s, 3), go => { E('circle', { cx, cy, r: 88, fill: s >= 3 ? '#e8d8f0' : '#f4e6f6', stroke: s >= 3 ? '#6a3a9a' : '#b89ac8', 'stroke-width': s >= 3 ? 5 : 8 }, go); E('circle', { cx, cy, r: 80, fill: '#fdf6ec', stroke: '#b89060', 'stroke-width': .8 }, go); });
      const gran = (gx, r) => { let cg = ''; for (let i = 0; i < 30; i++) { const a = i / 30 * 2 * PI; cg += B.ellD(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 1.6, 1.6, 0); } E('path', { d: cg, fill: '#6a3a9a' }, gx); };
      if (s === 3) gran(g, 82 + u * 6); else if (s > 3) B.cacheG(g, 'fzg', gx => gran(gx, 88));
      /* স্ত্রী নিউক্লিয়াস */ if (s < 4) { [[0, -6], [6, 2], [-6, 4]].forEach(([dx, dy], i) => E('path', { d: `M${cx + 20 + dx} ${cy - 30 + dy}v10`, stroke: ['#c0392b', '#2a6ab0', '#e08a2a'][i], 'stroke-width': 2.4 }, g)); E('path', { d: `M${cx + 12} ${cy - 22}h18`, stroke: FK.alpha('#444', .4), 'stroke-width': .8 }, g); }
      else { const m = s === 5 ? u : 0; E('circle', { cx: f1(cx + 20 - m * 16), cy: f1(cy - 6), r: 18, fill: '#f8e0ec', stroke: '#c04a7a', 'stroke-width': 1.2 }, g); E('circle', { cx: f1(cx - 24 + m * 18), cy: f1(cy + 4), r: 16, fill: '#e0ecf8', stroke: '#2a6ab0', 'stroke-width': 1.2 }, g); if (s === 4) E('circle', { cx: f1(cx + 56), cy: f1(cy - 94 + (1 - u) * 20), r: 6, fill: '#f8f0ff', stroke: '#8a6aa8', 'stroke-width': .8 }, g); }
      E('circle', { cx: cx + 50, cy: cy - 96, r: 7, fill: '#f8f0ff', stroke: '#8a6aa8', 'stroke-width': .8 }, g);
      /* শুক্রাণু */ let gT = g; const sperm = (x, y, a, fat) => { const g = gT; E('path', { d: B.ellD(x, y, 6, 3.6, a * 57), fill: '#5a4a8a' }, g); let d = `M${f1(x - Math.cos(a) * 6)} ${f1(y - Math.sin(a) * 6)}`; for (let i = 1; i <= 8; i++) { const L = 6 + i * 5, w = Math.sin(i * 1.3 + u * 20) * 3; d += `L${f1(x - Math.cos(a) * L - Math.sin(a) * w)} ${f1(y - Math.sin(a) * L + Math.cos(a) * w)}`; } E('path', { d, stroke: '#6a5a8a', 'stroke-width': 1, fill: 'none' }, g); };
      const pos = [[8, 220, -.5], [330, 260, -2.5], [340, 40, 2.6]]; B.cacheG(g, 'fzs', gs => { gT = gs; pos.forEach(([x, y, a]) => sperm(x + 40 * Math.cos(a), y + 40 * Math.sin(a), a)); gT = g; });
      if (s === 0) { const k = u, tx = cx - 72, ty = cy - 69; sperm(f1(20 + (tx - 20) * k), f1(30 + (ty - 30) * k), .6); }
      if (s >= 1 && s <= 3) { const p = [[cx - 72, cy - 69], [cx - 64, cy - 60], [cx - 50, cy - 48]][s - 1]; sperm(p[0], p[1], .75); if (s === 2) E('circle', { cx: p[0], cy: p[1], r: f1(4 + u * 8), fill: 'none', stroke: '#e08a2a', 'stroke-width': 1.4, opacity: f1(1 - u) }, g); }
      B.cacheG(g, 'fzl' + s, gl => { B.tx(gl, 8, 18, FZ[s].t, { fs: 10.4, w: 700, c: '#a8201a' }); if (s === 0) B.tx(gl, 352, 272, 'অ্যাম্পুলা', { fs: 9.8, a: 'end', c: C.mu }); B.tx(gl, 300, 126, 'জোনা পেলুসিডা', { fs: 9.8, c: '#6a3a9a' }); B.tx(gl, 8, 272, 'করোনা রেডিয়াটা', { fs: 9.8, c: '#a0603a' }); }); }
  }));

/* ═════════ বিভাজন ও প্রোথন (ইমপ্লান্টেশন) ═════════ */
const IM = [
  { t: 'জাইগোট (দিন 0–1)', en: 'Zygote', d: 'অ্যাম্পুলায় নিষেক — জাইগোট নালির সিলিয়া ও পেশির ঢেউয়ে জরায়ুর দিকে চলতে থাকে।' },
  { t: 'ক্লিভেজ (দিন 1–3)', en: 'Cleavage', d: 'দ্রুত মাইটোসিস: 2, 4, 8 কোষ (ব্লাস্টোমিয়ার) — মোট আকার বাড়ে না, কোষ ছোট হয়; জোনা পেলুসিডা তখনও থাকে।' },
  { t: 'মরুলা (দিন 3–4)', en: 'Morula', d: '16–32 কোষের নিরেট তুঁতফলের মতো বল — জরায়ুতে প্রবেশ করে।' },
  { t: 'ব্লাস্টোসিস্ট (দিন 5)', en: 'Blastocyst', d: 'ভেতরে তরলভরা গহ্বর (ব্লাস্টোসিল); বাইরের এক স্তর ট্রফোব্লাস্ট (পরে অমরা), এক পাশে অন্তঃকোষপুঞ্জ (পরে ভ্রূণ)। জোনা থেকে বেরিয়ে আসে (হ্যাচিং)।' },
  { t: 'প্রোথন (দিন 6–10)', en: 'Implantation', d: 'অন্তঃকোষপুঞ্জের দিক দিয়ে ব্লাস্টোসিস্ট এন্ডোমেট্রিয়ামে লেগে যায়; ট্রফোব্লাস্ট এনজাইম দিয়ে আস্তরে ঢুকে যায় ও hCG ক্ষরণ শুরু করে — কর্পাস লুটিয়াম টিকে থাকে, রজঃস্রাব হয় না। সাধারণত জরায়ুর ওপরের পেছনের প্রাচীরে।' }
];
const IMP = [[300, 96], [262, 84], [230, 84], [196, 104], [182, 150]];
V.implantation = Object.assign({ t: 'নিষেক থেকে প্রোথন', k: ['2d', 'anim', 'steps'], cap: 'নিষিক্ত ডিম্বাণু প্রায় এক সপ্তাহ ধরে নালি বেয়ে জরায়ুতে পৌঁছে এন্ডোমেট্রিয়ামে প্রোথিত হয় (ইমপ্লান্টেশন)। ব্লাস্টোসিস্ট নালিতেই আটকে গেলে একটোপিক গর্ভ — মায়ের জীবনের জন্য বিপজ্জনক। ভেতরের বড় বৃত্তে প্রতিটি ধাপ বড় করে দেখানো।' },
  BK.steps({ W: 360, H: 280, label: 'প্রোথন', dur: 3, stages: IM,
    draw(g, C, s, u) { B.cacheG(g, 'imb', gg => { B.organ(gg, sm([[140, 80], [180, 70], [220, 80], [228, 130], [214, 182], [196, 210], [164, 210], [146, 182], [132, 130]], true, .45), 'ut', { sw: .9 }); B.organ(gg, sm([[150, 92], [180, 84], [210, 92], [196, 140], [186, 176], [174, 176], [164, 140]], true, .35), 'endm', { sw: .6 }); E('path', { d: sm([[160, 98], [180, 92], [200, 98], [188, 138], [182, 168], [178, 168], [172, 138]], true, .35), fill: '#fff4f6' }, gg);
        B.tube(gg, sm([[214, 90], [240, 80], [272, 82], [300, 94], [320, 118]], false, .5), 9, 'endm', { sw: .6, hl: false }); B.organ(gg, B.ellD(318, 150, 22, 13, 0), 'ova', { sw: .8 }); B.tx(gg, 318, 182, 'ডিম্বাশয়', { fs: 9.8, a: 'middle', c: C.mu }); B.tx(gg, 296, 70, 'অ্যাম্পুলা', { fs: 9.8, a: 'middle', c: C.mu }); B.tx(gg, 180, 228, 'জরায়ু', { fs: 9.8, a: 'middle', c: C.mu }); });
      const p = IMP[s]; E('circle', { cx: p[0], cy: p[1], r: 5, fill: '#f8f0ff', stroke: '#c04a7a', 'stroke-width': 1.4 }, g); E('circle', { cx: p[0], cy: p[1], r: f1(6 + u * 6), fill: 'none', stroke: '#c04a7a', 'stroke-width': 1, opacity: f1(1 - u) }, g);
      /* বড় করে দেখানো */ const X = 64, Y = 150, R = 50; E('circle', { cx: X, cy: Y, r: R + 6, fill: C.sf, stroke: C.mu, 'stroke-width': .8 }, g); E('path', { d: `M${X + R + 6} ${Y}L${p[0] - 6} ${p[1]}`, stroke: FK.alpha(C.mu, .5), 'stroke-width': .7, 'stroke-dasharray': '3 2' }, g);
      if (s <= 2) E('circle', { cx: X, cy: Y, r: R - 6, fill: 'none', stroke: '#c8b0dc', 'stroke-width': 4 }, g);
      if (s === 0) { E('circle', { cx: X, cy: Y, r: R - 10, fill: '#fdf6ec', stroke: '#b89060', 'stroke-width': .8 }, g); E('circle', { cx: X - 8, cy: Y, r: 9, fill: '#f8e0ec', stroke: '#c04a7a' }, g); E('circle', { cx: X + 8, cy: Y, r: 9, fill: '#e0ecf8', stroke: '#2a6ab0' }, g); }
      if (s === 1) { const n = u < .33 ? 2 : u < .66 ? 4 : 8, rr = n === 2 ? 18 : n === 4 ? 14 : 11; for (let i = 0; i < n; i++) { const a = i / n * 2 * PI + .4; E('circle', { cx: f1(X + Math.cos(a) * rr * .9), cy: f1(Y + Math.sin(a) * rr * .9), r: rr, fill: '#fdf0e4', stroke: '#b89060', 'stroke-width': .8 }, g); } }
      if (s === 2) { for (let i = 0; i < 16; i++) { const a = i * 2.4, r = 8 + (i % 4) * 7; E('circle', { cx: f1(X + Math.cos(a) * r * .9), cy: f1(Y + Math.sin(a) * r * .9), r: 8, fill: '#fdf0e4', stroke: '#b89060', 'stroke-width': .7 }, g); } }
      if (s >= 3) { const by = s === 4 ? Y - 8 : Y, br = s === 4 ? R - 14 : R - 8; if (s === 4) { E('path', { d: `M${X - R + 4} ${Y + 12}Q${X} ${Y + 2} ${X + R - 4} ${Y + 12}L${X + R - 12} ${Y + R - 12}Q${X} ${Y + R + 6} ${X - R + 12} ${Y + R - 12}Z`, fill: B.TS('endm').c, stroke: B.TS('endm').dk, 'stroke-width': .8 }, g); let gl = ''; for (let i = -3; i <= 3; i++) gl += `M${X + i * 11} ${Y + 16}q2 10 0 20`; E('path', { d: gl, stroke: '#8a3a4a', 'stroke-width': 1, fill: 'none', opacity: .6 }, g); }
        E('circle', { cx: X, cy: by, r: br, fill: '#eef6fb', stroke: '#c08a60', 'stroke-width': 3.4 }, g); let tb = ''; const nt = s === 4 ? 16 : 18; for (let i = 0; i < nt; i++) { const a = i / nt * 2 * PI; tb += B.ellD(X + Math.cos(a) * br, by + Math.sin(a) * br, 3.6, 2.2, a * 57 + 90); } E('path', { d: tb, fill: '#e8c0a0', stroke: '#a07050', 'stroke-width': .4 }, g);
        const ix = s === 4 ? X : X - 22, iy = s === 4 ? by + br - 12 : Y - 10; E('path', { d: B.ellD(ix, iy, s === 4 ? 14 : 14, s === 4 ? 9 : 18, s === 4 ? 0 : 20), fill: '#f2c8d8', stroke: '#a05a7a', 'stroke-width': .8 }, g);
        if (s === 4) { const dp = 4 + u * 5; E('path', { d: `M${X - 16} ${by + br - 2}Q${X} ${by + br + dp * 2} ${X + 16} ${by + br - 2}`, fill: '#c89070', stroke: '#8a5a3a', 'stroke-width': .7, opacity: .9 }, g); for (let i = 0; i < 3; i++) E('circle', { cx: f1(X + 14 + u * 24 + i * 5), cy: f1(by - 6 - i * 8 - u * 10), r: 2.2, fill: '#c0392b', opacity: f1(1 - u) }, g); } }
      B.cacheG(g, 'iml' + s, gl => { B.tx(gl, 8, 18, IM[s].t, { fs: 10.4, w: 700, c: '#a8201a' }); if (s >= 3) { B.tx(gl, 10, 222, 'ট্রফোব্লাস্ট', { fs: 9.8, c: '#a07050' }); B.tx(gl, 10, 236, 'অন্তঃকোষপুঞ্জ', { fs: 9.8, c: '#a05a7a' }); } if (s === 4) B.tx(gl, 10, 250, 'hCG ক্ষরণ শুরু', { fs: 9.8, w: 700, c: '#c0392b' }); }); }
  }));
})();
