/* ═══════════════════════════════════════════════════════════════════
   visuals0b — অধ্যায় ৭ (চলন) এর নিজস্ব অঙ্কন-সহায়ক (B29 এ যোগ হয়)
   body (পূর্ণ দেহের রেখাচিত্র), রক্তকণিকা (রাইট/লিশম্যান রঞ্জনের রং), ইসিজি তরঙ্গ, কিফ্রেম ইন্টারপোলেশন,
   হৃৎপিণ্ডের সম্মুখ-ছেদ (heartSec) — কয়েকটি চিত্রে একই জ্যামিতি ব্যবহার হয়।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, BK = window.BK, T = BK.T, B = window.B29, PI = Math.PI;
const f1 = v => (+v).toFixed(1);
const sm = (p, c, k) => B.smooth(p, c, k);

/* ─── পূর্ণ দেহ (সামনে থেকে), cx = মধ্যরেখা, y0 = মাথার চূড়া, h = উচ্চতা ─── */
const BODY_R = [[0, 0], [13, 1.5], [21, 10], [24, 26], [22, 41], [17, 52], [11, 58], [10, 66], [11, 73], [26, 79], [44, 83], [55, 91], [60, 108], [63, 138], [67, 168], [71, 196], [75, 222], [79, 246], [84, 258], [87, 274], [84, 288], [78, 289], [74, 272], [70, 252], [63, 224], [55, 192], [51, 156], [47, 130], [44, 120], [44, 142], [42, 172], [38, 200], [37, 214], [40, 232], [44, 252], [45, 272], [43, 302], [39, 338], [35, 358], [35, 380], [31, 410], [25, 424], [30, 433], [27, 440], [9, 440], [10, 427], [12, 402], [14, 372], [12, 352], [10, 312], [6, 282], [0, 270]];
B.bodyPts = (cx, y0, h) => { const s = h / 440, R = BODY_R.map(([x, y]) => [cx + x * s, y0 + y * s]), L = BODY_R.slice(1, -1).reverse().map(([x, y]) => [cx - x * s, y0 + y * s]); return R.concat(L); };
B.body = (g, C, cx, y0, h, o = {}) => { const sk = B.TS('skin'), d = sm(B.bodyPts(cx, y0, h), true, .5);
  E('path', { d, fill: o.fill || FK.alpha(sk.c, C.dark ? .14 : .2), stroke: FK.alpha(sk.dk, .6), 'stroke-width': 1 }, g); return d; };

/* ─── রক্তকণিকা — রাইট/লিশম্যান রঞ্জনের রং ─── */
const memo = (svg, key, mk) => { const m = svg._b29c || (svg._b29c = {}); return m[key] || (m[key] = mk()); };
const svgOf = g => g.ownerSVGElement || g;
let gid = 0;
const defs = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };
/* দ্বি-অবতল চাকতি (সামনে থেকে): কিনারা গাঢ়, মাঝখান ফ্যাকাশে */
B.rbcG = (g, tone) => { const svg = svgOf(g); return memo(svg, 'rbc' + (tone || ''), () => { const id = 'b29rbc' + (++gid), gr = E('radialGradient', { id, cx: .5, cy: .5, r: .5, fx: .46, fy: .44 }, defs(svg));
  const c = tone === 'v' ? ['#e9c7d3', '#c98aa6', '#a0577c', '#7c3d60'] : tone === 'pale' ? ['#fbeae5', '#f2cfc6', '#e2a99d', '#c98679'] : ['#f6d2c8', '#eaa093', '#d8705f', '#b6513f'];
  [[0, c[0]], [.42, c[1]], [.78, c[2]], [1, c[3]]].forEach(([o, s]) => E('stop', { offset: o, 'stop-color': s }, gr)); return `url(#${id})`; }); };
B.rbcFace = (g, x, y, r, o = {}) => E('ellipse', { cx: f1(x), cy: f1(y), rx: f1(r * (o.sx || 1)), ry: f1(r * (o.sy || 1)), fill: B.rbcG(g, o.tone), stroke: o.tone === 'v' ? '#6a3352' : '#a24a3a', 'stroke-width': o.sw || .45, opacity: o.op != null ? o.op : 1, transform: o.rot ? `rotate(${f1(o.rot)} ${f1(x)} ${f1(y)})` : null }, g);
/* অণুচক্রিকা */
B.plt = (g, x, y, r = 2.2, seed = 1) => { let d = ''; for (let i = 0; i < 7; i++) { const a = i / 7 * 2 * PI, rr = r * (.7 + B.rnd(seed * 3 + i) * .5); d += (i ? 'L' : 'M') + f1(x + rr * Math.cos(a)) + ' ' + f1(y + rr * .8 * Math.sin(a)); }
  E('path', { d: d + 'Z', fill: '#c7a6d8', stroke: '#7d559b', 'stroke-width': .5 }, g); E('circle', { cx: f1(x), cy: f1(y), r: r * .35, fill: '#6f4590' }, g); };
/* দানা (একটি পথে) — কোষের ভেতরে এলোমেলো */
const gran = (x, y, R, n, gr, seed, avoid) => { let d = ''; const m = Math.max(1, R / 14); n = Math.round(n * m); gr /= Math.sqrt(m) * .9; for (let i = 0; i < n; i++) { const a = B.rnd(seed + i * 1.7) * 2 * PI, rr = Math.sqrt(B.rnd(seed * 2 + i * 3.1)) * R, px = x + rr * Math.cos(a), py = y + rr * Math.sin(a);
  if (avoid && avoid(px, py)) continue; d += B.ellD(px, py, gr, gr * .85, 0); } return d; };
/* লোব যুক্ত নিউক্লিয়াস: lobes = [[dx,dy,r]...] — সরু সুতা দিয়ে যুক্ত */
const lobed = (g, x, y, L, col, dk) => { let d = ''; L.forEach(([dx, dy, r], i) => { d += B.ellD(x + dx, y + dy, r, r * .82, i * 37); });
  E('path', { d: L.slice(1).map(([dx, dy], i) => `M${f1(x + L[i][0])} ${f1(y + L[i][1])}L${f1(x + dx)} ${f1(y + dy)}`).join(''), stroke: dk, 'stroke-width': 1.3, fill: 'none' }, g);
  E('path', { d, fill: col, stroke: dk, 'stroke-width': .6 }, g); };
/* শ্বেত কণিকা: type = neu | eos | bas | lym | mon; r = ব্যাসার্ধ (px) */
B.wbc = (g, x, y, r, type, o = {}) => { const seed = o.seed || 3, sc = r / 10;
  const outl = (fill, st) => E('path', { d: sm(Array.from({ length: 10 }, (_, i) => { const a = i / 10 * 2 * PI, rr = r * (.94 + B.rnd(seed * 5 + i) * .1); return [x + rr * Math.cos(a), y + rr * Math.sin(a)]; }), true, .5), fill, stroke: st, 'stroke-width': .7 }, g);
  if (type === 'neu') { outl('#efd9e6', '#b78aa8'); E('path', { d: gran(x, y, r * .85, 40, .55 * sc, seed), fill: '#c79ec4' }, g);
    lobed(g, x, y, [[-4.6, -2.6, 3], [-.6, -4.8, 2.8], [3.8, -1.4, 3], [1.6, 3.8, 2.9]].map(([a, b, c]) => [a * sc, b * sc, c * sc]), '#5b3b8f', '#36205f'); }
  else if (type === 'eos') { outl('#f6dccf', '#c78a73');
    lobed(g, x, y, [[-3.8, -1, 3.6], [3.8, -.6, 3.6]].map(([a, b, c]) => [a * sc, b * sc, c * sc]), '#5e3f93', '#3a2463');
    E('path', { d: gran(x, y, r * .86, 70, 1.05 * sc, seed, (px, py) => Math.hypot(px - x + 3.8 * sc, py - y + sc) < 2.6 * sc || Math.hypot(px - x - 3.8 * sc, py - y + .6 * sc) < 2.6 * sc), fill: '#e2694a', stroke: '#b4442b', 'stroke-width': .25 }, g); }
  else if (type === 'bas') { outl('#e4d6ee', '#8a6aa8'); lobed(g, x, y, [[-2.4, -.6, 3.8], [2.6, .8, 3.4]].map(([a, b, c]) => [a * sc, b * sc, c * sc]), '#8a72b8', '#5a4489');
    E('path', { d: gran(x, y, r * .84, 46, 1.25 * sc, seed), fill: '#2e1650', stroke: '#1d0d36', 'stroke-width': .2 }, g); }
  else if (type === 'lym') { outl('#bcd6f0', '#6e94bf'); const nr = r * .82; E('path', { d: B.ellD(x - r * .08, y + r * .04, nr, nr * .94, 20), fill: '#3f2b7a', stroke: '#24164e', 'stroke-width': .6 }, g);
    E('path', { d: gran(x - r * .08, y, nr * .8, 14, .7 * sc, seed), fill: '#2a1a5a' }, g); }
  else if (type === 'mon') { outl('#d2d7e6', '#8b93b0'); E('path', { d: gran(x, y, r * .8, 6, 1.3 * sc, seed + 9), fill: '#f4f6fb', stroke: '#aab0c6', 'stroke-width': .3 }, g);
    /* বৃক্কাকার নিউক্লিয়াস */
    const k = sc; E('path', { d: `M${f1(x - 6.6 * k)} ${f1(y - 2 * k)}C${f1(x - 6 * k)} ${f1(y - 7.4 * k)} ${f1(x + 4 * k)} ${f1(y - 7.6 * k)} ${f1(x + 6 * k)} ${f1(y - 3 * k)}C${f1(x + 7.4 * k)} ${f1(y + .5 * k)} ${f1(x + 5.6 * k)} ${f1(y + 5.4 * k)} ${f1(x + 2.4 * k)} ${f1(y + 5.2 * k)}C${f1(x)} ${f1(y + 5 * k)} ${f1(x + .4 * k)} ${f1(y + 1.4 * k)} ${f1(x - 1.6 * k)} ${f1(y + 1.6 * k)}C${f1(x - 3.4 * k)} ${f1(y + 1.8 * k)} ${f1(x - 3.4 * k)} ${f1(y + 5.4 * k)} ${f1(x - 5.2 * k)} ${f1(y + 4.6 * k)}C${f1(x - 7 * k)} ${f1(y + 3.8 * k)} ${f1(x - 7 * k)} ${f1(y + 1 * k)} ${f1(x - 6.6 * k)} ${f1(y - 2 * k)}Z`, fill: '#7a66b2', stroke: '#45357a', 'stroke-width': .6 }, g);
    E('path', { d: gran(x, y - 1.5 * k, 4.5 * k, 16, .5 * k, seed + 4), fill: '#4d3c86' }, g); }
};

/* ─── ইসিজি (লিড II): এক বিটের ভেতরে সময় t (সেকেন্ড), k = বিটের সময়-মাপ (সিস্টোলের অংশ) ─── */
const gs = (t, c, w, a) => a * Math.exp(-((t - c) * (t - c)) / (2 * w * w));
/* o = { p (P এর কেন্দ্র), r (R এর কেন্দ্র), tq (T এর কেন্দ্র), st (ST বিচ্যুতি mV), tAmp } */
B.ecgV = (t, o = {}) => { const p = o.p != null ? o.p : .03, r = o.r != null ? o.r : .1, tq = o.tq != null ? o.tq : .33, st = o.st || 0, ta = o.tAmp != null ? o.tAmp : .3;
  let v = (o.noP ? 0 : gs(t, p, .02, .14)) + gs(t, r - .016, .006, -.1) + gs(t, r, .0075, 1.05) + gs(t, r + .018, .007, -.24) + gs(t, tq, .038, ta);
  if (st) { const a = r + .03, b = tq; if (t > a && t < b + .03) v += st * Math.min(1, (t - a) / .015) * Math.min(1, (b + .03 - t) / .05); }
  return v; };
/* কিফ্রেম ইন্টারপোলেশন (মসৃণ): K = [[t, v], ...] (t ক্রমবর্ধমান), কোসাইন-মসৃণ */
B.kf = (K, t) => { if (t <= K[0][0]) return K[0][1]; for (let i = 1; i < K.length; i++) if (t <= K[i][0]) { const [t0, v0] = K[i - 1], [t1, v1] = K[i], u = (t - t0) / (t1 - t0 || 1), s = (1 - Math.cos(u * PI)) / 2; return v0 + (v1 - v0) * s; } return K[K.length - 1][1]; };
/* পথ বরাবর বিন্দু: pts (ঘন) → দৈর্ঘ্যভিত্তিক অবস্থান u (০–১) */
B.along = pts => { const L = [0]; for (let i = 1; i < pts.length; i++) L.push(L[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); const tot = L[L.length - 1];
  return u => { const d = ((u % 1) + 1) % 1 * tot; let i = 1; while (i < L.length - 1 && L[i] < d) i++; const k = (d - L[i - 1]) / ((L[i] - L[i - 1]) || 1); return [pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * k, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * k]; }; };

/* ─── হৃৎপিণ্ডের সম্মুখ-ছেদ (frontal section) — দর্শকের বাঁ = দেহের ডান ───
   ৩৬০ × ~৩৫০ এর জায়গায়; o = { ox, oy, s, sys (নিলয়ের সংকোচন ০–১), asys (অলিন্দের), av (AV কপাটিকা খোলা ০–১), sl (অর্ধচন্দ্র কপাটিকা খোলা ০–১), mono (রঙহীন কাঠামো) }
   বিন্দুর ট্যাগ: v = নিলয়ের, a = অলিন্দের (সংকোচনে নিজ কেন্দ্রের দিকে সরে) */
const HP = {
  outer: [[70, 190, 'a'], [72, 150, 'a'], [80, 124, 'a'], [100, 108], [146, 112, 'a'], [168, 132, 'a'], [178, 150], [198, 152], [204, 166], [232, 164], [238, 140, 'a'], [262, 124, 'a'], [302, 128, 'a'], [322, 154, 'a'], [326, 194, 'v'], [316, 240, 'v'], [294, 286, 'v'], [266, 322, 'v'], [242, 340, 'v'], [214, 334, 'v'], [176, 316, 'v'], [130, 294, 'v'], [96, 266, 'v'], [80, 232]],
  right: [[88, 138, 'a'], [100, 122, 'a'], [110, 112], [110, 98], [134, 98], [134, 114], [148, 124, 'a'], [162, 140, 'a'], [166, 166, 'a'], [160, 188, 'a'], [156, 204], [172, 200, 'v'], [178, 180], [180, 157], [196, 155], [196, 180], [190, 214, 'v'], [194, 250, 'v'], [204, 292, 'v'], [200, 304, 'v'], [178, 302, 'v'], [146, 290, 'v'], [118, 266, 'v'], [104, 240, 'v'], [102, 210], [96, 212], [96, 238], [84, 238], [84, 210], [82, 180, 'a']],
  left: [[222, 140, 'a'], [256, 130, 'a'], [294, 136, 'a'], [304, 146], [318, 146], [318, 158], [304, 160], [304, 168], [318, 168], [318, 180], [300, 184, 'a'], [290, 198], [300, 224, 'v'], [294, 260, 'v'], [274, 294, 'v'], [250, 316, 'v'], [238, 318, 'v'], [230, 298, 'v'], [222, 262, 'v'], [214, 226, 'v'], [210, 196], [206, 169], [228, 167], [232, 186], [242, 198], [238, 182, 'a'], [230, 162, 'a']],
  cRV: [150, 258], cLV: [258, 262], cRA: [124, 162], cLA: [262, 158]
};
B.HP = HP;
B.heartSec = (g, C, o = {}) => {
  const s = o.s || 1, ox = o.ox || 0, oy = o.oy || 0, P = ([x, y]) => [ox + x * s, oy + y * s], PP = a => a.map(P), W = w => w * s;
  const mu = B.TS('mus'), sys = o.sys || 0, asys = o.asys || 0;
  /* ট্যাগ অনুযায়ী সংকোচন */
  const mv = (pts, kv, ka, cv, ca) => pts.map(([x, y, tg]) => { const k = tg === 'v' ? kv : tg === 'a' ? ka : 0, c = tg === 'v' ? (typeof cv === 'function' ? cv(x) : cv) : ca; return k ? [c[0] + (x - c[0]) * (1 - k), c[1] + (y - c[1]) * (1 - k)] : [x, y]; });
  const near = x => x < 205 ? HP.cRV : HP.cLV;
  const bl = k => o.mono ? FK.alpha(B.TS(k).c, .35) : B.lin(g, k, 100);
  /* পেছনের নালি */
  const V = { svc: [[122, 8], [122, 60], [122, 108]], ivc: [[90, 352], [90, 290], [90, 222]], ao: [[217, 170], [214, 120], [212, 84], [224, 54], [258, 42], [290, 56], [304, 92], [306, 134]],
    pt: [[188, 158], [187, 124], [186, 98]], rpa: [[184, 98], [140, 94], [94, 96], [46, 104]], lpa: [[190, 98], [240, 88], [298, 92], [342, 100]], pv1: [[352, 138], [334, 146], [312, 152]], pv2: [[352, 188], [334, 180], [312, 174]] };
  B.tube(g, sm(PP(V.rpa)), W(17), 'vein'); B.tube(g, sm(PP(V.pv1)), W(12), 'art', { cap: 'butt' }); B.tube(g, sm(PP(V.pv2)), W(12), 'art', { cap: 'butt' });
  B.tube(g, sm(PP(V.ivc)), W(24), 'vein', { cap: 'butt' }); B.tube(g, sm(PP(V.svc)), W(24), 'vein', { cap: 'butt' });
  [[[224, 54], [214, 14]], [[246, 44], [246, 10]], [[270, 46], [282, 16]]].forEach(q => B.tube(g, sm(PP(q)), W(10), 'art', { cap: 'butt' }));
  B.tube(g, sm(PP(V.ao)), W(26), 'art', { cap: 'butt' });
  /* হৃৎপেশি */
  E('path', { d: sm(PP(mv(HP.outer, sys * .05, asys * .03, near, [190, 150])), true, .5), fill: o.mono ? FK.alpha(mu.c, .18) : B.vol(g, 'mus', { cx: .32, cy: .3, r: .95 }), stroke: mu.dk, 'stroke-width': 1.1 }, g);
  /* করোনারি খাঁজের চর্বি */
  if (!o.mono) E('path', { d: sm(PP([[84, 214], [120, 220], [160, 214]])), stroke: FK.alpha(B.TS('fat').c, .85), 'stroke-width': W(4), fill: 'none', 'stroke-linecap': 'round' }, g);
  /* গহ্বর */
  const rc = mv(HP.right, sys * .2, asys * .1, HP.cRV, HP.cRA), lc = mv(HP.left, sys * .2, asys * .1, HP.cLV, HP.cLA);
  E('path', { d: sm(PP(rc), true, .35), fill: bl('vein'), stroke: FK.alpha(mu.dk, .9), 'stroke-width': .9 }, g);
  E('path', { d: sm(PP(lc), true, .35), fill: bl('art'), stroke: FK.alpha(mu.dk, .9), 'stroke-width': .9 }, g);
  /* প্যাপিলারি পেশি */
  const sh = p => mv([[p[0], p[1], 'v']], sys * .2, 0, near, null)[0];
  const pap = (b0, b1, tip) => { const [t0, t1] = [sh(tip), sh(b0)], q = sh(b1); E('path', { d: `M${PP([t1])[0].map(v => v.toFixed(1)).join(' ')}Q${P([(t1[0] + t0[0]) / 2 - 4, (t1[1] + t0[1]) / 2])[0].toFixed(1)} ${P([0, (t1[1] + t0[1]) / 2])[1].toFixed(1)} ${P(t0)[0].toFixed(1)} ${P(t0)[1].toFixed(1)}Q${P([(q[0] + t0[0]) / 2 + 4, 0])[0].toFixed(1)} ${P([0, (q[1] + t0[1]) / 2])[1].toFixed(1)} ${P(q)[0].toFixed(1)} ${P(q)[1].toFixed(1)}Z`, fill: o.mono ? FK.alpha(mu.c, .4) : B.lin(g, 'mus', 0), stroke: mu.dk, 'stroke-width': .7 }, g); return t0; };
  const pRV1 = pap([108, 266], [134, 280], [126, 248]), pRV2 = pap([144, 292], [172, 298], [156, 266]), pLV1 = pap([230, 314], [260, 316], [250, 272]), pLV2 = pap([284, 278], [300, 248], [278, 244]);
  /* AV কপাটিকা */
  const av = o.av != null ? o.av : .5, sl = o.sl != null ? o.sl : 0, vcol = '#f4ead7', vst = '#a8916a';
  const leaf = (hx, hy, a0, a1, len) => { const a = (a0 + (a1 - a0) * av) * PI / 180, p0 = P([hx, hy]), p1 = [p0[0] + Math.cos(a) * len * s, p0[1] + Math.sin(a) * len * s], d = `M${p0[0].toFixed(1)} ${p0[1].toFixed(1)}Q${((p0[0] + p1[0]) / 2 + Math.sin(a) * 3).toFixed(1)} ${((p0[1] + p1[1]) / 2 - Math.cos(a) * 3).toFixed(1)} ${p1[0].toFixed(1)} ${p1[1].toFixed(1)}`;
    E('path', { d, stroke: vst, 'stroke-width': W(3.4), fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d, stroke: vcol, 'stroke-width': W(2), fill: 'none', 'stroke-linecap': 'round' }, g); return p1; };
  const chord = (p1, tip) => { const q = P(tip); E('path', { d: `M${p1[0].toFixed(1)} ${p1[1].toFixed(1)}L${q[0].toFixed(1)} ${q[1].toFixed(1)}M${p1[0].toFixed(1)} ${p1[1].toFixed(1)}L${(q[0] + 4 * s).toFixed(1)} ${(q[1] + 1).toFixed(1)}M${p1[0].toFixed(1)} ${p1[1].toFixed(1)}L${(q[0] - 4 * s).toFixed(1)} ${(q[1] + 1).toFixed(1)}`, stroke: '#efe3cc', 'stroke-width': .6, opacity: .95 }, g); };
  const ta = leaf(102, 210, 14, 72, 26), tb = leaf(156, 205, 166, 104, 26); chord(ta, pRV1); chord(tb, pRV2);
  const ma = leaf(242, 198, 12, 80, 25), mb = leaf(290, 198, 168, 102, 25); chord(ma, pLV1); chord(mb, pLV2);
  /* সামনের নালি: ফুসফুসীয় কাণ্ড ও বাম ফুসফুসীয় ধমনি */
  B.tube(g, sm(PP(V.lpa)), W(17), 'vein'); B.tube(g, sm(PP(V.pt)), W(20), 'vein', { cap: 'butt' });
  /* অর্ধচন্দ্র কপাটিকা: বন্ধ হলে পকেট নিচের দিকে মিলিত, খোলা হলে দেয়ালে সাঁটা */
  const semi = (x0, y0, x1, y1) => { const m = [(x0 + x1) / 2, (y0 + y1) / 2]; [[x0, y0, 1], [x1, y1, -1]].forEach(([x, y, sd]) => { const p0 = P([x, y]), tip = sl > .5 ? P([x + sd * 1.5, y - 12]) : P([m[0] + sd * 1.2, m[1] + 4]), c = sl > .5 ? P([x + sd * 3, y - 6]) : P([(x + m[0]) / 2, m[1] + 7]);
    const d = `M${p0[0].toFixed(1)} ${p0[1].toFixed(1)}Q${c[0].toFixed(1)} ${c[1].toFixed(1)} ${tip[0].toFixed(1)} ${tip[1].toFixed(1)}`; E('path', { d, stroke: vst, 'stroke-width': W(3), fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d, stroke: vcol, 'stroke-width': W(1.8), fill: 'none', 'stroke-linecap': 'round' }, g); }); };
  semi(180, 157, 196, 155); semi(206, 169, 228, 167);
  const paths = {
    svc: B.dense(PP([[122, 12], [122, 104], [126, 160], [130, 206], [140, 252], [172, 268], [186, 226], [188, 180], [188, 150], [187, 104], [150, 96], [60, 102]]), 6),
    ivc: B.dense(PP([[90, 348], [90, 230], [114, 182], [128, 210], [150, 262], [182, 244], [188, 170], [188, 110], [230, 90], [338, 99]]), 6),
    pv: B.dense(PP([[348, 140], [310, 152], [268, 160], [262, 204], [262, 268], [240, 292], [222, 244], [216, 196], [217, 168], [214, 104], [226, 56], [262, 44], [294, 62], [306, 112]]), 6),
    pv2: B.dense(PP([[348, 186], [310, 174], [274, 172], [272, 214], [272, 266], [248, 298], [226, 250], [220, 200], [218, 160], [216, 92], [240, 50], [280, 50], [304, 90]]), 6)
  };
  return { P, paths, V };
};
})();
