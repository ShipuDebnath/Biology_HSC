/* ═══════════════════════════════════════════════════════════════════
   visuals3 — ভ্রূণের বিকাশ: germFate, fetalMembranes, placenta, fetalGrowth, fundalHeight, labour
   B.fetus — কুণ্ডলী পাকানো ভ্রূণ (স্থানীয় একক; মাথা ওপরে, মুখ বাঁয়ে)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B29, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const preset = (ctx, k, v, dig = 0, unit = '') => { ctx.v[k] = v; const el = ctx.root && ctx.root.querySelector ? ctx.root.querySelector(`[data-sl="${k}"]`) : null; if (el) { el.value = v; const o2 = ctx.root.querySelector(`[data-slo="${k}"]`); if (o2) o2.textContent = FK.n(v, dig) + unit; } };
const lerp = (a, b, t) => a + (b - a) * t;

/* ─── ভ্রূণ: hp = মাথার অনুপাত (প্রথম দিকে বড়), o.cord = নাভিরজ্জুর শেষ বিন্দু (বিশ্ব-স্থানাঙ্ক নয়, স্থানীয়) ─── */
B.fetus = (g, x, y, s, rot = 0, o = {}) => { const tr = `translate(${f1(x)} ${f1(y)}) rotate(${f1(rot)}) scale(${f1(s / 10)})`, svg = g.ownerSVGElement || g, fk = (o.hp || 1) + '|' + JSON.stringify(o.cord), FM = svg._fet || (svg._fet = {});
  if (FM[fk]) { const c = FM[fk].cloneNode(true); c.setAttribute('transform', tr); g.appendChild(c); return c; }
  const G = B._fetus(g, o); FM[fk] = G.cloneNode(true); G.setAttribute('transform', tr); return G; };
B._fetus = (g, o) => { const hp = o.hp || 1, G = E('g', {}, g);
  const P = pts => sm(pts.map(([a, b]) => [a * 10, b * 10]), true, .5), L = pts => sm(pts.map(([a, b]) => [a * 10, b * 10]), false, .5);
  /* পিঠ-নিতম্ব */ B.organ(G, P([[.1, -.75], [.9, -.55], [1.45, .05], [1.62, .9], [1.4, 1.7], [.8, 2.15], [.05, 2.1], [-.45, 1.6], [-.6, .8], [-.48, .05], [-.25, -.5]]), 'fet', { sw: .9, gr: { cx: .65, cy: .3, r: .9 } });
  /* মেরুদণ্ডের আভাস */ E('path', { d: L([[.55, -.5], [1.15, .1], [1.3, .9], [1.1, 1.6], [.7, 1.95]]), stroke: FK.alpha('#b07860', .35), 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '1.6 1.6' }, G);
  /* পা: উরু → হাঁটু → পায়ের পাতা (ভাঁজ করা) */ B.tube(G, L([[.7, 1.75], [-.2, 1.55], [-.85, 1.05]]), 5.6, 'fet', { sw: .8 }); B.tube(G, L([[-.85, 1.05], [-.55, .55], [-.1, .2]]), 4.2, 'fet', { sw: .8 }); E('path', { d: B.ellD(-.1, .1, 3.2, 1.8, -30), fill: B.TS('fet').c, stroke: B.TS('fet').dk, 'stroke-width': .7 }, G);
  /* হাত: কাঁধ → কনুই → মুঠি মুখের কাছে */ B.tube(G, L([[.25, -.3], [-.35, .35], [-.75, -.2]]), 3.6, 'fet', { sw: .8 }); E('circle', { cx: -8, cy: -3.4, r: 2.2, fill: B.TS('fet').c, stroke: B.TS('fet').dk, 'stroke-width': .7 }, G);
  /* মাথা */ const hr = 9.6 * hp, hx = -1.8 - (hp - 1) * 4, hy = -15 - (hp - 1) * 7; B.organ(G, B.ellD(hx, hy, hr, hr * .94, -20), 'fet', { sw: .9, gr: { cx: .6, cy: .3, r: .8 } });
  E('path', { d: `M${f1(hx - hr * .72)} ${f1(hy + hr * .1)}q-1.4 1.6 -.6 3.2`, stroke: B.TS('fet').dk, 'stroke-width': .7, fill: 'none' }, G); E('circle', { cx: f1(hx - hr * .42), cy: f1(hy - hr * .05), r: f1(hr * .1), fill: '#5a3a30', opacity: .65 }, G); E('path', { d: `M${f1(hx + hr * .1)} ${f1(hy - hr * .05)}a${f1(hr * .18)} ${f1(hr * .24)} 0 1 1 0 ${f1(hr * .4)}`, stroke: B.TS('fet').dk, 'stroke-width': .7, fill: 'none' }, G);
  if (o.cord !== false) { const c = o.cord || [-14, 18], cd = `M-4 9C-10 12 ${f1(c[0] - 4)} ${f1(c[1] - 10)} ${f1(c[0])} ${f1(c[1])}`; B.tube(G, cd, 2.8, 'cart', { sw: .45, hl: false }); E('path', { d: cd, stroke: '#4060ab', 'stroke-width': .9, fill: 'none', 'stroke-dasharray': '1.6 1.6' }, G); E('path', { d: cd, stroke: '#c9352b', 'stroke-width': .9, fill: 'none', 'stroke-dasharray': '1.6 1.6', 'stroke-dashoffset': 1.6 }, G); }
  return G; };

/* ═════════ ভ্রূণস্তরের পরিণতি ═════════ */
const GL = {
  ecto: ['এক্টোডার্ম', 'এক্টোডার্ম (বহিঃস্তর) থেকে', 'ত্বকের এপিডার্মিস, চুল, নখ, ঘর্ম, তৈল ও স্তনগ্রন্থি; সম্পূর্ণ স্নায়ুতন্ত্র (মস্তিষ্ক, সুষুম্নাকাণ্ড, স্নায়ু), চোখের রেটিনা, লেন্স ও কর্নিয়ার আবরণী, অন্তঃকর্ণ; দাঁতের এনামেল; পিটুইটারির অগ্রখণ্ড, অ্যাড্রিনাল মেডালা; মুখ, নাক ও পায়ুর প্রান্তের আবরণী।'],
  meso: ['মেসোডার্ম', 'মেসোডার্ম (মধ্যস্তর) থেকে', 'সব ধরনের পেশি (ঐচ্ছিক, অনৈচ্ছিক, হৃৎপেশি), অস্থি ও তরুণাস্থি, ত্বকের ডার্মিস, যোজক কলা; হৃৎপিণ্ড, রক্ত, রক্তনালি ও লসিকাতন্ত্র; বৃক্ক ও মূত্রনালি, জননাঙ্গ (শুক্রাশয়, ডিম্বাশয়) ও তাদের নালি; অ্যাড্রিনাল কর্টেক্স, প্লীহা; দেহগহ্বরের আবরণ (পেরিটোনিয়াম, প্লুরা)।'],
  endo: ['এন্ডোডার্ম', 'এন্ডোডার্ম (অন্তঃস্তর) থেকে', 'পৌষ্টিকনালির ভেতরের আবরণী (গলবিল থেকে মলাশয়), যকৃৎ ও অগ্ন্যাশয়; শ্বাসনালি ও ফুসফুসের আবরণী; থাইরয়েড, প্যারাথাইরয়েড ও থাইমাস; মূত্রথলি ও মূত্রপথের আবরণী; মধ্যকর্ণ ও ইউস্টেশিয়ান নালির আবরণী; টনসিল।'],
  all: ['তিনটিই', 'তিন ভ্রূণস্তর (ট্রাইপ্লোব্লাস্টিক)', 'গ্যাস্ট্রুলেশনে (তৃতীয় সপ্তাহ) এপিব্লাস্ট কোষ আদি রেখা (primitive streak) দিয়ে ভেতরে ঢুকে তিনটি স্তর তৈরি করে। এরপর ভাঁজ হয়ে নল আকৃতির দেহ গড়ে — বাইরে এক্টোডার্ম, ভেতরে এন্ডোডার্মের নালি, মাঝখানে মেসোডার্ম। প্রতিটি অঙ্গ সাধারণত একাধিক স্তরের মিলিত অবদান (যেমন অন্ত্রের আবরণী এন্ডোডার্ম, পেশি মেসোডার্ম)।']
};
const GD = { ecto: ['ত্বক ও এর গ্রন্থি', 'চুল ও নখ', 'মস্তিষ্ক ও সুষুম্নাকাণ্ড', 'রেটিনা ও লেন্স', 'দাঁতের এনামেল', 'অ্যাড্রিনাল মেডালা'], meso: ['পেশি', 'অস্থি ও তরুণাস্থি', 'হৃৎপিণ্ড ও রক্ত', 'বৃক্ক', 'জননাঙ্গ', 'ডার্মিস'], endo: ['পৌষ্টিকনালির আবরণী', 'যকৃৎ ও অগ্ন্যাশয়', 'ফুসফুসের আবরণী', 'থাইরয়েড ও থাইমাস', 'মূত্রথলির আবরণী', 'মধ্যকর্ণের আবরণী'] };
const GC = { ecto: '#3a6aa8', meso: '#a84444', endo: '#a88a1a' };
V.germFate = Object.assign({}, B.seg({
  id: 'germ', t: 'ভ্রূণস্তর ও তাদের পরিণতি', H: 330, def: 'all', types: GL,
  cap: 'প্রায় 4 সপ্তাহের মানব ভ্রূণের প্রস্থচ্ছেদ (ভাঁজ হওয়ার পর) — নীল এক্টোডার্ম, লাল মেসোডার্ম, হলুদ এন্ডোডার্ম (প্রচলিত রং)। নিচে প্রতিটি স্তর থেকে তৈরি প্রধান অঙ্গ। বোতামে একটি স্তর বেছে নিলে ছেদে শুধু সেটি উজ্জ্বল থাকে।',
  art(g, C, ty) { const on = k => ty === 'all' || ty === k, op = k => on(k) ? 1 : .18, cx = 180, cy = 92;
    const S = E('g', {}, g);
    /* বাইরের এক্টোডার্ম (ত্বক) */ const body = sm([[cx, cy - 74], [cx + 40, cy - 66], [cx + 82, cy - 36], [cx + 100, cy + 10], [cx + 88, cy + 52], [cx + 50, cy + 74], [cx, cy + 80], [cx - 50, cy + 74], [cx - 88, cy + 52], [cx - 100, cy + 10], [cx - 82, cy - 36], [cx - 40, cy - 66]], true, .5);
    E('path', { d: body, fill: B.TS('meso').c, stroke: B.TS('ecto').c, 'stroke-width': 5, opacity: 1 }, S); E('path', { d: body, fill: 'none', stroke: B.TS('ecto').dk, 'stroke-width': .7, opacity: op('ecto') }, S);
    if (!on('ecto')) E('path', { d: body, fill: 'none', stroke: C.sf, 'stroke-width': 5, opacity: .8 }, S);
    /* দেহগহ্বর (সিলোম) */ const coel = (sx) => sm([[cx + sx * 34, cy + 4], [cx + sx * 66, cy - 6], [cx + sx * 82, cy + 16], [cx + sx * 72, cy + 50], [cx + sx * 40, cy + 62], [cx + sx * 22, cy + 46], [cx + sx * 26, cy + 20]], true, .5); [1, -1].forEach(sx => E('path', { d: coel(sx), fill: C.sf, stroke: B.TS('meso').dk, 'stroke-width': .7, opacity: 1 }, S));
    /* মেসোডার্মের আবছা */ if (!on('meso')) E('path', { d: body, fill: C.sf, opacity: .78 }, S);
    /* সোমাইট */ [1, -1].forEach(sx => { B.organ(S, B.ellD(cx + sx * 34, cy - 30, 15, 18, sx * 15), 'meso', { sw: .8, op: op('meso') }); E('path', { d: `M${cx + sx * 24} ${cy - 44}q${sx * 12} -4 ${sx * 22} 8`, stroke: B.TS('meso').dk, 'stroke-width': 2, fill: 'none', opacity: op('meso') }, S);
      /* মধ্যবর্তী মেসোডার্ম (বৃক্ক) */ B.organ(S, B.ellD(cx + sx * 52, cy - 4, 7, 6, 0), 'meso', { sw: .7, op: op('meso'), pat: 'dot' }); });
    /* নিউরাল টিউব ও নিউরাল ক্রেস্ট */ B.organ(S, B.ellD(cx, cy - 46, 13, 18, 0), 'ecto', { sw: .9, op: op('ecto') }); E('path', { d: B.ellD(cx, cy - 46, 3, 10, 0), fill: C.sf, opacity: op('ecto') }, S); [1, -1].forEach(sx => E('circle', { cx: cx + sx * 17, cy: cy - 58, r: 3.4, fill: B.TS('ecto').c, stroke: B.TS('ecto').dk, 'stroke-width': .5, opacity: op('ecto') }, S));
    /* নটোকর্ড */ E('circle', { cx, cy: cy - 18, r: 6, fill: B.TS('meso').c, stroke: B.TS('meso').dk, 'stroke-width': .8, opacity: op('meso') }, S);
    /* পৃষ্ঠীয় মহাধমনি */ [1, -1].forEach(sx => E('circle', { cx: cx + sx * 14, cy: cy - 4, r: 5, fill: B.TS('art').c, stroke: B.TS('art').dk, 'stroke-width': .6, opacity: op('meso') }, S));
    /* অন্ত্রনালি: এন্ডোডার্ম + স্প্ল্যাংকনিক মেসোডার্ম */ B.organ(S, B.ellD(cx, cy + 28, 20, 22, 0), 'meso', { sw: .7, op: op('meso') }); B.organ(S, B.ellD(cx, cy + 28, 12, 13, 0), 'endo3', { sw: 1, op: op('endo') }); E('path', { d: B.ellD(cx, cy + 28, 5.6, 6.4, 0), fill: C.sf }, S);
    /* লেবেল */ [[cx, cy - 46, 76, 22, 'নিউরাল টিউব', 'ecto'], [cx + 17, cy - 58, 284, 22, 'নিউরাল ক্রেস্ট', 'ecto'], [cx + 96, cy + 10, 284, cy + 30, 'ত্বক', 'ecto'], [cx - 46, cy - 32, 76, cy - 38, 'সোমাইট', 'meso'], [cx, cy - 18, 76, cy - 6, 'নটোকর্ড', 'meso'], [cx + 52, cy - 4, 284, cy - 16, 'বৃক্কের আদি', 'meso'], [cx - 66, cy + 30, 76, cy + 30, 'সিলোম', 'meso'], [cx + 12, cy + 30, 284, cy + 64, 'অন্ত্রনালি', 'endo']].forEach(([ax, ay, lx, ly, s, k]) => { if (on(k)) B.lead(g, C, ax, ay, lx, ly, s, { fs: 10.4, c: GC[k], a: lx < 180 ? 'end' : 'start' }); });
    /* নিচে তালিকা */ const cols = ty === 'all' ? ['ecto', 'meso', 'endo'] : [ty], cw = 344 / cols.length;
    cols.forEach((k, ci) => { const x0 = 8 + ci * cw; E('rect', { x: x0, y: 184, width: cw - 6, height: 140, rx: 8, fill: FK.alpha(GC[k], .09), stroke: FK.alpha(GC[k], .45), 'stroke-width': .8 }, g); B.tx(g, x0 + (cw - 6) / 2, 202, GL[k][0], { fs: 11.6, a: 'middle', w: 700, c: GC[k] });
      GD[k].forEach((n, i) => { const yy = 222 + i * (cols.length > 1 ? 17 : 17), xx = cols.length > 1 ? x0 + 8 : x0 + 16 + (i % 2) * 168, y2 = cols.length > 1 ? yy : 226 + Math.floor(i / 2) * 30; E('circle', { cx: xx + 3, cy: y2 - 3.6, r: 2.6, fill: GC[k] }, g); B.tx(g, xx + 10, y2, n, { fs: cols.length > 1 ? 9.8 : 12, c: C.fg }); }); }); },
  anim(g, C, ty, t) { const k = .5 + .5 * Math.sin(t * 2.4); if (ty === 'endo' || ty === 'all') E('circle', { cx: 180, cy: 120, r: f1(14 + k * 2), fill: 'none', stroke: '#a88a1a', 'stroke-width': .8, opacity: f1(.5 * k) }, g); }
}));

/* ═════════ ভ্রূণাবরণী (প্রায় 10–12 সপ্তাহ) ═════════ */
const FM_UT = sm([[180, 18], [236, 26], [270, 64], [278, 124], [262, 184], [226, 226], [204, 250], [196, 278], [164, 278], [156, 250], [134, 226], [98, 184], [82, 124], [90, 64], [124, 26]], true, .5);
V.fetalMembranes = Object.assign({ t: 'ভ্রূণাবরণী ও জরায়ুর ডেসিডুয়া', k: ['2d', 'anim', 'int', 'quiz'], cap: 'প্রায় 10–12 সপ্তাহের গর্ভবতী জরায়ুর লম্বচ্ছেদ (পাঠ্যবইয়ের রীতিতে সরলীকৃত)। ভ্রূণকে ঘিরে চারটি বহির্ভ্রূণীয় আবরণী: অ্যামনিয়ন, কোরিয়ন, কুসুমথলি ও অ্যালানটয়েস। কোরিয়নের যে অংশ ডেসিডুয়া বেসালিসের দিকে, তার ভিলাই ঘন হয়ে অমরা গড়ে; বাকি অংশ মসৃণ হয়ে যায়। চতুর্থ মাসের দিকে ডেসিডুয়া ক্যাপসুলারিস প্যারাইটালিসের সাথে মিশে জরায়ুগহ্বর লোপ পায়।' },
  BK.diagram({ W: 360, H: 300, label: 'ভ্রূণাবরণী', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      B.organ(P('myo'), FM_UT, 'ut', { sw: 1.1, gr: { cx: .4, cy: .3, r: .9 }, pat: 'line', pa: .14 });
      B.organ(P('decP'), sm([[180, 34], [226, 40], [256, 72], [262, 124], [248, 178], [216, 216], [196, 240], [164, 240], [144, 216], [112, 178], [98, 124], [104, 72], [134, 40]], true, .5), 'endm', { sw: .7 });
      E('path', { d: sm([[180, 44], [220, 50], [246, 78], [252, 124], [240, 172], [210, 208], [192, 230], [168, 230], [150, 208], [120, 172], [108, 124], [114, 78], [140, 50]], true, .5), fill: '#fff4f2', stroke: B.TS('endm').dk, 'stroke-width': .6 }, P('utc'));
      /* গর্ভথলি: ডেসিডুয়া বেসালিস ওপরের পেছনে (ডানে-ওপরে) */ const sx = 186, sy = 112;
      B.organ(P('decB'), sm([[200, 40], [238, 52], [258, 86], [262, 124], [252, 150], [226, 112], [196, 70]], true, .5), 'endm', { sw: .7, pat: 'dot', pa: .3 });
      B.organ(P('decC'), B.ellD(sx, sy, 64, 66, 0), 'endm', { sw: .7, op: .95 });
      /* কোরিয়ন: ফ্রন্ডোসাম (ভিলাইয়ের ঝাড়) ও লিভ */ E('path', { d: B.ellD(sx, sy, 58, 60, 0), fill: '#f6e6e8', stroke: '#9a3a46', 'stroke-width': 1.2 }, P('chor'));
      let vd = ''; for (let i = 0; i < 22; i++) { const a = -1.9 + i * .1, x0 = sx + Math.cos(a) * 58, y0 = sy + Math.sin(a) * 60, x1 = sx + Math.cos(a) * 74, y1 = sy + Math.sin(a) * 76; vd += `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}M${f1(lerp(x0, x1, .55))} ${f1(lerp(y0, y1, .55))}l${f1(Math.cos(a + .5) * 6)} ${f1(Math.sin(a + .5) * 6)}M${f1(lerp(x0, x1, .4))} ${f1(lerp(y0, y1, .4))}l${f1(Math.cos(a - .5) * 6)} ${f1(Math.sin(a - .5) * 6)}`; }
      E('path', { d: vd, stroke: B.TS('plac').c, 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, P('plac'));
      E('path', { d: B.ellD(sx, sy, 58, 60, 0), fill: 'none', stroke: B.TS('plac').c, 'stroke-width': 4, 'stroke-dasharray': '0 0', 'clip-path': B.clip(g, 'fmclip', 'M186 30L300 30L300 140L186 112Z') }, P('plac'));
      /* বহির্ভ্রূণীয় গহ্বর */ E('path', { d: B.ellD(sx, sy, 55, 57, 0), fill: '#fbf3ea', stroke: 'none' }, P('exc'));
      /* অ্যামনিয়ন */ B.organ(P('amn'), B.ellD(sx - 6, sy + 6, 44, 46, 0), 'amn', { sw: 1.1, st: '#5a8ab0' });
      /* কুসুমথলি */ B.organ(P('yolk'), B.ellD(sx + 38, sy + 44, 7, 7, 0), 'endo3', { sw: .7 }); E('path', { d: `M${sx + 18} ${sy - 18}Q${sx + 36} ${sy + 10} ${sx + 34} ${sy + 38}`, stroke: B.TS('endo3').dk, 'stroke-width': 1, fill: 'none' }, P('yolk'));
      /* নাভিরজ্জু: ভ্রূণ থেকে বেসালিসের দিকে, ভেতরে অ্যালানটয়েস */ const cd = `M${sx - 4} ${sy + 4}C${sx + 6} ${sy - 18} ${sx + 18} ${sy - 30} ${sx + 34} ${sy - 50}`; B.tube(P('cord'), cd, 7, 'amn', { sw: .6, hl: false }); E('path', { d: cd, stroke: '#c9352b', 'stroke-width': 1.2, fill: 'none', transform: 'translate(-1.5 0)' }, P('cord')); E('path', { d: cd, stroke: '#4060ab', 'stroke-width': 1.2, fill: 'none', transform: 'translate(1.5 0)' }, P('cord')); E('path', { d: cd, stroke: '#d8c070', 'stroke-width': .8, fill: 'none', 'stroke-dasharray': '2 2' }, P('cord'));
      B.fetus(P('fet'), sx - 16, sy + 10, 13, 10, { hp: 1.25, cord: false });
      /* সার্ভিক্স ও শ্লেষ্মা প্লাগ */ E('path', { d: 'M176 240L176 278M184 240L184 278', stroke: B.TS('ut').dk, 'stroke-width': .8 }, P('cx')); E('path', { d: 'M176.6 246h6.8v24h-6.8Z', fill: '#e8f0d8', stroke: '#9aa870', 'stroke-width': .5 }, P('cx'));
      hits(this.parts, part, 8); },
    idle(g, C, t) { const k = .5 + .5 * Math.sin(t * 6); E('circle', { cx: 162, cy: 96, r: f1(1.4 + k), fill: '#c9352b', opacity: f1(.5 + k * .5) }, g); },
    parts: [
      { id: 'amn', bn: 'অ্যামনিয়ন ও অ্যামনিওটিক তরল', lb: 'অ্যামনিয়ন', en: 'Amnion', fn: 'ভ্রূণকে সরাসরি ঘিরে থাকা পাতলা পর্দা; ভেতরের অ্যামনিওটিক তরল ধাক্কা থেকে রক্ষা, তাপমাত্রা স্থির, অবাধ নড়াচড়া ও ফুসফুসের বিকাশে সাহায্য করে; প্রসবকালে "পানি ভাঙা" এ থলিই।', a: [146, 150], l: [14, 196], an: 'start' },
      { id: 'chor', bn: 'কোরিয়ন (মসৃণ অংশ)', lb: 'কোরিয়ন', en: 'Chorion (laeve)', fn: 'সবচেয়ে বাইরের ভ্রূণাবরণী (ট্রফোব্লাস্ট + মেসোডার্ম); অমরার দিক ছাড়া বাকি অংশ মসৃণ হয়ে অ্যামনিয়নের সাথে মিশে যায়।', a: [130, 132], l: [14, 132], an: 'start' },
      { id: 'plac', bn: 'কোরিয়নিক ভিলাই (কোরিয়ন ফ্রন্ডোসাম → অমরা)', lb: 'কোরিয়নিক ভিলাই', en: 'Chorion frondosum', fn: 'ডেসিডুয়া বেসালিসের দিকের কোরিয়নে আঙুলের মতো ভিলাই ঘন হয় — এরাই মায়ের অংশের সাথে মিলে অমরা গড়ে।', a: [232, 70], l: [300, 30], an: 'middle' },
      { id: 'decB', bn: 'ডেসিডুয়া বেসালিস', lb: 'ডেসিডুয়া বেসালিস', en: 'Decidua basalis', fn: 'ভ্রূণ ও জরায়ুপ্রাচীরের মাঝের এন্ডোমেট্রিয়াম — অমরার মাতৃ-অংশ হয়।', a: [252, 110], l: [352, 96], an: 'end' },
      { id: 'decC', bn: 'ডেসিডুয়া ক্যাপসুলারিস', lb: 'ডেসিডুয়া ক্যাপসুলারিস', en: 'Decidua capsularis', fn: 'গর্ভথলির গহ্বরমুখী পাশ ঢেকে রাখা পাতলা এন্ডোমেট্রিয়াম।', a: [180, 176], l: [352, 212], an: 'end' },
      { id: 'decP', bn: 'ডেসিডুয়া প্যারাইটালিস', lb: 'ডেসিডুয়া প্যারাইটালিস', en: 'Decidua parietalis', fn: 'জরায়ুগহ্বরের বাকি সব প্রাচীরের এন্ডোমেট্রিয়াম।', a: [108, 120], l: [14, 96], an: 'start' },
      { id: 'utc', bn: 'জরায়ুগহ্বর', lb: 'জরায়ুগহ্বর', en: 'Uterine cavity', fn: 'ক্যাপসুলারিস ও প্যারাইটালিসের মাঝের ফাঁক — প্রায় চতুর্থ মাসে লোপ পায়।', a: [166, 214], l: [14, 232], an: 'start' },
      { id: 'yolk', bn: 'কুসুমথলি', lb: 'কুসুমথলি', en: 'Yolk sac', fn: 'মানুষে কুসুম নেই, তবু প্রথম রক্তকণিকা ও আদি জননকোষ এখানে তৈরি হয়; অন্ত্রের অংশ গড়ে; পরে ক্ষুদ্র হয়ে যায়।', a: [224, 156], l: [352, 176], an: 'end' },
      { id: 'cord', bn: 'নাভিরজ্জু (অ্যালানটয়েসসহ)', lb: 'নাভিরজ্জু', en: 'Umbilical cord', fn: '2টি নাভি-ধমনি (ভ্রূণ → অমরা, অক্সিজেনহীন রক্ত) ও 1টি নাভি-শিরা (অমরা → ভ্রূণ, অক্সিজেনযুক্ত রক্ত), ওয়ারটনের জেলিতে ঘেরা; ভেতরে অ্যালানটয়েসের অবশেষ। পূর্ণ গর্ভে প্রায় 50–60 সেমি লম্বা।', a: [206, 78], l: [300, 14], an: 'middle' },
      { id: 'fet', bn: 'ভ্রূণ (ফিটাস)', lb: 'ভ্রূণ', en: 'Fetus', fn: '8 সপ্তাহের পর থেকে "ফিটাস" বলা হয় — সব প্রধান অঙ্গের আদি তৈরি হয়ে গেছে।', a: [164, 112], l: [60, 64], an: 'middle' },
      { id: 'exc', bn: 'বহির্ভ্রূণীয় সিলোম', lb: 'বহির্ভ্রূণীয় সিলোম', en: 'Chorionic cavity', fn: 'অ্যামনিয়ন ও কোরিয়নের মাঝের ফাঁক — অ্যামনিয়ন বড় হতে থাকলে লোপ পায়।', a: [232, 132], l: [352, 150], an: 'end' },
      { id: 'myo', bn: 'মায়োমেট্রিয়াম', lb: 'মায়োমেট্রিয়াম', en: 'Myometrium', fn: 'জরায়ুর পুরু অনৈচ্ছিক পেশিস্তর — প্রসবে সংকোচন ঘটায়।', a: [92, 178], l: [14, 164], an: 'start' },
      { id: 'cx', bn: 'সার্ভিক্স ও শ্লেষ্মা প্লাগ', lb: 'সার্ভিক্স', en: 'Cervix & mucus plug', fn: 'গর্ভকালে ঘন শ্লেষ্মার প্লাগ জীবাণু ঢুকতে বাধা দেয়; প্রসবে নরম ও প্রসারিত হয়।', a: [180, 262], l: [230, 290], an: 'start' }
    ]
  }));

/* ═════════ অমরার গঠন ═════════ */
const villus = (x, y, h, sd) => { const r = i => B.rnd(sd * 13 + i); let d = `M${x} ${y}C${f1(x + (r(1) - .5) * 10)} ${f1(y + h * .3)} ${f1(x + (r(2) - .5) * 14)} ${f1(y + h * .6)} ${f1(x + (r(3) - .5) * 8)} ${f1(y + h)}`; const br = []; for (let i = 0; i < 4; i++) { const t = .3 + i * .17, bx = x + (r(4 + i) - .5) * 8, by = y + h * t, sx = i % 2 ? 1 : -1, L = 10 + r(9 + i) * 8; d += `M${f1(bx)} ${f1(by)}q${f1(sx * L * .5)} ${f1(L * .2)} ${f1(sx * L)} ${f1(L * .7)}`; br.push([bx + sx * L, by + L * .7]); } return [d, br]; };
V.placenta = Object.assign({ t: 'অমরার গঠন ও আদান-প্রদান', k: ['2d', 'anim', 'int', 'quiz'], cap: 'পূর্ণ অমরা থালার মতো, প্রায় 22 সেমি ব্যাস, 2–2.5 সেমি পুরু ও প্রায় 500 গ্রাম। মানব অমরা হিমোকোরিয়াল — মায়ের রক্ত সর্পিল ধমনি দিয়ে আন্তঃভিলাস ফাঁকে ছড়িয়ে ভিলাইকে স্নান করায়; ভ্রূণের রক্ত ভিলাইয়ের কৈশিকনালিতে থাকে। দুই রক্ত কখনো মেশে না — মাঝে কয়েক স্তরের পাতলা "অমরা প্রাচীর"। প্রচলিত রীতিতে অক্সিজেনহীন রক্ত নীল, অক্সিজেনযুক্ত লাল।' },
  BK.diagram({ W: 360, H: 308, label: 'অমরা', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      /* মাতৃ-অংশ */ B.organ(P('myo'), 'M8 246H352V292H8Z', 'ut', { sw: .8, lin: 90, pat: 'line', pa: .16 }); B.organ(P('dec'), 'M8 222H352V248H8Z', 'endm', { sw: .7, pat: 'dot', pa: .26 });
      /* আন্তঃভিলাস ফাঁক — মায়ের রক্ত */ E('path', { d: 'M8 92H352V224H8Z', fill: '#f6c8c4', stroke: 'none' }, P('ivs')); let rb = ''; for (let i = 0; i < 90; i++) rb += B.ellD(14 + B.rnd(i) * 332, 98 + B.rnd(i + 300) * 120, 2.2, 1.4, B.rnd(i + 99) * 180); E('path', { d: rb, fill: '#d8605a', opacity: .55 }, P('ivs'));
      /* সেপ্টাম */ [96, 236].forEach(x => B.organ(P('sep'), `M${x - 8} 224Q${x - 3} 170 ${x} 150Q${x + 3} 170 ${x + 8} 224Z`, 'endm', { sw: .6 }));
      /* কোরিওনিক প্লেট ও অ্যামনিয়ন */ B.organ(P('cp'), 'M8 70H352V94H8Z', 'plac', { sw: .8, lin: 90 }); E('path', { d: 'M8 66H352V71H8Z', fill: B.TS('amn').c, stroke: B.TS('amn').dk, 'stroke-width': .6 }, P('amnn'));
      /* ভিলাস গাছ */ [[46, 1], [156, 2], [184, 3], [290, 4], [318, 5]].forEach(([x, sd]) => { const [d, br] = villus(x, 94, x === 156 || x === 290 ? 128 : 96, sd); const tr = x === 156 ? P('anch') : P('vil'); E('path', { d, stroke: B.TS('plac').dk, 'stroke-width': 7.5, fill: 'none', 'stroke-linecap': 'round' }, tr); E('path', { d, stroke: B.TS('plac').lt, 'stroke-width': 5.4, fill: 'none', 'stroke-linecap': 'round' }, tr); E('path', { d, stroke: '#4060ab', 'stroke-width': 1, fill: 'none', transform: 'translate(-1.2 0)' }, tr); E('path', { d, stroke: '#c9352b', 'stroke-width': 1, fill: 'none', transform: 'translate(1.2 0)' }, tr); br.forEach(([bx, by]) => E('circle', { cx: f1(bx), cy: f1(by), r: 3.4, fill: B.TS('plac').lt, stroke: B.TS('plac').dk, 'stroke-width': .7 }, tr)); });
      /* সর্পিল ধমনি ও মাতৃ-শিরা */ E('path', { d: 'M126 292C120 278 134 268 126 256S134 236 128 222', stroke: B.TS('art').c, 'stroke-width': 4.2, fill: 'none' }, P('spa')); E('path', { d: 'M126 292C120 278 134 268 126 256S134 236 128 222', stroke: B.TS('art').lt, 'stroke-width': 1.6, fill: 'none' }, P('spa'));
      E('path', { d: 'M266 222L266 292', stroke: B.TS('vein').c, 'stroke-width': 5, fill: 'none' }, P('mv')); E('path', { d: 'M206 292C200 278 214 268 206 256S214 236 208 222', stroke: B.TS('art').c, 'stroke-width': 4.2, fill: 'none' }, P('spa'));
      /* নাভিরজ্জু */ B.organ(P('cord'), 'M162 0H198V68H162Z', 'amn', { sw: .8, lin: 0 }); E('path', { d: 'M170 0C168 30 166 50 150 70', stroke: '#4060ab', 'stroke-width': 3.4, fill: 'none' }, P('ua')); E('path', { d: 'M190 0C192 30 196 50 212 70', stroke: '#4060ab', 'stroke-width': 3.4, fill: 'none' }, P('ua')); E('path', { d: 'M180 0C180 30 180 52 180 72', stroke: '#c9352b', 'stroke-width': 5, fill: 'none' }, P('uv'));
      hits(this.parts, part, 8); },
    idle(g, C, t) { /* মায়ের রক্ত সর্পিল ধমনি থেকে ঝরনার মতো ছড়ায় */ for (let j = 0; j < 2; j++) { const x0 = [128, 208][j]; for (let i = 0; i < 4; i++) { const u = (t * .35 + i / 4) % 1; E('circle', { cx: f1(x0 + Math.sin(i * 2 + j) * u * 34), cy: f1(222 - u * 90), r: 2.4, fill: '#c0392b', opacity: f1(1 - u) }, g); } }
      for (let i = 0; i < 3; i++) { const u = (t * .5 + i / 3) % 1; E('circle', { cx: 180, cy: f1(72 - u * 66), r: 2, fill: '#fff', opacity: .9 }, g); E('circle', { cx: f1(170 - (1 - u) * 4), cy: f1(u * 66), r: 1.6, fill: '#e0e8ff', opacity: .9 }, g); }
 },
    parts: [
      { id: 'cord', bn: 'নাভিরজ্জু', lb: 'নাভিরজ্জু', en: 'Umbilical cord', fn: 'ভ্রূণ ও অমরার সংযোগ — ওয়ারটনের জেলিতে 2টি ধমনি ও 1টি শিরা।', a: [198, 30], l: [240, 22], an: 'start' },
      { id: 'uv', bn: 'নাভি-শিরা (অক্সিজেনযুক্ত রক্ত)', lb: 'নাভি-শিরা', en: 'Umbilical vein', fn: 'অমরা থেকে অক্সিজেন, গ্লুকোজ, অ্যামিনো অ্যাসিড, অ্যান্টিবডি (IgG) নিয়ে ভ্রূণে যায় — শিরা হয়েও অক্সিজেনযুক্ত রক্ত বহন করে।', a: [180, 50], l: [240, 44], an: 'start' },
      { id: 'ua', bn: 'নাভি-ধমনি (2টি, অক্সিজেনহীন রক্ত)', lb: 'নাভি-ধমনি', en: 'Umbilical arteries', fn: 'ভ্রূণ থেকে CO<sub>2</sub>, ইউরিয়া ও অন্য বর্জ্য অমরায় আনে — ধমনি হয়েও অক্সিজেনহীন রক্ত।', a: [167, 40], l: [110, 30], an: 'end' },
      { id: 'amnn', bn: 'অ্যামনিয়ন', lb: 'অ্যামনিয়ন', en: 'Amnion', fn: 'অমরার ভ্রূণমুখী তল ঢেকে রাখা পর্দা।', a: [60, 68], l: [60, 52], an: 'middle' },
      { id: 'cp', bn: 'কোরিওনিক প্লেট', lb: 'কোরিওনিক প্লেট', en: 'Chorionic plate', fn: 'ভ্রূণের দিকের ভিত্তি — নাভিরজ্জুর নালিগুলো এখানে শাখা হয়ে ভিলাইয়ে যায়।', a: [70, 84], l: [52, 114], an: 'middle' },
      { id: 'vil', bn: 'কোরিওনিক ভিলাস (ভাসমান)', lb: 'কোরিওনিক ভিলাস', en: 'Floating villus', fn: 'ভ্রূণের কৈশিকনালিসহ শাখাপ্রশাখা — মোট তলের আয়তন প্রায় 10–14 বর্গমিটার; ব্যাপন, সক্রিয় পরিবহন ও পিনোসাইটোসিসে আদান-প্রদান।', a: [300, 160], l: [352, 128], an: 'end' },
      { id: 'anch', bn: 'নোঙর ভিলাস', lb: 'নোঙর ভিলাস', en: 'Anchoring villus', fn: 'ডেসিডুয়া পর্যন্ত পৌঁছে অমরাকে জরায়ুপ্রাচীরে আটকে রাখে।', a: [158, 200], l: [60, 196], an: 'middle' },
      { id: 'ivs', bn: 'আন্তঃভিলাস ফাঁক (মায়ের রক্ত)', lb: 'আন্তঃভিলাস ফাঁক', en: 'Intervillous space', fn: 'মায়ের রক্তে ভরা — পূর্ণ গর্ভে প্রায় 500–600 মিলি/মিনিট রক্ত প্রবাহিত হয়।', a: [250, 120], l: [300, 108], an: 'middle' },
      { id: 'sep', bn: 'অমরা সেপ্টাম', lb: 'সেপ্টাম', en: 'Placental septum', fn: 'ডেসিডুয়া থেকে ওঠা প্রাচীর — অমরাকে 15–20টি কটিলিডনে ভাগ করে।', a: [96, 170], l: [40, 150], an: 'middle' },
      { id: 'spa', bn: 'সর্পিল ধমনি (মাতৃ)', lb: 'সর্পিল ধমনি', en: 'Spiral artery', fn: 'ট্রফোব্লাস্ট কোষ এর দেয়াল বদলে চওড়া করে দেয়, তাই নিম্নচাপে প্রচুর রক্ত ঢোকে। এটি ব্যর্থ হলে প্রি-এক্লাম্পসিয়ার ঝুঁকি বাড়ে।', a: [128, 262], l: [60, 274], an: 'middle' },
      { id: 'mv', bn: 'মাতৃ-শিরা', lb: 'মাতৃ-শিরা', en: 'Maternal vein', fn: 'আন্তঃভিলাস ফাঁক থেকে রক্ত (ভ্রূণের বর্জ্যসহ) মায়ের দেহে ফেরত নেয়।', a: [266, 262], l: [320, 274], an: 'middle' },
      { id: 'dec', bn: 'ডেসিডুয়া বেসালিস', lb: 'ডেসিডুয়া বেসালিস', en: 'Decidua basalis', fn: 'অমরার মাতৃ-অংশ; প্রসবের পর অমরার সাথে এর ওপরের স্তর খসে আসে।', a: [330, 235], l: [352, 214], an: 'end' },
      { id: 'myo', bn: 'মায়োমেট্রিয়াম', lb: 'মায়োমেট্রিয়াম', en: 'Myometrium', fn: 'জরায়ুর পেশিস্তর — অমরা আলাদা হওয়ার পর সংকুচিত হয়ে রক্তনালি চেপে রক্তপাত থামায়।', a: [40, 284], l: [14, 297], an: 'start' }
    ]
  }));

/* ═════════ গর্ভকালীন বৃদ্ধি (সপ্তাহ অনুযায়ী) ═════════ */
const FG = [[8, 1.6, 1], [12, 5.4, 58], [16, 18.6, 146], [20, 25.7, 331], [24, 32.2, 670], [28, 37.9, 1210], [32, 43, 1953], [36, 47.3, 2813], [40, 51, 3619]];
const fgAt = w => { if (w <= 8) return [1.6 * w / 8, Math.max(.1, w / 8)]; for (let i = 0; i < FG.length - 1; i++) if (w <= FG[i + 1][0]) { const t = (w - FG[i][0]) / 4; return [lerp(FG[i][1], FG[i + 1][1], t), Math.exp(lerp(Math.log(FG[i][2]), Math.log(FG[i + 1][2]), t))]; } return [51, 3619]; };
const MS = [[4, 'হৃৎপিণ্ড স্পন্দন শুরু (প্রায় 22 দিন), নিউরাল টিউব বন্ধ'], [8, 'সব প্রধান অঙ্গের আদি তৈরি — এরপর থেকে "ফিটাস"'], [12, 'আঙুল আলাদা, নখ গজাচ্ছে; বাইরের জননাঙ্গ আলাদা হতে শুরু'], [16, 'হাড় শক্ত হচ্ছে, চোখ-কান যথাস্থানে'], [20, 'মা প্রথম নড়াচড়া টের পান (কুইকেনিং, 18–20 সপ্তাহ); দেহে লানুগো লোম'], [24, 'ফুসফুসে সারফ্যাক্ট্যান্ট তৈরি শুরু — নিবিড় পরিচর্যায় বাঁচার সীমা (প্রায় 24 সপ্তাহ)'], [28, 'চোখের পাতা খোলে; ঘুম-জাগরণের ছন্দ'], [32, 'চর্বি জমে ত্বক মসৃণ; সাধারণত মাথা নিচের দিকে ঘুরে যায়'], [36, 'ফুসফুস প্রায় পরিপক্ব; মাথা পেলভিসে নামতে শুরু'], [40, 'পূর্ণ গর্ভ (37–42 সপ্তাহে জন্ম স্বাভাবিক)']];
const msAt = w => { let m = MS[0][1]; MS.forEach(([a, s]) => { if (w >= a) m = s; }); return m; };
const TR = { t1: ['প্রথম ত্রৈমাসিক', 'প্রথম ত্রৈমাসিক (সপ্তাহ 1–13)', 'নিষেক, প্রোথন ও অঙ্গসৃষ্টি (অর্গানোজেনেসিস) — ভ্রূণ সবচেয়ে সংবেদনশীল: ওষুধ, এক্স-রে, রুবেলা, অ্যালকোহল, ধূমপানে জন্মগত ত্রুটির ঝুঁকি সবচেয়ে বেশি। মায়ের বমিভাব সাধারণ। গর্ভপাতের অধিকাংশ এ সময়েই।', 10], t2: ['দ্বিতীয় ত্রৈমাসিক', 'দ্বিতীয় ত্রৈমাসিক (সপ্তাহ 14–27)', 'দ্রুত দৈর্ঘ্য বৃদ্ধি; মা নড়াচড়া টের পান; 18–22 সপ্তাহে আল্ট্রাসনোগ্রাফিতে গঠনগত ত্রুটি দেখা হয়। অমরা hCG এর বদলে নিজেই প্রোজেস্টেরন-ইস্ট্রোজেন তৈরি করে।', 20], t3: ['তৃতীয় ত্রৈমাসিক', 'তৃতীয় ত্রৈমাসিক (সপ্তাহ 28–40)', 'ওজন দ্রুত বাড়ে (জন্ম-ওজনের প্রায় দুই-তৃতীয়াংশ এ সময়ে), চর্বি জমে, ফুসফুস ও মস্তিষ্ক পরিপক্ব হয়। মায়ের রক্তশূন্যতা, উচ্চ রক্তচাপ ও ডায়াবেটিস নজরে রাখতে হয়।', 36] };
V.fetalGrowth = Object.assign({}, B.seg({
  id: 'fgr', t: 'গর্ভের সপ্তাহ অনুযায়ী ভ্রূণের বৃদ্ধি', H: 300, def: 't2', types: TR,
  sl: [{ k: 'w', l: 'গর্ভের সপ্তাহ', min: 8, max: 40, step: 1, val: 20 }],
  cap: 'গর্ভকাল গোনা হয় শেষ রজঃস্রাবের প্রথম দিন (LMP) থেকে — গড়ে 280 দিন বা 40 সপ্তাহ (নিষেক থেকে প্রায় 38 সপ্তাহ)। দৈর্ঘ্য: 12 সপ্তাহ পর্যন্ত মাথা-নিতম্ব (CRL), পরে মাথা-গোড়ালি। মান গড় হিসাব (perinatology.com এর সারণি); ব্যক্তিভেদে ভিন্ন। বাঁয়ের ভ্রূণ একই স্কেলে আঁকা — আকার বৃদ্ধি তুলনা করার জন্য।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; preset(ctx, 'w', TR[ty][3]); }
    B.cacheG(g, 'fgrb', gg => { E('rect', { x: 8, y: 22, width: 150, height: 196, rx: 10, fill: B.TS('amn').c, stroke: B.TS('amn').dk, 'stroke-width': .8 }, gg); 
      const X0 = 196, X1 = 350, Y0 = 34, Y1 = 206, xw = w => X0 + (w - 8) / 32 * (X1 - X0), yw = gm => Y1 - gm / 3800 * (Y1 - Y0);
      for (let gm = 0; gm <= 3500; gm += 1000) { E('path', { d: `M${X0} ${f1(yw(gm))}H${X1}`, stroke: FK.alpha(C.fg, .1), 'stroke-width': .7 }, gg); B.tx(gg, X0 - 4, yw(gm) + 3, FK.n(gm / 1000, 0), { fs: 9.6, a: 'end', c: C.mu }); }
      B.tx(gg, X0 - 4, 24, 'ওজন (কেজি)', { fs: 9.8, c: C.mu, a: 'start' }); for (let w = 8; w <= 40; w += 8) B.tx(gg, xw(w), 220, String(w), { fs: 9.8, a: 'middle', c: C.mu }); B.tx(gg, X1, 232, 'সপ্তাহ →', { fs: 9.6, a: 'end', c: C.mu });
      [[8, 13.9, '#f4dccf'], [13.9, 27.9, '#e4ecd8'], [27.9, 40, '#e0e4f2']].forEach(([a, b, c]) => E('rect', { x: f1(xw(a)), y: Y1 + 2, width: f1(xw(b) - xw(a)), height: 5, fill: c }, gg));
      let d = ''; for (let w = 8; w <= 40; w += .5) d += (w > 8 ? 'L' : 'M') + f1(xw(w)) + ' ' + f1(yw(fgAt(w)[1])); E('path', { d, stroke: '#a05a3a', 'stroke-width': 2, fill: 'none' }, gg); FG.forEach(([w, , gm]) => E('circle', { cx: f1(xw(w)), cy: f1(yw(gm)), r: 2, fill: '#a05a3a' }, gg)); });
    const w = ctx.v.w, [L, gm] = fgAt(w), hp = w < 12 ? 1.5 : w < 20 ? 1.5 - (w - 12) / 8 * .3 : 1.2 - Math.min(1, (w - 20) / 20) * .2, s = Math.max(1.3, L / 51 * 36);
    B.fetus(g, 88, 116 + s * .2, s, 0, { hp, cord: [-14, 18] });
    const X0 = 196, X1 = 350, xw = w => X0 + (w - 8) / 32 * (X1 - X0), yw = gm => 206 - gm / 3800 * 172; E('circle', { cx: f1(xw(w)), cy: f1(yw(gm)), r: 4.6, fill: '#c0392b', stroke: '#fff', 'stroke-width': 1.2 }, g);
    B.tx(g, 83, 213, 'হৃৎস্পন্দন ≈ 110–160/মিনিট', { fs: 9.8, a: 'middle', c: '#a8201a' });
    E('rect', { x: 8, y: 240, width: 344, height: 54, rx: 8, fill: FK.alpha('#a05a3a', .08), stroke: FK.alpha('#a05a3a', .3), 'stroke-width': .7 }, g);
    B.tx(g, 18, 258, `${w} সপ্তাহ: দৈর্ঘ্য ≈ ${FK.n(L, 1)} সেমি · ওজন ≈ ${gm < 1000 ? FK.n(gm, 0) + ' গ্রাম' : FK.n(gm / 1000, 2) + ' কেজি'}`, { fs: 11, w: 700, c: '#7a3a1a' });
    const m = msAt(w); B.tx(g, 18, 276, m.length > 52 ? m.slice(0, m.lastIndexOf(' ', 52)) : m, { fs: 10, c: C.fg }); if (m.length > 52) B.tx(g, 18, 290, m.slice(m.lastIndexOf(' ', 52) + 1), { fs: 10, c: C.fg }); },
  anim(g, C, ty, t, ctx) { const w = ctx.v.w || 20, k = .5 + .5 * Math.sin(t * 2 * PI * 2.3); if (w >= 6) { const [L] = fgAt(w), s = Math.max(1.3, L / 51 * 36); E('circle', { cx: f1(88 - s * .4), cy: f1(116 + s * .2 + s * .1), r: f1(Math.max(1.2, s * .07) * (1 + k * .3)), fill: '#c9352b', opacity: f1(.4 + k * .5) }, g); } }
}));

/* ═════════ জরায়ুর উচ্চতা (ফান্ডাল হাইট) ═════════ */
const TORSO = [[0, 0], [16, 1], [22, 10], [58, 22], [70, 34], [70, 58], [62, 80], [58, 112], [56, 140], [62, 168], [72, 196], [76, 222], [72, 252], [66, 280]];
const LM = { xi: 98, um: 168, sy: 236 };
const fundY = w => { const P = [[12, LM.sy - 4], [16, (LM.sy + LM.um) / 2], [20, LM.um + 6], [24, LM.um - 6], [28, LM.um - (LM.um - LM.xi) / 3], [32, LM.um - (LM.um - LM.xi) * 2 / 3], [36, LM.xi + 2], [40, LM.um - (LM.um - LM.xi) * .62]]; if (w <= 12) return LM.sy; for (let i = 0; i < P.length - 1; i++) if (w <= P[i + 1][0]) return lerp(P[i][1], P[i + 1][1], (w - P[i][0]) / (P[i + 1][0] - P[i][0])); return P[P.length - 1][1]; };
V.fundalHeight = Object.assign({}, B.seg({
  id: 'fund', t: 'গর্ভকালে জরায়ুর উচ্চতা (ফান্ডাল হাইট)', H: 300, def: 'one', types: { one: ['ফান্ডাল হাইট', 'জরায়ুর চূড়ার (ফান্ডাস) উচ্চতা', 'প্রসবপূর্ব পরীক্ষায় পেটে হাত দিয়ে জরায়ুর চূড়া কোথায় আছে দেখে গর্ভের বয়স ও ভ্রূণের বৃদ্ধি আন্দাজ করা হয়: 12 সপ্তাহে পিউবিক সিমফাইসিসের ঠিক ওপরে, 20–22 সপ্তাহে নাভির কাছে, 36 সপ্তাহে বক্ষাস্থির নিচের প্রান্ত (জিফিস্টার্নাম) পর্যন্ত। শেষ কয়েক সপ্তাহে মাথা পেলভিসে নেমে গেলে (লাইটেনিং) চূড়া একটু নিচে নামে। 20–36 সপ্তাহে সিমফাইসিস থেকে চূড়ার দূরত্ব (সেমি) প্রায় সপ্তাহ সংখ্যার সমান (±2)।'] },
  sl: [{ k: 'w', l: 'গর্ভের সপ্তাহ', min: 12, max: 40, step: 1, val: 28 }],
  cap: 'সামনে থেকে দেখা মায়ের ধড়ে সপ্তাহভেদে জরায়ুর চূড়ার অবস্থান (প্রচলিত ক্লিনিক্যাল চিহ্ন)। প্রত্যাশার চেয়ে কম বা বেশি হলে আল্ট্রাসনোগ্রাফিতে ভ্রূণের বৃদ্ধি, যমজ বা অ্যামনিওটিক তরলের পরিমাণ দেখা হয়।',
  art(g, C, ty, ctx) { const cx = 120, w = ctx.v.w, fy = fundY(w), bulge = Math.max(0, (LM.sy - fy - 40) / 140) * 26;
    const R = TORSO.map(([x, y]) => [x + (y > 110 && y < 250 ? bulge * Math.sin((y - 110) / 140 * PI) * .35 : 0), y + 10]); const pts = R.concat(R.slice(1, -1).reverse().map(([x, y]) => [-x, y])).map(([x, y]) => [cx + x, y]);
    E('path', { d: sm(pts.slice(0, R.length).concat([[cx - 66, 290]]).concat(pts.slice(R.length)), true, .5), fill: FK.alpha(B.TS('skin').c, .55), stroke: B.TS('skin').dk, 'stroke-width': 1 }, g);
    E('path', { d: `M${cx - 46} ${LM.xi - 8}Q${cx - 36} ${LM.xi - 30} ${cx - 16} ${LM.xi - 12}M${cx + 46} ${LM.xi - 8}Q${cx + 36} ${LM.xi - 30} ${cx + 16} ${LM.xi - 12}`, stroke: B.TS('skin').dk, 'stroke-width': .9, fill: 'none', opacity: .7 }, g);
    E('path', { d: `M${cx} ${LM.xi}L${cx - 48} ${LM.xi + 30}M${cx} ${LM.xi}L${cx + 48} ${LM.xi + 30}`, stroke: '#a89a7e', 'stroke-width': 1.2, 'stroke-dasharray': '3 2', fill: 'none' }, g); E('path', { d: `M${cx} ${LM.xi - 30}V${LM.xi}`, stroke: '#a89a7e', 'stroke-width': 3, 'stroke-linecap': 'round' }, g);
    E('path', { d: `M${cx - 30} ${LM.sy + 4}Q${cx} ${LM.sy - 6} ${cx + 30} ${LM.sy + 4}`, stroke: '#a89a7e', 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round' }, g);
    /* জরায়ু */ const uw = 18 + (LM.sy - fy) * .34 + bulge * .4, ud = sm([[cx, fy], [cx + uw * .78, fy + 8], [cx + uw, fy + (LM.sy - fy) * .4], [cx + uw * .7, LM.sy - 4], [cx + 10, LM.sy + 10], [cx - 10, LM.sy + 10], [cx - uw * .7, LM.sy - 4], [cx - uw, fy + (LM.sy - fy) * .4], [cx - uw * .78, fy + 8]], true, .5);
    B.organ(g, ud, 'ut', { sw: 1.2, op: .72 }); E('path', { d: ud, fill: 'none', stroke: B.TS('ut').dk, 'stroke-width': 1.2 }, g);
    const [L] = fgAt(w), sc = Math.min(uw * 1.1, (LM.sy - fy) * .55, 8 + L / 51 * 34); if (w >= 14) B.fetus(g, cx + 2, fy + (LM.sy - fy) * .55, sc * .45, w >= 32 ? 180 : 0, { hp: w < 20 ? 1.35 : 1.15, cord: false });
    E('circle', { cx, cy: LM.um, r: 2.6, fill: 'none', stroke: B.TS('skin').dk, 'stroke-width': 1.2 }, g);
    /* মাপকাঠি ও চিহ্ন */ [[LM.xi, 'জিফিস্টার্নাম', 36], [LM.um, 'নাভি', 20], [LM.sy, 'সিমফাইসিস', 12]].forEach(([y, n, wk]) => { E('path', { d: `M${cx + 76} ${y}H${cx + 92}`, stroke: FK.alpha(C.fg, .5), 'stroke-width': .8 }, g); B.tx(g, cx + 96, y + 4, `${n} (≈ ${wk} সপ্তাহ)`, { fs: 10.4, c: C.fg }); });
    E('path', { d: `M${cx + 86} ${LM.sy}V${f1(fy)}`, stroke: '#2a6ab0', 'stroke-width': 1.4, 'marker-end': B.mk(g, '#2a6ab0', 6), 'marker-start': B.mk(g, '#2a6ab0', 6) }, g);
    const cm = w >= 20 ? w : null; B.tx(g, cx + 96, f1((LM.sy + fy) / 2 + 22), cm ? `ফান্ডাল হাইট ≈ ${cm} ± 2 সেমি` : 'চূড়া এখনো নাভির নিচে', { fs: 10, c: '#2a5a90' }); },
  anim(g, C, ty, t, ctx) { const w = ctx.v.w, fy = fundY(w), k = .5 + .5 * Math.sin(t * 3); E('path', { d: `M86 ${f1(fy)}H154`, stroke: '#c0392b', 'stroke-width': 1.4, 'stroke-dasharray': '4 3', opacity: f1(.5 + .5 * k) }, g); T(g, 14, 18, `সপ্তাহ ${w}`, { fs: 12, w: 700, c: '#a8201a' }); if (w >= 38) T(g, 14, 34, 'লাইটেনিং — মাথা পেলভিসে নেমেছে', { fs: 9.8, c: '#a8201a' }); }
}));

/* ═════════ প্রসব (তিন ধাপ) ═════════ */
const LB = [
  { t: 'প্রসবের আগে', en: 'Before labour', d: 'প্রায় 40 সপ্তাহে ভ্রূণ সাধারণত মাথা নিচে (সেফালিক উপস্থাপন), মাথা পেলভিসে নেমে আসে। সার্ভিক্স বন্ধ ও লম্বা, শ্লেষ্মা প্লাগ আটকে আছে। ইস্ট্রোজেন বেড়ে জরায়ুতে অক্সিটোসিন গ্রাহক বাড়ায়, প্রোজেস্টেরনের প্রভাব কমে।' },
  { t: '১ম ধাপ: সার্ভিক্সের প্রসারণ', en: 'Stage 1: dilatation', d: 'নিয়মিত ব্যথাযুক্ত সংকোচন শুরু — ভ্রূণের মাথার চাপে সার্ভিক্স থেকে স্নায়ু-সংকেত → হাইপোথ্যালামাস → পশ্চাৎ পিটুইটারি থেকে অক্সিটোসিন → আরও জোরালো সংকোচন (ধনাত্মক ফিডব্যাক); প্রোস্টাগ্ল্যান্ডিনও সাহায্য করে। সার্ভিক্স পাতলা হয়ে 0 থেকে 10 সেমি খোলে; সাধারণত অ্যামনিওটিক থলি ফেটে পানি ভাঙে। প্রথম সন্তানে প্রায় 12–14 ঘণ্টা, পরে কম।' },
  { t: '২য় ধাপ: শিশু বের হওয়া', en: 'Stage 2: expulsion', d: 'সার্ভিক্স সম্পূর্ণ খোলার পর জরায়ুর সংকোচনের সাথে মায়ের পেটের পেশির চাপে (কোঁত) শিশু যোনিপথে নেমে আসে — সাধারণত প্রথমে মাথা, মুখ মায়ের পিঠের দিকে। কয়েক মিনিট থেকে প্রায় 2 ঘণ্টা। জন্মের পর নাভিরজ্জু বেঁধে কাটা হয়; প্রথম কান্নায় ফুসফুস প্রসারিত হয়।' },
  { t: '৩য় ধাপ: অমরা বের হওয়া', en: 'Stage 3: placenta', d: 'শিশু জন্মের 5–30 মিনিট পর জরায়ু আরও সংকুচিত হয়ে অমরা ও ভ্রূণাবরণী আলাদা হয়ে বের হয় (গর্ভফুল)। জরায়ুর পেশি "জীবন্ত সেলাই"এর মতো রক্তনালি চেপে রক্তপাত থামায় — প্রসব-পরবর্তী অতিরিক্ত রক্তক্ষরণ (PPH) মাতৃমৃত্যুর প্রধান কারণ, তাই এ ধাপে অক্সিটোসিন ইনজেকশন দেওয়া হয় (WHO এর পরামর্শ)।' }
];
const LBS = (g, s, u, pulse, dil) => {
      const dsc = s < 2 ? 0 : s === 2 ? u : 1, shr = s === 3 ? .34 + u * .1 : s === 2 ? u * .34 : 0;
      /* যোনিপথ — সার্ভিক্স থেকে সামনে-নিচে, পিউবিসের পেছন দিয়ে */ const vg = `M186 222C188 246 198 268 222 296`, vw = 9 + dil * 6 + (s === 2 ? 22 * Math.min(1, u * 1.6) : 0); B.tube(g, vg, vw + 8, 'ut', { sw: .9, hl: false }); B.tube(g, vg, vw, 'endm', { sw: .4, hl: false });
      /* জরায়ু */ const k1 = 1 - shr - pulse * .02, ux = 186, uy = 128, U = sm([[ux, uy - 116 * k1], [ux + 92 * k1, uy - 80 * k1], [ux + 108 * k1, uy], [ux + 84 * k1, uy + 76], [ux + 34 + dil * 10, uy + 102], [ux - 34 - dil * 10, uy + 102], [ux - 84 * k1, uy + 76], [ux - 108 * k1, uy], [ux - 92 * k1, uy - 80 * k1]], true, .5);
      B.organ(g, U, 'ut', { sw: 1.2 + pulse * 2, st: pulse > .3 ? '#80201a' : undefined }); const IU = sm([[ux, uy - 104 * k1], [ux + 80 * k1, uy - 72 * k1], [ux + 96 * k1, uy], [ux + 74 * k1, uy + 70], [ux + 22 + dil * 18, uy + 96], [ux - 22 - dil * 18, uy + 96], [ux - 74 * k1, uy + 70], [ux - 96 * k1, uy], [ux - 80 * k1, uy - 72 * k1]], true, .5);
      E('path', { d: IU, fill: s < 2 ? B.TS('amn').c : '#fbefe8', stroke: B.TS('amn').dk, 'stroke-width': .8 }, g);
      /* সার্ভিক্সের ঠোঁট: দৈর্ঘ্য কমে (এফেসমেন্ট) ও মুখ খোলে */ const op = 3 + dil * 28, cl = 22 - dil * 14; [-1, 1].forEach(sx => B.organ(g, B.ellD(ux + sx * (op / 2 + 7), uy + 104 + cl / 2 - 6, 7, cl / 2 + 3, 0), 'ut', { sw: .9 }));
      if (s === 0) E('path', { d: `M${ux - 1.6} ${uy + 96}h3.2v${cl}h-3.2Z`, fill: '#e8f0d8', stroke: '#9aa870', 'stroke-width': .5 }, g);
      /* অমরা (ওপরে পেছনে) */ const pd = s === 3 ? u : 0; B.organ(g, sm([[ux - 60 * k1, uy - 78 * k1 + pd * 120], [ux - 20 * k1, uy - 98 * k1 + pd * 130], [ux + 20 * k1, uy - 92 * k1 + pd * 128], [ux + 10 * k1, uy - 78 * k1 + pd * 126], [ux - 40 * k1, uy - 66 * k1 + pd * 120]], true, .5), 'plac', { sw: .8 });
      /* ভ্রূণ */ if (s < 2) B.fetus(g, ux - 4, uy - 14, 29, 172, { hp: 1.05, cord: [8, -16] }); else if (s === 2) { const e = Math.min(1, dsc * 1.15), fx = ux - 4 + e * 20, fy = uy - 14 + e * 128; B.fetus(g, fx, fy, 29, 172 - e * 22, { hp: 1.05, cord: [8, -16] }); }
      else { E('path', { d: `M${ux - 20} ${uy - 70 + u * 126}C${ux - 10} ${uy + 20 + u * 60} ${ux + 2} ${uy + 120} ${ux + 30} ${uy + 166}`, stroke: '#8aa0d8', 'stroke-width': 3, fill: 'none' }, g); }
  return U; };
V.labour = Object.assign({ t: 'প্রসবের ধাপ', k: ['2d', 'anim', 'steps'], cap: 'মায়ের শ্রোণিচক্রের মধ্যরেখা বরাবর লম্বচ্ছেদ (মা ডানদিকে মুখ করে) — সরলীকৃত। প্রসব (পার্টুরিশন) তিন ধাপে ঘটে; অক্সিটোসিনের ধনাত্মক ফিডব্যাক চক্রটি ভাঙে শিশু বের হয়ে গেলে।' },
  BK.steps({ W: 360, H: 300, label: 'প্রসব', dur: 4, stages: LB,
    draw(g, C, s, u) { const pulse = s === 1 || s === 2 ? Math.max(0, Math.sin(u * PI * 4)) : s === 3 ? Math.max(0, Math.sin(u * PI * 2)) * .6 : 0;
      B.cacheG(g, 'lbb', gg => { /* মেরুদণ্ড-স্যাক্রাম */ for (let i = 0; i < 6; i++) { const x = 58 + Math.sin(i / 5 * PI) * 8 + i * 2, y = 34 + i * 26, a = -8 + i * 6; B.organ(gg, `M${x - 13} ${y - 9}Q${x} ${y - 12} ${x + 13} ${y - 9}L${x + 14} ${y + 9}Q${x} ${y + 12} ${x - 14} ${y + 9}Z`, 'bone', { sw: .8, st: B.TS('bone').dk }).setAttribute('transform', `rotate(${a} ${x} ${y})`); if (i < 5) E('path', { d: B.ellD(x + 1, y + 13, 12, 2.4, a), fill: '#d8e8f0', stroke: '#87a0b0', 'stroke-width': .5 }, gg); } B.organ(gg, sm([[80, 186], [98, 196], [104, 232], [100, 262], [112, 286], [96, 290], [80, 262], [70, 228], [68, 196]], true, .5), 'bone', { sw: .8 }); B.tx(gg, 40, 232, 'স্যাক্রাম', { fs: 9.8, c: C.mu, a: 'middle' });
        /* পিউবিক সিমফাইসিস */ B.organ(gg, B.ellD(252, 236, 10, 18, -20), 'bone', { sw: .8 }); B.tx(gg, 300, 244, 'পিউবিস', { fs: 9.8, c: C.mu, a: 'middle' });
        /* পেটের প্রাচীর */ E('path', { d: 'M226 8C300 30 330 100 316 170C306 206 286 222 268 232', stroke: B.TS('skin').dk, 'stroke-width': 1.2, fill: 'none' }, gg); B.organ(gg, sm([[216, 210], [244, 204], [250, 222], [232, 234], [212, 228]], true, .5), 'muc', { sw: .7 }); B.tx(gg, 300, 210, 'মূত্রথলি', { fs: 9.8, c: C.mu, a: 'middle' }); });
      const dil = s === 0 ? 0 : s === 1 ? Math.round(u * 8) / 8 : 1;
      if (s < 2) { B.cacheG(g, 'lbu' + (s * 10 + Math.round(dil * 8)), gu => LBS(gu, s, 0, 0, dil)); const pq = Math.round(pulse * 5); if (pq > 0) B.cacheG(g, 'lbp' + (pq * 100 + s * 10 + Math.round(dil * 8)), gp => { const pulse = pq / 5, k1 = 1 - pulse * .02, ux = 186, uy = 128; E('path', { d: sm([[ux, uy - 116 * k1], [ux + 92 * k1, uy - 80 * k1], [ux + 108 * k1, uy], [ux + 84 * k1, uy + 76], [ux + 34 + dil * 10, uy + 102], [ux - 34 - dil * 10, uy + 102], [ux - 84 * k1, uy + 76], [ux - 108 * k1, uy], [ux - 92 * k1, uy - 80 * k1]], true, .5), fill: 'none', stroke: '#80201a', 'stroke-width': f1(1 + pulse * 2.6), opacity: f1(.3 + pulse * .6) }, gp); if (pulse > .3) B.tx(gp, 352, s === 1 ? 52 : 36, 'সংকোচন', { fs: 10, a: 'end', c: '#80201a' }); }); }
      else LBS(g, s, u, pulse, dil);
      /* সার্ভিক্স খোলার মাপ */ B.cacheG(g, 'lbl' + s, gl => { B.tx(gl, 8, 18, LB[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s === 1) B.tx(gl, 8, 292, 'অক্সিটোসিন ↑ → সংকোচন ↑ → চাপ ↑', { fs: 9.8, a: 'start', w: 700, c: '#7a3a9a' }); if (s === 3) B.tx(gl, 352, 292, 'গর্ভফুল (অমরা) বের হচ্ছে', { fs: 9.8, a: 'end', w: 700, c: '#7a3a1a' }); if (s === 0) B.tx(gl, 352, 292, 'সার্ভিক্স বন্ধ', { fs: 9.8, a: 'end', c: C.mu }); });
      if (s === 1) B.cacheG(g, 'lbc' + Math.round(dil * 8), gc => B.tx(gc, 352, 36, `সার্ভিক্স ≈ ${FK.n(dil * 10, 0)} সেমি`, { fs: 10.4, a: 'end', w: 700, c: '#2a5a90' })); if (s >= 2 && pulse > .3) T(g, 352, 36, 'সংকোচন', { fs: 10, a: 'end', c: '#80201a' }); }
  }));
})();
