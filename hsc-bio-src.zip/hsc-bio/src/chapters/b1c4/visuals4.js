/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §৪.৪ সার-সংক্ষেপ
   b1c4map    : অণুজীব অধ্যায়ের মাইন্ড ম্যাপ
   microScale : অণুজীবের আকারের লগ-স্কেল — কোনটি কোন যন্ত্রে দেখা যায় (চিপ/স্বয়ংক্রিয় ভ্রমণ)
   সংখ্যা (nm): পোলিও 30, T2 ফাজ প্রায় 200 (মাথা 95 + লেজ 95 + কলার), TMV 300, Mycoplasma 200,
   মিমিভাইরাস 750, E. coli 2000, লোহিত কণিকা 7500, স্পোরোজয়েট 12000, Thiomargarita 1e7
   আলোক অণুবীক্ষণের বিভেদন-সীমা প্রায় 200 nm; খালি চোখ প্রায় 0.1 mm = 1e5 nm
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

V.b1c4map = Object.assign({
  t: 'অণুজীব — এক নজরে', k: ['mind', 'int'],
  cap: 'ভাইরাস, ব্যাকটেরিয়া ও ম্যালেরিয়া পরজীবী — অধ্যায়ের সবচেয়ে জরুরি তথ্য এক জায়গায়। পাতায় চাপ দিলে বিস্তারিত।'
}, BK.mind({
  t: 'অণুজীব', d: 'খালি চোখে অদৃশ্য জীব ও জীবসদৃশ সত্তা।',
  c: [
    { t: 'ভাইরাস', d: 'অকোষীয়; DNA অথবা RNA + ক্যাপসিড; 20–300 nm।', c: [{ t: 'প্রকৃতি', d: 'জীব ও জড়ের যোগসূত্র; বাধ্যতামূলক অন্তঃকোষীয় পরজীবী।' }, { t: 'গঠন', d: 'TMV — দণ্ড, ssRNA; T2 — মাথা-লেজ, dsDNA, পোষক E. coli।' }, { t: 'বংশবৃদ্ধি', d: 'লাইটিক (সংযুক্তি → অনুপ্রবেশ → সংশ্লেষণ → সমাবেশ → বিদারণ) ও লাইসোজেনিক (প্রোফাজ)।' }, { t: 'সাবভাইরাল', d: 'ভিরয়েড — কেবল RNA; প্রিয়ন — কেবল প্রোটিন।' }, { t: 'রোগ', d: 'ডেঙ্গু, হেপাটাইটিস, AIDS, পোলিও; HPV — ক্যান্সার।' }] },
    { t: 'ব্যাকটেরিয়া', d: 'আদিকোষী; 70S রাইবোজোম; পেপটিডোগ্লাইকান প্রাচীর।', c: [{ t: 'শ্রেণি', d: 'আকৃতি, ফ্ল্যাজেলা, গ্রাম রঞ্জন (পজিটিভ বেগুনি, নেগেটিভ লাল), পুষ্টি, শ্বসন।' }, { t: 'গঠন', d: 'ক্যাপসুল, প্রাচীর, ঝিল্লি, নিউক্লিওয়েড, প্লাজমিড, ফ্ল্যাজেলা, পিলি।' }, { t: 'জনন', d: 'দ্বিবিভাজন (প্রায় 20 মিনিট); এন্ডোস্পোর; রূপান্তর, ট্রান্সডাকশন, কনজুগেশন।' }, { t: 'উপকার', d: 'N₂ সংবন্ধন (Rhizobium), দই, ভিনেগার, অ্যান্টিবায়োটিক, ইনসুলিন।' }, { t: 'রোগ', d: 'কলেরা, টাইফয়েড, যক্ষ্মা, ধনুষ্টংকার; ফসলে পাতা ঝলসানো।' }] },
    { t: 'ম্যালেরিয়া পরজীবী', d: 'Plasmodium — এককোষী সুকেন্দ্রিক প্রোটোজোয়া।', c: [{ t: 'পোষক', d: 'মানুষ — মাধ্যমিক (অযৌন); স্ত্রী Anopheles — মুখ্য (যৌন)।' }, { t: 'মানবদেহে', d: 'যকৃতে ও লোহিত কণিকায় সাইজোগনি; গ্যামিটোসাইট।' }, { t: 'মশকীর দেহে', d: 'গ্যামিটোগনি → জাইগোট (2n) → উকিনিট → উসিস্ট (মায়োসিস) → স্পোরোজয়েট।' }, { t: 'জনুঃক্রম', d: 'অযৌন জনু মানুষে, যৌন জনু মশকীতে।' }, { t: 'নিয়ন্ত্রণ', d: 'RDT, ACT, প্রাইমাকুইন, মশারি, লার্ভা দমন; লক্ষ্য 2030।' }] }
  ]
}));

const MS = [
  ['পোলিও ভাইরাস', 30, 'আবরণহীন বিশতলক RNA ভাইরাস'],
  ['T2 ফাজ', 200, 'মাথা প্রায় 65 × 95 nm, লেজ প্রায় 95 nm'],
  ['Mycoplasma', 200, 'ক্ষুদ্রতম ব্যাকটেরিয়াগুলোর একটি; প্রাচীরহীন'],
  ['TMV', 300, 'দণ্ডাকার, প্রায় 300 × 18 nm'],
  ['মিমিভাইরাস', 750, 'দৈত্যাকার ভাইরাস — কিছু ব্যাকটেরিয়ার চেয়েও বড়'],
  ['E. coli', 2000, 'প্রায় 1 × 2 µm দণ্ডাকার ব্যাকটেরিয়া'],
  ['লোহিত কণিকা', 7500, 'মানুষের লোহিত রক্তকণিকা — Plasmodium এর ঘর'],
  ['স্পোরোজয়েট', 12000, 'Plasmodium এর সুতাকার দশা, প্রায় 10–15 µm লম্বা'],
  ['Thiomargarita', 1e7, 'বৃহত্তম ব্যাকটেরিয়া — প্রায় 1 cm, খালি চোখে দেখা যায়']
];
const fmt = n => n >= 1e6 ? `${+(n / 1e6).toFixed(1)} mm` : n >= 1000 ? `${+(n / 1000).toFixed(1)} µm` : `${n} nm`;
const seeBy = n => n >= 1e5 ? 'খালি চোখে দেখা যায়' : n >= 200 ? 'আলোক অণুবীক্ষণে দেখা যায়' : 'কেবল ইলেকট্রন অণুবীক্ষণে দেখা যায়';

V.microScale = {
  t: 'অণুজীবের আকারের মাপকাঠি', k: ['graph', 'anim', 'int'],
  cap: 'লগ স্কেলে প্রতিটি দাগ আগেরটির 10 গুণ। আলোক অণুবীক্ষণ প্রায় 200 nm এর চেয়ে ছোট কিছু আলাদা করে দেখাতে পারে না — তাই অধিকাংশ ভাইরাস দেখতে ইলেকট্রন অণুবীক্ষণ লাগে। চিপে চাপ দাও বা চালু করে স্বয়ংক্রিয় ভ্রমণ দেখো।',
  html: () => `<div class="bk-chips" data-k="chips">${MS.map((m, i) => `<button type="button" data-i="${i}">${m[0]}</button>`).join('')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 300, AX = 22, AW = 316, AY = 232, L0 = 1, L1 = 7, RY = i => 40 + i * 21;
    const px = n => AX + (Math.log10(n) - L0) / (L1 - L0) * AW;
    let C, svg, ring, sel = 6, tt = 0, marks = [];
    const pick = (i, fromUser) => {
      sel = i; const m = MS[i], x = px(m[1]);
      marks.forEach((g, j) => { g.c.setAttribute('r', j === i ? 6.5 : 4.5); g.c.setAttribute('fill', j === i ? BK.ramp(j % 6).dk : BK.ramp(j % 6).c); g.l.setAttribute('font-weight', j === i ? 650 : 520); g.l.setAttribute('opacity', j === i ? 1 : .7); });
      ring.setAttribute('cx', x); ring.setAttribute('cy', marks[i].y);
      const rbc = 7500 / m[1];
      const cmp = i === 6 ? '' : rbc > 1 ? ` · লোহিত কণিকার প্রায় ${rbc >= 10 ? Math.round(rbc) : rbc.toFixed(1)} ভাগের এক ভাগ` : ` · লোহিত কণিকার প্রায় ${(1 / rbc) >= 10 ? Math.round(1 / rbc) : (1 / rbc).toFixed(1)} গুণ`;
      $('info').innerHTML = `<b>${m[0]}</b> — প্রায় ${fmt(m[1])}${cmp}<div class="small">${m[2]}; ${seeBy(m[1])}।</div>`;
      $('chips').querySelectorAll('button').forEach((b, j) => b.classList.toggle('on', j === i));
      if (fromUser) tt = 0;
    };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; marks = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'অণুজীবের আকারের লগ স্কেল' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const zone = (a, b, c, t) => { E('rect', { x: px(a), y: 8, width: px(b) - px(a), height: AY - 8, fill: c, opacity: .13 }, svg); T(svg, (px(a) + px(b)) / 2, 23, t, { fs: 10.5, a: 'middle', w: 620, c: C.mu }); };
      zone(10, 200, BK.ramp(3).c, 'ইলেকট্রন অণুবীক্ষণ');
      zone(200, 1e5, BK.ramp(1).c, 'আলোক অণুবীক্ষণ');
      zone(1e5, 1e7, BK.ramp(0).c, 'খালি চোখ');
      E('path', { d: `M${px(200)} 8V${AY + 30}`, stroke: C.bad, 'stroke-width': 1.3, 'stroke-dasharray': '4 3' }, svg);
      E('path', { d: `M${AX} ${AY}H${AX + AW}`, stroke: C.fg, 'stroke-width': 1.4 }, svg);
      ['10 nm', '100 nm', '1 µm', '10 µm', '100 µm', '1 mm', '1 cm'].forEach((s, k) => { const x = px(10 ** (k + 1)); E('path', { d: `M${x} ${AY - 4}V${AY + 4}`, stroke: C.fg }, svg); T(svg, x, AY + 17, s, { fs: 10, a: 'middle', w: 540, c: C.mu }); });
      MS.forEach((m, i) => {
        const x = px(m[1]), y = RY(i), R = BK.ramp(i % 6);
        E('path', { d: `M${x} ${y + 5}V${AY}`, stroke: R.c, 'stroke-width': 1, 'stroke-dasharray': '1.5 3', opacity: .7 }, svg);
        const g = E('g', { style: 'cursor:pointer' }, svg);
        E('rect', { x: 0, y: y - 10, width: W, height: 20, fill: 'transparent' }, g);
        const c = E('circle', { cx: x, cy: y, r: 4.5, fill: R.c, stroke: R.dk }, g);
        const rt = x > W * .55;
        const l = T(g, x + (rt ? -15 : 15), y + 4, m[0], { fs: 11, a: rt ? 'end' : 'start', w: 520, c: C.fg });
        g.addEventListener('click', () => pick(i, true));
        marks.push({ c, l, y });
      });
      T(svg, px(200) + 6, AY + 30, 'আলোক অণুবীক্ষণের সীমা ≈ 200 nm', { fs: 10.5, a: 'start', w: 620, c: C.bad });
      T(svg, W / 2, H - 10, 'প্রতিটি দাগ আগেরটির 10 গুণ', { fs: 10, a: 'middle', w: 520, c: C.mu });
      ring = E('circle', { r: 10, fill: 'none', stroke: C.fg, 'stroke-width': 1.5 }, svg);
      pick(sel);
    };
    const step = dt => { tt += dt; const r = 10 + 3 * Math.sin(tt * 5); ring.setAttribute('r', r.toFixed(2)); if (tt > 2.4) { tt = 0; pick((sel + 1) % MS.length); } };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    $('chips').addEventListener('click', e => { const b = e.target.closest('button'); if (b) pick(+b.dataset.i, true); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();
