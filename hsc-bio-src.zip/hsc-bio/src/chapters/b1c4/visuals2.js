/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৪.২ ব্যাকটেরিয়া
   bacCell       : আদর্শ ব্যাকটেরিয়া কোষের চিহ্নিত চিত্র (ফ্ল্যাজেলাম ঢেউ খেলে)
   bacShapes     : আকৃতি ও ফ্ল্যাজেলার বিন্যাস — দুই দৃশ্য, অ্যানিমেটেড
   gramStain     : গ্রাম রঞ্জন — চার ধাপে দুই কোষের রং বদল, প্রাচীরের প্রস্থচ্ছেদ
   binaryFission : দ্বিবিভাজন ও সূচকীয় বৃদ্ধি — সময় স্লাইডার, কোষ গণনা
   conjugation   : কনজুগেশন — F⁺ থেকে F⁻ এ প্লাজমিড স্থানান্তর (ধাপে ধাপে)
   bacClass      : শ্রেণিবিভাগ — গাছ
   cmpGram, cmpFlagPili, cmpVirBac : পার্থক্য
   bacUses, bacHarm : উপকারিতা ও অপকারিতা — মাইন্ড ম্যাপ
   bacDiseases   : ব্যাকটেরিয়াজনিত রোগ — গাছ
   সংখ্যা: E. coli দ্বিগুণ ~20 মিনিট (অনুকূল); 2^21 = 2,097,152 (7 ঘণ্টা) — Python দিয়ে যাচাই
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const CX = 170, CY = 140;
V.bacCell = Object.assign({
  t: 'একটি আদর্শ ব্যাকটেরিয়া কোষ', k: ['2d', 'label', 'int', 'anim'],
  cap: 'দণ্ডাকার (ব্যাসিলাস) ব্যাকটেরিয়ার গঠন — বাইরে থেকে ভেতরে: ক্যাপসুল → কোষপ্রাচীর → কোষঝিল্লি → সাইটোপ্লাজম; ভেতরে নিউক্লিওয়েড, প্লাজমিড, 70S রাইবোজোম ও সঞ্চিত দানা; বাইরে ফ্ল্যাজেলা ও পিলি। সুগঠিত নিউক্লিয়াস ও ঝিল্লিবদ্ধ অঙ্গাণু নেই।'
}, BK.diagram({
  W: 360, H: 280, label: 'ব্যাকটেরিয়া কোষ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const svg = g.ownerSVGElement, Rk = BK.ramp(7), Rw = BK.ramp(9), Rm = BK.ramp(2), Rc = BK.ramp(5), Rn = BK.ramp(0), Rp = BK.ramp(1), Rr = BK.ramp(3);
    const cap = P('capsule'); E('rect', { x: CX - 118, y: CY - 62, width: 236, height: 124, rx: 62, fill: FK.alpha(Rk.c, .12), stroke: FK.alpha(Rk.c, .6), 'stroke-width': 1.4, 'stroke-dasharray': '5 4' }, cap);
    const wl = P('wall'); E('rect', { x: CX - 108, y: CY - 52, width: 216, height: 104, rx: 52, fill: 'none', stroke: Rw.c, 'stroke-width': 6 }, wl);
    const mb = P('membrane'); E('rect', { x: CX - 101, y: CY - 45, width: 202, height: 90, rx: 45, fill: BK.lg(svg, FK.alpha(Rc.lt, .9), FK.alpha(Rc.c, .25), { a: 90 }), stroke: Rm.c, 'stroke-width': 2.2 }, mb);
    const nu = P('nucleoid'); let d = `M${CX - 50} ${CY}`; for (let i = 0; i < 12; i++) d += `q${4} ${i % 2 ? 16 : -16} ${9} 0`; E('path', { d, stroke: Rn.c, 'stroke-width': 2.2, fill: 'none' }, nu); E('path', { d: `M${CX - 46} ${CY + 8}c20 18 70 18 90 -6`, stroke: Rn.c, 'stroke-width': 2, fill: 'none' }, nu);
    const pl = P('plasmid'); [[CX + 62, CY - 18], [CX - 72, CY + 20]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 8, fill: 'none', stroke: Rp.c, 'stroke-width': 2 }, pl));
    const rb = P('ribo'); for (let i = 0; i < 26; i++) { const a = i * 2.39, r = 18 + (i * 7) % 26; const x = CX + 74 * Math.cos(a) * (r / 44), y = CY + 30 * Math.sin(a) * (r / 44); if (Math.abs(x - CX) < 56 && Math.abs(y - CY) < 14) continue; E('circle', { cx: x, cy: y, r: 2.4, fill: Rr.dk }, rb); }
    const gr = P('granule'); [[CX + 30, CY + 26], [CX - 20, CY - 28]].forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: 9, ry: 6, fill: FK.alpha(BK.ramp(4).c, .5), stroke: BK.ramp(4).dk }, gr));
    const pi = P('pili'); for (let i = 0; i < 9; i++) { const a = -2.6 + i * .32; const x0 = CX + 108 * Math.cos(a) * .98, y0 = CY + 52 * Math.sin(a); E('path', { d: `M${x0} ${y0}l${12 * Math.cos(a)} ${12 * Math.sin(a)}`, stroke: Rw.dk, 'stroke-width': 1.2 }, pi); }
    P('flag');
  },
  idle(g, C, t) {
    const Rf = BK.ramp(6); let d = `M${CX + 108} ${CY}`; for (let i = 0; i < 9; i++) { const x = CX + 108 + (i + 1) * 7, y = CY + 12 * Math.sin(t * 7 - i * .9); d += `L${x} ${y}`; }
    E('path', { d, stroke: Rf.dk, 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, g);
  },
  parts: [
    { id: 'capsule', bn: 'ক্যাপসুল / পিচ্ছিল স্তর', lb: 'ক্যাপসুল', en: 'Capsule', fn: 'পলিস্যাকারাইড (কখনো পলিপেপটাইড) এর আঠালো স্তর — শুকিয়ে যাওয়া ও শ্বেত রক্তকণিকার ভক্ষণ থেকে রক্ষা করে; রোগ সৃষ্টির ক্ষমতা বাড়ায়।', a: [CX - 112, CY - 30], l: [4, 50], an: 'start' },
    { id: 'wall', bn: 'কোষপ্রাচীর (পেপটিডোগ্লাইকান)', lb: 'কোষপ্রাচীর', en: 'Cell wall', fn: 'মিউরিন বা পেপটিডোগ্লাইকান (NAG + NAM শর্করা, পেপটাইড দিয়ে আড়াআড়ি যুক্ত) — আকৃতি দেয় ও অভিস্রবণে ফেটে যাওয়া ঠেকায়। পেনিসিলিন এর গঠনে বাধা দেয়।', a: [CX - 40, CY - 52], l: [120, 26] },
    { id: 'membrane', bn: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'ফসফোলিপিড দ্বিস্তর; নির্বাচিত ভেদ্য। মাইটোকন্ড্রিয়া না থাকায় শ্বসনের ইলেকট্রন পরিবহন এই ঝিল্লিতেই হয়।', a: [CX + 60, CY - 41], l: [260, 26] },
    { id: 'nucleoid', bn: 'নিউক্লিওয়েড (বৃত্তাকার DNA)', lb: 'নিউক্লিওয়েড', en: 'Nucleoid', fn: 'একটি বড় বৃত্তাকার দ্বিসূত্রক DNA (E. coli তে প্রায় 46 লক্ষ বেস জোড়া), নিউক্লিয়ার পর্দাহীন; হিস্টোন নেই।', a: [CX, CY - 6], l: [190, 250] },
    { id: 'plasmid', bn: 'প্লাজমিড', en: 'Plasmid', fn: 'ক্রোমোসোমের বাইরের ছোট বৃত্তাকার DNA; অ্যান্টিবায়োটিক প্রতিরোধ (R প্লাজমিড) বা কনজুগেশনের (F প্লাজমিড) জিন বহন করে; জিন প্রকৌশলের বাহক।', a: [CX + 62, CY - 18], l: [330, 90] },
    { id: 'ribo', bn: '70S রাইবোজোম', lb: 'রাইবোজোম', en: '70S ribosome', fn: '50S + 30S উপএকক; প্রোটিন সংশ্লেষণ। প্রকৃতকোষের 80S থেকে আলাদা বলে অনেক অ্যান্টিবায়োটিক (স্ট্রেপটোমাইসিন, টেট্রাসাইক্লিন) কেবল ব্যাকটেরিয়ার রাইবোজোমে কাজ করে।', a: [CX + 50, CY + 30], l: [300, 230] },
    { id: 'granule', bn: 'সঞ্চিত দানা', en: 'Inclusion body', fn: 'গ্লাইকোজেন, ভলিউটিন (পলিফসফেট), চর্বির দানা — খাদ্য ও শক্তির সঞ্চয়।', a: [CX - 20, CY - 28], l: [4, 240], an: 'start' },
    { id: 'pili', bn: 'পিলি / ফিমব্রি', lb: 'পিলি', en: 'Pili', fn: 'ছোট, সরু, অসংখ্য প্রোটিন (পিলিন) উপাঙ্গ — পৃষ্ঠে আটকে থাকা; সেক্স পিলাস কনজুগেশনে DNA স্থানান্তরের সেতু।', a: [CX - 90, CY - 48], l: [4, 130], an: 'start' },
    { id: 'flag', bn: 'ফ্ল্যাজেলাম', en: 'Flagellum', fn: 'ফ্ল্যাজেলিন প্রোটিনের লম্বা সর্পিল সুতা; গোড়ার ঘূর্ণায়মান মোটর (বেসাল বডি) প্রোপেলারের মতো ঘুরিয়ে চলন ঘটায়।', a: [CX + 130, CY + 4], l: [330, 170] }
  ]
}));

/* ───────── আকৃতি ও ফ্ল্যাজেলা ───────── */
const SHP = [
  ['mc', 'মাইক্রোককাস', 'একক গোল কোষ', 'Micrococcus'], ['dc', 'ডিপ্লোককাস', 'জোড়ায় জোড়ায়', 'Streptococcus pneumoniae'], ['sc', 'স্ট্রেপটোককাস', 'মালার মতো সারি', 'Streptococcus lactis'],
  ['st', 'স্ট্যাফাইলোককাস', 'আঙুরের থোকার মতো', 'Staphylococcus aureus'], ['ba', 'ব্যাসিলাস', 'দণ্ডাকার', 'Bacillus subtilis, E. coli'], ['vb', 'ভিব্রিও', 'কমা আকৃতি', 'Vibrio cholerae'],
  ['sp', 'স্পাইরিলাম', 'শক্ত সর্পিল', 'Spirillum'], ['spc', 'স্পাইরোকিট', 'নমনীয় সর্পিল', 'Treponema']
];
const FLG = [
  ['at', 'অ্যাট্রাইকাস', 'ফ্ল্যাজেলা নেই', 'Lactobacillus, Shigella'], ['mo', 'মনোট্রাইকাস', 'এক প্রান্তে একটি', 'Vibrio cholerae'], ['lo', 'লোফোট্রাইকাস', 'এক প্রান্তে একগুচ্ছ', 'Pseudomonas fluorescens'],
  ['am', 'অ্যামফিট্রাইকাস', 'দুই প্রান্তে একটি বা গুচ্ছ', 'Spirillum volutans'], ['pe', 'পেরিট্রাইকাস', 'সারা দেহে', 'E. coli, Salmonella typhi']
];
V.bacShapes = {
  t: 'ব্যাকটেরিয়ার আকৃতি ও ফ্ল্যাজেলার বিন্যাস', k: ['2d', 'anim', 'int'],
  cap: 'আকৃতি অনুযায়ী ককাস (গোল), ব্যাসিলাস (দণ্ড), ভিব্রিও (কমা), স্পাইরিলাম (সর্পিল); ককাসের বিন্যাস বিভাজনের তল থেকে আসে। ফ্ল্যাজেলার সংখ্যা ও অবস্থান অনুযায়ী পাঁচ ধরন। ঘরে চাপ দাও।',
  html: () => `<div class="fk-row">${X.seg('m', [['shape', 'আকৃতি'], ['flag', 'ফ্ল্যাজেলা']], 'shape')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360;
    let m = 'shape', sel = 0, C, svg, cells = [], tt = 0, flags = [];
    const list = () => m === 'shape' ? SHP : FLG;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const L = list(), cols = m === 'shape' ? 4 : 3, rows = Math.ceil(L.length / cols), cw = W / cols, ch = 104, H = rows * ch + 8;
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'ব্যাকটেরিয়ার আকৃতি' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); cells = []; flags = [];
      L.forEach((it, i) => {
        const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + 50, R0 = BK.ramp(i);
        const cg = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - cw / 2 + 4, y: y - 46, width: cw - 8, height: ch - 8, rx: 10, fill: i === sel ? FK.alpha(R0.c, .14) : C.s2, stroke: i === sel ? R0.c : C.ln, 'stroke-width': i === sel ? 2 : 1 }, cg);
        const gg = E('g', { transform: `translate(${x} ${y - 6})` }, cg); cells.push({ gg, x, y: y - 6, k: it[0] });
        const cell = (cx, cy, r) => E('circle', { cx, cy, r, fill: R0.c, stroke: R0.dk }, gg);
        const rod = (cx, cy, w = 34, h = 13) => E('rect', { x: cx - w / 2, y: cy - h / 2, width: w, height: h, rx: h / 2, fill: R0.c, stroke: R0.dk }, gg);
        if (m === 'shape') {
          const k = it[0];
          if (k === 'mc') cell(0, 0, 9); else if (k === 'dc') { cell(-8, 0, 8); cell(8, 0, 8); } else if (k === 'sc') for (let j = -3; j <= 3; j++) cell(j * 11, Math.sin(j) * 3, 5.5);
          else if (k === 'st') [[0, 0], [-10, -6], [10, -6], [-10, 6], [10, 6], [0, -12], [0, 12], [-19, 0], [19, 0]].forEach(([a, b]) => cell(a, b, 5.5));
          else if (k === 'ba') rod(0, 0); else if (k === 'vb') E('path', { d: 'M-16 6Q0 -18 16 6', stroke: R0.c, 'stroke-width': 10, fill: 'none', 'stroke-linecap': 'round' }, gg);
          else if (k === 'sp') E('path', { d: 'M-24 0q6 -12 12 0t12 0t12 0t12 0', stroke: R0.c, 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, gg);
          else E('path', { d: 'M-28 0q3.5 -7 7 0t7 0t7 0t7 0t7 0t7 0t7 0t7 0', stroke: R0.c, 'stroke-width': 3, fill: 'none' }, gg);
        } else {
          rod(0, 0, 40, 16); const k = it[0], pos = { at: [], mo: [[20, 0, 0]], lo: [[20, -4, 0], [20, 0, 0], [20, 4, 0]], am: [[20, 0, 0], [-20, 0, Math.PI]], pe: [[20, 0, 0], [-20, 0, Math.PI], [0, -8, -Math.PI / 2], [10, 8, Math.PI / 2], [-10, -8, -Math.PI / 2], [-6, 8, Math.PI / 2]] }[k];
          pos.forEach(([px, py, a]) => { const f = E('path', { stroke: R0.dk, 'stroke-width': 1.6, fill: 'none' }, gg); flags.push({ f, px, py, a }); });
        }
        T(cg, x, y + 40, it[1], { fs: 10.5, a: 'middle', w: 600, c: R0.ink });
      });
      svg.addEventListener('click', e => { const c = e.target.closest('[data-i]'); if (c) { sel = +c.dataset.i; base(); } });
      info(); step(0);
    };
    const info = () => { const it = list()[sel]; $('info').innerHTML = `<b>${it[1]}</b> — ${it[2]}<div class="small">উদাহরণ: <i>${it[3]}</i></div>`; };
    const step = dt => {
      tt += dt;
      flags.forEach((o, i) => { let d = `M${o.px} ${o.py}`; for (let j = 1; j <= 8; j++) { const s = j * 3.2, w = 4 * Math.sin(tt * 9 - j * .9 + i); d += `L${o.px + s * Math.cos(o.a) - w * Math.sin(o.a)} ${o.py + s * Math.sin(o.a) + w * Math.cos(o.a)}`; } o.f.setAttribute('d', d); });
      cells.forEach((c, i) => { const dx = i === sel ? 3 * Math.sin(tt * 2) : 0; c.gg.setAttribute('transform', `translate(${(c.x + dx).toFixed(1)} ${c.y})`); });
    };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'm', v => { m = v; sel = 0; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── গ্রাম রঞ্জন ───────── */
V.gramStain = Object.assign({
  t: 'গ্রাম রঞ্জন পদ্ধতি', k: ['2d', 'anim', 'int'],
  cap: 'ক্রিশ্চিয়ান গ্রাম (1884) উদ্ভাবিত পদ্ধতি। বাঁয়ে গ্রাম পজিটিভ (পুরু পেপটিডোগ্লাইকান), ডানে গ্রাম নেগেটিভ (পাতলা পেপটিডোগ্লাইকান + বাইরের ঝিল্লি)। অ্যালকোহল ধোয়ার ধাপেই পার্থক্য তৈরি হয়।'
}, BK.steps({
  W: 360, H: 250, label: 'গ্রাম রঞ্জন', dur: 2.4,
  stages: [
    { t: 'ক্রিস্টাল ভায়োলেট', en: 'Primary stain', d: 'দুই ধরনের কোষই বেগুনি রং নেয়।' },
    { t: 'আয়োডিন (মরড্যান্ট)', en: 'Mordant', d: 'আয়োডিন রঞ্জকের সাথে বড় CV–I জটিল যৌগ তৈরি করে — দুটিই গাঢ় বেগুনি।' },
    { t: 'অ্যালকোহল দিয়ে ধোয়া', en: 'Decolourise', d: 'পুরু পেপটিডোগ্লাইকান পানিশূন্য হয়ে সংকুচিত হয়, বড় জটিল যৌগ আটকে থাকে — বেগুনি থাকে। পাতলা প্রাচীর ও বাইরের ঝিল্লির লিপিড অ্যালকোহলে গলে রং বেরিয়ে যায় — বর্ণহীন।' },
    { t: 'স্যাফ্রানিন', en: 'Counterstain', d: 'বর্ণহীন গ্রাম নেগেটিভ কোষ লাল/গোলাপি রং নেয়; গ্রাম পজিটিভ বেগুনিই থাকে।' }
  ],
  draw(g, C, s, u) {
    const pur = '#6a2ca0', pink = '#e0568a', clr = '#e9e4f2';
    const mix = (a, b, k) => { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * k).toString(16).padStart(2, '0')).join(''); };
    const posC = s === 0 ? mix(clr, '#9a6cc8', u) : s === 1 ? mix('#9a6cc8', pur, u) : pur;
    const negC = s === 0 ? mix(clr, '#9a6cc8', u) : s === 1 ? mix('#9a6cc8', pur, u) : s === 2 ? mix(pur, clr, u) : mix(clr, pink, u);
    const cellAt = (x, col, thick) => {
      E('rect', { x: x - 56, y: 50, width: 112, height: 48, rx: 24, fill: col, stroke: C.mu, 'stroke-width': 1.4 }, g);
      /* প্রাচীরের প্রস্থচ্ছেদ — স্তরের ভেতরে লেবেল */
      const y0 = 124; T(g, x, y0 - 6, 'প্রাচীরের প্রস্থচ্ছেদ', { fs: 10, a: 'middle', w: 600, c: C.mu });
      const lay = (yy, hh, R0, op, lab) => { E('rect', { x: x - 62, y: yy, width: 124, height: hh, fill: FK.alpha(R0.c, op), stroke: R0.dk, 'stroke-width': 1 }, g); if (lab) T(g, x, yy + hh / 2 + 3.5, lab, { fs: 9.5, a: 'middle', w: 600, c: R0.ink }); };
      if (thick) { lay(y0, 50, BK.ramp(9), .55, 'পুরু পেপটিডোগ্লাইকান'); lay(y0 + 54, 18, BK.ramp(2), .45, 'কোষঝিল্লি'); }
      else { lay(y0, 20, BK.ramp(4), s === 2 ? .45 * (1 - u) + .1 : .5, 'বাইরের ঝিল্লি (LPS)'); lay(y0 + 22, 7, BK.ramp(9), .6, ''); T(g, x + 66, y0 + 29, 'পাতলা', { fs: 9, w: 600, c: BK.ramp(9).ink }); lay(y0 + 31, 6, BK.ramp(9), .15, ''); lay(y0 + 54, 18, BK.ramp(2), .45, 'কোষঝিল্লি'); T(g, x, y0 + 48, 'পাতলা পেপটিডোগ্লাইকান', { fs: 9, a: 'middle', w: 560, c: BK.ramp(9).ink }); }
    };
    cellAt(92, posC, true); cellAt(268, negC, false);
    T(g, 92, 30, 'গ্রাম পজিটিভ', { fs: 12.5, a: 'middle', w: 650, c: '#6a2ca0' }); T(g, 268, 30, 'গ্রাম নেগেটিভ', { fs: 12.5, a: 'middle', w: 650, c: '#c03a6e' });
    if (s === 2) for (let i = 0; i < 6; i++) E('circle', { cx: 268 + 40 * Math.cos(i + u * 5), cy: 74 + 30 * Math.sin(i * 2 + u * 3) - u * 20, r: 2.5, fill: pur, opacity: 1 - u }, g);
  }
}));

/* ───────── দ্বিবিভাজন ───────── */
V.binaryFission = {
  t: 'দ্বিবিভাজন ও সূচকীয় বৃদ্ধি', k: ['graph', 'anim', 'int'],
  cap: 'অনুকূল অবস্থায় E. coli প্রায় 20 মিনিটে একবার বিভাজিত হয়: 1 → 2 → 4 → 8… n প্রজন্মে কোষ = 2 এর n-তম ঘাত। সময় স্লাইডার সরাও বা চালাও। বাস্তবে খাদ্য ফুরিয়ে ও বর্জ্য জমে বৃদ্ধি থেমে যায় (স্থিতি দশা)।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.sl('t', 'সময়', 0, 180, 1, 0, ' মিনিট')}</div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 260;
    let t = 0, C, svg, dots = [], curve, cur, last = -1;
    const sl = FK.bindSl(root, 't', v => { t = v; paint(); }, ' মিনিট', 0);
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'দ্বিবিভাজন' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rb = BK.ramp(5); dots = [];
      for (let i = 0; i < 512; i++) { const col = i % 32, row = Math.floor(i / 32); dots.push(E('rect', { x: 16 + col * 10.4, y: 14 + row * 7.2, width: 8, height: 4.6, rx: 2.3, fill: Rb.c, opacity: 0 }, svg)); }
      /* লেখচিত্র */
      const gx = 40, gy = 248, gw = 300, gh = 112;
      E('path', { d: `M${gx} ${gy - gh}V${gy}H${gx + gw}`, stroke: C.mu, 'stroke-width': 1.2, fill: 'none' }, svg);
      T(svg, gx + gw, gy - 4, 'সময়', { fs: 10, a: 'end', w: 560, c: C.mu }); T(svg, gx + 4, gy - gh + 4, 'কোষসংখ্যা', { fs: 10, w: 560, c: C.mu });
      const pts = []; for (let m = 0; m <= 180; m += 3) pts.push(`${gx + m / 180 * gw} ${gy - Math.pow(2, m / 20) / 512 * gh}`);
      curve = E('path', { d: 'M' + pts.join('L'), stroke: BK.ramp(2).c, 'stroke-width': 2.4, fill: 'none' }, svg);
      cur = E('circle', { r: 5, fill: C.fg }, svg); last = -1; paint();
    };
    const paint = () => {
      const gen = Math.floor(t / 20), frac = (t % 20) / 20, n = Math.pow(2, gen);
      dots.forEach((d, i) => { const on = i < n ? 1 : i < 2 * n && frac > .6 ? (frac - .6) / .4 : 0; d.setAttribute('opacity', on.toFixed(2)); d.setAttribute('width', i < n && frac > .6 && i < 512 ? (8 - 2 * (frac - .6) / .4).toFixed(1) : 8); });
      cur.setAttribute('cx', 40 + t / 180 * 300); cur.setAttribute('cy', 248 - Math.pow(2, t / 20) / 512 * 112);
      if (gen !== last) { last = gen; $('info').innerHTML = `${Math.floor(t)} মিনিট = <b>${FK.bn(gen)}</b> প্রজন্ম → কোষ = 2<sup>${gen}</sup> = <b>${n.toLocaleString('en-US')}</b><div class="small">এই হারে 7 ঘণ্টায় (21 প্রজন্ম) 2,097,152টি কোষ; 24 ঘণ্টায় (72 প্রজন্ম) তাত্ত্বিকভাবে প্রায় 4.7 × 10²¹টি — বাস্তবে খাদ্য ও জায়গার অভাবে এটি কখনো ঘটে না।</div>`; }
    };
    const A = X.anim(root, dt => { t += dt * 12; if (t > 180) t = 0; sl.set(Math.round(t), true); paint(); }, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── কনজুগেশন ───────── */
V.conjugation = Object.assign({
  t: 'কনজুগেশন — প্লাজমিড স্থানান্তর', k: ['2d', 'anim', 'int'],
  cap: 'লেডারবার্গ ও টাটাম (1946) E. coli তে দেখান: F প্লাজমিডধারী (F⁺, দাতা) কোষ সেক্স পিলাসে F⁻ (গ্রহীতা) কোষের সাথে যুক্ত হয়ে প্লাজমিডের একটি সূত্রক পাঠায়; দুই কোষেই পরিপূরক সূত্রক তৈরি হয় — দুটিই F⁺। এটি যৌন জনন নয়, জিনগত পুনর্বিন্যাস (গ্যামেট নেই, সংখ্যা বাড়ে না)।'
}, BK.steps({
  W: 360, H: 210, label: 'কনজুগেশন', dur: 2.6,
  stages: [
    { t: 'F⁺ ও F⁻ কোষ', en: 'Donor & recipient', d: 'F⁺ কোষে F প্লাজমিড (উর্বরতা ফ্যাক্টর) আছে, যা সেক্স পিলাস তৈরির জিন বহন করে।' },
    { t: 'সেক্স পিলাস সংযোগ', en: 'Pilus contact', d: 'পিলাস F⁻ কোষে আটকে সংকুচিত হয়ে দুই কোষকে কাছে টানে; সংযোগ সেতু তৈরি হয়।' },
    { t: 'একসূত্রক স্থানান্তর', en: 'Transfer', d: 'প্লাজমিডের একটি সূত্রক কেটে সেতু দিয়ে F⁻ কোষে যায় (রোলিং সার্কেল রেপ্লিকেশন)।' },
    { t: 'দুটিই F⁺', en: 'Both F⁺', d: 'দুই কোষে পরিপূরক সূত্রক তৈরি হয়ে পূর্ণ প্লাজমিড; কোষ আলাদা হয় — গ্রহীতাও এখন F⁺। অ্যান্টিবায়োটিক প্রতিরোধী জিনও এভাবে দ্রুত ছড়ায়।' }
  ],
  draw(g, C, s, u) {
    const Rb = BK.ramp(5), Rp = BK.ramp(0), Rn = BK.ramp(3);
    const gap = s === 0 ? 70 : s === 1 ? 70 - 40 * u : s === 3 ? 30 + 30 * u : 30;
    const lx = 180 - gap / 2 - 70, rx = 180 + gap / 2 + 70, y = 110;
    [lx, rx].forEach((x, i) => { E('rect', { x: x - 70, y: y - 34, width: 140, height: 68, rx: 34, fill: FK.alpha(Rb.c, .2), stroke: Rb.dk, 'stroke-width': 2 }, g); let d = `M${x - 40} ${y + 8}`; for (let j = 0; j < 7; j++) d += `q5 ${j % 2 ? 9 : -9} 10 0`; E('path', { d, stroke: Rn.c, 'stroke-width': 1.8, fill: 'none', opacity: .7 }, g); });
    if (s >= 1 && s < 3) E('path', { d: `M${lx + 70} ${y - 8}L${rx - 70} ${y - 8}`, stroke: Rb.dk, 'stroke-width': s === 1 ? 2 : 5 }, g);
    /* প্লাজমিড */
    E('circle', { cx: lx + 30, cy: y - 12, r: 12, fill: 'none', stroke: Rp.c, 'stroke-width': 2.6 }, g);
    const tr = s === 2 ? u : s === 3 ? 1 : 0;
    if (s === 2) { const x = lx + 42 + (rx - 30 - lx - 42) * u; E('path', { d: `M${lx + 42} ${y - 12}L${x} ${y - 10}`, stroke: Rp.c, 'stroke-width': 1.6, 'stroke-dasharray': '3 2' }, g); }
    if (tr > 0) E('circle', { cx: rx - 30, cy: y - 12, r: 12 * Math.min(1, tr), fill: 'none', stroke: Rp.c, 'stroke-width': 2.6, 'stroke-dasharray': s === 2 ? '4 3' : null }, g);
    T(g, lx, 34, 'F⁺ (দাতা)', { fs: 12, a: 'middle', w: 650, c: Rp.ink }); T(g, rx, 34, s === 3 ? 'F⁺ (নতুন)' : 'F⁻ (গ্রহীতা)', { fs: 12, a: 'middle', w: 650, c: s === 3 ? Rp.ink : C.mu });
    T(g, 180, 196, 'লাল বৃত্ত = F প্লাজমিড · ঢেউ = ক্রোমোসোম', { fs: 10, a: 'middle', w: 520, c: C.mu });
  }
}));

/* ───────── শ্রেণিবিভাগ, পার্থক্য, উপকারিতা, রোগ ───────── */
V.bacClass = Object.assign({ t: 'ব্যাকটেরিয়ার শ্রেণিবিভাগ', k: ['tree', 'int'], cap: 'আকৃতি, ফ্ল্যাজেলা, গ্রাম রঞ্জন, পুষ্টি ও শ্বসন — পাঁচ ভিত্তি। শাখায় চাপ দাও।' }, BK.tree({
  t: 'ব্যাকটেরিয়া', d: 'আদিকোষী, এককোষী অণুজীব।',
  c: [
    { t: 'আকৃতি', c: [{ t: 'ককাস (গোল)', d: 'মাইক্রো-, ডিপ্লো-, স্ট্রেপটো-, স্ট্যাফাইলো-, টেট্রাড, সারসিনা।' }, { t: 'ব্যাসিলাস (দণ্ড)', d: 'মনো-, ডিপ্লো-, স্ট্রেপটোব্যাসিলাস — Bacillus anthracis শিকলে।' }, { t: 'ভিব্রিও (কমা)', d: 'Vibrio cholerae।' }, { t: 'সর্পিল', d: 'স্পাইরিলাম (শক্ত), স্পাইরোকিট (নমনীয়)।' }] },
    { t: 'ফ্ল্যাজেলা', c: [{ t: 'অ্যাট্রাইকাস', d: 'নেই — Lactobacillus।' }, { t: 'মনোট্রাইকাস', d: 'একটি — Vibrio cholerae।' }, { t: 'লোফোট্রাইকাস', d: 'এক প্রান্তে গুচ্ছ — Pseudomonas।' }, { t: 'অ্যামফিট্রাইকাস', d: 'দুই প্রান্তে।' }, { t: 'পেরিট্রাইকাস', d: 'সারা দেহে — E. coli, Salmonella।' }] },
    { t: 'গ্রাম রঞ্জন', c: [{ t: 'গ্রাম পজিটিভ', d: 'বেগুনি — Bacillus, Staphylococcus, Streptococcus, Clostridium।' }, { t: 'গ্রাম নেগেটিভ', d: 'লাল/গোলাপি — E. coli, Salmonella, Vibrio, Rhizobium।' }] },
    { t: 'পুষ্টি', c: [{ t: 'স্বভোজী', d: 'ফটোঅটোট্রফ (সবুজ ও বেগুনি সালফার ব্যাকটেরিয়া), কেমোঅটোট্রফ (Nitrosomonas, Nitrobacter)।' }, { t: 'পরভোজী', d: 'মৃতজীবী (পচনকারী), পরজীবী (রোগসৃষ্টিকারী), মিথোজীবী (Rhizobium)।' }] },
    { t: 'শ্বসন', c: [{ t: 'বাধ্যতামূলক সবাত', d: 'Mycobacterium tuberculosis।' }, { t: 'বাধ্যতামূলক অবাত', d: 'Clostridium — O₂ এ মারা যায়।' }, { t: 'ঐচ্ছিক অবাত', d: 'E. coli — O₂ থাকলে সবাত, না থাকলে অবাত।' }] }
  ]
}, { colW: 124 }));

V.cmpGram = Object.assign({ t: 'গ্রাম পজিটিভ ও গ্রাম নেগেটিভ ব্যাকটেরিয়ার পার্থক্য', k: ['cmp', 'int'], cap: 'সারণি দেখো, তারপর যাচাই খেলা।' }, BK.compare({
  a: 'গ্রাম পজিটিভ', b: 'গ্রাম নেগেটিভ',
  rows: [
    ['গ্রাম রঞ্জনে রং', 'বেগুনি (ক্রিস্টাল ভায়োলেট ধরে রাখে)', 'লাল/গোলাপি (স্যাফ্রানিন নেয়)'],
    ['পেপটিডোগ্লাইকান', 'পুরু (প্রায় 20–80 nm), বহুস্তর', 'পাতলা (প্রায় 2–7 nm)'],
    ['বাইরের ঝিল্লি', 'নেই', 'আছে — লাইপোপলিস্যাকারাইড (LPS)'],
    ['টাইকোইক অ্যাসিড', 'থাকে', 'থাকে না'],
    ['লিপিডের পরিমাণ', 'কম', 'বেশি'],
    ['পেনিসিলিনে সংবেদনশীলতা', 'বেশি', 'কম'],
    ['বিষ', 'প্রধানত এক্সোটক্সিন', 'LPS — এন্ডোটক্সিন'],
    ['উদাহরণ', 'Bacillus, Staphylococcus, Streptococcus, Clostridium', 'E. coli, Salmonella, Vibrio, Rhizobium']
  ]
}));
V.cmpFlagPili = Object.assign({ t: 'ফ্ল্যাজেলা ও পিলির পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই প্রোটিনের উপাঙ্গ, কিন্তু কাজ আলাদা।' }, BK.compare({
  a: 'ফ্ল্যাজেলা', b: 'পিলি (ফিমব্রি)',
  rows: [
    ['আকার', 'লম্বা (প্রায় 15–20 µm) ও মোটা', 'ছোট (প্রায় 0.5–2 µm) ও সরু'],
    ['সংখ্যা', 'কম (এক থেকে কয়েকটি)', 'অসংখ্য (শত শত)'],
    ['প্রোটিন', 'ফ্ল্যাজেলিন', 'পিলিন'],
    ['গোড়ার গঠন', 'বেসাল বডি, হুক ও সুতা — ঘূর্ণায়মান মোটর', 'সরল; ঘোরে না'],
    ['কাজ', 'চলন', 'পৃষ্ঠে আটকে থাকা; সেক্স পিলাস দিয়ে কনজুগেশন'],
    ['উপস্থিতি', 'চলনক্ষম ব্যাকটেরিয়ায়', 'প্রধানত গ্রাম নেগেটিভ ব্যাকটেরিয়ায়']
  ]
}));
V.cmpVirBac = Object.assign({ t: 'ভাইরাস ও ব্যাকটেরিয়ার পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই অণুজীব, কিন্তু একটি অকোষীয়, অন্যটি সম্পূর্ণ কোষ।' }, BK.compare({
  a: 'ভাইরাস', b: 'ব্যাকটেরিয়া',
  rows: [
    ['কোষীয় গঠন', 'অকোষীয় — কোষ নয়', 'আদিকোষী এককোষী জীব'],
    ['আকার', 'প্রায় 20–300 nm — ইলেকট্রন অণুবীক্ষণ লাগে', 'প্রায় 0.5–5 µm — আলোক অণুবীক্ষণে দেখা যায়'],
    ['নিউক্লিক অ্যাসিড', 'DNA অথবা RNA — একটি', 'DNA ও RNA — দুটিই'],
    ['রাইবোজোম ও বিপাক', 'নেই; নিজে শক্তি বা প্রোটিন তৈরি করতে পারে না', '70S রাইবোজোম; স্বাধীন বিপাক'],
    ['বংশবৃদ্ধি', 'কেবল জীবিত পোষক কোষের ভেতরে', 'দ্বিবিভাজনে, পোষকের বাইরেও'],
    ['কৃত্রিম মাধ্যমে চাষ', 'সম্ভব নয়', 'সম্ভব (আগার মাধ্যম)'],
    ['অ্যান্টিবায়োটিক', 'কাজ করে না', 'কাজ করে'],
    ['কেলাসিত করা যায়', 'হ্যাঁ (TMV)', 'না'],
    ['রোগ', 'ডেঙ্গু, পোলিও, AIDS, কোভিড-19', 'কলেরা, টাইফয়েড, যক্ষ্মা, ধনুষ্টংকার']
  ]
}));
V.bacUses = Object.assign({ t: 'ব্যাকটেরিয়ার উপকারিতা', k: ['mind', 'int'], cap: 'কৃষি, শিল্প, চিকিৎসা ও পরিবেশ — ব্যাকটেরিয়া ছাড়া পৃথিবীর জীবনচক্র অচল। পাতায় চাপ দাও।' }, BK.mind({
  t: 'উপকারী ব্যাকটেরিয়া', d: 'অধিকাংশ ব্যাকটেরিয়া রোগসৃষ্টিকারী নয়।',
  c: [
    { t: 'কৃষি', d: 'মাটির উর্বরতা।', c: [{ t: 'নাইট্রোজেন সংবন্ধন', d: 'Rhizobium (শিমজাতীয় উদ্ভিদের মূলের গুটিতে), Azotobacter, Clostridium (মুক্তজীবী); ধানক্ষেতে Anabaena ও Nostoc।' }, { t: 'নাইট্রিফিকেশন', d: 'Nitrosomonas: NH₃ → NO₂⁻; Nitrobacter: NO₂⁻ → NO₃⁻।' }, { t: 'পচন', d: 'মৃতদেহ ও বর্জ্য ভেঙে খনিজ মাটিতে ফেরায়।' }, { t: 'Bt টক্সিন', d: 'Bacillus thuringiensis এর জিন — বাংলাদেশে Bt বেগুন (2014 থেকে চাষ)।' }] },
    { t: 'শিল্প ও খাদ্য', d: 'গাঁজন ও প্রক্রিয়াকরণ।', c: [{ t: 'দই ও পনির', d: 'Lactobacillus, Streptococcus lactis।' }, { t: 'ভিনেগার', d: 'Acetobacter aceti।' }, { t: 'পাট পচানো', d: 'Clostridium প্রজাতি পেকটিন ভেঙে আঁশ আলাদা করে — বাংলাদেশের পাটশিল্পে।' }, { t: 'চা ও তামাক প্রক্রিয়াকরণ', d: 'স্বাদ ও গন্ধ উন্নত করা।' }] },
    { t: 'চিকিৎসা', d: 'ওষুধ ও গবেষণা।', c: [{ t: 'অ্যান্টিবায়োটিক', d: 'Streptomyces থেকে স্ট্রেপটোমাইসিন (ওয়াক্সম্যান, 1943), টেট্রাসাইক্লিন।' }, { t: 'জিন প্রকৌশল', d: 'E. coli দিয়ে ইনসুলিন ও গ্রোথ হরমোন উৎপাদন।' }, { t: 'অন্ত্রের ব্যাকটেরিয়া', d: 'ভিটামিন K ও B₁₂ তৈরি, ক্ষতিকর জীবাণু প্রতিরোধ।' }] },
    { t: 'পরিবেশ', d: 'দূষণ নিয়ন্ত্রণ।', c: [{ t: 'পয়ঃনিষ্কাশন শোধন', d: 'জৈব বর্জ্য ভাঙে।' }, { t: 'বায়োরিমিডিয়েশন', d: 'Pseudomonas তেল ও বিষাক্ত যৌগ ভাঙে।' }, { t: 'বায়োগ্যাস', d: 'মিথেন উৎপাদক অণুজীব (আর্কিয়া) — গোবর থেকে জ্বালানি।' }] }
  ]
}));
V.bacHarm = Object.assign({ t: 'ব্যাকটেরিয়ার অপকারিতা', k: ['mind', 'int'], cap: 'রোগ, খাদ্য নষ্ট, মাটির উর্বরতা হ্রাস ও ওষুধ-প্রতিরোধ। পাতায় চাপ দাও।' }, BK.mind({
  t: 'ক্ষতিকর ব্যাকটেরিয়া', d: 'অল্প কিছু প্রজাতি, কিন্তু বড় ক্ষতি।',
  c: [
    { t: 'মানুষের রোগ', d: 'কলেরা, টাইফয়েড, যক্ষ্মা, নিউমোনিয়া।', c: [{ t: 'বিষ', d: 'এক্সোটক্সিন (ধনুষ্টংকার, বটুলিজম) ও এন্ডোটক্সিন (LPS)।' }] },
    { t: 'পশুর রোগ', d: 'গবাদিপশুর তড়কা (অ্যানথ্রাক্স), বাদলা (ব্ল্যাক কোয়ার্টার), যক্ষ্মা।' },
    { t: 'ফসলের রোগ', d: 'উদ্ভিদের ক্ষতি।', c: [{ t: 'ধানের পাতা ঝলসানো', d: 'Xanthomonas oryzae।' }, { t: 'লেবুর ক্যাংকার', d: 'Xanthomonas citri।' }, { t: 'টমেটো ও বেগুনের ঢলে পড়া', d: 'Ralstonia solanacearum।' }, { t: 'আলু ও সবজির নরম পচা', d: 'Erwinia।' }] },
    { t: 'খাদ্য নষ্ট ও বিষক্রিয়া', d: 'Clostridium botulinum (বটুলিজম), Salmonella, Staphylococcus aureus।' },
    { t: 'মাটির উর্বরতা হ্রাস', d: 'ডিনাইট্রিফিকেশন — Pseudomonas ও Thiobacillus denitrificans নাইট্রেটকে N₂ গ্যাসে পরিণত করে।' },
    { t: 'অ্যান্টিবায়োটিক প্রতিরোধ', d: 'অপ্রয়োজনে বা অসম্পূর্ণ কোর্সে অ্যান্টিবায়োটিক সেবনে প্রতিরোধী "সুপারবাগ" তৈরি হয়।' }
  ]
}));
V.bacDiseases = Object.assign({ t: 'ব্যাকটেরিয়াজনিত রোগ', k: ['tree', 'int'], cap: 'রোগ, জীবাণু, সংক্রমণ ও প্রতিরোধ। শাখায় চাপ দাও।' }, BK.tree({
  t: 'ব্যাকটেরিয়াজনিত রোগ', d: 'বাংলাদেশে গুরুত্বপূর্ণগুলো।',
  c: [
    { t: 'পানি ও খাদ্যবাহিত', c: [{ t: 'কলেরা', d: 'Vibrio cholerae; চালধোয়া পানির মতো পাতলা পায়খানা; খাবার স্যালাইন (ORS) — ঢাকার আইসিডিডিআর,বি এর গবেষণা বিশ্বজুড়ে কোটি প্রাণ বাঁচিয়েছে।' }, { t: 'টাইফয়েড', d: 'Salmonella Typhi; টানা জ্বর; বিশুদ্ধ পানি, টিকা।' }, { t: 'আমাশয়', d: 'Shigella; রক্ত-আমযুক্ত পায়খানা।' }] },
    { t: 'বায়ুবাহিত', c: [{ t: 'যক্ষ্মা', d: 'Mycobacterium tuberculosis (কখ, 1882); দীর্ঘ কাশি; BCG টিকা ও DOTS চিকিৎসা।' }, { t: 'নিউমোনিয়া', d: 'Streptococcus pneumoniae; শিশুমৃত্যুর বড় কারণ; PCV টিকা।' }, { t: 'ডিপথেরিয়া ও হুপিং কাশি', d: 'Corynebacterium diphtheriae ও Bordetella pertussis; পেন্টাভ্যালেন্ট টিকায় প্রতিরোধ।' }] },
    { t: 'ক্ষত ও স্পর্শে', c: [{ t: 'ধনুষ্টংকার', d: 'Clostridium tetani; মাটি ও মরিচা ধরা লোহায় কাটা থেকে; TT টিকা।' }, { t: 'কুষ্ঠ', d: 'Mycobacterium leprae (হ্যানসেন, 1873); দীর্ঘ সংস্পর্শে; MDT চিকিৎসায় নিরাময়যোগ্য।' }] },
    { t: 'প্রাণী থেকে', c: [{ t: 'অ্যানথ্রাক্স (তড়কা)', d: 'Bacillus anthracis; আক্রান্ত পশুর মাংস ও চামড়া থেকে।' }, { t: 'প্লেগ', d: 'Yersinia pestis; ইঁদুরের মাছির মাধ্যমে।' }] }
  ]
}, { colW: 128 }));
})();
