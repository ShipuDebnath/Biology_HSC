/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৩.২ অ্যামিনো অ্যাসিড ও প্রোটিন
   aminoAcid      : সাধারণ গঠন + R গ্রুপ বদলাও + pH স্লাইডার → চার্জ, pI, তড়িৎক্ষেত্রে চলন (অ্যানিমেটেড)
   aaClass        : অ্যামিনো অ্যাসিডের শ্রেণিবিভাগ — গাছ
   peptideBond    : পেপটাইড বন্ধন — ডাইপেপটাইড থেকে ট্রাইপেপটাইড (ধাপে ধাপে)
   proteinLevels  : প্রোটিনের চার স্তর ও ডিন্যাচারেশন — শিকল ভাঁজ হওয়ার অ্যানিমেশন
   proteinDenature: একই, ডিন্যাচারেশন দিয়ে শুরু
   proteinClass   : প্রোটিনের শ্রেণিবিভাগ — গাছ
   cmpFibGlob     : তন্তুময় ও গোলাকার প্রোটিন — পার্থক্য
   proteinRoles   : প্রোটিনের ভূমিকা — মাইন্ড ম্যাপ
   proteinFood    : খাদ্যে প্রোটিন (g/100 g, কাঁচা, আনুমানিক) — স্তম্ভ
   pKa মান Lehninger থেকে; pI Python দিয়ে যাচাই: Gly 5.97, Ala 6.01, Ser 5.68, Cys 5.07, Phe 5.48, Lys 9.74, Glu 3.22
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* [নাম, R লেখা, α-COOH pKa, α-NH₃⁺ pKa, পার্শ্বশিকল: null | ['a'|'b', pKa, চার্জিত লেখা, নিরপেক্ষ লেখা], ধরন] */
const AA = {
  gly: ['গ্লাইসিন (Gly)', 'H', 2.34, 9.60, null, 'সরলতম — R = H; একমাত্র আলোক-নিষ্ক্রিয় অ্যামিনো অ্যাসিড (α-কার্বনে দুটি H)।'],
  ala: ['অ্যালানিন (Ala)', 'CH₃', 2.34, 9.69, null, 'অপোলার, পানিবিদ্বেষী R গ্রুপ।'],
  ser: ['সেরিন (Ser)', 'CH₂–OH', 2.21, 9.15, null, 'পোলার, চার্জহীন; –OH গ্রুপে ফসফেট যুক্ত হয়ে এনজাইম নিয়ন্ত্রিত হয়।'],
  cys: ['সিস্টেইন (Cys)', 'CH₂–SH', 1.96, 10.28, ['a', 8.18, 'CH₂–S⁻', 'CH₂–SH'], 'সালফারযুক্ত; দুটি সিস্টেইনের –SH মিলে ডাইসালফাইড (S–S) সেতু তৈরি করে।'],
  phe: ['ফিনাইলঅ্যালানিন (Phe)', 'CH₂–C₆H₅', 1.83, 9.13, null, 'অ্যারোমেটিক বলয়যুক্ত; অত্যাবশ্যকীয়।'],
  lys: ['লাইসিন (Lys)', '(CH₂)₄–NH₃⁺', 2.18, 8.95, ['b', 10.53, '(CH₂)₄–NH₃⁺', '(CH₂)₄–NH₂'], 'ক্ষারীয় — পার্শ্বশিকলে বাড়তি অ্যামিনো গ্রুপ; অত্যাবশ্যকীয়; চালে কম থাকে।'],
  glu: ['গ্লুটামিক অ্যাসিড (Glu)', '(CH₂)₂–COO⁻', 2.19, 9.67, ['a', 4.25, '(CH₂)₂–COO⁻', '(CH₂)₂–COOH'], 'অম্লীয় — পার্শ্বশিকলে বাড়তি কার্বক্সিল গ্রুপ; এর লবণ মনোসোডিয়াম গ্লুটামেট (টেস্টিং সল্ট)।']
};
const frac = (ph, pk) => 1 / (1 + Math.pow(10, ph - pk));   /* প্রোটনযুক্ত অংশের ভগ্নাংশ */
const charge = (a, ph) => {
  let z = frac(ph, a[3]) - (1 - frac(ph, a[2]));
  if (a[4]) z += a[4][0] === 'b' ? frac(ph, a[4][1]) : -(1 - frac(ph, a[4][1]));
  return z;
};
const pI = a => { let lo = 0, hi = 14; for (let i = 0; i < 50; i++) { const m = (lo + hi) / 2; if (charge(a, m) > 0) lo = m; else hi = m; } return (lo + hi) / 2; };
V.aminoAcid = {
  t: 'অ্যামিনো অ্যাসিডের গঠন ও pH এর প্রভাব', k: ['2d', 'anim', 'int'],
  cap: 'α-কার্বনের চার পাশে চারটি গ্রুপ: অ্যামিনো (–NH₂), কার্বক্সিল (–COOH), H এবং R। R বদলালেই অ্যামিনো অ্যাসিড বদলায়। pH স্লাইডার সরাও: অম্লে অণু ধনাত্মক হয়ে ক্যাথোডের দিকে, ক্ষারে ঋণাত্মক হয়ে অ্যানোডের দিকে সরে; আইসোইলেকট্রিক বিন্দুতে (pI) মোট চার্জ শূন্য — অণু স্থির থাকে (জুইটারআয়ন)।',
  html: () => `<div class="fk-row">${X.seg('aa', Object.keys(AA).map(k => [k, AA[k][0].split(' (')[0]]), 'gly')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.sl('ph', 'pH', 1, 13, .1, 6, '')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 270, CX = 180, CY = 118;
    let key = 'gly', ph = 6, C, svg, mol, dotG, dots = [], drift = 0, lastInfo = '';
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'অ্যামিনো অ্যাসিড' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      /* তড়িৎক্ষেত্রের পাত */
      const Rn = BK.ramp(4), Rp = BK.ramp(0);
      E('rect', { x: 8, y: 196, width: 26, height: 64, rx: 6, fill: FK.alpha(Rp.c, .25), stroke: Rp.c }, svg); T(svg, 21, 233, '−', { fs: 20, a: 'middle', w: 700, c: Rp.ink });
      E('rect', { x: W - 34, y: 196, width: 26, height: 64, rx: 6, fill: FK.alpha(Rn.c, .25), stroke: Rn.c }, svg); T(svg, W - 21, 233, '+', { fs: 20, a: 'middle', w: 700, c: Rn.ink });
      T(svg, 40, 210, 'ক্যাথোড', { fs: 10, w: 560, c: C.mu }); T(svg, W - 40, 210, 'অ্যানোড', { fs: 10, a: 'end', w: 560, c: C.mu });
      E('path', { d: `M40 252H${W - 40}`, stroke: C.ln, 'stroke-width': 1.2, 'stroke-dasharray': '3 4' }, svg);
      mol = E('g', {}, svg); dotG = E('g', {}, svg);
      dots = Array.from({ length: 5 }, (_, i) => ({ el: E('circle', { r: 6, cy: 236, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk }, dotG), x: CX - 40 + i * 20 }));
      paint();
    };
    const paint = () => {
      if (!mol) return;
      const a = AA[key], Ra = BK.ramp(5), Rc = BK.ramp(4), Rr = BK.ramp(2), Rh = BK.ramp(9);
      mol.innerHTML = '';
      const nh = ph < a[3] ? 'H₃N⁺' : 'H₂N', co = ph < a[2] ? 'COOH' : 'COO⁻';
      const R = a[4] ? (a[4][0] === 'b' ? (ph < a[4][1] ? a[4][2] : a[4][3]) : (ph < a[4][1] ? a[4][3] : a[4][2])) : a[1];
      const bond = (x1, y1, x2, y2) => E('path', { d: `M${x1} ${y1}L${x2} ${y2}`, stroke: C.fg, 'stroke-width': 2, opacity: .8 }, mol);
      bond(CX - 14, CY, CX - 52, CY); bond(CX + 14, CY, CX + 52, CY); bond(CX, CY - 14, CX, CY - 36); bond(CX, CY + 14, CX, CY + 40);
      E('circle', { cx: CX, cy: CY, r: 15, fill: FK.alpha(Rh.c, .2), stroke: Rh.c, 'stroke-width': 2 }, mol);
      T(mol, CX, CY + 5, 'C', { fs: 14, a: 'middle', w: 650 }); T(mol, CX + 15, CY - 12, 'α', { fs: 11, w: 600, c: Rh.ink });
      /* অ্যামিনো গ্রুপ */
      E('rect', { x: CX - 112, y: CY - 16, width: 58, height: 32, rx: 10, fill: FK.alpha(Ra.c, .18), stroke: Ra.c }, mol);
      T(mol, CX - 83, CY + 5, nh, { fs: 14, a: 'middle', w: 650, c: Ra.ink });
      T(mol, CX - 83, CY + 34, 'অ্যামিনো', { fs: 10, a: 'middle', w: 520, c: C.mu });
      /* কার্বক্সিল */
      E('rect', { x: CX + 54, y: CY - 16, width: 66, height: 32, rx: 10, fill: FK.alpha(Rc.c, .18), stroke: Rc.c }, mol);
      T(mol, CX + 87, CY + 5, co, { fs: 14, a: 'middle', w: 650, c: Rc.ink });
      T(mol, CX + 87, CY + 34, 'কার্বক্সিল', { fs: 10, a: 'middle', w: 520, c: C.mu });
      T(mol, CX, CY - 42, 'H', { fs: 14, a: 'middle', w: 600 });
      /* R গ্রুপ */
      const rw = Math.max(46, R.length * 8.4 + 16);
      E('rect', { x: CX - rw / 2, y: CY + 42, width: rw, height: 30, rx: 10, fill: FK.alpha(Rr.c, .22), stroke: Rr.c, 'stroke-width': 1.6 }, mol);
      T(mol, CX, CY + 62, R, { fs: 13, a: 'middle', w: 650, c: Rr.ink });
      T(mol, CX + rw / 2 + 6, CY + 62, 'R গ্রুপ', { fs: 10, w: 520, c: C.mu });
      const z = charge(a, ph), p = pI(a);
      T(mol, 12, 22, a[0], { fs: 13, w: 650 });
      T(mol, 12, 40, `pI = ${p.toFixed(2)}`, { fs: 11.5, w: 560, c: C.mu });
      T(mol, W - 12, 22, `মোট চার্জ: ${z >= 0 ? '+' : '−'}${Math.abs(z).toFixed(2)}`, { fs: 12.5, a: 'end', w: 650, c: Math.abs(z) < .05 ? C.ok : z > 0 ? Ra.ink : Rc.ink });
      const st = Math.abs(ph - p) < .25 ? 'আইসোইলেকট্রিক বিন্দু — জুইটারআয়ন, মোট চার্জ শূন্য, তড়িৎক্ষেত্রে স্থির' : ph < p ? 'pH < pI — অণু ধনাত্মক, ক্যাথোডের (−) দিকে সরে' : 'pH > pI — অণু ঋণাত্মক, অ্যানোডের (+) দিকে সরে';
      const inf = `<b>${a[0]}</b> — ${a[5]}<div class="small">pH ${ph.toFixed(1)}: ${st}।</div>`;
      if (inf !== lastInfo) { $('info').innerHTML = inf; lastInfo = inf; }
    };
    const step = dt => {
      const z = charge(AA[key], ph);
      /* ধনাত্মক → বাঁয়ে (ক্যাথোড), ঋণাত্মক → ডানে */
      drift += -z * dt * 60;
      dots.forEach((d, i) => {
        let x = d.x + drift + 3 * Math.sin(Date.now() / 300 + i);
        const span = W - 100; x = 50 + ((((x - 50) % span) + span) % span);
        d.el.setAttribute('cx', x.toFixed(1));
      });
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    FK.bindSl(root, 'ph', v => { ph = v; paint(); step(0); }, '', 1);
    X.onSeg(root, 'aa', v => { key = v; paint(); });
    const unT = FK.onTheme(base); base(); step(0);
    return () => { A.stop(); unT(); };
  }
};

V.aaClass = Object.assign({
  t: 'অ্যামিনো অ্যাসিডের শ্রেণিবিভাগ', k: ['tree', 'int'],
  cap: 'R গ্রুপের রাসায়নিক প্রকৃতি এবং পুষ্টির প্রয়োজন — দুই ভিত্তিতে ভাগ। শাখায় চাপ দাও।'
}, BK.tree({
  t: '20টি অ্যামিনো অ্যাসিড', en: 'Standard amino acids', d: 'প্রোটিনে জিন-নির্দেশিত 20টি L-α-অ্যামিনো অ্যাসিড।',
  c: [
    { t: 'R গ্রুপ অনুযায়ী', d: 'পার্শ্বশিকলের পোলারিটি ও চার্জ।', c: [
      { t: 'অপোলার (পানিবিদ্বেষী)', d: 'গ্লাইসিন, অ্যালানিন, ভ্যালিন, লিউসিন, আইসোলিউসিন, মিথিওনিন, প্রোলিন — প্রোটিনের ভেতরের দিকে থাকে।' },
      { t: 'অ্যারোমেটিক', d: 'ফিনাইলঅ্যালানিন, টাইরোসিন, ট্রিপটোফ্যান — বলয়যুক্ত; 280 nm এ অতিবেগুনি আলো শোষণ করে।' },
      { t: 'পোলার, চার্জহীন', d: 'সেরিন, থ্রিওনিন, সিস্টেইন, অ্যাসপারাজিন, গ্লুটামিন।' },
      { t: 'অম্লীয় (ঋণাত্মক)', d: 'অ্যাসপারটিক অ্যাসিড, গ্লুটামিক অ্যাসিড — বাড়তি –COOH।' },
      { t: 'ক্ষারীয় (ধনাত্মক)', d: 'লাইসিন, আর্জিনিন, হিস্টিডিন — বাড়তি অ্যামিনো বা ক্ষারীয় গ্রুপ।' }] },
    { t: 'পুষ্টি অনুযায়ী', d: 'দেহ তৈরি করতে পারে কি না।', c: [
      { t: 'অত্যাবশ্যকীয় (9)', d: 'ফিনাইলঅ্যালানিন, ভ্যালিন, থ্রিওনিন, ট্রিপটোফ্যান, আইসোলিউসিন, মিথিওনিন, হিস্টিডিন, লিউসিন, লাইসিন — খাদ্য থেকে নিতেই হবে।' },
      { t: 'শর্তসাপেক্ষ', d: 'আর্জিনিন — শিশুর দ্রুত বৃদ্ধি ও অসুস্থতায় দেহের তৈরি যথেষ্ট নয়; টাইরোসিন, সিস্টেইন।' },
      { t: 'অনাবশ্যকীয়', d: 'অ্যালানিন, অ্যাসপারটিক ও গ্লুটামিক অ্যাসিড, সেরিন ইত্যাদি — দেহ নিজেই তৈরি করে।' }] },
    { t: 'বিশেষ গ্রুপ অনুযায়ী', d: 'পার্শ্বশিকলের বিশেষ পরমাণু।', c: [
      { t: 'সালফারযুক্ত', d: 'সিস্টেইন, মিথিওনিন।' }, { t: 'ইমিনো অ্যাসিড', d: 'প্রোলিন — অ্যামিনো গ্রুপটি বলয়ের অংশ; নিনহাইড্রিনে হলুদ।' }, { t: 'হাইড্রক্সিলযুক্ত', d: 'সেরিন, থ্রিওনিন, টাইরোসিন।' }] }
  ]
}, { colW: 130 }));

V.proteinClass = Object.assign({
  t: 'প্রোটিনের শ্রেণিবিভাগ', k: ['tree', 'int'],
  cap: 'গঠন-উপাদান, আকৃতি ও কাজ — তিন ভিত্তিতে ভাগ। শাখায় চাপ দিলে উদাহরণ।'
}, BK.tree({
  t: 'প্রোটিন', en: 'Protein', d: 'পেপটাইড বন্ধনে যুক্ত অ্যামিনো অ্যাসিডের পলিমার।',
  c: [
    { t: 'উপাদান অনুযায়ী', c: [
      { t: 'সরল প্রোটিন', d: 'আর্দ্রবিশ্লেষণে কেবল অ্যামিনো অ্যাসিড: অ্যালবুমিন (ডিমের সাদা অংশ, রক্তরস), গ্লোবিউলিন, গ্লুটেলিন (গমের গ্লুটেনিন), প্রোলামিন (জিন), হিস্টোন, প্রোটামিন, স্ক্লেরোপ্রোটিন (কেরাটিন, কোলাজেন)।' },
      { t: 'যুগ্ম প্রোটিন', d: 'প্রোটিন + অপ্রোটিন অংশ (প্রোস্থেটিক গ্রুপ): গ্লাইকোপ্রোটিন (মিউসিন), লাইপোপ্রোটিন (LDL, HDL), নিউক্লিওপ্রোটিন (ক্রোমাটিন), ক্রোমোপ্রোটিন (হিমোগ্লোবিন), ফসফোপ্রোটিন (কেসিন), মেটালোপ্রোটিন (ফেরিটিন)।' },
      { t: 'উদ্ভূত প্রোটিন', d: 'প্রোটিনের আংশিক ভাঙনে তৈরি: প্রাথমিক — প্রোটিয়ান, মেটাপ্রোটিন, জমাট প্রোটিন; গৌণ — প্রোটিওজ, পেপটোন, পেপটাইড।' }] },
    { t: 'আকৃতি অনুযায়ী', c: [
      { t: 'তন্তুময় (ফাইব্রাস)', d: 'লম্বা, সুতার মতো, পানিতে অদ্রবণীয়, গাঠনিক: কেরাটিন, কোলাজেন, ইলাস্টিন, ফাইব্রোইন (রেশম), মায়োসিন।' },
      { t: 'গোলাকার (গ্লোবিউলার)', d: 'ভাঁজ হয়ে গোল, পানিতে দ্রবণীয়, সক্রিয়: এনজাইম, হিমোগ্লোবিন, অ্যালবুমিন, ইনসুলিন, অ্যান্টিবডি।' }] },
    { t: 'কাজ অনুযায়ী', c: [
      { t: 'এনজাইম', d: 'অ্যামাইলেজ, পেপসিন, রুবিস্কো।' }, { t: 'গাঠনিক', d: 'কোলাজেন, কেরাটিন।' }, { t: 'পরিবহন', d: 'হিমোগ্লোবিন, ঝিল্লির বাহক প্রোটিন।' }, { t: 'হরমোন', d: 'ইনসুলিন, গ্রোথ হরমোন।' }, { t: 'প্রতিরক্ষা', d: 'অ্যান্টিবডি, ফাইব্রিনোজেন।' }, { t: 'সংকোচনশীল', d: 'অ্যাকটিন, মায়োসিন।' }, { t: 'সঞ্চয়', d: 'কেসিন, ডিমের অ্যালবুমিন, ফেরিটিন।' }] }
  ]
}, { colW: 128 }));

V.cmpFibGlob = Object.assign({ t: 'তন্তুময় ও গোলাকার প্রোটিনের পার্থক্য', k: ['cmp', 'int'], cap: 'সারণি দেখো, তারপর "যাচাই খেলা"।' }, BK.compare({
  a: 'তন্তুময় প্রোটিন', b: 'গোলাকার প্রোটিন',
  rows: [
    ['আকৃতি', 'লম্বা, সুতা বা পাতের মতো', 'ভাঁজ হয়ে গোলাকার বা ডিম্বাকার'],
    ['প্রধান গঠনস্তর', 'মূলত সেকেন্ডারি (α-হেলিক্স, β-শিট, ত্রি-সূত্রক)', 'টারশিয়ারি ও কোয়াটারনারি'],
    ['পানিতে', 'অদ্রবণীয়', 'দ্রবণীয় (কলয়েড)'],
    ['তাপ ও pH এ', 'তুলনামূলক স্থিতিশীল', 'সহজে ডিন্যাচার হয়'],
    ['কাজ', 'গাঠনিক — দৃঢ়তা ও স্থিতিস্থাপকতা', 'বিপাকীয় — এনজাইম, পরিবহন, হরমোন, প্রতিরক্ষা'],
    ['উদাহরণ', 'কেরাটিন, কোলাজেন, ইলাস্টিন, রেশমের ফাইব্রোইন', 'হিমোগ্লোবিন, অ্যালবুমিন, ইনসুলিন, এনজাইম']
  ]
}));

V.proteinRoles = Object.assign({
  t: 'জীবদেহে প্রোটিনের ভূমিকা', k: ['mind', 'int'],
  cap: 'কোষের প্রায় প্রতিটি কাজের পেছনে কোনো না কোনো প্রোটিন। পাতায় চাপ দাও।'
}, BK.mind({
  t: 'প্রোটিনের কাজ', d: 'কোষের "কর্মী" অণু।',
  c: [
    { t: 'অনুঘটন', d: 'প্রায় সব এনজাইম প্রোটিন।', c: [{ t: 'অ্যামাইলেজ', d: 'স্টার্চ ভাঙে।' }, { t: 'রুবিস্কো', d: 'CO₂ সংবন্ধন; পৃথিবীর সবচেয়ে বেশি প্রোটিন।' }] },
    { t: 'গঠন', d: 'দৃঢ়তা ও স্থিতিস্থাপকতা।', c: [{ t: 'কোলাজেন', d: 'হাড়, চামড়া, কণ্ডরা; স্তন্যপায়ীর মোট প্রোটিনের প্রায় এক-চতুর্থাংশ।' }, { t: 'কেরাটিন', d: 'চুল, নখ, শিং, পালক।' }] },
    { t: 'পরিবহন ও সঞ্চয়', d: 'অণু বহন ও জমা রাখা।', c: [{ t: 'হিমোগ্লোবিন', d: 'O₂ পরিবহন।' }, { t: 'ফেরিটিন', d: 'যকৃতে লোহা জমা।' }, { t: 'কেসিন', d: 'দুধের প্রোটিন।' }] },
    { t: 'নিয়ন্ত্রণ ও সংকেত', d: 'হরমোন ও গ্রাহক।', c: [{ t: 'ইনসুলিন', d: 'রক্তশর্করা কমায় — 51টি অ্যামিনো অ্যাসিড।' }, { t: 'গ্রাহক প্রোটিন', d: 'কোষঝিল্লিতে সংকেত গ্রহণ।' }] },
    { t: 'প্রতিরক্ষা', d: 'রোগ প্রতিরোধ ও রক্ত জমাট।', c: [{ t: 'অ্যান্টিবডি', d: 'জীবাণুর অ্যান্টিজেন চেনে।' }, { t: 'ফাইব্রিনোজেন', d: 'রক্ত জমাট বাঁধায়।' }] },
    { t: 'চলন ও শক্তি', d: 'সংকোচন ও শেষ ভরসার জ্বালানি।', c: [{ t: 'অ্যাকটিন-মায়োসিন', d: 'পেশি সংকোচন।' }, { t: 'শক্তি', d: 'প্রতি গ্রামে প্রায় 4 kcal — অনাহারে ব্যবহৃত।' }] }
  ]
}));

V.proteinFood = Object.assign({
  t: 'খাদ্যে প্রোটিনের পরিমাণ', k: ['graph', 'int'],
  cap: 'প্রতি 100 g কাঁচা খাদ্যে প্রোটিন (আনুমানিক; জাত ও প্রস্তুতভেদে কম-বেশি হয়)। পরিমাণের সাথে মানও জরুরি — ডালে মিথিওনিন কম, চালে লাইসিন কম; তাই ভাত-ডাল বা খিচুড়ি একসাথে খেলে একে অন্যের ঘাটতি পূরণ করে। স্তম্ভে চাপ দাও।'
}, BK.bars({
  title: 'প্রোটিন (g / 100 g)', unit: ' g', d: 0, labW: 116, max: 40,
  items: [
    ['সয়াবিন', 36, null, 'উদ্ভিজ্জ উৎসের মধ্যে সবচেয়ে বেশি; প্রায় সম্পূর্ণ প্রোটিন।'],
    ['মসুর ডাল', 25, null, 'লাইসিন বেশি, মিথিওনিন কম।'],
    ['চিনাবাদাম', 26, null, 'প্রোটিনের সাথে প্রচুর তেলও।'],
    ['মুরগির মাংস', 22, null, 'প্রাণিজ, সম্পূর্ণ প্রোটিন।'],
    ['রুই মাছ', 17, null, 'সহজপাচ্য সম্পূর্ণ প্রোটিন।'],
    ['ডিম', 13, null, 'জৈবিক মূল্য সবচেয়ে বেশিগুলোর একটি — আদর্শ মানদণ্ড হিসেবে ধরা হয়।'],
    ['চাল', 7, null, 'পরিমাণে কম, কিন্তু বেশি খাওয়া হয় বলে মোট প্রোটিনের বড় উৎস; লাইসিন কম।'],
    ['গরুর দুধ', 3, null, 'প্রধানত কেসিন; ক্যালসিয়ামেরও ভালো উৎস।']
  ]
}));
})();

/* ───────── পেপটাইড বন্ধন ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const lerp = (a, b, t) => a + (b - a) * t;
const ABBR = ['Gly', 'Ala', 'Ser'], RS = ['H', 'CH₃', 'CH₂OH'];
V.peptideBond = Object.assign({
  t: 'পেপটাইড বন্ধন — ডাইপেপটাইড থেকে ট্রাইপেপটাইড', k: ['2d', 'anim', 'int'],
  cap: 'একটি অ্যামিনো অ্যাসিডের –COOH এর OH এবং পরেরটির –NH₂ এর একটি H মিলে এক অণু পানি বের হয়; C ও N এর মধ্যে তৈরি হয় –CO–NH– পেপটাইড বন্ধন। শিকলের এক প্রান্তে মুক্ত –NH₂ (N-প্রান্ত), অন্য প্রান্তে মুক্ত –COOH (C-প্রান্ত)। n টি অ্যামিনো অ্যাসিড → n − 1 টি বন্ধন ও n − 1 অণু পানি।'
}, BK.steps({
  W: 380, H: 220, label: 'পেপটাইড বন্ধন', dur: 2.6,
  stages: [
    { t: 'দুটি অ্যামিনো অ্যাসিড', en: 'Two amino acids', d: 'গ্লাইসিন ও অ্যালানিন — প্রত্যেকের একটি –NH₂ ও একটি –COOH।' },
    { t: 'পানি বের হয়', en: 'Condensation', d: 'গ্লাইসিনের –COOH থেকে OH, অ্যালানিনের –NH₂ থেকে H — মিলে H₂O।' },
    { t: 'ডাইপেপটাইড', en: 'Dipeptide', d: 'C–N পেপটাইড বন্ধন (রঙিন)। এর আংশিক দ্বিবন্ধন ধর্ম আছে, তাই বন্ধনটি ঘোরে না — সমতলীয়।' },
    { t: 'ট্রাইপেপটাইড', en: 'Tripeptide', d: 'সেরিন যুক্ত হলো — 3টি অ্যামিনো অ্যাসিড, 2টি পেপটাইড বন্ধন, 2 অণু পানি। রাইবোজোমে শিকল সবসময় C-প্রান্তে বাড়ে।' }
  ],
  draw(g, C, s, u) {
    const Rb = BK.ramp(4), Rw = BK.ramp(5), Rr = BK.ramp(2), Rn = BK.ramp(7);
    /* প্রতিটি অবশিষ্টাংশের (residue) কাঠামো: N — Cα — C(=O) ; প্রস্থ 112 */
    const join1 = s >= 2 ? 1 : s === 1 ? u : 0, join2 = s >= 3 ? u : 0, show3 = s >= 3 ? Math.min(1, u * 2) : 0;
    const W0 = 104, gap1 = lerp(36, 0, join1), gap2 = lerp(36, 0, join2);
    const n3 = s >= 3, total = W0 * (n3 ? 3 : 2) + gap1 + (n3 ? gap2 : 0);
    const x0 = 190 - total / 2 + 20, y = 108;
    const xs = [x0, x0 + W0 + gap1, x0 + 2 * W0 + gap1 + gap2];
    const res = (i, x, op) => {
      const gg = E('g', { opacity: op }, g);
      const nx = x, ax = x + 38, cx = x + 74;
      /* N */
      const joined = i === 1 ? join1 >= 1 : i === 2 ? join2 >= 1 : false;
      const rightFree = (i === 1 && !n3) || i === 2 || (i === 0 && join1 < 1) || (i === 1 && n3 && join2 < 1);
      T(gg, nx, y + 5, i === 0 ? 'H₂N' : joined ? 'N' : 'HN', { fs: 13, a: 'middle', w: 650, c: Rn.ink });
      if (joined) T(gg, nx, y + 26, 'H', { fs: 12, a: 'middle', w: 600 });
      E('path', { d: `M${nx + 14} ${y}L${ax - 10} ${y}M${ax + 10} ${y}L${cx - 8} ${y}`, stroke: C.fg, 'stroke-width': 2 }, gg);
      T(gg, ax, y + 5, 'C', { fs: 13, a: 'middle', w: 650 });
      T(gg, ax, y - 22, 'H', { fs: 12, a: 'middle', w: 600 }); E('path', { d: `M${ax} ${y - 8}V${y - 16}`, stroke: C.fg, 'stroke-width': 1.6 }, gg);
      E('path', { d: `M${ax} ${y + 9}V${y + 22}`, stroke: C.fg, 'stroke-width': 1.6 }, gg);
      const rw = RS[i].length * 8 + 14;
      E('rect', { x: ax - rw / 2, y: y + 24, width: rw, height: 22, rx: 8, fill: FK.alpha(Rr.c, .22), stroke: Rr.c }, gg);
      T(gg, ax, y + 39, RS[i], { fs: 11.5, a: 'middle', w: 650, c: Rr.ink });
      T(gg, ax, y + 62, ABBR[i], { fs: 10.5, a: 'middle', w: 600, c: C.mu });
      T(gg, cx, y + 5, 'C', { fs: 13, a: 'middle', w: 650 });
      E('path', { d: `M${cx - 2} ${y - 8}V${y - 18}M${cx + 2} ${y - 8}V${y - 18}`, stroke: C.fg, 'stroke-width': 1.5 }, gg);
      T(gg, cx, y - 22, 'O', { fs: 12.5, a: 'middle', w: 650, c: BK.ramp(4).ink });
      if (rightFree) { E('path', { d: `M${cx + 8} ${y}L${cx + 16} ${y}`, stroke: C.fg, 'stroke-width': 2 }, gg); }
      return { nx, cx };
    };
    const r0 = res(0, xs[0], 1), r1 = res(1, xs[1], 1); let r2 = null;
    if (n3) r2 = res(2, xs[2], show3);
    /* –OH ও H, পানি */
    const water = (rA, rB, k, sOn) => {
      if (k < 1) {
        const ohx = lerp(rA.cx + 30, (rA.cx + rB.nx) / 2 - 6, k), ohy = lerp(y + 5, y + 76, k);
        const hx = lerp(rB.nx - 2, (rA.cx + rB.nx) / 2 + 12, k), hy = lerp(y + 26, y + 76, k);
        T(g, ohx, ohy, 'OH', { fs: 12.5, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${1 - k * .3}` });
        T(g, hx, hy, 'H', { fs: 12.5, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${1 - k * .3}` });
      }
      if (k > .55) {
        const mx = (rA.cx + rB.nx) / 2, fl = Math.min(1, (k - .55) / .45);
        E('circle', { cx: mx + 3, cy: y + 86 + fl * 10, r: 17, fill: FK.alpha(Rw.c, .18 * fl), stroke: FK.alpha(Rw.c, .7 * fl) }, g);
        T(g, mx + 3, y + 91 + fl * 10, 'H₂O', { fs: 11.5, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${fl}` });
      }
      if (k >= .98 || sOn) {
        E('path', { d: `M${rA.cx + 8} ${y}L${rB.nx - 14} ${y}`, stroke: Rb.c, 'stroke-width': 3.2 }, g);
        E('rect', { x: rA.cx - 14, y: y - 36, width: rB.nx - rA.cx + 28, height: 70, rx: 12, fill: 'none', stroke: Rb.c, 'stroke-width': 1.4, 'stroke-dasharray': '4 3' }, g);
      }
    };
    water(r0, r1, s === 0 ? 0 : s === 1 ? u : 1, s >= 2);
    if (s >= 3) water(r1, r2, u, false);
    /* প্রান্তের লেবেল */
    if (s >= 2) {
      T(g, xs[0] - 4, 34, 'N-প্রান্ত', { fs: 11, a: 'middle', w: 650, c: Rn.ink });
      const last = n3 ? r2 : r1;
      T(g, last.cx + 30, 34, 'C-প্রান্ত', { fs: 11, a: 'middle', w: 650, c: BK.ramp(4).ink, st: `opacity:${n3 ? show3 : 1}` });
    }
    /* মুক্ত প্রান্তের OH */
    const tail = n3 ? r2 : r1;
    T(g, tail.cx + 30, y + 5, 'OH', { fs: 12.5, a: 'middle', w: 650, c: C.fg, st: `opacity:${n3 ? show3 : 1}` });
    if (s >= 2) T(g, 190, 22, s === 2 ? '1টি পেপটাইড বন্ধন' : '2টি পেপটাইড বন্ধন', { fs: 12.5, a: 'middle', w: 650, c: Rb.ink });
  }
}));
})();

/* ───────── প্রোটিনের চার স্তর ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const N = 24, lerp = (a, b, t) => a + (b - a) * t;
/* অবশিষ্টাংশের ধরন: 0 অপোলার, 1 পোলার, 2 চার্জিত, 3 সিস্টেইন */
const TY = [1, 0, 2, 0, 1, 3, 0, 0, 2, 1, 0, 1, 0, 2, 1, 0, 0, 1, 3, 0, 2, 1, 0, 1];
const P0 = [...Array(N)].map((_, i) => [26 + i * 13.5, 130]);
const P1 = [...Array(N)].map((_, i) => i < 12 ? [40 + i * 10, 130 + 30 * Math.sin(i * 1.745)] : i < 18 ? [196 + (i - 12) * 22, 98 + (i % 2) * 6] : [306 - (i - 18) * 22, 162 + (i % 2) * 6]);
/* ভাঁজ করা গোলক — অপোলার অংশ ভেতরে */
const P2 = (() => {
  const out = []; let inI = 0, outI = 0; const nin = TY.filter(t => t === 0).length, nout = N - nin;
  TY.forEach(t => {
    if (t === 0) { const a = inI++ / nin * Math.PI * 2; out.push([180 + 26 * Math.cos(a * 1.0 + .3), 130 + 22 * Math.sin(a)]); }
    else { const a = outI++ / nout * Math.PI * 2; out.push([180 + 66 * Math.cos(a), 130 + 54 * Math.sin(a)]); }
  });
  return out;
})();
const P4 = [...Array(N)].map((_, i) => [28 + i * 13.2, 130 + 34 * Math.sin(i * 1.3) + 14 * Math.sin(i * 3.1)]);
const ST = [
  { t: 'প্রাথমিক গঠন', en: 'Primary', d: 'অ্যামিনো অ্যাসিডের ক্রম — পেপটাইড বন্ধনে যুক্ত একটি সরল শিকল। এই ক্রমই পরের সব স্তর ঠিক করে (জিন দ্বারা নির্ধারিত)।' },
  { t: 'সেকেন্ডারি গঠন', en: 'Secondary', d: 'মেরুদণ্ডের C=O ও N–H এর হাইড্রোজেন বন্ধনে শিকল প্যাঁচায় (<b>α-হেলিক্স</b>, প্রতি পাকে 3.6 অ্যামিনো অ্যাসিড) বা ভাঁজ হয়ে পাশাপাশি বসে (<b>β-প্লিটেড শিট</b>)।' },
  { t: 'টারশিয়ারি গঠন', en: 'Tertiary', d: 'পুরো শিকল ত্রিমাত্রিকভাবে ভাঁজ হয়: অপোলার R গ্রুপ ভেতরে লুকায়, পোলার ও চার্জিত বাইরে পানির দিকে। ধরে রাখে <b>ডাইসালফাইড সেতু</b> (S–S), আয়নিক ও হাইড্রোজেন বন্ধন এবং পানিবিদ্বেষী আকর্ষণ।' },
  { t: 'কোয়াটারনারি গঠন', en: 'Quaternary', d: 'একাধিক পলিপেপটাইড (সাবইউনিট) মিলে একটি কার্যকর প্রোটিন — যেমন <b>হিমোগ্লোবিন</b>: 2টি α ও 2টি β শিকল, প্রতিটিতে একটি হিম গ্রুপ (Fe²⁺)।' },
  { t: 'ডিন্যাচারেশন', en: 'Denaturation', d: 'তাপ, অম্ল-ক্ষার, ভারী ধাতু বা ইউরিয়ায় দুর্বল বন্ধনগুলো ভাঙে, ত্রিমাত্রিক আকৃতি নষ্ট হয় — কিন্তু পেপটাইড বন্ধন (প্রাথমিক গঠন) অটুট থাকে। আকৃতি গেলে কাজও যায় — যেমন সেদ্ধ ডিমের সাদা অংশ।' }
];
const lvl = start => Object.assign({
  t: 'প্রোটিনের গঠনের চার স্তর', k: ['2d', 'anim', 'int'],
  cap: 'একটি শিকল কীভাবে ভাঁজ হয়ে কার্যকর প্রোটিন হয় দেখো। প্রতিটি বিন্দু একটি অ্যামিনো অ্যাসিড; রঙের অর্থ চিত্রের নিচে দেওয়া আছে। চালাও চাপলে ধাপগুলো পরপর আসবে।'
}, BK.steps({
  W: 360, H: 260, label: 'প্রোটিনের গঠন', dur: 3.2, start,
  stages: ST,
  draw(g, C, s, u) {
    const col = t => [BK.ramp(0), BK.ramp(4), BK.ramp(7), BK.ramp(1)][t];
    const svg = g.ownerSVGElement;
    if (!svg._leg) { svg._leg = E('g', {}, svg); [['অপোলার', 0], ['পোলার', 1], ['চার্জিত', 2], ['সিস্টেইন', 3]].forEach(([n, t], i) => { const x = 30 + i * 84; E('circle', { cx: x, cy: 248, r: 5.5, fill: col(t).c, stroke: col(t).dk }, svg._leg); T(svg._leg, x + 9, 252, n, { fs: 10.5, w: 560, c: C.mu }); }); }
    svg._leg.setAttribute('opacity', s === 3 ? 0 : 1);
    const from = [P0, P0, P1, P2, P2][s], to = [P0, P1, P2, P2, P4][s];
    const P = to.map((p, i) => [lerp(from[i][0], p[0], u), lerp(from[i][1], p[1], u)]);
    if (s === 0) { /* একে একে যুক্ত হয় */
      const k = Math.max(2, Math.round(u * N));
      E('path', { d: 'M' + P.slice(0, k).map(p => p.join(' ')).join('L'), stroke: C.mu, 'stroke-width': 2.4, fill: 'none' }, g);
      P.slice(0, k).forEach((p, i) => E('circle', { cx: p[0], cy: p[1], r: 6, fill: col(TY[i]).c, stroke: col(TY[i]).dk, 'stroke-width': 1 }, g));
      T(g, 26, 106, 'N', { fs: 12, a: 'middle', w: 650, c: BK.ramp(7).ink }); if (k === N) T(g, P[N - 1][0], 106, 'C', { fs: 12, a: 'middle', w: 650, c: BK.ramp(4).ink });
      T(g, 180, 200, 'Gly–Ala–Lys–Leu–Ser–Cys…', { fs: 11, a: 'middle', w: 560, c: C.mu });
      return;
    }
    if (s === 3) {
      /* চারটি সাবইউনিট কাছে আসে */
      const sc = .48, off = 1 - u, cs = [[-1, -1, 'α', BK.ramp(5)], [1, -1, 'β', BK.ramp(2)], [-1, 1, 'β', BK.ramp(2)], [1, 1, 'α', BK.ramp(5)]];
      cs.forEach(([dx, dy, nm, R0]) => {
        const cx = 180 + dx * (44 + 50 * off), cy = 130 + dy * (40 + 34 * off);
        const pts = P2.map(([x, y]) => [cx + (x - 180) * sc, cy + (y - 130) * sc]);
        E('ellipse', { cx, cy, rx: 38, ry: 32, fill: FK.alpha(R0.c, .2), stroke: R0.c, 'stroke-width': 1.4 }, g);
        E('path', { d: 'M' + pts.map(p => p.join(' ')).join('L'), stroke: R0.dk, 'stroke-width': 1.6, fill: 'none', opacity: .8 }, g);
        E('path', { d: `M${cx} ${cy - 8}l8 8l-8 8l-8 -8Z`, fill: BK.ramp(4).c, stroke: BK.ramp(4).dk }, g);
        T(g, cx + dx * 30, cy + dy * 26 + 4, nm, { fs: 13, a: 'middle', w: 700, c: R0.ink });
      });
      T(g, 180, 18, 'হিমোগ্লোবিন = 2α + 2β; ◆ = হিম', { fs: 11.5, a: 'middle', w: 600, c: C.mu });
      return;
    }
    E('path', { d: 'M' + P.map(p => p.join(' ')).join('L'), stroke: C.mu, 'stroke-width': 2.2, fill: 'none', 'stroke-linejoin': 'round' }, g);
    if (s === 1 && u > .7) {
      for (let i = 12; i < 18; i++) { const a = P[i], b = P[i + 6 > 23 ? 23 : 35 - i]; if (b) E('path', { d: `M${a[0]} ${a[1] + 7}L${b[0]} ${b[1] - 7}`, stroke: BK.ramp(5).c, 'stroke-width': 1.2, 'stroke-dasharray': '2 3', opacity: (u - .7) / .3 }, g); }
      T(g, 90, 82, 'α-হেলিক্স', { fs: 12, a: 'middle', w: 650, c: C.fg }); T(g, 252, 82, 'β-প্লিটেড শিট', { fs: 12, a: 'middle', w: 650, c: C.fg });
    }
    if ((s === 2 && u > .8) || (s === 4 && u < .2)) {
      const a = P[5], b = P[18], op = s === 2 ? (u - .8) / .2 : 1 - u / .2;
      E('path', { d: `M${a[0]} ${a[1]}L${b[0]} ${b[1]}`, stroke: BK.ramp(1).c, 'stroke-width': 3, 'stroke-dasharray': '5 3', opacity: op }, g);
      T(g, (a[0] + b[0]) / 2 + 8, (a[1] + b[1]) / 2 - 6, 'S–S', { fs: 11.5, w: 700, c: BK.ramp(1).ink, st: `opacity:${op}` });
      E('ellipse', { cx: 180, cy: 130, rx: 34, ry: 28, fill: FK.alpha(BK.ramp(0).c, .12 * op), stroke: 'none' }, g);
    }
    P.forEach((p, i) => E('circle', { cx: p[0], cy: p[1], r: 6, fill: col(TY[i]).c, stroke: col(TY[i]).dk, 'stroke-width': 1 }, g));
    if (s === 2 && u > .8) T(g, 180, 222, 'পানিবিদ্বেষী কেন্দ্র (ভেতরে) — পানিপ্রিয় পৃষ্ঠ (বাইরে)', { fs: 11, a: 'middle', w: 560, c: C.mu });
    if (s === 4) { T(g, 180, 30, 'তাপ / pH / ভারী ধাতু', { fs: 12, a: 'middle', w: 650, c: BK.ramp(0).ink, st: `opacity:${u}` }); T(g, 180, 222, 'পেপটাইড বন্ধন অটুট — কেবল আকৃতি নষ্ট', { fs: 11, a: 'middle', w: 560, c: C.mu, st: `opacity:${u}` }); }
  }
}));
V.proteinLevels = lvl(.999);
V.proteinDenature = Object.assign(lvl(4.999), { t: 'প্রোটিনের ডিন্যাচারেশন ও গঠনের স্তর' });
})();
