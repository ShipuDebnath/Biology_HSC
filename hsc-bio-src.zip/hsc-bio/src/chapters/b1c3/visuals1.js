/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৩.১ কার্বোহাইড্রেট
   cellElements  : মানবদেহের মৌল (ভরের %) — স্তম্ভ
   cellCompounds : কোষের যৌগ (ভরের %) — বৃত্ত
   carbClass     : কার্বোহাইড্রেটের শ্রেণিবিভাগ — গাছ
   sugarForms    : শিকল ↔ বলয় (গ্লুকোজ/ফ্রুক্টোজ/রাইবোজ/ডিঅক্সিরাইবোজ, α/β) — অ্যানিমেটেড
   pentoses      : একই চিত্র, রাইবোজ দিয়ে শুরু
   glycosidic    : গ্লাইকোসাইডিক বন্ধন — ঘনীভবন ও আর্দ্রবিশ্লেষণ (মল্টোজ/সুক্রোজ/ল্যাকটোজ/সেলোবায়োজ)
   polysac       : স্টার্চ (অ্যামাইলোজ, অ্যামাইলোপেকটিন), গ্লাইকোজেন, সেলুলোজ + আয়োডিন পরীক্ষা
   celluloseFib, glycogenModel : একই চিত্র, ভিন্ন শুরু
   glycogenFlow  : যকৃৎ ও পেশির গ্লাইকোজেন — খাবারের পর / উপবাস / ব্যায়াম
   cmpRiboDeoxy, cmpGluFru, cmpStarchCell : পার্থক্য
   carbDeriv     : কার্বোহাইড্রেট-ডেরিভেটিভস — গাছ
   carbRoles     : জীবদেহে শর্করার ভূমিকা — মাইন্ড ম্যাপ
   energyBars    : প্রতি গ্রামে শক্তি
   সব সংখ্যা: docs/FIGURE_PLAN.md অনুযায়ী পাঠ্যবই ও Campbell/Lehninger থেকে; Python দিয়ে যোগফল যাচাই করা।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, BK = window.BK;

/* ───────── মৌল ও যৌগ ───────── */
V.cellElements = Object.assign({
  t: 'মানবদেহের মৌল (ভরের শতাংশ)', k: ['graph', 'int'],
  cap: 'মাত্র চারটি মৌল — O, C, H, N — মিলে দেহের ভরের প্রায় 96%। ভরে O সবচেয়ে বেশি, কারণ দেহের বেশির ভাগই পানি (H₂O)। স্তম্ভে চাপ দিলে মৌলটির কাজ দেখা যাবে।'
}, BK.bars({
  title: 'মানবদেহের ভরের %', unit: '%', d: 1, labW: 112, max: 70,
  items: [
    ['অক্সিজেন (O)', 65, null, 'পানি ও সব জৈব অণুর অংশ; শ্বসনে শেষ ইলেকট্রন গ্রাহক।'],
    ['কার্বন (C)', 18.5, null, 'সব জৈব অণুর কাঠামো — চারটি সমযোজী বন্ধন গঠন করে শিকল ও বলয় বানায়।'],
    ['হাইড্রোজেন (H)', 9.5, null, 'পানি ও জৈব অণুতে; H⁺ আয়ন pH ও ATP তৈরিতে জরুরি।'],
    ['নাইট্রোজেন (N)', 3.3, null, 'প্রোটিন (অ্যামিনো গ্রুপ) ও নিউক্লিক অ্যাসিডের (নাইট্রোজেন বেস) অপরিহার্য অংশ।'],
    ['ক্যালসিয়াম (Ca)', 1.5, null, 'হাড় ও দাঁত, রক্ত জমাট বাঁধা, পেশি সংকোচন।'],
    ['ফসফরাস (P)', 1.0, null, 'ATP, DNA, RNA, ফসফোলিপিড ও হাড়।'],
    ['পটাশিয়াম (K)', 0.4, null, 'স্নায়ু উদ্দীপনা, কোষের ভেতরের প্রধান ধনাত্মক আয়ন।'],
    ['সালফার (S)', 0.3, null, 'সিস্টেইন ও মিথিওনিন অ্যামিনো অ্যাসিডে; প্রোটিনের ডাইসালফাইড বন্ধন।'],
    ['সোডিয়াম (Na)', 0.2, null, 'কোষের বাইরের প্রধান ধনাত্মক আয়ন; স্নায়ু উদ্দীপনা।'],
    ['ক্লোরিন (Cl)', 0.2, null, 'কোষের বাইরের প্রধান ঋণাত্মক আয়ন; পাকস্থলীর HCl।'],
    ['ম্যাগনেসিয়াম (Mg)', 0.1, null, 'বহু এনজাইমের কো-ফ্যাক্টর; উদ্ভিদে ক্লোরোফিলের কেন্দ্রীয় পরমাণু।']
  ]
}));

V.cellCompounds = Object.assign({
  t: 'একটি কোষের রাসায়নিক যৌগ (ভরের শতাংশ)', k: ['graph', 'int'],
  cap: 'আদর্শ কোষ হিসেবে ব্যাকটেরিয়া (E. coli) কোষের আনুমানিক হিসাব; উৎসভেদে সংখ্যা কিছুটা আলাদা হয়। পানি প্রায় 70%; শুকনো ভরের প্রায় অর্ধেকই প্রোটিন। অংশে চাপ দাও।'
}, BK.donut({
  title: 'কোষের যৌগ (%)', center: 'কোষ',
  items: [['পানি', 70], ['প্রোটিন', 15], ['নিউক্লিক অ্যাসিড', 7], ['কার্বোহাইড্রেট', 3], ['লিপিড', 2], ['অজৈব আয়ন', 1], ['অন্যান্য ক্ষুদ্র অণু', 2]]
}));

/* ───────── শ্রেণিবিভাগ ───────── */
V.carbClass = Object.assign({
  t: 'কার্বোহাইড্রেটের শ্রেণিবিভাগ', k: ['tree', 'int'],
  cap: 'আর্দ্রবিশ্লেষণে কয়টি মনোস্যাকারাইড পাওয়া যায় — সেটিই শ্রেণিবিভাগের ভিত্তি। শাখায় চাপ দিলে ভেতরের উদাহরণ খুলবে।'
}, BK.tree({
  t: 'কার্বোহাইড্রেট', en: 'Carbohydrate', d: 'পলিহাইড্রক্সি অ্যালডিহাইড বা কিটোন, অথবা আর্দ্রবিশ্লেষণে এদের দেয় এমন যৌগ।',
  c: [
    { t: 'মনোস্যাকারাইড', en: 'Monosaccharide', d: 'আর্দ্রবিশ্লেষণে আর ভাঙে না; সরলতম শর্করা; মিষ্টি, পানিতে দ্রবণীয়, দানাদার, বিজারক।', c: [
      { t: 'ট্রায়োজ (3C)', en: 'Triose', d: 'গ্লিসারালডিহাইড (অ্যালডোজ), ডাইহাইড্রক্সি অ্যাসিটোন (কিটোজ)।' },
      { t: 'টেট্রোজ (4C)', en: 'Tetrose', d: 'এরিথ্রোজ, এরিথ্রুলোজ।' },
      { t: 'পেন্টোজ (5C)', en: 'Pentose', d: 'রাইবোজ, ডিঅক্সিরাইবোজ, রাইবুলোজ, জাইলোজ, অ্যারাবিনোজ।' },
      { t: 'হেক্সোজ (6C)', en: 'Hexose', d: 'গ্লুকোজ, গ্যালাকটোজ, ম্যানোজ (অ্যালডোজ); ফ্রুক্টোজ (কিটোজ)।' },
      { t: 'হেপ্টোজ (7C)', en: 'Heptose', d: 'সেডোহেপ্টুলোজ — ক্যালভিন চক্রে।' }] },
    { t: 'অলিগোস্যাকারাইড', en: 'Oligosaccharide', d: '2–10টি মনোস্যাকারাইড গ্লাইকোসাইডিক বন্ধনে যুক্ত।', c: [
      { t: 'ডাইস্যাকারাইড', en: 'Disaccharide', d: 'সুক্রোজ = গ্লুকোজ + ফ্রুক্টোজ; মল্টোজ = গ্লুকোজ + গ্লুকোজ; ল্যাকটোজ = গ্যালাকটোজ + গ্লুকোজ।' },
      { t: 'ট্রাইস্যাকারাইড', en: 'Trisaccharide', d: 'র‍্যাফিনোজ = গ্যালাকটোজ + গ্লুকোজ + ফ্রুক্টোজ (শিম, বিট)।' },
      { t: 'টেট্রাস্যাকারাইড', en: 'Tetrasaccharide', d: 'স্ট্যাকিওজ (শিমজাতীয় বীজ)।' }] },
    { t: 'পলিস্যাকারাইড', en: 'Polysaccharide', d: 'বহু (সাধারণত শত থেকে হাজার) মনোস্যাকারাইডের পলিমার; মিষ্টি নয়, পানিতে প্রায় অদ্রবণীয়।', c: [
      { t: 'হোমোপলিস্যাকারাইড', en: 'Homopolysaccharide', d: 'একই ধরনের একক: স্টার্চ, গ্লাইকোজেন, সেলুলোজ (গ্লুকোজ); ইনুলিন (ফ্রুক্টোজ); কাইটিন (N-অ্যাসিটাইল গ্লুকোসামিন)।' },
      { t: 'হেটারোপলিস্যাকারাইড', en: 'Heteropolysaccharide', d: 'একাধিক ধরনের একক: হায়ালুরোনিক অ্যাসিড, হেপারিন, কন্ড্রয়টিন সালফেট, পেপটিডোগ্লাইকান।' }] }
  ]
}, { colW: 132 }));

V.carbDeriv = Object.assign({
  t: 'কার্বোহাইড্রেট-ডেরিভেটিভস', k: ['tree', 'int'],
  cap: 'মনোস্যাকারাইডের একটি গ্রুপ বদলে (জারণ, বিজারণ, –OH সরানো বা প্রতিস্থাপন) যেসব যৌগ তৈরি হয়। শাখায় চাপ দাও।'
}, BK.tree({
  t: 'ডেরিভেটিভস', en: 'Derivatives', d: 'শর্করার রাসায়নিক রূপান্তরে তৈরি যৌগ।',
  c: [
    { t: 'অ্যামিনো শর্করা', en: 'Amino sugar', d: 'C-2 এর –OH এর বদলে –NH₂।', c: [
      { t: 'গ্লুকোসামিন', d: 'N-অ্যাসিটাইল গ্লুকোসামিনের পলিমার কাইটিন — পতঙ্গের বহিঃকঙ্কাল ও ছত্রাকের কোষপ্রাচীর।' },
      { t: 'গ্যালাকটোসামিন', d: 'কন্ড্রয়টিন সালফেটে (তরুণাস্থি)।' }] },
    { t: 'শর্করা অ্যাসিড', en: 'Sugar acid', d: 'অ্যালডিহাইড বা প্রান্তিক –CH₂OH জারিত হয়ে –COOH।', c: [
      { t: 'গ্লুকুরোনিক অ্যাসিড', d: 'হায়ালুরোনিক অ্যাসিড ও হেপারিনের একক; যকৃতে বিষাক্ত পদার্থ দূর করে।' },
      { t: 'অ্যাসকরবিক অ্যাসিড', d: 'ভিটামিন C — গ্লুকোজ থেকে তৈরি; মানুষ তৈরি করতে পারে না।' }] },
    { t: 'শর্করা অ্যালকোহল', en: 'Sugar alcohol', d: 'কার্বনিল গ্রুপ বিজারিত হয়ে –OH।', c: [
      { t: 'সরবিটল', d: 'গ্লুকোজ থেকে; কৃত্রিম মিষ্টি।' }, { t: 'ম্যানিটল', d: 'বাদামি শৈবালে; ওষুধে।' }, { t: 'গ্লিসারল', d: 'গ্লিসারালডিহাইড থেকে; লিপিডের অংশ।' }] },
    { t: 'ডিঅক্সি শর্করা', en: 'Deoxy sugar', d: 'একটি –OH এর বদলে –H।', c: [
      { t: 'ডিঅক্সিরাইবোজ', d: 'DNA-র শর্করা (C-2 এ O নেই)।' }, { t: 'র‍্যামনোজ ও ফিউকোজ', d: 'কোষপ্রাচীর ও রক্তের গ্রুপের অ্যান্টিজেনে।' }] },
    { t: 'শর্করা ফসফেট', en: 'Sugar phosphate', d: 'ফসফেট গ্রুপ যুক্ত — বিপাকের সক্রিয় রূপ।', c: [
      { t: 'গ্লুকোজ-6-ফসফেট', d: 'গ্লাইকোলাইসিস ও গ্লাইকোজেন বিপাকের কেন্দ্রে।' }, { t: 'RuBP', d: 'রাইবুলোজ-1,5-বিসফসফেট — ক্যালভিন চক্রে CO₂ গ্রাহক।' }] },
    { t: 'গ্লাইকোসাইড', en: 'Glycoside', d: 'শর্করা + অশর্করা অংশ (অ্যাগ্লাইকোন)।', c: [
      { t: 'ডিজিটালিস', d: 'হৃদ্‌রোগের ওষুধ (কার্ডিয়াক গ্লাইকোসাইড)।' }, { t: 'অ্যামিগডালিন', d: 'তিতা বাদামে; আর্দ্রবিশ্লেষণে সায়ানাইড দেয়।' }] }
  ]
}, { colW: 128 }));

V.carbRoles = Object.assign({
  t: 'জীবদেহে শর্করার ভূমিকা', k: ['mind', 'int'],
  cap: 'শক্তি, সঞ্চয়, গঠন, তথ্য ও চেনাজানা — পাঁচ ধরনের কাজ। পাতায় চাপ দিলে বিস্তারিত।'
}, BK.mind({
  t: 'শর্করার ভূমিকা', d: 'জীবদেহের সবচেয়ে সহজলভ্য জ্বালানি এবং বহু গঠনের উপাদান।',
  c: [
    { t: 'শক্তির উৎস', d: 'প্রতি গ্রামে প্রায় 4 kcal (17 kJ)।', c: [{ t: 'গ্লুকোজ জারণ', d: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O; প্রায় 2870 kJ/mol।' }, { t: 'মস্তিষ্ক ও লোহিত কণিকা', d: 'স্বাভাবিক অবস্থায় প্রায় কেবল গ্লুকোজ ব্যবহার করে।' }] },
    { t: 'সঞ্চিত খাদ্য', d: 'অদ্রবণীয় পলিমার — অভিস্রবণে প্রভাব ফেলে না।', c: [{ t: 'স্টার্চ', d: 'উদ্ভিদে — আলু, চাল, গম।' }, { t: 'গ্লাইকোজেন', d: 'প্রাণী ও ছত্রাকে — যকৃৎ ও পেশি।' }, { t: 'ইনুলিন', d: 'ডালিয়া ও চিকরির মূলে।' }] },
    { t: 'গঠনগত', d: 'দৃঢ়তা ও সুরক্ষা।', c: [{ t: 'সেলুলোজ', d: 'উদ্ভিদের কোষপ্রাচীর।' }, { t: 'কাইটিন', d: 'পতঙ্গের বহিঃকঙ্কাল, ছত্রাকের কোষপ্রাচীর।' }, { t: 'পেপটিডোগ্লাইকান', d: 'ব্যাকটেরিয়ার কোষপ্রাচীর।' }, { t: 'পেকটিন', d: 'মধ্যপর্দা (ক্যালসিয়াম পেকটেট)।' }] },
    { t: 'বংশগতি ও শক্তিবাহক', d: 'পেন্টোজ শর্করা।', c: [{ t: 'DNA ও RNA', d: 'ডিঅক্সিরাইবোজ ও রাইবোজ।' }, { t: 'ATP, NAD, FAD', d: 'সবগুলোতে রাইবোজ।' }] },
    { t: 'চেনা ও সুরক্ষা', d: 'কোষের "পরিচয়পত্র" ও বিশেষ কাজ।', c: [{ t: 'গ্লাইকোক্যালিক্স', d: 'কোষ-কোষ শনাক্তকরণ; ABO রক্তের গ্রুপ।' }, { t: 'হেপারিন', d: 'রক্ত জমাট বাঁধতে বাধা।' }, { t: 'হায়ালুরোনিক অ্যাসিড', d: 'অস্থিসন্ধির পিচ্ছিলকারক।' }] }
  ]
}));

V.energyBars = Object.assign({
  t: 'প্রতি গ্রাম খাদ্য থেকে শক্তি', k: ['graph', 'int'],
  cap: 'শর্করা ও প্রোটিন প্রতি গ্রামে প্রায় 4 kcal, স্নেহ প্রায় 9 kcal দেয়। তবু শর্করাই প্রধান জ্বালানি — দ্রুত পাওয়া যায় এবং অক্সিজেন ছাড়াও (গ্লাইকোলাইসিসে) কিছু শক্তি দেয়।'
}, BK.bars({
  title: 'kcal প্রতি গ্রাম (≈ kJ ÷ 4.18)', unit: ' kcal', d: 0, labW: 112, max: 10,
  items: [['কার্বোহাইড্রেট', 4, null, 'প্রায় 17 kJ/g; দ্রুত পাওয়া যায়।'], ['প্রোটিন', 4, null, 'প্রায় 17 kJ/g; সাধারণত জ্বালানি হিসেবে শেষ ভরসা।'], ['স্নেহ (লিপিড)', 9, null, 'প্রায় 37 kJ/g; দীর্ঘমেয়াদি সঞ্চয়।']]
}));

/* ───────── পার্থক্য ───────── */
V.cmpRiboDeoxy = Object.assign({ t: 'রাইবোজ ও ডিঅক্সিরাইবোজের পার্থক্য', k: ['cmp', 'int'], cap: 'সারণি দেখো, তারপর "যাচাই খেলা"য় নিজেকে পরখ করো।' }, BK.compare({
  a: 'রাইবোজ', b: 'ডিঅক্সিরাইবোজ',
  rows: [
    ['আণবিক সংকেত', 'C₅H₁₀O₅', 'C₅H₁₀O₄'],
    ['C-2 কার্বনে', '–OH থাকে', '–H থাকে (একটি O কম)'],
    ['যে নিউক্লিক অ্যাসিডে', 'RNA', 'DNA'],
    ['অন্য যৌগে', 'ATP, NAD, FAD, কো-এনজাইম A', 'কেবল DNA-তে'],
    ['Cn(H₂O)n সূত্র', 'মেনে চলে', 'মেনে চলে না'],
    ['রাসায়নিক স্থিতিশীলতা', 'কম — 2′-OH ক্ষারে শিকল ভাঙতে সাহায্য করে', 'বেশি — দীর্ঘস্থায়ী তথ্যভান্ডারের উপযোগী'],
    ['শনাক্তকরণ', 'অরসিনল (বিয়াল) পরীক্ষায় সবুজ', 'ডাইফিনাইলঅ্যামিন (ডিশে) পরীক্ষায় নীল']
  ]
}));
V.cmpGluFru = Object.assign({ t: 'গ্লুকোজ ও ফ্রুক্টোজের পার্থক্য', k: ['cmp', 'int'], cap: 'দুটির সংকেত একই — C₆H₁₂O₆; পার্থক্য কার্যকরী গ্রুপ ও বলয়ের আকারে।' }, BK.compare({
  a: 'গ্লুকোজ', b: 'ফ্রুক্টোজ',
  rows: [
    ['কার্যকরী গ্রুপ', 'অ্যালডিহাইড (–CHO), C-1 এ — অ্যালডোজ', 'কিটোন (C=O), C-2 এ — কিটোজ'],
    ['বলয়', 'সাধারণত 6-সদস্য পাইরানোজ (5C + 1O)', 'যৌগে (যেমন সুক্রোজে) 5-সদস্য ফিউরানোজ (4C + 1O)'],
    ['বলয় বন্ধ হয়', 'C-1 ও C-5 এর মধ্যে', 'C-2 ও C-5 এর মধ্যে'],
    ['আলোক সক্রিয়তা', 'ডানঘূর্ণী (+) — তাই নাম ডেক্সট্রোজ', 'বামঘূর্ণী (−) — তাই নাম লেভুলোজ'],
    ['মিষ্টতা (সুক্রোজ = 1)', 'প্রায় 0.7', 'প্রায় 1.7 — প্রাকৃতিক শর্করার মধ্যে সবচেয়ে মিষ্টি'],
    ['প্রধান উৎস', 'আঙুর, মধু, রক্ত (রক্তশর্করা)', 'পাকা ফল ও মধু (ফলশর্করা)'],
    ['সেলিওয়ানফ পরীক্ষা', 'ধীরে হালকা রং', 'দ্রুত গাঢ় লাল রং'],
    ['বিজারক ধর্ম', 'বিজারক', 'বিজারক (ক্ষারীয় দ্রবণে)']
  ]
}));
V.cmpStarchCell = Object.assign({ t: 'স্টার্চ ও সেলুলোজের পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই গ্লুকোজের পলিমার — পার্থক্যের মূলে α বনাম β গ্লুকোজ।' }, BK.compare({
  a: 'স্টার্চ', b: 'সেলুলোজ',
  rows: [
    ['গ্লুকোজের ধরন', 'α-D-গ্লুকোজ', 'β-D-গ্লুকোজ'],
    ['বন্ধন', 'α(1→4); শাখায় α(1→6)', 'কেবল β(1→4)'],
    ['শিকলের আকৃতি', 'অ্যামাইলোজ সর্পিল, অ্যামাইলোপেকটিন শাখান্বিত', 'সোজা, শাখাহীন; পাশাপাশি শিকল হাইড্রোজেন বন্ধনে মাইক্রোফাইব্রিল'],
    ['আয়োডিন দ্রবণে', 'নীল-কালো (অ্যামাইলোজ)', 'কোনো রং হয় না'],
    ['পানিতে', 'গরম পানিতে কলয়েড (মণ্ড) তৈরি করে', 'অদ্রবণীয়; শোয়াইটজার দ্রবণে দ্রবণীয়'],
    ['কাজ', 'সঞ্চিত খাদ্য', 'কোষপ্রাচীরের গঠন'],
    ['কোথায় থাকে', 'অ্যামাইলোপ্লাস্টে দানা হিসেবে (আলু, চাল)', 'কোষপ্রাচীরে (তুলা প্রায় 90%)'],
    ['মানুষের পরিপাক', 'অ্যামাইলেজ ভাঙতে পারে', 'সেলুলেজ নেই — হজম হয় না, খাদ্যআঁশ']
  ]
}));
})();

/* ───────── শিকল ↔ বলয় ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const lerp = (a, b, t) => a + (b - a) * t;
/* পাইরানোজ (6-সদস্য) ও ফিউরানোজ (5-সদস্য) বলয়ের কোণের স্থানাঙ্ক — হাওয়ার্থ অভিক্ষেপ */
const PYR = [[300, 152], [268, 186], [200, 186], [166, 152], [200, 118], [268, 118]];   /* বলয়ের ক্রম: কার্বন…, শেষে O */
const FUR = [[296, 146], [272, 188], [196, 188], [172, 146], [234, 114]];
/* শিকলের অবস্থান (ফিশার) */
const CX = 78, Y0 = 46, DY = 38;
/* প্রতিটি পরমাণু: id, লেখা, শিকলের অবস্থান, বলয়ের অবস্থান; sub: [শিকলের লেখা, বলয়ের লেখা, শিকলের দিক L/R, বলয়ের দিক U/D] */
const mk = (key, an) => {
  const A = []; let B = [], ring, info;
  const chainPos = i => [CX, Y0 + i * DY];
  if (key === 'glu') {
    /* C1..C5 বলয়ে, C5 এর O বলয়ের O; C6 বলয়ের বাইরে, C5 এর উপরে */
    const up = an === 'b';
    A.push({ id: 'C1', l: 'C', n: 1, c: chainPos(0), r: PYR[0], an: 1, sub: [['H', up ? 'OH' : 'H', 'L', 'U'], ['=O', up ? 'H' : 'OH', 'R', 'D']] });
    A.push({ id: 'C2', l: 'C', n: 2, c: chainPos(1), r: PYR[1], sub: [['H', 'H', 'L', 'U'], ['OH', 'OH', 'R', 'D']] });
    A.push({ id: 'C3', l: 'C', n: 3, c: chainPos(2), r: PYR[2], sub: [['HO', 'OH', 'L', 'U'], ['H', 'H', 'R', 'D']] });
    A.push({ id: 'C4', l: 'C', n: 4, c: chainPos(3), r: PYR[3], sub: [['H', 'H', 'L', 'U'], ['OH', 'OH', 'R', 'D']] });
    A.push({ id: 'C5', l: 'C', n: 5, c: chainPos(4), r: PYR[4], sub: [['H', 'H', 'L', 'D']] });
    A.push({ id: 'C6', l: 'CH₂OH', n: 6, c: chainPos(5), r: [PYR[4][0], PYR[4][1] - 34] });
    A.push({ id: 'O', l: 'O', ring: 1, c: [CX + 34, Y0 + 4 * DY], r: PYR[5], h: 1 });
    B = [['C1', 'C2'], ['C2', 'C3'], ['C3', 'C4'], ['C4', 'C5'], ['C5', 'C6'], ['C5', 'O']]; ring = ['O', 'C1'];
    info = { n0: 'D-গ্লুকোজ (খোলা শিকল)', n1: `${up ? 'β' : 'α'}-D-গ্লুকোপাইরানোজ`, grp: 'অ্যালডিহাইড (–CHO) C-1 এ → অ্যালডোজ', rg: 'C-5 এর –OH এর O, C-1 এর সাথে যুক্ত হয়ে 6-সদস্য পাইরানোজ বলয় (5C + 1O)।' };
  } else if (key === 'fru') {
    const up = an === 'b';
    A.push({ id: 'C1', l: 'CH₂OH', n: 1, c: chainPos(0), r: up ? [FUR[0][0] + 16, 182] : [FUR[0][0] + 16, 110] });
    A.push({ id: 'C2', l: 'C', n: 2, c: chainPos(1), r: FUR[0], an: 1, sub: [['=O', up ? 'OH' : 'OH', 'R', up ? 'U' : 'D']] });
    A.push({ id: 'C3', l: 'C', n: 3, c: chainPos(2), r: FUR[1], sub: [['HO', 'OH', 'L', 'U'], ['H', 'H', 'R', 'D']] });
    A.push({ id: 'C4', l: 'C', n: 4, c: chainPos(3), r: FUR[2], sub: [['H', 'H', 'L', 'U'], ['OH', 'OH', 'R', 'D']] });
    A.push({ id: 'C5', l: 'C', n: 5, c: chainPos(4), r: FUR[3], sub: [['H', 'H', 'L', 'D']] });
    A.push({ id: 'C6', l: 'CH₂OH', n: 6, c: chainPos(5), r: [FUR[3][0], FUR[3][1] - 36] });
    A.push({ id: 'O', l: 'O', ring: 1, c: [CX + 34, Y0 + 4 * DY], r: FUR[4], h: 1 });
    B = [['C1', 'C2'], ['C2', 'C3'], ['C3', 'C4'], ['C4', 'C5'], ['C5', 'C6'], ['C5', 'O']]; ring = ['O', 'C2'];
    info = { n0: 'D-ফ্রুক্টোজ (খোলা শিকল)', n1: `${up ? 'β' : 'α'}-D-ফ্রুক্টোফিউরানোজ`, grp: 'কিটোন (C=O) C-2 এ → কিটোজ', rg: 'C-5 এর –OH এর O, C-2 এর সাথে যুক্ত হয়ে 5-সদস্য ফিউরানোজ বলয় (4C + 1O)। সুক্রোজে ফ্রুক্টোজ এই রূপে থাকে।' };
  } else {
    const de = key === 'dri', up = an === 'b';
    A.push({ id: 'C1', l: 'C', n: 1, c: chainPos(0), r: FUR[0], an: 1, sub: [['H', up ? 'OH' : 'H', 'L', 'U'], ['=O', up ? 'H' : 'OH', 'R', 'D']] });
    A.push({ id: 'C2', l: 'C', n: 2, c: chainPos(1), r: FUR[1], hl: de, sub: [['H', 'H', 'L', 'U'], [de ? 'H' : 'OH', de ? 'H' : 'OH', 'R', 'D']] });
    A.push({ id: 'C3', l: 'C', n: 3, c: chainPos(2), r: FUR[2], sub: [['H', 'H', 'L', 'U'], ['OH', 'OH', 'R', 'D']] });
    A.push({ id: 'C4', l: 'C', n: 4, c: chainPos(3), r: FUR[3], sub: [['H', 'H', 'L', 'D']] });
    A.push({ id: 'C5', l: 'CH₂OH', n: 5, c: chainPos(4), r: [FUR[3][0], FUR[3][1] - 36] });
    A.push({ id: 'O', l: 'O', ring: 1, c: [CX + 34, Y0 + 3 * DY], r: FUR[4], h: 1 });
    B = [['C1', 'C2'], ['C2', 'C3'], ['C3', 'C4'], ['C4', 'C5'], ['C4', 'O']]; ring = ['O', 'C1'];
    info = de
      ? { n0: '2-ডিঅক্সি-D-রাইবোজ (খোলা শিকল)', n1: `${up ? 'β' : 'α'}-2-ডিঅক্সি-D-রাইবোফিউরানোজ`, grp: 'অ্যালডিহাইড C-1 এ; C-2 তে –OH নেই, আছে দুটি H', rg: 'C-4 এর –OH এর O, C-1 এর সাথে যুক্ত — ফিউরানোজ বলয়। DNA-তে β রূপ।' }
      : { n0: 'D-রাইবোজ (খোলা শিকল)', n1: `${up ? 'β' : 'α'}-D-রাইবোফিউরানোজ`, grp: 'অ্যালডিহাইড C-1 এ → অ্যালডোপেন্টোজ', rg: 'C-4 এর –OH এর O, C-1 এর সাথে যুক্ত — ফিউরানোজ বলয়। RNA ও ATP-তে β রূপ।' };
  }
  return { A, B, ring, info };
};
const SUG = [['glu', 'গ্লুকোজ'], ['fru', 'ফ্রুক্টোজ'], ['rib', 'রাইবোজ'], ['dri', 'ডিঅক্সিরাইবোজ']];
const sugarVis = start => ({
  t: 'শিকল থেকে বলয় — শর্করার গঠন', k: ['2d', 'anim', 'int'],
  cap: 'পানিতে দ্রবীভূত মনোস্যাকারাইডের 99% এর বেশি অণু বলয় রূপে থাকে। চালাও চাপলে দেখবে: শেষের দিকের একটি –OH এর অক্সিজেন ঘুরে এসে কার্বনিল কার্বনের সাথে যুক্ত হয়, আর সেই কার্বনে নতুন –OH তৈরি হয় — এর দিক নিচে হলে α, উপরে হলে β। ফিশার চিত্রের ডান দিকের –OH হাওয়ার্থ চিত্রে নিচে যায়।',
  html: () => `<div class="fk-row">${X.seg('sg', SUG, start)}</div><div class="fk-row">${X.seg('an', [['a', 'α রূপ'], ['b', 'β রূপ']], 'a')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.sl('t', 'শিকল ↔ বলয়', 0, 100, 1, 0, '%')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 270;
    let key = start, an = 'a', M, t = 0, dir = 1, hold = 0, C, svg, g, hg, hT1, hT2, hT3, lastHead = '', lastInfo = '';
    const sl = FK.bindSl(root, 't', v => { t = v / 100; if (!A.paused) { A.pause(true); X.pp(root, A); } paint(); }, '%', 0);
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'শর্করার শিকল ও বলয়' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); g = E('g', {}, svg); hg = E('g', {}, svg); hT1 = T(hg, W - 12, 24, '', { fs: 12.5, a: 'end', w: 650 }); hT2 = T(hg, W - 12, 42, '', { fs: 10.5, a: 'end', w: 520, c: C.mu }); hT3 = T(hg, W - 12, H - 12, '', { fs: 10, a: 'end', w: 500, c: C.mu }); lastHead = ''; paint(); };
    const build = () => { M = mk(key, an); lastInfo = ''; lastHead = ''; };
    const pos = (a, e) => [lerp(a.c[0], a.r[0], e), lerp(a.c[1], a.r[1], e)];
    const paint = () => {
      if (!g) return;
      g.innerHTML = '';
      const e = FK.ease(t), Rc = BK.ramp(9), Ro = BK.ramp(4), Ra = BK.ramp(2), Rh = BK.ramp(7), P = {};
      M.A.forEach(a => P[a.id] = pos(a, e));
      /* বলয়ের সামনের কিনারা মোটা (হাওয়ার্থ) */
      const RA = {}; M.A.forEach(a => RA[a.id] = a);
      M.B.forEach(([p, q]) => {
        const front = e > .6 && RA[p].r[1] > 175 && RA[q].r[1] > 175 && (RA[p].l === 'C') && (RA[q].l === 'C');
        E('path', { d: `M${P[p][0]} ${P[p][1]}L${P[q][0]} ${P[q][1]}`, stroke: C.fg, 'stroke-width': front ? 2 + 3 * e : 2, 'stroke-linecap': 'round', opacity: .85 }, g);
      });
      /* নতুন বন্ধন O → অ্যানোমেরিক কার্বন */
      const [o, c1] = M.ring;
      if (e > .02) E('path', { d: `M${P[o][0]} ${P[o][1]}L${P[c1][0]} ${P[c1][1]}`, stroke: Ro.c, 'stroke-width': 2.4, 'stroke-dasharray': e < .97 ? '4 4' : null, opacity: Math.min(1, e * 1.4) }, g);
      /* গ্রুপগুলো */
      M.A.forEach(a => {
        (a.sub || []).forEach(([s0, s1, d0, d1]) => {
          const ox0 = d0 === 'L' ? -30 : 30, oy1 = d1 === 'U' ? -28 : 28, ox1 = a.an ? 14 : a.r[0] < 180 ? -10 : 0;
          const dx = lerp(ox0, ox1, e), dy = lerp(0, oy1, e), ax = P[a.id][0], ay = P[a.id][1], x = ax + dx, y = ay + dy, ln = Math.hypot(dx, dy) || 1, ux = dx / ln, uy = dy / ln;
          E('path', { d: `M${ax + ux * 11} ${ay + uy * 11}L${ax + ux * (ln - 10)} ${ay + uy * (ln - 10)}`, stroke: C.mu, 'stroke-width': 1.4 }, g);
          const isAn = a.an, swap = isAn && s0 !== s1;
          const col = isAn ? Ra.ink : (a.hl && s1 === 'H' && d1 === 'D') ? Rh.ink : (s1 === 'OH' || s0 === 'HO') ? Ro.ink : C.mu;
          if (swap) {
            T(g, x, y + 4, s0, { fs: 12.5, a: 'middle', w: 600, c: col, st: `opacity:${Math.max(0, 1 - e * 2)}` });
            T(g, x, y + 4, s1, { fs: 12.5, a: 'middle', w: 650, c: col, st: `opacity:${Math.max(0, e * 2 - 1)}` });
          } else T(g, x, y + 4, e < .5 ? s0 : s1, { fs: 12.5, a: 'middle', w: s1 === 'OH' ? 600 : 520, c: col });
        });
      });
      /* পরমাণু */
      M.A.forEach(a => {
        const [x, y] = P[a.id];
        if (a.l === 'C') {
          E('circle', { cx: x, cy: y, r: 11, fill: a.an ? FK.alpha(Ra.c, .28) : a.hl ? FK.alpha(Rh.c, .28) : C.sf, stroke: a.an ? Ra.c : a.hl ? Rh.c : Rc.c, 'stroke-width': a.an || a.hl ? 2 : 1.3 }, g);
          T(g, x, y + 4.5, 'C', { fs: 12, a: 'middle', w: 650 });
          T(g, x + 13, y - 8, String(a.n), { fs: 9.5, w: 600, c: C.mu });
        } else if (a.ring) {
          E('circle', { cx: x, cy: y, r: 11, fill: FK.alpha(Ro.c, .22), stroke: Ro.c, 'stroke-width': 1.8 }, g);
          T(g, x, y + 4.5, 'O', { fs: 12.5, a: 'middle', w: 650, c: Ro.ink });
          if (a.h && e < .98) {  /* –OH এর H টি সরে কার্বনিল O তে যায় */
            const tg = M.A.find(z => z.an), sb = tg.sub.find(z => z[1] === 'OH'), dy = sb[3] === 'U' ? -28 : 28;
            const hx = lerp(x + 20, P[tg.id][0] + 14 + 13, e), hy = lerp(y, P[tg.id][1] + dy, e);
            T(g, hx, hy + 4, 'H', { fs: 11.5, a: 'middle', w: 650, c: Ra.ink, st: `opacity:${1 - e}` });
          }
        } else {
          T(g, x, y + 4, a.l, { fs: 12, a: 'middle', w: 600, c: C.fg });
          T(g, x + 26, y - 8, String(a.n), { fs: 9.5, w: 600, c: C.mu });
        }
      });
      /* শিরোনাম */
      const head = (e < .5 ? 0 : 1) + '|' + (e > .6 ? 1 : 0) + '|' + key + an;
      if (head !== lastHead) { lastHead = head; hT1.textContent = e < .5 ? M.info.n0 : M.info.n1; hT1.setAttribute('fill', e < .5 ? C.fg : Ra.ink); hT2.textContent = e < .5 ? 'ফিশার অভিক্ষেপ' : 'হাওয়ার্থ অভিক্ষেপ'; hT3.textContent = e > .6 ? 'মোটা দাগ = বলয়ের সামনের কিনারা' : ''; }
      const inf = e < .5 ? `<b>${M.info.n0}</b> — ${M.info.grp}।<div class="small">ডান দিকের –OH পরে নিচে যাবে, বাঁ দিকেরটি উপরে।</div>` : `<b>${M.info.n1}</b> — ${M.info.rg}<div class="small"><b style="color:${Ra.ink}">অ্যানোমেরিক কার্বন</b> (রঙিন): এর –OH ${an === 'a' ? 'নিচে → α' : 'উপরে → β'}। ${key === 'dri' ? '<b>C-2 তে –OH নেই</b> — তাই নাম "ডিঅক্সি"।' : ''}</div>`;
      if (inf !== lastInfo) { $('info').innerHTML = inf; lastInfo = inf; }
    };
    const A = X.anim(root, dt => {
      if (hold > 0) { hold -= dt; return; }
      t += dir * dt / 2.6; if (t >= 1) { t = 1; dir = -1; hold = 1.6; } else if (t <= 0) { t = 0; dir = 1; hold = 1; }
      sl.set(Math.round(t * 100), true); paint();
    }, { paused: true });
    X.pp(root, A);
    X.onSeg(root, 'sg', v => { key = v; build(); paint(); });
    X.onSeg(root, 'an', v => { an = v; build(); paint(); });
    build();
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
V.sugarForms = sugarVis('glu');
V.pentoses = Object.assign(sugarVis('rib'), { t: 'রাইবোজ ও ডিঅক্সিরাইবোজ — শিকল থেকে বলয়' });
})();

/* ───────── গ্লাইকোসাইডিক বন্ধন ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const lerp = (a, b, t) => a + (b - a) * t;
const K = 1.3;  /* বলয়ের মাপ */
const HEX = [[34, 0], [18, 18], [-18, 18], [-34, 0], [-18, -18], [18, -18]].map(([x, y]) => [x * K, y * K]);     /* C1 C2 C3 C4 C5 O */
const PEN = [[-30, -2], [-18, 20], [18, 20], [30, -2], [0, -20]].map(([x, y]) => [x * K, y * K]);                 /* ফ্রুক্টোজ উল্টো: C2 বাঁয়ে */
const D = {
  mal: { n: 'মল্টোজ', a: ['গ্লুকোজ', 'α'], b: ['গ্লুকোজ', 'hex'], bond: 'α(1→4)', down: 1, red: 'আছে — ডান গ্লুকোজের C-1 মুক্ত', src: 'অঙ্কুরিত বীজ (মল্ট); স্টার্চ পরিপাকে তৈরি', enz: 'মল্টেজ' },
  suc: { n: 'সুক্রোজ', a: ['গ্লুকোজ', 'α'], b: ['ফ্রুক্টোজ', 'pen'], bond: 'α1→β2', down: 1, red: 'নেই — দুটি অ্যানোমেরিক কার্বনই বন্ধনে আটকা', src: 'আখ, সুগার বিট; ফ্লোয়েমে পরিবাহিত শর্করা', enz: 'সুক্রেজ (ইনভার্টেজ)' },
  lac: { n: 'ল্যাকটোজ', a: ['গ্যালাকটোজ', 'β'], b: ['গ্লুকোজ', 'hex'], bond: 'β(1→4)', down: 0, red: 'আছে — গ্লুকোজের C-1 মুক্ত', src: 'দুধ (দুগ্ধশর্করা) — মানুষের দুধে প্রায় 7%', enz: 'ল্যাকটেজ' },
  cel: { n: 'সেলোবায়োজ', a: ['গ্লুকোজ', 'β'], b: ['গ্লুকোজ', 'hex'], bond: 'β(1→4)', down: 0, red: 'আছে — ডান গ্লুকোজের C-1 মুক্ত', src: 'সেলুলোজ ভাঙলে তৈরি হয়', enz: 'সেলোবায়েজ (β-গ্লুকোসাইডেজ)' }
};
const ST = ['দুটি মনোস্যাকারাইড', 'কাছে আসে', '–OH ও –H মিলে পানি', 'গ্লাইকোসাইডিক বন্ধন'];
V.glycosidic = {
  t: 'গ্লাইকোসাইডিক বন্ধন — ঘনীভবন ও আর্দ্রবিশ্লেষণ', k: ['2d', 'anim', 'int'],
  cap: 'একটি মনোস্যাকারাইডের অ্যানোমেরিক কার্বনের –OH আর অন্যটির একটি –OH এর H মিলে এক অণু পানি বের হয়; মাঝে থাকে একটি O সেতু — গ্লাইকোসাইডিক বন্ধন (ঘনীভবন/ডিহাইড্রেশন)। উল্টো দিকে পানি যোগ করে বন্ধন ভাঙে — আর্দ্রবিশ্লেষণ। চিত্রটি সরলীকৃত।',
  html: () => `<div class="fk-row">${X.seg('ds', [['mal', 'মল্টোজ'], ['suc', 'সুক্রোজ'], ['lac', 'ল্যাকটোজ'], ['cel', 'সেলোবায়োজ']], 'mal')}</div>
    <div class="fk-row">${X.seg('md', [['syn', 'ঘনীভবন (তৈরি)'], ['hyd', 'আর্দ্রবিশ্লেষণ (ভাঙা)']], 'syn')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button><input type="range" class="fk-scrub" min="0" max="3.999" step=".01" value="0" data-k="scrub" aria-label="সময়"></div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250, Y = 120;
    let ds = 'mal', md = 'syn', t = 0, C, svg, g, tg, txt = {}, last = '';
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'গ্লাইকোসাইডিক বন্ধন' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); g = E('g', {}, svg); tg = E('g', {}, svg); txt = { nl: T(tg, 0, 0, '', { fs: 11.5, a: 'middle', w: 650 }), nr: T(tg, 0, 0, '', { fs: 11.5, a: 'middle', w: 650 }), bond: T(tg, 180, 30, '', { fs: 12.5, a: 'middle', w: 650 }), ano: T(tg, 14, 24, '', { fs: 10.5, w: 520, c: C.mu }) }; paint(); };
    const setT = (el, x, y, s, c, op) => { if (el._s !== s) { el.textContent = s; el._s = s; } el.setAttribute('x', x.toFixed(1)); el.setAttribute('y', y.toFixed(1)); if (c) el.setAttribute('fill', c); el.setAttribute('opacity', op == null ? 1 : op.toFixed(2)); };
    const ringAt = (pts, cx, cy, R0, name, hlIdx, oIdx) => {
      const P = pts.map(([x, y]) => [cx + x, cy + y]);
      E('path', { d: 'M' + P.map(p => p.join(' ')).join('L') + 'Z', fill: BK.lg(svg, R0.lt, FK.alpha(R0.c, .55), { a: 90 }), stroke: R0.dk, 'stroke-width': 1.8, 'stroke-linejoin': 'round' }, g);
      E('path', { d: `M${P[1][0]} ${P[1][1]}L${P[2][0]} ${P[2][1]}`, stroke: R0.dk, 'stroke-width': 4.5, 'stroke-linecap': 'round' }, g);
      T(g, P[oIdx][0], P[oIdx][1] - 5, 'O', { fs: 11, a: 'middle', w: 650, c: BK.ramp(4).ink });
      P.cx = cx; P.cy = cy; P.ink = R0.ink;
      return P;
    };
    const paint = () => {
      if (!g) return; g.innerHTML = '';
      const d = D[ds], R1 = BK.ramp(2), R2 = ds === 'suc' ? BK.ramp(6) : ds === 'lac' ? BK.ramp(2) : BK.ramp(2), Rg = ds === 'lac' ? BK.ramp(5) : R1, Ro = BK.ramp(4), Rw = BK.ramp(0);
      /* সময় → অগ্রগতি p (0 = আলাদা, 1 = যুক্ত) */
      const s = Math.min(3, Math.floor(t)), u = FK.ease(Math.min(1, t - s));
      const prog = md === 'syn' ? Math.min(1, (s + u) / 3) : 1 - Math.min(1, (s + u) / 3);
      const near = Math.min(1, prog * 3), wat = Math.max(0, Math.min(1, prog * 3 - 1)), bond = Math.max(0, Math.min(1, prog * 3 - 2));
      const gap = lerp(60, 0, near), xl = 100 - gap / 2, xr = 260 + gap / 2;
      const sgn = d.down ? 1 : -1;
      const Pl = ringAt(HEX, xl, Y, Rg, d.a[0], 0, 5);
      const Pr = d.b[1] === 'pen' ? ringAt(PEN, xr, Y, R2, d.b[0], 0, 4) : ringAt(HEX, xr, Y, R2, d.b[0], 3, 5);
      const cL = Pl[0], cR = d.b[1] === 'pen' ? Pr[0] : Pr[3];
      T(g, cL[0] + 4, cL[1] - 6 * sgn - (sgn < 0 ? 4 : -12), ds === 'suc' ? '1' : '1', { fs: 9.5, w: 600, c: C.mu });
      T(g, cR[0] - 10, cR[1] - 6 * sgn - (sgn < 0 ? 4 : -12), ds === 'suc' ? '2' : '4', { fs: 9.5, w: 600, c: C.mu });
      const mid = [(cL[0] + cR[0]) / 2, Y + sgn * 40];
      /* বন্ধনের আগের –OH গ্রুপ (বাঁ C-1) ও H–O (ডান) */
      if (bond < 1) {
        const op = 1 - bond;
        E('path', { d: `M${cL[0]} ${cL[1]}l${8} ${sgn * 26}`, stroke: C.mu, 'stroke-width': 1.4, opacity: op }, g);
        E('path', { d: `M${cR[0]} ${cR[1]}l${-8} ${sgn * 26}`, stroke: C.mu, 'stroke-width': 1.4, opacity: op }, g);
        /* বাঁয়ের OH: O থাকে না (পানিতে যায়), ডানের O থেকে যায়, H যায় */
        const wx = lerp(cL[0] + 12, mid[0], wat), wy = lerp(cL[1] + sgn * 36, Y + sgn * 92, wat);
        const hx = lerp(cR[0] - 22, mid[0] + 6, wat), hy = lerp(cR[1] + sgn * 36, Y + sgn * 92, wat);
        if (wat < .98) {
          T(g, wx, wy + 4, 'OH', { fs: 12, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${op}` });
          T(g, hx, hy + 4, 'H', { fs: 12, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${op}` });
        }
        T(g, cR[0] - 6, cR[1] + sgn * 36 + 4, 'O', { fs: 12, a: 'middle', w: 650, c: Ro.ink, st: `opacity:${1 - bond * .9}` });
      }
      /* পানি */
      if (wat > .6) {
        const fl = md === 'syn' ? Math.min(1, (wat - .6) / .4) : 1;
        const wy = Y + sgn * 92 + (md === 'syn' ? sgn * bond * 14 : sgn * (1 - wat) * 14);
        E('circle', { cx: mid[0], cy: wy, r: 18, fill: FK.alpha(BK.ramp(5).c, .2 * fl), stroke: FK.alpha(BK.ramp(5).c, .7 * fl), 'stroke-width': 1.4 }, g);
        T(g, mid[0], wy + 4.5, 'H₂O', { fs: 12.5, a: 'middle', w: 650, c: BK.ramp(5).ink, st: `opacity:${fl}` });
      }
      /* O সেতু */
      if (bond > 0) {
        E('path', { d: `M${cL[0]} ${cL[1]}L${mid[0]} ${mid[1]}L${cR[0]} ${cR[1]}`, fill: 'none', stroke: Ro.c, 'stroke-width': 2.6, opacity: bond, 'stroke-linejoin': 'round' }, g);
        E('circle', { cx: mid[0], cy: mid[1], r: 10, fill: C.sf, stroke: Ro.c, 'stroke-width': 1.8, opacity: bond }, g);
        T(g, mid[0], mid[1] + 4.5, 'O', { fs: 12, a: 'middle', w: 650, c: Ro.ink, st: `opacity:${bond}` });
      }
      setT(txt.bond, mid[0], d.down ? 30 : H - 20, `${d.bond} গ্লাইকোসাইডিক বন্ধন`, Ro.ink, bond);
      setT(txt.ano, 14, d.down ? H - 16 : 24, `${d.a[1]} অ্যানোমার`, C.mu, 1);
      setT(txt.nl, Pl.cx, Pl.cy + 5, d.a[0], Pl.ink, 1); setT(txt.nr, Pr.cx, Pr.cy + 5, d.b[0], Pr.ink, 1);
      const stTxt = md === 'syn' ? ST[s] : ['বন্ধন যুক্ত ডাইস্যাকারাইড', 'পানি যোগ হয়', 'বন্ধন ভাঙে', 'দুটি মনোস্যাকারাইড'][s];
      $('scrub').value = t;
      const inf = `<span class="chip acc">${FK.bn(s + 1)}/৪</span> <b>${stTxt}</b><div class="small"><b>${d.n}</b> = ${d.a[0]} + ${d.b[0]}; বন্ধন <b>${d.bond}</b>। বিজারক প্রান্ত: ${d.red}। উৎস: ${d.src}। ভাঙে <b>${d.enz}</b> এনজাইমে।</div>`;
      if (inf !== last) { $('info').innerHTML = inf; last = inf; }
    };
    const A = X.anim(root, dt => { t += dt / 1.6; if (t >= 4.9) t = 0; paint(); }, { paused: true });
    X.pp(root, A);
    $('scrub').addEventListener('input', e => { t = +e.target.value; paint(); });
    X.onSeg(root, 'ds', v => { ds = v; paint(); });
    X.onSeg(root, 'md', v => { md = v; t = 0; paint(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();

/* ───────── পলিস্যাকারাইড মডেল ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const INFO = {
  amy: { n: 'অ্যামাইলোজ', d: 'স্টার্চের 20–30%; α(1→4) বন্ধনে যুক্ত শাখাহীন শিকল, প্রতি পাকে প্রায় 6টি গ্লুকোজ — সর্পিল (হেলিক্স)।', io: 'নীল-কালো', ic: '#1b2a6b', why: 'আয়োডিন অণু (I₃⁻/I₅⁻ শিকল) সর্পিলের ভেতরের ফাঁপা নলে ঢুকে আলো শোষণ করে।' },
  ap: { n: 'অ্যামাইলোপেকটিন', d: 'স্টার্চের 70–80%; α(1→4) শিকল, প্রায় প্রতি 24–30টি গ্লুকোজ পরপর α(1→6) শাখা।', io: 'লালচে বেগুনি', ic: '#7a2a6b', why: 'শাখাগুলো ছোট, তাই লম্বা সর্পিল কম — আয়োডিন কম জমে।' },
  gly: { n: 'গ্লাইকোজেন', d: 'প্রাণীর স্টার্চ; প্রতি 8–12টি গ্লুকোজ পরপর α(1→6) শাখা — অ্যামাইলোপেকটিনের চেয়ে বেশি শাখান্বিত ও ঘন। কেন্দ্রে গ্লাইকোজেনিন প্রোটিন।', io: 'লালচে বাদামি', ic: '#8a3b12', why: 'খুব ছোট শাখা — সর্পিল প্রায় নেই।' },
  cel: { n: 'সেলুলোজ', d: 'β(1→4) বন্ধন; প্রতি পরের গ্লুকোজ 180° উল্টে থাকে, তাই শিকল সোজা। পাশাপাশি শিকল হাইড্রোজেন বন্ধনে যুক্ত হয়ে মাইক্রোফাইব্রিল।', io: 'রং হয় না', ic: null, why: 'সর্পিল নেই — আয়োডিন ঢোকার জায়গা নেই।' }
};
const polyVis = start => ({
  t: 'পলিস্যাকারাইডের গঠন ও আয়োডিন পরীক্ষা', k: ['2d', 'anim', 'int'],
  cap: 'প্রতিটি বিন্দু একটি গ্লুকোজ একক। রঙিন বিন্দু = শাখা শুরুর α(1→6) বিন্দু। শাখার ঘনত্ব আনুপাতিক দেখানো হয়েছে (প্রকৃত সংখ্যা তথ্য-ঘরে)। "আয়োডিন দাও" চাপলে রঙের পরিবর্তন দেখো।',
  html: () => `<div class="fk-row">${X.seg('pm', [['amy', 'অ্যামাইলোজ'], ['ap', 'অ্যামাইলোপেকটিন'], ['gly', 'গ্লাইকোজেন'], ['cel', 'সেলুলোজ']], start)}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.btn('io', '<span data-lbl>আয়োডিন দাও</span>', '')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250;
    let pm = start, io = false, C, svg, tint, gB, gX, helix, beads = [], hb = [], ph = 0, grow = 1, iodK = 0;
    /* বিন্দুর তালিকা তৈরি: [x, y, ক্রম, শাখা-বিন্দু?] + সংযোগ */
    const layout = () => {
      const B = [], L = [];
      if (pm === 'amy') { for (let i = 0; i < 40; i++) B.push({ i, o: i }); }
      else if (pm === 'cel') {
        for (let r = 0; r < 4; r++) for (let i = 0; i < 18; i++) B.push({ x: 30 + i * 17.5, y: 70 + r * 40, o: i, flip: (i + r) % 2 });
        for (let r = 0; r < 3; r++) for (let i = 0; i < 18; i += 2) hb.push([30 + i * 17.5 + 4, 70 + r * 40 + 7, 30 + i * 17.5 + 4, 70 + (r + 1) * 40 - 7]);
      } else if (pm === 'ap') {
        /* মূল শিকল + শাখা — প্রতি 6 বিন্দুতে একটি শাখা (আনুপাতিক) */
        const add = (x, y, ang, n, depth, o0, parent) => {
          let px = x, py = y, prev = parent;
          for (let i = 0; i < n; i++) {
            px += 15 * Math.cos(ang); py += 15 * Math.sin(ang);
            const br = depth < 2 && i > 1 && i % 6 === 3;
            B.push({ x: px, y: py, o: o0 + i, br }); const cur = B.length - 1;
            if (prev != null) L.push([prev, cur, i === 0]);
            prev = cur;
            if (br) add(px, py, ang + (((i / 6) | 0) % 2 === depth % 2 ? -.8 : .8), depth ? 4 : 8, depth + 1, o0 + i + 1, cur);
          }
        };
        add(10, 136, -.06, 22, 0, 0, null);
      } else {
        /* গ্লাইকোজেন — কেন্দ্র থেকে স্তরে স্তরে শাখা */
        const cx = 180, cy = 126;
        B.push({ x: cx, y: cy, o: 0, core: 1 });
        const grow3 = (x, y, ang, depth, parent, o0) => {
          let px = x, py = y, prev = parent;
          const n = depth === 0 ? 4 : 3;
          for (let i = 0; i < n; i++) {
            px += 11 * Math.cos(ang); py += 11 * Math.sin(ang);
            const br = depth < 2 && i === n - 2;
            B.push({ x: px, y: py, o: o0 + i, br }); L.push([prev, B.length - 1]); prev = B.length - 1;
            if (br) grow3(px, py, ang + .62, depth + 1, prev, o0 + i + 1);
          }
          if (depth < 2) grow3(px, py, ang - .32, depth + 1, prev, o0 + n);
        };
        for (let k = 0; k < 6; k++) grow3(cx, cy, k * Math.PI / 3 + .2, 0, 0, 1);
      }
      return [B, L];
    };
    let links = [];
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; hb = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পলিস্যাকারাইডের গঠন' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      tint = E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: 'transparent' }, svg);
      gX = E('g', {}, svg); gB = E('g', {}, svg);
      const [B, L] = layout(); links = L; const Rg = BK.ramp(2), Rb = BK.ramp(4), Rk = BK.ramp(7);
      const maxO = Math.max(...B.map(b => b.o));
      beads = B.map(b => {
        const el = E('circle', { cx: b.x || 0, cy: b.y || 0, r: b.core ? 9 : 5.6, fill: b.core ? Rk.c : b.br ? Rb.c : Rg.c, stroke: b.br ? Rb.dk : Rg.dk, 'stroke-width': 1 }, gB);
        return Object.assign(b, { el, k: b.o / (maxO || 1) });
      });
      links.forEach(([a, b, br]) => { if (B[a] && B[b] && pm !== 'amy') { const ln = E('path', { d: `M${B[a].x} ${B[a].y}L${B[b].x} ${B[b].y}`, stroke: br && B[a].br ? Rb.c : Rg.dk, 'stroke-width': br && B[a].br ? 2 : 1.4, opacity: .7 }, gX); ln._b = b; B[b].ln = ln; } });
      if (pm === 'cel') {
        hb = hb.map(([x1, y1, x2, y2]) => E('path', { d: `M${x1} ${y1}L${x2} ${y2}`, stroke: BK.ramp(5).c, 'stroke-width': 1.4, 'stroke-dasharray': '2 3' }, gX));
        beads.forEach(b => { if (b.flip) E('path', { d: `M${b.x} ${b.y - 9}v-5`, stroke: Rg.dk, 'stroke-width': 1.4 }, gX); else E('path', { d: `M${b.x} ${b.y + 9}v5`, stroke: Rg.dk, 'stroke-width': 1.4 }, gX); });
        for (let r = 0; r < 4; r++) E('path', { d: `M30 ${70 + r * 40}H${30 + 17 * 17.5}`, stroke: Rg.dk, 'stroke-width': 1.4, opacity: .6 }, gX).parentNode.insertBefore(gX.lastChild, gX.firstChild);
        T(svg, 12, 30, 'সমান্তরাল β-গ্লুকোজ শিকল', { fs: 11.5, w: 600, c: C.mu });
        T(svg, 12, H - 14, 'নীল ছোট দাগ = হাইড্রোজেন বন্ধন; খাড়া কাঁটা = উল্টানো একক', { fs: 10, w: 500, c: C.mu });
      } else if (pm === 'amy') {
        helix = E('path', { d: '', stroke: Rg.dk, 'stroke-width': 1.4, fill: 'none', opacity: .7 }, gX);
        T(svg, 12, 30, 'α(1→4) সর্পিল — প্রতি পাকে ~6 গ্লুকোজ', { fs: 11.5, w: 600, c: C.mu });
      } else if (pm === 'gly') {
        T(svg, 12, 30, 'কেন্দ্র: গ্লাইকোজেনিন প্রোটিন', { fs: 11.5, w: 600, c: BK.ramp(7).ink });
        T(svg, 12, H - 14, 'বহু মুক্ত প্রান্ত → একসাথে বহু গ্লুকোজ ছাড়া যায়', { fs: 10, w: 500, c: C.mu });
      } else {
        T(svg, 12, 30, 'α(1→4) শিকল + α(1→6) শাখা', { fs: 11.5, w: 600, c: C.mu });
        T(svg, 12, H - 14, 'রঙিন বিন্দু = শাখা-বিন্দু', { fs: 10, w: 500, c: C.mu });
      }
      grow = 1; ph = 0; paintTint(); info(); step(0);
    };
    const info = () => { const d = INFO[pm]; $('info').innerHTML = `<b>${d.n}</b> — ${d.d}<div class="small">আয়োডিন পরীক্ষা: <b>${d.io}</b>${io ? ' — ' + d.why : ''}</div>`; };
    const paintTint = () => { const d = INFO[pm]; tint.setAttribute('fill', io && d.ic ? FK.alpha(d.ic, .18 * iodK) : 'transparent'); };
    const step = dt => {
      if (pm === 'amy') {
        ph += dt * 1.2;
        const pts = [];
        beads.forEach((b, i) => {
          const a = i * 2 * Math.PI / 6 + ph, x = 22 + i * 8.1, y = 130 + 40 * Math.sin(a), z = Math.cos(a);
          b.el.setAttribute('cx', x.toFixed(1)); b.el.setAttribute('cy', y.toFixed(1)); b.el.setAttribute('r', (5 + 1.8 * z).toFixed(2)); b.el.setAttribute('opacity', (.55 + .45 * (z + 1) / 2).toFixed(2));
          pts.push(`${x.toFixed(1)} ${y.toFixed(1)}`);
        });
        helix.setAttribute('d', 'M' + pts.join('L'));
        if (io) { if (!gX._io) { gX._io = E('path', { d: 'M22 130H340', stroke: INFO.amy.ic, 'stroke-width': 5, 'stroke-linecap': 'round' }, gX); } gX._io.setAttribute('opacity', (.85 * iodK).toFixed(2)); }
        else if (gX._io) { gX._io.remove(); gX._io = null; }
      } else if (pm === 'cel') {
        ph += dt; hb.forEach((h, i) => h.setAttribute('opacity', (.45 + .55 * Math.abs(Math.sin(ph * 2 + i * .7))).toFixed(2)));
      } else {
        /* তৈরি হওয়া: গ্লাইকোজেন সিনথেজ ও শাখা এনজাইম একে একে একক যোগ করে, তারপর থামে */
        if (grow < 1) grow = Math.min(1, grow + dt / 4);
        const shown = grow * 1.02;
        beads.forEach(b => { const v = b.k <= shown || b.core ? 1 : 0; if (b._v !== v) { b._v = v; b.el.setAttribute('opacity', v); if (b.ln) b.ln.setAttribute('opacity', v * .7); } });
        if (grow >= 1 && dt > 0) { ph += dt; if (ph > 2.5) { ph = 0; grow = 0; } }
      }
      if (io && iodK < 1) { iodK = Math.min(1, iodK + dt * 1.5); paintTint(); }
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    X.onSeg(root, 'pm', v => { pm = v; ph = 0; base(); });
    FK.on(root, 'io', b => { io = !io; iodK = io ? 0 : 0; b.querySelector('[data-lbl]').textContent = io ? 'আয়োডিন সরাও' : 'আয়োডিন দাও'; if (io && A.paused) iodK = 1; paintTint(); info(); step(0); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
V.polysac = polyVis('amy');
V.celluloseFib = Object.assign(polyVis('cel'), { t: 'সেলুলোজ মাইক্রোফাইব্রিল ও অন্যান্য পলিস্যাকারাইড' });
V.glycogenModel = Object.assign(polyVis('gly'), { t: 'গ্লাইকোজেনের শাখান্বিত গঠন' });
})();

/* ───────── যকৃৎ ও পেশির গ্লাইকোজেন ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const MODE = {
  meal: { n: 'খাবারের পর', h: 'ইনসুলিন', bg: 'বেশি', liv: 1, mus: 1, d: 'রক্তে গ্লুকোজ বেড়ে যায় → অগ্ন্যাশয়ের β-কোষ <b>ইনসুলিন</b> ছাড়ে → যকৃৎ ও পেশি গ্লুকোজ টেনে নিয়ে <b>গ্লাইকোজেন তৈরি</b> করে (গ্লাইকোজেনেসিস)। রক্তে গ্লুকোজ স্বাভাবিকে ফেরে।' },
  fast: { n: 'উপবাস', h: 'গ্লুকাগন', bg: 'কম', liv: -1, mus: 0, d: 'রক্তে গ্লুকোজ কমে যায় → α-কোষ <b>গ্লুকাগন</b> ছাড়ে → <b>যকৃতের</b> গ্লাইকোজেন ভেঙে (গ্লাইকোজেনোলাইসিস) গ্লুকোজ রক্তে আসে। পেশির গ্লাইকোজেন রক্তে যায় না — পেশিতে গ্লুকোজ-6-ফসফাটেজ এনজাইম নেই।' },
  ex: { n: 'ব্যায়াম', h: 'অ্যাড্রেনালিন', bg: 'স্বাভাবিক', liv: -1, mus: -1, d: '<b>অ্যাড্রেনালিন</b>: পেশির গ্লাইকোজেন ভেঙে <b>পেশি নিজেই</b> ব্যবহার করে — শক্তি (ATP) ও সংকোচন। যকৃৎ রক্তে গ্লুকোজ পাঠিয়ে মাত্রা ঠিক রাখে।' }
};
V.glycogenFlow = {
  t: 'যকৃৎ ও পেশির গ্লাইকোজেন — কখন জমে, কখন ভাঙে', k: ['2d', 'anim', 'int'],
  cap: 'অবস্থা বদলে দেখো, গ্লুকোজ কণা কোন দিকে যাচ্ছে আর ভান্ডারের গ্লাইকোজেন বাড়ছে না কমছে। মূল কথা: যকৃতের গ্লাইকোজেন সারা দেহের জন্য, পেশির গ্লাইকোজেন কেবল পেশির জন্য।',
  html: () => `<div class="fk-row">${X.seg('m', [['meal', 'খাবারের পর'], ['fast', 'উপবাস'], ['ex', 'ব্যায়াম']], 'meal')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 280, BY = 168;
    let m = 'meal', C, svg, dots = [], lvL = .5, lvM = .5, barL, barM, hormT, bgT, atpT, ph = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'গ্লাইকোজেনের প্রবাহ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rl = BK.ramp(4), Rm = BK.ramp(0), Rb = BK.ramp(4), Rg = BK.ramp(2);
      /* রক্তনালি */
      E('rect', { x: 10, y: BY - 18, width: W - 20, height: 36, rx: 18, fill: FK.alpha(Rb.c, .14), stroke: FK.alpha(Rb.c, .55), 'stroke-width': 1.4 }, svg);
      T(svg, W / 2, BY + 4, 'রক্ত', { fs: 12, a: 'middle', w: 600, c: Rb.ink });
      /* যকৃৎ */
      E('path', { d: 'M24 46Q30 22 100 26Q160 30 158 62Q150 110 70 112Q20 108 24 46Z', fill: BK.lg(svg, BK.ramp(6).lt, BK.ramp(6).c, { a: 90 }), stroke: BK.ramp(6).dk, 'stroke-width': 1.6 }, svg);
      T(svg, 90, 50, 'যকৃৎ', { fs: 13, a: 'middle', w: 650, c: BK.ramp(6).ink });
      /* পেশি */
      E('rect', { x: 204, y: 28, width: 140, height: 84, rx: 30, fill: BK.lg(svg, Rm.lt, Rm.c, { a: 90 }), stroke: Rm.dk, 'stroke-width': 1.6 }, svg);
      for (let i = 0; i < 4; i++) E('path', { d: `M${222 + i * 10} ${40}Q${274} ${70 + (i - 1.5) * 6} ${326 - i * 10} ${100}`, stroke: FK.alpha(Rm.dk, .25), 'stroke-width': 1.2, fill: 'none' }, svg);
      T(svg, 274, 50, 'পেশি', { fs: 13, a: 'middle', w: 650, c: Rm.ink });
      /* ভান্ডার মিটার */
      const meter = (x, y, lab) => { E('rect', { x, y, width: 80, height: 10, rx: 5, fill: C.s2, stroke: C.ln }, svg); T(svg, x, y - 4, lab, { fs: 10, w: 560, c: C.mu }); return E('rect', { x, y, width: 40, height: 10, rx: 5, fill: Rg.c }, svg); };
      barL = meter(50, 84, 'গ্লাইকোজেন'); barM = meter(234, 84, 'গ্লাইকোজেন');
      /* হরমোন ও রক্তশর্করা */
      E('rect', { x: 20, y: 214, width: 150, height: 50, rx: 12, fill: C.s2, stroke: C.ln }, svg);
      T(svg, 32, 234, 'অগ্ন্যাশয় → হরমোন', { fs: 10.5, w: 560, c: C.mu }); hormT = T(svg, 32, 254, '', { fs: 13, w: 650, c: BK.ramp(7).ink });
      E('rect', { x: 190, y: 214, width: 150, height: 50, rx: 12, fill: C.s2, stroke: C.ln }, svg);
      T(svg, 202, 234, 'রক্তে গ্লুকোজ', { fs: 10.5, w: 560, c: C.mu }); bgT = T(svg, 202, 254, '', { fs: 13, w: 650, c: Rb.ink });
      atpT = T(svg, 274, 140, 'ATP', { fs: 13, a: 'middle', w: 700, c: BK.ramp(0).ink });
      dots = Array.from({ length: 14 }, (_, i) => ({ el: E('circle', { r: 4.5, fill: Rg.c, stroke: Rg.dk, 'stroke-width': 1 }, svg), u: i / 14, lane: i % 2 }));
      setMode();
    };
    const setMode = () => { const d = MODE[m]; hormT.textContent = d.h; bgT.textContent = d.bg; $('info').innerHTML = `<b>${d.n}</b> — ${d.d}`; };
    const step = dt => {
      const d = MODE[m]; ph += dt;
      lvL = Math.max(.08, Math.min(.95, lvL + d.liv * dt * .05)); lvM = Math.max(.08, Math.min(.95, lvM + d.mus * dt * .05));
      if ((d.liv < 0 && lvL <= .08) || (d.liv > 0 && lvL >= .95)) lvL = .5; if ((d.mus < 0 && lvM <= .08) || (d.mus > 0 && lvM >= .95)) lvM = .5;
      barL.setAttribute('width', (80 * lvL).toFixed(1)); barM.setAttribute('width', (80 * lvM).toFixed(1));
      atpT.setAttribute('opacity', m === 'ex' ? (.5 + .5 * Math.abs(Math.sin(ph * 4))).toFixed(2) : 0);
      dots.forEach((p, i) => {
        p.u = (p.u + dt * .35) % 1; const u = p.u;
        let x, y, show = 1;
        /* রক্তে বাঁ থেকে ডানে ভাসা */
        if (p.lane === 0) {
          /* যকৃৎ পথ */
          if (d.liv > 0) { x = 90; y = BY - (BY - 70) * u; }            /* রক্ত → যকৃৎ */
          else if (d.liv < 0) { x = 100; y = 80 + (BY - 80) * u; }        /* যকৃৎ → রক্ত */
          else show = 0;
          if (i % 4 === 0) { x = 30 + 300 * u; y = BY + 6 * Math.sin(u * 12); show = 1; }
        } else {
          if (d.mus > 0) { x = 264; y = BY - (BY - 70) * u; }           /* রক্ত → পেশি */
          else if (d.mus < 0) { x = 270 + 14 * Math.sin(u * 6); y = 80 + 50 * u; show = u < .8 ? 1 : 0; }  /* পেশির ভেতরে → ATP */
          else { x = 30 + 300 * u; y = BY - 6 * Math.cos(u * 12); }
        }
        p.el.setAttribute('cx', x.toFixed(1)); p.el.setAttribute('cy', y.toFixed(1)); p.el.setAttribute('opacity', show ? Math.min(1, Math.min(u, 1 - u) * 8).toFixed(2) : 0);
      });
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    X.onSeg(root, 'm', v => { m = v; setMode(); step(0); });
    const unT = FK.onTheme(base); base(); step(0);
    return () => { A.stop(); unT(); };
  }
};
})();
