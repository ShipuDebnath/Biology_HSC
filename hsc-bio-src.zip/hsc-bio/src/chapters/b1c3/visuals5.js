/* ═══════════════════════════════════════════════════════════════════
   visuals5 — §৩.৫ পুনরালোচনা
   bioTests : জৈব অণুর শনাক্তকরণ — ভার্চুয়াল পরীক্ষাগার (নমুনা × পরীক্ষা → টেস্টটিউবে রং বদল, অ্যানিমেটেড)
   b1c3map  : কোষ রসায়ন অধ্যায়ের মাইন্ড ম্যাপ
   ফলাফল-সারণি: পাঠ্যবইয়ের প্রচলিত ফল (বেনেডিক্ট — গরম করে; বাইউরেট — ঠান্ডায়)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const SAMPLES = [['glu', 'গ্লুকোজ'], ['suc', 'সুক্রোজ'], ['sta', 'স্টার্চ'], ['alb', 'ডিমের সাদা অংশ'], ['oil', 'সয়াবিন তেল'], ['milk', 'দুধ']];
const TESTS = [['ben', 'বেনেডিক্ট'], ['iod', 'আয়োডিন'], ['biu', 'বাইউরেট'], ['sud', 'সুদান III']];
/* প্রতিটি পরীক্ষার শুরু রং ও ফল: [শেষ রং, তলানি রং|null, তেলের স্তর রং|null, বর্ণনা, পজিটিভ?] */
const START = { ben: '#3b6fd8', iod: '#c9a227', biu: '#4f86d9', sud: '#f3d9d4' };
const R = {
  ben: { glu: ['#c8642a', '#b5401c', null, 'ইটের মতো লাল অধঃক্ষেপ — বিজারক শর্করা।', 1], suc: ['#3b6fd8', null, null, 'নীল থেকে যায় — সুক্রোজ অবিজারক।', 0], sta: ['#3b6fd8', null, null, 'নীল থেকে যায় — স্টার্চ কার্যত অবিজারক।', 0], alb: ['#3b6fd8', null, null, 'নীল — শর্করা নেই।', 0], oil: ['#3b6fd8', null, '#f1d77a', 'নীল; উপরে তেলের স্তর — শর্করা নেই।', 0], milk: ['#d98a3a', '#c4602a', null, 'কমলা-লাল অধঃক্ষেপ — দুধের ল্যাকটোজ বিজারক।', 1] },
  iod: { glu: ['#c9a227', null, null, 'হলদে-বাদামি (আয়োডিনের নিজের রং) — স্টার্চ নেই।', 0], suc: ['#c9a227', null, null, 'হলদে-বাদামি — স্টার্চ নেই।', 0], sta: ['#1f2350', null, null, 'নীল-কালো — স্টার্চ আছে (অ্যামাইলোজের সর্পিলে আয়োডিন)।', 1], alb: ['#c9a227', null, null, 'হলদে-বাদামি — স্টার্চ নেই।', 0], oil: ['#c9a227', null, '#f1d77a', 'হলদে-বাদামি; উপরে তেল — স্টার্চ নেই।', 0], milk: ['#d8b54a', null, null, 'হলদে — স্টার্চ নেই।', 0] },
  biu: { glu: ['#4f86d9', null, null, 'নীল থেকে যায় — পেপটাইড বন্ধন নেই।', 0], suc: ['#4f86d9', null, null, 'নীল — প্রোটিন নেই।', 0], sta: ['#4f86d9', null, null, 'নীল — প্রোটিন নেই।', 0], alb: ['#7a3fb0', null, null, 'বেগুনি — প্রোটিন আছে (অ্যালবুমিন)।', 1], oil: ['#4f86d9', null, '#f1d77a', 'নীল; উপরে তেল — প্রোটিন নেই।', 0], milk: ['#8a5bc0', null, null, 'বেগুনি — দুধের কেসিন প্রোটিন।', 1] },
  sud: { glu: ['#f0c6c0', null, null, 'হালকা গোলাপি, তেলের লাল স্তর নেই — লিপিড নেই।', 0], suc: ['#f0c6c0', null, null, 'লাল স্তর নেই — লিপিড নেই।', 0], sta: ['#f0c6c0', null, null, 'লাল স্তর নেই — লিপিড নেই।', 0], alb: ['#f0c6c0', null, null, 'লাল স্তর নেই — লিপিড নেই।', 0], oil: ['#f6e7c4', null, '#d6342b', 'উপরে উজ্জ্বল লাল তেলের স্তর — লিপিড আছে।', 1], milk: ['#f4dcd2', null, '#e0584a', 'লাল রঞ্জিত চর্বির ফোঁটা — দুধে লিপিড আছে।', 1] }
};
const HOW = { ben: '2 mL নমুনা + 2 mL বেনেডিক্ট দ্রবণ, গরম পানিতে 3–5 মিনিট ফোটাও।', iod: 'নমুনায় 2–3 ফোঁটা আয়োডিন দ্রবণ দাও (গরম কোরো না)।', biu: '2 mL নমুনা + 2 mL NaOH, তারপর ফোঁটায় ফোঁটায় লঘু CuSO₄ — ঝাঁকাও।', sud: 'নমুনা + পানি + কয়েক ফোঁটা সুদান III, ঝাঁকিয়ে রেখে দাও।' };
const mix = (a, b, k) => { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * k).toString(16).padStart(2, '0')).join(''); };
V.bioTests = {
  t: 'ভার্চুয়াল পরীক্ষাগার — জৈব অণু শনাক্তকরণ', k: ['2d', 'anim', 'int'],
  cap: 'একটি নমুনা ও একটি পরীক্ষা বেছে নাও, তারপর "পরীক্ষা করো" চাপো — টেস্টটিউবে রং বদল দেখো। সব নমুনায় চারটি পরীক্ষা করে নিচের সারণি পূর্ণ করো; দুধে কোন কোন জৈব অণু আছে, নিজেই আবিষ্কার করো।',
  html: () => `<div class="fk-row">${X.seg('smp', SAMPLES, 'glu')}</div><div class="fk-row">${X.seg('tst', TESTS, 'ben')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row">${FK.btn('go', 'পরীক্ষা করো', 'play')}${FK.btn('rs', 'সারণি মোছো', '')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250;
    let smp = 'glu', tst = 'ben', C, svg, liq, ppt, layer, flame, bub = [], k = 0, run = false, done = {}, grid;
    const TX = 74, TY = 40, TW = 44, TH = 150;
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'জৈব অণু শনাক্তকরণ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      /* টেস্টটিউব */
      const cid = 'bt-clip-' + Math.random().toString(36).slice(2, 8), clip = E('clipPath', { id: cid }, E('defs', {}, svg));
      E('path', { d: `M${TX} ${TY}V${TY + TH - TW / 2}A${TW / 2} ${TW / 2} 0 0 0 ${TX + TW} ${TY + TH - TW / 2}V${TY}Z`, fill: '#000' }, clip);
      const g = E('g', { 'clip-path': `url(#${cid})` }, svg);
      liq = E('rect', { x: TX, y: TY + 50, width: TW, height: TH, fill: START[tst] }, g);
      layer = E('rect', { x: TX, y: TY + 50, width: TW, height: 0, fill: '#f1d77a' }, g);
      ppt = E('rect', { x: TX, y: TY + TH - 22, width: TW, height: 30, fill: 'transparent' }, g);
      bub = Array.from({ length: 6 }, (_, i) => E('circle', { cx: TX + 8 + i * 6, cy: TY + TH - 10, r: 2, fill: '#fff', opacity: 0 }, g));
      E('path', { d: `M${TX} ${TY}V${TY + TH - TW / 2}A${TW / 2} ${TW / 2} 0 0 0 ${TX + TW} ${TY + TH - TW / 2}V${TY}`, fill: 'none', stroke: C.mu, 'stroke-width': 2.2 }, svg);
      E('path', { d: `M${TX - 6} ${TY}H${TX + TW + 6}`, stroke: C.mu, 'stroke-width': 3, 'stroke-linecap': 'round' }, svg);
      flame = E('path', { d: `M${TX + TW / 2} ${TY + TH + 32}q-12 -10 0 -26q12 16 0 26Z`, fill: '#f08c2a', opacity: 0 }, svg);
      T(svg, TX + TW / 2, H - 10, '', { fs: 11, a: 'middle', w: 600, c: C.mu });
      /* ফলাফল সারণি */
      grid = E('g', {}, svg); drawGrid(); paint();
    };
    const drawGrid = () => {
      grid.innerHTML = ''; const gx = 134, gy = 34, cw = 44, rh = 30;
      T(grid, gx, gy - 12, 'ফলাফল সারণি (+ পজিটিভ, − নেগেটিভ)', { fs: 10.5, w: 600, c: C.mu });
      TESTS.forEach(([t, n], j) => T(grid, gx + 48 + j * cw + (cw - 6) / 2, gy + 8, n.slice(0, 5), { fs: 9.5, a: 'middle', w: 600, c: C.mu }));
      SAMPLES.forEach(([s, n], i) => {
        const y = gy + 20 + i * rh;
        T(grid, gx, y + 15, n.length > 6 ? n.slice(0, 5) + '…' : n, { fs: 10, w: 560 });
        TESTS.forEach(([t], j) => {
          const key = s + '|' + t, d = done[key], x = gx + 48 + j * cw;
          E('rect', { x, y: y + 2, width: cw - 6, height: rh - 6, rx: 6, fill: d == null ? C.s2 : d ? FK.alpha(C.ok, .25) : FK.alpha(C.mu, .12), stroke: s === smp && t === tst ? C.fg : C.ln, 'stroke-width': s === smp && t === tst ? 1.6 : 1 }, grid);
          T(grid, x + (cw - 6) / 2, y + 18, d == null ? '?' : d ? '+' : '−', { fs: 12.5, a: 'middle', w: 700, c: d == null ? C.mu : d ? C.ok : C.mu });
        });
      });
    };
    const paint = () => {
      const r = R[tst][smp], e = FK.ease(k), sc = START[tst];
      liq.setAttribute('fill', mix(sc, r[0], e));
      ppt.setAttribute('fill', r[1] ? FK.alpha(r[1], e) : 'transparent');
      const lh = r[2] ? 18 : 0; layer.setAttribute('height', lh); layer.setAttribute('y', TY + 50); layer.setAttribute('fill', r[2] ? (tst === 'sud' ? mix('#f1d77a', r[2], e) : r[2]) : 'transparent');
      flame.setAttribute('opacity', tst === 'ben' && run ? .9 : 0);
      bub.forEach((b, i) => { const on = tst === 'ben' && run; b.setAttribute('opacity', on ? .7 : 0); b.setAttribute('cy', (TY + TH - 10 - ((k * 4 + i * .17) % 1) * 90).toFixed(1)); });
      const nm = SAMPLES.find(x => x[0] === smp)[1], tn = TESTS.find(x => x[0] === tst)[1];
      $('info').innerHTML = k < 1 ? `<b>${tn} পরীক্ষা — ${nm}</b><div class="small">পদ্ধতি: ${HOW[tst]}</div>` : `<b>${tn} — ${nm}: ${r[4] ? 'পজিটিভ' : 'নেগেটিভ'}</b><div class="small">${r[3]}</div>`;
    };
    const A = X.anim(root, dt => { if (!run) return; k = Math.min(1, k + dt / 1.8); paint(); if (k >= 1) { run = false; done[smp + '|' + tst] = R[tst][smp][4]; drawGrid(); paint(); A.pause(true); } }, { paused: true });
    FK.on(root, 'go', () => { k = 0; run = true; A.pause(false); });
    FK.on(root, 'rs', () => { done = {}; drawGrid(); });
    X.onSeg(root, 'smp', v => { smp = v; k = 0; run = false; drawGrid(); paint(); });
    X.onSeg(root, 'tst', v => { tst = v; k = 0; run = false; drawGrid(); paint(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

V.b1c3map = Object.assign({
  t: 'কোষ রসায়ন — এক নজরে', k: ['mind', 'int'],
  cap: 'চারটি জৈব অণু ও এনজাইম — অধ্যায়ের সবচেয়ে জরুরি তথ্য এক জায়গায়। পাতায় চাপ দিলে বিস্তারিত।'
}, BK.mind({
  t: 'কোষ রসায়ন', d: 'জীবকোষের জৈব অণু ও তাদের অনুঘটক।',
  c: [
    { t: 'কার্বোহাইড্রেট', d: 'Cn(H₂O)n; 4 kcal/g; গ্লাইকোসাইডিক বন্ধন।', c: [{ t: 'মনোস্যাকারাইড', d: 'গ্লুকোজ (অ্যালডোজ), ফ্রুক্টোজ (কিটোজ), রাইবোজ।' }, { t: 'ডাইস্যাকারাইড', d: 'সুক্রোজ (অবিজারক), মল্টোজ, ল্যাকটোজ।' }, { t: 'পলিস্যাকারাইড', d: 'স্টার্চ ও গ্লাইকোজেন (α, সঞ্চয়), সেলুলোজ (β, গঠন)।' }] },
    { t: 'প্রোটিন', d: 'অ্যামিনো অ্যাসিডের পলিমার; পেপটাইড বন্ধন।', c: [{ t: 'অ্যামিনো অ্যাসিড', d: '20টি; উভধর্মী; 9টি অত্যাবশ্যকীয়।' }, { t: 'চার স্তর', d: 'প্রাথমিক → সেকেন্ডারি → টারশিয়ারি → কোয়াটারনারি।' }, { t: 'ডিন্যাচারেশন', d: 'আকৃতি ও কাজ নষ্ট, পেপটাইড বন্ধন অটুট।' }] },
    { t: 'লিপিড', d: 'পানিতে অদ্রবণীয়; 9 kcal/g; এস্টার বন্ধন।', c: [{ t: 'ট্রাইগ্লিসারাইড', d: 'গ্লিসারল + 3 ফ্যাটি অ্যাসিড; 3 অণু পানি।' }, { t: 'ফসফোলিপিড', d: 'উভপ্রেমী — কোষঝিল্লির দ্বিস্তর।' }, { t: 'স্টেরয়েড', d: 'কোলেস্টেরল, যৌন হরমোন, ভিটামিন D।' }] },
    { t: 'এনজাইম', d: 'প্রোটিনধর্মী জৈব অনুঘটক।', c: [{ t: 'কর্মপদ্ধতি', d: 'E + S → ES → E + P; লক-অ্যান্ড-কি, ইনডিউসড ফিট।' }, { t: 'প্রভাবক', d: 'তাপ, pH, [S], [E], প্রতিরোধক।' }, { t: 'শ্রেণি', d: 'অক্সিডো-, ট্রান্সফা-, হাইড্রো-, লায়েজ, আইসোমারেজ, লাইগেজ।' }] }
  ]
}));
})();
