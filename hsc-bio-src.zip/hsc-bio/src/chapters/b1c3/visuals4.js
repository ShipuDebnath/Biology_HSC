/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §৩.৪ এনজাইম
   activationEnergy : সক্রিয়ন শক্তি — অনুঘটকহীন / অজৈব অনুঘটক / এনজাইম (বল গড়িয়ে পাহাড় পেরোয়)
   enzMech          : লক-অ্যান্ড-কি বনাম ইনডিউসড ফিট — E + S → ES → EP → E + P (অ্যানিমেটেড)
   holoenzyme       : অ্যাপোএনজাইম + কো-ফ্যাক্টর → হলোএনজাইম (ধাপে ধাপে)
   cofactorTree     : কো-ফ্যাক্টরের প্রকারভেদ — গাছ
   enzClass         : এনজাইমের শ্রেণিবিন্যাস (IUBMB, 7 শ্রেণি) — গাছ
   enzKinetics      : সাবস্ট্রেটের ঘনত্ব বনাম বিক্রিয়ার হার + প্রতিরোধক (মাইকেলিস-মেনটেন) + সম্পৃক্ততার কণা-দৃশ্য
   enzUses          : জৈবিক ও শিল্পে এনজাইমের ব্যবহার — মাইন্ড ম্যাপ
   cmpEnzCoenz, cmpEnzCat : পার্থক্য
   H₂O₂ বিয়োজনের Ea (আনুমানিক, উৎসভেদে ভিন্ন): অনুঘটকহীন ~75, প্লাটিনাম ~49, ক্যাটালেজ ~23 kJ/mol; ΔH ≈ −98 kJ/mol
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const MODES = [['none', 'অনুঘটক নেই', 75], ['pt', 'অজৈব অনুঘটক (Pt)', 49], ['enz', 'এনজাইম (ক্যাটালেজ)', 23]];
V.activationEnergy = {
  t: 'সক্রিয়ন শক্তি ও অনুঘটক', k: ['graph', 'anim', 'int'],
  cap: 'বিক্রিয়া শুরু করতে বিক্রিয়ক অণুকে একটি শক্তির "পাহাড়" — সক্রিয়ন শক্তি (Ea) — পেরোতে হয়। অনুঘটক বিকল্প পথ দিয়ে পাহাড় নিচু করে; এনজাইম সবচেয়ে বেশি নিচু করে। লক্ষ করো: বিক্রিয়ার মোট শক্তি পরিবর্তন (ΔH) একই থাকে — অনুঘটক কেবল গতি বাড়ায়, সাম্যাবস্থা বদলায় না। উদাহরণ: H₂O₂ এর বিয়োজন (মান আনুমানিক)।',
  html: () => `<div class="fk-row">${X.seg('m', MODES.map(([k, n]) => [k, n]), 'enz')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250;
    const X0 = 40, X1 = 340, Y0 = 118, SC = .78;     /* বিক্রিয়ক স্তর y=118; 1 kJ = 0.78 px */
    let m = 'enz', C, svg, ball, lines = {}, tt = 0;
    const curve = ea => { const pts = []; for (let i = 0; i <= 60; i++) { const u = i / 60, x = X0 + u * (X1 - X0), k = Math.max(0, Math.min(1, (u - .5) / .3)), base = -98 * FK.ease(k), bump = Math.exp(-Math.pow((u - .45) / .11, 2)); pts.push([x, Y0 - SC * (base + ea * bump)]); } return pts; };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'সক্রিয়ন শক্তি' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      E('path', { d: `M${X0} 20V${H - 22}H${X1}`, stroke: C.mu, 'stroke-width': 1.4, fill: 'none' }, svg);
      T(svg, 14, 120, 'শক্তি', { fs: 11, w: 600, c: C.mu, st: 'writing-mode:vertical-rl' }); T(svg, X1, H - 8, 'বিক্রিয়ার অগ্রগতি →', { fs: 10.5, a: 'end', w: 560, c: C.mu });
      MODES.forEach(([k, n, ea], i) => {
        const pts = curve(ea);
        lines[k] = E('path', { d: 'M' + pts.map(p => p.map(v => v.toFixed(1)).join(' ')).join('L'), stroke: BK.ramp([0, 6, 2][i]).c, 'stroke-width': 2.6, fill: 'none', 'stroke-dasharray': k === 'none' ? '5 4' : null }, svg);
        lines[k]._pts = pts;
      });
      T(svg, X0 + 6, Y0 - 6, 'H₂O₂', { fs: 11.5, w: 650 }); T(svg, X1 - 4, Y0 + 98 * SC - 6, 'H₂O + ½O₂', { fs: 11.5, a: 'end', w: 650 });
      E('path', { d: `M${X1 - 10} ${Y0}V${Y0 + 98 * SC}`, stroke: C.mu, 'stroke-width': 1.2, 'stroke-dasharray': '3 3' }, svg);
      T(svg, X1 - 14, Y0 + 50, 'ΔH ≈ −98', { fs: 10.5, a: 'end', w: 600, c: C.mu });
      lines.ea = E('path', { stroke: C.fg, 'stroke-width': 1.4, fill: 'none' }, svg); lines.eaT = T(svg, 0, 0, '', { fs: 11.5, w: 650 });
      ball = E('circle', { r: 7, fill: BK.ramp(4).c, stroke: '#fff', 'stroke-width': 1.5 }, svg);
      setMode(); step(0);
    };
    const setMode = () => {
      const i = MODES.findIndex(x => x[0] === m), ea = MODES[i][2];
      Object.keys(lines).forEach(k => { if (lines[k]._pts) lines[k].setAttribute('opacity', k === m ? 1 : .28); });
      const xPeak = X0 + .45 * (X1 - X0);
      lines.ea.setAttribute('d', `M${xPeak} ${Y0}V${Y0 - ea * SC + 4}M${xPeak - 4} ${Y0 - ea * SC + 10}l4 -6l4 6`);
      lines.eaT.setAttribute('x', xPeak + 8); lines.eaT.setAttribute('y', Y0 - ea * SC / 2 + 4); lines.eaT.textContent = `Ea ≈ ${ea} kJ/mol`;
      $('info').innerHTML = `<b>${MODES[i][1]}</b>: সক্রিয়ন শক্তি প্রায় ${ea} kJ/mol। ${m === 'enz' ? 'Ea কমায় ঘরের তাপমাত্রাতেই অনেক বেশি অণু পাহাড় পেরোতে পারে — ক্যাটালেজের একটি অণু প্রতি সেকেন্ডে কয়েক মিলিয়ন H₂O₂ ভাঙে।' : m === 'pt' ? 'ধাতব অনুঘটক Ea কিছুটা কমায়, তবে এনজাইমের মতো নয়, আর নির্দিষ্টতাও নেই।' : 'অনুঘটক ছাড়া H₂O₂ খুব ধীরে ভাঙে — বোতলে মাসের পর মাস থাকে।'}`;
    };
    const step = dt => {
      tt = (tt + dt * .35) % 1.25; const u = Math.min(1, tt), pts = lines[m]._pts, j = Math.min(pts.length - 1, Math.round(u * (pts.length - 1)));
      ball.setAttribute('cx', pts[j][0].toFixed(1)); ball.setAttribute('cy', (pts[j][1] - 7).toFixed(1));
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    X.onSeg(root, 'm', v => { m = v; tt = 0; setMode(); step(0); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── লক-অ্যান্ড-কি ও ইনডিউসড ফিট ───────── */
V.enzMech = {
  t: 'এনজাইমের কর্মপদ্ধতি — লক-অ্যান্ড-কি ও ইনডিউসড ফিট', k: ['2d', 'anim', 'int'],
  cap: 'সাবস্ট্রেট এনজাইমের সক্রিয় স্থানে বসে এনজাইম-সাবস্ট্রেট জটিল (ES) তৈরি করে, বিক্রিয়ার পর উৎপাদ (P) মুক্ত হয় এবং এনজাইম অপরিবর্তিত থেকে আবার কাজ করে: E + S ⇌ ES → EP → E + P। লক-অ্যান্ড-কি মডেলে সক্রিয় স্থান আগে থেকেই সাবস্ট্রেটের মাপমতো; ইনডিউসড ফিট মডেলে সাবস্ট্রেট কাছে এলে সক্রিয় স্থান নিজেকে বদলে তাকে আঁকড়ে ধরে।',
  html: () => `<div class="fk-row">${X.seg('m', [['lock', 'লক-অ্যান্ড-কি (ফিশার, 1894)'], ['fit', 'ইনডিউসড ফিট (কোশল্যান্ড, 1958)']], 'lock')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button><input type="range" class="fk-scrub" min="0" max="4.99" step=".01" value="0" data-k="scrub" aria-label="সময়"></div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 240, EX = 180, EY = 170;
    let m = 'lock', t = 0, C, svg, g, last = -1;
    const ST = ['এনজাইম (E) ও সাবস্ট্রেট (S)', 'সাবস্ট্রেট সক্রিয় স্থানের দিকে', 'এনজাইম-সাবস্ট্রেট জটিল (ES)', 'বিক্রিয়া — বন্ধন ভাঙে (EP)', 'উৎপাদ মুক্ত, এনজাইম অপরিবর্তিত'];
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'এনজাইমের কর্মপদ্ধতি' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); g = E('g', {}, svg); paint(); };
    const paint = () => {
      if (!g) return; g.innerHTML = '';
      const s = Math.min(4, Math.floor(t)), u = FK.ease(Math.min(1, t - s)), Re = BK.ramp(5), Rs = BK.ramp(0), Rp = BK.ramp(2);
      /* সক্রিয় স্থানের খাঁজ: লক মডেলে সবসময় V আকৃতি; ফিট মডেলে শুরুতে চওড়া U, ES এ সংকুচিত */
      const close = m === 'fit' ? (s < 1 ? 0 : s === 1 ? u * .6 : s < 4 ? .6 + (s === 2 ? u * .4 : .4) : 1 - u) : 1;
      const wTop = m === 'fit' ? 44 - 12 * close : 32, depth = 34;
      const d = `M${EX - 110} ${EY + 50}Q${EX - 120} ${EY - 40} ${EX - 60} ${EY - 46}L${EX - wTop} ${EY - 46}L${EX} ${EY - 46 + depth}L${EX + wTop} ${EY - 46}L${EX + 60} ${EY - 46}Q${EX + 120} ${EY - 40} ${EX + 110} ${EY + 50}Z`;
      E('path', { d, fill: BK.lg(svg, Re.lt, Re.c, { a: 90 }), stroke: Re.dk, 'stroke-width': 2 }, g);
      T(g, EX, EY + 30, 'এনজাইম (E)', { fs: 13, a: 'middle', w: 650, c: Re.ink });
      T(g, EX + 70, EY - 54, 'সক্রিয় স্থান', { fs: 10.5, w: 560, c: C.mu });
      /* সাবস্ট্রেট: দুই অংশের ত্রিভুজ (যুক্ত), বিক্রিয়ায় ভাগ হয় */
      const sy0 = EY - 52, sx = s === 0 ? 80 : s === 1 ? 80 + (EX - 80) * u : EX, sy = s === 0 ? 40 : s === 1 ? 40 + (sy0 - 40) * u : sy0;
      const split = s >= 3 ? (s === 3 ? u * 6 : 6) : 0, away = s === 4 ? u : 0;
      const tri = (dx, half, col) => {
        const cx = sx + dx, cy = sy;
        const pts = half < 0 ? [[cx - 2 - split, cy - 14], [cx - 30 - split, cy - 14], [cx - 2 - split, cy + 30]] : [[cx + 2 + split, cy - 14], [cx + 30 + split, cy - 14], [cx + 2 + split, cy + 30]];
        E('path', { d: 'M' + pts.map(p => p.join(' ')).join('L') + 'Z', fill: col.c, stroke: col.dk, 'stroke-width': 1.6, 'stroke-linejoin': 'round' }, g);
      };
      const leftCol = s >= 3 ? Rp : Rs, rightCol = s >= 3 ? Rp : Rs;
      const ox = away * 70, oy = -away * 60;
      g.appendChild(E('g', { transform: `translate(${-ox} ${oy})` })); tri.call(null, 0, -1, leftCol); const lastL = g.lastChild; const grp1 = g.children[g.children.length - 2]; grp1.appendChild(lastL);
      g.appendChild(E('g', { transform: `translate(${ox} ${oy})` })); tri.call(null, 0, 1, rightCol); const lastR = g.lastChild; const grp2 = g.children[g.children.length - 2]; grp2.appendChild(lastR);
      if (s < 3) T(g, sx, sy - 22, 'S', { fs: 13, a: 'middle', w: 700, c: Rs.ink });
      if (s >= 3) { T(g, sx - 18 - ox - split, sy - 22 + oy, 'P₁', { fs: 12.5, a: 'middle', w: 700, c: Rp.ink }); T(g, sx + 18 + ox + split, sy - 22 + oy, 'P₂', { fs: 12.5, a: 'middle', w: 700, c: Rp.ink }); }
      if (s === 3) { for (let i = 0; i < 6; i++) { const a = i * 1.05 + t * 3; E('circle', { cx: sx + 40 * Math.cos(a), cy: sy + 8 + 22 * Math.sin(a), r: 2.2, fill: BK.ramp(1).c, opacity: .8 }, g); } }
      if (m === 'fit' && s >= 1 && s <= 3) T(g, EX, 22, 'সক্রিয় স্থানের আকৃতি বদলাচ্ছে →', { fs: 11, a: 'middle', w: 600, c: Re.ink, st: `opacity:${Math.min(1, close)}` });
      $('scrub').value = t;
      if (s !== last) { last = s; $('info').innerHTML = `<span class="chip acc">${FK.bn(s + 1)}/৫</span> <b>${ST[s]}</b><div class="small">${m === 'lock' ? 'তালা-চাবির মতো — সক্রিয় স্থানের আকৃতি স্থির; কেবল মাপমতো সাবস্ট্রেটই বসে। এটি এনজাইমের সুনির্দিষ্টতা ব্যাখ্যা করে।' : 'হাতে দস্তানার মতো — সাবস্ট্রেট বসার সময় এনজাইমের আকৃতি পরিবর্তিত হয়ে শক্ত করে ধরে এবং বন্ধনে টান সৃষ্টি করে। হেক্সোকাইনেজে এটি দেখা গেছে; আধুনিক বিজ্ঞানে এটিই বেশি গ্রহণযোগ্য।'}</div>`; }
    };
    const A = X.anim(root, dt => { t += dt / 1.5; if (t >= 5.6) t = 0; paint(); }, { paused: true });
    X.pp(root, A);
    $('scrub').addEventListener('input', e => { t = +e.target.value; paint(); });
    X.onSeg(root, 'm', v => { m = v; t = 0; last = -1; paint(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();

/* ───────── হলোএনজাইম ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.holoenzyme = Object.assign({
  t: 'অ্যাপোএনজাইম + কো-ফ্যাক্টর = হলোএনজাইম', k: ['2d', 'anim', 'int'],
  cap: 'অনেক এনজাইমের প্রোটিন অংশ (অ্যাপোএনজাইম) একা নিষ্ক্রিয়; একটি অপ্রোটিন অংশ — কো-ফ্যাক্টর (ধাতব আয়ন বা জৈব কো-এনজাইম) — যুক্ত হলে সক্রিয় স্থান সম্পূর্ণ হয় এবং সক্রিয় হলোএনজাইম তৈরি হয়।'
}, BK.steps({
  W: 360, H: 220, label: 'হলোএনজাইম', dur: 2.6,
  stages: [
    { t: 'অ্যাপোএনজাইম (নিষ্ক্রিয়)', en: 'Apoenzyme', d: 'প্রোটিন অংশ; সক্রিয় স্থান অসম্পূর্ণ — সাবস্ট্রেট বসলেও বিক্রিয়া হয় না। তাপে নষ্ট হয় (তাপ-অস্থিতিশীল)।' },
    { t: 'কো-ফ্যাক্টর যুক্ত হয়', en: 'Cofactor binds', d: 'যেমন Zn²⁺ (কার্বনিক অ্যানহাইড্রেজ) বা NAD⁺ (ডিহাইড্রোজিনেজ)। কো-ফ্যাক্টর সাধারণত তাপে স্থিতিশীল।' },
    { t: 'হলোএনজাইম (সক্রিয়)', en: 'Holoenzyme', d: 'অ্যাপোএনজাইম + কো-ফ্যাক্টর = হলোএনজাইম। এখন সক্রিয় স্থান সম্পূর্ণ।' },
    { t: 'সাবস্ট্রেট বসে ও বিক্রিয়া', en: 'Catalysis', d: 'কো-ফ্যাক্টর ইলেকট্রন, পরমাণু বা গ্রুপ স্থানান্তরে সাহায্য করে — যেমন NAD⁺ সাবস্ট্রেট থেকে H নিয়ে NADH হয়।' }
  ],
  draw(g, C, s, u) {
    const Re = BK.ramp(5), Rc = BK.ramp(1), Rs = BK.ramp(0), Rp = BK.ramp(2);
    const ex = 180, ey = 150;
    E('path', { d: `M${ex - 100} ${ey + 40}Q${ex - 110} ${ey - 40} ${ex - 50} ${ey - 44}L${ex - 26} ${ey - 44}L${ex - 26} ${ey - 14}L${ex + 26} ${ey - 14}L${ex + 26} ${ey - 44}L${ex + 50} ${ey - 44}Q${ex + 110} ${ey - 40} ${ex + 100} ${ey + 40}Z`, fill: BK.lg(g.ownerSVGElement, Re.lt, Re.c, { a: 90 }), stroke: Re.dk, 'stroke-width': 2, opacity: s === 0 ? .65 : 1 }, g);
    T(g, ex, ey + 22, s < 2 ? 'অ্যাপোএনজাইম' : 'হলোএনজাইম', { fs: 13, a: 'middle', w: 650, c: Re.ink });
    /* কো-ফ্যাক্টর */
    const cy = s === 0 ? 40 : s === 1 ? 40 + (ey - 24 - 40) * u : ey - 24, cx = s === 0 ? 300 : s === 1 ? 300 + (ex - 300) * u : ex;
    E('circle', { cx, cy, r: 10, fill: Rc.c, stroke: Rc.dk, 'stroke-width': 1.6 }, g);
    T(g, cx, cy + 4, 'Zn²⁺', { fs: 8.5, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    if (s === 0) T(g, 300, 22, 'কো-ফ্যাক্টর', { fs: 11, a: 'middle', w: 600, c: Rc.ink });
    if (s === 0) T(g, ex, ey - 54, 'নিষ্ক্রিয়', { fs: 12, a: 'middle', w: 650, c: C.bad });
    if (s === 2) T(g, ex, ey - 54, 'সক্রিয়', { fs: 12, a: 'middle', w: 650, c: C.ok, st: `opacity:${u}` });
    if (s === 3) {
      const sy = 30 + (ey - 58 - 30) * Math.min(1, u * 2), done = u > .6;
      E('rect', { x: ex - 18, y: sy - 12, width: 36, height: 22, rx: 6, fill: done ? Rp.c : Rs.c, stroke: done ? Rp.dk : Rs.dk }, g);
      T(g, ex, sy + 3, done ? 'P' : 'S', { fs: 12, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
      if (done) T(g, ex + 70, ey - 54, 'উৎপাদ তৈরি', { fs: 11.5, w: 650, c: Rp.ink });
    }
    T(g, 14, 22, 'হলোএনজাইম = অ্যাপোএনজাইম + কো-ফ্যাক্টর', { fs: 11, w: 600, c: C.mu });
  }
}));

V.cofactorTree = Object.assign({
  t: 'কো-ফ্যাক্টরের প্রকারভেদ', k: ['tree', 'int'],
  cap: 'কো-ফ্যাক্টর অজৈব (ধাতব আয়ন) বা জৈব (কো-এনজাইম) হতে পারে; শক্তভাবে স্থায়ীভাবে যুক্ত থাকলে তাকে প্রোস্থেটিক গ্রুপ বলে। শাখায় চাপ দাও।'
}, BK.tree({
  t: 'কো-ফ্যাক্টর', en: 'Cofactor', d: 'এনজাইমের কাজের জন্য প্রয়োজনীয় অপ্রোটিন অংশ।',
  c: [
    { t: 'ধাতব আয়ন (অ্যাক্টিভেটর)', en: 'Metal ions', d: 'অজৈব কো-ফ্যাক্টর।', c: [
      { t: 'Mg²⁺', d: 'কাইনেজ এনজাইম (ATP এর সাথে), DNA পলিমারেজ।' }, { t: 'Zn²⁺', d: 'কার্বনিক অ্যানহাইড্রেজ, কার্বক্সিপেপটিডেজ, অ্যালকোহল ডিহাইড্রোজিনেজ।' },
      { t: 'Fe²⁺/Fe³⁺, Cu²⁺', d: 'সাইটোক্রোম, ক্যাটালেজ, সাইটোক্রোম অক্সিডেজ।' }, { t: 'Mo, Ni, Mn²⁺', d: 'নাইট্রোজিনেজ ও নাইট্রেট রিডাক্টেজ (Mo), ইউরিয়েজ (Ni), আর্জিনেজ (Mn)।' }] },
    { t: 'কো-এনজাইম', en: 'Coenzyme', d: 'ঢিলেভাবে যুক্ত জৈব অণু; অধিকাংশ ভিটামিন B থেকে তৈরি; বিক্রিয়ায় পরিবর্তিত হয়ে পরে পুনরুৎপন্ন হয়।', c: [
      { t: 'NAD⁺, NADP⁺', d: 'নায়াসিন (B₃) থেকে — ইলেকট্রন ও H বহন (ডিহাইড্রোজিনেজ)।' }, { t: 'FAD, FMN', d: 'রাইবোফ্লাভিন (B₂) থেকে — ইলেকট্রন বহন।' },
      { t: 'কো-এনজাইম A', d: 'প্যান্টোথেনিক অ্যাসিড (B₅) থেকে — অ্যাসাইল গ্রুপ বহন।' }, { t: 'TPP, PLP', d: 'থায়ামিন (B₁) — পাইরুভেট ডিহাইড্রোজিনেজ; পাইরিডক্সিন (B₆) — ট্রান্সঅ্যামিনেজ।' }] },
    { t: 'প্রোস্থেটিক গ্রুপ', en: 'Prosthetic group', d: 'শক্তভাবে (প্রায়ই সমযোজী বন্ধনে) স্থায়ীভাবে যুক্ত কো-ফ্যাক্টর।', c: [
      { t: 'হিম', d: 'সাইটোক্রোম, ক্যাটালেজ, পারঅক্সিডেজ।' }, { t: 'বায়োটিন', d: 'কার্বক্সিলেজ এনজাইমে।' }, { t: 'FAD (কিছু এনজাইমে)', d: 'সাকসিনেট ডিহাইড্রোজিনেজে শক্তভাবে যুক্ত।' }] }
  ]
}, { colW: 130 }));

V.enzClass = Object.assign({
  t: 'এনজাইমের শ্রেণিবিন্যাস (IUBMB)', k: ['tree', 'int'],
  cap: 'আন্তর্জাতিক জৈবরসায়ন ও আণবিক জীববিজ্ঞান ইউনিয়ন বিক্রিয়ার ধরন অনুযায়ী এনজাইমকে ভাগ করেছে (প্রতিটি এনজাইমের EC নম্বর)। দীর্ঘদিন 6টি শ্রেণি ছিল; 2018 সালে সপ্তম শ্রেণি — ট্রান্সলোকেজ — যুক্ত হয়।'
}, BK.tree({
  t: 'এনজাইম (EC)', en: 'Enzyme Commission', d: 'বিক্রিয়ার ধরন অনুযায়ী শ্রেণি।',
  c: [
    { t: '১. অক্সিডোরিডাক্টেজ', en: 'Oxidoreductase', d: 'জারণ-বিজারণ (ইলেকট্রন বা H স্থানান্তর): ডিহাইড্রোজিনেজ, অক্সিডেজ, ক্যাটালেজ, পারঅক্সিডেজ।' },
    { t: '২. ট্রান্সফারেজ', en: 'Transferase', d: 'একটি অণু থেকে আরেকটিতে গ্রুপ স্থানান্তর: কাইনেজ (ফসফেট), ট্রান্সঅ্যামিনেজ (অ্যামিনো গ্রুপ)।' },
    { t: '৩. হাইড্রোলেজ', en: 'Hydrolase', d: 'পানি যোগ করে বন্ধন ভাঙে: অ্যামাইলেজ, লাইপেজ, পেপসিন, ট্রিপসিন, ইউরিয়েজ — পরিপাকের প্রায় সব এনজাইম।' },
    { t: '৪. লায়েজ', en: 'Lyase', d: 'পানি বা জারণ ছাড়াই বন্ধন ভাঙে বা দ্বিবন্ধনে গ্রুপ যোগ করে: অ্যালডোলেজ, ডিকার্বক্সিলেজ, ফিউমারেজ, কার্বনিক অ্যানহাইড্রেজ।' },
    { t: '৫. আইসোমারেজ', en: 'Isomerase', d: 'অণুর ভেতরে পুনর্বিন্যাস — সমাণু তৈরি: ফসফোহেক্সোজ আইসোমারেজ, ট্রায়োজ ফসফেট আইসোমারেজ, মিউটেজ।' },
    { t: '৬. লাইগেজ', en: 'Ligase', d: 'ATP ব্যবহার করে দুটি অণু জোড়া লাগায়: DNA লাইগেজ, পাইরুভেট কার্বক্সিলেজ, অ্যামিনোঅ্যাসাইল-tRNA সিনথেটেজ।' },
    { t: '৭. ট্রান্সলোকেজ', en: 'Translocase', d: 'ঝিল্লির এক পাশ থেকে আরেক পাশে আয়ন বা অণু স্থানান্তর (2018 সালে যুক্ত) — যেমন ATP সিনথেজ।' }
  ]
}, { colW: 134, collapse: false }));

V.enzUses = Object.assign({
  t: 'এনজাইমের ব্যবহার', k: ['mind', 'int'],
  cap: 'দেহের ভেতরে প্রতিটি বিপাকীয় ধাপে, আর বাইরে খাদ্য, শিল্প, চিকিৎসা ও জীবপ্রযুক্তিতে এনজাইম। পাতায় চাপ দাও।'
}, BK.mind({
  t: 'এনজাইমের ব্যবহার', d: 'জৈব অনুঘটক — দেহে ও দেহের বাইরে।',
  c: [
    { t: 'দেহে', d: 'জীবনের প্রতিটি রাসায়নিক বিক্রিয়ায়।', c: [{ t: 'পরিপাক', d: 'অ্যামাইলেজ, পেপসিন, ট্রিপসিন, লাইপেজ।' }, { t: 'শ্বসন ও সালোকসংশ্লেষণ', d: 'ডিহাইড্রোজিনেজ, ATP সিনথেজ, রুবিস্কো।' }, { t: 'DNA রেপ্লিকেশন', d: 'হেলিকেজ, DNA পলিমারেজ, লাইগেজ।' }] },
    { t: 'খাদ্যশিল্প', d: 'প্রক্রিয়াকরণ ও মান উন্নয়ন।', c: [{ t: 'রেনিন (কাইমোসিন)', d: 'দুধ জমিয়ে পনির।' }, { t: 'প্যাপেইন ও ব্রোমেলিন', d: 'কাঁচা পেঁপে ও আনারস — মাংস নরম করে।' }, { t: 'পেকটিনেজ', d: 'ফলের রস স্বচ্ছ করে।' }, { t: 'ল্যাকটেজ', d: 'ল্যাকটোজমুক্ত দুধ।' }, { t: 'অ্যামাইলেজ', d: 'রুটি, মদ্যশিল্প, গ্লুকোজ সিরাপ।' }] },
    { t: 'শিল্প', d: 'রাসায়নিকের পরিবেশবান্ধব বিকল্প।', c: [{ t: 'ডিটারজেন্ট', d: 'প্রোটিয়েজ ও লাইপেজ — রক্ত ও তেলের দাগ তোলে।' }, { t: 'বস্ত্র ও চামড়া', d: 'অ্যামাইলেজে মাড় তোলা, সেলুলেজে "স্টোন-ওয়াশ" জিন্স, প্রোটিয়েজে চামড়া নরম।' }, { t: 'জৈব জ্বালানি', d: 'সেলুলেজ ও অ্যামাইলেজে বায়োইথানল।' }] },
    { t: 'চিকিৎসা', d: 'রোগনির্ণয় ও চিকিৎসা।', c: [{ t: 'গ্লুকোজ অক্সিডেজ', d: 'গ্লুকোমিটারের স্ট্রিপে রক্তশর্করা মাপা।' }, { t: 'ALT, AST, CK-MB', d: 'রক্তে বাড়লে যকৃৎ বা হৃৎপেশির ক্ষতির সংকেত।' }, { t: 'স্ট্রেপটোকাইনেজ', d: 'হার্ট অ্যাটাকে রক্তের জমাট গলায়।' }] },
    { t: 'জীবপ্রযুক্তি', d: 'জিন প্রকৌশল ও পরীক্ষা।', c: [{ t: 'রেস্ট্রিকশন এনজাইম', d: 'DNA নির্দিষ্ট স্থানে কাটে — "আণবিক কাঁচি"।' }, { t: 'DNA লাইগেজ', d: 'DNA জোড়া লাগায় — "আণবিক আঠা"।' }, { t: 'Taq পলিমারেজ', d: 'উষ্ণ প্রস্রবণের ব্যাকটেরিয়া থেকে — PCR এ উচ্চ তাপে কাজ করে।' }] }
  ]
}));

V.cmpEnzCoenz = Object.assign({ t: 'এনজাইম ও কো-এনজাইমের পার্থক্য', k: ['cmp', 'int'], cap: 'সারণি দেখো, তারপর যাচাই খেলা।' }, BK.compare({
  a: 'এনজাইম', b: 'কো-এনজাইম',
  rows: [
    ['প্রকৃতি', 'প্রধানত প্রোটিন (ব্যতিক্রম রাইবোজাইম — RNA)', 'অপ্রোটিন জৈব অণু'],
    ['আণবিক ভর', 'অনেক বেশি (হাজার থেকে লক্ষ ডাল্টন)', 'কম'],
    ['উৎস', 'জিন-নির্দেশিত, কোষে সংশ্লেষিত', 'অধিকাংশ ভিটামিন B থেকে তৈরি'],
    ['তাপে', 'সহজে ডিন্যাচার হয় (তাপ-অস্থিতিশীল)', 'সাধারণত তাপ-স্থিতিশীল'],
    ['সুনির্দিষ্টতা', 'অত্যন্ত সুনির্দিষ্ট', 'একই কো-এনজাইম বহু এনজাইমের সাথে কাজ করে'],
    ['বিক্রিয়ায়', 'অপরিবর্তিত থাকে', 'পরিবর্তিত হয় (যেমন NAD⁺ → NADH), পরে পুনরুৎপন্ন'],
    ['উদাহরণ', 'অ্যামাইলেজ, পেপসিন, ক্যাটালেজ', 'NAD⁺, FAD, কো-এনজাইম A']
  ]
}));
V.cmpEnzCat = Object.assign({ t: 'এনজাইম ও অজৈব অনুঘটকের পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই সক্রিয়ন শক্তি কমায় ও বিক্রিয়া শেষে অপরিবর্তিত থাকে — কিন্তু আচরণে বিশাল পার্থক্য।' }, BK.compare({
  a: 'এনজাইম (জৈব অনুঘটক)', b: 'অজৈব অনুঘটক',
  rows: [
    ['প্রকৃতি', 'প্রোটিন, জীবকোষে তৈরি', 'ধাতু বা অজৈব যৌগ (Pt, Ni, MnO₂, Fe)'],
    ['আণবিক আকার', 'বিশাল, জটিল ত্রিমাত্রিক গঠন', 'ছোট, সরল'],
    ['সুনির্দিষ্টতা', 'অত্যন্ত — নির্দিষ্ট সাবস্ট্রেট ও বিক্রিয়া', 'কম — বহু বিক্রিয়ায় কাজ করে'],
    ['কার্যক্ষমতা', 'অনেক বেশি; বিক্রিয়ার হার 10⁶–10¹⁷ গুণ', 'তুলনামূলক কম'],
    ['কাজের পরিবেশ', 'মৃদু — দেহের তাপমাত্রা, নিরপেক্ষ pH, স্বাভাবিক চাপ', 'প্রায়ই উচ্চ তাপ ও চাপ লাগে'],
    ['তাপ ও pH', 'অত্যন্ত সংবেদনশীল; বেশি তাপে নষ্ট', 'সাধারণত প্রভাব কম'],
    ['নিয়ন্ত্রণ', 'নিয়ন্ত্রণযোগ্য — প্রতিরোধক, সক্রিয়ক, অ্যালোস্টেরিক নিয়ন্ত্রণ', 'নিয়ন্ত্রণ করা যায় না'],
    ['প্রতিরোধক', 'নির্দিষ্ট প্রতিরোধকে বাধাপ্রাপ্ত', 'বিষাক্ত পদার্থে "বিষাক্ত" হতে পারে, তবে নির্দিষ্টতা নেই']
  ]
}));
})();

/* ───────── বিক্রিয়ার হার বনাম সাবস্ট্রেট ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const INH = { none: ['প্রতিরোধক নেই', 1, 1], comp: ['প্রতিযোগিতামূলক', 3, 1], non: ['অপ্রতিযোগিতামূলক', 1, .5] };   /* [নাম, Km গুণক, Vmax গুণক] */
V.enzKinetics = {
  t: 'সাবস্ট্রেটের ঘনত্ব, বিক্রিয়ার হার ও প্রতিরোধক', k: ['graph', 'anim', 'int'],
  cap: 'উপরে: প্রতিটি "প্যাকম্যান" একটি এনজাইম; সাবস্ট্রেট বাড়ালে ব্যস্ত এনজাইমের সংখ্যা বাড়ে, সব এনজাইম ব্যস্ত হলে (সম্পৃক্ত) হার আর বাড়ে না — Vmax। নিচে মাইকেলিস-মেনটেন বক্ররেখা: v = Vmax·[S] ÷ (Km + [S]); Km হলো যে [S] এ হার Vmax এর অর্ধেক। প্রতিরোধক বদলে দেখো — প্রতিযোগিতামূলকে Km বাড়ে কিন্তু Vmax একই; অপ্রতিযোগিতামূলকে Vmax কমে কিন্তু Km একই।',
  html: () => `<div class="fk-row">${X.seg('inh', Object.keys(INH).map(k => [k, INH[k][0]]), 'none')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.sl('S', '[S] (সাবস্ট্রেট)', 0, 50, .5, 5, '')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 300;
    const KM = 5, VM = 100, GX = 46, GY = 270, GW = 296, GH = 140;
    let inh = 'none', S = 5, C, svg, curves = {}, dot, vline, enzG, subs = [], enz = [], tt = 0, last = '';
    const v = (s, k) => { const [, a, b] = INH[k]; return VM * b * s / (KM * a + s); };
    const px = s => GX + s / 50 * GW, py = r => GY - r / 110 * GH;
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'এনজাইমের গতিবিদ্যা' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      /* কণা-দৃশ্য */
      E('rect', { x: 10, y: 10, width: W - 20, height: 92, rx: 10, fill: C.s2, stroke: C.ln }, svg);
      enzG = E('g', {}, svg); enz = []; subs = [];
      for (let i = 0; i < 6; i++) { const x = 40 + i * 54, y = 56; const gg = E('g', { transform: `translate(${x} ${y})` }, enzG); E('path', { d: 'M0 0L16 -10A19 19 0 1 0 16 10Z', fill: BK.ramp(5).c, stroke: BK.ramp(5).dk, 'stroke-width': 1.2 }, gg); const sb = E('circle', { cx: 9, cy: 0, r: 5, fill: BK.ramp(0).c, opacity: 0 }, gg); enz.push({ x, y, sb, busy: 0, ph: i * .37 }); }
      for (let i = 0; i < 40; i++) subs.push({ el: E('circle', { r: 3.2, fill: BK.ramp(0).c, opacity: 0 }, svg), x: 20 + Math.random() * 320, y: 18 + Math.random() * 76, vx: (Math.random() - .5) * 40, vy: (Math.random() - .5) * 30 });
      /* লেখচিত্র */
      E('path', { d: `M${GX} ${GY - GH - 6}V${GY}H${GX + GW}`, stroke: C.mu, 'stroke-width': 1.4, fill: 'none' }, svg);
      T(svg, GX - 6, GY - GH + 4, 'v', { fs: 12, a: 'end', w: 650, c: C.mu }); T(svg, GX + GW, GY + 18, '[S]', { fs: 11.5, a: 'end', w: 600, c: C.mu });
      E('path', { d: `M${GX} ${py(VM)}H${GX + GW}`, stroke: C.mu, 'stroke-width': 1, 'stroke-dasharray': '4 4' }, svg); T(svg, GX + 4, py(VM) - 4, 'Vmax', { fs: 10.5, w: 600, c: C.mu });
      Object.keys(INH).forEach((k, i) => { const pts = []; for (let j = 0; j <= 80; j++) { const s = j / 80 * 50; pts.push(`${px(s).toFixed(1)} ${py(v(s, k)).toFixed(1)}`); } curves[k] = E('path', { d: 'M' + pts.join('L'), stroke: BK.ramp([2, 0, 7][i]).c, 'stroke-width': 2.6, fill: 'none' }, svg); });
      curves.km = E('path', { stroke: BK.ramp(9).c, 'stroke-width': 1.2, 'stroke-dasharray': '3 3', fill: 'none' }, svg); curves.kmT = T(svg, 0, 0, '', { fs: 10.5, a: 'middle', w: 650, c: BK.ramp(9).ink });
      vline = E('path', { stroke: C.fg, 'stroke-width': 1, 'stroke-dasharray': '2 3' }, svg); dot = E('circle', { r: 5.5, fill: C.fg, stroke: C.sf, 'stroke-width': 1.5 }, svg);
      paint(); step(0);
    };
    const paint = () => {
      const [, a, b] = INH[inh], km = KM * a, r = v(S, inh);
      Object.keys(INH).forEach(k => curves[k].setAttribute('opacity', k === inh ? 1 : .22));
      curves.km.setAttribute('d', `M${GX} ${py(VM * b / 2)}H${px(km)}V${GY}`); curves.kmT.setAttribute('x', px(km)); curves.kmT.setAttribute('y', GY + 14); curves.kmT.textContent = 'Km';
      vline.setAttribute('d', `M${px(S)} ${GY}V${py(r)}`); dot.setAttribute('cx', px(S)); dot.setAttribute('cy', py(r));
      const inf = `[S] = ${S}, হার v ≈ <b>${r.toFixed(0)}%</b> (সর্বোচ্চের)। Km = ${km}, Vmax = ${VM * b}%।<div class="small">${inh === 'comp' ? 'প্রতিযোগিতামূলক প্রতিরোধক সাবস্ট্রেটের মতো দেখতে, সক্রিয় স্থান দখলের জন্য প্রতিযোগিতা করে; সাবস্ট্রেট অনেক বাড়ালে প্রতিরোধককে হটিয়ে আবার Vmax এ পৌঁছানো যায়। উদাহরণ: সাকসিনেট ডিহাইড্রোজিনেজে ম্যালোনেট।' : inh === 'non' ? 'অপ্রতিযোগিতামূলক প্রতিরোধক সক্রিয় স্থানের বাইরে অন্য জায়গায় যুক্ত হয়ে এনজাইমের আকৃতি বদলায়; সাবস্ট্রেট বাড়িয়েও Vmax ফেরে না। উদাহরণ: ভারী ধাতুর আয়ন (Hg²⁺, Pb²⁺)।' : S > 4 * KM ? 'প্রায় সব এনজাইম ব্যস্ত — সম্পৃক্ত অবস্থা; এখন হার বাড়াতে এনজাইম বাড়াতে হবে।' : 'কম [S] এ হার প্রায় [S] এর সমানুপাতিক — খালি এনজাইম অনেক।'}</div>`;
      if (inf !== last) { $('info').innerHTML = inf; last = inf; }
    };
    const step = dt => {
      tt += dt;
      const [, a, b] = INH[inh], occ = S / (KM * a + S), n = Math.round(Math.min(40, S * .8 + (S > 0 ? 2 : 0)));
      subs.forEach((p, i) => { const on = i < n; if (on) { p.x += p.vx * dt; p.y += p.vy * dt; if (p.x < 16 || p.x > 344) p.vx *= -1; if (p.y < 16 || p.y > 96) p.vy *= -1; } p.el.setAttribute('cx', p.x.toFixed(1)); p.el.setAttribute('cy', p.y.toFixed(1)); p.el.setAttribute('opacity', on ? .85 : 0); });
      /* কতগুলো এনজাইম ব্যস্ত — দখলের ভগ্নাংশ অনুযায়ী (অপ্রতিযোগিতামূলকে অর্ধেক এনজাইম অচল) */
      const active = inh === 'non' ? 3 : 6, busy = Math.round(occ * active);
      enz.forEach((e, i) => { const dead = i >= active; const isBusy = !dead && i < busy; const blink = isBusy ? (Math.sin(tt * 6 + e.ph * 10) > -.6 ? 1 : 0) : 0; e.sb.setAttribute('opacity', blink); e.sb.setAttribute('fill', inh === 'comp' && !isBusy && i % 3 === 2 ? BK.ramp(7).c : BK.ramp(0).c); if (inh === 'comp' && !isBusy && i % 3 === 2) e.sb.setAttribute('opacity', .9); e.sb.parentNode.setAttribute('opacity', dead ? .35 : 1); });
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    FK.bindSl(root, 'S', x => { S = x; paint(); step(0); }, '', 1);
    X.onSeg(root, 'inh', k => { inh = k; paint(); step(0); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();
