/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §৩.৩ লিপিড
   fattyAcid    : ফ্যাটি অ্যাসিডের শিকল (সম্পৃক্ত, cis, trans) + তাপমাত্রা স্লাইডারে কঠিন ↔ তরল (অ্যানিমেটেড)
   fatMelt      : একই চিত্র, "অনেক অণু" দৃশ্য দিয়ে শুরু
   triglyceride : গ্লিসারল + 3 ফ্যাটি অ্যাসিড → ট্রাইগ্লিসারাইড, তারপর সাবানীকরণ (ধাপে ধাপে)
   phospholipid : একটি ফসফোলিপিড ↔ দ্বিস্তর ঝিল্লি ↔ মাইসেল (নড়াচড়া করা অণু)
   lipidProfile : লিপিড প্রোফাইল ক্যালকুলেটর (ফ্রিডওয়াল্ড সূত্রে LDL)
   lipidClass   : লিপিডের শ্রেণিবিভাগ — গাছ
   cmpFatOil    : চর্বি ও তেল — পার্থক্য
   oxyBars      : অক্সিজেনের ভর % — গ্লুকোজ বনাম ট্রাইপালমিটিন বনাম কোলেস্টেরল
   lipidRoles   : লিপিডের ভূমিকা — মাইন্ড ম্যাপ
   গলনাঙ্ক (Lehninger): পালমিটিক 63.1, স্টিয়ারিক 69.6, ওলেইক 13.4, লিনোলেইক −5 °C; ইলাইডিক (trans) প্রায় 45 °C
   O%: Python — গ্লুকোজ 53.3, ট্রাইপালমিটিন 11.9, কোলেস্টেরল 4.1
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* [নাম, সংকেত, কার্বন, দ্বিবন্ধন অবস্থান তালিকা, cis?, গলনাঙ্ক, তথ্য] */
const FA = {
  pal: ['পালমিটিক অ্যাসিড', 'C16:0', 16, [], true, 63, 'সম্পৃক্ত — কোনো দ্বিবন্ধন নেই; পাম তেল ও প্রাণিজ চর্বিতে বেশি।'],
  ste: ['স্টিয়ারিক অ্যাসিড', 'C18:0', 18, [], true, 70, 'সম্পৃক্ত; গরু-খাসির চর্বিতে বেশি।'],
  ole: ['ওলেইক অ্যাসিড', 'C18:1 cis-9', 18, [9], true, 13, 'একটি cis দ্বিবন্ধনে শিকল প্রায় 30° বেঁকে যায় — অলিভ ও সরিষার তেলে।'],
  lin: ['লিনোলেইক অ্যাসিড', 'C18:2 cis-9,12', 18, [9, 12], true, -5, 'অত্যাবশ্যকীয় (ω-6) — দেহ তৈরি করতে পারে না; সয়াবিন ও সূর্যমুখী তেলে।'],
  ela: ['ইলাইডিক অ্যাসিড (ট্রান্স)', 'C18:1 trans-9', 18, [9], false, 45, 'trans দ্বিবন্ধনে শিকল প্রায় সোজা থাকে — সম্পৃক্তের মতো ঘন সাজে; হাইড্রোজেনেটেড তেলে (ডালডা) তৈরি হয়, হৃদ্‌রোগের ঝুঁকি বাড়ায়।']
};
/* শিকলের বিন্দু: মাথা থেকে লেজ পর্যন্ত, cis দ্বিবন্ধনে বাঁক */
const chainPts = (fa, x0, y0, ang0, L = 9.2) => {
  const P = [[x0, y0]]; let ang = ang0;
  for (let i = 1; i < fa[2]; i++) {
    if (fa[4] && fa[3].includes(i)) ang += .55;               /* cis বাঁক */
    const zig = (i % 2 ? 1 : -1) * .52;
    const [px, py] = P[P.length - 1];
    P.push([px + L * Math.cos(ang + zig), py + L * Math.sin(ang + zig)]);
  }
  return P;
};
const faVis = startMode => ({
  t: 'ফ্যাটি অ্যাসিড: সম্পৃক্ত, অসম্পৃক্ত ও ট্রান্স', k: ['2d', 'anim', 'int'],
  cap: 'শিকলের প্রতিটি কোণ একটি কার্বন। "অনেক অণু" দৃশ্যে তাপমাত্রা বাড়িয়ে দেখো: সোজা শিকল ঘনভাবে সাজে বলে গলাতে বেশি তাপ লাগে (চর্বি — কঠিন); cis বাঁকা শিকল কাছাকাছি বসতে পারে না, তাই কম তাপেই তরল (তেল)।',
  html: () => `<div class="fk-row">${X.seg('fa', Object.keys(FA).map(k => [k, FA[k][0].split(' ')[0]]), 'pal')}</div>
    <div class="fk-row">${X.seg('vm', [['one', 'একটি অণু'], ['pack', 'অনেক অণু']], startMode)}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.sl('T', 'তাপমাত্রা', -10, 80, 1, 25, ' °C')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250;
    let key = 'pal', vm = startMode, Tc = 25, C, svg, g, mols = [], tt = 0, last = '';
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'ফ্যাটি অ্যাসিড' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); g = E('g', {}, svg); build(); };
    const build = () => {
      g.innerHTML = ''; mols = [];
      const fa = FA[key], Rh = BK.ramp(4), Rt = BK.ramp(1), Rd = BK.ramp(0);
      if (vm === 'one') {
        const P = chainPts(fa, 60, 60, Math.PI / 2 - .08, 9.6);
        const gg = E('g', {}, g);
        E('path', { d: 'M' + P.map(p => p.join(' ')).join('L'), stroke: Rt.dk, 'stroke-width': 3, fill: 'none', 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, gg);
        fa[3].forEach(i => { const a = P[i - 1], b = P[i]; const nx = -(b[1] - a[1]), ny = b[0] - a[0], l = Math.hypot(nx, ny); E('path', { d: `M${a[0] + nx / l * 4} ${a[1] + ny / l * 4}L${b[0] + nx / l * 4} ${b[1] + ny / l * 4}`, stroke: Rd.c, 'stroke-width': 3 }, gg); T(gg, b[0] + 12, b[1] + 4, fa[4] ? 'cis' : 'trans', { fs: 11, w: 650, c: Rd.ink }); });
        E('circle', { cx: 60, cy: 48, r: 14, fill: FK.alpha(Rh.c, .25), stroke: Rh.c, 'stroke-width': 1.6 }, gg);
        T(gg, 60, 52, 'COOH', { fs: 9.5, a: 'middle', w: 650, c: Rh.ink });
        T(gg, 82, 40, 'পানিপ্রিয় মাথা (কার্বক্সিল)', { fs: 10.5, w: 560, c: C.mu });
        const tl = P[P.length - 1]; T(gg, tl[0] + 10, tl[1] + 4, 'CH₃ — পানিবিদ্বেষী লেজ', { fs: 10.5, w: 560, c: C.mu });
        T(gg, W - 12, 24, fa[0], { fs: 13, a: 'end', w: 650 }); T(gg, W - 12, 42, fa[1], { fs: 11.5, a: 'end', w: 560, c: C.mu });
        mols.push({ g: gg, x: 0, y: 0, ph: 0 });
      } else {
        const n = 7;
        for (let i = 0; i < n; i++) {
          const gg = E('g', {}, g), P = chainPts(fa, 0, 0, Math.PI / 2, 8.2);
          E('path', { d: 'M' + P.map(p => p.join(' ')).join('L'), stroke: Rt.dk, 'stroke-width': 2.4, fill: 'none', 'stroke-linejoin': 'round' }, gg);
          E('circle', { cx: 0, cy: -6, r: 8, fill: FK.alpha(Rh.c, .3), stroke: Rh.c }, gg);
          mols.push({ g: gg, x: 0, y: 0, ph: i * 1.7, i });
        }
      }
      tt = 0; step(0);
    };
    const step = dt => {
      tt += dt;
      const fa = FA[key], liquid = Tc > fa[5], heat = Math.max(0, (Tc + 10) / 90);
      if (vm === 'one') {
        const a = 1.2 * Math.sin(tt * 3) * heat; mols[0].g.setAttribute('transform', `rotate(${a.toFixed(2)} 60 48)`);
      } else {
        const bent = fa[4] && fa[3].length;
        const gap = bent ? 44 : 28, x0 = W / 2 - gap * 3, amp = liquid ? 16 : 1.5 * heat;
        mols.forEach(m => {
          const k = m.i, dx = amp * Math.sin(tt * (liquid ? 2.3 : 6) + m.ph), dy = amp * .8 * Math.cos(tt * (liquid ? 1.9 : 5) + m.ph * 1.3), rot = liquid ? 14 * Math.sin(tt * 1.4 + m.ph) : 0;
          const x = x0 + k * gap + dx + (liquid ? (k - 3) * 6 : 0), y = 60 + dy;
          m.g.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot.toFixed(1)})`);
        });
      }
      const inf = vm === 'one'
        ? `<b>${fa[0]}</b> (${fa[1]}) — ${fa[6]}<div class="small">গলনাঙ্ক প্রায় ${fa[5]} °C।</div>`
        : `<b>${fa[0]}</b>: গলনাঙ্ক প্রায় ${fa[5]} °C → ${Tc} °C এ <b>${liquid ? 'তরল' : 'কঠিন'}</b>।<div class="small">${fa[4] && fa[3].length ? 'বাঁকা শিকল ঘনভাবে সাজতে পারে না — অণুগুলোর মধ্যে আকর্ষণ (ভ্যান ডার ওয়ালস) দুর্বল।' : 'সোজা শিকল একটির গায়ে আরেকটি শুয়ে থাকে — আকর্ষণ বেশি, গলাতে বেশি তাপ লাগে।'}</div>`;
      if (inf !== last) { $('info').innerHTML = inf; last = inf; }
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    FK.bindSl(root, 'T', v => { Tc = v; step(0); }, ' °C', 0);
    X.onSeg(root, 'fa', v => { key = v; build(); });
    X.onSeg(root, 'vm', v => { vm = v; build(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
V.fattyAcid = faVis('one');
V.fatMelt = Object.assign(faVis('pack'), { t: 'চর্বি কঠিন, তেল তরল — কেন?' });

/* ───────── শ্রেণিবিভাগ, পার্থক্য, স্তম্ভ, মাইন্ড ম্যাপ ───────── */
V.lipidClass = Object.assign({
  t: 'লিপিডের শ্রেণিবিভাগ (ব্লুর)', k: ['tree', 'int'],
  cap: 'গঠন-উপাদান অনুযায়ী তিন ভাগ। শাখায় চাপ দিলে উদাহরণ।'
}, BK.tree({
  t: 'লিপিড', en: 'Lipid', d: 'পানিতে অদ্রবণীয়, অপোলার দ্রাবকে দ্রবণীয় জৈব যৌগ।',
  c: [
    { t: 'সরল লিপিড', en: 'Simple', d: 'ফ্যাটি অ্যাসিড + অ্যালকোহলের এস্টার।', c: [
      { t: 'চর্বি ও তেল', d: 'গ্লিসারল + 3 ফ্যাটি অ্যাসিড = ট্রাইগ্লিসারাইড।' },
      { t: 'মোম', d: 'ফ্যাটি অ্যাসিড + দীর্ঘ শিকলের অ্যালকোহল — মৌমাছির মোম, পাতার কিউটিকল, কানের খোল।' }] },
    { t: 'যৌগিক লিপিড', en: 'Compound', d: 'ফ্যাটি অ্যাসিড + অ্যালকোহল + অন্য গ্রুপ।', c: [
      { t: 'ফসফোলিপিড', d: 'ফসফেট গ্রুপযুক্ত: লেসিথিন (কোলিন), সেফালিন, স্ফিঙ্গোমায়েলিন — কোষঝিল্লি ও মায়েলিন।' },
      { t: 'গ্লাইকোলিপিড', d: 'শর্করাযুক্ত: সেরিব্রোসাইড, গ্যাংলিওসাইড — স্নায়ুকলা, কোষের পরিচয়।' },
      { t: 'লাইপোপ্রোটিন', d: 'প্রোটিনযুক্ত: কাইলোমাইক্রন, VLDL, LDL, HDL — রক্তে লিপিড পরিবহন।' }] },
    { t: 'উদ্ভূত লিপিড', en: 'Derived', d: 'সরল ও যৌগিক লিপিডের আর্দ্রবিশ্লেষণে পাওয়া বা লিপিডের মতো আচরণ করা যৌগ।', c: [
      { t: 'ফ্যাটি অ্যাসিড ও গ্লিসারল', d: 'ট্রাইগ্লিসারাইডের উপাদান।' },
      { t: 'স্টেরয়েড', d: '4টি যুক্ত বলয়: কোলেস্টেরল, ইস্ট্রোজেন, টেস্টোস্টেরন, কর্টিসল, ভিটামিন D, পিত্ত অ্যাসিড।' },
      { t: 'টারপিন', d: 'আইসোপ্রিন একক: ক্যারোটিন, ভিটামিন A, E, K, প্রাকৃতিক রাবার, সুগন্ধি তেল।' },
      { t: 'প্রোস্টাগ্ল্যান্ডিন', d: 'অ্যারাকিডোনিক অ্যাসিড থেকে — প্রদাহ, ব্যথা ও জ্বরের সংকেত।' }] }
  ]
}, { colW: 128 }));

V.cmpFatOil = Object.assign({ t: 'চর্বি ও তেলের পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই ট্রাইগ্লিসারাইড; পার্থক্য ফ্যাটি অ্যাসিডের ধরনে।' }, BK.compare({
  a: 'চর্বি (Fat)', b: 'তেল (Oil)',
  rows: [
    ['ঘরের তাপমাত্রায় (20–25 °C)', 'কঠিন', 'তরল'],
    ['প্রধান ফ্যাটি অ্যাসিড', 'সম্পৃক্ত (পালমিটিক, স্টিয়ারিক)', 'অসম্পৃক্ত (ওলেইক, লিনোলেইক)'],
    ['শিকলের আকৃতি', 'সোজা — ঘনভাবে সাজে', 'cis দ্বিবন্ধনে বাঁকা — ঢিলেভাবে সাজে'],
    ['গলনাঙ্ক', 'বেশি', 'কম'],
    ['আয়োডিন মান', 'কম', 'বেশি'],
    ['সাধারণ উৎস', 'প্রাণিজ (ঘি, মাখন, চর্বি) — ব্যতিক্রম নারকেল ও পাম তেল (সম্পৃক্ত)', 'উদ্ভিজ্জ (সয়াবিন, সরিষা) ও মাছের তেল'],
    ['হৃদ্‌স্বাস্থ্যে', 'বেশি খেলে LDL বাড়ায়', 'অসম্পৃক্ত তেল তুলনামূলক উপকারী']
  ]
}));

V.oxyBars = Object.assign({
  t: 'অণুতে অক্সিজেনের ভর-শতাংশ', k: ['graph', 'int'],
  cap: 'লিপিডে O অনেক কম, C–H বন্ধন অনেক বেশি — অর্থাৎ লিপিড আগে থেকেই কম জারিত। তাই সম্পূর্ণ জারণে প্রতি গ্রামে শর্করার দ্বিগুণের বেশি শক্তি দেয়। (Python দিয়ে হিসাব করা)'
}, BK.bars({
  title: 'O এর ভর % (অণুর মোট ভরের)', unit: '%', d: 1, labW: 122, max: 60,
  items: [['গ্লুকোজ C₆H₁₂O₆', 53.3, null, 'ভর 180.2; প্রতি গ্রামে প্রায় 4 kcal।'], ['ট্রাইপালমিটিন C₅₁H₉₈O₆', 11.9, null, 'একটি সাধারণ চর্বি; ভর 807.3; প্রতি গ্রামে প্রায় 9 kcal।'], ['কোলেস্টেরল C₂₇H₄₆O', 4.1, null, 'স্টেরয়েড; শক্তির উৎস হিসেবে ব্যবহৃত হয় না — গঠন ও হরমোনের কাঁচামাল।']]
}));

V.lipidRoles = Object.assign({
  t: 'জীবদেহে লিপিডের ভূমিকা', k: ['mind', 'int'],
  cap: 'শক্তি সঞ্চয় থেকে হরমোন — লিপিডের বহুমুখী কাজ। পাতায় চাপ দাও।'
}, BK.mind({
  t: 'লিপিডের ভূমিকা', d: 'পানিবিদ্বেষী অণুর বিশেষ সুবিধা।',
  c: [
    { t: 'শক্তি সঞ্চয়', d: 'প্রতি গ্রামে প্রায় 9 kcal (37 kJ)।', c: [{ t: 'চর্বিকলা', d: 'অ্যাডিপোজ কোষে ট্রাইগ্লিসারাইড।' }, { t: 'বীজের তেল', d: 'সরিষা, সূর্যমুখী, চিনাবাদাম।' }, { t: 'বিপাকীয় পানি', d: 'উটের কুঁজের চর্বি জারণে প্রতি গ্রামে প্রায় 1.1 g পানি।' }] },
    { t: 'গঠন', d: 'ঝিল্লি ও আবরণ।', c: [{ t: 'ফসফোলিপিড দ্বিস্তর', d: 'সব কোষঝিল্লির ভিত্তি।' }, { t: 'কোলেস্টেরল', d: 'প্রাণিকোষের ঝিল্লির তারল্য নিয়ন্ত্রণ।' }, { t: 'মায়েলিন আবরণ', d: 'স্নায়ু উদ্দীপনা দ্রুত করে।' }] },
    { t: 'সুরক্ষা ও অন্তরণ', d: 'তাপ ও আঘাত থেকে।', c: [{ t: 'ত্বকের নিচের চর্বি', d: 'তাপ অন্তরক; তিমির ব্লাবার।' }, { t: 'অঙ্গের চারপাশে', d: 'বৃক্ক ও হৃৎপিণ্ডের গদি।' }, { t: 'মোম', d: 'পাতার কিউটিকল ও পাখির পালক পানিরোধী।' }] },
    { t: 'হরমোন ও সংকেত', d: 'স্টেরয়েড ও প্রোস্টাগ্লান্ডিন।', c: [{ t: 'যৌন হরমোন', d: 'ইস্ট্রোজেন, টেস্টোস্টেরন।' }, { t: 'কর্টিসল ও অ্যালডোস্টেরন', d: 'বিপাক ও লবণ-পানি নিয়ন্ত্রণ।' }, { t: 'প্রোস্টাগ্লান্ডিন', d: 'প্রদাহ ও ব্যথার সংকেত।' }] },
    { t: 'ভিটামিন ও পরিপাক', d: 'চর্বিতে দ্রবণীয় ভিটামিন।', c: [{ t: 'ভিটামিন A, D, E, K', d: 'চর্বিতে দ্রবীভূত হয়ে শোষিত হয়।' }, { t: 'পিত্ত লবণ', d: 'চর্বিকে ক্ষুদ্র কণায় ভেঙে (ইমালসিফাই) হজমে সাহায্য করে।' }] }
  ]
}));
})();

/* ───────── ট্রাইগ্লিসারাইড ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const lerp = (a, b, t) => a + (b - a) * t;
V.triglyceride = Object.assign({
  t: 'ট্রাইগ্লিসারাইড গঠন ও সাবানীকরণ', k: ['2d', 'anim', 'int'],
  cap: 'গ্লিসারলের তিনটি –OH এর প্রতিটির সাথে একটি করে ফ্যাটি অ্যাসিডের –COOH এস্টার বন্ধন (–CO–O–) গঠন করে; প্রতিটি বন্ধনে এক অণু পানি — মোট 3 অণু। শেষ ধাপে ক্ষার (NaOH) দিয়ে ভাঙলে গ্লিসারল ও সাবান (ফ্যাটি অ্যাসিডের সোডিয়াম লবণ) তৈরি হয়।'
}, BK.steps({
  W: 360, H: 250, label: 'ট্রাইগ্লিসারাইড', dur: 2.4,
  stages: [
    { t: 'গ্লিসারল + 3 ফ্যাটি অ্যাসিড', en: 'Glycerol + 3 fatty acids', d: 'গ্লিসারল (C₃H₈O₃) তিন কার্বনের অ্যালকোহল, প্রতিটি কার্বনে একটি –OH।' },
    { t: 'প্রথম এস্টার বন্ধন', en: 'Esterification 1', d: '–OH + HOOC– → –O–CO– + H₂O। ফলে মনোগ্লিসারাইড।' },
    { t: 'দ্বিতীয় এস্টার বন্ধন', en: 'Esterification 2', d: 'ডাইগ্লিসারাইড; মোট 2 অণু পানি।' },
    { t: 'ট্রাইগ্লিসারাইড', en: 'Triglyceride', d: 'তিনটি এস্টার বন্ধন, 3 অণু পানি। সব ফ্যাটি অ্যাসিড এক হলে সরল, ভিন্ন হলে মিশ্র ট্রাইগ্লিসারাইড।' },
    { t: 'সাবানীকরণ', en: 'Saponification', d: 'ট্রাইগ্লিসারাইড + 3NaOH → গ্লিসারল + 3টি সাবান অণু (R–COO⁻Na⁺)। দেহে একই বন্ধন ভাঙে লাইপেজ এনজাইম — তবে পানি দিয়ে (আর্দ্রবিশ্লেষণ)।' }
  ],
  draw(g, C, s, u) {
    const Rg = BK.ramp(5), Rf = BK.ramp(1), Rw = BK.ramp(4), Ro = BK.ramp(0), Rs = BK.ramp(7);
    const GX = 64, ys = [70, 125, 180];
    const joined = i => s > i + 1 || (s === i + 1 && u >= .98) ? 1 : s === i + 1 ? u : 0;
    const sap = s === 4 ? u : 0;
    /* গ্লিসারল মেরুদণ্ড */
    const gx = GX - sap * 20;
    E('path', { d: `M${gx} ${ys[0]}V${ys[2]}`, stroke: Rg.dk, 'stroke-width': 3 }, g);
    ys.forEach((y, i) => { E('circle', { cx: gx, cy: y, r: 11, fill: FK.alpha(Rg.c, .25), stroke: Rg.c, 'stroke-width': 1.6 }, g); T(g, gx, y + 4.5, 'C', { fs: 12, a: 'middle', w: 650 }); T(g, gx - 16, y + 4, 'H₂', { fs: 10.5, a: 'end', w: 560, c: C.mu }); });
    const svg = g.ownerSVGElement; if (!svg._gl) svg._gl = T(svg, 56, 40, 'গ্লিসারল', { fs: 11.5, a: 'middle', w: 650, c: Rg.ink });
    ys.forEach((y, i) => {
      const k = joined(i);
      const free = sap > .5 ? 1 : 1 - k;            /* সাবানীকরণে আবার আলাদা */
      const fx = lerp(lerp(150, 104, k), 190, sap);     /* ফ্যাটি অ্যাসিডের মাথার x */
      /* –OH (গ্লিসারলের) */
      if (k < 1 || sap > .5) T(g, gx + 26, y + 4.5, 'OH', { fs: 12, a: 'middle', w: 650, c: Rw.ink, st: `opacity:${sap > .5 ? sap : 1 - k}` });
      /* এস্টার বন্ধন */
      if (k > .9 && sap < .5) { E('path', { d: `M${gx + 11} ${y}L${fx - 14} ${y}`, stroke: Ro.c, 'stroke-width': 3 }, g); T(g, (gx + fx) / 2, y - 7, 'O', { fs: 11, a: 'middle', w: 700, c: Ro.ink }); }
      /* ফ্যাটি অ্যাসিডের মাথা */
      E('circle', { cx: fx, cy: y, r: 13, fill: FK.alpha(sap > .5 ? Rs.c : Rf.c, .25), stroke: sap > .5 ? Rs.c : Rf.c, 'stroke-width': 1.6 }, g);
      T(g, fx, y + 4, sap > .5 ? 'COO⁻' : k > .9 ? 'C=O' : 'COOH', { fs: 9, a: 'middle', w: 650, c: sap > .5 ? Rs.ink : Rf.ink });
      if (sap > .5) T(g, fx + 2, y - 16, 'Na⁺', { fs: 10.5, a: 'middle', w: 650, c: Rs.ink, st: `opacity:${(sap - .5) * 2}` });
      /* লেজ (জিগজ্যাগ) */
      let d = `M${fx + 13} ${y}`; for (let j = 1; j <= 14; j++) d += `L${fx + 13 + j * 10} ${y + (j % 2 ? -5 : 5)}`;
      E('path', { d, stroke: Rf.dk, 'stroke-width': 2.4, fill: 'none', 'stroke-linejoin': 'round' }, g);
      /* পানি বেরোচ্ছে */
      if (s === i + 1 && u > .3 && u < 1) { const p = (u - .3) / .7; E('circle', { cx: 120 + p * 40, cy: y + 18 + p * 10, r: 13, fill: FK.alpha(BK.ramp(5).c, .2), stroke: BK.ramp(5).c }, g); T(g, 120 + p * 40, y + 22 + p * 10, 'H₂O', { fs: 10, a: 'middle', w: 650, c: BK.ramp(5).ink }); }
    });
    if (s >= 3 && s < 4) T(g, 180, 226, '3টি এস্টার বন্ধন · 3 অণু H₂O বের হয়েছে', { fs: 12, a: 'middle', w: 650, c: Ro.ink });
    if (s === 4) { T(g, 330, 40, '+ 3NaOH', { fs: 12.5, a: 'end', w: 650, c: Rs.ink }); T(g, 180, 226, sap > .5 ? 'গ্লিসারল + 3 অণু সাবান' : 'ক্ষার এস্টার বন্ধন ভাঙছে…', { fs: 12, a: 'middle', w: 650, c: Rs.ink }); }
  }
}));
})();

/* ───────── ফসফোলিপিড ও ঝিল্লি ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
V.phospholipid = {
  t: 'ফসফোলিপিড — উভপ্রেমী অণু থেকে কোষঝিল্লি', k: ['2d', 'anim', 'int'],
  cap: 'ফসফোলিপিডের ফসফেটযুক্ত মাথা পানিপ্রিয়, দুটি ফ্যাটি অ্যাসিডের লেজ পানিবিদ্বেষী — একে উভপ্রেমী (অ্যাম্ফিপ্যাথিক) অণু বলে। পানিতে এরা নিজে থেকেই লেজ ভেতরে রেখে দ্বিস্তর বা গোল মাইসেল/ভেসিকল তৈরি করে। চালাও চাপলে দেখবে অণুগুলো স্তরের ভেতরে পাশাপাশি সরে — ঝিল্লি তরল।',
  html: () => `<div class="fk-row">${X.seg('m', [['one', 'একটি অণু'], ['bi', 'দ্বিস্তর ঝিল্লি'], ['mic', 'মাইসেল']], 'one')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250;
    let m = 'one', C, svg, g, items = [], tt = 0;
    const lipid = (parent, sc, kink, chol) => {
      const gg = E('g', {}, parent), Rh = BK.ramp(5), Rt = BK.ramp(1), Rc = BK.ramp(9);
      if (chol) { E('rect', { x: -4 * sc, y: 4 * sc, width: 8 * sc, height: 22 * sc, rx: 3 * sc, fill: Rc.c, stroke: Rc.dk }, gg); E('circle', { cx: 0, cy: 2 * sc, r: 3 * sc, fill: BK.ramp(4).c }, gg); return gg; }
      E('path', { d: `M${-3 * sc} ${6 * sc}L${-3 * sc} ${34 * sc}`, stroke: Rt.dk, 'stroke-width': 2 * sc, 'stroke-linecap': 'round' }, gg);
      E('path', { d: kink ? `M${3 * sc} ${6 * sc}L${3 * sc} ${18 * sc}L${8 * sc} ${32 * sc}` : `M${3 * sc} ${6 * sc}L${3 * sc} ${34 * sc}`, stroke: Rt.dk, 'stroke-width': 2 * sc, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, gg);
      E('circle', { cx: 0, cy: 0, r: 7 * sc, fill: BK.lg(svg, Rh.lt, Rh.c, { a: 90 }), stroke: Rh.dk, 'stroke-width': 1 }, gg);
      return gg;
    };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'ফসফোলিপিড' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      g = E('g', {}, svg); items = [];
      const Rh = BK.ramp(5), Rt = BK.ramp(1), Rw = BK.ramp(4);
      if (m === 'one') {
        /* লেবেলযুক্ত বড় অণু */
        const cx = 120, gg = E('g', {}, g);
        const parts = [['কোলিন (N⁺)', 40, BK.ramp(7)], ['ফসফেট (PO₄⁻)', 70, BK.ramp(4)], ['গ্লিসারল', 100, BK.ramp(5)]];
        parts.forEach(([n, y, R0]) => { E('rect', { x: cx - 26, y: y - 13, width: 52, height: 26, rx: 9, fill: FK.alpha(R0.c, .22), stroke: R0.c, 'stroke-width': 1.5 }, gg); T(gg, cx + 34, y + 4, n, { fs: 11.5, w: 600, c: R0.ink }); });
        E('path', { d: `M${cx} 53V57M${cx} 83V87`, stroke: C.fg, 'stroke-width': 2 }, gg);
        let d1 = `M${cx - 12} 113`, d2 = `M${cx + 12} 113`;
        for (let j = 1; j <= 11; j++) { d1 += `L${cx - 12 + (j % 2 ? -4 : 4)} ${113 + j * 10}`; }
        for (let j = 1; j <= 11; j++) { const x = j < 5 ? cx + 12 + (j % 2 ? -4 : 4) : cx + 12 + (j - 4) * 4 + (j % 2 ? -4 : 4); d2 += `L${x} ${113 + j * 10}`; }
        E('path', { d: d1, stroke: Rt.dk, 'stroke-width': 2.6, fill: 'none', 'stroke-linejoin': 'round' }, gg);
        E('path', { d: d2, stroke: Rt.dk, 'stroke-width': 2.6, fill: 'none', 'stroke-linejoin': 'round' }, gg);
        T(gg, cx + 40, 166, 'দুটি ফ্যাটি অ্যাসিডের লেজ', { fs: 11.5, w: 600, c: Rt.ink }); T(gg, cx + 40, 184, '(একটিতে cis বাঁক)', { fs: 10.5, w: 520, c: C.mu });
        E('rect', { x: 14, y: 26, width: 70, height: 88, rx: 10, fill: FK.alpha(Rw.c, .08), stroke: FK.alpha(Rw.c, .5), 'stroke-dasharray': '4 3' }, g); T(g, 49, 124, 'পানিপ্রিয়', { fs: 11, a: 'middle', w: 650, c: Rw.ink }); T(g, 49, 138, 'মাথা', { fs: 11, a: 'middle', w: 650, c: Rw.ink });
        E('rect', { x: 14, y: 148, width: 70, height: 80, rx: 10, fill: FK.alpha(Rt.c, .08), stroke: FK.alpha(Rt.c, .5), 'stroke-dasharray': '4 3' }, g); T(g, 49, 186, 'পানিবিদ্বেষী', { fs: 11, a: 'middle', w: 650, c: Rt.ink }); T(g, 49, 200, 'লেজ', { fs: 11, a: 'middle', w: 650, c: Rt.ink });
        items.push({ g: gg, x: 0, y: 0, ph: 0, one: 1 });
      } else if (m === 'bi') {
        E('rect', { x: 0, y: 0, width: W, height: 62, rx: 12, fill: FK.alpha(Rw.c, .08) }, g); E('rect', { x: 0, y: 166, width: W, height: 84, rx: 12, fill: FK.alpha(Rw.c, .08) }, g);
        T(g, 12, 22, 'কোষের বাইরে (পানি)', { fs: 11, w: 600, c: Rw.ink }); T(g, 12, 240, 'সাইটোপ্লাজম (পানি)', { fs: 11, w: 600, c: Rw.ink });
        for (let i = 0; i < 15; i++) {
          const chol = i % 5 === 2;
          const top = lipid(g, 1, i % 3 === 1, chol); items.push({ g: top, x: 18 + i * 23, y: 76, rot: 0, ph: i * .9 });
          const bot = lipid(g, 1, i % 4 === 2, (i + 2) % 5 === 0); items.push({ g: bot, x: 18 + i * 23 + 10, y: 152, rot: 180, ph: i * 1.3 });
        }
        T(g, W - 12, 22, 'নীল-ধূসর দণ্ড = কোলেস্টেরল', { fs: 10, a: 'end', w: 520, c: C.mu });
      } else {
        const cx = 180, cy = 128, n = 16;
        E('circle', { cx, cy, r: 66, fill: FK.alpha(Rw.c, .06) }, g);
        for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const l = lipid(g, 1, i % 3 === 0, false); items.push({ g: l, x: cx + 58 * Math.cos(a), y: cy + 58 * Math.sin(a), rot: a * 180 / Math.PI + 90, ph: i, ring: a }); }
        T(g, cx, cy + 4, 'তেলের কণা', { fs: 11, a: 'middle', w: 600, c: Rt.ink });
        T(g, 12, 22, 'চারদিকে পানি — মাথা বাইরে, লেজ ভেতরে', { fs: 11, w: 600, c: Rw.ink });
      }
      info(); step(0);
    };
    const info = () => { $('info').innerHTML = m === 'one' ? '<b>ফসফাটিডিলকোলিন (লেসিথিন)</b>: গ্লিসারলের দুটি –OH এ দুটি ফ্যাটি অ্যাসিড, তৃতীয়টিতে ফসফেট, তার সাথে কোলিন। মাথা চার্জিত ও পানিপ্রিয়, লেজ পানিবিদ্বেষী।' : m === 'bi' ? '<b>ফসফোলিপিড দ্বিস্তর</b>: মাথা দুই দিকে পানির দিকে, লেজ মাঝখানে মুখোমুখি — প্রায় 5 nm পুরু। কোলেস্টেরল লেজগুলোর ফাঁকে বসে তারল্য নিয়ন্ত্রণ করে। পানিতে দ্রবণীয় আয়ন ও বড় অণু এই পানিবিদ্বেষী স্তর সহজে পেরোতে পারে না — তাই ঝিল্লি নির্বাচিত ভেদ্য।' : '<b>মাইসেল</b>: সাবান বা পিত্ত লবণের মতো উভপ্রেমী অণু তেলের কণাকে ঘিরে ফেলে — লেজ তেলের দিকে, মাথা পানির দিকে। এভাবেই সাবান ময়লা তোলে এবং পিত্ত লবণ অন্ত্রে চর্বিকে ক্ষুদ্র কণায় ভাঙে (ইমালসিফিকেশন)।'; };
    const step = dt => {
      tt += dt;
      items.forEach((it, i) => {
        if (it.one) { it.g.setAttribute('transform', `rotate(${(1.5 * Math.sin(tt * 2)).toFixed(2)} 120 70)`); return; }
        let x = it.x, y = it.y, r = it.rot;
        if (m === 'bi') { x = ((it.x + tt * (i % 2 ? 6 : -5) + 4 * Math.sin(tt * 2 + it.ph)) % (W + 10) + W + 10) % (W + 10) - 5; y = it.y + 1.5 * Math.sin(tt * 3 + it.ph); }
        else { const a = it.ring + tt * .15; x = 180 + 58 * Math.cos(a); y = 128 + 58 * Math.sin(a); r = a * 180 / Math.PI + 90; }
        it.g.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${r.toFixed(1)})`);
      });
    };
    const A = X.anim(root, step, { paused: true });
    X.pp(root, A);
    X.onSeg(root, 'm', v => { m = v; tt = 0; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();

/* ───────── লিপিড প্রোফাইল ক্যালকুলেটর ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* সীমা (mg/dL) — প্রাপ্তবয়স্কের সাধারণ নির্দেশিকা (NCEP ATP III) */
const band = (k, v) => {
  if (k === 'tc') return v < 200 ? 0 : v < 240 ? 1 : 2;
  if (k === 'ldl') return v < 130 ? 0 : v < 160 ? 1 : 2;
  if (k === 'hdl') return v >= 60 ? 0 : v >= 40 ? 1 : 2;
  if (k === 'tg') return v < 150 ? 0 : v < 200 ? 1 : 2;
  return 0;
};
const WORD = ['কাম্য', 'সীমারেখায়', 'ঝুঁকিপূর্ণ'];
V.lipidProfile = {
  t: 'লিপিড প্রোফাইল — পড়তে শেখো', k: ['graph', 'int', 'anim'],
  cap: 'স্লাইডার দিয়ে মোট কোলেস্টেরল, HDL ও ট্রাইগ্লিসারাইড বদলাও; LDL ও VLDL ফ্রিডওয়াল্ড সূত্রে হিসাব হবে: VLDL = TG ÷ 5, LDL = TC − HDL − TG ÷ 5 (সব mg/dL; TG < 400 হলে প্রযোজ্য)। রং কেবল শিক্ষার জন্য — রোগনির্ণয় চিকিৎসকের কাজ।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row">${FK.sl('tc', 'মোট কোলেস্টেরল', 120, 320, 1, 200, '')}</div>
    <div class="fk-row">${FK.sl('hdl', 'HDL', 20, 90, 1, 50, '')}</div>
    <div class="fk-row">${FK.sl('tg', 'ট্রাইগ্লিসারাইড', 50, 390, 1, 150, '')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 230;
    const v = { tc: 200, hdl: 50, tg: 150 }; let C, svg, bars = {}, shown = { tc: 0, ldl: 0, hdl: 0, tg: 0, vldl: 0 };
    const ROWS = [['tc', 'মোট কোলেস্টেরল', 320], ['ldl', 'LDL ("খারাপ")', 250], ['hdl', 'HDL ("ভালো")', 100], ['vldl', 'VLDL', 80], ['tg', 'ট্রাইগ্লিসারাইড', 400]];
    const calc = () => { const vldl = v.tg / 5; return { tc: v.tc, hdl: v.hdl, tg: v.tg, vldl, ldl: Math.max(0, v.tc - v.hdl - vldl) }; };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'লিপিড প্রোফাইল' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      T(svg, 12, 22, 'mg/dL (খালি পেটে 9–12 ঘণ্টা পর রক্ত)', { fs: 11, w: 560, c: C.mu });
      ROWS.forEach(([k, n, mx], i) => {
        const y = 40 + i * 37;
        T(svg, 12, y + 15, n, { fs: 11.5, w: 600 });
        E('rect', { x: 124, y: y + 4, width: 170, height: 14, rx: 7, fill: C.s2, stroke: C.ln }, svg);
        bars[k] = { r: E('rect', { x: 124, y: y + 4, width: 0, height: 14, rx: 7, fill: C.ok }, svg), t: T(svg, 300, y + 16, '', { fs: 11.5, w: 650 }), w: T(svg, 124, y + 32, '', { fs: 9.5, w: 520, c: C.mu }), mx };
      });
      paint(true);
    };
    const paint = force => {
      const c = calc(), cols = [C.ok, BK.ramp(1).c, C.bad];
      Object.keys(bars).forEach(k => {
        const b = bars[k], val = force ? c[k] : shown[k], bd = k === 'vldl' ? (val <= 30 ? 0 : val <= 40 ? 1 : 2) : band(k, val);
        b.r.setAttribute('width', (170 * Math.min(1, val / b.mx)).toFixed(1)); b.r.setAttribute('fill', cols[bd]);
        b.t.textContent = Math.round(val); b.w.textContent = WORD[bd];
      });
      const ratio = c.tc / c.hdl;
      $('info').innerHTML = `LDL = ${c.tc} − ${c.hdl} − ${c.tg}/5 = <b>${Math.round(c.ldl)}</b> mg/dL · মোট কোলেস্টেরল/HDL অনুপাত = <b>${ratio.toFixed(1)}</b> (${ratio < 5 ? 'কম ঝুঁকি' : 'ঝুঁকি বেশি'}; 5 এর কম ভালো)<div class="small">LDL কলায় কোলেস্টেরল পৌঁছায়, বেশি হলে ধমনির দেয়ালে জমে (অ্যাথেরোস্ক্লেরোসিস); HDL বাড়তি কোলেস্টেরল যকৃতে ফিরিয়ে আনে — তাই HDL বেশি হওয়াই ভালো।</div>`;
    };
    const A = X.anim(root, dt => { const c = calc(); let moving = false; Object.keys(shown).forEach(k => { const d = c[k] - shown[k]; if (Math.abs(d) > .5) { shown[k] += d * Math.min(1, dt * 8); moving = true; } else shown[k] = c[k]; }); paint(false); if (!moving) A.pause(true); }, { paused: true });
    ['tc', 'hdl', 'tg'].forEach(k => FK.bindSl(root, k, x => { v[k] = x; A.pause(false); }, '', 0));
    const unT = FK.onTheme(base); base(); Object.assign(shown, calc());
    return () => { A.stop(); unT(); };
  }
};
})();

/* ───────── স্টেরয়েড নিউক্লিয়াস — কোলেস্টেরল (চিহ্নিত চিত্র) ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
/* বলয়ের কোণ: A, B, C ছয় কোণা; D পাঁচ কোণা — সমতল কঙ্কাল চিত্র */
const hex = (cx, cy, r) => [...Array(6)].map((_, i) => [cx + r * Math.cos(Math.PI / 6 + i * Math.PI / 3), cy + r * Math.sin(Math.PI / 6 + i * Math.PI / 3)]);
const R0 = 26, h = R0 * Math.sqrt(3) / 2;
const A = hex(92, 170, R0), B = hex(92 + 2 * h, 170 - 0, R0).map(([x, y]) => [x, y]), Cc = hex(92 + 3 * h, 170 - 1.5 * R0, R0);
const D = (() => { const cx = 92 + 3 * h + 2 * h + 2, cy = 170 - 1.5 * R0 - 4, r = 23; return [...Array(5)].map((_, i) => [cx + r * Math.cos(Math.PI + .63 + i * 2 * Math.PI / 5), cy + r * Math.sin(Math.PI + .63 + i * 2 * Math.PI / 5)]); })();
V.steroidRing = Object.assign({
  t: 'স্টেরয়েড নিউক্লিয়াস — কোলেস্টেরল', k: ['2d', 'label', 'int'],
  cap: 'সব স্টেরয়েডের ভিত্তি চারটি যুক্ত কার্বন বলয় — তিনটি ছয় কোণা (A, B, C) ও একটি পাঁচ কোণা (D)। কোলেস্টেরলে C-3 এ একটি –OH (একমাত্র পোলার অংশ), B বলয়ে একটি দ্বিবন্ধন (C-5 ও C-6 এর মধ্যে) এবং D বলয়ে একটি হাইড্রোকার্বন পার্শ্বশিকল। অংশে চাপ দাও বা লেবেল-কুইজ খেলো।'
}, BK.diagram({
  W: 360, H: 260, label: 'কোলেস্টেরলের গঠন',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rr = BK.ramp(9), Ro = BK.ramp(4), Rs = BK.ramp(1), Rd = BK.ramp(0);
    const poly = (pts, gg, fill) => E('path', { d: 'M' + pts.map(p => p.map(v => v.toFixed(1)).join(' ')).join('L') + 'Z', fill, stroke: Rr.dk, 'stroke-width': 2.2, 'stroke-linejoin': 'round' }, gg);
    const ga = P('ra'); poly(A, ga, FK.alpha(Rr.c, .18)); T(ga, 92, 175, 'A', { fs: 14, a: 'middle', w: 700, c: Rr.ink });
    const gb = P('rb'); poly(B, gb, FK.alpha(Rr.c, .26)); T(gb, 92 + 2 * h, 175, 'B', { fs: 14, a: 'middle', w: 700, c: Rr.ink });
    E('path', { d: `M${B[1][0] - 4} ${B[1][1] - 6}L${B[2][0] + 2} ${B[2][1] - 6}`, stroke: Rd.c, 'stroke-width': 2.4 }, P('db'));
    const gc = P('rc'); poly(Cc, gc, FK.alpha(Rr.c, .18)); T(gc, 92 + 3 * h, 175 - 1.5 * R0, 'C', { fs: 14, a: 'middle', w: 700, c: Rr.ink });
    const gd = P('rd'); poly(D, gd, FK.alpha(Rr.c, .26)); const dc = D.reduce((a, p) => [a[0] + p[0] / 5, a[1] + p[1] / 5], [0, 0]); T(gd, dc[0], dc[1] + 5, 'D', { fs: 14, a: 'middle', w: 700, c: Rr.ink });
    const go = P('oh'); E('path', { d: `M${A[3][0]} ${A[3][1]}l-22 10`, stroke: Ro.c, 'stroke-width': 2.2 }, go); T(go, A[3][0] - 30, A[3][1] + 18, 'HO', { fs: 13, a: 'middle', w: 700, c: Ro.ink });
    const gs = P('sc'); const s0 = D[2]; let d = `M${s0[0]} ${s0[1]}`; const zz = [[14, -10], [14, 8], [14, -10], [14, 8], [12, -10], [10, 10], [12, -10]]; let x = s0[0], y = s0[1]; zz.forEach(([dx, dy]) => { x += dx; y += dy; d += `L${x} ${y}`; }); E('path', { d, stroke: Rs.dk, 'stroke-width': 2.2, fill: 'none', 'stroke-linejoin': 'round' }, gs);
    const gm = P('me'); [[B[5], -18], [Cc[5], -18]].forEach(([p]) => E('path', { d: `M${p[0]} ${p[1]}l0 -18`, stroke: Rr.dk, 'stroke-width': 2.2 }, gm));
  },
  parts: [
    { id: 'ra', bn: 'A বলয়', en: 'Ring A', fn: 'ছয় কোণা কার্বন বলয়; এর C-3 এ –OH যুক্ত।', a: [92, 180], l: [40, 228] },
    { id: 'rb', bn: 'B বলয়', en: 'Ring B', fn: 'ছয় কোণা; কোলেস্টেরলে C-5 ও C-6 এর মধ্যে একটি দ্বিবন্ধন।', a: [92 + 2 * h, 186], l: [150, 238] },
    { id: 'db', bn: 'দ্বিবন্ধন (C5=C6)', en: 'Double bond', fn: 'কোলেস্টেরলকে অন্য কিছু স্টেরয়েড থেকে আলাদা করে।', a: [92 + 1.6 * h, 154], l: [70, 96], an: 'middle' },
    { id: 'rc', bn: 'C বলয়', en: 'Ring C', fn: 'তৃতীয় ছয় কোণা বলয়।', a: [92 + 3 * h, 140], l: [200, 92] },
    { id: 'rd', bn: 'D বলয় (পাঁচ কোণা)', en: 'Ring D', fn: 'পাঁচ কার্বনের বলয়; এর C-17 এ পার্শ্বশিকল।', a: [dcX(), 128], l: [300, 176], an: 'middle' },
    { id: 'oh', bn: 'হাইড্রক্সিল (–OH)', en: '3-β hydroxyl', fn: 'একমাত্র পোলার গ্রুপ — ঝিল্লিতে ফসফোলিপিডের মাথার দিকে থাকে; তাই কোলেস্টেরল সামান্য উভপ্রেমী।', a: [A[3][0] - 26, A[3][1] + 12], l: [14, 112], an: 'start' },
    { id: 'sc', bn: 'হাইড্রোকার্বন পার্শ্বশিকল', en: 'Side chain', fn: '8 কার্বনের অপোলার শিকল — ঝিল্লির ভেতরে লেজের মতো থাকে।', a: [D[2][0] + 40, D[2][1] - 4], l: [270, 40], an: 'middle' },
    { id: 'me', bn: 'মিথাইল গ্রুপ (C-18, C-19)', en: 'Angular methyls', fn: 'বলয় সংযোগে দুটি –CH₃।', a: [B[5][0], B[5][1] - 14], l: [160, 34], an: 'middle' }
  ],
  idle(g, C, t) { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx: A[3][0] - 30, cy: A[3][1] + 13, r: 13 + 3 * k, fill: 'none', stroke: FK.alpha(BK.ramp(4).c, .25 + .35 * k), 'stroke-width': 2 }, g); }
}));
function dcX() { return D.reduce((a, p) => a + p[0] / 5, 0); }
})();
