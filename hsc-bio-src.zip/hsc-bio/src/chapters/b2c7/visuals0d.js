/* ═══════════════════════════════════════════════════════════════════
   visuals0d — অধ্যায় ৭ (চলন ও অঙ্গচালনা): পূর্ণ কঙ্কাল (সামনে থেকে, শারীরস্থানিক অবস্থান)
   B.skel(g, C, { x, y, s, tint:{দল:রং}, dim:{দল:true}, gfor:দল→g, only:[দল] }) → নোঙর বিন্দু
   স্থানীয় একক: মাথার চূড়া y = 0, পায়ের তলা y ≈ 442, মধ্যরেখা x = 0; প্রতিটি অংশ ডান অর্ধে (x > 0) লেখা,
   বাম অর্ধ আয়নার প্রতিফলন। দর্শকের বাঁ = দেহের ডান। অনুপাত প্রাপ্তবয়স্ক মানুষের (মাথা ≈ দেহের ১/৭)।
   দল: skull mand hyoid cerv thor lumb sac cocc ster rib cc clav scap hum rad uln carp mcp phal hip fem pat tib fib tars mtt toe
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, B = window.B27, PI = Math.PI;
const f1 = v => (+v).toFixed(1), sm = (p, c, k) => B.smooth(p, c, k);

/* ─── স্থানীয় জ্যামিতি (ডান অর্ধ) ─── */
const SK = {};
/* করোটি + মুখমণ্ডল (চোয়াল ছাড়া) — সম্পূর্ণ বন্ধ রূপরেখা পরে আয়না করে বানানো হয় */
SK.skullR = [[0, 0], [10, 1.2], [17.5, 5.5], [22, 12.5], [23.8, 21], [23.6, 28.5], [22.4, 33], [23, 37], [21.2, 40.5], [17.5, 42.6], [14.5, 45.6], [10.5, 47.8], [5, 48.4], [0, 48.6]];
SK.mandR = [[19.4, 38.5], [20.2, 45], [19.2, 51.5], [15.5, 56], [9, 59.4], [0, 60.6]];
SK.mandIn = [[16.4, 41.5], [16.6, 46.5], [13.6, 49.6], [8, 50.6], [0, 51]];
SK.orbit = [[3.6, 21.6], [9, 20.2], [14.2, 21.4], [15.6, 26.5], [14, 31.6], [9, 32.8], [4.4, 31], [3.2, 26]];
SK.nasal = [[0, 30.5], [2.6, 33], [4.4, 38.4], [3.6, 42.6], [1.4, 43.6], [0, 43.4]];
/* মেরুদণ্ড: [y শুরু, y শেষ, অর্ধ-প্রস্থ] */
const VB = []; (() => { let y = 61.5; for (let i = 0; i < 7; i++) { VB.push(['cerv', y, y + 2.3, 4.2 + i * .25]); y += 2.85; } y = 81.5; for (let i = 0; i < 12; i++) { VB.push(['thor', y, y + 5.3, 5.2 + i * .42]); y += 6.55; } y = 160.5; for (let i = 0; i < 5; i++) { VB.push(['lumb', y, y + 6.6, 10.2 + i * .5]); y += 7.85; } })();
SK.VB = VB;
SK.sacR = [[0, 199.5], [12.6, 199.8], [11.6, 208], [9, 216], [6, 223.5], [3.2, 229], [0, 230]];
SK.coccR = [[0, 230.8], [2.6, 231], [2, 234.2], [1.2, 237], [0, 238.4]];
SK.manub = [[0, 80.2], [3.2, 79.6], [6.6, 80.8], [7.2, 84.6], [5, 89], [4.6, 92.6], [0, 92.8]];
SK.sbody = [[0, 93.8], [4.6, 93.8], [5.2, 104], [5.6, 118], [4.8, 128], [3.4, 131.5], [0, 132]];
SK.xiph = [[0, 132.8], [2.4, 133], [1.6, 137.5], [0, 140.6]];
/* পর্শুকা: মেরুদণ্ডে সংযোগ ys, পাশের সর্বোচ্চ বিস্তার W, সামনের প্রান্ত (তরুণাস্থির শুরু), স্টার্নামে সংযোগ */
const RW = [18, 24, 28.6, 32.4, 35.4, 37.4, 38.6, 39.2, 38.8, 37.2, 33, 28.2];
const RC = [[9.6, 84.6], [13.6, 98.5], [16.6, 108], [19.2, 117], [21.2, 126], [22.6, 134], [23.6, 142.5], [24.6, 150.4], [24.4, 156.8], [23.8, 161.8], [31.2, 171.4], [25.4, 172.6]];
const RS = [[6.4, 83.6], [5, 93.2], [5.2, 100.2], [5.4, 106.6], [5.6, 113.4], [5.4, 120.4], [4.6, 128.6], [10.4, 137.6], [14, 143.6], [17.6, 149.4]];
SK.ribs = RW.map((W, i) => { const ys = 78.8 + 7.05 * i, [cx, cy] = RC[i];
  const post = [[5.5, ys + 1.2], [W * .55, ys - 1.4 + i * .1], [W * .92, ys + .4], [W, ys + 3.4]];
  const ant = [[W, ys + 3.4], [W - .5, ys + 6.2 + i * .2], [(W + cx) / 2 + 1.6, (ys + 3.4 + cy) / 2 + 1.6], [cx, cy]];
  return { ys, W, post, ant, end: [cx, cy], st: RS[i] || null, w: i === 0 ? 2.8 : 2.2 + Math.min(i, 6) * .12 - Math.max(0, i - 8) * .2 }; });
SK.clav = [[5.6, 79.8], [14, 77.2], [24, 78.8], [33, 77.6], [40.6, 75.6]];
SK.scap = [[29.6, 80.6], [39.6, 76.4], [43.4, 77], [45.6, 81.6], [44.4, 86.8], [41, 96], [36.4, 110], [33.2, 121.4], [30.2, 116], [28.4, 100], [27.6, 88]];
SK.hum = [[43.2, 89.6], [44.2, 84.8], [48.6, 82.6], [52.2, 85], [52.8, 91.4], [51.2, 104], [51.6, 128], [53.4, 150], [56.6, 162], [58.2, 168.4], [56.4, 172.2], [53.2, 173.6], [50.2, 172.2], [47.2, 173.2], [45.8, 169], [47.4, 161], [48.4, 148], [47.2, 126], [45.8, 104], [44.2, 96]];
SK.uln = [[47.4, 170.8], [50.8, 170.2], [51.8, 174.6], [51.6, 180], [52.4, 200], [54.6, 222], [56.6, 240.2], [56.8, 244.6], [54.6, 245.4], [53.6, 241], [51.4, 222], [48.6, 200], [47.2, 182], [46.2, 175.4]];
SK.rad = [[52.4, 174.6], [56.2, 174], [56.8, 177.8], [55.6, 181.6], [56.2, 200], [59.4, 222], [63.6, 238.4], [65.4, 243.4], [61.8, 245], [57.6, 244.6], [57.4, 238.6], [55.8, 222], [53.6, 200], [53.2, 182], [52.8, 178.6]];
/* কব্জির ৮টি অস্থি: দুই সারি (ভেতর → বাইরে) */
SK.carp = [[54.2, 248.4, 1.9, 2.1], [57.6, 248.6, 1.9, 2.2], [61, 248.4, 1.8, 2.1], [64.4, 247.8, 1.9, 2.1], [55, 253, 1.8, 2.2], [58.2, 253.4, 1.9, 2.3], [61.4, 253.2, 1.7, 2.2], [64.6, 252.4, 1.8, 2.1]];
/* করতলাস্থি ও আঙুল: [ভিত্তি, মাথা], আঙুলের পর্বাস্থির দৈর্ঘ্য */
SK.fing = [ { b: [55, 256], h: [54.2, 271], L: [7.6, 5.2, 3.8] }, { b: [57.8, 256.4], h: [57.8, 273], L: [9.2, 6.2, 4] }, { b: [60.8, 256.4], h: [61.6, 273.4], L: [9.8, 6.6, 4.2] }, { b: [63.8, 256], h: [65.6, 272], L: [9, 6, 4] }, { b: [66.4, 252.4], h: [71.6, 262.4], L: [7, 0, 5] } ];
SK.hip = [[12, 190.4], [21.4, 181.2], [33.6, 179.6], [40.8, 185.4], [40.2, 192.8], [37.6, 202.6], [36.4, 211.4], [35.6, 221.6], [33.4, 229.4], [28.4, 236.6], [21.6, 240], [12.2, 238.4], [4, 234.4], [1.8, 230], [1.8, 223], [7.6, 219.4], [15.4, 215.8], [18, 210], [15.2, 203], [12.8, 198]];
SK.obt = [[12.2, 225.4], [17.6, 223.6], [21.6, 227], [20.2, 232.6], [14.6, 234.6], [10.4, 231.6]];
SK.fem = [[36.4, 221.2], [40.4, 218.8], [43, 222.4], [42.4, 230], [40.4, 238], [37.6, 252], [33.8, 290], [30.8, 318], [31.6, 326.4], [31.6, 333.4], [29.4, 338.4], [25.8, 339.8], [23, 337.2], [19.6, 339.4], [16, 337.4], [14.6, 331.6], [15.6, 325], [19.6, 314], [24.8, 288], [29.6, 252], [30.2, 241], [27.4, 237.2], [29.4, 233.2], [31.6, 227.6], [32, 223.8]];
SK.fhead = [28.6, 220.2, 5.2];
SK.pat = [23.4, 329.8, 4.2, 5.4];
SK.tib = [[13.6, 342.4], [21.6, 341.4], [31.2, 342.2], [30.8, 348.4], [26.4, 355.4], [24.8, 380], [24.4, 404], [25.2, 413.6], [23.4, 419.2], [19.2, 419.6], [16.8, 423.6], [14.6, 420.4], [15.8, 412], [18.2, 400], [19.6, 380], [19.2, 356], [14.6, 349.4]];
SK.fib = [[31.4, 348.8], [33.8, 349.6], [33.6, 353.6], [32.4, 380], [30.8, 405], [30.6, 418], [30, 425.4], [27.4, 425.6], [27.6, 418], [28.4, 405], [29.6, 380], [30.4, 354.6], [29.6, 351]];
SK.tars = [[16.6, 422.6], [22, 420.8], [27.8, 422], [30.6, 426.4], [30.2, 431], [24, 432.6], [16.4, 432], [14.2, 427.6]];
SK.mtt = [[14.6, 432], [11.2, 437.4]].concat([]);
const MT = [[[15.2, 431.6], [11.4, 437.6]], [[18.8, 432.2], [16.4, 438.2]], [[22, 432.4], [21, 438.4]], [[25.2, 432.2], [25.6, 438]], [[28.4, 431.4], [30.4, 437.2]]];
SK.MT = MT;
/* অনুপাত সংশোধন: কাঁধের প্রস্থ (দুই অ্যাক্রোমিয়ন) শ্রোণির চেয়ে চওড়া */
const wid = p => [5 + (p[0] - 5) * 1.22, p[1]], nar = p => { const k = p[1] < 250 ? .9 : p[1] > 318 ? 1 : .9 + .1 * (p[1] - 250) / 68; return [p[0] * k, p[1]]; };
['clav', 'scap', 'hum', 'uln', 'rad'].forEach(k => { SK[k] = SK[k].map(wid); });
SK.carp = SK.carp.map(c => wid(c).concat(c.slice(2))); SK.fing.forEach(f => { f.b = wid(f.b); f.h = wid(f.h); });
['hip', 'obt', 'fem'].forEach(k => { SK[k] = SK[k].map(nar); }); SK.fhead = nar(SK.fhead).concat([SK.fhead[2]]);
B.SK = SK;

/* ─── অঙ্কন ─── */
B.skel = (g, C, o = {}) => {
  const X0 = o.x || 0, Y0 = o.y || 0, s = o.s || 1, tint = o.tint || {}, dim = o.dim || {}, only = o.only, gf = o.gfor || (() => g);
  const P = (p, sd = 1) => [+(X0 + sd * p[0] * s).toFixed(1), +(Y0 + p[1] * s).toFixed(1)];
  const mirror = R => R.map(p => P(p)).concat(R.slice(1, -1).reverse().map(p => P(p, -1)));   /* ডান অর্ধ → পূর্ণ বন্ধ */
  const poly = pts => 'M' + pts.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  const on = k => !only || only.includes(k);
  const A = {};
  const bone = (k, d, kind = 'bone', ex = {}) => { if (!on(k)) return; const gg = gf(k); const op = dim[k] ? .28 : 1;
    B.organ(gg, d, kind, Object.assign({ sw: Math.max(.5, .62 * Math.sqrt(s)), op, gr: { cx: .38, cy: .32, r: .9 } }, ex));
    if (tint[k]) E('path', { d, fill: tint[k], opacity: dim[k] ? .15 : .48, stroke: 'none' }, gg); };
  const line = (k, d, w = .5, op = .45) => { if (!on(k)) return; E('path', { d, stroke: '#6e5c3c', 'stroke-width': w * Math.sqrt(s), fill: 'none', opacity: dim[k] ? op * .3 : op, 'stroke-linecap': 'round' }, gf(k)); };
  const both = fn => { if (!o.side || o.side === 1) fn(1); if (!o.side || o.side === -1) fn(-1); };

  /* ১. স্ক্যাপুলা (পর্শুকার পেছনে) */
  both(sd => bone('scap', sm(SK.scap.map(p => P(p, sd)), true, .45)));
  /* ২. মেরুদণ্ডের দেহ ও চাকতি */
  VB.forEach(([k, y0, y1, w], i) => { if (!on(k)) return; const a = P([w, y0]), b = P([w, y1]), c = P([-w, y0]), r = Math.min(1.6, (y1 - y0) * .3) * s;
    bone(k, `M${f1(c[0] + r)} ${f1(a[1])}H${f1(a[0] - r)}Q${f1(a[0])} ${f1(a[1])} ${f1(a[0] + .6 * s)} ${f1(a[1] + r)}L${f1(b[0] + .6 * s)} ${f1(b[1] - r)}Q${f1(b[0])} ${f1(b[1])} ${f1(b[0] - r)} ${f1(b[1])}H${f1(c[0] + r)}Q${f1(c[0])} ${f1(b[1])} ${f1(c[0] - .6 * s)} ${f1(b[1] - r)}L${f1(c[0] - .6 * s)} ${f1(a[1] + r)}Q${f1(c[0])} ${f1(a[1])} ${f1(c[0] + r)} ${f1(a[1])}Z`, 'bone', { lin: 0 });
    /* অনুপ্রস্থ প্রবর্ধক */ if (k !== 'cerv') both(sd => { const t0 = P([w, (y0 + y1) / 2], sd), t1 = P([w + (k === 'lumb' ? 4.4 : 3.2), (y0 + y1) / 2 - (k === 'lumb' ? .4 : 1.2)], sd); E('path', { d: `M${t0[0]} ${t0[1]}L${t1[0]} ${t1[1]}`, stroke: B.TS('bone').dk, 'stroke-width': (k === 'lumb' ? 2.6 : 1.8) * s, 'stroke-linecap': 'round', opacity: dim[k] ? .25 : .55 }, gf(k)); });
    const nx = VB[i + 1]; if (nx && nx[0] === k || (nx && k !== 'lumb')) { const d0 = P([w * .92, y1]), d1 = P([-w * .92, (nx ? nx[1] : y1 + 1)]); if (on(k)) E('rect', { x: f1(d1[0]), y: f1(d0[1]), width: f1(d0[0] - d1[0]), height: f1(Math.max(.4, d1[1] - d0[1])), fill: B.TS('cart').c, opacity: dim[k] ? .25 : .9 }, gf(k)); } });
  /* ৩. পর্শুকার পেছনের অংশ (হালকা) */
  SK.ribs.forEach((r, i) => both(sd => { if (!on('rib')) return; E('path', { d: sm(r.post.map(p => P(p, sd)), false, .5), stroke: B.TS('bone').dk, 'stroke-width': (r.w + .6) * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.rib ? .12 : .35 }, gf(o.ribG ? o.ribG(i) : 'rib'));
    E('path', { d: sm(r.post.map(p => P(p, sd)), false, .5), stroke: B.TS('bone').c, 'stroke-width': r.w * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.rib ? .12 : .55 }, gf(o.ribG ? o.ribG(i) : 'rib')); }));
  /* ৪. নিতম্বাস্থি, স্যাক্রাম, কক্সিক্স */
  both(sd => { const d = sm(SK.hip.map(p => P(p, sd)), true, .38); bone('hip', d, 'bone', { gr: { cx: .4, cy: .3, r: .8 } });
    if (on('hip')) { E('path', { d: sm(SK.obt.map(p => P(p, sd)), true, .5), fill: C.sf || '#fffdf6', stroke: B.TS('bone').dk, 'stroke-width': .6, opacity: dim.hip ? .5 : 1 }, gf('hip')); E('path', { d: sm(SK.obt.map(p => P(p, sd)), true, .5), fill: FK.alpha('#6a5636', .1), stroke: 'none' }, gf('hip')); line('hip', sm([[15.4, 202], [19, 209.6], [15.6, 215.6]].map(p => P(p, sd)), false, .5), .5, .5);  } });
  bone('sac', poly(mirror(SK.sacR)).replace(/L/g, 'L'), 'bone');
  if (on('sac')) for (let i = 0; i < 4; i++) both(sd => { const c = P([5.6 - i * .6, 203.6 + i * 6.4], sd); E('ellipse', { cx: c[0], cy: c[1], rx: f1(1.5 * s), ry: f1(1.1 * s), fill: FK.alpha('#4a3a26', .35) }, gf('sac')); const l = P([8.6 - i * 1.4, 206.8 + i * 6.4], sd), l2 = P([-(8.6 - i * 1.4), 206.8 + i * 6.4]); if (sd > 0) line('sac', `M${l[0]} ${l[1]}L${l2[0]} ${l2[1]}`, .4, .4); });
  bone('cocc', poly(mirror(SK.coccR)), 'bone');
  /* ৫. পর্শুকার সামনের অংশ ও তরুণাস্থি */
  SK.ribs.forEach((r, i) => both(sd => { if (on('rib')) { const d = sm(r.ant.map(p => P(p, sd)), false, .5); E('path', { d, stroke: B.TS('bone').dk, 'stroke-width': (r.w + 1) * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.rib ? .25 : 1 }, gf(o.ribG ? o.ribG(i) : 'rib')); E('path', { d, stroke: B.TS('bone').c, 'stroke-width': r.w * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.rib ? .25 : 1 }, gf(o.ribG ? o.ribG(i) : 'rib')); E('path', { d, stroke: '#fffaf0', 'stroke-width': r.w * .3 * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.rib ? .1 : .55, transform: `translate(0 ${f1(-r.w * .22 * s)})` }, gf(o.ribG ? o.ribG(i) : 'rib')); const rc = o.ribCol ? o.ribCol(i) : tint.rib; if (rc) E('path', { d, stroke: rc, 'stroke-width': r.w * s, fill: 'none', 'stroke-linecap': 'round', opacity: .5 }, gf(o.ribG ? o.ribG(i) : 'rib')); }
    if (on('cc') && r.st) { const a = P(r.end, sd), b = P(r.st, sd), m = P([(r.end[0] + r.st[0]) / 2 + (i < 7 ? 1.4 : 1), Math.max(r.end[1], r.st[1]) + (i < 5 ? 1.6 : 1.2)], sd), d = `M${a[0]} ${a[1]}Q${m[0]} ${m[1]} ${b[0]} ${b[1]}`; E('path', { d, stroke: B.TS('cart').dk, 'stroke-width': (r.w + .6) * s * .92, fill: 'none', 'stroke-linecap': 'round', opacity: dim.cc ? .25 : .9 }, gf(o.ribG ? o.ribG(i) : 'cc')); E('path', { d, stroke: tint.cc || B.TS('cart').c, 'stroke-width': r.w * s * .85, fill: 'none', 'stroke-linecap': 'round', opacity: dim.cc ? .25 : 1 }, gf(o.ribG ? o.ribG(i) : 'cc')); }
    if (on('cc') && i >= 10) { const a = P(r.end, sd), b = P([r.end[0] - 2.4, r.end[1] + 1.4], sd); E('path', { d: `M${a[0]} ${a[1]}L${b[0]} ${b[1]}`, stroke: B.TS('cart').c, 'stroke-width': r.w * s * .8, 'stroke-linecap': 'round', opacity: dim.cc ? .25 : 1 }, gf(o.ribG ? o.ribG(i) : 'cc')); } }));
  /* ৬. স্টার্নাম */
  bone('ster', poly(mirror(SK.manub)), 'bone', { lin: 0 }); bone('ster', poly(mirror(SK.sbody)), 'bone', { lin: 0 }); bone('ster', poly(mirror(SK.xiph)), 'cart', { lin: 0 });
  if (on('ster')) [100.2, 106.6, 113.4, 120.4].forEach(y => line('ster', `M${P([-4.4, y])[0]} ${P([0, y])[1]}H${P([4.4, y])[0]}`, .35, .35));
  /* ৭. কণ্ঠাস্থি (ক্ল্যাভিকল) */
  both(sd => { if (!on('clav')) return; const d = sm(SK.clav.map(p => P(p, sd)), false, .5); E('path', { d, stroke: B.TS('bone').dk, 'stroke-width': 4.2 * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.clav ? .25 : 1 }, gf('clav')); E('path', { d, stroke: tint.clav || B.TS('bone').c, 'stroke-width': 3 * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.clav ? .25 : 1 }, gf('clav')); E('path', { d, stroke: '#fffaf0', 'stroke-width': 1 * s, fill: 'none', opacity: dim.clav ? .1 : .6, transform: `translate(0 ${f1(-.7 * s)})` }, gf('clav')); });
  /* ৮. হাত: হিউমেরাস, আলনা, রেডিয়াস, কব্জি, করতল, আঙুল */
  both(sd => { bone('hum', sm(SK.hum.map(p => P(p, sd)), true, .42), 'bone', { lin: sd > 0 ? 0 : 180 }); const hh = P([46.6, 87.6], sd); if (on('hum')) E('path', { d: `M${f1(hh[0] - 3.6 * s * sd)} ${f1(hh[1] - 2.6 * s)}q${f1(2.4 * s * sd)} ${f1(-2.2 * s)} ${f1(5.4 * s * sd)} ${f1(-.6 * s)}`, stroke: '#fffaf0', 'stroke-width': .9 * s, fill: 'none', opacity: .6 }, gf('hum'));
    bone('uln', sm(SK.uln.map(p => P(p, sd)), true, .4), 'bone', { lin: 0 }); bone('rad', sm(SK.rad.map(p => P(p, sd)), true, .4), 'bone', { lin: 0 });
    SK.carp.forEach(([x, y, rx, ry], i) => { const c = P([x, y], sd); bone('carp', B.ellD(c[0], c[1], rx * s, ry * s, (i % 4 - 1.5) * 12 * sd), 'bone', { sw: .45 }); });
    SK.fing.forEach((f, j) => { const b = P(f.b, sd), h = P(f.h, sd); if (on('mcp')) B.tube(gf('mcp'), `M${b[0]} ${b[1]}L${h[0]} ${h[1]}`, (j === 4 ? 2.4 : 2) * s, 'bone', { sw: .5 * Math.sqrt(s), hl: false, op: dim.mcp ? .28 : 1 }); if (tint.mcp && on('mcp')) E('path', { d: `M${b[0]} ${b[1]}L${h[0]} ${h[1]}`, stroke: tint.mcp, 'stroke-width': 2 * s, opacity: .5, 'stroke-linecap': 'round' }, gf('mcp'));
      const ux = (f.h[0] - f.b[0]), uy = (f.h[1] - f.b[1]), L0 = Math.hypot(ux, uy), dx = ux / L0, dy = uy / L0; let cur = f.h.slice();
      f.L.forEach((L, k) => { if (!L) return; const nx = [cur[0] + dx * (L + .5), cur[1] + dy * (L + .5)], a = P([cur[0] + dx * .5, cur[1] + dy * .5], sd), b2 = P(nx, sd); if (on('phal')) { B.tube(gf('phal'), `M${a[0]} ${a[1]}L${b2[0]} ${b2[1]}`, (1.9 - k * .3) * s, 'bone', { sw: .45 * Math.sqrt(s), hl: false, op: dim.phal ? .28 : 1 }); if (tint.phal) E('path', { d: `M${a[0]} ${a[1]}L${b2[0]} ${b2[1]}`, stroke: tint.phal, 'stroke-width': (1.9 - k * .3) * s, opacity: .5, 'stroke-linecap': 'round' }, gf('phal')); } cur = nx; });
      if (j === 0 && sd > 0) A.fingTip = P(cur, sd); }); });
  /* ৯. পা: ফিমার, প্যাটেলা, টিবিয়া, ফিবুলা, গোড়ালি, পদতল, আঙুল */
  both(sd => { const fh = P(SK.fhead.slice(0, 2), sd); bone('fem', `M${f1(fh[0] + SK.fhead[2] * s)} ${fh[1]}a${f1(SK.fhead[2] * s)} ${f1(SK.fhead[2] * s)} 0 1 0 ${f1(-2 * SK.fhead[2] * s)} 0a${f1(SK.fhead[2] * s)} ${f1(SK.fhead[2] * s)} 0 1 0 ${f1(2 * SK.fhead[2] * s)} 0Z`);
    bone('fem', sm(SK.fem.map(p => P(p, sd)), true, .4), 'bone', { lin: sd > 0 ? 0 : 180 });
    bone('fib', sm(SK.fib.map(p => P(p, sd)), true, .4), 'bone', { lin: 0 }); bone('tib', sm(SK.tib.map(p => P(p, sd)), true, .4), 'bone', { lin: sd > 0 ? 0 : 180 });
    const pc = P(SK.pat.slice(0, 2), sd); bone('pat', B.ellD(pc[0], pc[1], SK.pat[2] * s, SK.pat[3] * s, 0), 'bone', { gr: { cx: .4, cy: .35, r: .7 } });
    bone('tars', sm(SK.tars.map(p => P(p, sd)), true, .45)); if (on('tars')) line('tars', sm([[17.6, 426.4], [22.6, 425], [28.4, 427]].map(p => P(p, sd)), false, .5), .4, .45);
    MT.forEach(([a, b], j) => { const pa = P(a, sd), pb = P(b, sd); if (on('mtt')) B.tube(gf('mtt'), `M${pa[0]} ${pa[1]}L${pb[0]} ${pb[1]}`, (j ? 2 : 2.8) * s, 'bone', { sw: .45 * Math.sqrt(s), hl: false, op: dim.mtt ? .28 : 1 });
      const dx = b[0] - a[0], dy = b[1] - a[1], L0 = Math.hypot(dx, dy), t1 = P([b[0] + dx / L0 * .6, b[1] + dy / L0 * .6], sd), t2 = P([b[0] + dx / L0 * (j ? 3.6 : 4.2), b[1] + dy / L0 * (j ? 3.6 : 4.2)], sd); if (on('toe')) B.tube(gf('toe'), `M${t1[0]} ${t1[1]}L${t2[0]} ${t2[1]}`, (j ? 1.7 : 2.5) * s, 'bone', { sw: .45 * Math.sqrt(s), hl: false, op: dim.toe ? .28 : 1 }); }); });
  /* ১০. গ্রীবাদেশীয় কশেরুকা পর্যন্ত আঁকা হয়েছে; এখন করোটি, চোয়াল, হাইঅয়েড */
  if (on('skull')) { const d = sm(mirror(SK.skullR), true, .42); bone('skull', d, 'bone', { gr: { cx: .42, cy: .28, r: .85 } }); const gg = gf('skull'), dk = '#3d2f20', op = dim.skull ? .3 : 1;
    both(sd => { E('path', { d: sm(SK.orbit.map(p => P(p, sd)), true, .5), fill: dk, opacity: .78 * op, stroke: B.TS('bone').dk, 'stroke-width': .6 }, gg);
      E('path', { d: sm([[5, 23], [9, 21.8], [13.4, 23]].map(p => P(p, sd)), false, .5), stroke: '#fffaf0', 'stroke-width': .8 * s, fill: 'none', opacity: .45 * op }, gg);
      line('skull', sm([[14.4, 32.4], [18.4, 33.6], [21.6, 36]].map(p => P(p, sd)), false, .5), .45, .45); line('skull', sm([[22.2, 33], [19.6, 31.6], [16, 31]].map(p => P(p, sd)), false, .5), .35, .35);
      const fo = P([8.6, 35.6], sd); E('circle', { cx: fo[0], cy: fo[1], r: .7 * s, fill: dk, opacity: .6 * op }, gg); const so = P([7.6, 20.2], sd); E('circle', { cx: so[0], cy: so[1], r: .55 * s, fill: dk, opacity: .5 * op }, gg); });
    E('path', { d: poly(mirror(SK.nasal)), fill: dk, opacity: .8 * op }, gg); line('skull', `M${P([0, 22.6])[0]} ${P([0, 22.6])[1]}L${P([0, 30.4])[0]} ${P([0, 30.4])[1]}`, .4, .5); line('skull', sm([[-2.6, 30.6], [-1.4, 25], [0, 22.6], [1.4, 25], [2.6, 30.6]].map(p => P(p)), false, .5), .4, .4);
    /* ওপরের দাঁত */ for (let i = -5; i <= 5; i++) { const x = i * 1.62, a = P([x - .7, 46.6]), w = 1.4 * s; E('rect', { x: f1(a[0]), y: f1(a[1]), width: f1(w), height: f1(2.2 * s), rx: .4 * s, fill: '#fbf8ef', stroke: '#a89c80', 'stroke-width': .3, opacity: op }, gg); } }
  if (on('mand')) { const d = sm(mirror(SK.mandR), false, .45) + 'L' + SK.mandIn.slice().reverse().map(p => P(p, -1)).concat(SK.mandIn.slice(1).map(p => P(p))).map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
    bone('mand', d, 'bone', { gr: { cx: .4, cy: .3, r: .8 } }); const gg = gf('mand'); for (let i = -5; i <= 5; i++) { const a = P([i * 1.5 - .65, 48.8]); E('rect', { x: f1(a[0]), y: f1(a[1]), width: f1(1.3 * s), height: f1(2.1 * s), rx: .4 * s, fill: '#fbf8ef', stroke: '#a89c80', 'stroke-width': .3, opacity: dim.mand ? .3 : 1 }, gg); }
    both(sd => { const mf = P([7, 54.4], sd); E('circle', { cx: mf[0], cy: mf[1], r: .6 * s, fill: '#3d2f20', opacity: .5 }, gg); }); }
  if (on('hyoid')) { const a = P([-5.2, 63.4]), b = P([5.2, 63.4]), m = P([0, 66.2]); E('path', { d: `M${a[0]} ${a[1]}Q${m[0]} ${m[1]} ${b[0]} ${b[1]}`, stroke: B.TS('bone').dk, 'stroke-width': 2 * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.hyoid ? .25 : 1 }, gf('hyoid')); E('path', { d: `M${a[0]} ${a[1]}Q${m[0]} ${m[1]} ${b[0]} ${b[1]}`, stroke: tint.hyoid || B.TS('bone').c, 'stroke-width': 1.3 * s, fill: 'none', 'stroke-linecap': 'round', opacity: dim.hyoid ? .25 : 1 }, gf('hyoid')); }

  /* নোঙর (লেবেলের জন্য) — ডান অর্ধ = দর্শকের ডান = দেহের বাম; L = দর্শকের বাম */
  const q = (p, sd = 1) => P(p, sd);
  Object.assign(A, { skull: q([12, 9]), face: q([-12, 40], 1), orbit: q([9, 26.5]), mand: q([12, 55]), hyoid: q([3, 64]), cerv: q([0, 70]), clav: q(wid([26, 78.4])), scap: q(wid([31, 104])), ster: q([0, 112]), rib: q([30, 122]), cc: q([16, 134]), thor: q([0, 150]), lumb: q([0, 180]),
    sac: q([0, 214]), cocc: q([0, 236]), hip: q(nar([-30, 192]), 1), hipR: q(nar([30, 192])), hum: q(wid([50, 128])), uln: q(wid([51, 210])), rad: q(wid([57.6, 214])), carp: q(wid([60, 251])), mcp: q(wid([60.2, 264])), phal: q(wid([62.4, 280])), fem: q([27, 290]), pat: q([23.4, 330]), tib: q([21.4, 385]), fib: q([30.4, 395]), tars: q([22, 427]), mtt: q([21.4, 435]), toe: q([21.6, 440]), fhead: q(SK.fhead.slice(0, 2)), knee: q([23, 340]), ankle: q([22, 421]), elbow: q(wid([52, 172])), wrist: q(wid([60, 245])), shoulder: q(wid([46, 86])), hipJ: q(nar([29, 220])) });
  ['hum', 'uln', 'rad', 'fem', 'tib', 'fib', 'clav', 'scap', 'rib', 'carp', 'mcp', 'phal', 'tars', 'mtt', 'toe', 'pat'].forEach(k => { A[k + 'L'] = [2 * X0 - A[k][0], A[k][1]]; });
  return A;
};
})();
