/* ═══════════════════════════════════════════════════════════════════
   visuals6 — পেশি টানে, ঠেলে না; রডস ও লিভার; হাঁটু; সন্ধি:
   antagonistic, leverClasses, leverCalc, kneeJoint, kneeMove, synovialJoint, jointTypes
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B27, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const rad = d => d * PI / 180;
/* পেশির পেট: মধ্যরেখা pts, সর্বোচ্চ প্রস্থ W, দুই প্রান্তে টেনডনের অংশ (ভগ্নাংশ) */
const belly = (g, pts, W, o = {}) => { const ta = o.ta != null ? o.ta : .14, tb = o.tb != null ? o.tb : .16, D = B.dense(pts, 10), n = D.length;
  const wf = u => u < ta || u > 1 - tb ? 2.4 : 2.4 + (W - 2.4) * Math.pow(Math.max(0, Math.sin(PI * (u - ta) / (1 - ta - tb))), .75);
  const L = [], R = []; for (let i = 0; i < n; i++) { const a = D[Math.max(0, i - 1)], b = D[Math.min(n - 1, i + 1)], l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, nx = -(b[1] - a[1]) / l, ny = (b[0] - a[0]) / l, w = wf(i / (n - 1)) / 2, bias = o.bias || 0; L.push([D[i][0] + nx * (w + bias * w), D[i][1] + ny * (w + bias * w)]); R.push([D[i][0] - nx * (w - bias * w), D[i][1] - ny * (w - bias * w)]); }
  const d = 'M' + L.concat(R.reverse()).map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  B.organ(g, d, 'mus', { sw: .8, gr: { cx: .4, cy: .35, r: .9 }, pat: 'line', pa: .22, po: { s: 2.6, a: o.fa || 0, w: .4 } });
  if (o.on) E('path', { d, fill: FK.alpha('#ff5a3a', .18 + .15 * (o.pulse || 0)), stroke: '#c0392b', 'stroke-width': 1.2 }, g);
  /* টেনডন (দুই প্রান্ত) */ const tA = D.slice(0, Math.max(2, Math.round(n * ta) + 1)), tB = D.slice(Math.round(n * (1 - tb)) - 1);
  [tA, tB].forEach(t => E('path', { d: 'M' + t.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L'), stroke: B.TS('tnd').dk, 'stroke-width': 3.4, fill: 'none', 'stroke-linecap': 'round' }, g)); [tA, tB].forEach(t => E('path', { d: 'M' + t.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L'), stroke: B.TS('tnd').c, 'stroke-width': 2.2, fill: 'none', 'stroke-linecap': 'round' }, g));
  return { mid: D[Math.round(n / 2)], o: D[0], i: D[n - 1] }; };
const longB = (g, a, b, w0, w1, k = 'bone') => { const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L, P = (u, w) => [a[0] + dx * u + nx * w, a[1] + dy * u + ny * w];
  const pts = [P(0, w0 * .9), P(.06, w0 * .62), P(.5, (w0 + w1) * .22), P(.94, w1 * .62), P(1, w1 * .9), P(1.03, 0), P(1, -w1 * .9), P(.94, -w1 * .62), P(.5, -(w0 + w1) * .22), P(.06, -w0 * .62), P(0, -w0 * .9), P(-.03, 0)];
  B.organ(g, sm(pts, true, .4), k, { sw: .9, lin: Math.atan2(ny, nx) * 180 / PI }); };

/* ═════════ বিপরীতধর্মী পেশি: বাইসেপস ও ট্রাইসেপস ═════════ */
const ARM = (ang) => { const S = [104, 34], El = [110, 176], Lf = 136, ph = rad(180 - ang), dir = [Math.sin(ph), Math.cos(ph)], Wr = [El[0] + dir[0] * Lf, El[1] + dir[1] * Lf], nrm = [dir[1], -dir[0]];
  const at = (u, off) => [El[0] + dir[0] * u + nrm[0] * off, El[1] + dir[1] * u + nrm[1] * off]; return { S, El, Wr, dir, nrm, at }; };
const AG = {
  flex: ['ভাঁজ (ফ্লেক্সন)', 'কনুই ভাঁজ: বাইসেপস সংকুচিত, ট্রাইসেপস শিথিল', 'বাইসেপস (সম্মুখ বাহু) সংকুচিত হয়ে খাটো ও মোটা হয় — টেনডন রেডিয়াসকে ওপরে টানে, কনুই ভাঁজ হয়। তখন পেছনের ট্রাইসেপস শিথিল হয়ে টানটান লম্বা হয়। বাইসেপস এখানে প্রধান কর্মী (অ্যাগোনিস্ট), ট্রাইসেপস বিপরীতধর্মী (অ্যান্টাগোনিস্ট)।'],
  ext: ['সোজা (এক্সটেনশন)', 'কনুই সোজা: ট্রাইসেপস সংকুচিত, বাইসেপস শিথিল', 'বাইসেপস নিজে বাহুকে ঠেলে সোজা করতে পারে না — পেশি শুধু টানে। তাই পেছনের ট্রাইসেপস সংকুচিত হয়ে আলনার অলিক্র্যানন প্রবর্ধক টেনে প্রকোষ্ঠ সোজা করে; এবার ট্রাইসেপস অ্যাগোনিস্ট, বাইসেপস অ্যান্টাগোনিস্ট।']
};
V.antagonistic = Object.assign({}, B.seg({
  id: 'antg', t: 'পেশি টানে, ঠেলে না: বিপরীতধর্মী পেশিজোড়', H: 330, def: 'flex', types: AG,
  sl: [{ k: 'a', l: 'কনুইয়ের কোণ (°)', min: 40, max: 175, step: 1, val: 90 }],
  cap: 'পেশি সংকোচনে শুধু খাটো হয়ে টান দিতে পারে; শিথিল হলে নিজে লম্বা হতে পারে না — অন্য পেশির টানে লম্বা হয়। তাই প্রতিটি সন্ধিতে বিপরীত দিকে টানা পেশিজোড় থাকে (বিপরীতধর্মী বা অ্যান্টাগোনিস্টিক পেশি): বাইসেপস-ট্রাইসেপস (কনুই), কোয়াড্রিসেপস-হ্যামস্ট্রিং (হাঁটু)। পেশির স্থির প্রান্ত উৎপত্তি (অরিজিন), সচল প্রান্ত সন্নিবেশ (ইনসারশন)।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; const v = ty === 'flex' ? 70 : 165; ctx.v.a = v; const el = ctx.root.querySelector('[data-sl="a"]'); if (el) { el.value = v; const o2 = ctx.root.querySelector('[data-slo="a"]'); if (o2) o2.textContent = FK.n(v, 0); } }
    const ang = ctx.v.a, A = ARM(ang), k = (175 - ang) / 135;
    /* স্ক্যাপুলা ও হিউমেরাস */ B.organ(g, sm([[60, 20], [118, 16], [124, 30], [104, 56], [78, 74], [62, 52]], true, .45), 'bone', { sw: .9 }); longB(g, [106, 38], A.El, 16, 18);
    /* আলনা ও রেডিয়াস */ const ul0 = [A.El[0] - A.nrm[0] * 6 - A.dir[0] * 8, A.El[1] - A.nrm[1] * 6 - A.dir[1] * 8], ul1 = A.at(Lf(), -3), ra0 = A.at(6, 5), ra1 = A.at(Lf(), 5); longB(g, ul0, ul1, 13, 7); longB(g, ra0, ra1, 7, 11);
    /* হাত */ const h0 = A.at(138, 0), h1 = A.at(176, 2); B.organ(g, sm([A.at(134, -9), A.at(150, -11), A.at(176, -6), A.at(180, 4), A.at(160, 12), A.at(134, 10)], true, .45), 'skin', { sw: .7, op: .9 });
    E('circle', { cx: A.El[0], cy: A.El[1], r: 4, fill: '#fffaf0', stroke: B.TS('bone').dk, 'stroke-width': 1 }, g);
    /* বাইসেপস: উৎপত্তি স্ক্যাপুলা → সন্নিবেশ রেডিয়াস */ const ins = A.at(22, 10), bi = [[118, 44], [128 + k * 6, 78], [134 + k * 12, 126 - k * 10], [(ins[0] + 134 + k * 12) / 2 + 2, (ins[1] + 150) / 2], ins];
    const flex = ty === 'flex', biW = flex ? 26 + 14 * k : 18, trW = !flex ? 30 + 6 * (1 - k) : 20;
    /* ট্রাইসেপস: স্ক্যাপুলা/হিউমেরাস → অলিক্র্যানন */ const ol = [A.El[0] - A.nrm[0] * 11 - A.dir[0] * 12, A.El[1] - A.nrm[1] * 11 - A.dir[1] * 12]; const tr = [[84, 52], [76, 84], [78, 130], [88, 160], ol];
    const RB = belly(g, bi, biW, { on: flex, ta: .12, tb: .2 }), RT = belly(g, tr, trW, { on: !flex, ta: .1, tb: .14 });
    this._lab = { bi: RB.mid, tr: RT.mid, bo: RB.o, bi2: RB.i, to: RT.o, ti: RT.i, hum: [112, 110], el: A.El, rad: A.at(80, 6), uln: A.at(80, -5) };
    const L = this._lab; B.lead(g, C, L.bi[0] + 8, L.bi[1], 300, 60, flex ? 'বাইসেপস (সংকুচিত)' : 'বাইসেপস (শিথিল)', { fs: 9.6, c: flex ? '#a8201a' : C.fg });
    B.lead(g, C, L.tr[0] - 10, L.tr[1], 20, 160, flex ? 'ট্রাইসেপস (শিথিল)' : 'ট্রাইসেপস (সংকুচিত)', { fs: 9.6, a: 'start', c: !flex ? '#a8201a' : C.fg });
    B.lead(g, C, L.bo[0], L.bo[1], 300, 22, 'উৎপত্তি (স্ক্যাপুলা)', { fs: 9.2 }); B.lead(g, C, L.bi2[0], L.bi2[1], 300, 104, 'সন্নিবেশ (রেডিয়াস)', { fs: 9.2 }); B.lead(g, C, L.el[0], L.el[1], 20, 214, 'কনুই (আলম্ব)', { fs: 9.2, a: 'start' }); B.lead(g, C, L.ti[0], L.ti[1], 20, 250, 'অলিক্র্যানন', { fs: 9.2, a: 'start' });
    B.tx(g, 352, 316, `কোণ ${Math.round(ang)}°`, { fs: 10, a: 'end', w: 700 });
    function Lf() { return 128; } },
  anim(g, C, ty, t, ctx) { /* সংকুচিত পেশিতে টানের তীর */ const L = this._lab || V.antagonistic._l; const ang = ctx.v.a, A = ARM(ang), flex = ty === 'flex', ph = (t * 1.5) % 1;
    const P = flex ? A.at(20, 9) : [A.El[0] - A.nrm[0] * 11 - A.dir[0] * 12, A.El[1] - A.nrm[1] * 11 - A.dir[1] * 12], Q = flex ? [118, 44] : [84, 52], dx = Q[0] - P[0], dy = Q[1] - P[1], l = Math.hypot(dx, dy);
    const a = [P[0] + dx / l * (10 + ph * 18), P[1] + dy / l * (10 + ph * 18)]; E('path', { d: `M${f1(P[0] + dx / l * 6)} ${f1(P[1] + dy / l * 6)}L${f1(a[0])} ${f1(a[1])}`, stroke: '#c0392b', 'stroke-width': 2.4, 'marker-end': B.mk(g, '#c0392b', 6), opacity: .85 }, g); }
}));

/* ═════════ লিভারের তিন শ্রেণি ═════════ */
const LV = {
  c1: ['প্রথম শ্রেণি', 'প্রথম শ্রেণির লিভার — আলম্ব মাঝে (E–F–L)', 'আলম্ব (F) বল (E) ও ভারের (L) মাঝে — যেমন কাঁচি, ঢেঁকি। দেহে: মাথা সামনে-পেছনে নাড়া — অ্যাটলাস-অক্সিপিটাল সন্ধি আলম্ব, মুখমণ্ডলের ভার সামনে, ঘাড়ের পেছনের পেশি (স্প্লেনিয়াস, ট্র্যাপিজিয়াস) বল দেয়। ট্রাইসেপস দিয়ে কনুই সোজা করাও প্রথম শ্রেণি।'],
  c2: ['দ্বিতীয় শ্রেণি', 'দ্বিতীয় শ্রেণির লিভার — ভার মাঝে (F–L–E)', 'ভার আলম্ব ও বলের মাঝে — যেমন এক চাকার ঠেলাগাড়ি, জাঁতি। দেহে: পায়ের আঙুলে ভর দিয়ে দাঁড়ানো — আঙুলের গোড়ার সন্ধি আলম্ব, দেহের ভার টিবিয়া দিয়ে মাঝে, পায়ের ডিমের পেশি (গ্যাস্ট্রোকনেমিয়াস) অ্যাকিলিস টেনডন দিয়ে গোড়ালিতে বল দেয়। বলবাহু বড় — অল্প বলে বেশি ভার তোলা যায় (যান্ত্রিক সুবিধা > 1)।'],
  c3: ['তৃতীয় শ্রেণি', 'তৃতীয় শ্রেণির লিভার — বল মাঝে (F–E–L)', 'বল আলম্ব ও ভারের মাঝে — যেমন চিমটা, বঁড়শির ছিপ। দেহে সবচেয়ে বেশি: হাতে বস্তু তুলে কনুই ভাঁজ — কনুই আলম্ব, বাইসেপসের সন্নিবেশ কাছে (বল), হাতের বস্তু দূরে (ভার)। যান্ত্রিক সুবিধা < 1 — বল বেশি লাগে, কিন্তু হাত দ্রুত ও অনেক দূর নড়ে।']
};
const LVP = { c1: { F: 180, E: 70, L: 300, eUp: false }, c2: { F: 60, L: 180, E: 300, eUp: true }, c3: { F: 60, E: 130, L: 300, eUp: true } };
V.leverClasses = Object.assign({}, B.seg({
  id: 'levc', t: 'দেহের লিভার: তিন শ্রেণি', H: 320, def: 'c3', types: LV,
  cap: 'কঙ্কালতন্ত্র "রডস ও লিভার" তন্ত্র: অস্থি দণ্ড (রড), সন্ধি আলম্ব (ফালক্রাম), পেশির টান বল (এফোর্ট) এবং দেহাংশের ওজন বা বহনকৃত বস্তু ভার (লোড)। কোনটি মাঝে আছে তা দিয়ে শ্রেণি চেনা যায় — মনে রাখার কৌশল "1-F, 2-L, 3-E মাঝে"। যান্ত্রিক সুবিধা = বলবাহু ÷ ভারবাহু।',
  art(g, C, ty) { const P = LVP[ty], y = 96, bo = B.TS('bone');
    /* ওপরে সাধারণ লিভার নকশা */ E('rect', { x: 40, y: y - 5, width: 280, height: 10, rx: 4, fill: B.lin(g, 'bone', 90), stroke: bo.dk, 'stroke-width': .8 }, g);
    E('path', { d: `M${P.F} ${y + 5}l-14 26h28Z`, fill: '#5a6a7a', stroke: '#2a3a4a' }, g); B.tx(g, P.F + (ty === 'c1' ? 0 : -30), y + 42, 'F (আলম্ব)', { fs: 9.6, a: 'middle', w: 700, c: '#2a3a4a' });
    E('rect', { x: P.L - 16, y: y - 37, width: 32, height: 32, rx: 4, fill: '#b06a3a', stroke: '#6a3a1a' }, g); B.tx(g, P.L, y - 44, 'L (ভার)', { fs: 9.6, a: 'middle', w: 700, c: '#6a3a1a' });
    B.tx(g, P.E, P.eUp ? y - 56 : y + 100, 'E (বল)', { fs: 9.6, a: 'middle', w: 700, c: '#a8201a' });
    /* বলবাহু ও ভারবাহু */ const arm = (x0, x1, yy, s2, col) => { E('path', { d: `M${x0} ${yy}H${x1}`, stroke: col, 'stroke-width': 1, 'marker-start': B.mk(g, col, 5), 'marker-end': B.mk(g, col, 5) }, g); B.tx(g, (x0 + x1) / 2, yy + 13, s2, { fs: 8.8, a: 'middle', c: col }); };
    arm(Math.min(P.F, P.E), Math.max(P.F, P.E), y + (ty === 'c1' ? 76 : 50), 'বলবাহু', '#a8201a'); arm(Math.min(P.F, P.L), Math.max(P.F, P.L), y + (ty === 'c1' ? 50 : 76), 'ভারবাহু', '#6a3a1a');
    /* নিচে দেহের উদাহরণ */ const yb = 236; E('path', { d: `M10 ${yb - 40}H350`, stroke: FK.alpha(C.fg, .12) }, g);
    if (ty === 'c1') { B.skullLat(g, C, { x: 130, y: yb - 34, s: .48 }); B.tube(g, `M${130 + 150 * .48} ${yb + 30}L${130 + 150 * .48 - 4} ${yb + 74}`, 12, 'bone', { sw: .7 }); E('path', { d: `M${130 + 140 * .48} ${yb + 30}l-8 14h16Z`, fill: '#5a6a7a' }, g); B.tx(g, 236, yb + 20, 'ঘাড়ের পেশি → E', { fs: 9.2, c: '#a8201a', w: 650 }); B.tx(g, 30, yb + 20, 'মুখের ভার ↓ L', { fs: 9.2, c: '#6a3a1a', w: 650 }); B.tx(g, 152, yb + 70, 'F', { fs: 10, w: 700 }); }
    if (ty === 'c2') { const sk = B.TS('skin'); B.tube(g, `M200 ${yb - 36}L196 ${yb + 30}`, 12, 'bone', { sw: .7 }); B.organ(g, sm([[150, yb + 66], [176, yb + 38], [212, yb + 26], [232, yb + 34], [236, yb + 52], [204, yb + 58], [168, yb + 70]], true, .5), 'bone', { sw: .8 });
      B.organ(g, 'M232 ' + (yb - 30) + ' Q246 ' + (yb) + ' 236 ' + (yb + 38) + ' L228 ' + (yb + 36) + ' Q236 ' + yb + ' 222 ' + (yb - 28) + 'Z', 'mus', { sw: .7 }); E('path', { d: `M150 ${yb + 66}l-10 14h20Z`, fill: '#5a6a7a' }, g); B.tx(g, 132, yb + 92, 'F: আঙুলের গোড়া', { fs: 9, w: 650 }); B.tx(g, 250, yb - 6, 'E: পায়ের ডিম ↑', { fs: 9, c: '#a8201a', w: 650 }); B.tx(g, 176, yb - 44, 'L: দেহের ভার ↓', { fs: 9, c: '#6a3a1a', w: 650 }); }
    if (ty === 'c3') { longB(g, [60, yb + 4], [250, yb + 18], 12, 8); B.organ(g, sm([[246, yb + 6], [276, yb + 4], [300, yb + 14], [296, yb + 28], [262, yb + 30], [246, yb + 26]], true, .5), 'skin', { sw: .7 }); E('rect', { x: 284, y: yb - 20, width: 26, height: 26, rx: 3, fill: '#b06a3a', stroke: '#6a3a1a' }, g);
      longB(g, [60, yb - 90], [60, yb], 12, 12); belly(g, [[74, yb - 86], [86, yb - 50], [96, yb - 16], [106, yb + 4]], 16, { on: true }); E('circle', { cx: 60, cy: yb + 2, r: 5, fill: '#5a6a7a' }, g); B.tx(g, 40, yb + 34, 'F: কনুই', { fs: 9, w: 650 }); B.tx(g, 116, yb - 30, 'E: বাইসেপস', { fs: 9, c: '#a8201a', w: 650 }); B.tx(g, 300, yb + 50, 'L: হাতের বস্তু', { fs: 9, a: 'middle', c: '#6a3a1a', w: 650 }); } },
  anim(g, C, ty, t) { const P = LVP[ty], y = 96, k = Math.sin(t * 2) * 3; E('path', { d: P.eUp ? `M${P.E} ${y - 10}V${f1(y - 48 + k)}` : `M${P.E} ${y + 10}V${f1(y + 54 + k)}`, stroke: '#c0392b', 'stroke-width': 2.6, 'marker-end': B.mk(g, '#c0392b', 7) }, g); E('path', { d: `M${P.L} ${y - 40}V${f1(y - 70 - k)}`, stroke: 'none' }, g); }
}));

/* ═════════ লিভারের হিসাব: প্রকোষ্ঠ (তৃতীয় শ্রেণি) ═════════ */
const LC = { arm: ['প্রকোষ্ঠ', 'কনুই ভাঁজ করে ভার তোলা (তৃতীয় শ্রেণি)', 'বলবাহু (কনুই থেকে বাইসেপসের সন্নিবেশ) প্রায় 4 সেমি, ভারবাহু (কনুই থেকে হাতের তালু) প্রায় 32 সেমি। সাম্যাবস্থায় বল × বলবাহু = ভার × ভারবাহু।'], toe: ['পায়ের আঙুলে ভর', 'আঙুলে ভর দিয়ে ওঠা (দ্বিতীয় শ্রেণি)', 'আলম্ব আঙুলের গোড়ায়; ভারবাহু (আলম্ব থেকে টিবিয়ার ভার-রেখা) প্রায় 12 সেমি, বলবাহু (আলম্ব থেকে গোড়ালিতে অ্যাকিলিস টেনডন) প্রায 17 সেমি।'] };
const LCD = { arm: { ea: 4, la: 32, w: 5 }, toe: { ea: 17, la: 12, w: 60 } };
V.leverCalc = Object.assign({}, B.seg({
  id: 'levk', t: 'লিভারের হিসাব: পেশিকে কত বল দিতে হয়?', H: 260, def: 'arm', types: LC,
  sl: [{ k: 'w', l: 'ভার (কেজি)', min: 1, max: 80, step: 1, val: 5 }],
  cap: 'লিভারের নীতি: বল × বলবাহু = ভার × ভারবাহু, তাই বল = ভার × ভারবাহু ÷ বলবাহু; যান্ত্রিক সুবিধা (MA) = বলবাহু ÷ ভারবাহু = ভার ÷ বল। (সহজ করার জন্য অস্থির নিজের ওজন ও কোণ ধরা হয়নি; 1 কেজি ভার ≈ 9.8 নিউটন।)',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; const v = LCD[ty].w; ctx.v.w = v; const el = ctx.root.querySelector('[data-sl="w"]'); if (el) { el.value = v; const o2 = ctx.root.querySelector('[data-slo="w"]'); if (o2) o2.textContent = FK.n(v, 0); } }
    const D = LCD[ty], w = ctx.v.w, F = w * D.la / D.ea, MA = D.ea / D.la, y = 120, x0 = 40, sc = 260 / (Math.max(D.ea, D.la) + 4);
    const xF = ty === 'arm' ? x0 : x0, xE = x0 + D.ea * sc, xL = x0 + D.la * sc;
    E('rect', { x: x0 - 6, y: y - 5, width: Math.max(xE, xL) - x0 + 20, height: 10, rx: 4, fill: B.lin(g, 'bone', 90), stroke: B.TS('bone').dk, 'stroke-width': .8 }, g); E('path', { d: `M${xF} ${y + 5}l-12 22h24Z`, fill: '#5a6a7a' }, g);
    const fl = Math.min(110, 18 + F * (ty === 'arm' ? 1.6 : .7)), ll = Math.min(90, 14 + w * (ty === 'arm' ? 2.6 : .9));
    E('path', { d: `M${f1(xE)} ${y - 6}V${f1(y - 6 - fl * .6)}`, stroke: '#c0392b', 'stroke-width': 3, 'marker-end': B.mk(g, '#c0392b', 8) }, g); E('path', { d: `M${f1(xL)} ${y + 6}V${f1(y + 6 + ll * .6)}`, stroke: '#6a3a1a', 'stroke-width': 3, 'marker-end': B.mk(g, '#6a3a1a', 8) }, g);
    B.tx(g, xE, y - 14 - fl * .6, 'E', { fs: 11, a: 'middle', w: 700, c: '#a8201a' }); B.tx(g, xL, y + 26 + ll * .6, 'L = ' + w + ' কেজি', { fs: 10, a: 'middle', w: 700, c: '#6a3a1a' }); B.tx(g, xF, y + 42, 'F', { fs: 11, a: 'middle', w: 700 });
    E('path', { d: `M${xF} ${y + 54}H${f1(xE)}`, stroke: '#a8201a', 'stroke-width': 1, 'marker-start': B.mk(g, '#a8201a', 5), 'marker-end': B.mk(g, '#a8201a', 5) }, g); B.tx(g, (xF + xE) / 2, y + 66, D.ea + ' সেমি', { fs: 8.8, a: 'middle', c: '#a8201a' });
    E('path', { d: `M${xF} ${y + 76}H${f1(xL)}`, stroke: '#6a3a1a', 'stroke-width': 1, 'marker-start': B.mk(g, '#6a3a1a', 5), 'marker-end': B.mk(g, '#6a3a1a', 5) }, g); B.tx(g, (xF + xL) / 2, y + 88, D.la + ' সেমি', { fs: 8.8, a: 'middle', c: '#6a3a1a' });
    E('rect', { x: 10, y: 214, width: 340, height: 40, rx: 8, fill: FK.alpha('#c04a5a', .08), stroke: FK.alpha('#c04a5a', .3) }, g);
    B.tx(g, 20, 230, `বল = ${w} × ${D.la} ÷ ${D.ea} = ${FK.n(F, 1)} কেজি-ভার (≈ ${FK.n(F * 9.8, 0)} N)`, { fs: 10, w: 650 }); B.tx(g, 20, 247, `যান্ত্রিক সুবিধা = ${D.ea} ÷ ${D.la} = ${FK.n(MA, 2)} ${MA < 1 ? '(< 1: বল বেশি, গতি বেশি)' : '(> 1: অল্প বলে বেশি ভার)'}`, { fs: 9.6, c: MA < 1 ? '#a8201a' : '#1f6a3a' }); },
  anim(g, C, ty, t) { const k = (Math.sin(t * 1.6) + 1) / 2; E('circle', { cx: 40, cy: 120, r: 6 + k * 3, fill: 'none', stroke: FK.alpha('#5a6a7a', .5 - k * .3), 'stroke-width': 1.4 }, g); }
}));

/* ═════════ হাঁটুসন্ধি (লম্বচ্ছেদ, পাশ থেকে) ═════════ */
const KJ = { fem: [[118, 8], [176, 8], [178, 120], [190, 150], [196, 176], [186, 198], [160, 206], [132, 202], [114, 186], [110, 160], [116, 120]], tib: [[110, 222], [138, 214], [176, 214], [206, 220], [210, 232], [190, 244], [182, 296], [180, 330], [140, 330], [140, 296], [128, 248], [108, 236]] };
V.kneeJoint = Object.assign({ t: 'হাঁটুসন্ধি (পাশ থেকে লম্বচ্ছেদ)', k: ['2d', 'anim', 'int', 'quiz'], cap: 'দেহের বৃহত্তম ও জটিলতম সাইনোভিয়াল সন্ধি — ফিমার, টিবিয়া ও প্যাটেলা মিলে; প্রধানত কবজা সন্ধি (ভাঁজ-সোজা), ভাঁজ অবস্থায় সামান্য ঘোরে। ভেতরের দুটি ক্রুশিয়েট লিগামেন্ট আড়াআড়ি "X" এর মতো সামনে-পেছনে পিছলে যাওয়া আটকায়; C আকৃতির দুটি মেনিসকাস ধাক্কা শোষণ করে। (সামনে ডান দিকে)' },
  BK.diagram({ W: 360, H: 346, label: 'হাঁটুসন্ধি', idle: true,
    art(g, C, part) { const G = {}; const P = k => G[k] || (G[k] = part(k)), ca = B.TS('cart');
      /* পেশি ও টেনডন (পেছনে ও সামনে) */ B.organ(P('quad'), sm([[188, 0], [222, 0], [230, 60], [226, 110], [214, 130], [200, 120], [192, 60]], true, .45), 'mus', { sw: .8, pat: 'line', po: { s: 3, a: 85, w: .4 } }); B.organ(P('quad'), 'M200 112 L224 112 L232 150 L212 150 Z', 'tnd', { sw: .8 });
      B.organ(P('ham'), sm([[66, 0], [102, 0], [104, 80], [98, 170], [94, 240], [82, 240], [78, 170], [70, 80]], true, .45), 'mus', { sw: .8, op: .85, pat: 'line', po: { s: 3, a: 95, w: .4 } }); B.organ(P('ham'), 'M80 240 L96 240 L112 268 L100 274 Z', 'tnd', { sw: .7 });
      /* সন্ধি-আবরণী ও সাইনোভিয়াল গহ্বর */ E('path', { d: sm([[116, 110], [112, 160], [104, 210], [112, 250], [150, 248], [210, 246], [236, 226], [242, 176], [236, 120], [226, 90], [206, 86], [196, 110]], true, .45), fill: B.TS('syn').c, stroke: '#b07a9a', 'stroke-width': 1.6 }, P('syn'));
      E('path', { d: sm([[198, 90], [222, 70], [236, 84], [230, 110]], false, .5), stroke: '#b07a9a', 'stroke-width': 1.4, fill: FK.alpha(B.TS('syn').c, .8) }, P('bur'));
      /* ফিমার ও টিবিয়া */ B.organ(P('fem'), sm(KJ.fem, true, .4), 'bone', { sw: 1, lin: 0 }); B.organ(P('tib'), sm(KJ.tib, true, .4), 'bone', { sw: 1, lin: 0 }); B.organ(P('fib'), sm([[112, 238], [128, 244], [126, 330], [114, 330], [110, 260]], true, .4), 'bone', { sw: .9, lin: 0, op: .7 });
      /* তরুণাস্থি */ E('path', { d: sm([[114, 178], [124, 198], [152, 206], [182, 200], [196, 176], [194, 156]], false, .5), stroke: ca.dk, 'stroke-width': 6.4, fill: 'none', 'stroke-linecap': 'round' }, P('art')); E('path', { d: sm([[114, 178], [124, 198], [152, 206], [182, 200], [196, 176], [194, 156]], false, .5), stroke: ca.c, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, P('art'));
      E('path', { d: 'M112 222 Q160 210 206 222', stroke: ca.dk, 'stroke-width': 5.4, fill: 'none', 'stroke-linecap': 'round' }, P('art')); E('path', { d: 'M112 222 Q160 210 206 222', stroke: ca.c, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, P('art'));
      /* মেনিসকাস (কীলক) */ [[118, 214, 1], [200, 214, -1]].forEach(([x, y, sd]) => E('path', { d: `M${x - sd * 6} ${y + 4}L${x + sd * 24} ${y + 2}L${x - sd * 6} ${y - 8}Z`, fill: B.TS('fcart').c, stroke: B.TS('fcart').dk, 'stroke-width': .8 }, P('men')));
      /* ক্রুশিয়েট লিগামেন্ট */ B.tube(P('acl'), 'M140 200L176 218', 6, 'lig', { sw: .6 }); B.tube(P('pcl'), 'M168 198L128 220', 6, 'lig', { sw: .6 }); E('path', { d: 'M140 200L176 218', stroke: '#c07a20', 'stroke-width': 1.4, opacity: .8 }, P('acl')); E('path', { d: 'M168 198L128 220', stroke: '#2a6ab0', 'stroke-width': 1.4, opacity: .8 }, P('pcl'));
      /* প্যাটেলা ও লিগামেন্ট */ B.organ(P('pat'), sm([[210, 144], [230, 148], [238, 176], [230, 202], [212, 200], [206, 172]], true, .45), 'bone', { sw: 1 }); E('path', { d: 'M208 152 Q204 176 210 198', stroke: ca.c, 'stroke-width': 4 }, P('pat'));
      B.organ(P('plig'), 'M216 200 L234 200 L214 264 L198 262 Z', 'tnd', { sw: .8 }); B.organ(P('fat'), sm([[200, 206], [214, 210], [208, 238], [196, 246], [186, 228]], true, .5), 'fat', { sw: .6, op: .9 });
      hits(this.parts, part, 9); },
    idle(g, C, t) { /* সাইনোভিয়াল তরলের চলাচল */ for (let i = 0; i < 6; i++) { const u = (t * .25 + i / 6) % 1, th = u * 2 * PI, x = 172 + 58 * Math.cos(th), y = 176 + 64 * Math.sin(th); E('circle', { cx: f1(x), cy: f1(y), r: 1.6, fill: '#5a9ac0', opacity: .6 }, g); } },
    parts: [
      { id: 'fem', bn: 'ফিমার (কন্ডাইল)', lb: 'ফিমার', en: 'Femur', fn: 'ঊর্বস্থির নিচের গোল কন্ডাইল টিবিয়ার চ্যাপ্টা প্লেটোর ওপর গড়ায় ও পিছলায়।', a: [146, 60], l: [40, 30], an: 'middle' },
      { id: 'quad', bn: 'কোয়াড্রিসেপস ও তার টেনডন', lb: 'কোয়াড্রিসেপস', en: 'Quadriceps', fn: 'উরুর সামনের চার মাথার পেশি — সংকুচিত হলে প্যাটেলা ও প্যাটেলার লিগামেন্টের মাধ্যমে টিবিয়া টেনে হাঁটু সোজা করে (লাথি মারা, সিঁড়ি ওঠা)।', a: [212, 60], l: [292, 26], an: 'start' },
      { id: 'bur', bn: 'সুপ্রাপ্যাটেলার বারসা', lb: 'বারসা', en: 'Suprapatellar bursa', fn: 'টেনডন ও অস্থির মাঝে তরলভরা থলি — ঘর্ষণ কমায়; হাঁটুর সন্ধিগহ্বরের সাথে যুক্ত।', a: [226, 82], l: [292, 72], an: 'start' },
      { id: 'pat', bn: 'প্যাটেলা (জানুফলক)', lb: 'প্যাটেলা', en: 'Patella', fn: 'কোয়াড্রিসেপস টেনডনের ভেতরের সিসাময়েড অস্থি — পেছনে তরুণাস্থি; টেনডনকে ফিমার থেকে দূরে রেখে টানের বাহু বাড়ায় — ফলে কোয়াড্রিসেপস কম বলে বেশি কাজ করতে পারে।', a: [224, 174], l: [292, 126], an: 'start' },
      { id: 'syn', bn: 'সাইনোভিয়াল গহ্বর ও পর্দা', lb: 'সাইনোভিয়াল', en: 'Synovial cavity', fn: 'সন্ধি-আবরণীর ভেতরের সাইনোভিয়াল পর্দা ডিমের সাদা অংশের মতো পিচ্ছিল সাইনোভিয়াল তরল ক্ষরণ করে — ঘর্ষণ কমায় ও তরুণাস্থিকে পুষ্টি দেয়।', a: [238, 150], l: [292, 176], an: 'start' },
      { id: 'plig', bn: 'প্যাটেলার লিগামেন্ট', lb: 'প্যাটেলার লিগামেন্ট', en: 'Patellar ligament', fn: 'প্যাটেলা থেকে টিবিয়াল টিউবারোসিটি পর্যন্ত — আসলে কোয়াড্রিসেপস টেনডনের ধারাবাহিক অংশ; এখানে হাতুড়ি দিলে হাঁটু-ঝাঁকুনি প্রতিবর্ত হয়।', a: [214, 238], l: [272, 334], an: 'middle' },
      { id: 'fat', bn: 'চর্বির প্যাড', lb: 'চর্বি', en: 'Infrapatellar fat pad', fn: 'প্যাটেলার লিগামেন্টের পেছনে নরম চর্বি — সন্ধির ফাঁক পূরণ করে ও গদির কাজ করে।', a: [202, 226], l: [292, 226], an: 'start' },
      { id: 'tib', bn: 'টিবিয়া', lb: 'টিবিয়া', en: 'Tibia', fn: 'নলার মোটা অস্থি — চ্যাপ্টা প্লেটোতে দুটি মেনিসকাস বসে।', a: [160, 290], l: [292, 276], an: 'start' },
      { id: 'art', bn: 'সন্ধি-তরুণাস্থি', lb: 'সন্ধি-তরুণাস্থি', en: 'Articular cartilage', fn: 'ফিমার, টিবিয়া ও প্যাটেলার সন্ধিতল ঢাকা মসৃণ হায়ালিন তরুণাস্থি (হাঁটুতে প্রায় 2–4 মিলিমিটার পুরু)।', a: [150, 205], l: [40, 290], an: 'middle' },
      { id: 'men', bn: 'মেনিসকাস (তন্তুময় তরুণাস্থি)', lb: 'মেনিসকাস', en: 'Meniscus', fn: 'ভেতরের ও বাইরের C আকৃতির দুটি তন্তুময় তরুণাস্থির চাকতি — সন্ধিতল গভীর করে, ধাক্কা শোষণ ও ভার ছড়িয়ে দেয়। মোচড়ে ছিঁড়ে যাওয়া খেলোয়াড়দের সাধারণ আঘাত।', a: [126, 212], l: [40, 250], an: 'middle' },
      { id: 'acl', bn: 'সম্মুখ ক্রুশিয়েট লিগামেন্ট (ACL)', lb: 'ACL', en: 'Anterior cruciate ligament', fn: 'টিবিয়াকে ফিমারের সামনে পিছলে যেতে বাধা দেয়; হঠাৎ দিক বদল বা লাফ দিয়ে নামায় ছিঁড়ে যায় (ফুটবল, ক্রিকেট খেলোয়াড়)।', a: [168, 214], l: [196, 334], an: 'middle' },
      { id: 'pcl', bn: 'পশ্চাৎ ক্রুশিয়েট লিগামেন্ট (PCL)', lb: 'PCL', en: 'Posterior cruciate ligament', fn: 'টিবিয়াকে পেছনে সরে যেতে বাধা দেয় — ACL এর চেয়ে মোটা ও শক্ত।', a: [136, 216], l: [140, 334], an: 'middle' },
      { id: 'ham', bn: 'হ্যামস্ট্রিং পেশি', lb: 'হ্যামস্ট্রিং', en: 'Hamstrings', fn: 'উরুর পেছনের তিনটি পেশি — টিবিয়া ও ফিবুলার পেছনে যুক্ত; সংকুচিত হলে হাঁটু ভাঁজ করে। কোয়াড্রিসেপসের বিপরীতধর্মী।', a: [84, 120], l: [40, 160], an: 'middle' },
      { id: 'fib', bn: 'ফিবুলা', lb: 'ফিবুলা', en: 'Fibula', fn: 'হাঁটুসন্ধিতে সরাসরি অংশ নেয় না — টিবিয়ার পাশে নিচে যুক্ত।', a: [120, 300], l: [40, 320], an: 'middle' }
    ]
  }));

/* ═════════ হাঁটু সঞ্চালনে অস্থি ও পেশির সমন্বয় ═════════ */
const KM = {
  ext: ['সোজা করা', 'হাঁটু সোজা করা (এক্সটেনশন)', 'কোয়াড্রিসেপস সংকুচিত → প্যাটেলা ও প্যাটেলার লিগামেন্ট টিবিয়াকে সামনে টানে → হাঁটু সোজা (বল লাথি মারা, চেয়ার থেকে ওঠা)। হ্যামস্ট্রিং তখন শিথিল ও প্রসারিত।'],
  flex: ['ভাঁজ করা', 'হাঁটু ভাঁজ করা (ফ্লেক্সন)', 'হ্যামস্ট্রিং (ও গ্যাস্ট্রোকনেমিয়াস) সংকুচিত → টিবিয়ার পেছন টেনে হাঁটু ভাঁজ; কোয়াড্রিসেপস শিথিল। ভাঁজের শুরুতে পপলিটিয়াস পেশি হাঁটুর "তালা" খোলে।'],
  walk: ['হাঁটা', 'হাঁটার চক্রে হাঁটুর কাজ', 'পা মাটিতে পড়ার সময় হাঁটু প্রায় সোজা — কোয়াড্রিসেপস ভার নেয়; পা সামনে দোলানোর সময় হ্যামস্ট্রিং হাঁটু ভাঁজ করে পা মাটি থেকে তোলে, পরে কোয়াড্রিসেপস আবার সোজা করে; গোড়ালিতে কাফ পেশি ধাক্কা দেয়। একটি চক্রে হাঁটু 0° থেকে প্রায় 60–70° পর্যন্ত ভাঁজ হয়।']
};
const LEG = (kAng, hip = [150, 30], thighAng = 0) => { const Lt = 140, Ls = 140, ta = rad(thighAng), K = [hip[0] + Math.sin(ta) * Lt, hip[1] + Math.cos(ta) * Lt], sa = ta - rad(kAng), A = [K[0] + Math.sin(sa) * Ls, K[1] + Math.cos(sa) * Ls]; return { H: hip, K, A, ta, sa }; };
const kmDraw = (g, C, ty, kA, thA, act) => { const L = LEG(kA, [150, 24], thA), ex = act ? act === 'q' : ty !== 'flex', fl = act ? act === 'h' : ty === 'flex';
  /* উরু ও নলার ত্বক-রেখা (হালকা) */ const n = [Math.cos(L.ta), -Math.sin(L.ta)], ns = [Math.cos(L.sa), -Math.sin(L.sa)];
  longB(g, L.H, L.K, 16, 20); const tib0 = [L.K[0] + Math.sin(L.sa) * 8, L.K[1] + Math.cos(L.sa) * 8]; longB(g, tib0, L.A, 18, 12); longB(g, [tib0[0] - ns[0] * 10 + Math.sin(L.sa) * 10, tib0[1] - ns[1] * 10 + Math.cos(L.sa) * 10], [L.A[0] - ns[0] * 9, L.A[1] - ns[1] * 9], 7, 7);
  /* পায়ের পাতা */ const fa = L.sa + rad(90), F1 = [L.A[0] + Math.sin(fa) * 56, L.A[1] + Math.cos(fa) * 56]; B.organ(g, sm([[L.A[0] - ns[0] * 14, L.A[1] - ns[1] * 14 + 4], [L.A[0], L.A[1] - 4], [F1[0], F1[1] - 4], [F1[0] + 4, F1[1] + 6], [L.A[0] - ns[0] * 14, L.A[1] - ns[1] * 14 + 12]], true, .5), 'bone', { sw: .8 });
  E('circle', { cx: f1(L.K[0]), cy: f1(L.K[1]), r: 5, fill: '#fffaf0', stroke: B.TS('bone').dk }, g);
  /* প্যাটেলা */ const pk = [L.K[0] + n[0] * 22 + Math.sin(L.ta) * -2, L.K[1] + n[1] * 22]; B.organ(g, B.ellD(pk[0], pk[1], 6, 9, -thA), 'bone', { sw: .8 });
  /* কোয়াড্রিসেপস: নিতম্ব সামনে → প্যাটেলা → টিবিয়াল টিউবারোসিটি */ const q0 = [L.H[0] + n[0] * 12, L.H[1] + n[1] * 12 + 6], qm = [L.H[0] + n[0] * 28 + Math.sin(L.ta) * 70, L.H[1] + n[1] * 28 + Math.cos(L.ta) * 70], tt = [tib0[0] + ns[0] * 12 + Math.sin(L.sa) * 26, tib0[1] + ns[1] * 12 + Math.cos(L.sa) * 26];
  belly(g, [q0, qm, pk], ex ? 34 : 26, { on: ex, ta: .06, tb: .14 }); E('path', { d: `M${f1(pk[0])} ${f1(pk[1])}L${f1(tt[0])} ${f1(tt[1])}`, stroke: B.TS('tnd').dk, 'stroke-width': 4.4, 'stroke-linecap': 'round' }, g); E('path', { d: `M${f1(pk[0])} ${f1(pk[1])}L${f1(tt[0])} ${f1(tt[1])}`, stroke: B.TS('tnd').c, 'stroke-width': 3, 'stroke-linecap': 'round' }, g);
  /* হ্যামস্ট্রিং: ইসকিয়াম পেছনে → টিবিয়ার পেছন */ const h0 = [L.H[0] - n[0] * 14, L.H[1] - n[1] * 14 + 10], hm = [L.H[0] - n[0] * 26 + Math.sin(L.ta) * 80, L.H[1] - n[1] * 26 + Math.cos(L.ta) * 80], hi = [tib0[0] - ns[0] * 14 + Math.sin(L.sa) * 22, tib0[1] - ns[1] * 14 + Math.cos(L.sa) * 22];
  belly(g, [h0, hm, [L.K[0] - n[0] * 16, L.K[1] - n[1] * 16], hi], fl ? 30 : 22, { on: fl, ta: .06, tb: .2 });
  /* গ্যাস্ট্রোকনেমিয়াস */ const g0 = [L.K[0] - n[0] * 10 - Math.sin(L.ta) * 8, L.K[1] - n[1] * 10 - Math.cos(L.ta) * 8], gm = [tib0[0] - ns[0] * 20 + Math.sin(L.sa) * 50, tib0[1] - ns[1] * 20 + Math.cos(L.sa) * 50], gh = [L.A[0] - ns[0] * 16, L.A[1] - ns[1] * 16 + 6];
  belly(g, [g0, gm, gh], 22, { on: act === 'g', ta: .04, tb: .4 });
  return { L, pk, qm, hm, gm };
};
B.kmDraw = kmDraw;
V.kneeMove = Object.assign({}, B.seg({
  id: 'knm', t: 'হাঁটু সঞ্চালনে অস্থি ও পেশির সমন্বয়', H: 330, def: 'ext', types: KM,
  sl: [{ k: 'k', l: 'হাঁটুর ভাঁজ (°)', min: 0, max: 120, step: 1, val: 5 }],
  cap: 'হাঁটুর নড়াচড়া তিন উপাদানের সমন্বয়: অস্থি (ফিমার-টিবিয়া লিভার, প্যাটেলা কপিকল), পেশি (কোয়াড্রিসেপস-হ্যামস্ট্রিং বিপরীতধর্মী জোড়) এবং লিগামেন্ট-মেনিসকাস (স্থিতি)। মস্তিষ্ক ও সুষুম্নাকাণ্ড একটি পেশিকে সংকোচনের সংকেত দিলে বিপরীত পেশিকে শিথিল হওয়ার সংকেত দেয় (পারস্পরিক নিষেধ)। "হাঁটা" বেছে চালাও চাপলে পুরো চক্র দেখাবে।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; const v = ty === 'ext' ? 5 : ty === 'flex' ? 95 : 20; ctx.v.k = v; const el = ctx.root.querySelector('[data-sl="k"]'); if (el) { el.value = v; const o2 = ctx.root.querySelector('[data-slo="k"]'); if (o2) o2.textContent = FK.n(v, 0); } }
    E('path', { d: 'M20 318H340', stroke: FK.alpha(C.fg, .25), 'stroke-width': 1 }, g);
    if (ty !== 'walk') { const R = kmDraw(g, C, ty, ctx.v.k, -8, null); B.lead(g, C, R.qm[0] + 10, R.qm[1], 262, 60, 'কোয়াড্রিসেপস', { fs: 9.4, c: ty === 'ext' ? '#a8201a' : C.fg }); B.tx(g, 266, 76, ty === 'ext' ? '(সংকুচিত)' : '(শিথিল)', { fs: 9, c: ty === 'ext' ? '#a8201a' : C.mu }); B.lead(g, C, R.hm[0] - 10, R.hm[1], 20, 100, ty === 'flex' ? 'হ্যামস্ট্রিং (সংকুচিত)' : 'হ্যামস্ট্রিং (শিথিল)', { fs: 9.4, a: 'start', c: ty === 'flex' ? '#a8201a' : C.fg }); B.lead(g, C, R.pk[0] + 6, R.pk[1], 262, 150, 'প্যাটেলা', { fs: 9.4 }); B.lead(g, C, R.gm[0] - 8, R.gm[1], 20, 230, 'গ্যাস্ট্রোকনেমিয়াস', { fs: 9.4, a: 'start' }); B.tx(g, 350, 310, `ভাঁজ ${Math.round(ctx.v.k)}°`, { fs: 10, a: 'end', w: 700 }); } },
  anim(g, C, ty, t) { if (ty !== 'walk') return; const ph = (t * .5) % 1, th = 22 * Math.sin(ph * 2 * PI) - 4, kn = ph < .55 ? 6 + 10 * Math.sin(ph / .55 * PI) : 6 + 58 * Math.sin((ph - .55) / .45 * PI), act = ph < .4 ? 'q' : ph < .55 ? 'g' : ph < .8 ? 'h' : 'q';
    kmDraw(g, C, ty, kn, th, act); const lab = { q: 'কোয়াড্রিসেপস সক্রিয় (ভার গ্রহণ)', g: 'কাফ পেশি সক্রিয় (ধাক্কা)', h: 'হ্যামস্ট্রিং সক্রিয় (পা তোলা)' }[act]; B.tx(g, 180, 300, lab, { fs: 10, a: 'middle', w: 700, c: '#a8201a' }); B.tx(g, 350, 22, `ভাঁজ ${Math.round(kn)}°`, { fs: 10, a: 'end', w: 700 }); }
}));

})();
