/* ═══════════════════════════════════════════════════════════════════
   visuals5 — পেশির গঠন ও কাজ: muscleTypes, muscleHierarchy, sarcomere, crossBridge, excitation, twitchTetanus
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B27, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const MU = () => B.TS('mus');
const strip = (g, d, o = {}) => { /* ডোরাকাটা পেশিতন্তু: ভরাট + আড়াআড়ি A/I ব্যান্ড */ const m = MU(); E('path', { d, fill: o.fill || '#e9a5b2', stroke: o.st || '#a8586a', 'stroke-width': o.sw || .8 }, g); if (o.str !== false) E('path', { d, fill: B.pat(g, 'line', FK.alpha('#8a2a44', o.so || .55), { s: o.s || 3.4, a: o.a != null ? o.a : 90, w: o.w || 1.3 }), stroke: 'none' }, g); };

/* ═════════ তিন ধরনের পেশি (অণুবীক্ষণে) ═════════ */
const MT = {
  skel: ['কঙ্কাল পেশি', 'কঙ্কাল পেশি (ঐচ্ছিক, ডোরাকাটা)', 'লম্বা নলাকার বহুনিউক্লিয়াসযুক্ত কোষ (তন্তু, কয়েক সেমি পর্যন্ত লম্বা); নিউক্লিয়াস কোষের কিনারায় সারকোলেমার নিচে; স্পষ্ট আড়াআড়ি গাঢ়-হালকা ডোরা। ইচ্ছামতো দ্রুত ও জোরে সংকোচন, তবে দ্রুত ক্লান্ত হয়। টেনডন দিয়ে অস্থিতে যুক্ত — চলন ও অঙ্গচালনা।'],
  smooth: ['মসৃণ পেশি', 'মসৃণ পেশি (অনৈচ্ছিক, ডোরাহীন)', 'মাকু আকৃতির একনিউক্লিয়াসযুক্ত ছোট কোষ, নিউক্লিয়াস মাঝখানে; ডোরা নেই (অ্যাকটিন-মায়োসিন এলোমেলো সাজানো)। ধীর, দীর্ঘস্থায়ী সংকোচন, ক্লান্ত হয় না; স্বয়ংক্রিয় স্নায়ুতন্ত্র নিয়ন্ত্রণ করে। পাকস্থলী-অন্ত্র, রক্তনালি, মূত্রথলি, জরায়ু, চোখের তারারন্ধ্র।'],
  card: ['হৃৎপেশি', 'হৃৎপেশি (অনৈচ্ছিক, ডোরাকাটা)', 'শাখাযুক্ত, সাধারণত একনিউক্লিয়াসযুক্ত কোষ, নিউক্লিয়াস মাঝে; ডোরা আছে; কোষগুলো ইন্টারক্যালেটেড ডিস্কে (গ্যাপ জাংশন ও ডেসমোসোম) জোড়া — সংকেত দ্রুত ছড়িয়ে সব কোষ একসাথে সংকুচিত হয়। শুধু হৃৎপিণ্ডে; ছন্দময়, কখনো ক্লান্ত হয় না।']
};
V.muscleTypes = Object.assign({}, B.seg({
  id: 'mtyp', t: 'তিন ধরনের পেশিকলা', H: 290, def: 'skel', types: MT,
  cap: 'স্লাইডে (H&E, লম্বচ্ছেদ) তিন ধরনের পেশি চেনার কৌশল: ডোরা + কিনারায় অনেক নিউক্লিয়াস = কঙ্কাল পেশি; ডোরা নেই + মাকু আকৃতি = মসৃণ পেশি; ডোরা + শাখা + গাঢ় আড়াআড়ি ইন্টারক্যালেটেড ডিস্ক = হৃৎপেশি। পেশিকলার বৈশিষ্ট্য: উত্তেজিতা, সংকোচনশীলতা, প্রসারণশীলতা ও স্থিতিস্থাপকতা।',
  art(g, C, ty) { const cx = 132, cy = 145, R = 126, cl = B.clip(g, 'mtF' + ty, `M${cx - R} ${cy}a${R} ${R} 0 1 0 ${2 * R} 0a${R} ${R} 0 1 0 ${-2 * R} 0Z`), fg = E('g', { 'clip-path': cl }, g);
    E('rect', { x: 0, y: 0, width: 270, height: 290, fill: '#f8e4ea' }, fg);
    if (ty === 'skel') { for (let i = 0; i < 6; i++) { const y = 26 + i * 44, h = 36 + (i % 2) * 4, d = `M0 ${y}Q132 ${y - 4} 270 ${y + 2}V${y + h}Q132 ${y + h + 4} 0 ${y + h}Z`; strip(fg, d, { s: 3.2, w: 1.25 }); for (let k = 0; k < 6; k++) { const x = 18 + k * 46 + (i % 2) * 20, edge = k % 2 ? y + 4 : y + h - 4; B.nuc(fg, x, edge, 7, 2.4, 0); } } }
    if (ty === 'smooth') { for (let i = 0; i < 34; i++) { const r = Math.floor(i / 5), c = i % 5, x = 6 + c * 56 + (r % 2) * 28, y = 18 + r * 38, L = 46, h = 9, d = `M${x - L} ${y}Q${x} ${y - h} ${x + L} ${y}Q${x} ${y + h} ${x - L} ${y}Z`; E('path', { d, fill: '#eaa0b4', stroke: '#b0607a', 'stroke-width': .7 }, fg); B.nuc(fg, x, y, 8, 2.2, 0); } }
    if (ty === 'card') { const rows = [24, 84, 144, 204, 264]; rows.forEach((y, i) => { const d = `M-10 ${y - 17}Q60 ${y - 20} 130 ${y - 16}T280 ${y - 18}V${y + 17}Q200 ${y + 20} 130 ${y + 16}T-10 ${y + 18}Z`; strip(fg, d, { s: 3.4, w: 1.1, fill: '#e39aa8' }); });
      [[70, 54], [190, 114], [110, 174], [230, 234], [40, 234]].forEach(([x, y]) => strip(fg, `M${x - 14} ${y - 14}L${x + 20} ${y - 14}L${x + 12} ${y + 14}L${x - 20} ${y + 14}Z`, { s: 3.4, w: 1.1, fill: '#e39aa8', st: 'none' }));
      rows.forEach((y, i) => { [40, 104, 168, 232].forEach((x, k) => { const xx = x + (i % 2) * 26; let d = `M${xx} ${y - 17}`; for (let q = 1; q <= 6; q++) d += `L${xx + (q % 2 ? 3 : -3)} ${y - 17 + q * 34 / 6}`; E('path', { d, stroke: '#5a1a2a', 'stroke-width': 2, fill: 'none' }, fg); B.nuc(fg, xx + 28, y, 6, 3.4, 0); }); }); }
    E('circle', { cx, cy, r: R, fill: 'none', stroke: '#3a3030', 'stroke-width': 1.6 }, g);
    const F = { skel: [['ডোরা (A ও I ব্যান্ড)', 46, 60], ['কিনারার নিউক্লিয়াস', 64, 112], ['সারকোলেমা', 30, 160]], smooth: [['মাকু আকৃতির কোষ', 62, 56], ['মাঝখানের একটি নিউক্লিয়াস', 62, 114]], card: [['ইন্টারক্যালেটেড ডিস্ক', 40, 84], ['শাখা', 70, 54], ['কেন্দ্রীয় নিউক্লিয়াস', 132, 144]] }[ty];
    F.forEach(([s2, ax, ay], i) => B.lead(g, C, ax, ay, 268, 40 + i * 46, s2, { fs: 9.4, a: 'start' }));
    const K = { skel: ['ঐচ্ছিক', 'বহু নিউক্লিয়াস', 'দ্রুত, ক্লান্ত হয়'], smooth: ['অনৈচ্ছিক', '1 নিউক্লিয়াস', 'ধীর, অক্লান্ত'], card: ['অনৈচ্ছিক', '1 (কখনো 2)', 'ছন্দময়, অক্লান্ত'] }[ty];
    K.forEach((s2, i) => B.tx(g, 270, 196 + i * 20, s2, { fs: 9.6, w: 650, c: '#8a2a44' })); },
  anim(g, C, ty, t) { /* সংকোচনের ছন্দ: কঙ্কাল একবার জোরে, মসৃণ ধীরে, হৃৎপেশি নিয়মিত */ const ph = ty === 'skel' ? Math.max(0, Math.sin(t * 2)) : ty === 'smooth' ? (Math.sin(t * .6) + 1) / 2 : Math.max(0, Math.sin(t * 7.5)) ** 3;
    E('rect', { x: 270, y: 262, width: 80, height: 8, rx: 4, fill: FK.alpha(C.fg, .1) }, g); E('rect', { x: 270, y: 262, width: f1(10 + ph * 70), height: 8, rx: 4, fill: '#c04a5a' }, g); B.tx(g, 270, 256, 'সংকোচন', { fs: 8.4, c: C.mu }); }
}));

/* ═════════ কঙ্কাল পেশির গঠনের স্তর ═════════ */
const MH = [
  { t: 'সম্পূর্ণ পেশি', en: 'Whole muscle', d: 'যেমন বাহুর বাইসেপস — দুই প্রান্তে টেনডন দিয়ে অস্থিতে যুক্ত; বাইরে যোজক কলার আবরণ এপিমাইসিয়াম।' },
  { t: 'পেশিগুচ্ছ (ফ্যাসিকল)', en: 'Fascicle', d: 'পেশির প্রস্থচ্ছেদে অনেক গুচ্ছ, প্রতিটি পেরিমাইসিয়ামে মোড়া; এর ভেতর দিয়ে রক্তনালি ও স্নায়ু চলে।' },
  { t: 'পেশিতন্তু (পেশিকোষ)', en: 'Muscle fibre', d: 'একটি গুচ্ছে শত শত তন্তু, প্রতিটি এন্ডোমাইসিয়ামে মোড়া। তন্তু একটি বহুনিউক্লিয়াসযুক্ত দীর্ঘ কোষ — কোষঝিল্লি সারকোলেমা, সাইটোপ্লাজম সারকোপ্লাজম, ER হলো সারকোপ্লাজমিক রেটিকুলাম (Ca<sup>2+</sup> জমা রাখে)।' },
  { t: 'মায়োফাইব্রিল', en: 'Myofibril', d: 'প্রতিটি তন্তুতে হাজারো সমান্তরাল মায়োফাইব্রিল (প্রায় 1–2 µm চওড়া) — সারি সারি সারকোমিয়ার নিয়ে গঠিত; পাশাপাশি সারকোমিয়ারের ব্যান্ড মিলে যাওয়ায় পুরো তন্তু ডোরাকাটা দেখায়।' },
  { t: 'সারকোমিয়ার', en: 'Sarcomere', d: 'দুটি Z রেখার মাঝের অংশ (বিশ্রামে প্রায় 2–2.5 µm) — পেশির সংকোচনের কার্যকর একক। মাঝে মোটা মায়োসিন সূত্র (A ব্যান্ড), দুই পাশে Z থেকে আসা সরু অ্যাকটিন সূত্র (I ব্যান্ড)।' },
  { t: 'আণবিক সূত্র', en: 'Myofilaments', d: 'সরু সূত্র: দুটি অ্যাকটিন শৃঙ্খলের পেঁচানো দড়ি, সাথে ট্রপোমায়োসিন ও ট্রপোনিন। মোটা সূত্র: প্রায় 300টি মায়োসিন অণু — প্রতিটির গলফ ক্লাবের মতো মাথা বেরিয়ে থাকে (ক্রস-ব্রিজ)।' }
];
const actinRow = (g, x0, x1, y, r = 2.3) => { let a = '', b2 = ''; for (let x = x0, i = 0; x <= x1; x += r * 1.8, i++) { const off = Math.sin(i * .55) * r * .45; (i % 2 ? a : b2); if (i % 2) a += `M${f1(x + r)} ${f1(y - off)}a${r} ${r} 0 1 0 ${-2 * r} 0a${r} ${r} 0 1 0 ${2 * r} 0`; else b2 += `M${f1(x + r)} ${f1(y + off)}a${r} ${r} 0 1 0 ${-2 * r} 0a${r} ${r} 0 1 0 ${2 * r} 0`; } E('path', { d: b2, fill: '#f0b04a', stroke: '#a8701a', 'stroke-width': .4 }, g); E('path', { d: a, fill: '#f6c46a', stroke: '#a8701a', 'stroke-width': .4 }, g); };
const myosin = (g, x0, x1, y, o = {}) => { const h = o.h || 4.5; E('rect', { x: x0, y: y - h / 2, width: x1 - x0, height: h, rx: h / 2, fill: '#8a6ac8', stroke: '#4a3a88', 'stroke-width': .6 }, g); const mid = (x0 + x1) / 2, bare = o.bare || 10; let d = ''; for (let x = x0 + 4; x < x1 - 2; x += o.step || 7) { if (Math.abs(x - mid) < bare) continue; const sd = x < mid ? -1 : 1, up = ((x - x0) / (o.step || 7)) % 2 ? -1 : 1, ang = o.ang != null ? o.ang : 0; d += `M${f1(x)} ${f1(y + up * h / 2)}l${f1(sd * (4 + ang))} ${f1(up * (5 - Math.abs(ang) * .3))}`; } E('path', { d, stroke: '#5a3aa8', 'stroke-width': 2.2, 'stroke-linecap': 'round', fill: 'none' }, g); };
/* সারকোমিয়ার: cx, cy, L (Z–Z দৈর্ঘ্য), A ব্যান্ড দৈর্ঘ্য, অ্যাকটিনের দৈর্ঘ্য, উচ্চতা */
B.sarc = (g, C, cx, cy, Lz, o = {}) => { const A = o.A || 160, Ac = o.act || 100, H = o.H || 120, n = o.n || 6, z0 = cx - Lz / 2, z1 = cx + Lz / 2;
  E('rect', { x: z0, y: cy - H / 2, width: Lz, height: H, fill: FK.alpha('#f8e4ea', .9), stroke: 'none' }, g);
  E('rect', { x: cx - A / 2, y: cy - H / 2, width: A, height: H, fill: FK.alpha('#d6a0c0', .35) }, g);
  for (let i = 0; i < n; i++) { const y = cy - H / 2 + (i + .5) * H / n; if (i < n) { actinRow(g, z0, z0 + Ac, y - H / n / 4, o.r || 2.2); actinRow(g, z1 - Ac, z1, y - H / n / 4, o.r || 2.2); actinRow(g, z0, z0 + Ac, y + H / n / 4, o.r || 2.2); actinRow(g, z1 - Ac, z1, y + H / n / 4, o.r || 2.2); }
    myosin(g, cx - A / 2, cx + A / 2, y, { h: 4.6, ang: o.ang || 0, step: o.step || 7 }); }
  [z0, z1].forEach(x => { let d = `M${x} ${cy - H / 2 - 6}`; for (let k = 1; k <= 16; k++) d += `L${f1(x + (k % 2 ? 3 : -3))} ${f1(cy - H / 2 - 6 + k * (H + 12) / 16)}`; E('path', { d, stroke: '#3a2a4a', 'stroke-width': 2.4, fill: 'none' }, g); });
  E('path', { d: `M${cx} ${cy - H / 2 - 2}V${cy + H / 2 + 2}`, stroke: '#3a2a6a', 'stroke-width': 1.6 }, g);
  return { z0, z1, a0: cx - A / 2, a1: cx + A / 2, h0: z0 + Ac, h1: z1 - Ac };
};
V.muscleHierarchy = Object.assign({ t: 'কঙ্কাল পেশির গঠন: পেশি থেকে অণু', k: ['2d', 'anim', 'steps'], cap: 'রশির মতো স্তরে স্তরে গঠন: পেশি → গুচ্ছ (ফ্যাসিকল) → তন্তু (কোষ) → মায়োফাইব্রিল → সারকোমিয়ার → অ্যাকটিন ও মায়োসিন সূত্র। প্রতিটি স্তর যোজক কলায় মোড়া (এপি-, পেরি-, এন্ডোমাইসিয়াম), যা প্রান্তে মিলে টেনডন তৈরি করে — তাই প্রতিটি তন্তুর টান অস্থিতে পৌঁছায়।' },
  BK.steps({ W: 360, H: 290, label: 'পেশির গঠনের স্তর', dur: 3.2, stages: MH,
    draw(g, C, s, u) { const m = MU();
      B.cacheG(g, 'mh' + s, gg => {
        if (s === 0) { /* হিউমেরাস ও বাইসেপস */ B.tube(gg, 'M40 60L320 70', 22, 'bone', { sw: .9 }); B.organ(gg, sm([[70, 92], [120, 108], [180, 132], [240, 120], [290, 98], [300, 104], [244, 146], [180, 166], [118, 148], [64, 104]], true, .45), 'mus', { sw: 1, pat: 'line', po: { s: 3, a: 8, w: .45 } });
          B.organ(gg, 'M52 82 L70 92 L64 104 L44 96 Z', 'tnd', { sw: .8 }); B.organ(gg, 'M296 96 L330 120 L326 128 L292 108 Z', 'tnd', { sw: .8 }); B.tube(gg, 'M300 130L340 150', 14, 'bone', { sw: .8 });
          B.lead(gg, C, 180, 150, 180, 230, 'পেশি (এপিমাইসিয়ামে মোড়া)', { fs: 9.6, a: 'middle' }); B.lead(gg, C, 56, 92, 40, 140, 'টেনডন', { fs: 9.6, a: 'middle' }); B.tx(gg, 180, 50, 'হিউমেরাস', { fs: 9.4, a: 'middle', c: C.mu }); }
        if (s === 1) { E('circle', { cx: 150, cy: 145, r: 112, fill: '#f4d2c8', stroke: '#c09080', 'stroke-width': 3 }, gg); const P = []; for (let i = 0; i < 24; i++) { const a = i * 2.4, r = 14 + Math.sqrt(i) * 19; P.push([150 + r * Math.cos(a), 145 + r * Math.sin(a)]); }
          P.forEach(([x, y], i) => { if (Math.hypot(x - 150, y - 145) > 92) return; const pts = Array.from({ length: 9 }, (_, k) => { const a = k / 9 * 2 * PI, r = 16.5 * (1 + (B.rnd(i * 9 + k) - .5) * .22); return [x + r * Math.cos(a), y + r * Math.sin(a)]; }), d = sm(pts, true, .5);
            E('path', { d, fill: B.vol(gg, 'mus', { cx: .45, cy: .4, r: .8 }), stroke: '#f6e4dc', 'stroke-width': 2.6 }, gg); E('path', { d, fill: B.pat(gg, 'dot', FK.alpha('#f8d0c8', .55), { s: 3.4, w: .9 }), stroke: 'none' }, gg); });
          B.tube(gg, 'M150 145L170 160', 4, 'art', { sw: .4, hl: false }); B.lead(gg, C, 150 + 17, 145, 290, 60, 'পেশিগুচ্ছ', { fs: 9.6 }); B.lead(gg, C, 150, 145 + 30, 290, 120, 'পেরিমাইসিয়াম', { fs: 9.6 }); B.lead(gg, C, 150 + 108, 160, 290, 230, 'এপিমাইসিয়াম', { fs: 9.6 }); B.tx(gg, 150, 282, 'প্রস্থচ্ছেদ', { fs: 9, a: 'middle', c: C.mu }); }
        if (s === 2) { strip(gg, 'M20 80 Q180 70 340 80 V200 Q180 210 20 200 Z', { s: 4, w: 1.6 }); [[60, 86], [150, 196], [240, 84], [320, 194]].forEach(([x, y]) => B.nuc(gg, x, y, 11, 3.4, 0)); for (let i = 0; i < 6; i++) E('path', { d: `M20 ${100 + i * 18}H340`, stroke: '#fff', 'stroke-width': .8, opacity: .5 }, gg);
          E('path', { d: 'M20 76 Q180 64 340 76', stroke: '#7a3048', 'stroke-width': 2, fill: 'none' }, gg); B.lead(gg, C, 150, 196, 150, 250, 'নিউক্লিয়াস (কিনারায়, অনেক)', { fs: 9.6, a: 'middle' }); B.lead(gg, C, 260, 72, 280, 34, 'সারকোলেমা', { fs: 9.6, a: 'middle' }); B.lead(gg, C, 90, 136, 60, 34, 'মায়োফাইব্রিল', { fs: 9.6, a: 'middle' }); }
        if (s === 3) { for (let i = 0; i < 4; i++) { const y = 70 + i * 44; strip(gg, `M10 ${y}H350V${y + 34}H10Z`, { s: 50, w: 22, so: .28, fill: '#f0c6d0' }); for (let x = 10; x <= 350; x += 50) E('path', { d: `M${x} ${y}V${y + 34}`, stroke: '#3a2a4a', 'stroke-width': 1.6 }, gg); for (let x = 35; x <= 350; x += 50) E('path', { d: `M${x} ${y + 2}V${y + 32}`, stroke: '#6a4a8a', 'stroke-width': .7, opacity: .6 }, gg); }
          E('path', { d: 'M60 64V58H110V64', stroke: '#c04a5a', 'stroke-width': 1.4, fill: 'none' }, gg); B.tx(gg, 85, 52, 'একটি সারকোমিয়ার', { fs: 9.6, a: 'middle', w: 650, c: '#a8201a' }); B.tx(gg, 180, 268, 'গাঢ় = A ব্যান্ড, হালকা = I ব্যান্ড, মাঝে Z রেখা', { fs: 9.4, a: 'middle', c: C.mu }); }
        if (s === 4) { const R = B.sarc(gg, C, 180, 140, 300, { A: 150, act: 110, H: 140, n: 5 }); B.tx(gg, R.z0, 54, 'Z', { fs: 11, a: 'middle', w: 700 }); B.tx(gg, R.z1, 54, 'Z', { fs: 11, a: 'middle', w: 700 }); B.tx(gg, 180, 54, 'M', { fs: 11, a: 'middle', w: 700 });
          const br = (x0, x1, y, s2) => { E('path', { d: `M${x0} ${y - 4}v4H${x1}v-4`, stroke: C.fg, 'stroke-width': .9, fill: 'none' }, gg); B.tx(gg, (x0 + x1) / 2, y + 12, s2, { fs: 9.4, a: 'middle', w: 650 }); }; br(R.a0, R.a1, 226, 'A ব্যান্ড'); br(R.z0, R.a0, 226, 'I'); br(R.a1, R.z1, 226, 'I'); br(R.h0, R.h1, 254, 'H অঞ্চল'); }
        if (s === 5) { actinRow(gg, 20, 340, 92, 6); E('path', { d: sm([[20, 88], [80, 98], [140, 84], [200, 98], [260, 84], [340, 96]], false, .5), stroke: '#3a8a5a', 'stroke-width': 2.4, fill: 'none' }, gg); [70, 170, 270].forEach(x => E('path', { d: B.ellD(x, 82, 7, 5, 0), fill: '#c04a5a', stroke: '#7a2a3a', 'stroke-width': .6 }, gg));
          myosin(gg, 40, 320, 190, { h: 12, step: 18, bare: 26 }); B.tx(gg, 20, 70, 'সরু সূত্র: অ্যাকটিন (কমলা) + ট্রপোমায়োসিন (সবুজ) + ট্রপোনিন (লাল)', { fs: 9.2, w: 600 }); B.tx(gg, 20, 160, 'মোটা সূত্র: মায়োসিন — মাথা (ক্রস-ব্রিজ) বেরিয়ে আছে', { fs: 9.2, w: 600 }); B.tx(gg, 180, 240, 'মাঝে মাথাহীন "খালি অঞ্চল" (M রেখা)', { fs: 9, a: 'middle', c: C.mu }); } });
      /* জুম ফ্রেম: পরের স্তরের দিকে */ if (s < 5) { const z = 1 - u * .25; E('rect', { x: f1(180 - 40 * z), y: f1(145 - 30 * z), width: f1(80 * z), height: f1(60 * z), fill: 'none', stroke: FK.alpha('#2a6ab0', .25 + .5 * u), 'stroke-width': 1.4, 'stroke-dasharray': '4 3' }, g); } }
  }));

/* ═════════ সারকোমিয়ার: শিথিল ও সংকুচিত ═════════ */
const SR = {
  rest: ['শিথিল', 'শিথিল সারকোমিয়ার (প্রায় 2.3 µm)', 'অ্যাকটিন ও মায়োসিন আংশিক পরস্পরের ওপর পড়ে আছে; মাঝে H অঞ্চল চওড়া, দুই পাশে I ব্যান্ড চওড়া।'],
  con: ['সংকুচিত', 'সংকুচিত সারকোমিয়ার (প্রায় 1.8 µm)', 'মায়োসিনের মাথা অ্যাকটিনকে M রেখার দিকে টেনে আনে — Z রেখা কাছে আসে; I ব্যান্ড ও H অঞ্চল সরু বা লোপ পায়, কিন্তু A ব্যান্ডের দৈর্ঘ্য একই থাকে (সূত্র নিজে ছোট হয় না — পিছলে যায়)।'],
  str: ['প্রসারিত', 'প্রসারিত সারকোমিয়ার (প্রায় 3 µm)', 'অতিরিক্ত টানে অ্যাকটিন-মায়োসিনের উপরিপাত কমে যায় — ক্রস-ব্রিজ কম তৈরি হয়, তাই খুব প্রসারিত পেশি জোরে সংকুচিত হতে পারে না।']
};
const SRV = { rest: 30, con: 85, str: 0 };
V.sarcomere = Object.assign({}, B.seg({
  id: 'sarc', t: 'সারকোমিয়ার ও পিছলে যাওয়া সূত্র তত্ত্ব', H: 300, def: 'rest', types: SR,
  sl: [{ k: 'c', l: 'সংকোচন (%)', min: 0, max: 100, step: 1, val: 30 }],
  cap: 'হাক্সলি ও হ্যানসন (1954) এবং হাক্সলি ও নিডারগার্কি (1954) এর পিছলে যাওয়া সূত্র তত্ত্ব: সংকোচনে অ্যাকটিন ও মায়োসিন সূত্রের দৈর্ঘ্য বদলায় না; অ্যাকটিন মায়োসিনের ওপর দিয়ে কেন্দ্রের দিকে পিছলে যায়। ফলে সারকোমিয়ার ছোট হয় → A ব্যান্ড অপরিবর্তিত, I ব্যান্ড ও H অঞ্চল ছোট। স্লাইডার টেনে দেখো।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; const v = SRV[ty]; ctx.v.c = v; const el = ctx.root.querySelector('[data-sl="c"]'); if (el) { el.value = v; const o2 = ctx.root.querySelector('[data-slo="c"]'); if (o2) o2.textContent = FK.n(v, 0); } }
    const c = ctx.v.c / 100, A = 150, Ac = 104, Lz = 324 - c * 140, R = B.sarc(g, C, 180, 130, Lz, { A, act: Ac, H: 130, n: 5, ang: c * 2 });
    const br = (x0, x1, y, s2, col) => { if (x1 - x0 < 2) { B.tx(g, (x0 + x1) / 2, y + 12, s2 + ' = 0', { fs: 9.4, a: 'middle', w: 650, c: col || C.fg }); return; } E('path', { d: `M${f1(x0)} ${y - 4}v4H${f1(x1)}v-4`, stroke: col || C.fg, 'stroke-width': 1, fill: 'none' }, g); B.tx(g, (x0 + x1) / 2, y + 12, s2, { fs: 9.4, a: 'middle', w: 650, c: col || C.fg }); };
    br(R.a0, R.a1, 218, 'A ব্যান্ড', '#5a3aa8'); br(R.z0, R.a0, 218, 'I', '#a8701a'); br(R.a1, R.z1, 218, 'I', '#a8701a'); br(Math.max(R.a0, R.h0), Math.min(R.a1, R.h1), 248, 'H অঞ্চল', '#2a6a8a'); br(R.z0, R.z1, 276, 'সারকোমিয়ার (Z থেকে Z)', '#3a2a4a');
    const um = 2.3 * Lz / (324 - .3 * 140) ; B.tx(g, 352, 22, 'দৈর্ঘ্য ≈ ' + um.toFixed(1) + ' µm', { fs: 10, a: 'end', w: 700, c: '#3a2a4a' });
    [['Z', R.z0], ['M', 180], ['Z', R.z1]].forEach(([s2, x]) => B.tx(g, x, 56, s2, { fs: 11, a: 'middle', w: 700 })); },
  anim(g, C, ty, t, ctx) { const c = ctx.v.c / 100; if (c < .05) return; /* মায়োসিনের মাথার নড়াচড়া (পাওয়ার স্ট্রোক) */ const Lz = 324 - c * 140, ph = (t * 4) % 1, cx = 180; for (let i = 0; i < 5; i++) { const y = 130 - 65 + (i + .5) * 26; [-1, 1].forEach(sd => { const x = cx + sd * (38 + ph * 6); E('path', { d: `M${f1(x)} ${f1(y - 2.3)}l${f1(sd * 4)} -5`, stroke: '#ffdd55', 'stroke-width': 2, 'stroke-linecap': 'round', opacity: .85 }, g); }); } }
}));

/* ═════════ ক্রস-ব্রিজ চক্র ═════════ */
const CB = [
  { t: 'বিশ্রাম: বাঁধার স্থান ঢাকা', en: 'Rest', d: 'Ca<sup>2+</sup> কম থাকলে ট্রপোমায়োসিন অ্যাকটিনের মায়োসিন-বাঁধার স্থান ঢেকে রাখে; মায়োসিনের মাথায় ADP + Pi — মাথা "টানটান" (উচ্চশক্তি অবস্থা)।' },
  { t: 'Ca<sup>2+</sup> ট্রপোনিনে যুক্ত', en: 'Calcium binds troponin', d: 'স্নায়ু-সংকেতে সারকোপ্লাজমিক রেটিকুলাম থেকে Ca<sup>2+</sup> বের হয়ে ট্রপোনিন-C তে বসে; ট্রপোনিনের আকার বদলে ট্রপোমায়োসিন সরে যায় — বাঁধার স্থান খোলে।' },
  { t: 'ক্রস-ব্রিজ তৈরি', en: 'Cross-bridge forms', d: 'টানটান মায়োসিনের মাথা অ্যাকটিনের খোলা স্থানে যুক্ত হয়।' },
  { t: 'পাওয়ার স্ট্রোক', en: 'Power stroke', d: 'Pi ও পরে ADP ছেড়ে দিয়ে মাথা প্রায় 45° ঘোরে — অ্যাকটিনকে M রেখার দিকে প্রায় 10 ন্যানোমিটার টেনে আনে।' },
  { t: 'ATP যুক্ত হয়ে বিচ্ছেদ', en: 'Detachment', d: 'নতুন ATP মায়োসিনের মাথায় বসলে মাথা অ্যাকটিন ছেড়ে দেয়। মৃত্যুর পর ATP না থাকায় মাথা আটকে থাকে — পেশি শক্ত হয়ে যায় (রাইগর মর্টিস)।' },
  { t: 'ATP ভেঙে মাথা আবার টানটান', en: 'Re-cocking', d: 'মায়োসিন-ATPase ATP কে ADP + Pi তে ভেঙে শক্তি দিয়ে মাথাকে আবার টানটান করে — Ca<sup>2+</sup> থাকলে চক্র চলতে থাকে।' }
];
V.crossBridge = Object.assign({ t: 'ক্রস-ব্রিজ চক্র: অ্যাকটিন-মায়োসিনের টান', k: ['2d', 'anim', 'steps'], cap: 'প্রতিটি চক্রে একটি মায়োসিন মাথা একটি ATP খরচ করে অ্যাকটিনকে একটু টানে; লক্ষ লক্ষ মাথা পালাক্রমে টানে বলে সূত্র মসৃণভাবে পিছলে যায় — যেমন অনেক লোক পালা করে দড়ি টানে। শিথিলতার জন্যও ATP লাগে (Ca<sup>2+</sup> কে রেটিকুলামে ফেরত পাম্প করতে)।' },
  BK.steps({ W: 360, H: 260, label: 'ক্রস-ব্রিজ চক্র', dur: 3, stages: CB,
    draw(g, C, s, u) { const shift = s >= 3 ? (s === 3 ? u * 26 : 26) : 0, yA = 92, yM = 196, hx = 184;
      B.cacheG(g, 'cbm', gg => { E('rect', { x: 20, y: yM - 9, width: 320, height: 18, rx: 9, fill: '#8a6ac8', stroke: '#4a3a88', 'stroke-width': .8 }, gg); B.tx(gg, 30, yM + 34, 'মোটা সূত্র (মায়োসিন)', { fs: 9.4, w: 650, c: '#4a3a88' }); B.tx(gg, 300, yM + 34, 'M রেখার দিক →', { fs: 9, a: 'end', c: C.mu }); });
      const trop = s >= 1, AL = B.cacheG(g, 'cba' + (trop ? 1 : 0), ag => { actinRow(ag, -20, 380, yA, 7);
      E('path', { d: sm([[-20, yA - 8 + (trop ? -6 : 0)], [60, yA + 2 + (trop ? -6 : 0)], [140, yA - 8 + (trop ? -6 : 0)], [220, yA + 2 + (trop ? -6 : 0)], [300, yA - 8 + (trop ? -6 : 0)], [380, yA + 2 + (trop ? -6 : 0)]], false, .5), stroke: '#3a8a5a', 'stroke-width': 3, fill: 'none' }, ag);
      [40, 160, 280].forEach(x => { E('path', { d: B.ellD(x, yA - 14, 8, 6, 0), fill: '#c04a5a', stroke: '#7a2a3a', 'stroke-width': .6 }, ag); if (s >= 1 && s <= 5) { E('circle', { cx: x + 6, cy: yA - 22, r: 3.6, fill: '#2a9ad0', stroke: '#1a5a80', 'stroke-width': .5 }, ag); } });
      for (let k = 0; k < 6; k++) { const bx = 30 + k * 60; E('circle', { cx: bx, cy: yA + 7, r: 3, fill: s >= 1 ? '#ffffff' : FK.alpha('#ffffff', .2), stroke: s >= 1 ? '#3a8a5a' : 'none', 'stroke-width': 1 }, ag); } });
      const tr = `translate(${f1(shift)} 0)`; if (AL.getAttribute('transform') !== tr) AL.setAttribute('transform', tr);
      B.cacheG(g, 'cbl' + s, gl => { B.tx(gl, 20, 40, 'সরু সূত্র (অ্যাকটিন)', { fs: 9.4, w: 650, c: '#a8701a' }); B.tx(gl, 340, 40, s >= 1 ? 'ট্রপোমায়োসিন সরে গেছে' : 'ট্রপোমায়োসিন ঢেকে রেখেছে', { fs: 9, a: 'end', c: '#2a6a4a' }); if (s === 3) B.tx(gl, 220, yA - 40, 'অ্যাকটিন পিছলে যায়', { fs: 9, c: '#a8201a', w: 650 }); });
      /* মায়োসিনের মাথা */ const cocked = s === 0 || s === 1 || s === 2 || (s === 5 && u > .5), att = s === 2 || s === 3, ang = s === 3 ? -40 + u * 80 : s === 4 ? 40 : s === 5 ? 40 - u * 80 : -40, base = [hx, yM - 9];
      const L = 62, tipx = base[0] + Math.sin(ang * PI / 180) * L * .5 + (att && s === 2 ? -0 : 0), tipy = s === 4 ? yM - 50 + u * 8 : att ? yA + 12 : yM - 52;
      const hp = att ? [base[0] + (s === 3 ? u * 26 : 0) + Math.sin(ang * PI / 180) * 10, tipy] : [base[0] + Math.sin(ang * PI / 180) * 30, tipy];
      E('path', { d: `M${base[0]} ${base[1]}Q${f1((base[0] + hp[0]) / 2 - 10)} ${f1((base[1] + hp[1]) / 2)} ${f1(hp[0])} ${f1(hp[1] + 10)}`, stroke: '#5a3aa8', 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, g);
      E('path', { d: B.ellD(hp[0], hp[1], 14, 9, ang + 90), fill: '#9a7ad8', stroke: '#4a3a88', 'stroke-width': 1 }, g);
      const tag = s === 0 || s === 1 || s === 2 ? 'ADP + Pi' : s === 3 ? (u < .5 ? 'Pi বের' : 'ADP বের') : s === 4 ? 'ATP' : (u < .5 ? 'ATP → ADP + Pi' : 'ADP + Pi');
      E('rect', { x: f1(hp[0] + 18), y: f1(hp[1] - 8), width: tag.length * 5.4 + 8, height: 16, rx: 8, fill: s === 4 ? '#fbe7a6' : '#eef0f8', stroke: '#8a7aa8', 'stroke-width': .6 }, g); B.tx(g, hp[0] + 22, hp[1] + 4, tag, { fs: 9, w: 650 });
      if (s === 3) E('path', { d: `M${f1(220)} ${yA - 34}h${f1(30 + u * 10)}`, stroke: '#c0392b', 'stroke-width': 2, 'marker-end': B.mk(g, '#c0392b', 6) }, g); }
  }));

/* ═════════ স্নায়ু-পেশি সংযোগ ও উত্তেজনা-সংকোচন যুগ্মতা ═════════ */
const EX = [
  { t: 'স্নায়ু-উদ্দীপনা পৌঁছায়', en: 'Nerve impulse', d: 'মোটর নিউরনের অ্যাক্সন বেয়ে কার্যবিভব প্রান্তে (স্নায়ু-পেশি সংযোগ বা মোটর এন্ড প্লেট) পৌঁছায়; প্রান্তে Ca<sup>2+</sup> চ্যানেল খুলে Ca<sup>2+</sup> ঢোকে।' },
  { t: 'অ্যাসিটাইলকোলিন নিঃসরণ', en: 'ACh release', d: 'Ca<sup>2+</sup> এর প্রভাবে ভেসিকল এক্সোসাইটোসিসে অ্যাসিটাইলকোলিন (ACh) সিন্যাপটিক ফাঁকে ছাড়ে।' },
  { t: 'সারকোলেমায় কার্যবিভব', en: 'Muscle action potential', d: 'ACh সারকোলেমার গ্রাহকে বসে Na<sup>+</sup> চ্যানেল খোলে — এন্ড প্লেট বিভব থেকে পেশির কার্যবিভব তৈরি হয়ে পুরো তন্তুতে ছড়ায়।' },
  { t: 'T নালি বেয়ে ভেতরে', en: 'T-tubules', d: 'কার্যবিভব সারকোলেমার ভাঁজ — ট্রান্সভার্স (T) নালি — দিয়ে তন্তুর গভীরে প্রতিটি মায়োফাইব্রিলের কাছে পৌঁছায়।' },
  { t: 'রেটিকুলাম থেকে Ca<sup>2+</sup>', en: 'Calcium release', d: 'T নালির সংকেতে পাশের সারকোপ্লাজমিক রেটিকুলাম তার জমানো Ca<sup>2+</sup> সারকোপ্লাজমে ছাড়ে।' },
  { t: 'সংকোচন', en: 'Contraction', d: 'Ca<sup>2+</sup> ট্রপোনিনে বসে বাঁধার স্থান খোলে — ক্রস-ব্রিজ চক্রে অ্যাকটিন পিছলে যায়, সারকোমিয়ার ছোট হয়।' },
  { t: 'শিথিলতা', en: 'Relaxation', d: 'অ্যাসিটাইলকোলিনএস্টারেজ ACh ভেঙে ফেলে; ATP চালিত পাম্প Ca<sup>2+</sup> রেটিকুলামে ফেরায় — ট্রপোমায়োসিন আবার স্থান ঢাকে, পেশি শিথিল হয়।' }
];
V.excitation = Object.assign({ t: 'স্নায়ু-পেশি সংযোগ থেকে সংকোচন', k: ['2d', 'anim', 'steps'], cap: 'স্নায়ুর বৈদ্যুতিক সংকেত কীভাবে যান্ত্রিক টানে পরিণত হয় (উত্তেজনা-সংকোচন যুগ্মতা) — মূল বার্তাবাহক Ca<sup>2+</sup>। কুরারে বিষ ACh গ্রাহক আটকে পেশি অবশ করে; কিছু কীটনাশক (অর্গানোফসফেট) এস্টারেজ আটকে পেশিতে টানা খিঁচুনি ঘটায়।' },
  BK.steps({ W: 360, H: 290, label: 'উত্তেজনা-সংকোচন', dur: 3, stages: EX,
    draw(g, C, s, u) { B.cacheG(g, 'exb', gg => { /* স্নায়ুপ্রান্ত */ B.tube(gg, 'M10 30Q60 40 100 70', 9, 'nrv', { sw: .7 }); E('path', { d: sm([[96, 64], [140, 66], [176, 82], [190, 102], [160, 116], [110, 112], [86, 92]], true, .5), fill: B.vol(gg, 'nrv'), stroke: B.TS('nrv').dk, 'stroke-width': .9 }, gg);
        for (let i = 0; i < 10; i++) E('circle', { cx: 112 + (i % 5) * 14, cy: 84 + Math.floor(i / 5) * 14, r: 4.4, fill: '#fff6d0', stroke: '#a3831a', 'stroke-width': .6 }, gg);
        /* পেশিতন্তু */ strip(gg, 'M0 126H360V280H0Z', { s: 9, w: 3.6, so: .3, fill: '#f3c4ce' }); E('path', { d: 'M0 126H360', stroke: '#7a3048', 'stroke-width': 2 }, gg); B.tx(gg, 352, 120, 'সারকোলেমা', { fs: 9, a: 'end', c: '#7a3048' });
        [130, 250].forEach(x => { E('path', { d: `M${x} 126V270`, stroke: '#7a3048', 'stroke-width': 3.4 }, gg); E('path', { d: `M${x - 22} 150V262M${x + 22} 150V262`, stroke: '#6ab0d8', 'stroke-width': 7, opacity: .7 }, gg); }); B.tx(gg, 130, 284, 'T নালি', { fs: 9, a: 'middle', c: '#7a3048' }); B.tx(gg, 196, 284, 'সারকোপ্লাজমিক রেটিকুলাম', { fs: 9, a: 'middle', c: '#2a7aa8' });
        for (let i = 0; i < 8; i++) E('rect', { x: 120 + i * 10, y: 123, width: 6, height: 4, rx: 1, fill: '#c04a5a' }, gg); B.tx(gg, 40, 100, 'মোটর নিউরনের প্রান্ত', { fs: 9, c: '#8a6a00', w: 650 }); });
      if (s === 0) { const x = 10 + u * 100, y = 30 + u * 40; E('circle', { cx: f1(x), cy: f1(y), r: 6, fill: '#ffdd55', stroke: '#c08a00', 'stroke-width': 1 }, g); }
      if (s >= 1) { const n = s === 1 ? Math.round(u * 14) : 14; for (let i = 0; i < n; i++) { const x = 124 + (i % 7) * 9, y = 116 + (s === 1 ? u : 1) * 6 + Math.floor(i / 7) * 3; if (s < 6 || u < .5) E('circle', { cx: f1(x), cy: f1(y), r: 1.6, fill: '#2a9a5a' }, g); } }
      if (s >= 2 && s <= 3) { const spread = s === 2 ? u : 1; E('path', { d: `M${f1(160 - spread * 160)} 126H${f1(160 + spread * 200)}`, stroke: '#ffdd55', 'stroke-width': 3.4, opacity: .9 }, g); }
      if (s === 3) [130, 250].forEach(x => E('path', { d: `M${x} 126V${f1(126 + u * 144)}`, stroke: '#ffdd55', 'stroke-width': 3, opacity: .9 }, g));
      if (s >= 4 && s <= 5) { for (let i = 0; i < 26; i++) { const x0 = [108, 152, 228, 272][i % 4], y = 156 + (i * 7) % 104, k = s === 4 ? u : 1, x = x0 + (i % 2 ? 1 : -1) * k * 14; E('circle', { cx: f1(x), cy: f1(y), r: 2.4, fill: '#2a9ad0', stroke: '#1a5a80', 'stroke-width': .4 }, g); } }
      if (s === 5) { const k = Math.sin(u * PI); E('path', { d: `M${f1(40 + k * 14)} 210H${f1(90 + k * 14)}M${f1(320 - k * 14)} 210H${f1(270 - k * 14)}`, stroke: '#c0392b', 'stroke-width': 2.6, 'marker-end': B.mk(g, '#c0392b', 6) }, g); B.tx(g, 180, 214, 'সংকোচন', { fs: 11, a: 'middle', w: 700, c: '#a8201a' }); }
      if (s === 6) { for (let i = 0; i < 26; i++) { const x0 = [108, 152, 228, 272][i % 4], y = 156 + (i * 7) % 104, x = x0 + (i % 2 ? 1 : -1) * (1 - u) * 14; E('circle', { cx: f1(x), cy: f1(y), r: 2.4, fill: '#2a9ad0', opacity: 1 - u * .7 }, g); } B.tx(g, 180, 214, 'শিথিল', { fs: 11, a: 'middle', w: 700, c: '#2a6a4a' }); } }
  }));

/* ═════════ পেশির সংকোচনের লেখচিত্র ═════════ */
const TW = {
  tw: ['একক টান', 'একক সংকোচন (টুইচ)', 'একটি উদ্দীপনায় একবার সংকোচন ও শিথিলতা: সুপ্তকাল (প্রায় 2–10 মিলিসেকেন্ড, Ca<sup>2+</sup> বের হতে সময়), সংকোচনকাল ও শিথিলকাল। ব্যাঙের গ্যাস্ট্রোকনেমিয়াসে পুরো টুইচ প্রায় 0.1 সেকেন্ড।'],
  sum: ['যোগফল', 'তরঙ্গ যোগফল (সামেশন)', 'প্রথম টান পুরো শিথিল হওয়ার আগেই দ্বিতীয় উদ্দীপনা দিলে দ্বিতীয় টান প্রথমটির ওপর চড়ে আরও উঁচু হয় — সারকোপ্লাজমে Ca<sup>2+</sup> জমতে থাকে।'],
  tet: ['টিটেনাস', 'টিটেনাস (টানা সংকোচন)', 'খুব দ্রুত বারবার উদ্দীপনায় (সেকেন্ডে প্রায় 50 বারের বেশি) টানগুলো মিশে মসৃণ সর্বোচ্চ টানা সংকোচন — আমাদের স্বাভাবিক ঐচ্ছিক নড়াচড়া এভাবেই হয়। (টিটেনাস রোগ এক আলাদা বিষয় — ব্যাকটেরিয়ার বিষে অনিয়ন্ত্রিত খিঁচুনি।)'],
  fat: ['ক্লান্তি', 'পেশির ক্লান্তি (ফ্যাটিগ)', 'দীর্ঘক্ষণ টানা সংকোচনে ATP ও ক্রিয়েটিন ফসফেট কমে, অবাত শ্বসনে ল্যাকটিক অ্যাসিড জমে, Ca<sup>2+</sup> নিঃসরণ কমে — উদ্দীপনা চললেও টান ক্রমশ কমে যায়। বিশ্রামে অক্সিজেন ঋণ শোধ হয়ে পেশি আবার সুস্থ হয়।']
};
const twF = (tt, ty) => { const one = x => x < .02 ? 0 : x < .06 ? Math.pow((x - .02) / .04, 1.4) : x < .16 ? Math.exp(-(x - .06) * 22) : Math.exp(-(x - .06) * 22); if (ty === 'tw') return one(tt);
  if (ty === 'sum') return Math.min(1.5, one(tt) + one(tt - .08) * 1.05); const f = ty === 'tet' ? 1 : 1; let v = 0; const iv = ty === 'tet' ? .015 : .02, stop = ty === 'tet' ? .4 : .55; for (let k = 0; k * iv < Math.min(tt, stop); k++) v += one(tt - k * iv) * .55; const cap = Math.min(v, 2.2); return ty === 'fat' ? cap * Math.max(.25, 1 - Math.max(0, tt - .12) * 1.6) : cap; };
V.twitchTetanus = Object.assign({}, B.seg({
  id: 'twt', t: 'পেশির সংকোচনের ধরন (কাইমোগ্রাফের রেখা)', H: 260, def: 'tw', types: TW,
  cap: 'কাইমোগ্রাফ বা আধুনিক ট্রান্সডিউসারে পেশির টান বনাম সময়ের রেখা। নিচের দাগগুলো উদ্দীপনার মুহূর্ত। উদ্দীপনা যত ঘন, টান তত বেশি ও মসৃণ — কিন্তু একটানা চললে ক্লান্তিতে কমে যায়।',
  art(g, C, ty) { const P = B.axes(g, C, [46, 30, 290, 170], { xr: [0, ty === 'tw' ? .2 : .6], yr: [0, 2.4], yt: [], xt: ty === 'tw' ? [0, .05, .1, .15, .2] : [0, .2, .4, .6], xf: v => String(Math.round(v * 1000)), lx: 'সময় (মিলিসেকেন্ড)', ly: 'টান' });
    const xm = ty === 'tw' ? .2 : .6, iv = ty === 'tet' ? .015 : .02, stop = ty === 'tet' ? .4 : .55, st = ty === 'tw' ? [0] : ty === 'sum' ? [0, .08] : Array.from({ length: Math.floor(stop / iv) }, (_, k) => k * iv);
    st.forEach(x => { const [px] = P(x, 0); E('path', { d: `M${f1(px)} 214v8`, stroke: '#c0392b', 'stroke-width': 1.2 }, g); }); B.tx(g, 46, 236, 'উদ্দীপনা', { fs: 8.6, c: '#a8201a' });
    B.curve(g, P, x => twF(x, ty), 0, xm, { stroke: FK.alpha('#5a3aa8', .25) }, 220);
    if (ty === 'tw') { const L = [[0, .02, 'সুপ্তকাল'], [.02, .06, 'সংকোচন'], [.06, .16, 'শিথিলতা']]; L.forEach(([a, b2, s2], i) => { const [x0] = P(a, 0), [x1] = P(b2, 0); E('path', { d: `M${f1(x0)} ${48 + i * 0}h${f1(x1 - x0)}`, stroke: ['#8a8a8a', '#c04a5a', '#2a6ab0'][i], 'stroke-width': 3 }, g); B.tx(g, (x0 + x1) / 2, 44 - (i % 2) * 10, s2, { fs: 9, a: 'middle', w: 650, c: ['#6a6a6a', '#a8201a', '#1f5a86'][i] }); }); } },
  anim(g, C, ty, t) { const xm = ty === 'tw' ? .2 : .6, P = B.axes(E('g', { opacity: 0 }, g), C, [46, 30, 290, 170], { xr: [0, xm], yr: [0, 2.4] }), k = t <= 0 ? 1 : Math.min(1, (t % 5) / 3.4), lim = xm * k;
    B.curve(g, P, x => twF(x, ty), 0, Math.max(.001, lim), { stroke: '#5a3aa8' }, Math.max(8, Math.round(140 * k))); const [px, py] = P(lim, twF(lim, ty)); E('circle', { cx: f1(px), cy: f1(py), r: 3.4, fill: '#5a3aa8' }, g); }
}));
})();
