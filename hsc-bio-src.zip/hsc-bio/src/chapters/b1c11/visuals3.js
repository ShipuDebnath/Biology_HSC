/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §১১.৩ রিকম্বিনেন্ট DNA প্রযুক্তির প্রয়োগ
   gmCrops, rDrugs, herbicideTol, dollyClone, transAnimal, btAction, bdGM, cmpTransClone, cmpGmConv
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const nope = (g, x, y, r, c, w = 2.4) => E('path', { d: `M${x - r} ${y - r}L${x + r} ${y + r}M${x + r} ${y - r}L${x - r} ${y + r}`, stroke: c, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
const okm = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y}l${r * .7} ${r * .7}l${r * 1.3} ${-r * 1.4}`, stroke: c, 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
const arrow = (g, x0, y0, x1, y1, c, o = {}) => { const a = Math.atan2(y1 - y0, x1 - x0), h = o.h || 6; E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: c, 'stroke-width': o.w || 1.6, 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1 }, g); E('path', { d: `M${x1} ${y1}l${-h * Math.cos(a - .45)} ${-h * Math.sin(a - .45)}l${h * Math.cos(a - .45) - h * Math.cos(a + .45)} ${h * Math.sin(a - .45) - h * Math.sin(a + .45)}z`, fill: c, opacity: o.op != null ? o.op : 1 }, g); };
/* চারাগাছ — wilt ০→১ এ নুইয়ে পড়ে ও রং বদলায় */
const sprout = (g, x, y, h, wilt = 0, o = {}) => {
  const R = BK.ramp(o.ri != null ? o.ri : 10), Rb = BK.ramp(11), bend = wilt * h * .5, col = wilt > .5 ? Rb.c : R.c, dk = wilt > .5 ? Rb.dk : R.dk;
  E('path', { d: `M${x} ${y}Q${x} ${y - h * .6} ${x + bend} ${y - h + bend * .6}`, stroke: dk, 'stroke-width': o.sw || 1.8, fill: 'none' }, g);
  const tx = x + bend, ty = y - h + bend * .6;
  [-1, 1].forEach(sd => { const a = sd < 0 ? -2.4 + wilt * 1.4 : -.7 + wilt * 1.2, L = h * (o.lf || .42), c = Math.cos(a), s = Math.sin(a); E('path', { d: `M${tx} ${ty}q${c * L * .5 - s * L * .2} ${s * L * .5 + c * L * .2} ${c * L} ${s * L}q${-c * L * .5 - s * L * .2} ${-s * L * .5 + c * L * .2} ${-c * L} ${-s * L}`, fill: col, stroke: dk, 'stroke-width': .8 }, g); });
  if (o.mid) [-1, 1].forEach(sd => { const yy = y - h * .45, a = sd < 0 ? -2.7 + wilt : -.45 + wilt * .8, L = h * .34, c = Math.cos(a), s = Math.sin(a); E('path', { d: `M${x + bend * .3} ${yy}q${c * L * .5} ${s * L * .5 + 3} ${c * L} ${s * L}q${-c * L * .5} ${-s * L * .5 - 3} ${-c * L} ${-s * L}`, fill: col, stroke: dk, 'stroke-width': .8 }, g); });
};
const cellN = (g, C, x, y, r, R, o = {}) => { E('circle', { cx: x, cy: y, r, fill: FK.alpha(R.c, o.f != null ? o.f : .14), stroke: R.dk, 'stroke-width': 1.2 }, g); if (o.nuc !== false) E('circle', { cx: x + (o.nx || 0), cy: y + (o.ny || 0), r: o.nr || r * .36, fill: FK.alpha(BK.ramp(o.ni != null ? o.ni : 3).c, .55), stroke: BK.ramp(o.ni != null ? o.ni : 3).dk, 'stroke-width': 1 }, g); };
window.B11X = { nope, okm, arrow, sprout, cellN, cmp };

/* ═════════ ১. GM ফসল ═════════ */
const GMC = [
  ['Bt বেগুন', 10, 'কীট প্রতিরোধী', 'cry1Ac', 'Bacillus thuringiensis', 'ডগা ও ফল ছিদ্রকারী পোকা (Leucinodes orbonalis) প্রতিরোধী। মাটির ব্যাকটেরিয়া Bacillus thuringiensis এর cry1Ac জিন বসানো (ভারতের মাহিকো কোম্পানির তৈরি EE-1 ইভেন্ট, BARI তে স্থানীয় জাতে স্থানান্তরিত)। বাংলাদেশে 30 অক্টোবর 2013 এ জাতীয় জীবনিরাপত্তা কমিটি চারটি জাত অনুমোদন করে — দক্ষিণ এশিয়ার প্রথম GM খাদ্য ফসল।'],
  ['Bt তুলা', 2, 'বোলওয়ার্ম প্রতিরোধী', 'cry1Ac, cry2Ab', 'Bacillus thuringiensis', 'তুলার গুটি (বোল) ছিদ্রকারী বোলওয়ার্ম প্রতিরোধী। যুক্তরাষ্ট্রে 1996, ভারতে 2002 থেকে চাষ; বাংলাদেশে মে 2023 এ দুটি জাত (JKCH 1947 Bt ও JKCH 1050 Bt) অনুমোদিত হয়ে 2023-24 মৌসুমে অবমুক্ত হয়।'],
  ['গোল্ডেন রাইস', 6, 'বিটা-ক্যারোটিন সমৃদ্ধ', 'psy + crtI', 'ভুট্টা ও Pantoea ব্যাকটেরিয়া', 'চালের সস্যে (এন্ডোস্পার্মে) বিটা-ক্যারোটিন (প্রো-ভিটামিন A) তৈরি হয় বলে সোনালি রং। প্রথম সংস্করণ ইঙ্গো পটরিকাস ও পিটার বেয়ারের (2000) — ড্যাফোডিলের psy ও Erwinia (বর্তমান নাম Pantoea) এর crtI জিন; উন্নত GR2 (2005) এ ভুট্টার psy — বহুগুণ বেশি ক্যারোটিন। উদ্দেশ্য ভিটামিন A এর অভাবজনিত রাতকানা ও শিশু-অন্ধত্ব প্রতিরোধ। ফিলিপাইন 2021 এ প্রথম চাষের অনুমোদন দেয়; বাংলাদেশে BRRI ধান২৯ এর গোল্ডেন সংস্করণ জীবনিরাপত্তা ছাড়পত্রের অপেক্ষায় রয়েছে।'],
  ['রাউন্ডআপ রেডি সয়াবিন', 5, 'আগাছানাশক সহনশীল', 'CP4 EPSPS', 'Agrobacterium sp. CP4', 'গ্লাইফোসেট (রাউন্ডআপ) সহনশীল — ফসল দাঁড়ানো অবস্থায় স্প্রে করলে আগাছা মরে, ফসল টিকে থাকে। 1996 থেকে বাণিজ্যিক চাষ; বিশ্বে সবচেয়ে বেশি চাষ হওয়া GM ফসলের একটি।'],
  ['ফ্লেভর সেভর টমেটো', 4, 'দেরিতে নরম হয়', 'অ্যান্টিসেন্স PG', 'টমেটোর নিজের জিন (উল্টো)', 'কোষপ্রাচীর নরমকারী পলিগ্যালাকচুরোনেজ (PG) এনজাইমের জিনের উল্টো (অ্যান্টিসেন্স) কপি বসিয়ে এনজাইমের পরিমাণ কমানো — ফল পাকার পরও বেশি দিন শক্ত ও পরিবহনযোগ্য থাকে। ক্যালজিন কোম্পানির; 1994 এ বাজারে আসা প্রথম বাণিজ্যিক GM খাদ্য।'],
  ['রেইনবো পেঁপে', 7, 'ভাইরাস প্রতিরোধী', 'PRSV কোট প্রোটিন', 'পেঁপে রিংস্পট ভাইরাস', 'পেঁপে রিংস্পট ভাইরাসের (PRSV) আবরণ প্রোটিনের জিন পেঁপেতে বসালে উদ্ভিদ সেই ভাইরাস প্রতিরোধী হয় (প্যাথোজেন-উদ্ভূত প্রতিরোধ)। 1998 এ হাওয়াইতে চাষ শুরু — ভাইরাসে ধ্বংসপ্রায় পেঁপে শিল্প রক্ষা পায়।'],
  ['Bt ভুট্টা', 8, 'কর্ন বোরার প্রতিরোধী', 'cry1Ab', 'Bacillus thuringiensis', 'ইউরোপীয় কর্ন বোরার পোকা প্রতিরোধী; 1996 থেকে চাষ। পরে একাধিক cry জিন ও আগাছানাশক সহনশীলতা একসাথে যুক্ত (স্ট্যাকড) জাত এসেছে।'],
  ['RB আলু', 1, 'নাবি ধসা প্রতিরোধী', 'RB জিন', 'বন্য আলু Solanum bulbocastanum', 'আলুর নাবি ধসা (লেট ব্লাইট, Phytophthora infestans) রোগ প্রতিরোধী — বন্য আলুর RB প্রতিরোধী জিন চাষের আলুতে বসানো (সিসজেনিক ধরনের)। বাংলাদেশে BARI এর তত্ত্বাবধানে পরীক্ষামূলক মাঠ পর্যায়ে।']
];
const GSRC = [['Bacillus thuringiensis', 0, [0, 1, 6]], ['Agrobacterium CP4', 5, [3]], ['ভুট্টা + Pantoea', 6, [2]], ['PRSV ভাইরাস', 7, [5]], ['টমেটোর নিজের জিন', 4, [4]], ['বন্য আলু', 1, [7]]];
const cropIcon = (g, C, x, y, i, s = 1) => {
  const R = BK.ramp(GMC[i][1]);
  E('circle', { cx: x, cy: y, r: 15 * s, fill: FK.alpha(R.c, .18), stroke: R.dk, 'stroke-width': 1 }, g);
  if (i === 0) { E('path', { d: `M${x - 9 * s} ${y + 2 * s}q${9 * s} ${-12 * s} ${17 * s} ${-4 * s}q${2 * s} ${10 * s} ${-9 * s} ${11 * s}q${-7 * s} 0 ${-8 * s} ${-7 * s}z`, fill: '#5b2a6e', stroke: '#3a1747', 'stroke-width': .8 }, g); E('path', { d: `M${x + 8 * s} ${y - 3 * s}l${4 * s} ${-6 * s}`, stroke: BK.ramp(10).dk, 'stroke-width': 2 }, g); return; }
  if (i === 1) { [[-5, 2], [4, 0], [0, -6]].forEach(([dx, dy]) => E('circle', { cx: x + dx * s, cy: y + dy * s, r: 5.5 * s, fill: '#fbfbf7', stroke: '#9a9a90', 'stroke-width': .8 }, g)); return; }
  if (i === 2) { for (let k = 0; k < 5; k++) E('ellipse', { cx: x - 6 * s + k * 3 * s, cy: y + 4 * s - k * 3.5 * s, rx: 2.4 * s, ry: 4 * s, fill: '#f0b429', stroke: '#b77d0a', 'stroke-width': .6 }, g); return; }
  if (i === 3) { E('path', { d: `M${x - 8 * s} ${y + 6 * s}q${4 * s} ${-16 * s} ${16 * s} ${-12 * s}`, stroke: '#8a7a3a', 'stroke-width': 5 * s, fill: 'none', 'stroke-linecap': 'round' }, g); [0, 1, 2].forEach(k => E('circle', { cx: x - 4 * s + k * 5 * s, cy: y + 2 * s - k * 4 * s, r: 2.3 * s, fill: '#d8c770' }, g)); return; }
  if (i === 4) { E('circle', { cx: x, cy: y + 2 * s, r: 9 * s, fill: '#e04b3a', stroke: '#9a2a1e', 'stroke-width': .8 }, g); E('path', { d: `M${x - 5 * s} ${y - 6 * s}l${5 * s} ${3 * s}l${5 * s} ${-3 * s}`, stroke: BK.ramp(10).dk, 'stroke-width': 1.6, fill: 'none' }, g); return; }
  if (i === 5) { E('ellipse', { cx: x, cy: y + 1 * s, rx: 7 * s, ry: 11 * s, fill: '#f29f3d', stroke: '#b26414', 'stroke-width': .8 }, g); E('ellipse', { cx: x, cy: y + 3 * s, rx: 3 * s, ry: 6 * s, fill: '#c3461e', opacity: .7 }, g); return; }
  if (i === 6) { E('ellipse', { cx: x, cy: y, rx: 5.5 * s, ry: 11 * s, fill: '#f2cd4a', stroke: '#b18f12', 'stroke-width': .8 }, g); E('path', { d: `M${x - 6 * s} ${y + 10 * s}q${-6 * s} ${-12 * s} ${-2 * s} ${-20 * s}M${x + 6 * s} ${y + 10 * s}q${6 * s} ${-12 * s} ${2 * s} ${-20 * s}`, stroke: BK.ramp(10).c, 'stroke-width': 2, fill: 'none' }, g); return; }
  E('ellipse', { cx: x, cy: y + 1 * s, rx: 10 * s, ry: 7.5 * s, fill: '#c69b5a', stroke: '#8a6630', 'stroke-width': .8 }, g); [[-4, -1], [3, 2], [5, -3]].forEach(([dx, dy]) => E('circle', { cx: x + dx * s, cy: y + dy * s, r: .9 * s, fill: '#6b4a1e' }, g));
};
V.gmCrops = Object.assign({}, B.seg({
  id: 'gmc', t: 'জিনগতভাবে পরিবর্তিত (GM) ফসল', H: 252, def: 'card', sel: null,
  cap: 'GM বা ট্রান্সজেনিক ফসল — রিকম্বিনেন্ট DNA প্রযুক্তিতে অন্য জীবের (বা নিজের পরিবর্তিত) জিন বসিয়ে তৈরি উদ্ভিদ, যাতে কাঙ্ক্ষিত নতুন বৈশিষ্ট্য প্রকাশ পায়। উদ্ভিদে জিন ঢোকানো হয় মূলত Agrobacterium tumefaciens এর Ti প্লাসমিড বা জিন গান (বায়োলিস্টিক) দিয়ে; রূপান্তরিত কোষ থেকে টিস্যু কালচারে পূর্ণ উদ্ভিদ জন্মানো হয়। কার্ডে বা উৎসে চাপ দাও।',
  types: {
    card: ['ফসল', 'উল্লেখযোগ্য GM ফসল', 'প্রতিটি কার্ডে বৈশিষ্ট্য ও বসানো জিন — চাপ দিলে বিস্তারিত।'],
    flow: ['জিনের উৎস', 'কোন জীবের জিন কোন ফসলে', 'GM প্রযুক্তিতে প্রজাতির সীমা নেই — ব্যাকটেরিয়া, ভাইরাস, অন্য উদ্ভিদ, এমনকি নিজের উল্টো জিনও কাজে লাগে।']
  },
  art(g, C, ty, ctx) {
    const H = [];
    if (ty === 'card') {
      GMC.forEach(([s, ri, tr, gn], i) => {
        const c = i % 2, r = Math.floor(i / 2), x = 10 + c * 172, y = 12 + r * 59, R = BK.ramp(ri), on = ctx.sel === i;
        E('rect', { x, y, width: 166, height: 53, rx: 10, fill: FK.alpha(R.c, on ? .22 : .07), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g);
        cropIcon(g, C, x + 24, y + 26, i, .95);
        T(g, x + 46, y + 18, s, { fs: s.length > 14 ? 9.4 : 10.5, w: 700, c: R.ink });
        T(g, x + 46, y + 32, tr, { fs: 9.4, c: C.fg });
        T(g, x + 46, y + 45, gn, { fs: 8.8, c: C.mu });
        H.push([x + 83, y + 26, i]);
      });
      ctx.H = H; return;
    }
    GSRC.forEach(([s, ri, to], j) => {
      const y = 24 + j * 37, R = BK.ramp(ri), on = ctx.sel === 's' + j;
      E('rect', { x: 8, y: y - 12, width: 126, height: 24, rx: 8, fill: FK.alpha(R.c, on ? .3 : .12), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      T(g, 71, y + 4, s, { fs: s.length > 17 ? 8.4 : 9.4, a: 'middle', w: 600, c: R.ink });
      H.push([71, y, 's' + j]);
      to.forEach(i => { const yy = 20 + i * 29, act = ctx.sel == null || on || ctx.sel === i; E('path', { d: `M134 ${y}C190 ${y} 196 ${yy} 244 ${yy}`, stroke: FK.alpha(BK.ramp(6).c, act ? .75 : .16), 'stroke-width': act ? 2 : 1.2, fill: 'none' }, g); });
    });
    GMC.forEach(([s, ri], i) => { const y = 20 + i * 29, R = BK.ramp(ri), on = ctx.sel === i; cropIcon(g, C, 258, y, i, .62); T(g, 272, y + 3.5, s, { fs: 9.2, w: on ? 700 : 550, c: on ? R.ink : C.fg }); H.push([300, y, i]); });
    ctx.H = H;
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    if (ty === 'card') { const i = Math.floor(t * .45) % GMC.length, c = i % 2, r = Math.floor(i / 2), x = 10 + c * 172 + 24, y = 12 + r * 59 + 26, k = (t * .45) % 1; E('circle', { cx: x, cy: y, r: 15 + 8 * k, fill: 'none', stroke: BK.ramp(GMC[i][1]).c, 'stroke-width': 2, opacity: 1 - k }, g); return; }
    GSRC.forEach(([, , to], j) => { const y = 24 + j * 37; to.forEach((i, q) => { if (ctx.sel != null && ctx.sel !== 's' + j && ctx.sel !== i) return; const yy = 20 + i * 29, u = (t * .4 + j * .17 + q * .3) % 1, mt = 1 - u; const px = mt ** 3 * 134 + 3 * mt * mt * u * 190 + 3 * mt * u * u * 196 + u ** 3 * 244, py = mt ** 3 * y + 3 * mt * mt * u * y + 3 * mt * u * u * yy + u ** 3 * yy; E('rect', { x: px - 6, y: py - 3, width: 12, height: 6, rx: 2, fill: BK.ramp(6).c, stroke: BK.ramp(6).dk, 'stroke-width': .6 }, g); }); });
  },
  tap(x, y, ty, ctx) {
    const h = hot(ctx.H || [], x, y, ty === 'card' ? 84 : 40); if (!h) return null; ctx.sel = h[2];
    if (typeof h[2] === 'string') { const s = GSRC[+h[2].slice(1)]; return `<b>${s[0]}</b> → ${s[2].map(i => GMC[i][0]).join(', ')}।<div class="small">জিন: ${s[2].map(i => GMC[i][3]).join('; ')}</div>`; }
    const c = GMC[h[2]]; return `<b>${c[0]}</b> — ${c[2]}; জিন: ${c[3]} (উৎস: ${c[4]})।<div class="small">${c[5]}</div>`;
  }
}));
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11, XB = window.B11X;
const cl = B.cl, rnd = B.rnd, node = B.node, hot = B.hot, nope = XB.nope, okm = XB.okm, arrow = XB.arrow, sprout = XB.sprout;

/* ═════════ ২. রিকম্বিনেন্ট ওষুধ ═════════ */
const RD = [
  ['মানব ইনসুলিন', 'E. coli, ইস্ট', 'ডায়াবেটিস', 1982, 'প্রথম রিকম্বিনেন্ট ওষুধ — জেনেনটেক 1978 এ E. coli তে মানব ইনসুলিন তৈরি করে, এলি লিলি "হিউমুলিন" নামে 1982 এ বাজারে আনে। টাইপ-১ ও অনেক টাইপ-২ ডায়াবেটিস রোগীর রক্তে গ্লুকোজ নিয়ন্ত্রণে ব্যবহৃত।'],
  ['গ্রোথ হরমোন (hGH)', 'E. coli', 'বামনত্ব', 1985, 'সোমাটোট্রপিন — পিটুইটারি গ্রন্থির হরমোন; এর ঘাটতিজনিত বামনত্বের চিকিৎসায় ব্যবহৃত। আগে মৃতদেহের পিটুইটারি থেকে সংগ্রহ করা হতো, তাতে প্রিয়ন রোগ (CJD) সংক্রমণের ঝুঁকি ছিল; রিকম্বিনেন্ট hGH (1985) সে ঝুঁকিমুক্ত।'],
  ['ইন্টারফেরন-আলফা', 'E. coli', 'হেপাটাইটিস, ক্যান্সার', 1986, 'ভাইরাসরোধী ও রোগপ্রতিরোধ নিয়ন্ত্রক প্রোটিন; হেপাটাইটিস B ও C, হেয়ারি সেল লিউকেমিয়া, কাপোসি সারকোমা ও কিছু মেলানোমার চিকিৎসায় ব্যবহৃত (প্রথম অনুমোদন 1986)।'],
  ['হেপাটাইটিস B টিকা', 'ইস্ট', 'প্রতিরোধ (টিকা)', 1986, 'ভাইরাসের উপরিতলের অ্যান্টিজেনের (HBsAg) জিন ইস্টে প্রকাশ করে তৈরি — প্রথম রিকম্বিনেন্ট টিকা (1986)। পুরো ভাইরাস ব্যবহৃত হয় না বলে সংক্রমণের ঝুঁকি নেই; বাংলাদেশে EPI কর্মসূচিতে শিশুদের দেওয়া হয়।'],
  ['tPA (অ্যালটেপ্লেজ)', 'CHO কোষ', 'হার্ট অ্যাটাক, স্ট্রোক', 1987, 'টিস্যু প্লাসমিনোজেন অ্যাক্টিভেটর — রক্তনালিতে জমাট বাঁধা রক্ত (থ্রম্বাস) গলিয়ে দেয়; চাইনিজ হ্যামস্টার ওভারি (CHO) কোষে উৎপাদিত (জেনেনটেক, 1987)।'],
  ['এরিথ্রোপয়েটিন (EPO)', 'CHO কোষ', 'রক্তস্বল্পতা', 1989, 'বৃক্কের হরমোন, অস্থিমজ্জায় লোহিত রক্তকণিকা তৈরি বাড়ায় — বৃক্ক বিকল রোগী (ডায়ালাইসিস) ও কেমোথেরাপিজনিত রক্তস্বল্পতায় ব্যবহৃত (1989)।'],
  ['ফ্যাক্টর VIII', 'CHO / BHK কোষ', 'হিমোফিলিয়া A', 1992, 'রক্ত জমাট বাঁধার প্রোটিন; হিমোফিলিয়া A রোগীর রক্তক্ষরণ বন্ধে। আগে দাতার রক্তরস থেকে নেওয়া হতো — HIV ও হেপাটাইটিস সংক্রমণের ঝুঁকি ছিল; রিকম্বিনেন্ট ফ্যাক্টর VIII (1992) নিরাপদ।'],
  ['HPV টিকা', 'ইস্ট', 'জরায়ুমুখ ক্যান্সার প্রতিরোধ', 2006, 'হিউম্যান প্যাপিলোমা ভাইরাসের আবরণ প্রোটিন (L1) ইস্টে তৈরি করে ভাইরাস-সদৃশ কণা (VLP) বানানো হয় — 2006 এ অনুমোদিত; বাংলাদেশে 2023 থেকে কিশোরীদের দেওয়া হচ্ছে।']
];
const RDT = [[1977, 'সোমাটোস্ট্যাটিন', 'E. coli তে তৈরি প্রথম মানব প্রোটিন (ইটাকুরা, বয়ার ও সহযোগীরা)।'], [1978, 'ইনসুলিন জিন', 'জেনেনটেক E. coli তে মানব ইনসুলিনের দুই শিকল তৈরি করে।'], [1982, 'হিউমুলিন', 'প্রথম অনুমোদিত রিকম্বিনেন্ট ওষুধ — মানব ইনসুলিন বাজারে।'], [1985, 'গ্রোথ হরমোন', 'রিকম্বিনেন্ট hGH অনুমোদিত — প্রিয়ন সংক্রমণের ঝুঁকি দূর হয়।'], [1986, 'ইন্টারফেরন ও HBV টিকা', 'ইন্টারফেরন-আলফা এবং প্রথম রিকম্বিনেন্ট টিকা (হেপাটাইটিস B) অনুমোদিত।'], [1987, 'tPA', 'স্তন্যপায়ী (CHO) কোষে তৈরি প্রথম বড় প্রোটিন ওষুধ।'], [1989, 'EPO', 'এরিথ্রোপয়েটিন — রক্তস্বল্পতার চিকিৎসায়।'], [1992, 'ফ্যাক্টর VIII', 'হিমোফিলিয়া A এর জন্য রক্তবাহিত সংক্রমণমুক্ত ফ্যাক্টর।'], [2006, 'HPV টিকা', 'ভাইরাস-সদৃশ কণার টিকা — জরায়ুমুখ ক্যান্সার প্রতিরোধ।']];
const hostCol = h => h.includes('CHO') || h.includes('BHK') ? 3 : h.includes('ইস্ট') && !h.includes('coli') ? 9 : 0;
V.rDrugs = Object.assign({}, B.seg({
  id: 'rdr', t: 'রিকম্বিনেন্ট DNA প্রযুক্তিতে তৈরি ওষুধ', H: 268, def: 'list', sel: null,
  cap: 'মানুষের প্রোটিন-ওষুধের জিন ব্যাকটেরিয়া (E. coli), ইস্ট বা স্তন্যপায়ী কোষে (CHO — চাইনিজ হ্যামস্টার ওভারি) বসিয়ে বড় ফার্মেন্টার বা বায়োরিঅ্যাক্টরে প্রচুর পরিমাণে উৎপাদন করা হয়। সরল প্রোটিনের জন্য ব্যাকটেরিয়াই যথেষ্ট; শর্করাযুক্ত (গ্লাইকোসাইলেটেড) জটিল প্রোটিনের জন্য স্তন্যপায়ী কোষ লাগে, কারণ ব্যাকটেরিয়া প্রোটিনে শর্করা যোগ করতে পারে না। সারিতে বা বিন্দুতে চাপ দাও।',
  types: {
    list: ['ওষুধ ও পোষক', 'ওষুধ, পোষক কোষ ও ব্যবহার', 'পোষকের রং: টিল — ব্যাকটেরিয়া, ধূসর — ইস্ট, বেগুনি — স্তন্যপায়ী কোষ।'],
    time: ['সময়রেখা', 'রিকম্বিনেন্ট ওষুধের ইতিহাস', '1977 এ প্রথম মানব প্রোটিন থেকে আজ শতাধিক রিকম্বিনেন্ট ওষুধ — বিশ্ব ওষুধ বাজারের বড় অংশ এখন এভাবেই তৈরি।']
  },
  art(g, C, ty, ctx) {
    const H = [];
    if (ty === 'list') {
      T(g, 14, 20, 'ওষুধ', { fs: 9.5, w: 700, c: C.mu }); T(g, 176, 20, 'পোষক', { fs: 9.5, a: 'middle', w: 700, c: C.mu }); T(g, 230, 20, 'ব্যবহার', { fs: 9.5, w: 700, c: C.mu });
      RD.forEach(([s, h, u], i) => {
        const y = 30 + i * 29, on = ctx.sel === i, R = BK.ramp(hostCol(h));
        E('rect', { x: 6, y, width: 348, height: 25, rx: 7, fill: on ? FK.alpha(R.c, .2) : i % 2 ? FK.alpha(C.ln, .18) : 'none', stroke: on ? R.dk : 'none', 'stroke-width': 1.6 }, g);
        T(g, 14, y + 16.5, s, { fs: s.length > 16 ? 9 : 10, w: on ? 700 : 600, c: C.fg });
        B.chip(g, 176, y + 12.5, h, R, { w: 78, h: 17, fs: 8.6 });
        T(g, 230, y + 16.5, u, { fs: u.length > 16 ? 8.4 : 9.4, c: C.fg });
        H.push([180, y + 12, i]);
      });
      ctx.H = H; return;
    }
    const x0 = 26, x1 = 338, PX = yr => x0 + (yr - 1976) / 32 * (x1 - x0), y = 140;
    E('path', { d: `M${x0} ${y}H${x1}`, stroke: C.fg, 'stroke-width': 1.6 }, g);
    [1980, 1990, 2000].forEach(v => { E('path', { d: `M${PX(v)} ${y}v6`, stroke: C.mu }, g); T(g, PX(v), y + 20, String(v), { fs: 9, a: 'middle', c: C.mu }); });
    RDT.forEach(([yr, sh], i) => {
      const up = i % 2 === 0, px = PX(yr), L = up ? (i % 4 === 0 ? 76 : 40) : (i % 4 === 1 ? 70 : 36), py = up ? y - L : y + L, on = ctx.sel === i, R = BK.ramp(i === 2 ? 6 : 1);
      E('path', { d: `M${px} ${y}V${py + (up ? 10 : -10)}`, stroke: FK.alpha(R.c, .6), 'stroke-width': 1 }, g);
      E('circle', { cx: px, cy: y, r: on ? 6 : 4, fill: R.c, stroke: C.sf, 'stroke-width': 1.4 }, g);
      T(g, cl(px, 30, 330), py + (up ? 4 : 4), String(yr), { fs: 9.4, a: 'middle', w: 700, c: R.ink });
      T(g, cl(px, 42, 318), py + (up ? -8 : 16), sh, { fs: 8.4, a: 'middle', c: C.fg });
      H.push([px, y, i]);
    });
    T(g, 180, 258, 'বিন্দুতে চাপ দিয়ে ঘটনাটি পড়ো', { fs: 9, a: 'middle', c: C.mu });
    ctx.H = H;
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    if (ty === 'list') { const i = Math.floor(t * .5) % RD.length, y = 30 + i * 29, k = (t * .5) % 1; E('circle', { cx: 6 + 348 * k, cy: y + 24, r: 2.2, fill: BK.ramp(hostCol(RD[i][1])).c }, g); return; }
    const u = (t * .09) % 1; E('circle', { cx: 26 + 312 * u, cy: 140, r: 5, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2 }, g);
  },
  tap(x, y, ty, ctx) {
    const h = hot(ctx.H || [], x, y, ty === 'list' ? 180 : 26); if (!h) return null; ctx.sel = h[2];
    if (ty === 'list') { const d = RD[h[2]]; return `<b>${d[0]}</b> — পোষক: ${d[1]}; ব্যবহার: ${d[2]} (${d[3]})।<div class="small">${d[4]}</div>`; }
    const e = RDT[h[2]]; return `<b>${e[0]} — ${e[1]}</b><div class="small">${e[2]}</div>`;
  }
}));

/* ═════════ ৩. আগাছানাশক সহনশীল উদ্ভিদ ═════════ */
const HB = [
  ['গ্লাইফোসেট (রাউন্ডআপ)', 'EPSPS — শিকিমেট পথ', 'অসংবেদনশীল লক্ষ্য এনজাইম', 'CP4 EPSPS', 'গ্লাইফোসেট উদ্ভিদের EPSPS এনজাইমে আটকে শিকিমেট পথ বন্ধ করে — অ্যারোমেটিক অ্যামিনো অ্যাসিড (ফিনাইলঅ্যালানিন, টাইরোসিন, ট্রিপটোফ্যান) তৈরি না হওয়ায় উদ্ভিদ মরে যায়। Agrobacterium sp. CP4 এর EPSPS এ গ্লাইফোসেট বাঁধতে পারে না, তাই GM উদ্ভিদে পথটি চালু থাকে।'],
  ['গ্লুফোসিনেট (বাস্তা)', 'গ্লুটামিন সিনথেটেজ', 'আগাছানাশক নিষ্ক্রিয় করা', 'bar / pat', 'গ্লুফোসিনেট গ্লুটামিন সিনথেটেজ বন্ধ করে — কোষে অ্যামোনিয়া জমে বিষক্রিয়া হয়। Streptomyces এর bar জিনের ফসফিনোথ্রিসিন অ্যাসিটাইলট্রান্সফারেজ (PAT) এনজাইম আগাছানাশকটিতে অ্যাসিটাইল যোগ করে নিষ্ক্রিয় করে দেয় (ডিটক্সিফিকেশন)।'],
  ['ব্রোমোক্সিনিল', 'ফটোসিস্টেম II', 'আগাছানাশক ভেঙে ফেলা', 'bxn', 'ব্রোমোক্সিনিল সালোকসংশ্লেষণের ফটোসিস্টেম II এ ইলেকট্রন প্রবাহ আটকে দেয়। Klebsiella এর bxn জিনের নাইট্রিলেজ এনজাইম একে নিরীহ যৌগে ভেঙে ফেলে (BXN তুলা)।']
];
V.herbicideTol = Object.assign({}, B.seg({
  id: 'hbt', t: 'আগাছানাশক সহনশীল উদ্ভিদ', H: 250, def: 'path', sel: 0,
  cap: 'আগাছানাশক (হার্বিসাইড) সাধারণত আগাছা ও ফসল দুটিকেই মারে। আগাছানাশকের লক্ষ্য এনজাইমের অসংবেদনশীল রূপ, বা আগাছানাশক ভেঙে ফেলার এনজাইমের জিন ফসলে বসালে ফসল টিকে থাকে — তখন ফসল দাঁড়ানো অবস্থায়ও মাঠে স্প্রে করে কেবল আগাছা দমন করা যায়। নিড়ানির শ্রম ও বারবার চাষ কমে, মাটির ক্ষয়ও কম হয়।',
  types: {
    path: ['এনজাইমের পথ', 'গ্লাইফোসেট যেভাবে কাজ করে', 'উপরের দুই বোতামে সাধারণ ও GM উদ্ভিদ বদলাও। প্রাণীদেহে শিকিমেট পথ নেই, তাই গ্লাইফোসেট প্রাণীর জন্য তুলনামূলক কম বিষাক্ত।'],
    field: ['মাঠে স্প্রে', 'GM ফসলের মাঠে আগাছানাশক স্প্রে', 'স্প্রে চলে যাওয়ার পর আগাছা নুইয়ে মরে যায়, GM ফসল সবুজ থাকে।', 'ঝুঁকি: একই আগাছানাশক বারবার ব্যবহারে প্রতিরোধী "সুপার আগাছা" তৈরি হতে পারে; পরাগের মাধ্যমে বন্য আত্মীয়ে জিন প্রবাহের আশঙ্কাও থাকে।'],
    kind: ['তিন কৌশল', 'সহনশীলতা অর্জনের কৌশল', 'লক্ষ্য এনজাইম বদলানো, আগাছানাশক নিষ্ক্রিয় করা বা ভেঙে ফেলা — সারিতে চাপ দাও।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'path') {
      const gm = ctx.sel === 1, Rg = BK.ramp(2), Re = gm ? BK.ramp(6) : BK.ramp(1);
      [['সাধারণ উদ্ভিদ', 0], ['GM উদ্ভিদ (CP4)', 1]].forEach(([s, v], i) => { const on = ctx.sel === v, R = v ? BK.ramp(6) : BK.ramp(1); E('rect', { x: 26 + i * 160, y: 8, width: 148, height: 24, rx: 12, fill: on ? FK.alpha(R.c, .3) : 'none', stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g); T(g, 100 + i * 160, 24, s, { fs: 10.5, a: 'middle', w: on ? 700 : 500, c: R.ink }); });
      ctx.H = [[100, 20, 0], [260, 20, 1]];
      node(g, 64, 70, 'শিকিমেট-৩-P', BK.ramp(9), 96, 22, { fs: 9.4 }); node(g, 64, 104, 'PEP', BK.ramp(9), 60, 22, { fs: 9.4 });
      E('path', { d: 'M112 70Q132 70 140 86M94 104Q130 104 140 92', stroke: C.mu, 'stroke-width': 1.4, fill: 'none' }, g);
      E('ellipse', { cx: 170, cy: 89, rx: 30, ry: 19, fill: FK.alpha(Re.c, .25), stroke: Re.dk, 'stroke-width': 1.6 }, g);
      T(g, 170, 86, gm ? 'CP4' : 'EPSPS', { fs: 10, a: 'middle', w: 700, c: Re.ink }); T(g, 170, 99, gm ? 'EPSPS' : '(উদ্ভিদের)', { fs: 8.4, a: 'middle', c: C.mu });
      E('path', { d: 'M148 46l7 -7l7 7l-7 7z', fill: Rg.c, stroke: Rg.dk }, g); T(g, 168, 44, 'গ্লাইফোসেট', { fs: 9.4, w: 600, c: Rg.ink });
      const off = !gm, op = off ? .3 : 1;
      arrow(g, 202, 89, 238, 89, C.fg, { op }); node(g, 272, 89, 'EPSP', BK.ramp(9), 56, 22, { fs: 9.4, fill: FK.alpha(BK.ramp(9).c, off ? .06 : .2) });
      arrow(g, 272, 101, 272, 126, C.fg, { op }); node(g, 272, 138, 'কোরিসমেট', BK.ramp(9), 76, 22, { fs: 9.4, fill: FK.alpha(BK.ramp(9).c, off ? .06 : .2) });
      ['ফিনাইলঅ্যালানিন', 'টাইরোসিন', 'ট্রিপটোফ্যান'].forEach((s, i) => { const x = 82 + i * 98; E('path', { d: `M272 150Q${x} 160 ${x} 172`, stroke: C.mu, 'stroke-width': 1.2, fill: 'none', opacity: op }, g); node(g, x, 182, s, BK.ramp(5), 94, 20, { fs: 8.8, fill: FK.alpha(BK.ramp(5).c, off ? .05 : .2) }); });
      T(g, 180, 210, 'প্রোটিন, লিগনিন, অক্সিন ও অন্যান্য যৌগ', { fs: 9.4, a: 'middle', c: C.fg, op });
      if (off) { nope(g, 212, 70, 7, BK.ramp(4).dk, 3); T(g, 180, 236, 'পথ বন্ধ, অ্যামিনো অ্যাসিড তৈরি হয় না — উদ্ভিদ মরে যায়', { fs: 9.6, a: 'middle', w: 650, c: BK.ramp(4).ink }); }
      else { okm(g, 210, 70, 6, BK.ramp(10).dk); T(g, 180, 236, 'গ্লাইফোসেট বাঁধে না, পথ চালু — উদ্ভিদ বেঁচে থাকে', { fs: 9.6, a: 'middle', w: 650, c: BK.ramp(10).ink }); }
      return;
    }
    if (ty === 'field') {
      E('rect', { x: 0, y: 196, width: 360, height: 54, fill: FK.alpha(BK.ramp(11).c, .28) }, g); E('path', { d: 'M0 196H360', stroke: BK.ramp(11).dk, 'stroke-width': 1.2 }, g);
      T(g, 86, 236, 'GM ফসল — টিকে থাকে', { fs: 9.4, a: 'middle', w: 600, c: BK.ramp(10).ink }); T(g, 274, 236, 'আগাছা — মরে যায়', { fs: 9.4, a: 'middle', w: 600, c: BK.ramp(11).ink });
      return;
    }
    HB.forEach(([s, tg, st, gn], i) => { const y = 14 + i * 76, on = ctx.sel === i, R = BK.ramp([6, 0, 1][i]); E('rect', { x: 8, y, width: 344, height: 68, rx: 10, fill: FK.alpha(R.c, on ? .2 : .07), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); T(g, 20, y + 18, s, { fs: 11, w: 700, c: R.ink }); T(g, 20, y + 35, 'লক্ষ্য: ' + tg, { fs: 9.4, c: C.fg }); T(g, 20, y + 52, 'কৌশল: ' + st, { fs: 9.4, c: C.fg }); B.chip(g, 294, y + 50, gn, R, { w: 102, h: 18, fs: 9 }); });
    ctx.H = HB.map((_, i) => [180, 48 + i * 76, i]);
  },
  anim(g, C, ty, t, ctx) {
    if (ty === 'path') {
      const gm = ctx.sel === 1, u = t ? t * .55 : .4;
      for (let i = 0; i < 5; i++) { const k = (u + i * .2) % 1; if (!gm) { E('circle', { cx: 112 + Math.min(k, .5) * 48, cy: 70 + (k > .5 ? (i - 2) * 3 : 0), r: 3, fill: BK.ramp(9).c, opacity: .9 }, g); } else { const pts = [[112, 70], [140, 86], [202, 89], [244, 89], [272, 120], [272, 150], [82 + (i % 3) * 98, 172]], [x, y] = B.along(pts, k); E('circle', { cx: x, cy: y, r: 3, fill: BK.ramp(6).c }, g); } }
      const k2 = t ? (t * .5) % 1 : .5; E('path', { d: `M155 ${53 + 10 * k2}v8`, stroke: BK.ramp(2).c, 'stroke-width': 2, opacity: 1 - k2, 'stroke-linecap': 'round' }, g);
      return;
    }
    if (ty === 'field') {
      const u = t ? (t * .12) % 1.3 : .55, sx = -20 + u * 400;
      for (let i = 0; i < 8; i++) { const x = 24 + i * 45, crop = i % 2 === 0, w = crop ? 0 : cl((sx - x) / 60); if (crop) sprout(g, x, 196, 70, 0, { ri: 10, mid: 1, sw: 2.6, lf: .38 }); else sprout(g, x, 196, 34, w, { ri: 8, lf: .5 }); }
      E('rect', { x: sx - 30, y: 26, width: 60, height: 14, rx: 4, fill: BK.ramp(9).c, stroke: BK.ramp(9).dk }, g); E('path', { d: `M${sx} 40v14`, stroke: BK.ramp(9).dk, 'stroke-width': 3 }, g);
      for (let i = 0; i < 14; i++) { const dy = ((t * 2.2 + rnd(i + 30)) % 1) * 130, dx = (rnd(i) - .5) * 64 * dy / 130; E('circle', { cx: sx + dx, cy: 56 + dy, r: 1.8, fill: BK.ramp(2).c, opacity: .75 }, g); }
      T(g, cl(sx, 40, 320), 20, 'গ্লাইফোসেট স্প্রে', { fs: 9.4, a: 'middle', w: 600, c: BK.ramp(2).ink });
      return;
    }
    if (!t) return; const i = ctx.sel != null ? ctx.sel : Math.floor(t * .4) % 3, y = 64 + i * 76, k = (t * .6) % 1; E('circle', { cx: 210 + 30 * k, cy: y, r: 3, fill: BK.ramp([6, 0, 1][i]).c, opacity: 1 - k }, g);
  },
  tap(x, y, ty, ctx) {
    if (ty === 'field') return null;
    if (ty === 'path') { if (y > 40) return null; ctx.sel = x < 180 ? 0 : 1; return ctx.sel ? '<b>GM উদ্ভিদ</b> — Agrobacterium sp. CP4 এর cp4 epsps জিন বসানো; এই এনজাইমের সক্রিয় স্থানে গ্লাইফোসেট বাঁধতে পারে না, তাই শিকিমেট পথ চালু থাকে। উদাহরণ — রাউন্ডআপ রেডি সয়াবিন (1996), ভুট্টা, তুলা, ক্যানোলা।' : '<b>সাধারণ উদ্ভিদ</b> — গ্লাইফোসেট EPSPS এনজাইমে PEP এর জায়গায় বসে এনজাইমকে আটকে দেয়; শিকিমেট-৩-ফসফেট জমতে থাকে, অ্যারোমেটিক অ্যামিনো অ্যাসিড তৈরি বন্ধ হয় এবং এক-দুই সপ্তাহে উদ্ভিদ মরে যায়।'; }
    const h = hot(ctx.H || [], x, y, 180); if (!h) return null; ctx.sel = h[2]; const d = HB[h[2]]; return `<b>${d[0]}</b> — জিন: ${d[3]}।<div class="small">${d[4]}</div>`;
  }
}));
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11, XB = window.B11X;
const cl = B.cl, rnd = B.rnd, node = B.node, hot = B.hot, arrow = XB.arrow, cellN = XB.cellN;
/* ভেড়ার সরল রূপ — face: 'w' সাদা মুখ, 'b' কালো মুখ */
const ewe = (g, C, x, y, s, face, lab) => {
  const wool = '#f2eee4', edge = '#b8b1a1';
  for (let i = 0; i < 6; i++) { const a = i / 6 * 2 * Math.PI; E('circle', { cx: x + Math.cos(a) * 17 * s, cy: y + Math.sin(a) * 9 * s, r: 8.6 * s, fill: wool, stroke: edge, 'stroke-width': .8 }, g); }
  E('ellipse', { cx: x, cy: y, rx: 20 * s, ry: 11 * s, fill: wool }, g);
  [-11, -4, 5, 12].forEach(dx => E('path', { d: `M${x + dx * s} ${y + 9 * s}v${11 * s}`, stroke: '#4a4038', 'stroke-width': 2.2 * s, 'stroke-linecap': 'round' }, g));
  const hx = x + 24 * s, hy = y - 6 * s, fc = face === 'b' ? '#36302a' : '#eee3cf';
  E('ellipse', { cx: hx, cy: hy, rx: 7.5 * s, ry: 9.5 * s, fill: fc, stroke: face === 'b' ? '#1d1a17' : '#a99b82', 'stroke-width': .9 }, g);
  E('ellipse', { cx: hx - 6 * s, cy: hy - 7 * s, rx: 4.6 * s, ry: 2.3 * s, fill: fc, stroke: face === 'b' ? '#1d1a17' : '#a99b82', 'stroke-width': .8 }, g);
  E('circle', { cx: hx + 2 * s, cy: hy - 2 * s, r: 1.2 * s, fill: face === 'b' ? '#ded8cc' : '#2a2520' }, g);
  if (lab) T(g, x, y + 32 * s, lab, { fs: 9, a: 'middle', w: 600, c: C.fg });
};
const womb = (g, C, x, y, s, R) => {
  E('path', { d: `M${x - 26 * s} ${y - 26 * s}q${6 * s} ${22 * s} ${10 * s} ${28 * s}q${-6 * s} ${26 * s} ${16 * s} ${30 * s}q${22 * s} ${-4 * s} ${16 * s} ${-30 * s}q${4 * s} ${-6 * s} ${10 * s} ${-28 * s}`, fill: FK.alpha(R.c, .14), stroke: R.dk, 'stroke-width': 1.4, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
  E('path', { d: `M${x - 20 * s} ${y - 24 * s}q${-8 * s} ${-6 * s} ${-14 * s} ${-2 * s}M${x + 20 * s} ${y - 24 * s}q${8 * s} ${-6 * s} ${14 * s} ${-2 * s}`, stroke: R.dk, 'stroke-width': 1.4, fill: 'none', 'stroke-linecap': 'round' }, g);
};
window.B11W = womb;
const pipette = (g, x, y, a, R, L = 40) => { const c = Math.cos(a), s = Math.sin(a); E('path', { d: `M${x} ${y}L${x + c * L} ${y + s * L}`, stroke: R.dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); E('path', { d: `M${x + c * L * .45} ${y + s * L * .45}L${x + c * L} ${y + s * L}`, stroke: R.c, 'stroke-width': 4.6, 'stroke-linecap': 'round', opacity: .5 }, g); };

/* ═════════ ৪. ক্লোন প্রাণী — ডলি ═════════ */
V.dollyClone = Object.assign({ t: 'দেহকোষ নিউক্লিয়াস স্থানান্তর — ডলি ভেড়া', k: ['anim', 'steps'], cap: 'ক্লোন প্রাণী — যৌন প্রজনন ছাড়াই একটি প্রাণীর দেহকোষের নিউক্লিয়াস থেকে তৈরি প্রাণী, যার নিউক্লিয়াসের জিন দাতার সাথে হুবহু এক। স্কটল্যান্ডের রোজলিন ইনস্টিটিউটে ইয়ান উইলমুট ও কিথ ক্যাম্পবেলের দল 5 জুলাই 1996 এ প্রথম প্রাপ্তবয়স্ক দেহকোষ থেকে স্তন্যপায়ী ক্লোন করেন — ডলি ভেড়া (ঘোষণা ফেব্রুয়ারি 1997)। ক্লোনিংয়ে বাইরের কোনো জিন যুক্ত হয় না, তাই ক্লোন প্রাণী ট্রান্সজেনিক নয়।' }, BK.steps({
  W: 360, H: 240, label: 'ক্লোনিংয়ের ধাপ', dur: 3.2,
  stages: [
    { t: 'দাতা দেহকোষ', en: 'Donor somatic cell', d: '৬ বছর বয়সী সাদা মুখের ফিন ডরসেট ভেড়ির স্তনগ্রন্থির (ম্যামারি) কোষ নিয়ে অল্প পুষ্টির মাধ্যমে (০.৫% সিরাম) রাখা হয় — কোষ বিভাজন থেমে বিশ্রাম দশায় (G0) আসে, তখন নিউক্লিয়াস নতুন করে কাজ শুরু করতে পারে।' },
    { t: 'ডিম্বাণুর নিউক্লিয়াস অপসারণ', en: 'Enucleation', d: 'কালো মুখের স্কটিশ ব্ল্যাকফেস ভেড়ির অনিষিক্ত ডিম্বাণু থেকে সূক্ষ্ম পিপেটে নিউক্লিয়াস (ক্রোমোসোম) সরিয়ে ফেলা হয় — থাকে কেবল সাইটোপ্লাজম ও মাইটোকন্ড্রিয়া।' },
    { t: 'বৈদ্যুতিক মিলন', en: 'Electrofusion', d: 'দাতা কোষটি নিউক্লিয়াসহীন ডিম্বাণুর পাশে রেখে মৃদু বৈদ্যুতিক স্পন্দন দেওয়া হয় — দুটি কোষ মিলে এক হয়ে যায় এবং ডিম্বাণু সক্রিয় হয়ে বিভাজন শুরু করে।' },
    { t: 'ভ্রূণ স্থাপন', en: 'Embryo transfer', d: 'কয়েক দিন কালচারে ভ্রূণ (মরুলা বা ব্লাস্টোসিস্ট দশা) তৈরি হলে তা আরেকটি স্কটিশ ব্ল্যাকফেস প্রতিপালক (সারোগেট) মায়ের জরায়ুতে স্থাপন করা হয়।' },
    { t: 'ডলির জন্ম', en: 'Dolly, 1996', d: 'জন্মানো ভেড়ার মুখ সাদা — অর্থাৎ সে নিউক্লিয়াসদাতা ফিন ডরসেটেরই প্রতিরূপ, ডিম্বাণুদাতা বা প্রতিপালক মায়ের নয়। ২৭৭টি মিলিত কোষ থেকে মাত্র একটি জীবিত শাবক — সাফল্যের হার খুব কম। মাইটোকন্ড্রিয়ার DNA এসেছে ডিম্বাণুদাতার কাছ থেকে, তাই ক্লোন শতভাগ অভিন্ন নয়। ডলি ছয়টি স্বাভাবিক শাবকের জন্ম দেয় এবং ফুসফুসের রোগে ৬ বছর বয়সে (2003) মারা যায়।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Rn = BK.ramp(6), Rc = BK.ramp(5), Re = BK.ramp(4);
    ewe(g, C, 58, 48, .72, 'w', 'ফিন ডরসেট (দাতা)'); ewe(g, C, 296, 48, .72, 'b', 'ব্ল্যাকফেস (ডিম্বাণু)');
    if (s === 0) { const x = 58 + 52 * k, y = 126 + 18 * k; arrow(g, 62, 84, x - 8, y - 24, C.mu, { dash: '3 3' }); cellN(g, C, x, y, 20, Rc, { ni: 6 }); T(g, 180, 150, 'স্তনগ্রন্থির কোষ — G0 দশায় আনা', { fs: 10, a: 'middle', w: 600, c: Rn.ink }); T(g, 180, 170, 'নিউক্লিয়াসে দাতার সম্পূর্ণ জিন', { fs: 9.4, a: 'middle', c: C.mu }); return; }
    if (s === 1) { arrow(g, 292, 84, 250, 118, C.mu, { dash: '3 3' }); cellN(g, C, 236, 140, 26, Rc, { ni: 9, nr: 9, nx: 10 * (1 - k) + 26 * k, ny: -14 * k, nuc: k < .98 }); pipette(g, 300 + 20 * k, 96 + 10 * k, 2.4, Re, 46); T(g, 180, 196, 'ডিম্বাণুর নিউক্লিয়াস সরিয়ে ফেলা হলো', { fs: 10, a: 'middle', w: 600, c: Re.ink }); T(g, 180, 214, 'থাকল সাইটোপ্লাজম ও মাইটোকন্ড্রিয়া', { fs: 9.2, a: 'middle', c: C.mu }); return; }
    if (s === 2) { const gap = 46 * (1 - k); cellN(g, C, 150 + gap * .5, 140, 18, Rc, { ni: 6, nr: 7 }); cellN(g, C, 214 - gap * .5, 140, 26, Rc, { nuc: false }); if (k > .35) for (let i = 0; i < 5; i++) { const a = i / 5 * 2 * Math.PI + k * 6; E('path', { d: `M${182 + Math.cos(a) * 34} ${140 + Math.sin(a) * 26}l4 4`, stroke: BK.ramp(2).c, 'stroke-width': 2, 'stroke-linecap': 'round', opacity: 1 - k * .5 }, g); } T(g, 180, 196, 'বৈদ্যুতিক স্পন্দনে দুই কোষ এক হলো', { fs: 10, a: 'middle', w: 600, c: BK.ramp(2).ink }); T(g, 180, 214, 'নিউক্লিয়াস দাতার, সাইটোপ্লাজম ডিম্বাণুর', { fs: 9.2, a: 'middle', c: C.mu }); return; }
    if (s === 3) { const n = 1 + Math.floor(k * 4), m = Math.min(2 ** n, 16); for (let i = 0; i < m; i++) { const a = i / m * 2 * Math.PI, r = m === 1 ? 0 : 22 - m * .5; cellN(g, C, 150 + Math.cos(a) * r, 128 + Math.sin(a) * r, Math.max(6, 22 - m), Rc, { ni: 6, nr: 4 }); } womb(g, C, 266, 156, .95, BK.ramp(4)); T(g, 262, 196, 'প্রতিপালক মা', { fs: 9.4, a: 'middle', c: C.fg }); arrow(g, 182, 128, 232, 150, C.mu, { dash: '3 3' }); if (k > .6) cellN(g, C, 258, 168, 7, Rc, { ni: 6, nr: 3 }); T(g, 180, 222, 'ভ্রূণ জরায়ুতে স্থাপন', { fs: 10, a: 'middle', w: 600, c: C.fg }); return; }
    ewe(g, C, 150, 158, .78 + .1 * k, 'w', 'ডলি — সাদা মুখ'); E('circle', { cx: 150, cy: 158, r: 44 + 10 * k, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2, opacity: 1 - k * .7 }, g);
    T(g, 180, 212, 'নিউক্লিয়াসদাতার হুবহু প্রতিরূপ — ট্রান্সজেনিক নয়', { fs: 9.6, a: 'middle', w: 600, c: BK.ramp(6).ink });
  }
}));

/* ═════════ ৫. ট্রান্সজেনিক প্রাণী ═════════ */
const TRA = [
  ['ট্রান্সজেনিক ইঁদুর', 4, 'রোগের মডেল — ক্যান্সার, আলঝেইমার ও স্থূলতার গবেষণায়; 1982 এ ইঁদুরে ইঁদুরের গ্রোথ হরমোন জিন বসিয়ে প্রায় দ্বিগুণ আকারের "সুপার মাউস" (পালমিটার ও ব্রিনস্টার) — প্রথম উল্লেখযোগ্য ট্রান্সজেনিক স্তন্যপায়ী।'],
  ['ট্রান্সজেনিক ভেড়া — পলি', 10, 'মানুষের রক্ত জমাট বাঁধার প্রোটিন ফ্যাক্টর IX এর জিন বসানো ভেড়া (রোজলিন, 1997) — দুধে ওষুধ-প্রোটিন তৈরি হয়। দুধ থেকে ওষুধ পাওয়ার এ কৌশলকে বলে ফার্মিং (pharming)।'],
  ['AquAdvantage স্যামন', 5, 'চিনুক স্যামনের গ্রোথ হরমোন জিন ও আরেক মাছের প্রোমোটার বসিয়ে সারা বছর দ্রুত বর্ধনশীল আটলান্টিক স্যামন — যুক্তরাষ্ট্রে 2015 এ অনুমোদিত প্রথম GM প্রাণী-খাদ্য।'],
  ['ট্রান্সজেনিক গরু', 6, 'দুধে মানুষের ল্যাকটোফেরিন বা অ্যালবুমিনের মতো প্রোটিন; দুধের গুণমান পরিবর্তন ও রোগ প্রতিরোধী জাত তৈরির গবেষণা।'],
  ['ট্রান্সজেনিক ছাগল', 2, 'দুধে অ্যান্টিথ্রম্বিন প্রোটিন — ATryn নামে 2006 (ইউরোপ) ও 2009 (যুক্তরাষ্ট্র) এ অনুমোদিত, ট্রান্সজেনিক প্রাণীর দুধ থেকে পাওয়া প্রথম ওষুধ।'],
  ['GloFish', 0, 'জেলিফিশ ও প্রবালের প্রতিপ্রভ (ফ্লুরোসেন্ট) প্রোটিনের জিন বসানো জেব্রা মাছ — প্রথমে পানিদূষণ শনাক্তকরণের জন্য তৈরি, পরে শৌখিন অ্যাকোয়ারিয়ামে।']
];
V.transAnimal = Object.assign({}, B.seg({
  id: 'tra', t: 'ট্রান্সজেনিক প্রাণী', H: 258, def: 'make', sel: null,
  cap: 'ট্রান্সজেনিক প্রাণী — রিকম্বিনেন্ট DNA প্রযুক্তিতে যার জিনোমে অন্য জীবের (বা পরিবর্তিত) জিন ইচ্ছাকৃতভাবে ঢুকিয়ে দেওয়া হয়েছে এবং যা সে জিন পরবর্তী বংশে দিতে পারে। প্রধান কৌশল — নিষিক্ত ডিম্বাণুর পুংনিউক্লিয়াসে সূক্ষ্ম সুচে জিন ঢোকানো (মাইক্রোইনজেকশন); অন্য কৌশল ভাইরাস-বাহক, ভ্রূণীয় স্টেম কোষ ও জিন-সম্পাদনা।',
  types: {
    make: ['তৈরির ধাপ', 'মাইক্রোইনজেকশনে ট্রান্সজেনিক প্রাণী', 'ধাপ: কাঙ্ক্ষিত জিন আলাদা করা → নিষিক্ত ডিম্বাণুর পুংনিউক্লিয়াসে ইনজেকশন → প্রতিপালক মায়ের জরায়ুতে স্থাপন → জন্মানো শাবকের DNA পরীক্ষা করে ট্রান্সজেনিক বাছাই → বংশবৃদ্ধি।'],
    use: ['উদাহরণ ও ব্যবহার', 'উল্লেখযোগ্য ট্রান্সজেনিক প্রাণী', 'কার্ডে চাপ দাও।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'use') {
      TRA.forEach(([s, ri], i) => { const c = i % 2, r = Math.floor(i / 2), x = 10 + c * 172, y = 16 + r * 78, R = BK.ramp(ri), on = ctx.sel === i; E('rect', { x, y, width: 166, height: 70, rx: 10, fill: FK.alpha(R.c, on ? .22 : .07), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); T(g, x + 83, y + 22, s, { fs: s.length > 18 ? 9.4 : 10.4, a: 'middle', w: 700, c: R.ink }); const w = TRA[i][2].split(' ').slice(0, 7).join(' '); T(g, x + 83, y + 44, w.length > 34 ? w.slice(0, 34) : w, { fs: 8.6, a: 'middle', c: C.fg }); T(g, x + 83, y + 60, 'বিস্তারিত দেখতে চাপ দাও', { fs: 8.2, a: 'middle', c: C.mu }); });
      ctx.H = TRA.map((_, i) => [10 + (i % 2) * 172 + 83, 16 + Math.floor(i / 2) * 78 + 35, i]); return;
    }
    const st = ['কাঙ্ক্ষিত জিন', 'নিষিক্ত ডিম্বাণুতে ইনজেকশন', 'প্রতিপালক মায়ের জরায়ুতে', 'শাবকের DNA পরীক্ষা', 'ট্রান্সজেনিক বংশ'];
    st.forEach((s, i) => { const y = 24 + i * 46, R = BK.ramp([6, 3, 4, 1, 10][i]); node(g, 92, y, s, R, 168, 26, { fs: 9.6 }); if (i < 4) { E('path', { d: `M92 ${y + 13}v20`, stroke: C.mu, 'stroke-width': 1.4 }, g); E('path', { d: `M92 ${y + 35}l-4 -6h8z`, fill: C.mu }, g); } });
    cellN(g, C, 258, 70, 26, BK.ramp(5), { ni: 3, nr: 9 });
    T(g, 258, 110, 'নিষিক্ত ডিম্বাণু', { fs: 9, a: 'middle', c: C.mu });
    window.B11W(g, C, 258, 168, .95, BK.ramp(4));
    T(g, 258, 212, 'প্রতিপালক মা', { fs: 9, a: 'middle', c: C.mu });
    T(g, 180, 248, 'জিন পরবর্তী বংশে যায় — তাই ট্রান্সজেনিক লাইন তৈরি হয়', { fs: 9.2, a: 'middle', c: C.fg });
    ctx.H = null;
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    if (ty === 'use') { const i = Math.floor(t * .4) % TRA.length, x = 10 + (i % 2) * 172 + 83, y = 16 + Math.floor(i / 2) * 78 + 35, k = (t * .4) % 1; E('rect', { x: x - 83, y: y - 19, width: 166, height: 70, rx: 10, fill: 'none', stroke: BK.ramp(TRA[i][1]).c, 'stroke-width': 1.6, opacity: 1 - k }, g); return; }
    const u = (t * .35) % 1, Re = BK.ramp(6);
    pipette(g, 300 - 30 * cl(u * 2), 36 + 18 * cl(u * 2), 2.5, BK.ramp(4), 44);
    if (u > .4) { const k = (u - .4) / .6; E('circle', { cx: 258 - 10 + 10 * k, cy: 70 - 6 + 6 * k, r: 3.4, fill: Re.c, stroke: Re.dk, 'stroke-width': .7 }, g); }
    const i = Math.floor((t * .5) % 5), y = 24 + i * 46; E('rect', { x: 6, y: y - 15, width: 172, height: 30, rx: 9, fill: 'none', stroke: BK.ramp([6, 3, 4, 1, 10][i]).c, 'stroke-width': 1.6, opacity: .7 }, g);
  },
  tap(x, y, ty, ctx) { if (ty !== 'use') return null; const h = hot(ctx.H || [], x, y, 90); if (!h) return null; ctx.sel = h[2]; const d = TRA[h[2]]; return `<b>${d[0]}</b> — ${d[2]}`; }
}));
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11, XB = window.B11X;
const cl = B.cl, rnd = B.rnd, node = B.node, hot = B.hot, cmp = XB.cmp, arrow = XB.arrow;
const larva = (g, x, y, s, R, sick = 0) => {
  const dk = sick > .5 ? BK.ramp(9).dk : R.dk, c = sick > .5 ? BK.ramp(9).c : R.c;
  for (let i = 0; i < 7; i++) { const dx = i * 11 * s, dy = Math.sin(i * .9 + sick * 2) * 3 * s * (1 - sick * .6); E('circle', { cx: x + dx, cy: y + dy, r: (7 - i * .35) * s, fill: FK.alpha(c, .75), stroke: dk, 'stroke-width': .9 }, g); }
  E('circle', { cx: x - 2 * s, cy: y + 1 * s, r: 1.4 * s, fill: dk }, g);
};

/* ═════════ ৬. Bt প্রোটিন যেভাবে কাজ করে ═════════ */
V.btAction = Object.assign({ t: 'Bt (Cry) প্রোটিন কীভাবে পোকা মারে', k: ['anim', 'steps'], cap: 'Bacillus thuringiensis (Bt) মাটির একটি গ্রাম-পজিটিভ ব্যাকটেরিয়া, যা স্পোর তৈরির সময় কোষের ভেতরে প্যারাস্পোরাল স্ফটিক (ক্রিস্টাল বা Cry) প্রোটিন জমা করে। এ প্রোটিন কেবল নির্দিষ্ট কয়েকটি বর্গের পোকার লার্ভার জন্য বিষাক্ত — cry1 শ্রেণি Lepidoptera (প্রজাপতি-মথের শুঁয়োপোকা), cry3 শ্রেণি Coleoptera (গুবরে পোকা)। cry জিন উদ্ভিদে বসালে উদ্ভিদ নিজেই এ প্রোটিন তৈরি করে, ফলে কীটনাশক স্প্রে অনেক কমে।' }, BK.steps({
  W: 360, H: 240, label: 'Bt প্রোটিনের কাজ', dur: 3,
  stages: [
    { t: 'স্ফটিক প্রোটিন (প্রোটক্সিন)', en: 'Cry protoxin', d: 'Bt ব্যাকটেরিয়া বা Bt উদ্ভিদে তৈরি Cry প্রোটিন নিষ্ক্রিয় অবস্থায় থাকে — একে প্রোটক্সিন বলে (cry1Ac এর ক্ষেত্রে প্রায় 130 kDa)। এ অবস্থায় এটি কোনো ক্ষতি করে না।' },
    { t: 'লার্ভা পাতা খায়', en: 'Ingestion', d: 'শুঁয়োপোকা বা ছিদ্রকারী লার্ভা Bt উদ্ভিদের পাতা, ডগা বা ফল খেলে প্রোটক্সিন তার পৌষ্টিকনালিতে পৌঁছায়। Bt প্রোটিন স্পর্শে কাজ করে না — খেতেই হয়।' },
    { t: 'ক্ষারীয় মধ্য-অন্ত্রে সক্রিয়', en: 'Activation', d: 'লেপিডপটেরা লার্ভার মধ্য-অন্ত্র প্রবল ক্ষারীয় (pH প্রায় 9.5–12)। সেখানে স্ফটিক গলে যায় এবং অন্ত্রের প্রোটিয়েজ এনজাইম প্রোটক্সিন কেটে ছোট সক্রিয় টক্সিন (প্রায় 60–65 kDa) বানায়।' },
    { t: 'অন্ত্রের রিসেপ্টরে যুক্ত', en: 'Receptor binding', d: 'সক্রিয় টক্সিন মধ্য-অন্ত্রের এপিথেলিয়াল কোষের ঝিল্লির নির্দিষ্ট রিসেপ্টরে (ক্যাডহেরিন, অ্যামাইনোপেপটাইডেজ-N) বাঁধে। এ রিসেপ্টর কেবল নির্দিষ্ট পোকার থাকে — এজন্যই Bt নির্দিষ্ট লক্ষ্যভিত্তিক।' },
    { t: 'ঝিল্লিতে ছিদ্র ও মৃত্যু', en: 'Pore formation', d: 'কয়েকটি টক্সিন অণু একসাথে ঝিল্লিতে ছিদ্র তৈরি করে; আয়ন ও পানির ভারসাম্য নষ্ট হয়ে কোষ ফুলে ফেটে যায়। লার্ভা কয়েক ঘণ্টার মধ্যেই খাওয়া বন্ধ করে এবং ১–৩ দিনে মারা যায়। মানুষ ও গবাদি পশুর পাকস্থলী অম্লীয় এবং এ রিসেপ্টর নেই, তাই Cry প্রোটিন হজম হয়ে যায় — ক্ষতি করে না।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Rc = BK.ramp(4), Rl = BK.ramp(10), Rg = BK.ramp(0);
    if (s === 0) {
      B.bac(g, C, 170, 90, 170, 70, { plas: 0 });
      E('path', { d: 'M196 72l26 -10l10 26l-26 10z', fill: FK.alpha(Rc.c, .7), stroke: Rc.dk, 'stroke-width': 1.3 }, g);
      E('ellipse', { cx: 126, cy: 90, rx: 20, ry: 13, fill: FK.alpha(BK.ramp(9).c, .35), stroke: BK.ramp(9).dk, 'stroke-width': 1.1 }, g);
      T(g, 126, 124, 'স্পোর', { fs: 9.4, a: 'middle', c: C.mu }); T(g, 214, 124, 'Cry স্ফটিক', { fs: 9.4, a: 'middle', w: 600, c: Rc.ink });
      T(g, 180, 160, 'Bacillus thuringiensis — স্পোরের সাথে স্ফটিক প্রোটিন', { fs: 10, a: 'middle', w: 600, c: C.fg });
      T(g, 180, 182, 'Bt উদ্ভিদে cry জিন থেকে একই প্রোটিন তৈরি হয়', { fs: 9.4, a: 'middle', c: C.mu });
      for (let i = 0; i < 4; i++) { const a = k * 4 + i * 1.6; E('path', { d: `M${232 + Math.cos(a) * 16} ${70 + Math.sin(a) * 10}l6 -3l3 6l-6 3z`, fill: FK.alpha(Rc.c, .5), stroke: Rc.dk, 'stroke-width': .7 }, g); }
      return;
    }
    if (s === 1) {
      XB.sprout(g, 300, 200, 110, 0, { ri: 10, mid: 1, sw: 3 });
      larva(g, 80 + 130 * k, 150, 1.1, BK.ramp(6));
      for (let i = 0; i < 5; i++) E('path', { d: `M${250 + i * 8} ${120 + i * 6}l5 -2l2 5l-5 2z`, fill: FK.alpha(Rc.c, .6), stroke: Rc.dk, 'stroke-width': .6 }, g);
      T(g, 180, 206, 'লার্ভা Bt পাতা খায় — প্রোটিন পেটে যায়', { fs: 10, a: 'middle', w: 600, c: C.fg });
      return;
    }
    if (s === 2) {
      larva(g, 40, 70, 1.3, BK.ramp(6));
      E('rect', { x: 40, y: 120, width: 280, height: 56, rx: 16, fill: FK.alpha(Rg.c, .14), stroke: Rg.dk, 'stroke-width': 1.3 }, g);
      T(g, 180, 112, 'মধ্য-অন্ত্র — pH 9.5 থেকে 12 (ক্ষারীয়)', { fs: 9.6, a: 'middle', w: 600, c: Rg.ink });
      for (let i = 0; i < 4; i++) {
        const x = 70 + i * 66, br = cl(k * 1.4 - i * .12);
        if (br < .5) E('path', { d: `M${x} ${140}l14 -6l6 14l-14 6z`, fill: FK.alpha(Rc.c, .7), stroke: Rc.dk, 'stroke-width': 1.1 }, g);
        else { [-1, 1].forEach(sd => E('ellipse', { cx: x + 7 + sd * 10 * (br - .5) * 2, cy: 147, rx: 6, ry: 4.6, fill: FK.alpha(Rc.c, .85), stroke: Rc.dk, 'stroke-width': 1 }, g)); }
      }
      T(g, 180, 198, 'স্ফটিক গলে প্রোটিয়েজ কেটে সক্রিয় টক্সিন বানায়', { fs: 10, a: 'middle', w: 600, c: Rc.ink });
      T(g, 180, 218, '130 kDa প্রোটক্সিন → প্রায় 60 kDa সক্রিয় টক্সিন', { fs: 9.2, a: 'middle', c: C.mu });
      return;
    }
    const yw = 150;
    E('path', { d: `M20 ${yw}H340`, stroke: Rg.dk, 'stroke-width': 2 }, g);
    for (let i = 0; i < 5; i++) { const x = 44 + i * 68; E('rect', { x: x - 26, y: yw, width: 52, height: 54, rx: 5, fill: FK.alpha(Rg.c, .16), stroke: Rg.dk, 'stroke-width': 1 }, g); E('circle', { cx: x, cy: yw + 30, r: 7, fill: FK.alpha(BK.ramp(3).c, .4), stroke: BK.ramp(3).dk, 'stroke-width': .8 }, g); E('path', { d: `M${x - 7} ${yw}v-9h14v9`, stroke: BK.ramp(2).dk, 'stroke-width': 2, fill: 'none' }, g); }
    T(g, 180, 128, 'মধ্য-অন্ত্রের এপিথেলিয়াল কোষ ও রিসেপ্টর', { fs: 9.6, a: 'middle', w: 600, c: C.fg });
    if (s === 3) {
      for (let i = 0; i < 5; i++) { const x = 44 + i * 68, d = cl(k * 1.3 - i * .08), y = 50 + (yw - 62) * d; [-1, 1].forEach(sd => E('ellipse', { cx: x + sd * 5, cy: y, rx: 6, ry: 4.6, fill: FK.alpha(Rc.c, .85), stroke: Rc.dk, 'stroke-width': 1 }, g)); }
      T(g, 180, 222, 'টক্সিন নির্দিষ্ট রিসেপ্টরে বাঁধে — তাই লক্ষ্যভিত্তিক', { fs: 10, a: 'middle', w: 600, c: Rc.ink });
      return;
    }
    for (let i = 0; i < 5; i++) { const x = 44 + i * 68; E('path', { d: `M${x - 7} ${yw - 2}v-6M${x + 7} ${yw - 2}v-6`, stroke: Rc.dk, 'stroke-width': 2.6 }, g); E('rect', { x: x - 26, y: yw, width: 52, height: 54, rx: 5, fill: FK.alpha(Rc.c, .1 + .22 * k), stroke: Rc.dk, 'stroke-width': 1 }, g); E('circle', { cx: x, cy: yw + 30, r: 7 + 5 * k, fill: FK.alpha(BK.ramp(3).c, .4 - .2 * k), stroke: BK.ramp(3).dk, 'stroke-width': .8, opacity: 1 - k * .6 }, g); for (let q = 0; q < 3; q++) { const a = q * 2.1 + k * 4; E('circle', { cx: x + Math.cos(a) * 16 * k, cy: yw + 26 + Math.sin(a) * 14 * k, r: 2, fill: BK.ramp(5).c, opacity: k }, g); } }
    larva(g, 240, 52, 1.1, BK.ramp(6), k);
    T(g, 180, 222, 'ছিদ্র → কোষ ফেটে যায় → লার্ভা খাওয়া বন্ধ করে মারা যায়', { fs: 9.6, a: 'middle', w: 600, c: Rc.ink });
  }
}));

/* ═════════ ৭. বাংলাদেশে GM ফসল ═════════ */
const BDG = [
  [2013, 'Bt বেগুন অনুমোদন', 6, '30 অক্টোবর 2013 — জাতীয় জীবনিরাপত্তা কমিটি (NCB) চারটি Bt বেগুনের জাত অনুমোদন করে: BARI Bt বেগুন-১ (উত্তরা), -২ (কাজলা), -৩ (নয়নতারা) ও -৪ (ঈশ্বরদী স্থানীয়, ISD006)। এটি দক্ষিণ এশিয়ার প্রথম অনুমোদিত GM খাদ্য ফসল।'],
  [2014, 'প্রথম মাঠে চাষ', 10, '22 জানুয়ারি 2014 — গাজীপুর, জামালপুর, পাবনা ও রংপুর — এ চার জেলার ২০ জন কৃষককে চারা দেওয়া হয়। পরের বছরগুলোতে প্রদর্শনী প্লট ও কৃষকের সংখ্যা দ্রুত বাড়ে।'],
  [2018, 'সম্প্রসারণ', 5, 'বাংলাদেশ কৃষি উন্নয়ন কর্পোরেশনের (BADC) মাধ্যমে প্রায় ১৮ হাজার কৃষকের কাছে বীজ পৌঁছায়; বেগুন চাষিদের উল্লেখযোগ্য অংশ Bt বেগুন চাষে আসে।'],
  [2019, 'প্রভাব সমীক্ষা', 1, '১২০০ কৃষকের ওপর IFPRI এর সমীক্ষায় ডগা ও ফল ছিদ্রকারী পোকার আক্রমণ প্রায় ৯৫% কম, কীটনাশকের পরিবেশগত বিষাক্ততা প্রায় ৫৬% কম এবং কীটনাশক ব্যবহারজনিত শারীরিক উপসর্গ কম পাওয়া যায়।'],
  [2023, 'Bt তুলা', 2, 'মে 2023 এ দুটি Bt তুলার জাত (JKCH 1947 Bt ও JKCH 1050 Bt) অনুমোদিত হয় এবং আগস্ট 2023 এ অবমুক্ত করা হয় — বাংলাদেশের দ্বিতীয় অনুমোদিত GM ফসল।'],
  [0, 'পাইপলাইনে', 9, 'গোল্ডেন রাইস (BRRI ধান২৯ ভিত্তিক, ভিটামিন A), নাবি ধসা প্রতিরোধী আলু, লবণ ও বন্যাসহিষ্ণু ধান এবং Bt তুলার দেশীয় জাত — গবেষণা ও জীবনিরাপত্তা পর্যালোচনার পর্যায়ে।']
];
const INST = [['BARI', 10, 'বাংলাদেশ কৃষি গবেষণা ইনস্টিটিউট, গাজীপুর — Bt বেগুন, আলু, টমেটো, পেঁপে ও কলার জীবপ্রযুক্তি গবেষণা।'], ['BRRI', 6, 'বাংলাদেশ ধান গবেষণা ইনস্টিটিউট — গোল্ডেন রাইস, লবণ ও বন্যাসহিষ্ণু ধানের জিন গবেষণা।'], ['BINA', 5, 'বাংলাদেশ পরমাণু কৃষি গবেষণা ইনস্টিটিউট, ময়মনসিংহ — মিউটেশন ব্রিডিং ও টিস্যু কালচার।'], ['BSMRAU ও বিশ্ববিদ্যালয়', 3, 'বঙ্গবন্ধু শেখ মুজিবুর রহমান কৃষি বিশ্ববিদ্যালয়, ঢাকা ও রাজশাহী বিশ্ববিদ্যালয়সহ নানা প্রতিষ্ঠানে টিস্যু কালচার ও আণবিক জীববিজ্ঞান গবেষণা।'], ['BJRI', 2, 'বাংলাদেশ পাট গবেষণা ইনস্টিটিউট — মাকসুদুল আলমের নেতৃত্বে পাটের জিনোম (2010) ও পাটের ছত্রাক Macrophomina phaseolina এর জিনোম (2012) উন্মোচন।']];
V.bdGM = Object.assign({}, B.seg({
  id: 'bdg', t: 'বাংলাদেশে GM ফসল ও জীবপ্রযুক্তি', H: 262, def: 'tl', sel: null,
  cap: 'বাংলাদেশে GM ফসলের অনুমোদন দেয় পরিবেশ অধিদপ্তরের অধীন জাতীয় জীবনিরাপত্তা কমিটি (National Committee on Biosafety), জীবনিরাপত্তা বিধিমালা ২০১২ অনুযায়ী। গবেষণা চলে BARI, BRRI, BINA ও বিশ্ববিদ্যালয়গুলোতে। সময়রেখা বা প্রতিষ্ঠানের নামে চাপ দাও।',
  types: {
    tl: ['সময়রেখা', 'বাংলাদেশে GM ফসলের ধাপ', 'Bt বেগুন (2013) দক্ষিণ এশিয়ার প্রথম GM খাদ্য ফসল; Bt তুলা (2023) দ্বিতীয় অনুমোদিত GM ফসল।'],
    ins: ['প্রতিষ্ঠান', 'গবেষণা প্রতিষ্ঠান ও অবদান', 'প্রতিটি নামে চাপ দিয়ে কাজ দেখো।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'ins') {
      INST.forEach(([s, ri], i) => { const y = 20 + i * 48, R = BK.ramp(ri), on = ctx.sel === i; E('rect', { x: 10, y, width: 340, height: 40, rx: 10, fill: FK.alpha(R.c, on ? .22 : .07), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); T(g, 24, y + 25, s, { fs: 11.5, w: 700, c: R.ink }); const d = INST[i][2]; T(g, 158, y + 25, d.split(' — ')[0].slice(0, 32), { fs: 9, c: C.mu }); });
      ctx.H = INST.map((_, i) => [180, 40 + i * 48, i]); return;
    }
    BDG.forEach(([yr, s, ri], i) => {
      const y = 22 + i * 40, R = BK.ramp(ri), on = ctx.sel === i;
      E('path', { d: 'M52 14V250', stroke: C.ln, 'stroke-width': 2 }, g);
      E('circle', { cx: 52, cy: y, r: on ? 7 : 5, fill: R.c, stroke: C.sf, 'stroke-width': 1.6 }, g);
      T(g, 42, y + 4, yr ? String(yr) : 'এখন', { fs: 9.6, a: 'end', w: 700, c: R.ink });
      E('rect', { x: 66, y: y - 15, width: 286, height: 30, rx: 8, fill: FK.alpha(R.c, on ? .22 : .08), stroke: on ? R.dk : 'none', 'stroke-width': 1.6 }, g);
      T(g, 78, y + 4, s, { fs: 10.4, w: on ? 700 : 600, c: C.fg });
    });
    ctx.H = BDG.map((_, i) => [200, 22 + i * 40, i]);
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    if (ty === 'ins') { const i = Math.floor(t * .4) % INST.length, k = (t * .4) % 1; E('rect', { x: 10, y: 20 + i * 48, width: 340, height: 40, rx: 10, fill: 'none', stroke: BK.ramp(INST[i][1]).c, 'stroke-width': 1.6, opacity: 1 - k }, g); return; }
    const u = (t * .16) % 1; E('circle', { cx: 52, cy: 22 + u * 200, r: 4, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2 }, g);
  },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, ty === 'ins' ? 170 : 150); if (!h) return null; ctx.sel = h[2]; if (ty === 'ins') { const d = INST[h[2]]; return `<b>${d[0]}</b> — ${d[2]}`; } const d = BDG[h[2]]; return `<b>${d[0] ? d[0] + ' — ' : ''}${d[1]}</b><div class="small">${d[3]}</div>`; }
}));

/* ═════════ তুলনা ═════════ */
V.cmpTransClone = cmp('ট্রান্সজেনিক প্রাণী বনাম ক্লোন প্রাণী', 'দুটিই জীবপ্রযুক্তিতে তৈরি, কিন্তু একটিতে নতুন জিন যোগ হয়, অন্যটিতে হয় না।', 'ট্রান্সজেনিক প্রাণী', 'ক্লোন প্রাণী', [
  ['সংজ্ঞা', 'যার জিনোমে অন্য জীবের জিন ঢোকানো হয়েছে', 'যা একটি প্রাণীর দেহকোষের নিউক্লিয়াস থেকে তৈরি অভিন্ন প্রতিরূপ'],
  ['নতুন জিন', 'যুক্ত হয় — নতুন বৈশিষ্ট্য আসে', 'যুক্ত হয় না — জিন দাতারই'],
  ['মূল কৌশল', 'মাইক্রোইনজেকশন, ভাইরাস-বাহক, ভ্রূণীয় স্টেম কোষ', 'দেহকোষ নিউক্লিয়াস স্থানান্তর (SCNT)'],
  ['জিনগত পরিচয়', 'দাতা ও গ্রহীতা উভয়ের জিন — নতুন সমন্বয়', 'নিউক্লিয়াসদাতার হুবহু (মাইটোকন্ড্রিয়া ডিম্বাণুর)'],
  ['উদ্দেশ্য', 'নতুন বৈশিষ্ট্য বা ওষুধ-প্রোটিন উৎপাদন', 'উন্নত বা দুর্লভ প্রাণীর হুবহু বংশবৃদ্ধি'],
  ['উদাহরণ', 'সুপার মাউস (1982), পলি ভেড়া (1997), AquAdvantage স্যামন', 'ডলি ভেড়া (1996), ক্লোন করা গরু ও বিড়াল'],
  ['প্রজন্মে স্থানান্তর', 'নতুন জিন পরবর্তী বংশে যায়', 'নতুন কিছু যাওয়ার নেই']
]);
V.cmpGmConv = cmp('GM ফসল বনাম প্রচলিত প্রজনন', 'দুটিতেই উন্নত জাত আসে, তবে জিন বদলানোর পথ আলাদা।', 'GM (ট্রান্সজেনিক) ফসল', 'প্রচলিত সংকরায়ণ', [
  ['জিনের উৎস', 'যেকোনো জীব — ব্যাকটেরিয়া, ভাইরাস, অন্য উদ্ভিদ', 'একই বা কাছের প্রজাতি (প্রজননে মিলনযোগ্য)'],
  ['জিনের সংখ্যা', 'এক বা কয়েকটি নির্দিষ্ট জিন', 'হাজার হাজার জিন একসাথে মিশে যায়'],
  ['সময়', 'তুলনামূলক কম — ৫ থেকে ১০ বছর', 'বেশি — ১০ থেকে ১৫ বছর বা তারও বেশি'],
  ['নির্ভুলতা', 'নির্দিষ্ট বৈশিষ্ট্য যোগ, অন্য বৈশিষ্ট্য অক্ষত', 'অবাঞ্ছিত বৈশিষ্ট্যও সাথে আসে, পরে বাদ দিতে হয়'],
  ['নিয়ন্ত্রণ', 'জীবনিরাপত্তা বিধি ও কমিটির অনুমোদন লাগে', 'সাধারণত বিশেষ অনুমোদন লাগে না'],
  ['জনমত', 'নিরাপত্তা ও পরিবেশ নিয়ে বিতর্ক রয়েছে', 'ব্যাপকভাবে গৃহীত'],
  ['উদাহরণ', 'Bt বেগুন, গোল্ডেন রাইস', 'ইরি ধান, হাইব্রিড ভুট্টা ও সবজি']
]);
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11, XB = window.B11X;
const cl = B.cl, rnd = B.rnd, node = B.node, hot = B.hot, cmp = XB.cmp, arrow = XB.arrow, cellN = XB.cellN;
/* অ্যামিনো অ্যাসিডের শিকল — n টি গুটি, বাঁকা পথে */
const chainP = (g, x0, y0, n, R, o = {}) => {
  const amp = o.amp || 10, dx = o.dx || 8, pts = [];
  for (let i = 0; i < n; i++) { const x = x0 + i * dx, y = y0 + Math.sin(i * (o.f || .8)) * amp; pts.push([x, y]); }
  E('path', { d: pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(''), stroke: R.dk, 'stroke-width': o.sw || 2, fill: 'none', 'stroke-linecap': 'round', opacity: o.op != null ? o.op : 1 }, g);
  pts.forEach(([x, y], i) => { if (o.every && i % o.every) return; E('circle', { cx: x, cy: y, r: o.r || 3, fill: R.c, stroke: R.dk, 'stroke-width': .6, opacity: o.op != null ? o.op : 1 }, g); });
  return pts;
};
const ssBond = (g, a, b, c) => { E('path', { d: `M${a[0]} ${a[1]}L${b[0]} ${b[1]}`, stroke: c, 'stroke-width': 1.6, 'stroke-dasharray': '3 2' }, g); };

/* ═════════ ৮. ইনসুলিন উৎপাদন ═════════ */
V.insulinMake = Object.assign({}, B.seg({
  id: 'ins', t: 'জিন প্রকৌশলে মানব ইনসুলিন উৎপাদন', H: 268, def: 'two', sel: null,
  cap: 'ইনসুলিন অগ্ন্যাশয়ের আইলেটস অব ল্যাঙ্গারহ্যান্সের বিটা কোষের হরমোন — রক্তের গ্লুকোজ কমায়। এতে দুটি পলিপেপটাইড শিকল: A শিকলে ২১টি ও B শিকলে ৩০টি অ্যামিনো অ্যাসিড; দুটি ডাইসালফাইড (S–S) বন্ধনে যুক্ত, A শিকলের ভেতরে আরও একটি। আগে গরু ও শূকরের অগ্ন্যাশয় থেকে ইনসুলিন নেওয়া হতো — তাতে পরিমাণ কম পড়ত ও অনেকের অ্যালার্জি হতো। 1978 এ জেনেনটেক E. coli তে মানব ইনসুলিন তৈরি করে, 1982 এ এলি লিলি "হিউমুলিন" নামে বাজারে আনে — এটিই প্রথম অনুমোদিত রিকম্বিনেন্ট ওষুধ।',
  types: {
    two: ['দুই শিকল পদ্ধতি', 'A ও B শিকল আলাদা করে তৈরি (মূল পদ্ধতি)', 'A ও B শিকলের জন্য আলাদা কৃত্রিম জিন তৈরি করে আলাদা E. coli তে প্রকাশ করা হয়; পরে শিকল দুটি বিক্রিয়ায় ডাইসালফাইড বন্ধনে জোড়া হয়।'],
    pro: ['প্রোইনসুলিন পদ্ধতি', 'এক জিনে প্রোইনসুলিন, পরে C-পেপটাইড কাটা', 'বর্তমানে বেশি ব্যবহৃত — প্রোইনসুলিনের একটিমাত্র জিন প্রকাশ করে এনজাইমে (ট্রিপসিন ও কার্বক্সিপেপটাইডেজ B) মাঝের C-পেপটাইড কেটে ফেলা হয়; বন্ধন নিজেই সঠিকভাবে তৈরি হয় বলে ফলন বেশি।'],
    mol: ['ইনসুলিনের গঠন', 'A ও B শিকল এবং ডাইসালফাইড বন্ধন', 'A শিকল ২১, B শিকল ৩০ অ্যামিনো অ্যাসিড; দুই শিকলের মধ্যে দুটি ও A শিকলের ভেতরে একটি S–S বন্ধন। মোট ৫১টি অ্যামিনো অ্যাসিড।']
  },
  art(g, C, ty, ctx) {
    const Ra = BK.ramp(6), Rb = BK.ramp(5), Rp = BK.ramp(3), Rc = BK.ramp(0);
    if (ty === 'mol') {
      const a = chainP(g, 92, 84, 21, Ra, { dx: 8.4, amp: 11, f: .72, r: 3.4 });
      const b = chainP(g, 72, 176, 30, Rb, { dx: 7.4, amp: 11, f: .6, r: 3.4 });
      ssBond(g, a[6], b[8], BK.ramp(2).dk); ssBond(g, a[19], b[18], BK.ramp(2).dk);
      E('path', { d: `M${a[5][0]} ${a[5][1]}Q${(a[5][0] + a[10][0]) / 2} ${a[5][1] - 26} ${a[10][0]} ${a[10][1]}`, stroke: BK.ramp(2).dk, 'stroke-width': 1.6, 'stroke-dasharray': '3 2', fill: 'none' }, g);
      T(g, (a[5][0] + a[10][0]) / 2, a[5][1] - 20, 'A শিকলের ভেতরের S–S', { fs: 8.4, a: 'middle', c: BK.ramp(2).ink });
      T(g, 80, 44, 'A শিকল — ২১ অ্যামিনো অ্যাসিড', { fs: 10, w: 650, c: Ra.ink });
      T(g, 60, 212, 'B শিকল — ৩০ অ্যামিনো অ্যাসিড', { fs: 10, w: 650, c: Rb.ink });
      B.chip(g, 290, 128, 'দুই শিকলের S–S', BK.ramp(2), { w: 120, h: 20, fs: 9.4 });
      T(g, 180, 242, 'মোট ৫১টি অ্যামিনো অ্যাসিড; দুই শিকলের মাঝে দুটি ও A শিকলের ভেতরে একটি S–S', { fs: 8.8, a: 'middle', c: C.mu });
      ctx.H = null; return;
    }
    const twoW = ty === 'two';
    const rows = twoW
      ? [['A ও B শিকলের কৃত্রিম জিন তৈরি', 6], ['আলাদা প্লাসমিডে বসিয়ে E. coli তে', 3], ['দুই কালচারে আলাদা শিকল উৎপাদন', 0], ['শিকল পৃথক ও বিশুদ্ধকরণ', 9], ['বিক্রিয়ায় S–S বন্ধনে জোড়া — ইনসুলিন', 2]]
      : [['প্রোইনসুলিনের cDNA তৈরি', 6], ['প্লাসমিডে বসিয়ে E. coli তে', 3], ['কালচারে প্রোইনসুলিন উৎপাদন', 0], ['ট্রিপসিনে C-পেপটাইড কেটে ফেলা', 4], ['বিশুদ্ধ মানব ইনসুলিন', 2]];
    rows.forEach(([s, ri], i) => { const y = 22 + i * 38, R = BK.ramp(ri); node(g, 108, y, s, R, 200, 26, { fs: 9.4 }); if (i < 4) { E('path', { d: `M108 ${y + 13}v12`, stroke: C.mu, 'stroke-width': 1.4 }, g); E('path', { d: `M108 ${y + 27}l-4 -6h8z`, fill: C.mu }, g); } });
    if (twoW) {
      const a = chainP(g, 240, 60, 11, Ra, { dx: 8, amp: 7, f: .9, r: 2.8 }), b = chainP(g, 240, 108, 14, Rb, { dx: 7, amp: 7, f: .8, r: 2.8 });
      T(g, 296, 44, 'A', { fs: 10, a: 'middle', w: 700, c: Ra.ink }); T(g, 296, 128, 'B', { fs: 10, a: 'middle', w: 700, c: Rb.ink });
      const a2 = chainP(g, 240, 182, 11, Ra, { dx: 8, amp: 7, f: .9, r: 2.8 }), b2 = chainP(g, 240, 214, 14, Rb, { dx: 7, amp: 7, f: .8, r: 2.8 });
      ssBond(g, a2[3], b2[3], BK.ramp(2).dk); ssBond(g, a2[9], b2[10], BK.ramp(2).dk);
      T(g, 290, 240, 'মানব ইনসুলিন', { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(2).ink });
      void a; void b;
    } else {
      const p = chainP(g, 232, 76, 16, Rp, { dx: 7.4, amp: 9, f: .7, r: 2.8 });
      T(g, 290, 52, 'প্রোইনসুলিন', { fs: 9.6, a: 'middle', w: 650, c: Rp.ink });
      T(g, 290, 104, 'A + C + B', { fs: 9, a: 'middle', c: C.mu });
      chainP(g, 236, 168, 7, Ra, { dx: 8, amp: 6, f: .9, r: 2.8 }); chainP(g, 236, 200, 9, Rb, { dx: 7, amp: 6, f: .8, r: 2.8 });
      E('path', { d: 'M300 176q12 6 0 12', stroke: BK.ramp(9).dk, 'stroke-width': 1.4, fill: 'none' }, g);
      T(g, 316, 196, 'C বাদ', { fs: 8.8, a: 'middle', c: C.mu });
      T(g, 274, 232, 'মানব ইনসুলিন', { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(2).ink });
      void p;
    }
    ctx.H = null;
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    if (ty === 'mol') { const u = (t * .3) % 1, x = 92 + u * 168; E('circle', { cx: x, cy: 84 + Math.sin((x - 92) / 8.4 * .72) * 11, r: 5, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2 }, g); return; }
    const i = Math.floor((t * .5) % 5), y = 22 + i * 38; E('rect', { x: 6, y: y - 15, width: 204, height: 30, rx: 9, fill: 'none', stroke: BK.ramp(1).c, 'stroke-width': 1.6, opacity: .75 }, g);
    const u = (t * .4) % 1; E('circle', { cx: 232, cy: 150 - 60 * Math.cos(u * Math.PI), r: 3, fill: BK.ramp(6).c, opacity: .8 }, g);
  }
}));

/* ═════════ ৯. ইন্টারফেরনের কাজ ═════════ */
V.ifnAction = Object.assign({ t: 'ইন্টারফেরন — উৎপাদন ও কাজ', k: ['anim', 'steps'], cap: 'ইন্টারফেরন — ভাইরাসে আক্রান্ত বা উদ্দীপ্ত কোষ থেকে নিঃসৃত ছোট গ্লাইকোপ্রোটিন, যা আশেপাশের কোষকে ভাইরাসের বিরুদ্ধে প্রস্তুত করে। আইজ্যাকস ও লিন্ডেনম্যান (1957) আবিষ্কার করেন। তিন শ্রেণি: আলফা (শ্বেতকণিকা), বিটা (ফাইব্রোব্লাস্ট) ও গামা (T লিম্ফোসাইট)। দেহে পরিমাণ অতি সামান্য বলে আগে বিপুল রক্ত থেকে সামান্য ইন্টারফেরন পাওয়া যেত ও দাম ছিল আকাশছোঁয়া; 1980 সালে চার্লস ভাইসমানের দল জিনটি ক্লোন করার পর E. coli ও ইস্টে সস্তায় উৎপাদন সম্ভব হয় (প্রথম অনুমোদন 1986)।' }, BK.steps({
  W: 360, H: 236, label: 'ইন্টারফেরনের ধাপ', dur: 3,
  stages: [
    { t: 'জিন থেকে উৎপাদন', en: 'Production', d: 'মানব শ্বেতকণিকার mRNA থেকে রিভার্স ট্রান্সক্রিপ্টেজে ইন্টারফেরনের cDNA তৈরি করে প্লাসমিডে বসিয়ে E. coli বা ইস্টে প্রকাশ করা হয়; ফার্মেন্টারে প্রচুর পরিমাণে পাওয়া যায়।' },
    { t: 'ভাইরাসে আক্রান্ত কোষ', en: 'Infected cell', d: 'দেহে ভাইরাস ঢুকলে আক্রান্ত কোষ ভাইরাসের দ্বিসূত্রক RNA টের পেয়ে ইন্টারফেরনের জিন সক্রিয় করে এবং ইন্টারফেরন তৈরি করে ছেড়ে দেয়।' },
    { t: 'প্রতিবেশী কোষে সংকেত', en: 'Signalling', d: 'নিঃসৃত ইন্টারফেরন আশেপাশের সুস্থ কোষের পৃষ্ঠের রিসেপ্টরে বাঁধে — অর্থাৎ এটি নিজে ভাইরাস মারে না, বরং প্রতিবেশী কোষকে সতর্ক করে।' },
    { t: 'ভাইরাসরোধী প্রোটিন', en: 'Antiviral state', d: 'সংকেত পেয়ে কোষ ভাইরাসরোধী প্রোটিনের (যেমন প্রোটিন কাইনেজ R, 2-5 অলিগোঅ্যাডেনাইলেট সিনথেটেজ) জিন চালু করে — এরা ভাইরাসের RNA ভেঙে দেয় ও প্রোটিন তৈরি বন্ধ করে।' },
    { t: 'সংক্রমণ থেমে যায়', en: 'Outcome', d: 'প্রস্তুত কোষে ভাইরাস ঢুকলেও বংশবৃদ্ধি করতে পারে না, তাই সংক্রমণ ছড়ানো বন্ধ হয়। ইন্টারফেরন প্রজাতি-নির্দিষ্ট কিন্তু ভাইরাস-নির্দিষ্ট নয় — একই ইন্টারফেরন নানা ভাইরাসের বিরুদ্ধে কাজ করে। ব্যবহার: হেপাটাইটিস B ও C, কিছু লিউকেমিয়া ও মেলানোমা, মাল্টিপল স্ক্লেরোসিস (বিটা)।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Rv = BK.ramp(4), Ri = BK.ramp(2), Rc = BK.ramp(5), Rn = BK.ramp(0);
    if (s === 0) {
      B.bac(g, C, 92, 104, 150, 64, { plas: 2 });
      arrow(g, 172, 104, 212, 104, C.mu);
      B.flask(g, C, 268, 148, .9, { med: 2 });
      for (let i = 0; i < 6; i++) { const a = k * 5 + i; E('circle', { cx: 268 + Math.cos(a) * 20, cy: 120 + Math.sin(a) * 10, r: 3, fill: Ri.c, opacity: .85 }, g); }
      T(g, 92, 158, 'ইন্টারফেরনের cDNA যুক্ত E. coli', { fs: 9.6, a: 'middle', w: 600, c: C.fg });
      T(g, 268, 184, 'ফার্মেন্টারে উৎপাদন', { fs: 9.6, a: 'middle', c: C.fg });
      T(g, 180, 214, 'আগে বিপুল রক্ত থেকে সামান্য মিলত — এখন সস্তায় প্রচুর', { fs: 9.2, a: 'middle', c: C.mu });
      return;
    }
    cellN(g, C, 76, 110, 34, Rc, { ni: 3, nr: 11 });
    [180, 272].forEach(x => cellN(g, C, x, 110, 34, Rn, { ni: 3, nr: 11 }));
    T(g, 76, 164, 'আক্রান্ত কোষ', { fs: 9.4, a: 'middle', c: C.fg }); T(g, 226, 164, 'প্রতিবেশী সুস্থ কোষ', { fs: 9.4, a: 'middle', c: C.fg });
    if (s === 1) { for (let i = 0; i < 5; i++) { const a = i * 1.3 + k * 3; E('path', { d: `M${76 + Math.cos(a) * 16} ${110 + Math.sin(a) * 16}l5 0l0 5l-5 0z`, fill: Rv.c, stroke: Rv.dk, 'stroke-width': .6 }, g); } T(g, 180, 206, 'ভাইরাস ঢুকে কোষকে ইন্টারফেরন তৈরিতে বাধ্য করে', { fs: 9.6, a: 'middle', w: 600, c: Rv.ink }); return; }
    if (s === 2) { for (let i = 0; i < 6; i++) { const q = (k + i * .17) % 1, x = 76 + q * 160, y = 110 - Math.sin(q * Math.PI) * 34; E('circle', { cx: x, cy: y, r: 4, fill: Ri.c, stroke: Ri.dk, 'stroke-width': .7 }, g); } T(g, 180, 206, 'ইন্টারফেরন প্রতিবেশী কোষের রিসেপ্টরে বাঁধে', { fs: 9.6, a: 'middle', w: 600, c: Ri.ink }); return; }
    if (s === 3) { [180, 272].forEach(x => { E('circle', { cx: x, cy: 110, r: 34, fill: 'none', stroke: Ri.c, 'stroke-width': 2 + 2 * k, opacity: .8 }, g); for (let i = 0; i < 4; i++) { const a = i * 1.6 + k * 2; E('path', { d: `M${x + Math.cos(a) * 20} ${110 + Math.sin(a) * 20}h8`, stroke: BK.ramp(10).dk, 'stroke-width': 2, opacity: k }, g); } }); T(g, 180, 206, 'ভাইরাসরোধী প্রোটিন তৈরি — কোষ প্রস্তুত', { fs: 9.6, a: 'middle', w: 600, c: BK.ramp(10).ink }); return; }
    [180, 272].forEach(x => { E('circle', { cx: x, cy: 110, r: 36, fill: 'none', stroke: BK.ramp(10).c, 'stroke-width': 2.4 }, g); const bx = x - 2, by = 110 - 52 + 30 * Math.min(k * 2, 1); E('path', { d: `M${bx} ${by}l5 0l0 5l-5 0z`, fill: Rv.c, stroke: Rv.dk, 'stroke-width': .6 }, g); if (k > .5) XB.nope(g, x, 74, 7, Rv.dk, 2.6); });
    T(g, 180, 206, 'ভাইরাস ঢুকলেও বংশবৃদ্ধি করতে পারে না', { fs: 9.6, a: 'middle', w: 600, c: BK.ramp(10).ink });
  }
}));

/* ═════════ ১০. tPA — জমাট রক্ত গলানো ═════════ */
V.tpaAction = Object.assign({}, B.seg({
  id: 'tpa', t: 'টিস্যু প্লাসমিনোজেন অ্যাক্টিভেটর (tPA)', H: 248, def: 'clot', sel: null,
  cap: 'tPA — রক্তনালির অন্তঃআবরণ (এন্ডোথেলিয়াম) থেকে নিঃসৃত এনজাইম, যা নিষ্ক্রিয় প্লাসমিনোজেনকে সক্রিয় প্লাসমিনে পরিণত করে; প্লাসমিন ফাইব্রিনের জাল ভেঙে জমাট রক্ত (থ্রম্বাস) গলিয়ে দেয়। দেহে এর পরিমাণ অতি সামান্য, তাই জিন প্রকৌশলে CHO কোষে উৎপাদন করা হয় (অ্যালটেপ্লেজ, জেনেনটেক 1987)। হৃদরোগ (হার্ট অ্যাটাক) ও রক্তনালি বন্ধ হয়ে হওয়া স্ট্রোকে ব্যবহৃত — তবে কেবল চিকিৎসকের তত্ত্বাবধানে, কারণ রক্তক্ষরণের ঝুঁকি থাকে।',
  types: {
    clot: ['জমাট গলানো', 'ফাইব্রিনের জাল ভেঙে রক্তপ্রবাহ ফেরা', 'ধাপ: tPA → প্লাসমিনোজেন থেকে প্লাসমিন → ফাইব্রিন ভাঙা → নালি খোলা।'],
    time: ['সময়ের গুরুত্ব', 'যত দেরি তত কম উপকার', 'রক্তনালি বন্ধ হয়ে হওয়া স্ট্রোকে সাধারণত লক্ষণ শুরুর ৩ থেকে ৪.৫ ঘণ্টার মধ্যে দিলে সবচেয়ে ভালো ফল মেলে; দেরিতে উপকারের তুলনায় রক্তক্ষরণের ঝুঁকি বেড়ে যায়।']
  },
  art(g, C, ty, ctx) {
    const Rf = BK.ramp(4), Rp = BK.ramp(6), Rb = BK.ramp(0);
    if (ty === 'time') {
      const P = B.axes(g, C, [48, 28, 272, 140], { xr: [0, 8], yr: [0, 100], xt: [0, 2, 4, 6, 8], yt: [0, 25, 50, 75, 100], xf: v => B.bn(v), yf: v => B.bn(v), lx: 'ঘণ্টা', ly: 'আপেক্ষিক উপকার (%)' });
      B.area(g, P, x => 100 * Math.exp(-x * .42), 0, 4.5, 0, { fill: FK.alpha(Rp.c, .18) });
      B.curve(g, P, x => 100 * Math.exp(-x * .42), 0, 8, { stroke: Rp.c });
      B.curve(g, P, x => Math.min(100, 8 + x * x * 2.4), 0, 8, { stroke: Rf.c, 'stroke-dasharray': '5 3' });
      const [wx] = P(4.5, 0); E('path', { d: `M${wx} 28V168`, stroke: Rf.dk, 'stroke-dasharray': '3 3' }, g);
      T(g, wx - 6, 44, '৪.৫ ঘণ্টা', { fs: 9, a: 'end', w: 650, c: Rf.ink });
      B.chip(g, 96, 198, 'উপকার', Rp, { w: 80, h: 20, fs: 9.4 }); B.chip(g, 240, 198, 'রক্তক্ষরণের ঝুঁকি', Rf, { w: 136, h: 20, fs: 9.4 });
      T(g, 180, 226, 'লেখচিত্রটি ধারণা বোঝানোর জন্য — নির্দিষ্ট চিকিৎসা-নির্দেশনা নয়', { fs: 8.6, a: 'middle', c: C.mu });
      ctx.H = null;
      return;
    }
    E('path', { d: 'M0 86h360M0 162h360', stroke: Rb.dk, 'stroke-width': 2.4 }, g);
    E('rect', { x: 0, y: 88, width: 360, height: 72, fill: FK.alpha(Rb.c, .1) }, g);
    T(g, 12, 76, 'রক্তনালি', { fs: 9.4, c: Rb.ink });
    ctx.H = null;
  },
  anim(g, C, ty, t, ctx) {
    if (ty === 'time') { if (!t) return; const u = (t * .12) % 1, P = B.axes(E('g', { opacity: 0 }, g), C, [48, 28, 272, 140], { xr: [0, 8], yr: [0, 100] }), [px, py] = P(u * 8, 100 * Math.exp(-u * 8 * .42)); E('circle', { cx: px, cy: py, r: 4.5, fill: BK.ramp(6).dk }, g); return; }
    const Rf = BK.ramp(4), Rp = BK.ramp(6), u = t ? (t * .16) % 1 : .35, open = cl((u - .25) / .6);
    for (let i = 0; i < 26; i++) { const x = 130 + rnd(i) * 100, y = 92 + rnd(i + 40) * 64, o = 1 - open; E('path', { d: `M${x} ${y}l${10 - open * 8} ${6 - open * 4}`, stroke: Rf.dk, 'stroke-width': 2.2, opacity: o, 'stroke-linecap': 'round' }, g); }
    if (open < .9) E('ellipse', { cx: 180, cy: 124, rx: 56 * (1 - open), ry: 34 * (1 - open * .8), fill: FK.alpha(Rf.c, .3 * (1 - open)) }, g);
    for (let i = 0; i < 7; i++) { const q = (u * 1.4 + i * .14) % 1, x = q * 360, lim = open > .5 ? 360 : 124; const xx = Math.min(x, lim + (open > .5 ? 0 : 0)); E('ellipse', { cx: xx, cy: 100 + (i % 4) * 16, rx: 7, ry: 4.6, fill: FK.alpha(BK.ramp(4).c, .55), stroke: BK.ramp(4).dk, 'stroke-width': .6 }, g); }
    for (let i = 0; i < 5; i++) { const q = cl(u * 2 - i * .08); E('circle', { cx: 40 + q * 110, cy: 70 + i * 4, r: 4, fill: Rp.c, stroke: Rp.dk, 'stroke-width': .7, opacity: 1 - open * .7 }, g); }
    T(g, 180, 196, u < .3 ? 'tPA প্লাসমিনোজেনকে প্লাসমিনে পরিণত করে' : u < .7 ? 'প্লাসমিন ফাইব্রিনের জাল ভাঙছে' : 'জমাট গলে রক্তপ্রবাহ ফিরে এল', { fs: 10.4, a: 'middle', w: 600, c: u < .7 ? Rf.ink : BK.ramp(10).ink });
    T(g, 180, 220, 'tPA → প্লাসমিনোজেন → প্লাসমিন → ফাইব্রিন ভাঙা', { fs: 9.2, a: 'middle', c: C.mu });
  }
}));

V.cmpInsulinSrc = cmp('প্রাণীজ ইনসুলিন বনাম রিকম্বিনেন্ট ইনসুলিন', 'ডায়াবেটিসের চিকিৎসায় ইনসুলিনের দুই উৎস।', 'গরু বা শূকরের অগ্ন্যাশয় থেকে', 'রিকম্বিনেন্ট (মানব) ইনসুলিন', [
  ['উৎস', 'জবাই করা পশুর অগ্ন্যাশয়', 'E. coli বা ইস্টে মানব জিন থেকে'],
  ['গঠন', 'মানুষের থেকে সামান্য ভিন্ন অ্যামিনো অ্যাসিড', 'মানুষের ইনসুলিনের হুবহু একই'],
  ['অ্যালার্জি', 'কারও কারও অ্যালার্জি ও প্রতিরোধ গড়ে ওঠে', 'ঝুঁকি অনেক কম'],
  ['পরিমাণ', 'সীমিত — এক রোগীর এক বছরের জন্য বহু পশুর অগ্ন্যাশয় লাগত', 'চাহিদামতো যত খুশি উৎপাদন সম্ভব'],
  ['দাম ও সরবরাহ', 'ব্যয়বহুল ও অনিশ্চিত', 'তুলনামূলক সস্তা ও নিয়মিত'],
  ['ধর্মীয় ও নৈতিক দিক', 'শূকরজাত হওয়ায় অনেকের আপত্তি', 'কোনো পশু ব্যবহৃত হয় না'],
  ['সময়কাল', '1922 থেকে প্রায় ১৯৮০ এর দশক', '1982 থেকে (হিউমুলিন)']
]);
})();
