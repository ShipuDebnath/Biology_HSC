/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §১১.২ রিকম্বিনেন্ট DNA প্রযুক্তি, প্লাসমিড, রেস্ট্রিকশন এনজাইম, জিন ক্লোনিং, PCR
   rdnaSteps   : রিকম্বিনেন্ট DNA প্রযুক্তির ধাপ (কাটা → জোড়া → প্রবেশ → বাছাই → ক্লোন)
   plasmidMap  : pBR322 এর মানচিত্র, প্লাসমিডের প্রকার, স্বাধীন প্রতিলিপন
   reCut       : EcoRI, BamHI, PstI, SmaI এর কাটা ও লাইগেজের জোড়া (অ্যানিমেশন)
   siteFreq    : রেস্ট্রিকশন সাইটের প্রত্যাশিত দূরত্ব 4^n — জিনোমে কতবার কাটবে
   transformSel: ট্রান্সফরমেশন, ইনসারশনাল ইনঅ্যাক্টিভেশন (রেপ্লিকা প্লেটিং), নীল-সাদা বাছাই
   cloneGrowth : জিন ক্লোনিংয়ে কোষ ও জিনের কপি সংখ্যা     cdnaMake : mRNA থেকে cDNA
   vectorCap   : বাহকের ধারণক্ষমতা (লগ স্কেল)       pcrCycle : PCR এর ধাপ      pcrCount : PCR এ কপি সংখ্যা
   cmpTcRdna, cmpRdnaPcr, cmpPlasmidChromo, cmpStickyBlunt : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B11;
const PI = Math.PI, ch = B.ch, cl = B.cl, rnd = B.rnd, node = B.node, lab = B.lab, bn = B.bn, hot = B.hot, pol = B.pol;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const Rg = () => BK.ramp(6), Rp = () => BK.ramp(3), Rr = () => BK.ramp(4), Rl = () => BK.ramp(1);
/* সরল DNA রেখা (দুই সূত্র) — রঙ R */
const ds = (g, x0, x1, y, R, o = {}) => { E('path', { d: `M${x0} ${y}H${x1}M${x0} ${y + 7}H${x1}`, stroke: R.dk, 'stroke-width': o.w || 2.2, 'stroke-linecap': 'round', opacity: o.op != null ? o.op : 1 }, g); for (let x = x0 + 4; x < x1; x += 6) E('path', { d: `M${x} ${y + 1}v5`, stroke: R.c, 'stroke-width': 1.2, opacity: o.op != null ? o.op : 1 }, g); };
const scissors = (g, x, y, R, open = .4) => { const o = Math.max(.08, open); [-1, 1].forEach(sd => { E('path', { d: `M${x + sd * 6} ${y - 20}L${x - sd * 12 * o} ${y + 6}`, stroke: R.dk, 'stroke-width': 2.2, 'stroke-linecap': 'round' }, g); E('circle', { cx: x + sd * 7, cy: y - 24, r: 4, fill: 'none', stroke: R.dk, 'stroke-width': 1.6 }, g); }); E('circle', { cx: x, cy: y - 8, r: 1.6, fill: R.dk }, g); };

/* ═════════ ১. রিকম্বিনেন্ট DNA প্রযুক্তির ধাপ ═════════ */
V.rdnaSteps = Object.assign({ t: 'রিকম্বিনেন্ট DNA প্রযুক্তির ধাপসমূহ', k: ['anim', 'steps'], cap: 'দাতা জীবের কাঙ্ক্ষিত জিন একই রেস্ট্রিকশন এনজাইমে কাটা বাহকে (প্লাসমিড) জুড়ে দিয়ে পোষক ব্যাকটেরিয়ায় ঢোকানো হয় — ব্যাকটেরিয়া বিভাজিত হয়ে জিনটির লক্ষ কোটি কপি (ক্লোন) ও তার প্রোটিন তৈরি করে। কোহেন ও বয়ার (1973) প্রথম এভাবে জিন ক্লোন করেন।' }, BK.steps({
  W: 360, H: 240, label: 'rDNA প্রযুক্তির ধাপ', dur: 3,
  stages: [
    { t: 'DNA ও বাহক পৃথকীকরণ', en: 'Isolation', d: 'দাতা কোষ (যেমন মানুষের কোষ) থেকে কাঙ্ক্ষিত জিনসহ DNA এবং ব্যাকটেরিয়া থেকে প্লাসমিড পৃথক করা হয় — কোষ ভেঙে (লাইসোজাইম, ডিটারজেন্ট), প্রোটিন ও RNA সরিয়ে (প্রোটিয়েজ, RNase), ইথানলে DNA অধঃক্ষেপণ।' },
    { t: 'রেস্ট্রিকশন এনজাইমে কাটা', en: 'Restriction digestion', d: 'একই রেস্ট্রিকশন এনজাইম (যেমন EcoRI — G↓AATTC) দিয়ে দাতা DNA ও প্লাসমিড কাটা হয় — দুটিতেই একই রকম পরিপূরক এক-সূত্রক প্রান্ত (স্টিকি এন্ড: AATT) তৈরি হয়।' },
    { t: 'মিশ্রণ ও জোড় বাঁধা', en: 'Annealing', d: 'কাটা জিন ও খোলা প্লাসমিড একসাথে মেশালে স্টিকি এন্ডের পরিপূরক ক্ষারক হাইড্রোজেন বন্ধনে জোড় বাঁধে।' },
    { t: 'লাইগেজে জোড়া — rDNA', en: 'Ligation', d: 'DNA লাইগেজ (সাধারণত T4 DNA লাইগেজ, ATP লাগে) চিনি-ফসফেট মেরুদণ্ডের ফাঁক ফসফোডাইএস্টার বন্ধনে স্থায়ীভাবে জোড়া দেয় — তৈরি হয় রিকম্বিনেন্ট DNA (rDNA) বা কাইমেরিক DNA।' },
    { t: 'পোষকে প্রবেশ — ট্রান্সফরমেশন', en: 'Transformation', d: 'শীতল CaCl<sub>2</sub> দ্রবণে রাখা E. coli কোষকে 42 °C এ ৪৫–৯০ সেকেন্ড তাপ-আঘাত (হিট শক) দিলে কোষঝিল্লি সাময়িক ভেদ্য হয়ে rDNA ভেতরে ঢোকে; বিকল্প — ইলেকট্রোপোরেশন। rDNA গ্রহণকারী কোষ — ট্রান্সফরমড কোষ।' },
    { t: 'বাছাই (সিলেকশন)', en: 'Selection', d: 'প্লাসমিডের অ্যান্টিবায়োটিক প্রতিরোধী জিন (যেমন ampR) থাকায় অ্যাম্পিসিলিনযুক্ত মাধ্যমে শুধু প্লাসমিডযুক্ত কোষ বাঁচে; ইনসারশনাল ইনঅ্যাক্টিভেশন বা নীল-সাদা পরীক্ষায় rDNA যুক্ত কোষ আলাদা করা হয়।' },
    { t: 'ক্লোনিং ও প্রকাশ', en: 'Cloning & expression', d: 'বাছাইকৃত কোষ বায়োরিঅ্যাক্টরে বংশবৃদ্ধি করে — প্রতি ২০ মিনিটে দ্বিগুণ; সাথে জিনেরও কোটি কোটি কপি (জিন ক্লোনিং)। উপযুক্ত প্রোমোটার থাকলে জিনটি প্রকাশিত হয়ে প্রোটিন (যেমন ইনসুলিন) তৈরি করে — পরিশোধন করে ঔষধ।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Ra = Rg(), Rv = Rp(), Re = Rr(), Rb = BK.ramp(0);
    if (s === 0) {
      E('circle', { cx: 90, cy: 120, r: 60, fill: FK.alpha(BK.ramp(8).c, .12), stroke: BK.ramp(8).dk }, g); E('circle', { cx: 90, cy: 120, r: 22, fill: FK.alpha(BK.ramp(3).c, .2), stroke: BK.ramp(3).dk }, g); T(g, 90, 200, 'দাতা কোষ (মানুষ)', { fs: 10, a: 'middle', c: C.fg });
      B.bac(g, C, 270, 120, 120, 56, { plas: 3 }); T(g, 270, 170, 'ব্যাকটেরিয়া', { fs: 10, a: 'middle', c: C.fg });
      const y = 120 - 60 * k; ds(g, 60, 120, y - 4, BK.ramp(9), { op: k }); E('path', { d: `M80 ${y - 4}h20M80 ${y + 3}h20`, stroke: Ra.c, 'stroke-width': 4, opacity: k }, g); T(g, 90, 40, 'কাঙ্ক্ষিত জিনসহ DNA', { fs: 9.5, a: 'middle', c: Ra.ink });
      B.plasmid(g, C, 300, 58 - 10 * (1 - k), 14, { sw: 4 }); T(g, 300, 30, 'প্লাসমিড', { fs: 9.5, a: 'middle', c: Rv.ink }); return;
    }
    if (s === 1) {
      ds(g, 30, 200, 70, BK.ramp(9)); E('path', { d: 'M90 70h40M90 77h40', stroke: Ra.c, 'stroke-width': 4 }, g);
      [90, 130].forEach(x => { scissors(g, x, 60, Re, .5 - .3 * Math.sin(k * PI * 4)); }); T(g, 110, 104, 'EcoRI — G↓AATTC', { fs: 10, a: 'middle', w: 650, c: Re.ink });
      B.plasmid(g, C, 280, 150, 46, { genes: [[200, 260, 2, 'ampR']], sites: [[0, 'EcoRI']] });
      if (k > .6) { E('path', { d: 'M276 102l8 0', stroke: C.sf, 'stroke-width': 8 }, g); T(g, 280, 220, 'প্লাসমিড খুলে গেল', { fs: 9.5, a: 'middle', c: C.mu }); }
      T(g, 110, 140, 'দুই ক্ষেত্রেই একই স্টিকি এন্ড', { fs: 10, a: 'middle', c: C.fg }); T(g, 110, 160, '5\'-AATT-', { fs: 11, a: 'middle', w: 700, c: BK.ramp(7).ink }); return;
    }
    if (s === 2 || s === 3) {
      const gap = s === 2 ? 30 * (1 - k) : 0; B.plasmid(g, C, 180, 130, 70, { genes: [[200, 250, 2, 'ampR'], [90, 150, 5, 'ori']] });
      E('path', { d: B.arc(180, 130, 70, -22 - gap * .3, 22 + gap * .3), stroke: C.sf, 'stroke-width': 12, fill: 'none' }, g);
      E('path', { d: B.arc(180, 130 - gap, 70, -20, 20), stroke: Ra.c, 'stroke-width': 9, fill: 'none' }, g); T(g, 180, 48 - gap, 'কাঙ্ক্ষিত জিন', { fs: 10, a: 'middle', w: 650, c: Ra.ink });
      if (s === 3) { [-20, 20].forEach(a => { const [x, y] = pol(180, 130, 70, a); E('circle', { cx: x, cy: y, r: 8 * (1 - k) + 3, fill: FK.alpha(Rl().c, .5), stroke: Rl().dk }, g); }); T(g, 180, 136, 'rDNA', { fs: 15, a: 'middle', w: 700, c: C.fg }); T(g, 180, 154, 'লাইগেজ জোড়া দিল', { fs: 9.5, a: 'middle', c: Rl().ink }); }
      else T(g, 180, 136, 'হাইড্রোজেন বন্ধনে জোড়', { fs: 10, a: 'middle', c: C.mu });
      return;
    }
    if (s === 4) {
      B.bac(g, C, 180, 140, 170, 80, {}); E('rect', { x: 20, y: 20, width: 60, height: 22, rx: 6, fill: FK.alpha(BK.ramp(5).c, .25), stroke: BK.ramp(5).dk }, g); T(g, 50, 35, ch('CaCl_{2}, 0 °C'), { fs: 9, a: 'middle', c: C.fg }); E('rect', { x: 280, y: 20, width: 60, height: 22, rx: 6, fill: FK.alpha(Re.c, .25), stroke: Re.dk }, g); T(g, 310, 35, '42 °C, ৯০ সে', { fs: 9, a: 'middle', c: C.fg });
      const x = 180 + 90 * (1 - k), y = 60 + 70 * k; B.plasmid(g, C, x, y, 12, { sw: 3, ins: [-40, 40] }); T(g, 180, 214, 'তাপ-আঘাতে ঝিল্লি সাময়িক ভেদ্য', { fs: 10, a: 'middle', c: C.fg }); return;
    }
    if (s === 5) {
      B.dish(g, C, 180, 120, 86, { lab: 'অ্যাম্পিসিলিনযুক্ত মাধ্যম' });
      for (let i = 0; i < 14; i++) { const a = rnd(i) * PI * 2, r = 20 + rnd(i + 7) * 58, live = i % 3 !== 0; E('circle', { cx: 180 + r * Math.cos(a), cy: 120 + r * Math.sin(a), r: live ? 4 + 3 * k : 4, fill: live ? Rb.c : 'none', stroke: live ? Rb.dk : C.mu, 'stroke-dasharray': live ? '' : '2 2', opacity: live ? 1 : 1 - k }, g); }
      T(g, 300, 40, 'প্লাসমিডহীন কোষ মরে', { fs: 9.5, a: 'middle', c: C.mu }); return;
    }
    const n = 1 + Math.floor(k * 4); for (let i = 0; i < 2 ** n && i < 16; i++) { const c = i % 4, r = Math.floor(i / 4); B.bac(g, C, 60 + c * 80, 50 + r * 44, 60, 26, { plas: 2, pr: 6, chromo: false }); }
    E('path', { d: 'M110 228H250', stroke: Ra.c, 'stroke-width': 3 }, g); T(g, 180, 222, `${bn(2 ** n)}টি কোষ → ইনসুলিন প্রোটিন`, { fs: 10, a: 'middle', c: C.fg });
  }
}));

/* ═════════ ২. প্লাসমিড ═════════ */
const PBR = { genes: [[7.1, 105.3, 2, 'tetR'], [271.8, 342.8, 2, 'ampR'], [195, 222, 5, 'ori'], [158, 174, 9, 'rop']], sites: [[359.8, 'EcoRI', -14], [2.4, 'HindIII', 16], [31, 'BamHI', 33], [53.7, 'SalI', 56], [297.9, 'PstI', 296], [308, 'PvuI', 312]] };
const PBRinfo = { EcoRI: 'EcoRI — অবস্থান 4359; tetR ও ampR এর বাইরে (একক সাইট) — এখানে জিন বসালে দুটি প্রতিরোধই অক্ষত থাকে।', HindIII: 'HindIII — অবস্থান 29; tetR জিনের প্রোমোটার অঞ্চলে।', BamHI: 'BamHI — অবস্থান 375; tetR জিনের ভেতরে। এখানে বিদেশি জিন বসালে tetR নষ্ট হয় (ইনসারশনাল ইনঅ্যাক্টিভেশন) — rDNA যুক্ত কোষ অ্যাম্পিসিলিনে বাঁচে কিন্তু টেট্রাসাইক্লিনে মরে।', SalI: 'SalI — অবস্থান 651; tetR জিনের ভেতরে।', PstI: 'PstI — অবস্থান 3609; ampR জিনের ভেতরে। এখানে জিন বসালে কোষ টেট্রাসাইক্লিনে বাঁচে, অ্যাম্পিসিলিনে মরে।', PvuI: 'PvuI — অবস্থান 3733; ampR জিনের ভেতরে।', tetR: 'tetR — টেট্রাসাইক্লিন প্রতিরোধী জিন (অবস্থান প্রায় 86–1276); বাছাই চিহ্নক (সিলেক্টেবল মার্কার)।', ampR: 'ampR (bla) — β-ল্যাকটামেজ এনজাইম তৈরি করে অ্যাম্পিসিলিন নষ্ট করে; বাছাই চিহ্নক (প্রায় 3293–4153)।', ori: 'ori — প্রতিলিপন সূচনা বিন্দু (pMB1 উৎসের): এর কারণেই প্লাসমিড পোষকের ক্রোমোসোম থেকে স্বাধীনভাবে প্রতিলিপিত হয়; কোষপ্রতি প্রায় ১৫–২০ কপি।', rop: 'rop — কপি সংখ্যা নিয়ন্ত্রক প্রোটিনের জিন।' };
const PK = [
  ['F প্লাসমিড', 1, 'ফার্টিলিটি (উর্বরতা) প্লাসমিড — tra জিন সেক্স পিলাস তৈরি করে; কনজুগেশনে F<sup>+</sup> কোষ থেকে F<sup>−</sup> কোষে নিজের কপি স্থানান্তর করে। E. coli তে প্রায় 100 kb।'],
  ['R প্লাসমিড', 2, 'রেজিস্ট্যান্স প্লাসমিড — এক বা একাধিক অ্যান্টিবায়োটিক প্রতিরোধী জিন বহন করে; অনেকগুলো কনজুগেশনে ছড়ায় — হাসপাতালে বহু-ঔষধ প্রতিরোধী জীবাণুর অন্যতম কারণ।'],
  ['Col প্লাসমিড', 8, 'কোলিসিন প্লাসমিড — কোলিসিন নামক প্রোটিন তৈরি করে যা সম্পর্কিত অন্য ব্যাকটেরিয়াকে মেরে ফেলে (যেমন E. coli এর ColE1)।'],
  ['Ti প্লাসমিড', 10, 'টিউমার-ইনডিউসিং প্লাসমিড — Agrobacterium tumefaciens এর; এর T-DNA উদ্ভিদের ক্রোমোসোমে ঢুকে ক্রাউন গল টিউমার ঘটায়। ক্ষতিকর জিন সরিয়ে উদ্ভিদে জিন স্থানান্তরের সেরা প্রাকৃতিক বাহক (প্রায় 200 kb)।'],
  ['বিয়োজক প্লাসমিড', 7, 'ডিগ্রেডেটিভ প্লাসমিড — অস্বাভাবিক যৌগ ভাঙার এনজাইমের জিন; যেমন Pseudomonas putida এর TOL প্লাসমিড টলুইন ভাঙে — বায়োরেমিডিয়েশনে কাজে লাগে।'],
  ['ভিরুলেন্স প্লাসমিড', 4, 'রোগ সৃষ্টির ক্ষমতা (টক্সিন, আসঞ্জন) দেয় — যেমন কিছু E. coli এর এন্টারোটক্সিন জিন প্লাসমিডে।']
];
V.plasmidMap = Object.assign({}, B.seg({
  id: 'pls', t: 'প্লাসমিড — গঠন, প্রকার ও প্রতিলিপন', H: 272, def: 'pbr', sel: null,
  cap: 'প্লাসমিড — ব্যাকটেরিয়ার (কখনো ইস্টের) ক্রোমোসোমের বাইরের ছোট, সাধারণত বৃত্তাকার, দ্বিসূত্রক DNA, যা নিজে নিজে প্রতিলিপিত হয়। শব্দটি জশুয়া লেডারবার্গের (1952)। pBR322 — বলিভার ও রড্রিগেজের (1977) তৈরি প্রথম বহুল ব্যবহৃত কৃত্রিম ক্লোনিং বাহক। মানচিত্রের জিন বা সাইটে চাপ দাও।',
  types: {
    pbr: ['pBR322', 'pBR322 — একটি আদর্শ ক্লোনিং বাহক (4361 bp)', 'দুটি অ্যান্টিবায়োটিক প্রতিরোধী জিন (ampR, tetR), প্রতিলিপন সূচনা বিন্দু (ori) এবং কয়েকটি একক রেস্ট্রিকশন সাইট।'],
    kinds: ['প্রকারভেদ', 'কাজ অনুযায়ী প্লাসমিডের প্রকার', 'F, R, Col, Ti, বিয়োজক ও ভিরুলেন্স প্লাসমিড — যেকোনোটিতে চাপ দাও।'],
    rep: ['প্রতিলিপন', 'স্বাধীন প্রতিলিপন ও কপি সংখ্যা', 'প্লাসমিড নিজের ori থেকে পোষকের এনজাইম ব্যবহার করে ক্রোমোসোম থেকে স্বাধীনভাবে প্রতিলিপিত হয়; কোষ বিভাজনে দুই অপত্য কোষে ভাগ হয়। কোষপ্রতি কপি সংখ্যা — কঠোর নিয়ন্ত্রিত (১–২) বা শিথিল নিয়ন্ত্রিত (১০–৫০০ বা বেশি; pUC তে ৫০০–৭০০)।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'pbr') {
      B.plasmid(g, C, 180, 138, 84, { genes: PBR.genes, sw: 11, fs: 9.5 });
      PBR.sites.forEach(([a, s, la]) => { const [x0, y0] = pol(180, 138, 88, a), [x1, y1] = pol(180, 138, 98, a), [lx, ly] = pol(180, 138, 112, la); E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: Rr().dk, 'stroke-width': 1.6 }, g); E('path', { d: `M${x1} ${y1}L${lx} ${ly}`, stroke: FK.alpha(Rr().c, .5), 'stroke-width': .8 }, g); T(g, lx, ly + 3.5, s, { fs: 9.5, a: lx < 176 ? 'end' : lx > 184 ? 'start' : 'middle', w: 650, c: Rr().ink }); });
      T(g, 180, 134, 'pBR322', { fs: 14, a: 'middle', w: 700, c: Rp().ink }); T(g, 180, 150, '4361 bp', { fs: 10, a: 'middle', c: C.mu });
      const H = []; PBR.genes.forEach(([a0, a1, , s]) => H.push(pol(180, 138, 84, (a0 + a1) / 2).concat([s]))); PBR.sites.forEach(([a, s, la]) => H.push(pol(180, 138, 108, la).concat([s]))); ctx.H = H;
      if (ctx.sel) { const h = H.find(q => q[2] === ctx.sel); if (h) E('circle', { cx: h[0], cy: h[1], r: 13, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2.2 }, g); }
      return;
    }
    if (ty === 'kinds') {
      const H = []; PK.forEach(([s, ri], i) => { const c = i % 3, r = Math.floor(i / 3), x = 62 + c * 118, y = 66 + r * 120, R = BK.ramp(ri), on = ctx.sel === i; E('rect', { x: x - 54, y: y - 54, width: 108, height: 108, rx: 12, fill: FK.alpha(R.c, on ? .25 : .08), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); B.plasmid(g, C, x, y - 8, 26, { genes: [[300, 60, ri, '']], sw: 6 }); T(g, x, y + 40, s, { fs: 10.5, a: 'middle', w: 650, c: R.ink }); H.push([x, y, i]); }); ctx.H = H;
      return;
    }
    T(g, 180, 22, 'প্লাসমিড ক্রোমোসোম থেকে স্বাধীন', { fs: 10.5, a: 'middle', c: C.fg });
  },
  anim(g, C, ty, t, ctx) {
    if (ty === 'pbr') { if (!t) return; const a = (t * 30) % 360, [x, y] = pol(180, 138, 84, a); E('circle', { cx: x, cy: y, r: 5, fill: BK.ramp(5).c, stroke: C.sf, 'stroke-width': 1.5 }, g); return; }
    if (ty === 'kinds') { if (!t) return; const i = Math.floor(t * .5) % 6, c = i % 3, r = Math.floor(i / 3), x = 62 + c * 118, y = 58 + r * 120, a = (t * 90) % 360, [px, py] = pol(x, y, 26, a); E('circle', { cx: px, cy: py, r: 3.5, fill: BK.ramp(PK[i][1]).c }, g); return; }
    const u = t ? (t * .2) % 1 : .3, k = FK.ease(cl(u * 1.4)), split = cl((u - .7) * 3.3);
    if (split <= 0) { B.bac(g, C, 180, 140, 200 + 40 * k, 90, { plas: 0 }); const n = 2 + Math.floor(k * 6); for (let i = 0; i < n; i++) { const a = i * 2.4 + t * .5, x = 230 + 30 * Math.cos(a), y = 140 + 24 * Math.sin(a); B.plasmid(g, C, x, y, 7, { sw: 2 }); } T(g, 180, 230, `কোষপ্রতি প্লাসমিড: ${bn(n)}টি`, { fs: 10, a: 'middle', c: C.fg }); }
    else { [-1, 1].forEach(sd => { const x = 180 + sd * (70 + 20 * split); B.bac(g, C, x, 140, 120, 76, {}); for (let i = 0; i < 4; i++) B.plasmid(g, C, x + 24 + (i % 2) * 14, 124 + Math.floor(i / 2) * 18, 6, { sw: 2 }); }); T(g, 180, 230, 'বিভাজনে দুই অপত্য কোষে ভাগ', { fs: 10, a: 'middle', c: C.fg }); }
  },
  tap(x, y, ty, ctx) { if (ty === 'rep') return null; const h = hot(ctx.H || [], x, y, ty === 'kinds' ? 58 : 24); if (!h) return null; ctx.sel = h[2]; if (ty === 'kinds') { const p = PK[h[2]]; return `<b>${p[0]}</b> — ${p[2]}`; } return `<b>${h[2]}</b> — ${PBRinfo[h[2]]}`; }
}));

/* ═════════ ৩. রেস্ট্রিকশন এনজাইম ও লাইগেজ ═════════ */
const RE = {
  eco: ['EcoRI', 'GAATTC', 1, 5, 'Escherichia coli RY13', '৫\' বাড়তি প্রান্ত (AATT) — স্টিকি এন্ড'],
  bam: ['BamHI', 'GGATCC', 1, 5, 'Bacillus amyloliquefaciens H', '৫\' বাড়তি প্রান্ত (GATC) — স্টিকি এন্ড'],
  pst: ['PstI', 'CTGCAG', 5, 1, 'Providencia stuartii', '৩\' বাড়তি প্রান্ত (TGCA) — স্টিকি এন্ড'],
  sma: ['SmaI', 'CCCGGG', 3, 3, 'Serratia marcescens', 'সমান কাটা — ভোঁতা প্রান্ত (ব্লান্ট এন্ড)']
};
const FL = ['ATCGT', 'TACGA'];
V.reCut = Object.assign({}, B.seg({
  id: 'rec', t: 'রেস্ট্রিকশন এনজাইম ও DNA লাইগেজ — আণবিক কাঁচি ও আঠা', H: 248, def: 'eco',
  cap: 'রেস্ট্রিকশন এন্ডোনিউক্লিয়েজ DNA এর নির্দিষ্ট ৪–৮ ক্ষারক জোড়ের প্যালিনড্রোমিক ক্রম (দুই সূত্রে ৫\'→৩\' দিকে একই পড়া যায়) চিনে সেখানে কাটে — ব্যাকটেরিয়া এগুলো দিয়ে আক্রমণকারী ফাজের DNA কেটে নিজেকে রক্ষা করে (নিজের DNA মিথাইলেশনে সুরক্ষিত)। চালাও চাপলে এনজাইম সাইট খুঁজে কাটবে।',
  types: {
    eco: ['EcoRI', 'EcoRI — G↓AATTC', 'G ও A এর মাঝে কাটে; দুই সূত্রে কাটা ৪ ক্ষারক সরে থাকায় ৫\'-AATT এক-সূত্রক প্রান্ত (স্টিকি এন্ড)। নাম: E = Escherichia, co = coli, R = স্ট্রেইন RY13, I = প্রথম আবিষ্কৃত।'],
    bam: ['BamHI', 'BamHI — G↓GATCC', 'G ও G এর মাঝে কাটে; ৫\'-GATC স্টিকি এন্ড। pBR322 এর tetR জিনের ভেতরে এর একটি সাইট আছে।'],
    pst: ['PstI', 'PstI — CTGCA↓G', 'A ও G এর মাঝে কাটে; ৩\' দিকে বাড়তি TGCA প্রান্ত — স্টিকি এন্ড (৩\' ওভারহ্যাং)।'],
    sma: ['SmaI', 'SmaI — CCC↓GGG', 'ঠিক মাঝখানে দুই সূত্র একই জায়গায় কাটে — কোনো বাড়তি প্রান্ত নেই, ভোঁতা প্রান্ত (ব্লান্ট এন্ড)। ব্লান্ট এন্ড যেকোনো ব্লান্ট এন্ডের সাথে জোড়া লাগে, তবে কম দক্ষতায়।'],
    lig: ['লাইগেজ', 'DNA লাইগেজ — জোড়া দেওয়া', 'দুটি স্টিকি এন্ড পরিপূরক ক্ষারকে হাইড্রোজেন বন্ধনে জোড় বাঁধার পর লাইগেজ এক নিউক্লিওটাইডের ৩\'-OH ও পরেরটির ৫\'-ফসফেটের মধ্যে ফসফোডাইএস্টার বন্ধন তৈরি করে ফাঁক (নিক) বন্ধ করে। T4 DNA লাইগেজ ATP ব্যবহার করে এবং ব্লান্ট এন্ডও জোড়া দিতে পারে।']
  },
  art(g, C, ty) {
    const r = RE[ty === 'lig' ? 'eco' : ty]; T(g, 180, 26, ty === 'lig' ? 'দুটি ভিন্ন উৎসের EcoRI-কাটা খণ্ড' : `চেনার সাইট: ${r[1]} (প্যালিনড্রোম)`, { fs: 10.5, a: 'middle', w: 650, c: C.fg });
    if (ty !== 'lig') { T(g, 180, 232, `উৎস: ${r[4]}`, { fs: 9.2, a: 'middle', c: C.mu }); E('rect', { x: 60 + 5 * 15, y: 76, width: 90, height: 62, rx: 6, fill: FK.alpha(Rr().c, .1), stroke: Rr().c, 'stroke-dasharray': '3 3' }, g); }
  },
  anim(g, C, ty, t) {
    const u = t ? (t * .18) % 1 : .99;
    if (ty === 'lig') {
      const k = FK.ease(cl(u * 1.6)), sep = 60 * (1 - k), seq = FL[0] + 'GAATTC' + FL[1];
      const sx = 60;
      B.dna(g, C, sx, 100, seq, { cut: [6, 10], sep: Math.max(sep, 0.01), lab: true, w: 15 });
      for (let i = 0; i < 16; i++) { const R = i < 8 ? Rg() : BK.ramp(9); E('rect', { x: sx + i * 15 + (i >= 6 ? sep / 2 : -sep / 2) + 1, y: 70, width: 13, height: 3, fill: R.c, opacity: .6 }, g); }
      if (k > .98) { [6, 10].forEach((ci, s) => { const x = sx + ci * 15, y = s ? 133 : 91; E('circle', { cx: x, cy: y, r: 6 + 2 * Math.sin(t * 6), fill: FK.alpha(Rl().c, .35), stroke: Rl().dk }, g); }); T(g, 180, 176, 'লাইগেজ ফসফোডাইএস্টার বন্ধন তৈরি করছে', { fs: 10.5, a: 'middle', c: Rl().ink }); T(g, 180, 196, 'ফল: রিকম্বিনেন্ট DNA', { fs: 10.5, a: 'middle', w: 650, c: C.fg }); }
      else T(g, 180, 186, 'পরিপূরক স্টিকি এন্ড কাছে আসছে', { fs: 10.5, a: 'middle', c: C.mu });
      return;
    }
    const r = RE[ty], seq = FL[0] + r[1] + FL[1], sx = 60, find = cl(u * 2.2), cut = u > .5, sep = cut ? 34 * FK.ease(cl((u - .5) * 3)) : 0;
    B.dna(g, C, sx, 96, seq, { cut: cut ? [5 + r[2], 5 + r[3]] : null, sep, lab: true, w: 15 });
    if (!cut) { const ex = sx + 10 + find * (5 * 15 + 45 - 10); E('ellipse', { cx: ex, cy: 108, rx: 30, ry: 26, fill: FK.alpha(Rr().c, .22), stroke: Rr().dk, 'stroke-width': 1.4 }, g); T(g, ex, 152, r[0], { fs: 10.5, a: 'middle', w: 700, c: Rr().ink }); }
    else { const xt = sx + (5 + r[2]) * 15, xb = sx + (5 + r[3]) * 15; E('path', { d: `M${xt} 70v12`, stroke: Rr().c, 'stroke-width': 2 }, g); E('path', { d: `M${xb} 134v12`, stroke: Rr().c, 'stroke-width': 2 }, g); T(g, 180, 178, ty === 'sma' ? 'দুই সূত্র একই জায়গায় কাটা — ভোঁতা প্রান্ত' : 'দুই সূত্রে সরানো কাটা — এক-সূত্রক স্টিকি এন্ড', { fs: 10.5, a: 'middle', c: C.fg }); T(g, 180, 198, r[5], { fs: 10, a: 'middle', w: 650, c: Rr().ink }); }
  }
}));

/* ═════════ ৪. সাইটের প্রত্যাশিত দূরত্ব ═════════ */
const GEN = { lam: ['λ ফাজ', 48502, 'λ ফাজের জিনোম 48,502 bp। প্রকৃতপক্ষে এতে EcoRI সাইট ৫টি, BamHI ৫টি, HindIII ৭টি — প্রত্যাশিত (প্রায় ১২) এর চেয়ে কম, কারণ বাস্তব DNA তে ক্ষারকের ক্রম পুরোপুরি এলোমেলো নয়।'], eco: ['E. coli', 4.64e6, 'E. coli K-12 জিনোম প্রায় 46 লক্ষ bp।'], hum: ['মানুষ', 3.1e9, 'মানব জিনোম (হ্যাপ্লয়েড) প্রায় 310 কোটি bp।'] };
V.siteFreq = Object.assign({}, B.seg({
  id: 'sfq', t: 'রেস্ট্রিকশন সাইট কত ঘন ঘন থাকে? — 4<sup>n</sup> এর হিসাব', H: 230, def: 'lam',
  sl: [{ k: 'n', l: 'ক্রমের দৈর্ঘ্য n', min: 4, max: 8, step: 1, val: 6 }],
  cap: 'DNA তে চার ধরনের ক্ষারক সমান হারে ও এলোমেলোভাবে থাকলে নির্দিষ্ট একটি n-ক্ষারকের ক্রম গড়ে প্রতি 4<sup>n</sup> ক্ষারক জোড়ে একবার আসে। তাই ৪-কাটার (যেমন AluI) ঘন ঘন কাটে (প্রতি 256 bp), ৬-কাটার (EcoRI) প্রতি 4096 bp, আর ৮-কাটার (NotI) প্রতি প্রায় 65,536 bp এ।',
  types: { lam: ['λ ফাজ', 'λ ফাজের জিনোম', GEN.lam[2]], eco: ['E. coli', 'E. coli এর জিনোম', GEN.eco[2]], hum: ['মানুষ', 'মানব জিনোম', GEN.hum[2]] },
  art(g, C, ty, ctx) {
    const n = ctx.v.n, L = GEN[ty][1], d = 4 ** n, cuts = L / d;
    const R = BK.ramp(4), bar = [30, 70, 300, 18];
    E('rect', { x: bar[0], y: bar[1], width: bar[2], height: bar[3], rx: 9, fill: FK.alpha(BK.ramp(9).c, .3), stroke: BK.ramp(9).dk }, g);
    const show = Math.min(80, Math.round(cuts)); ctx.show = show;
    for (let i = 0; i < show; i++) { const x = bar[0] + (i + .5 + (rnd(i * 3 + n) - .5) * .8) / Math.max(show, 1) * bar[2]; E('path', { d: `M${x} ${bar[1] - 5}V${bar[1] + bar[3] + 5}`, stroke: R.c, 'stroke-width': 1.6 }, g); }
    T(g, 180, 50, `${GEN[ty][0]} — ${FK.n(L, 0)} bp`, { fs: 11, a: 'middle', w: 650, c: C.fg });
    if (cuts > 80) T(g, 180, 112, '(চিত্রে সর্বোচ্চ ৮০টি দাগ দেখানো হয়েছে)', { fs: 9, a: 'middle', c: C.mu });
    T(g, 180, 146, ch(`প্রত্যাশিত দূরত্ব = 4^{${n}}`) + ` = ${FK.n(d, 0)} bp`, { fs: 12, a: 'middle', w: 700, c: R.ink });
    T(g, 180, 172, `প্রত্যাশিত কাটার সংখ্যা ≈ ${FK.n(L, 0)} ÷ ${FK.n(d, 0)} ≈ ${cuts >= 10 ? FK.n(cuts, 0) : FK.n(cuts, 1)}`, { fs: 11, a: 'middle', c: C.fg });
    T(g, 180, 196, 'রৈখিক DNA তে খণ্ড = কাটা + ১; বৃত্তাকার DNA তে খণ্ড = কাটা', { fs: 9.5, a: 'middle', c: C.mu });
    ctx.selInfo = () => `<b>n = ${n}</b> → প্রতি 4<sup>${n}</sup> = ${FK.n(d, 0)} bp এ গড়ে একবার; ${GEN[ty][0]} এ প্রায় <b>${cuts >= 10 ? FK.n(cuts, 0) : FK.n(cuts, 1)}</b> বার কাটবে।<div class="small">${GEN[ty][2]} বাস্তবে GC-অনুপাত ও ক্রমের অসমতার জন্য সংখ্যা কিছুটা আলাদা হয়।</div>`;
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const x = 30 + ((t * 60) % 300); E('ellipse', { cx: x, cy: 79, rx: 9, ry: 14, fill: FK.alpha(BK.ramp(4).c, .3), stroke: BK.ramp(4).dk }, g); }
}));

/* ═════════ ৫. ট্রান্সফরমেশন ও বাছাই ═════════ */
V.transformSel = Object.assign({}, B.seg({
  id: 'tfs', t: 'ট্রান্সফরমেশন ও রিকম্বিনেন্ট কোষ বাছাই', H: 262, def: 'ins',
  cap: 'ট্রান্সফরমেশনের পর তিন ধরনের কোষ থাকে — প্লাসমিডহীন, শুধু প্লাসমিডযুক্ত (জিন ছাড়া) এবং rDNA যুক্ত। প্লাসমিডের চিহ্নক জিনের সাহায্যে শেষেরটিকে আলাদা করা হয়। চালাও চাপলে প্রক্রিয়া দেখাবে।',
  types: {
    trans: ['ট্রান্সফরমেশন', 'ট্রান্সফরমেশন — CaCl<sub>2</sub> ও তাপ-আঘাত', 'বরফ-শীতল CaCl<sub>2</sub> এ Ca<sup>2+</sup> আয়ন DNA এর ঋণাত্মক ফসফেট ও কোষঝিল্লির লিপোপলিস্যাকারাইডের বিকর্ষণ কমায়; 42 °C এ হঠাৎ তাপ-আঘাতে ঝিল্লিতে তাপীয় চাপ সৃষ্টি হয়ে DNA ভেতরে ঢোকে (ম্যান্ডেল ও হিগা, 1970)। সাফল্যের হার কম — প্রতি হাজার কোষে মাত্র কয়েকটি ট্রান্সফরমড হয়।'],
    ins: ['ইনসারশনাল ইনঅ্যাক্টিভেশন', 'ইনসারশনাল ইনঅ্যাক্টিভেশন — রেপ্লিকা প্লেটিং', 'pBR322 এর BamHI সাইট tetR জিনের ভেতরে; সেখানে জিন বসালে tetR নষ্ট হয়। অ্যাম্পিসিলিন প্লেটে সব প্লাসমিডযুক্ত কোষ বাঁচে; একই কলোনিগুলো ভেলভেট দিয়ে টেট্রাসাইক্লিন প্লেটে ছাপ দিলে (রেপ্লিকা প্লেটিং) যেগুলো বাঁচে না — সেগুলোই rDNA যুক্ত।'],
    bw: ['নীল-সাদা', 'নীল-সাদা বাছাই (pUC বাহক)', 'pUC বাহকে lacZα জিনের ভেতরে বহু ক্লোনিং সাইট (MCS)। X-gal ও IPTG যুক্ত মাধ্যমে অক্ষত lacZα থেকে β-গ্যালাকটোসাইডেজ X-gal ভেঙে নীল রং দেয় — জিন ঢুকলে lacZα নষ্ট, কলোনি সাদা। সাদা কলোনিই rDNA যুক্ত।']
  },
  art(g, C, ty) {
    if (ty === 'trans') { E('rect', { x: 26, y: 40, width: 80, height: 34, rx: 8, fill: FK.alpha(BK.ramp(5).c, .3), stroke: BK.ramp(5).dk }, g); T(g, 66, 56, ch('বরফ + CaCl_{2}'), { fs: 9.5, a: 'middle', c: C.fg }); T(g, 66, 68, '০ °C', { fs: 9, a: 'middle', c: C.mu }); E('rect', { x: 254, y: 40, width: 80, height: 34, rx: 8, fill: FK.alpha(Rr().c, .25), stroke: Rr().dk }, g); T(g, 294, 56, 'ওয়াটার বাথ', { fs: 9.5, a: 'middle', c: C.fg }); T(g, 294, 68, '42 °C, ৯০ সে', { fs: 9, a: 'middle', c: C.mu }); return; }
    if (ty === 'ins') {
      B.dish(g, C, 90, 112, 64, { lab: '১. অ্যাম্পিসিলিন প্লেট' }); B.dish(g, C, 270, 112, 64, { lab: '২. টেট্রাসাইক্লিন প্লেট', med: 2 });
      T(g, 180, 222, 'যে কলোনি ১ এ আছে কিন্তু ২ এ নেই — rDNA যুক্ত', { fs: 10, a: 'middle', w: 650, c: BK.ramp(6).ink });
      T(g, 180, 244, 'ampR অক্ষত, tetR নষ্ট (BamHI সাইটে জিন)', { fs: 9.5, a: 'middle', c: C.mu });
      return;
    }
    B.dish(g, C, 120, 120, 84, { lab: 'অ্যাম্পিসিলিন + X-gal + IPTG' });
    const Rb = BK.ramp(5);
    for (let i = 0; i < 16; i++) { const a = rnd(i + 3) * PI * 2, r = 12 + rnd(i + 11) * 62, w = i % 4 === 1 || i % 5 === 0; E('circle', { cx: 120 + r * Math.cos(a), cy: 120 + r * Math.sin(a), r: 6, fill: w ? '#ffffff' : Rb.c, stroke: w ? C.mu : Rb.dk, 'stroke-width': 1 }, g); }
    node(g, 290, 80, 'নীল কলোনি', Rb, 100, 24); T(g, 290, 106, 'lacZα অক্ষত — জিন নেই', { fs: 9, a: 'middle', c: C.mu });
    node(g, 290, 150, 'সাদা কলোনি', BK.ramp(9), 100, 24, { fill: '#ffffff' }); T(g, 290, 176, 'lacZα নষ্ট — rDNA আছে', { fs: 9, a: 'middle', w: 650, c: BK.ramp(6).ink });
  },
  anim(g, C, ty, t) {
    const u = t ? (t * .2) % 1 : .99, k = FK.ease(cl(u * 1.3));
    if (ty === 'trans') {
      const x = 66 + (294 - 66) * cl(u * 2), y = 150; B.bac(g, C, x, y, 110, 56, { plas: 0 });
      for (let i = 0; i < 5; i++) { const ang = i * 1.3, inside = u > .55 && i < 2, px = inside ? x - 20 + i * 18 : x + 70 * Math.cos(ang), py = inside ? y : y + 40 * Math.sin(ang); B.plasmid(g, C, px, py, 7, { sw: 2, ins: [-40, 40] }); }
      if (u > .5) for (let i = 0; i < 6; i++) { const a = i / 6 * PI * 2; E('path', { d: `M${x + 60 * Math.cos(a)} ${y + 32 * Math.sin(a)}l${6 * Math.cos(a)} ${4 * Math.sin(a)}`, stroke: Rr().c, 'stroke-width': 2 }, g); }
      T(g, 180, 236, u < .5 ? 'শীতল CaCl<sub>2</sub> — DNA কোষপৃষ্ঠে লেগে থাকে' : 'তাপ-আঘাত — কিছু প্লাসমিড ভেতরে', { fs: 10, a: 'middle', c: C.fg }); return;
    }
    if (ty === 'ins') {
      const P = [[-30, -20, 1], [10, -34, 0], [30, 8, 1], [-12, 18, 0], [-36, 22, 1], [20, 36, 1], [0, -2, 0]], Rc = BK.ramp(0);
      P.forEach(([dx, dy, tet]) => { E('circle', { cx: 90 + dx, cy: 112 + dy, r: 6, fill: Rc.c, stroke: Rc.dk }, g); if (k > .5) { const show = tet; E('circle', { cx: 270 + dx, cy: 112 + dy, r: 6, fill: show ? Rc.c : 'none', stroke: show ? Rc.dk : BK.ramp(6).c, 'stroke-width': show ? 1 : 2, 'stroke-dasharray': show ? '' : '2 2', opacity: k }, g); } });
      const vx = 90 + 180 * cl(u * 2); E('rect', { x: vx - 40, y: 30, width: 80, height: 10, rx: 3, fill: FK.alpha(BK.ramp(8).c, .5), stroke: BK.ramp(8).dk }, g); T(g, vx, 26, 'ভেলভেট', { fs: 9, a: 'middle', c: C.mu });
      return;
    }
    const s = 6 + 2 * Math.sin((t || 0) * 3); E('circle', { cx: 290, cy: 150, r: 50, fill: 'none', stroke: FK.alpha(BK.ramp(6).c, .4), 'stroke-width': 2 }, g); E('circle', { cx: 120, cy: 120, r: 84 + s * .2, fill: 'none', stroke: FK.alpha(BK.ramp(5).c, .25), 'stroke-width': 1 }, g);
  }
}));

/* ═════════ ৬. ক্লোনিংয়ে কপি সংখ্যা ═════════ */
V.cloneGrowth = Object.assign({}, B.seg({
  id: 'clg', t: 'জিন ক্লোনিং — এক কোষ থেকে কত কপি?', H: 236, def: 'x',
  sl: [{ k: 'h', l: 'সময় (ঘণ্টা)', min: 1, max: 12, step: 1, val: 6 }, { k: 'c', l: 'প্লাসমিড/কোষ', min: 1, max: 500, step: 1, val: 20 }],
  cap: 'উপযুক্ত পরিবেশে E. coli প্রায় ২০ মিনিটে একবার বিভাজিত হয় — ঘণ্টায় ৩ প্রজন্ম। h ঘণ্টায় একটি ট্রান্সফরমড কোষ থেকে 2<sup>3h</sup> কোষ, আর প্রতিটিতে c টি প্লাসমিড থাকলে জিনের কপি = 2<sup>3h</sup> × c (পুষ্টি ও জায়গা সীমিত না হলে)।',
  types: { x: ['হিসাব', 'কোষ ও জিনের কপি সংখ্যা', 'স্লাইডার বদলে দেখো — রাতভর (১২ ঘণ্টা) কালচারে তাত্ত্বিকভাবে কোটি কোটি কোষ।'] },
  art(g, C, ty, ctx) {
    const h = ctx.v.h, c = ctx.v.c, gen = 3 * h, P = B.axes(g, C, [52, 30, 276, 150], { xr: [0, 12], yr: [0, 14], xt: [0, 3, 6, 9, 12], yt: [0, 4, 8, 12], yf: v => v === 0 ? '1' : ch('10^{' + v + '}'), xf: v => bn(v), lx: 'সময় (ঘণ্টা)', ly: 'কপি (লগ স্কেল)' });
    ctx.P = P; const Rc = BK.ramp(0), Ra = Rg();
    B.curve(g, P, x => Math.min(14, 3 * x * Math.log10(2)), 0, h, { stroke: Rc.c }); B.curve(g, P, x => Math.min(14, 3 * x * Math.log10(2) + Math.log10(c)), 0, h, { stroke: Ra.c, 'stroke-dasharray': '5 3' });
    const cells = 2 ** gen, copies = cells * c; ctx.cells = cells;
    E('rect', { x: 60, y: 34, width: 196, height: 36, rx: 8, fill: C.sf, stroke: C.ln }, g);
    T(g, 68, 48, ch(`কোষ = 2^{${gen}}`) + ` ≈ ${cells >= 1e6 ? FK.n(cells / 1e6, 1) + ' মিলিয়ন' : FK.n(cells, 0)}`, { fs: 10, w: 650, c: Rc.ink });
    T(g, 68, 64, `জিনের কপি ≈ ${copies >= 1e9 ? FK.n(copies / 1e9, 1) + ' বিলিয়ন' : copies >= 1e6 ? FK.n(copies / 1e6, 1) + ' মিলিয়ন' : FK.n(copies, 0)}`, { fs: 10, w: 650, c: Ra.ink });
    ctx.selInfo = () => `<b>${bn(h)} ঘণ্টা = ${bn(gen)} প্রজন্ম</b> → কোষ 2<sup>${gen}</sup> = ${FK.n(cells, 0)}; কোষপ্রতি ${c}টি প্লাসমিডে জিনের কপি ≈ ${FK.n(copies, 0)}।<div class="small">সবুজ রেখা — কোষ; অ্যাম্বার ড্যাশ — জিনের কপি। বাস্তবে কয়েক ঘণ্টা পর পুষ্টি ফুরিয়ে বৃদ্ধি থেমে যায় (স্থিতি দশা) — সাধারণ ফ্লাস্কে প্রতি মিলিলিটারে প্রায় 10<sup>9</sup> কোষ পর্যন্ত।</div>`;
  },
  anim(g, C, ty, t, ctx) { if (!t || !ctx.P) return; const h = ctx.v.h, x = ((t * .4) % 1) * h, [px, py] = ctx.P(x, 3 * x * Math.log10(2)); E('circle', { cx: px, cy: py, r: 6, fill: FK.alpha(BK.ramp(0).c, .3) }, g); E('circle', { cx: px, cy: py, r: 3.2, fill: BK.ramp(0).dk }, g); }
}));

/* ═════════ ৭. cDNA তৈরি ═════════ */
V.cdnaMake = Object.assign({ t: 'mRNA থেকে cDNA — রিভার্স ট্রান্সক্রিপশন', k: ['anim', 'steps'], cap: 'প্রকৃতকোষী জিনে ইন্ট্রন থাকে, কিন্তু ব্যাকটেরিয়া ইন্ট্রন কেটে বাদ দিতে পারে না। তাই পরিণত mRNA (ইন্ট্রনবিহীন) থেকে রিভার্স ট্রান্সক্রিপ্টেজ এনজাইমে পরিপূরক DNA (cDNA) তৈরি করে বাহকে বসানো হয় — ইনসুলিন, ইন্টারফেরন, গ্রোথ হরমোন উৎপাদনে এ কৌশল ব্যবহৃত।' }, BK.steps({
  W: 360, H: 220, label: 'cDNA তৈরির ধাপ', dur: 3,
  stages: [
    { t: 'mRNA পৃথকীকরণ', en: 'mRNA', d: 'যে কোষে জিনটি বেশি প্রকাশিত (যেমন অগ্ন্যাশয়ের বিটা কোষে ইনসুলিন mRNA) সেখান থেকে mRNA সংগ্রহ; এর ৩\' প্রান্তের পলি-A লেজ ধরে oligo-dT দিয়ে আলাদা করা যায়।' },
    { t: 'প্রাইমার ও রিভার্স ট্রান্সক্রিপ্টেজ', en: 'Reverse transcription', d: 'পলি-A লেজে oligo-dT প্রাইমার জোড় বাঁধে; রেট্রোভাইরাসের এনজাইম রিভার্স ট্রান্সক্রিপ্টেজ mRNA কে ছাঁচ ধরে পরিপূরক DNA সূত্র (cDNA) তৈরি করে — RNA:DNA সংকর।' },
    { t: 'RNA অপসারণ', en: 'RNase H', d: 'RNase H বা ক্ষার দিয়ে mRNA সূত্র ভেঙে সরানো হয় — একসূত্রক cDNA থাকে।' },
    { t: 'দ্বিসূত্রক cDNA', en: 'Second strand', d: 'DNA পলিমারেজ প্রথম cDNA কে ছাঁচ ধরে দ্বিতীয় সূত্র তৈরি করে — দ্বিসূত্রক, ইন্ট্রনবিহীন জিন; এটি বাহকে বসিয়ে ব্যাকটেরিয়ায় প্রকাশ করা যায়।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Rm = BK.ramp(2), Rd = Rg(), x0 = 40, x1 = 300, y = 100;
    const rna = (op = 1) => { E('path', { d: `M${x0} ${y}H${x1}`, stroke: Rm.c, 'stroke-width': 3.4, opacity: op, 'stroke-linecap': 'round' }, g); for (let x = x0 + 6; x < x1; x += 10) E('path', { d: `M${x} ${y}v8`, stroke: Rm.dk, 'stroke-width': 1.2, opacity: op }, g); T(g, x1 + 6, y + 4, 'AAAA', { fs: 9.5, w: 700, c: Rm.ink, op }); T(g, x0 - 4, y - 6, "5'", { fs: 9, a: 'end', c: C.mu }); };
    if (s === 0) { rna(k); T(g, 170, 70, 'পরিণত mRNA (ইন্ট্রনবিহীন) + পলি-A লেজ', { fs: 10, a: 'middle', c: Rm.ink }); return; }
    if (s === 1) { rna(); const xe = x1 - (x1 - x0) * k; E('path', { d: `M${x1} ${y + 16}H${xe}`, stroke: Rd.c, 'stroke-width': 3.4, 'stroke-linecap': 'round' }, g); E('path', { d: `M${x1 + 30} ${y + 16}H${x1}`, stroke: BK.ramp(9).c, 'stroke-width': 3.4 }, g); T(g, x1 + 20, y + 32, 'TTTT', { fs: 9, a: 'middle', c: C.mu }); E('ellipse', { cx: xe, cy: y + 10, rx: 18, ry: 14, fill: FK.alpha(BK.ramp(3).c, .3), stroke: BK.ramp(3).dk }, g); T(g, 170, 160, 'রিভার্স ট্রান্সক্রিপ্টেজ — RNA → DNA', { fs: 10.5, a: 'middle', w: 650, c: BK.ramp(3).ink }); return; }
    if (s === 2) { rna(1 - k); E('path', { d: `M${x0} ${y + 16}H${x1}`, stroke: Rd.c, 'stroke-width': 3.4 }, g); for (let i = 0; i < 6; i++) if (k > .3) E('circle', { cx: x0 + 20 + i * 44, cy: y - 14 - 20 * k, r: 2.5, fill: Rm.c, opacity: 1 - k * .7 }, g); T(g, 170, 160, 'RNase H — mRNA ভেঙে সরানো', { fs: 10.5, a: 'middle', c: C.fg }); return; }
    E('path', { d: `M${x0} ${y + 16}H${x1}`, stroke: Rd.c, 'stroke-width': 3.4 }, g); E('path', { d: `M${x0} ${y}H${x0 + (x1 - x0) * k}`, stroke: Rd.dk, 'stroke-width': 3.4 }, g); for (let x = x0 + 6; x < x0 + (x1 - x0) * k; x += 10) E('path', { d: `M${x} ${y + 2}v12`, stroke: Rd.c, 'stroke-width': 1.2 }, g); T(g, 170, 160, 'DNA পলিমারেজ → দ্বিসূত্রক cDNA', { fs: 10.5, a: 'middle', w: 650, c: Rd.ink });
  }
}));

/* ═════════ ৮. বাহকের ধারণক্ষমতা ═════════ */
const VEC = [
  ['প্লাসমিড', 3, .1, 10, 'pBR322, pUC — সাধারণত ১০ kb পর্যন্ত বিদেশি DNA; সহজ, সস্তা, বহু কপি। E. coli তে।'],
  ['λ ফাজ', 5, 9, 23, 'ব্যাকটেরিওফাজ লাম্বডা — অপ্রয়োজনীয় মাঝের অংশ সরিয়ে প্রায় ৯–২৩ kb; ফাজ কণায় প্যাকেজিং হয়ে দক্ষভাবে কোষে ঢোকে।'],
  ['কসমিড', 0, 35, 45, 'প্লাসমিড + λ ফাজের cos সাইট — ৩৫–৪৫ kb; ফাজের মতো প্যাকেজিং, প্লাসমিডের মতো প্রতিলিপন।'],
  ['BAC', 1, 100, 300, 'ব্যাকটেরিয়াল কৃত্রিম ক্রোমোসোম (F প্লাসমিড ভিত্তিক) — ১০০–৩০০ kb; স্থিতিশীল, মানব জিনোম প্রকল্পে বহুল ব্যবহৃত।'],
  ['YAC', 6, 100, 2000, 'ইস্ট কৃত্রিম ক্রোমোসোম — সেন্ট্রোমিয়ার, টেলোমিয়ার ও ori যুক্ত; ১০০ kb থেকে প্রায় ২ Mb পর্যন্ত; ইস্টে প্রতিলিপিত।'],
  ['Ti প্লাসমিড', 10, 1, 50, 'Agrobacterium এর Ti প্লাসমিড থেকে তৈরি উদ্ভিদ বাহক (বাইনারি ভেক্টর) — T-DNA অংশে জিন বসিয়ে উদ্ভিদের ক্রোমোসোমে স্থানান্তর।']
];
V.vectorCap = Object.assign({}, B.seg({
  id: 'vcp', t: 'ক্লোনিং বাহক ও তাদের ধারণক্ষমতা', H: 236, def: 'x', sel: 0,
  cap: 'বাহক (ভেক্টর) — যে DNA অণু বিদেশি জিন বহন করে পোষক কোষে নিয়ে যায় ও সেখানে প্রতিলিপিত হয়। আদর্শ বাহকের বৈশিষ্ট্য: ছোট আকার, প্রতিলিপন সূচনা বিন্দু (ori), বাছাই চিহ্নক জিন, একক রেস্ট্রিকশন সাইট, বেশি কপি সংখ্যা, সহজে পোষকে প্রবেশ। বারে চাপ দাও।',
  types: { x: ['ধারণক্ষমতা', 'কত বড় DNA খণ্ড বহন করতে পারে (লগ স্কেল)', 'বড় জিন বা জিনোম লাইব্রেরির জন্য বড় ধারণক্ষমতার বাহক দরকার।'] },
  art(g, C, ty, ctx) {
    const x0 = 96, w = 240, lg = v => x0 + (Math.log10(v) + 1) / 4.4 * w;
    [0.1, 1, 10, 100, 1000].forEach(v => { const x = lg(v); E('path', { d: `M${x} 16V214`, stroke: C.ln, opacity: .5 }, g); T(g, x, 228, v >= 1000 ? '1 Mb' : FK.n(v, v < 1 ? 1 : 0) + ' kb', { fs: 9, a: 'middle', c: C.mu }); });
    VEC.forEach(([s, ri, a, b], i) => { const y = 24 + i * 32, R = BK.ramp(ri), on = ctx.sel === i; T(g, x0 - 8, y + 12, s, { fs: 10.5, a: 'end', w: on ? 700 : 550, c: C.fg }); E('rect', { x: lg(a), y, width: lg(b) - lg(a), height: 18, rx: 6, fill: FK.alpha(R.c, on ? .7 : .4), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g); });
    ctx.selInfo = () => { const v = VEC[ctx.sel]; return `<b>${v[0]}</b> — ${v[4]}`; };
  },
  anim(g, C, ty, t) { if (!t) return; const i = Math.floor(t * .5) % VEC.length, y = 24 + i * 32; E('rect', { x: 2, y: y - 3, width: 356, height: 24, rx: 6, fill: 'none', stroke: BK.ramp(VEC[i][1]).c, 'stroke-width': 1.4, opacity: .6 }, g); },
  tap(x, y, ty, ctx) { const i = Math.floor((y - 20) / 32); if (i < 0 || i >= VEC.length) return null; ctx.sel = i; const v = VEC[i]; return `<b>${v[0]}</b> — ${v[4]}`; }
}));

/* ═════════ ৯. PCR ═════════ */
const thermo = (g, C, x, y, w, h, u, R) => { const pts = [[0, 72], [.08, 95], [.3, 95], [.36, 55], [.6, 55], [.66, 72], [.92, 72], [1, 72]]; const P = ([a, b]) => [x + a * w, y + h - (b - 40) / 60 * h]; E('path', { d: pts.map((p, i) => (i ? 'L' : 'M') + P(p).join(' ')).join(''), stroke: R.c, 'stroke-width': 2.4, fill: 'none' }, g); [[95, 'ঐ'], [72, ''], [55, '']].forEach(([v]) => { const [, py] = P([0, v]); T(g, x - 4, py + 3, v + ' °C', { fs: 8.5, a: 'end', c: C.mu }); }); if (u != null) { const [px, py] = P(B.along(pts, u)); E('circle', { cx: px, cy: py, r: 4.5, fill: R.dk }, g); } };
V.pcrCycle = Object.assign({ t: 'পলিমারেজ চেইন রিঅ্যাকশন (PCR) — একটি চক্র', k: ['anim', 'steps'], cap: 'PCR — পরীক্ষানলে (ইন ভিট্রো) DNA এর নির্দিষ্ট অংশের কোটি কোটি কপি কয়েক ঘণ্টায় তৈরির পদ্ধতি; ক্যারি মুলিস (1983, নোবেল 1993)। থার্মাল সাইক্লার যন্ত্রে তিন তাপমাত্রার চক্র ২৫–৩৫ বার ঘোরে। উপাদান: ছাঁচ DNA, দুটি প্রাইমার, চার dNTP, তাপসহিষ্ণু Taq পলিমারেজ, Mg<sup>2+</sup> যুক্ত বাফার।' }, BK.steps({
  W: 360, H: 240, label: 'PCR এর ধাপ', dur: 3,
  stages: [
    { t: 'উপাদান মেশানো', en: 'Reaction mix', d: 'একটি ছোট নলে ছাঁচ DNA (কাঙ্ক্ষিত অংশসহ), লক্ষ্য অংশের দুই প্রান্তের পরিপূরক দুটি প্রাইমার (প্রায় ১৮–২৫ নিউক্লিওটাইড), dATP-dTTP-dGTP-dCTP, Taq DNA পলিমারেজ ও Mg<sup>2+</sup> যুক্ত বাফার।' },
    { t: 'ডিন্যাচারেশন — 94–96 °C', en: 'Denaturation', d: 'উচ্চ তাপে দুই সূত্রের মধ্যকার হাইড্রোজেন বন্ধন ভেঙে DNA একসূত্রক হয় (২০–৩০ সেকেন্ড)।' },
    { t: 'অ্যানিলিং — 50–65 °C', en: 'Annealing', d: 'তাপমাত্রা কমালে প্রাইমার দুটি নিজ নিজ ছাঁচ সূত্রের পরিপূরক অংশে জোড় বাঁধে — লক্ষ্য অংশের দুই প্রান্তে (২০–৪০ সেকেন্ড)।' },
    { t: 'এক্সটেনশন — 72 °C', en: 'Extension', d: 'Taq পলিমারেজ (উষ্ণ প্রস্রবণের ব্যাকটেরিয়া Thermus aquaticus থেকে; সর্বোত্তম 72 °C) প্রাইমারের ৩\' প্রান্ত থেকে dNTP যোগ করে নতুন সূত্র তৈরি করে (প্রতি kb এ প্রায় ১ মিনিট)।' },
    { t: 'চক্র শেষে দ্বিগুণ', en: 'Doubling', d: 'একটি চক্রে লক্ষ্য DNA দ্বিগুণ — n চক্রে 2<sup>n</sup> গুণ; ৩০ চক্রে প্রায় 10<sup>9</sup> (১০০ কোটির বেশি) কপি, সময় ১.৫–২ ঘণ্টা। Taq উচ্চ তাপে নষ্ট হয় না, তাই প্রতি চক্রে নতুন এনজাইম লাগে না।' }
  ],
  draw(g, C, s, u) {
    const k = FK.ease(u), Rt = BK.ramp(9), Rn = Rg(), Rpm = BK.ramp(4), Rq = BK.ramp(3), x0 = 70, x1 = 290;
    thermo(g, C, 220, 16, 120, 50, s === 0 ? null : s === 1 ? .08 + .22 * u : s === 2 ? .36 + .24 * u : s === 3 ? .66 + .26 * u : u, BK.ramp(4));
    if (s === 0) { E('path', { d: 'M60 90h44l-6 90q-16 14 -32 0z', fill: FK.alpha(BK.ramp(5).c, .15), stroke: C.fg, 'stroke-width': 1.3 }, g); E('rect', { x: 56, y: 82, width: 52, height: 10, rx: 3, fill: '#e2e2e2', stroke: C.mu }, g); [[70, 150, Rt], [82, 130, Rpm], [92, 160, Rq], [76, 168, Rn]].forEach(([x, y, R]) => E('circle', { cx: x + 4 * Math.sin(k * 6 + x), cy: y, r: 4, fill: R.c }, g)); ['ছাঁচ DNA', 'প্রাইমার', 'Taq পলিমারেজ', 'dNTP'].forEach((sx, i) => { const R = [Rt, Rpm, Rq, Rn][i]; E('circle', { cx: 140, cy: 110 + i * 22, r: 5, fill: R.c }, g); T(g, 152, 114 + i * 22, sx, { fs: 10, c: C.fg }); }); return; }
    const gap = s === 1 ? 6 + 30 * k : 36;
    if (s >= 1 && s <= 3) {
      E('path', { d: `M${x0} ${130 - gap / 2}H${x1}`, stroke: Rt.dk, 'stroke-width': 3 }, g); E('path', { d: `M${x0} ${136 + gap / 2}H${x1}`, stroke: Rt.dk, 'stroke-width': 3 }, g);
      if (s === 1) for (let x = x0 + 6; x < x1; x += 10) E('path', { d: `M${x} ${130 - gap / 2 + 2}V${136 + gap / 2 - 2}`, stroke: Rt.c, 'stroke-width': 1, opacity: 1 - k }, g);
      E('rect', { x: 120, y: 112, width: 120, height: 44, fill: FK.alpha(Rn.c, .08), stroke: Rn.c, 'stroke-dasharray': '3 3' }, g); T(g, 180, 196, 'লক্ষ্য অংশ', { fs: 9.5, a: 'middle', c: C.mu });
      if (s >= 2) { const pk = s === 2 ? k : 1; E('path', { d: `M${120} ${130 - gap / 2 + 7 + (1 - pk) * 20}h26`, stroke: Rpm.c, 'stroke-width': 3.4, opacity: pk }, g); E('path', { d: `M${214} ${136 + gap / 2 - 7 - (1 - pk) * 20}h26`, stroke: Rpm.c, 'stroke-width': 3.4, opacity: pk }, g); }
      if (s === 3) { E('path', { d: `M146 ${130 - gap / 2 + 7}H${146 + (x1 - 146) * k}`, stroke: Rn.c, 'stroke-width': 3 }, g); E('path', { d: `M214 ${136 + gap / 2 - 7}H${214 - (214 - x0) * k}`, stroke: Rn.c, 'stroke-width': 3 }, g); E('ellipse', { cx: 146 + (x1 - 146) * k, cy: 130 - gap / 2 + 7, rx: 10, ry: 8, fill: FK.alpha(Rq.c, .4), stroke: Rq.dk }, g); E('ellipse', { cx: 214 - (214 - x0) * k, cy: 136 + gap / 2 - 7, rx: 10, ry: 8, fill: FK.alpha(Rq.c, .4), stroke: Rq.dk }, g); }
      T(g, 100, 40, ['', 'দুই সূত্র আলাদা', 'প্রাইমার জোড় বাঁধে', 'Taq নতুন সূত্র বানায়'][s], { fs: 11, a: 'middle', w: 650, c: C.fg });
      return;
    }
    const n = 1 + Math.floor(k * 3.99), m = 2 ** n; for (let i = 0; i < m; i++) { const y = 96 + i * (100 / m); E('path', { d: `M110 ${y}h140M110 ${y + 4}h140`, stroke: i % 2 ? Rn.c : Rt.dk, 'stroke-width': 1.6 }, g); }
    T(g, 100, 40, `${bn(n)} চক্র → ${bn(m)} কপি`, { fs: 12, a: 'middle', w: 700, c: C.fg });
  }
}));
V.pcrCount = Object.assign({}, B.seg({
  id: 'pcn', t: 'PCR এ কপি সংখ্যার হিসাব — 2<sup>n</sup>', H: 236, def: 'x',
  sl: [{ k: 'n', l: 'চক্র n', min: 1, max: 40, step: 1, val: 30 }, { k: 'm', l: 'শুরুর অণু m', min: 1, max: 1000, step: 1, val: 1 }],
  cap: 'প্রতিটি চক্রে DNA এর পরিমাণ দ্বিগুণ — শুরুতে m টি অণু থাকলে n চক্রে তাত্ত্বিক কপি = m × 2<sup>n</sup>। নির্দিষ্ট দৈর্ঘ্যের লক্ষ্য খণ্ড (দুই প্রাইমারের মাঝের অংশ) একটি দ্বিসূত্রক ছাঁচ থেকে n চক্রে 2<sup>n</sup> − 2n টি। বাস্তবে ২৫–৩০ চক্রের পর প্রাইমার ও dNTP ফুরিয়ে এলে বৃদ্ধি থেমে যায় (মালভূমি বা প্লাটো দশা)।',
  types: { x: ['হিসাব', 'n চক্রে কপি সংখ্যা', 'স্লাইডার সরাও — প্রতি ১০ চক্রে প্রায় ১০০০ গুণ (2<sup>10</sup> = 1024)।'] },
  art(g, C, ty, ctx) {
    const n = ctx.v.n, m = ctx.v.m, P = B.axes(g, C, [52, 30, 276, 150], { xr: [0, 40], yr: [0, 15], xt: [0, 10, 20, 30, 40], yt: [0, 3, 6, 9, 12, 15], yf: v => v === 0 ? '1' : ch('10^{' + v + '}'), xf: v => bn(v), lx: 'চক্র', ly: 'কপি (লগ স্কেল)' });
    ctx.P = P; const R = BK.ramp(4), Rq = BK.ramp(0), cap = 12.5;
    B.curve(g, P, x => Math.min(15, Math.log10(m) + x * Math.log10(2)), 0, n, { stroke: FK.alpha(R.c, .6), 'stroke-dasharray': '5 3' });
    B.curve(g, P, x => { const th = Math.log10(m) + x * Math.log10(2); return th < cap - 1 ? th : cap - Math.exp(-(th - (cap - 1))) ; }, 0, n, { stroke: Rq.c });
    const th = m * 2 ** n, tg = 2 ** n - 2 * n;
    E('rect', { x: 60, y: 34, width: 220, height: 36, rx: 8, fill: C.sf, stroke: C.ln }, g);
    T(g, 68, 48, ch(`তাত্ত্বিক = ${m} × 2^{${n}}`) + ` ≈ ${th >= 1e9 ? FK.n(th / 1e9, 2) + ' বিলিয়ন' : th >= 1e6 ? FK.n(th / 1e6, 2) + ' মিলিয়ন' : FK.n(th, 0)}`, { fs: 10, w: 650, c: R.ink });
    T(g, 68, 64, ch(`লক্ষ্য খণ্ড (m = ১ হলে) = 2^{${n}} − ${2 * n}`) + ` = ${FK.n(Math.max(tg, 0), 0)}`, { fs: 9.5, c: C.mu });
    ctx.selInfo = () => `<b>${bn(n)} চক্রে:</b> ${m} × 2<sup>${n}</sup> = <b>${FK.n(th, 0)}</b> কপি (তাত্ত্বিক)।<div class="small">লাল ড্যাশ — তাত্ত্বিক সূচকীয় বৃদ্ধি; টিল রেখা — বাস্তবে উপাদান ফুরিয়ে মালভূমি দশা (প্রায় 10<sup>12</sup> কপির কাছে)।</div>`;
  },
  anim(g, C, ty, t, ctx) { if (!t || !ctx.P) return; const n = ctx.v.n, x = ((t * .3) % 1) * n, [px, py] = ctx.P(x, Math.min(15, Math.log10(ctx.v.m) + x * Math.log10(2))); E('circle', { cx: px, cy: py, r: 4, fill: BK.ramp(4).dk }, g); }
}));

/* ═════════ তুলনা ═════════ */
V.cmpTcRdna = cmp('টিস্যু কালচার বনাম রিকম্বিনেন্ট DNA প্রযুক্তি', 'দুটিই জীবপ্রযুক্তির মৌলিক কৌশল — একটি কোষ থেকে উদ্ভিদ বানায়, অন্যটি জিন বদলায়।', 'টিস্যু কালচার', 'রিকম্বিনেন্ট DNA প্রযুক্তি', [
  ['মূলনীতি', 'কোষের টটিপোটেন্সি', 'জিন কাটা-জোড়া ও স্থানান্তর'],
  ['কাজের একক', 'কোষ, টিস্যু বা অঙ্গ', 'DNA অণু বা জিন'],
  ['জিনগত পরিবর্তন', 'সাধারণত নেই — মাতৃসম ক্লোন', 'নতুন জিন যুক্ত — জিনগত পরিবর্তিত জীব'],
  ['প্রয়োজনীয় উপকরণ', 'পুষ্টি মাধ্যম, হরমোন, জীবাণুমুক্ত গবেষণাগার', 'রেস্ট্রিকশন এনজাইম, লাইগেজ, বাহক, পোষক কোষ'],
  ['প্রজাতির সীমা', 'একই উদ্ভিদ (দেহজ সংকরে কাছের প্রজাতি)', 'যেকোনো জীব থেকে যেকোনো জীবে'],
  ['ফল', 'অসংখ্য চারা', 'ট্রান্সজেনিক জীব, রিকম্বিনেন্ট প্রোটিন'],
  ['উদাহরণ', 'কলা, আলুর ভাইরাসমুক্ত চারা', 'ইনসুলিন উৎপাদন, Bt বেগুন']
]);
V.cmpRdnaPcr = cmp('rDNA প্রযুক্তি বনাম PCR', 'দুটিতেই জিনের অনেক কপি তৈরি হয় — একটি জীবিত কোষে, অন্যটি পরীক্ষানলে।', 'rDNA প্রযুক্তি (জিন ক্লোনিং)', 'PCR', [
  ['স্থান', 'জীবিত পোষক কোষে (ইন ভিভো)', 'পরীক্ষানলে (ইন ভিট্রো)'],
  ['প্রয়োজনীয় উপকরণ', 'রেস্ট্রিকশন এনজাইম, লাইগেজ, বাহক, পোষক', 'প্রাইমার, Taq পলিমারেজ, dNTP, থার্মাল সাইক্লার'],
  ['সময়', 'কয়েক দিন থেকে সপ্তাহ', 'কয়েক ঘণ্টা'],
  ['ক্রম জানা দরকার', 'না-ও হতে পারে', 'প্রাইমারের জন্য দুই প্রান্তের ক্রম জানা আবশ্যক'],
  ['খণ্ডের আকার', 'বড় খণ্ডও (BAC, YAC এ লক্ষ bp)', 'সাধারণত কয়েক kb পর্যন্ত'],
  ['প্রোটিন উৎপাদন', 'জিন প্রকাশ করে প্রোটিন তৈরি সম্ভব', 'শুধু DNA এর কপি; প্রোটিন নয়'],
  ['উদ্ভাবক', 'বার্গ (1972), কোহেন ও বয়ার (1973)', 'ক্যারি মুলিস (1983)']
]);
V.cmpPlasmidChromo = cmp('প্লাসমিড বনাম ব্যাকটেরিয়ার ক্রোমোসোম', 'দুটিই ব্যাকটেরিয়ার দ্বিসূত্রক DNA — পার্থক্য আকার ও অপরিহার্যতায়।', 'প্লাসমিড', 'ক্রোমোসোম', [
  ['আকার', 'ছোট — সাধারণত ১–২০০ kb', 'বড় — E. coli তে প্রায় 4600 kb'],
  ['সংখ্যা', 'কোষপ্রতি ১ থেকে শত শত কপি', 'সাধারণত একটি'],
  ['অপরিহার্যতা', 'বেঁচে থাকার জন্য অপরিহার্য নয়', 'অপরিহার্য — মৌলিক জিন'],
  ['জিন', 'বিশেষ সুবিধার জিন — অ্যান্টিবায়োটিক প্রতিরোধ, টক্সিন, কনজুগেশন', 'বিপাক, প্রতিলিপন, প্রোটিন সংশ্লেষণের জিন'],
  ['স্থানান্তর', 'সহজে অন্য কোষে যায় (কনজুগেশন, ট্রান্সফরমেশন)', 'সাধারণত যায় না'],
  ['জিন প্রকৌশলে', 'প্রধান বাহক', 'বাহক হিসেবে ব্যবহৃত হয় না']
]);
V.cmpStickyBlunt = cmp('স্টিকি এন্ড বনাম ব্লান্ট এন্ড', 'রেস্ট্রিকশন এনজাইম কাটার ধরনে দুই রকম প্রান্ত তৈরি হয়।', 'স্টিকি এন্ড (আঠালো প্রান্ত)', 'ব্লান্ট এন্ড (ভোঁতা প্রান্ত)', [
  ['কাটার ধরন', 'দুই সূত্রে সরানো স্থানে কাটে', 'দুই সূত্রে একই স্থানে কাটে'],
  ['প্রান্ত', 'কয়েকটি এক-সূত্রক বাড়তি ক্ষারক', 'কোনো বাড়তি ক্ষারক নেই'],
  ['জোড়া লাগা', 'পরিপূরক প্রান্তে সহজে ও দক্ষভাবে', 'যেকোনো ব্লান্ট প্রান্তে, তবে কম দক্ষতায়'],
  ['দিকনির্দিষ্টতা', 'ভিন্ন দুই এনজাইমে কাটলে নির্দিষ্ট দিকে বসানো যায়', 'দিক নিয়ন্ত্রণ করা যায় না'],
  ['উদাহরণ', 'EcoRI, BamHI, HindIII, PstI', 'SmaI, AluI, HaeIII, EcoRV']
]);
})();
