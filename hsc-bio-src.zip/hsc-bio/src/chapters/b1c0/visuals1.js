/* ═══════════════════════════════════════════════════════════════════
   visuals1 — উদ্ভিদ কারা ও শ্রেণিবিন্যাস কী:
   plantCellTraits (উদ্ভিদকোষের বৈশিষ্ট্যসূচক অংশ), plantGroups (শৈবাল থেকে আবৃতবীজী — নমুনা উদ্ভিদ),
   taxonomyPillars (ট্যাক্সোনমির চার কাজ), groupingSteps (ধাপে ধাপে দলে ভাগ করা)
   সহায়ক: B.spirogyra, B.moss, B.fern, B.cycas, B.mustard, B.icon (defs + use)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const P2 = pts => pts.map((p, i) => (i ? 'L' : 'M') + f1(p[0]) + ' ' + f1(p[1])).join('');
B.P2 = P2;

/* ─── পাতার আকৃতি: ভিত্তি (x,y) থেকে কোণ a তে দৈর্ঘ্য L, প্রস্থ w ─── */
const leafD = (x, y, a, L, w, tip = .55) => { const c = Math.cos(a), s = Math.sin(a), q = (u, v) => [x + u * c - v * s, y + u * s + v * c];
  const p1 = q(L * .35, w), p2 = q(L * tip + L * .2, w * .7), e = q(L, 0), p3 = q(L * tip + L * .2, -w * .7), p4 = q(L * .35, -w);
  return `M${f1(x)} ${f1(y)}C${f1(p1[0])} ${f1(p1[1])} ${f1(p2[0])} ${f1(p2[1])} ${f1(e[0])} ${f1(e[1])}C${f1(p3[0])} ${f1(p3[1])} ${f1(p4[0])} ${f1(p4[1])} ${f1(x)} ${f1(y)}Z`; };
B.leafD = leafD;
const lab = (g, ax, ay, lx, ly, s, C, an) => { E('path', { d: `M${f1(ax)} ${f1(ay)}L${f1(lx)} ${f1(ly)}`, stroke: FK.alpha(C.fg, .55), 'stroke-width': .8 }, g); E('circle', { cx: f1(ax), cy: f1(ay), r: 1.8, fill: C.fg }, g);
  B.tx(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 3.5, s, { fs: 9.6, a: an || 'start', c: C.fg }); };
B.labL = lab;

/* ═════════ উদ্ভিদকোষ: উদ্ভিদের বৈশিষ্ট্যসূচক অংশ ═════════ */
V.plantCellTraits = Object.assign({ t: 'উদ্ভিদকোষ: উদ্ভিদ চেনার কোষীয় বৈশিষ্ট্য', k: ['2d', 'int', 'quiz'], cap: 'একটি পরিণত পাতার মেসোফিল কোষের রেখাচিত্র (আলোক অণুবীক্ষণে যা দেখা যায় তার সাথে ইলেকট্রন অণুবীক্ষণের কিছু অংশ যোগ করা)। সেলুলোজের কোষপ্রাচীর, ক্লোরোপ্লাস্ট ও বড় কেন্দ্রীয় কোষগহ্বর — এ তিনটি উদ্ভিদকোষকে প্রাণীকোষ থেকে আলাদা করে। পাশের কোষের সাথে প্লাজমোডেসমাটা দিয়ে সংযোগ থাকে।' },
  BK.diagram({ W: 360, H: 300, label: 'উদ্ভিদকোষ',
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), W0 = B.TS('cwall'), X0 = 78, Y0 = 46, X1 = 284, Y1 = 250;
      /* পাশের কোষের অংশ (প্রাচীর ভাগ করা) */
      E('rect', { x: 20, y: 20, width: 320, height: 256, rx: 6, fill: FK.alpha(W0.lt, .55) }, g);
      const cellD = (x0, y0, x1, y1, r) => `M${x0 + r} ${y0}H${x1 - r}Q${x1} ${y0} ${x1} ${y0 + r}V${y1 - r}Q${x1} ${y1} ${x1 - r} ${y1}H${x0 + r}Q${x0} ${y1} ${x0} ${y1 - r}V${y0 + r}Q${x0} ${y0} ${x0 + r} ${y0}Z`;
      /* কোষপ্রাচীর: বাইরের ও ভেতরের সীমার মাঝখান ভরাট; মধ্যপর্দা */
      E('path', { d: cellD(X0 - 8, Y0 - 8, X1 + 8, Y1 + 8, 14) + cellD(X0, Y0, X1, Y1, 9), fill: W0.c, 'fill-rule': 'evenodd', stroke: W0.dk, 'stroke-width': .7 }, P('wall'));
      E('path', { d: cellD(X0 - 8, Y0 - 8, X1 + 8, Y1 + 8, 14), fill: 'none', stroke: '#7a6a3a', 'stroke-width': 1.3 }, P('wall'));
      for (let i = 0; i < 26; i++) { const t = i / 26, x = lerp(X0 - 4, X1 + 4, t); E('path', { d: `M${f1(x)} ${Y0 - 7}l2.4 5`, stroke: FK.alpha(W0.dk, .35), 'stroke-width': .5 }, P('wall')); E('path', { d: `M${f1(x)} ${Y1 + 2}l2.4 5`, stroke: FK.alpha(W0.dk, .35), 'stroke-width': .5 }, P('wall')); }
      /* প্লাজমোডেসমাটা: প্রাচীরের ফাঁক দিয়ে সাইটোপ্লাজমের সুতা */
      [[X0 - 8, 110], [X0 - 8, 180], [X1, 140], [X1, 200], [150, Y0 - 8], [220, Y1]].forEach(([x, y], i) => { const hz = i < 4;
        E('rect', hz ? { x, y: y - 2, width: 8, height: 4, fill: B.TS('pcyt').c } : { x: x - 2, y, width: 4, height: 8, fill: B.TS('pcyt').c }, P('pd'));
        E('path', { d: hz ? `M${x - 3} ${y}H${x + 11}` : `M${x} ${y - 3}V${y + 11}`, stroke: '#6a7a4a', 'stroke-width': .8 }, P('pd')); });
      /* সাইটোপ্লাজম ও কোষঝিল্লি */
      E('path', { d: cellD(X0, Y0, X1, Y1, 9), fill: B.TS('pcyt').c, stroke: 'none' }, g);
      E('path', { d: cellD(X0 + 1.6, Y0 + 1.6, X1 - 1.6, Y1 - 1.6, 8), fill: 'none', stroke: '#3e5a7a', 'stroke-width': 1.1 }, P('mem'));
      /* কেন্দ্রীয় কোষগহ্বর (টোনোপ্লাস্টসহ) */
      const VD = 'M112 84C140 70 228 70 252 86C268 100 268 196 252 212C232 226 150 228 118 214C100 200 96 100 112 84Z';
      E('path', { d: VD, fill: B.vol(g, 'vac'), stroke: '#4a7a9a', 'stroke-width': 1.2 }, P('vac'));
      for (let i = 0; i < 5; i++) E('path', { d: `M${130 + i * 24} ${120 + (i % 2) * 40}q6 -4 12 0`, stroke: FK.alpha('#4a7a9a', .35), 'stroke-width': .8, fill: 'none' }, P('vac'));
      /* নিউক্লিয়াস (একপাশে চাপা) */
      E('path', { d: B.ellD(102, 232, 19, 12, -8), fill: B.vol(g, 'nuc'), stroke: '#31266a', 'stroke-width': .9 }, P('nuc'));
      E('circle', { cx: 98, cy: 231, r: 4.4, fill: '#2a1e5a' }, P('nuc')); for (let i = 0; i < 9; i++) { const a = i / 9 * 2 * PI; E('circle', { cx: f1(102 + Math.cos(a) * 18.6), cy: f1(232 + Math.sin(a) * 11.6), r: .9, fill: '#e8e4f8' }, P('nuc')); }
      for (let i = 0; i < 12; i++) E('circle', { cx: f1(94 + B.rnd(i) * 18), cy: f1(226 + B.rnd(i + 20) * 12), r: .8, fill: FK.alpha('#1a1040', .6) }, P('nuc'));
      /* ক্লোরোপ্লাস্ট: পরিধি বরাবর, গ্রানা */
      const CH = [[94, 62, 20], [140, 56, 0], [196, 56, -6], [250, 60, 10], [272, 104, 80], [274, 160, 95], [270, 218, 120], [226, 238, 175], [168, 240, 180], [88, 128, 95], [88, 182, 80]];
      CH.forEach(([x, y, a]) => { const gg = E('g', { transform: `translate(${x} ${y}) rotate(${a})` }, P('chlo'));
        E('path', { d: B.ellD(0, 0, 10.5, 5.2), fill: B.vol(g, 'chlo'), stroke: '#2a6020', 'stroke-width': .7 }, gg);
        for (let k = -2; k <= 2; k++) { E('rect', { x: k * 3.6 - 1.2, y: -2.4, width: 2.4, height: 4.8, rx: .6, fill: '#2e6a22' }, gg); }
        E('path', { d: 'M-8 0H8', stroke: FK.alpha('#2a6020', .6), 'stroke-width': .4 }, gg); });
      /* মাইটোকন্ড্রিয়া */
      [[126, 236, 10], [208, 66, -15], [262, 132, 80], [92, 96, 60]].forEach(([x, y, a]) => { const gg = E('g', { transform: `translate(${x} ${y}) rotate(${a})` }, P('mito'));
        E('path', { d: B.ellD(0, 0, 6.6, 3.4), fill: B.vol(g, 'mito'), stroke: '#9a5a30', 'stroke-width': .6 }, gg); E('path', { d: 'M-4 -2.4V1M-1.4 2.4V-1M1.4 -2.4V1M4 2.4V-1', stroke: '#9a5a30', 'stroke-width': .5 }, gg); });
      /* শ্বেতসার দানা (ক্লোরোপ্লাস্টের ভেতরে নয়, সাইটোপ্লাজমে সঞ্চিত দানা হিসেবে দেখানো) */
      [[176, 240], [244, 232], [270, 76]].forEach(([x, y]) => { E('path', { d: B.ellD(x, y, 4.2, 3.2, 20), fill: B.TS('starch').c, stroke: '#8a826a', 'stroke-width': .5 }, P('starch')); E('path', { d: B.ellD(x - .6, y, 2, 1.4, 20), fill: 'none', stroke: '#a8a08a', 'stroke-width': .4 }, P('starch')); });
      hits(this.parts, part, 12); },
    parts: [
      { id: 'wall', bn: 'সেলুলোজের কোষপ্রাচীর', lb: 'কোষপ্রাচীর', en: 'Cell wall (cellulose)', fn: 'কোষঝিল্লির বাইরে শক্ত, ভেদ্য আবরণ — প্রধানত সেলুলোজ, হেমিসেলুলোজ ও পেকটিন। পাশের কোষের সাথে মধ্যপর্দা (পেকটিন) দিয়ে জোড়া। প্রাণীকোষে থাকে না; ছত্রাকের প্রাচীর কাইটিনের।', a: [80, 44], l: [10, 14], an: 'start' },
      { id: 'mem', bn: 'কোষঝিল্লি (প্লাজমা মেমব্রেন)', lb: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'প্রাচীরের ঠিক ভেতরে অর্ধভেদ্য লিপিড-প্রোটিন ঝিল্লি; পদার্থের আসা-যাওয়া নিয়ন্ত্রণ করে।', a: [284, 60], l: [352, 30], an: 'end' },
      { id: 'chlo', bn: 'ক্লোরোপ্লাস্ট (সবুজ প্লাস্টিড)', lb: 'ক্লোরোপ্লাস্ট', en: 'Chloroplast', fn: 'দ্বিস্তরী ঝিল্লিতে ঘেরা; ভেতরে থাইলাকয়েডের স্তূপ (গ্রানা) ও স্ট্রোমা। ক্লোরোফিল-a ও b থাকায় সালোকসংশ্লেষণে নিজের খাদ্য তৈরি করে — উদ্ভিদের প্রধান বৈশিষ্ট্য।', a: [140, 56], l: [140, 18], an: 'middle' },
      { id: 'vac', bn: 'কেন্দ্রীয় কোষগহ্বর', lb: 'কেন্দ্রীয় কোষগহ্বর', en: 'Central vacuole', fn: 'পরিণত উদ্ভিদকোষের প্রায় 80–90% আয়তন দখল করে; টোনোপ্লাস্ট ঝিল্লিতে ঘেরা কোষরসে পানি, লবণ, শর্করা ও রঞ্জক থাকে। রসস্ফীতি চাপ দিয়ে কোষকে টানটান রাখে।', a: [200, 150], l: [200, 150], an: 'middle' },
      { id: 'nuc', bn: 'নিউক্লিয়াস', lb: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'বড় কোষগহ্বরের চাপে একপাশে সরে থাকে; নিউক্লিয়ার আবরণে ছিদ্র, ভেতরে নিউক্লিওলাস ও ক্রোমাটিন। সুগঠিত নিউক্লিয়াস — প্রকৃতকোষী (ইউক্যারিওটিক) কোষের চিহ্ন।', a: [104, 236], l: [30, 288], an: 'start' },
      { id: 'mito', bn: 'মাইটোকন্ড্রিয়া', lb: 'মাইটোকন্ড্রিয়া', en: 'Mitochondria', fn: 'শ্বসনের মাধ্যমে ATP তৈরি করে; উদ্ভিদ ও প্রাণী দুই কোষেই থাকে।', a: [262, 132], l: [352, 120], an: 'end' },
      { id: 'pd', bn: 'প্লাজমোডেসমাটা', lb: 'প্লাজমোডেসমাটা', en: 'Plasmodesmata', fn: 'পাশাপাশি দুটি উদ্ভিদকোষের প্রাচীর ভেদ করা সূক্ষ্ম সাইটোপ্লাজমীয় সংযোগ — পানি, খাদ্য ও সংকেত এক কোষ থেকে আরেক কোষে যায়।', a: [288, 200], l: [352, 232], an: 'end' },
      { id: 'starch', bn: 'শ্বেতসার দানা', lb: 'শ্বেতসার দানা', en: 'Starch grain', fn: 'উদ্ভিদ বাড়তি শর্করা শ্বেতসার (স্টার্চ) রূপে জমা রাখে; প্রাণী জমা রাখে গ্লাইকোজেন রূপে।', a: [244, 232], l: [300, 290], an: 'middle' }
    ]
  }));

/* ═════════ নমুনা উদ্ভিদের আঁকা ═════════ */
/* Spirogyra: তিনটি কোষের সূত্র; সর্পিল ফিতার মতো ক্লোরোপ্লাস্ট */
B.spirogyra = (g, x0, y0, L, h, n = 3, o = {}) => { const A = B.TS('algaG'), cw = L / n;
  E('rect', { x: x0, y: y0 - h / 2, width: L, height: h, rx: 3, fill: FK.alpha('#eaf8e0', .9), stroke: '#4a8a3a', 'stroke-width': 1 }, g);
  for (let i = 1; i < n; i++) E('path', { d: `M${f1(x0 + i * cw)} ${f1(y0 - h / 2)}V${f1(y0 + h / 2)}`, stroke: '#4a8a3a', 'stroke-width': 1.4 }, g);
  for (let i = 0; i < n; i++) { const xa = x0 + i * cw + 3, xb = x0 + (i + 1) * cw - 3, turns = 2.25, N = 60;
    const pts = k => { const out = []; for (let j = 0; j <= N; j++) { const u = j / N, th = u * turns * 2 * PI + k; out.push([lerp(xa, xb, u), y0 + Math.sin(th) * (h / 2 - 3)]); } return out; };
    /* পেছনের অংশ হালকা, সামনের অংশ গাঢ় */
    E('path', { d: P2(pts(PI)), stroke: FK.alpha(A.c, .35), 'stroke-width': 3.4, fill: 'none' }, g);
    const fr = pts(0); let fd = ''; for (let j = 0; j < N; j++) { const th = (j / N) * turns * 2 * PI; if (Math.cos(th) > -.1) fd += `M${f1(fr[j][0])} ${f1(fr[j][1])}L${f1(fr[j + 1][0])} ${f1(fr[j + 1][1])}`; } E('path', { d: fd, stroke: A.c, 'stroke-width': 3.6, 'stroke-linecap': 'round', fill: 'none' }, g);
    let pd = ''; for (let j = 4; j < N; j += 9) pd += `M${f1(fr[j][0] - 1.5)} ${f1(fr[j][1])}a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0`; E('path', { d: pd, fill: '#e8f4d8', stroke: '#2e6a22', 'stroke-width': .5 }, g);
    const nx = (xa + xb) / 2; E('path', { d: `M${f1(nx - 6)} ${y0}L${f1(xa + 2)} ${f1(y0 - h / 2 + 3)}M${f1(nx + 6)} ${y0}L${f1(xb - 2)} ${f1(y0 + h / 2 - 3)}M${f1(nx)} ${f1(y0 - 4)}L${f1(nx + 4)} ${f1(y0 - h / 2 + 3)}`, stroke: FK.alpha('#8a9a7a', .7), 'stroke-width': .5 }, g);
    E('path', { d: B.ellD(nx, y0, 4.6, 3.4), fill: '#c8b8e0', stroke: '#5a4a8a', 'stroke-width': .6 }, g); E('circle', { cx: f1(nx), cy: y0, r: 1.2, fill: '#5a4a8a' }, g); }
  return { cw }; };

/* মস (Funaria): পাতাযুক্ত গ্যামিটোফাইট + সিটা ও ক্যাপসিউলসহ স্পোরোফাইট */
B.moss = (g, x, y, s = 1, o = {}) => { const M = B.TS('moss'), gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  for (let i = 0; i < 7; i++) E('path', { d: `M${-2 + i * .6} 0q${f1(-6 + B.rnd(i) * 12)} 6 ${f1(-8 + B.rnd(i + 5) * 16)} ${f1(10 + B.rnd(i + 9) * 6)}`, stroke: '#8a6a40', 'stroke-width': .5, fill: 'none' }, gg);
  E('path', { d: 'M0 0V-34', stroke: '#6a8a3a', 'stroke-width': 1.4 }, gg);
  let md = ''; for (let i = 0; i < 14; i++) { const yy = -4 - i * 2.2, sd = i % 2 ? 1 : -1, L = 7 - i * .25; md += leafD(0, yy, sd > 0 ? -PI / 5 - i * .02 : -PI + PI / 5 + i * .02, L, 1.8); } E('path', { d: md, fill: B.vol(gg, 'moss'), stroke: M.dk, 'stroke-width': .35 }, gg);
  if (o.spo !== false) { E('path', { d: 'M0 -34C1 -50 2 -66 6 -78', stroke: '#a86a30', 'stroke-width': 1, fill: 'none' }, gg);
    E('path', { d: 'M6 -78C2 -80 2 -88 8 -92C14 -94 18 -90 17 -84C16 -79 11 -77 6 -78Z', fill: '#b88a40', stroke: '#6a4a1a', 'stroke-width': .5 }, gg);
    E('path', { d: 'M8 -92C10 -96 15 -96 17 -91', fill: '#d8b060', stroke: '#6a4a1a', 'stroke-width': .5 }, gg); }
  return gg; };

/* ফার্ন: রাইজোম, অস্থানিক মূল, পক্ষল ফ্রন্ড ও কুণ্ডলিত কচি পাতা */
B.fern = (g, x, y, s = 1, o = {}) => { const F = B.TS('frond'), gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M-40 4C-20 0 10 2 40 6', stroke: '#7a5a3a', 'stroke-width': 5, 'stroke-linecap': 'round', fill: 'none' }, gg);
  for (let i = 0; i < 9; i++) E('path', { d: `M${-36 + i * 9} 6q${f1(-3 + B.rnd(i) * 6)} 8 ${f1(-4 + B.rnd(i + 3) * 8)} ${f1(12 + B.rnd(i + 7) * 6)}`, stroke: '#6a4a2a', 'stroke-width': .6, fill: 'none' }, gg);
  const frond = (bx, ang, L, np) => { const c = Math.cos(ang), sn = Math.sin(ang), Q = u => [bx + c * L * u + Math.sin(u * 2.2) * 6, 2 + sn * L * u + u * u * 14];
    const pts = []; for (let k = 0; k <= 20; k++) pts.push(Q(k / 20)); E('path', { d: sm(pts, false, .5), stroke: '#5a7a2a', 'stroke-width': 1.3, fill: 'none' }, gg);
    let fd = ''; for (let k = 1; k <= np; k++) { const u = .18 + k / (np + 1) * .78, [px, py] = Q(u), [qx, qy] = Q(u + .02), a = Math.atan2(qy - py, qx - px), Lp = 12 * (1 - u * .7);
      [1, -1].forEach(sd => { fd += leafD(px, py, a + sd * 1.2, Lp, 2.6); }); } E('path', { d: fd, fill: B.vol(gg, 'frond'), stroke: F.dk, 'stroke-width': .35 }, gg); };
  frond(-14, -PI / 2 - .5, 70, 11); frond(6, -PI / 2 + .25, 76, 12);
  /* কুণ্ডলিত কচি পাতা (circinate vernation) */
  E('path', { d: 'M22 2C22 -14 24 -26 30 -30C36 -33 38 -26 34 -23C31 -21 29 -24 31 -26', stroke: '#6a9a3a', 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, gg);
  return gg; };

/* সাইকাস: স্তম্ভাকার কাণ্ড (পত্রমূলের দাগ), শীর্ষে পক্ষল পাতার মুকুট, মাঝে পুংস্ট্রোবিলাস */
B.cycas = (g, x, y, s = 1, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), Bk = B.TS('bark');
  E('path', { d: 'M-9 0C-10 -20 -9 -44 -8 -60H8C9 -44 10 -20 9 0Z', fill: B.lin(gg, 'bark', 0), stroke: Bk.dk, 'stroke-width': .7 }, gg);
  let sd2 = ''; for (let r = 0; r < 9; r++) for (let c = 0; c < 3; c++) { const xx = -6.6 + c * 4.6 + (r % 2) * 2.3, yy = -4 - r * 6.4; if (xx > 5) continue; sd2 += `M${f1(xx)} ${yy}l2 -2.4l2 2.4l-2 2.4Z`; } E('path', { d: sd2, fill: 'none', stroke: FK.alpha(Bk.dk, .7), 'stroke-width': .5 }, gg);
  const leaf = (a, L) => { const pts = []; for (let k = 0; k <= 16; k++) { const u = k / 16; pts.push([Math.cos(a) * L * u, -62 + Math.sin(a) * L * u + u * u * L * .45]); }
    E('path', { d: sm(pts, false, .5), stroke: '#4a6a2a', 'stroke-width': 1, fill: 'none' }, gg);
    let ld = ''; for (let k = 2; k < 16; k++) { const [px, py] = pts[k], [qx, qy] = pts[k + 1] || pts[k], ta = Math.atan2(qy - py, qx - px); [1, -1].forEach(sd => { ld += `M${f1(px)} ${f1(py)}l${f1(Math.cos(ta + sd * .9) * 7)} ${f1(Math.sin(ta + sd * .9) * 7)}`; }); } E('path', { d: ld, stroke: '#3a6a22', 'stroke-width': 1.1, 'stroke-linecap': 'round', fill: 'none' }, gg); };
  [-PI + .25, -PI + .7, -PI / 2 - .45, -PI / 2 + .45, -.7, -.25, -PI + 1.2, -.95].forEach((a, i) => leaf(a, 46 - (i % 3) * 4));
  if (o.cone !== false) { E('path', { d: 'M-5 -62C-6 -72 -4 -84 0 -88C4 -84 6 -72 5 -62Z', fill: B.vol(gg, 'cone'), stroke: '#6e4a1c', 'stroke-width': .6 }, gg); for (let k = 0; k < 6; k++) E('path', { d: `M-4.6 ${-64 - k * 4}Q0 ${-62 - k * 4} 4.6 ${-64 - k * 4}`, stroke: '#6e4a1c', 'stroke-width': .4, fill: 'none' }, gg); }
  return gg; };

/* সরিষা (Brassica): প্রধান মূল, কাণ্ড, একান্তর পাতা, রেসিম পুষ্পমঞ্জরি, সিলিকুয়া */
B.mustard = (g, x, y, s = 1, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), Y = B.TS('mstd');
  E('path', { d: 'M0 0C-1 8 1 16 0 26', stroke: '#7a6040', 'stroke-width': 2.2, fill: 'none' }, gg);
  for (let i = 0; i < 6; i++) E('path', { d: `M0 ${4 + i * 3.6}q${i % 2 ? 6 : -6} 3 ${i % 2 ? 10 : -10} 6`, stroke: '#7a6040', 'stroke-width': .6, fill: 'none' }, gg);
  E('path', { d: 'M0 0C-1 -30 1 -62 0 -96', stroke: '#6a9a3a', 'stroke-width': 2, fill: 'none' }, gg);
  E('path', { d: 'M0 -70C8 -80 14 -88 18 -100', stroke: '#6a9a3a', 'stroke-width': 1.3, fill: 'none' }, gg);
  [[-6, -1, 22], [-16, 1, 20], [-30, -1, 17], [-46, 1, 14], [-60, -1, 11]].forEach(([yy, sd, L], i) => { const a = sd < 0 ? -PI + .5 : -.5;
    E('path', { d: leafD(0, yy, a, L, L * .33), fill: B.vol(gg, 'leaf'), stroke: '#3a6a22', 'stroke-width': .5 }, gg);
    E('path', { d: `M0 ${yy}L${f1(Math.cos(a) * L * .9)} ${f1(yy + Math.sin(a) * L * .9)}`, stroke: '#3a6a22', 'stroke-width': .4 }, gg); });
  /* ফল (সিলিকুয়া) নিচের দিকে, ফুল ওপরে */
  for (let k = 0; k < 5; k++) { const yy = -74 - k * 4, sd = k % 2 ? 1 : -1; E('path', { d: `M0 ${yy}l${sd * 4} -2l${sd * 3} -12`, stroke: '#8ab040', 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, gg); }
  const flw = (fx, fy, r) => { for (let p = 0; p < 4; p++) { const a = p * PI / 2 + PI / 4; E('path', { d: B.ellD(fx + Math.cos(a) * r * .9, fy + Math.sin(a) * r * .9, r * .9, r * .55, a * 180 / PI), fill: Y.c, stroke: Y.dk, 'stroke-width': .35 }, gg); } E('circle', { cx: fx, cy: fy, r: r * .35, fill: '#c8a020' }, gg); };
  [[0, -98, 3.4], [-4, -93, 3], [4, -92, 3], [18, -101, 3], [15, -96, 2.6], [-1, -104, 2.4]].forEach(([fx, fy, r]) => flw(fx, fy, r));
  return gg; };

const PG = {
  alg: ['শৈবাল', 'Spirogyra — সূত্রাকার সবুজ শৈবাল', 'থ্যালয়েড দেহ — মূল, কাণ্ড ও পাতায় বিভক্ত নয়; পানিতে থাকে; প্রতিটি কোষে ফিতার মতো সর্পিল ক্লোরোপ্লাস্ট ও পাইরিনয়েড। পরিবহন টিস্যু ও ভ্রূণ নেই। (মারগুলিসের পঞ্চজগতে শৈবাল প্রোটিস্টা জগতে; তবে প্রচলিত উদ্ভিদবিজ্ঞানে উদ্ভিদের সাথে পড়ানো হয়।)'],
  bry: ['ব্রায়োফাইট', 'Funaria — মস', 'ছোট, আর্দ্র স্থানের উদ্ভিদ; প্রকৃত মূলের বদলে রাইজয়েড; পরিবহন টিস্যু (জাইলেম-ফ্লোয়েম) নেই। প্রধান দেহ গ্যামিটোফাইট; তার ওপর পরজীবীর মতো স্পোরোফাইট (সিটা ও ক্যাপসিউল) জন্মায়। ভ্রূণ গঠিত হয়।'],
  pte: ['টেরিডোফাইট', 'Pteris — ফার্ন', 'প্রকৃত মূল, কাণ্ড (রাইজোম) ও পাতা আছে; জাইলেম-ফ্লোয়েম আছে কিন্তু ফুল-বীজ হয় না। পাতার নিচে স্পোরাঞ্জিয়ার গুচ্ছ (সোরাস) থেকে রেণু ছড়ায়; কচি পাতা কুণ্ডলিত থাকে। প্রধান দেহ স্পোরোফাইট।'],
  gym: ['নগ্নবীজী', 'Cycas — সাইকাস', 'বীজ হয় কিন্তু ফুল ও ফল হয় না — ডিম্বক মেগাস্পোরোফিলের ওপর উন্মুক্ত থাকে, তাই বীজ "নগ্ন"। কাণ্ড শাখাহীন স্তম্ভাকার, শীর্ষে পক্ষল পাতা; প্রজনন অঙ্গ স্ট্রোবিলাস (কোন)।'],
  ang: ['আবৃতবীজী', 'Brassica — সরিষা', 'সপুষ্পক উদ্ভিদ: ফুল হয়, ডিম্বক গর্ভাশয়ের ভেতরে আবৃত থাকে, নিষেকের পর গর্ভাশয় ফলে ও ডিম্বক বীজে পরিণত হয়; দ্বি-নিষেক ঘটে। সরিষার ফুল চার পাপড়ির, ফল সিলিকুয়া।']
};
V.plantGroups = Object.assign({}, B.seg({
  id: 'pgr', t: 'উদ্ভিদজগতের প্রধান দল: নমুনা উদ্ভিদ', H: 290, def: 'ang', types: PG,
  cap: 'সরল থেকে জটিল — শৈবাল, ব্রায়োফাইট, টেরিডোফাইট, নগ্নবীজী ও আবৃতবীজী। আকার অনুপাতে নয়; প্রতিটি নমুনার নিচে আনুমানিক মাপ দেওয়া আছে।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 236, fill: FK.alpha('#eef4e4', .6) }, g);
    if (ty === 'alg') { E('rect', { x: 0, y: 0, width: 360, height: 236, fill: B.lin(g, 'wtr', 90) }, g); const r = B.spirogyra(g, 40, 118, 280, 44, 3);
      lab(g, 40 + r.cw * 2, 98, 300, 40, 'কোষপ্রাচীর', C, 'start'); lab(g, 70, 102, 40, 40, 'সর্পিল ক্লোরোপ্লাস্ট', C, 'start'); lab(g, 40 + r.cw * 1.5, 118, 200, 190, 'নিউক্লিয়াস', C, 'middle'); lab(g, 84, 134, 70, 190, 'পাইরিনয়েড', C, 'middle');
    }
    if (ty === 'bry') { E('rect', { x: 0, y: 196, width: 360, height: 40, fill: B.lin(g, 'soil', 90) }, g); [130, 168, 206, 240].forEach((xx, i) => B.moss(g, xx, 198, 1.6 - (i % 2) * .15, { spo: i !== 3 }));
      lab(g, 141, 49, 60, 40, 'ক্যাপসিউল (রেণুধর)', C, 'start'); lab(g, 136, 120, 60, 110, 'সিটা', C, 'start'); lab(g, 250, 176, 300, 140, 'ক্ষুদ্র পাতা', C, 'start'); lab(g, 166, 212, 280, 214, 'রাইজয়েড', C, 'start');
    }
    if (ty === 'pte') { E('rect', { x: 0, y: 188, width: 360, height: 48, fill: B.lin(g, 'soil', 90) }, g); B.fern(g, 180, 186, 1.9);
      lab(g, 120, 60, 40, 40, 'পত্রফলক (ফ্রন্ড)', C, 'start'); lab(g, 238, 64, 300, 34, 'পত্রাংশ (পিনা)', C, 'start'); lab(g, 238, 130, 300, 120, 'কুণ্ডলিত কচি পাতা', C, 'start'); lab(g, 120, 193, 40, 208, 'রাইজোম', C, 'start'); lab(g, 210, 214, 280, 224, 'অস্থানিক মূল', C, 'start');
      /* পত্রাংশের নিচের দিক — প্রান্তে সোরাস (Pteris) */
      const gx = E('g', { transform: 'translate(46 150)' }, g); E('rect', { x: -26, y: -24, width: 52, height: 48, rx: 6, fill: C.sf, stroke: FK.alpha(C.fg, .3) }, gx);
      E('path', { d: leafD(-18, 0, 0, 36, 8), fill: B.TS('frond').c, stroke: B.TS('frond').dk, 'stroke-width': .5 }, gx); E('path', { d: 'M-14 -5C-4 -9 6 -8 14 -3M-14 5C-4 9 6 8 14 3', stroke: '#7a4a20', 'stroke-width': 2.2, fill: 'none' }, gx);
      B.tx(gx, 0, 36, 'নিচের দিক: প্রান্তে সোরাস', { fs: 8.6, a: 'middle', c: C.mu }); }
    if (ty === 'gym') { E('rect', { x: 0, y: 200, width: 360, height: 36, fill: B.lin(g, 'grass', 90) }, g); B.cycas(g, 180, 202, 2.2);
      lab(g, 180, 18, 260, 18, 'পুংস্ট্রোবিলাস (কোন)', C, 'start'); lab(g, 92, 74, 30, 40, 'পক্ষল পাতা', C, 'start'); lab(g, 194, 150, 260, 150, 'কাণ্ডে পত্রমূলের দাগ', C, 'start');
    }
    if (ty === 'ang') { E('rect', { x: 0, y: 160, width: 360, height: 76, fill: B.lin(g, 'soil', 90) }, g); B.mustard(g, 180, 162, 1.5);
      lab(g, 180, 12, 250, 22, 'পুষ্পমঞ্জরি (রেসিম) — চার পাপড়ির ফুল', C, 'start'); lab(g, 174, 52, 70, 46, 'ফল (সিলিকুয়া)', C, 'start'); lab(g, 206, 140, 270, 120, 'সরল পাতা', C, 'start'); lab(g, 180, 192, 250, 200, 'প্রধান মূল', C, 'start');
    }
    B.tx(g, 180, 256, PG[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 276, { alg: 'প্রতিটি কোষ প্রায় 0.1 মিমি লম্বা · পরিবহন টিস্যু ও ভ্রূণ নেই', bry: 'উচ্চতা প্রায় 1–3 সেমি · ভ্রূণ আছে, পরিবহন টিস্যু নেই', pte: 'ফ্রন্ড প্রায় 30–60 সেমি · পরিবহন টিস্যু আছে, বীজ নেই', gym: 'উচ্চতা প্রায় 1–3 মিটার · বীজ আছে, ফুল-ফল নেই', ang: 'উচ্চতা প্রায় 0.5–1 মিটার · ফুল, ফল ও আবৃত বীজ' }[ty], { fs: 10, a: 'middle', c: C.mu });
  }
}));

/* ═════════ শ্রেণিবিন্যাসবিদ্যার চার কাজ ═════════ */
V.taxonomyPillars = Object.assign({ t: 'ট্যাক্সোনমির মূল কাজ', k: ['cycle', 'anim', 'int'], cap: 'উদ্ভিদ শ্রেণিবিন্যাসবিদ্যা (Plant taxonomy) চারটি পরস্পর-সম্পর্কিত কাজ নিয়ে — একটি উদ্ভিদকে চেনা, তার সঠিক নাম দেওয়া, বৈশিষ্ট্য লিখে রাখা এবং সম্পর্ক অনুযায়ী দলে স্থান দেওয়া। নতুন তথ্য এলে চক্রটি আবার ঘোরে।' },
  BK.cycle({ W: 360, H: 330, label: 'ট্যাক্সোনমির চক্র', center: 'ট্যাক্সোনমি', sub: 'Taxonomy',
    nodes: [
      { t: 'শনাক্তকরণ', en: 'Identification', d: 'অজানা উদ্ভিদকে আগে থেকে জানা নমুনা, বর্ণনা, চাবি (key) বা হার্বেরিয়ামের সাথে মিলিয়ে চেনা — এটি কোন গোত্র, গণ, প্রজাতির।' },
      { t: 'নামকরণ', en: 'Nomenclature', d: 'আন্তর্জাতিক নিয়ম (ICN) মেনে সঠিক বৈজ্ঞানিক নাম দেওয়া — দ্বিপদ নাম, যেমন Oryza sativa L.।' },
      { t: 'বর্ণনা', en: 'Description', d: 'মূল, কাণ্ড, পাতা, ফুল, ফল, বীজসহ সব বৈশিষ্ট্য লিখে রাখা; নমুনা শুকিয়ে হার্বেরিয়ামে সংরক্ষণ।' },
      { t: 'শ্রেণিকরণ', en: 'Classification', d: 'মিল-অমিল ও বিবর্তনীয় সম্পর্ক অনুযায়ী উদ্ভিদকে ধাপে ধাপে দলে (প্রজাতি → গণ → গোত্র …) সাজানো।' }
    ] }));

/* ═════════ ধাপে ধাপে দলে ভাগ: ৮টি উদ্ভিদ ═════════ */
/* আইকন: defs এ একবার এঁকে <use> দিয়ে বসানো */
let icN = 0;
const ICD = {
  spi: gg => { B.spirogyra(gg, -26, 0, 52, 10, 2); },
  mos: gg => { B.moss(gg, 0, 16, .42); },
  fer: gg => { B.fern(gg, 0, 14, .38); },
  cyc: gg => { B.cycas(gg, 0, 18, .38, { cone: true }); },
  ric: gg => { for (let i = 0; i < 7; i++) { const a = -PI / 2 + (i - 3) * .16; E('path', { d: `M0 16Q${f1(Math.cos(a) * 10)} ${f1(16 + Math.sin(a) * 18)} ${f1(Math.cos(a) * 18)} ${f1(16 + Math.sin(a) * 30)}`, stroke: '#6aa03a', 'stroke-width': 1.2, fill: 'none' }, gg); }
    E('path', { d: 'M2 -10Q10 -14 14 -6', stroke: '#c8a840', 'stroke-width': 1.6, fill: 'none' }, gg); for (let k = 0; k < 6; k++) E('path', { d: B.ellD(4 + k * 1.8, -12 + k * 1.2, 1.4, .8, 40), fill: '#e0c050' }, gg); },
  coc: gg => { E('path', { d: 'M0 18C1 4 3 -6 5 -16', stroke: '#8a6a4a', 'stroke-width': 2.4, fill: 'none' }, gg); [-2.6, -2, -1.2, -.4, .2, -1.6].forEach(a => { const pts = []; for (let k = 0; k <= 8; k++) { const u = k / 8; pts.push([5 + Math.cos(a) * 18 * u, -16 + Math.sin(a) * 18 * u + u * u * 9]); } E('path', { d: sm(pts, false, .5), stroke: '#3a7a2a', 'stroke-width': 1.6, fill: 'none' }, gg); });
    E('circle', { cx: 3, cy: -13, r: 2, fill: '#8a6a2a' }, gg); E('circle', { cx: 7, cy: -12, r: 2, fill: '#8a6a2a' }, gg); },
  man: gg => { E('path', { d: 'M-2 18C-2 8 -1 2 0 -2M2 18C2 8 1 2 0 -2', stroke: '#6a4a2a', 'stroke-width': 2, fill: 'none' }, gg); E('path', { d: 'M-16 -2C-22 -12 -12 -24 0 -22C12 -26 22 -14 16 -2C10 4 -10 4 -16 -2Z', fill: B.vol(gg, 'leaf'), stroke: '#3a6a22', 'stroke-width': .6 }, gg);
    E('path', { d: B.ellD(-6, -4, 2.2, 3, 10), fill: '#e8b030', stroke: '#8a6010', 'stroke-width': .3 }, gg); E('path', { d: B.ellD(8, -6, 2.2, 3, -10), fill: '#e8b030', stroke: '#8a6010', 'stroke-width': .3 }, gg); },
  mus: gg => { B.mustard(gg, 0, 18, .34); }
};
B.ICD = ICD;
B.icon = (g, k, x, y, s = 1) => { const svg = g.ownerSVGElement || g; svg._ic = svg._ic || {};
  if (!svg._ic[k]) { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } const id = 'b100ic' + (++icN); const gg = E('g', { id }, d); ICD[k](gg); svg._ic[k] = id; }
  return E('use', { href: '#' + svg._ic[k], transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g); };

const GK = ['spi', 'mos', 'fer', 'cyc', 'ric', 'coc', 'man', 'mus'], GN = ['স্পাইরোগাইরা', 'মস', 'ফার্ন', 'সাইকাস', 'ধান', 'নারকেল', 'আম', 'সরিষা'];
/* প্রতিটি ধাপে প্রতিটি উদ্ভিদের অবস্থান (x,y) */
const GP = [
  GK.map((k, i) => [48 + (i % 4) * 88, 70 + Math.floor(i / 4) * 92]),
  [[40, 90], [92, 90], [144, 90], [216, 90], [268, 90], [320, 90], [242, 176], [294, 176]],
  [[40, 90], [92, 90], [144, 90], [216, 120], [272, 100], [322, 100], [272, 176], [322, 176]],
  [[40, 90], [92, 90], [144, 90], [216, 120], [274, 112], [322, 112], [274, 188], [322, 188]],
  [[40, 210], [92, 210], [144, 210], [192, 210], [236, 210], [276, 210], [318, 210], [358, 210]].map(([x, y]) => [x * .96 + 4, y])
];
const GS = [
  { t: 'অনেক উদ্ভিদ একসাথে', en: 'Unsorted', d: 'আটটি পরিচিত উদ্ভিদ এলোমেলো। শ্রেণিবিন্যাসের শুরু — প্রতিটির বৈশিষ্ট্য লক্ষ করা।' },
  { t: 'বীজ হয় কি না', en: 'Seeds?', d: 'প্রথম ভাগ: যারা বীজ তৈরি করে না (অবীজী বা ক্রিপ্টোগাম — শৈবাল, মস, ফার্ন) আর যারা বীজ তৈরি করে (বীজী বা ফ্যানেরোগাম)।' },
  { t: 'বীজ ঢাকা কি না', en: 'Ovary?', d: 'বীজী উদ্ভিদের দ্বিতীয় ভাগ: বীজ ফলের ভেতরে আবৃত নয় — নগ্নবীজী (সাইকাস); বীজ ফলের ভেতরে — আবৃতবীজী।' },
  { t: 'বীজপত্র এক না দুই', en: 'Cotyledons', d: 'আবৃতবীজীর তৃতীয় ভাগ: একবীজপত্রী (ধান, নারকেল — সমান্তরাল শিরাবিন্যাস) ও দ্বিবীজপত্রী (আম, সরিষা — জালিকা শিরাবিন্যাস)।' },
  { t: 'ধাপে ধাপে স্তরবিন্যাস', en: 'Hierarchy', d: 'প্রতিটি ভাগ আগের দলের ভেতরে ছোট দল — এভাবে বড় থেকে ছোট এককে সাজানোই শ্রেণিবিন্যাস। মিল যত বেশি, দল তত ছোট।' }
];
V.groupingSteps = Object.assign({ t: 'শ্রেণিবিন্যাস কীভাবে হয়: ধাপে ধাপে দল', k: ['2d', 'anim', 'steps'], cap: 'বৈশিষ্ট্যের মিল-অমিল দেখে প্রথমে বড় দলে, তারপর প্রতিটি দলকে আবার ছোট দলে ভাগ করা হয় — শেষে একটি স্তরবিন্যস্ত গাছের মতো কাঠামো তৈরি হয়। (সরল শিক্ষণ-উদাহরণ; প্রকৃত শ্রেণিবিন্যাসে আরও অনেক বৈশিষ্ট্য দেখা হয়।)' },
  BK.steps({ W: 360, H: 290, label: 'দলে ভাগ করা', dur: 3.4, stages: GS,
    draw(g, C, s, u) {
      const k = FK.ease(cl(u * 1.4)), A = GP[Math.max(0, s - 1)], Bq = GP[s];
      B.cacheG(g, 'gsfr' + s, gg => {
        if (s >= 1 && s <= 3) { const box = (x, y, w, h, t, c) => { E('rect', { x, y, width: w, height: h, rx: 10, fill: FK.alpha(c, .1), stroke: c, 'stroke-width': 1.2, 'stroke-dasharray': '4 3' }, gg); B.tx(gg, x + w / 2, y + 14, t, { fs: 9.6, a: 'middle', w: 700, c }); };
          box(12, 36, 160, 100, 'অবীজী (ক্রিপ্টোগাম)', '#6a7a8a'); box(184, 36, 168, s === 1 ? 190 : 190, 'বীজী (ফ্যানেরোগাম)', '#7a5a2a');
          if (s >= 2) { box(190, 60, 52, 110, 'নগ্নবীজী', '#8a6a2a'); box(246, 56, 102, 166, 'আবৃতবীজী', '#3a7a3a'); }
          if (s >= 3) { box(250, 72, 94, 74, 'একবীজপত্রী', '#2a6a9a'); box(250, 150, 94, 72, 'দ্বিবীজপত্রী', '#9a4a2a'); } }
        if (s === 4) { const N = (x, y, t, c) => { E('rect', { x: x - 44, y: y - 11, width: 88, height: 22, rx: 11, fill: FK.alpha(c, .12), stroke: c, 'stroke-width': 1 }, gg); B.tx(gg, x, y + 4, t, { fs: 9.6, a: 'middle', w: 700, c }); };
          const L = (x0, y0, x1, y1) => E('path', { d: `M${x0} ${y0}V${(y0 + y1) / 2}H${x1}V${y1}`, stroke: FK.alpha(C.fg, .45), 'stroke-width': 1, fill: 'none' }, gg);
          N(180, 28, 'উদ্ভিদজগৎ', '#3a5a2a'); L(180, 39, 92, 64); L(180, 39, 268, 64); N(92, 74, 'অবীজী', '#6a7a8a'); N(268, 74, 'বীজী', '#7a5a2a');
          L(268, 85, 192, 112); L(268, 85, 300, 112); N(192, 122, 'নগ্নবীজী', '#8a6a2a'); N(300, 122, 'আবৃতবীজী', '#3a7a3a');
          L(300, 133, 240, 159); L(300, 133, 318, 159); N(240, 170, 'একবীজপত্রী', '#2a6a9a');
          E('rect', { x: 287, y: 159, width: 62, height: 22, rx: 11, fill: FK.alpha('#9a4a2a', .12), stroke: '#9a4a2a' }, gg); B.tx(gg, 318, 174, 'দ্বিবীজপত্রী', { fs: 9.6, a: 'middle', w: 700, c: '#9a4a2a' });
          [[92, 85, 92, 190], [188, 133, 188, 190], [240, 181, 240, 190], [318, 181, 318, 190]].forEach(([a, b, c2, d]) => E('path', { d: `M${a} ${b}L${c2} ${d}`, stroke: FK.alpha(C.fg, .25), 'stroke-width': 1, 'stroke-dasharray': '2 3' }, gg)); }
        B.tx(gg, 180, 282, ['আটটি উদ্ভিদ — কোনটি কোন দলে?', 'বীজ আছে / নেই', 'বীজ আবৃত / নগ্ন', 'একবীজপত্রী / দ্বিবীজপত্রী', 'বড় দল থেকে ছোট দল — স্তরবিন্যাস'][s], { fs: 10.4, a: 'middle', c: C.mu }); });
      /* আইকন ও নাম স্থায়ী স্তরে — প্রতি ফ্রেমে শুধু অবস্থান বদলায় (নতুন <use> তৈরি করলে ধীর) */
      const LY = B.cacheG(g, 'gsic', gg => { gg._u = GK.map(key => B.icon(gg, key, 0, 0, 1)); gg._t = GN.map(n => B.tx(gg, 0, 0, n, { fs: 9.4, a: 'middle', c: C.fg })); });
      GK.forEach((key, i) => { const [x0, y0] = A[i], [x1, y1] = Bq[i], x = s === 0 ? x1 : lerp(x0, x1, k), y = s === 0 ? y1 : lerp(y0, y1, k), sc = s === 4 ? .8 : 1;
        LY._u[i].setAttribute('transform', `translate(${f1(x)} ${f1(y)}) scale(${sc})`); const tx = LY._t[i]; tx.setAttribute('x', f1(x)); tx.setAttribute('y', f1(y + (s === 4 ? 24 : 30))); tx.style.fontSize = (s === 4 ? 8.4 : 9.4) + 'px'; });
    }
  }));
})();
