/* ═══════════════════════════════════════════════════════════════════
   visuals3 — শ্রেণিবিন্যাসের প্রকারভেদ ও থিওফ্রাস্টাসের স্বভাবভিত্তিক বিভাজন:
   classTypes (কৃত্রিম / প্রাকৃতিক / জাতিজনি — একই ছয় উদ্ভিদ তিনভাবে),
   habitForms (বৃক্ষ, গুল্ম, উপগুল্ম, বীরুৎ — মানুষের উচ্চতার সাথে তুলনা)
   সহায়ক আইকন: শাপলা, পদ্ম, কচুরিপানা (B.ICD এ যোগ)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, leafD = B.leafD;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ─── জলজ উদ্ভিদের আইকন ─── */
const water = gg => E('path', { d: 'M-24 12Q-12 9 0 12T24 12', stroke: '#6a9ac0', 'stroke-width': 1.2, fill: 'none' }, gg);
B.ICD.sha = gg => { water(gg); /* শাপলা: ভাসমান খাঁজকাটা গোল পাতা, পানির ওপরে সাদা ফুল */
  E('path', { d: 'M-22 12C-22 6 -12 4 -6 6L-6 12Z', fill: B.TS('pad').c, stroke: B.TS('pad').dk, 'stroke-width': .5 }, gg);
  E('path', { d: 'M8 13C8 8 16 6 22 9C24 11 22 14 16 14Z', fill: B.TS('pad').c, stroke: B.TS('pad').dk, 'stroke-width': .5 }, gg);
  for (let i = 0; i < 9; i++) { const a = -PI / 2 + (i - 4) * .3; E('path', { d: leafD(0, 6, a, 12 - Math.abs(i - 4) * .8, 2.6), fill: B.TS('lily').lt, stroke: '#a8a0b8', 'stroke-width': .4 }, gg); }
  E('circle', { cx: 0, cy: 3, r: 2.6, fill: '#f0c840' }, gg); };
B.ICD.pad = gg => { water(gg); /* পদ্ম: পানির ওপরে উঁচু গোল পাতা, উঁচু ডাঁটায় গোলাপি ফুল, বীজকোষ */
  E('path', { d: 'M-12 12V-6M8 12V-16M18 12V-4', stroke: '#6a8a3a', 'stroke-width': 1, fill: 'none' }, gg);
  E('path', { d: 'M-24 -6Q-12 -14 0 -6Q-12 -2 -24 -6Z', fill: B.TS('pad').c, stroke: B.TS('pad').dk, 'stroke-width': .5 }, gg);
  for (let i = 0; i < 7; i++) { const a = -PI / 2 + (i - 3) * .32; E('path', { d: leafD(8, -16, a, 11, 3.6), fill: '#f6b0c4', stroke: '#b0506a', 'stroke-width': .4 }, gg); }
  E('path', { d: 'M14 -4L22 -4L20 -9L16 -9Z', fill: '#9ab060', stroke: '#4a6a22', 'stroke-width': .4 }, gg); };
B.ICD.kac = gg => { water(gg); /* কচুরিপানা: ফোলা বোঁটার পাতা, বেগুনি ফুলের মঞ্জরি, পানিতে ঝুলন্ত মূল */
  for (let i = 0; i < 8; i++) E('path', { d: `M${-6 + i * 1.8} 12q${f1(-2 + B.rnd(i) * 4)} 6 ${f1(-1 + B.rnd(i + 3) * 2)} 12`, stroke: '#5a4a6a', 'stroke-width': .5, fill: 'none' }, gg);
  [[-PI + .8, 12], [-PI / 2 - .5, 13], [-PI / 2 + .6, 12], [-.6, 11]].forEach(([a, L]) => { const c = Math.cos(a), s = Math.sin(a);
    E('path', { d: B.ellD(c * 5, 8 + s * 5, 3, 1.8, a * 57), fill: '#8ac050', stroke: '#3a6a22', 'stroke-width': .4 }, gg);
    E('path', { d: B.ellD(c * L, 8 + s * L, 5.6, 4.6, a * 57), fill: B.TS('leaf').c, stroke: '#2e5a1a', 'stroke-width': .4 }, gg); });
  E('path', { d: 'M2 6V-18', stroke: '#6a8a3a', 'stroke-width': 1 }, gg); for (let k = 0; k < 6; k++) E('path', { d: B.ellD(2 + (k % 2 ? 3 : -3), -6 - k * 2.6, 3, 2, 0), fill: '#b8a0e0', stroke: '#6a4a9a', 'stroke-width': .35 }, gg); };

/* ═════════ একই ছয় উদ্ভিদ — তিন ধরনের শ্রেণিবিন্যাস ═════════ */
const SIX = [['sha', 'শাপলা'], ['pad', 'পদ্ম'], ['kac', 'কচুরিপানা'], ['ric', 'ধান'], ['man', 'আম'], ['mus', 'সরিষা']];
const CT = {
  art: ['কৃত্রিম', 'কৃত্রিম: একটিমাত্র বৈশিষ্ট্য — বাসস্থান', 'শুধু একটি সহজে দেখা যায় এমন বৈশিষ্ট্য (এখানে: পানিতে জন্মায় কি না) দিয়ে ভাগ। ফলে কচুরিপানা (একবীজপত্রী) শাপলা ও পদ্মের সাথে আর ধান (একবীজপত্রী) আম-সরিষার সাথে এক দলে পড়ে — সম্পর্কহীন উদ্ভিদ একসাথে। উদাহরণ: থিওফ্রাস্টাস, লিনিয়াসের পদ্ধতি।'],
  nat: ['প্রাকৃতিক', 'প্রাকৃতিক: অনেক বৈশিষ্ট্যের সামগ্রিক মিল', 'বীজপত্রের সংখ্যা, শিরাবিন্যাস, ফুলের অংশের সংখ্যা, মূলতন্ত্রসহ অনেক অঙ্গসংস্থানিক বৈশিষ্ট্য একসাথে বিবেচনা — একবীজপত্রী (কচুরিপানা, ধান) ও দ্বিবীজপত্রী (শাপলা, পদ্ম, আম, সরিষা)। বেনথাম ও হুকার শাপলা ও পদ্মকে চেহারার মিলের কারণে একই গোত্রে (Nymphaeaceae) রেখেছিলেন। উদাহরণ: দ্য জুসিউ, দ্য ক্যান্ডল, বেনথাম ও হুকার।'],
  phy: ['জাতিজনি', 'জাতিজনি: বিবর্তনীয় সম্পর্ক (কোন উদ্ভিদ কার নিকট আত্মীয়)', 'সাধারণ পূর্বপুরুষ থেকে উৎপত্তির ক্রম অনুযায়ী সাজানো — আজকাল DNA তথ্যও ব্যবহৃত হয়। আধুনিক APG পদ্ধতিতে শাপলা আদি সপুষ্পক উদ্ভিদের একটি প্রাচীন শাখা, আর পদ্ম সত্যিকার দ্বিবীজপত্রীর (ইউডাইকট) শাখায় — চেহারায় মিল থাকলেও এরা দূর-সম্পর্কিত। উদাহরণ: এঙ্গলার ও প্র্যান্টল, হাচিনসন, ক্রনকুইস্ট, APG।']
};
V.classTypes = Object.assign({}, B.seg({
  id: 'clt', t: 'শ্রেণিবিন্যাসের তিন প্রকার: একই উদ্ভিদ, ভিন্ন দল', H: 300, def: 'art', types: CT,
  cap: 'একই ছয়টি উদ্ভিদকে তিন পদ্ধতিতে সাজালে দলগুলো বদলে যায়। কৃত্রিম পদ্ধতি সহজ কিন্তু সম্পর্ক দেখায় না; প্রাকৃতিক পদ্ধতি সামগ্রিক মিল দেখায়; জাতিজনি পদ্ধতি বিবর্তনীয় আত্মীয়তা দেখায়। (জাতিজনি গাছটি APG IV অনুযায়ী সরলীকৃত।)',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 252, fill: FK.alpha('#f2f4ea', .6) }, g);
    const place = (pos) => SIX.forEach(([k, n], i) => { const [x, y] = pos[i]; B.icon(g, k, x, y, 1.25); B.tx(g, x, y + 36, n, { fs: 9.6, a: 'middle', c: C.fg }); });
    const box = (x, y, w, h, t, c) => { E('rect', { x, y, width: w, height: h, rx: 12, fill: FK.alpha(c, .08), stroke: c, 'stroke-width': 1.3 }, g); B.tx(g, x + w / 2, y + 16, t, { fs: 10.4, a: 'middle', w: 700, c }); };
    if (ty === 'art') { box(10, 16, 166, 222, 'জলজ উদ্ভিদ', '#2a6a9a'); box(184, 16, 166, 222, 'স্থলজ উদ্ভিদ', '#8a5a2a'); place([[56, 80], [130, 80], [93, 170], [228, 80], [306, 80], [267, 170]]);
B.tx(g, 93, 228, 'একবীজপত্রী, তবু এখানে', { fs: 8.6, a: 'middle', c: '#a8302a' }); B.tx(g, 228, 140, 'একবীজপত্রী, তবু এখানে', { fs: 8.6, a: 'middle', c: '#a8302a' }); }
    if (ty === 'nat') { box(10, 16, 118, 222, 'একবীজপত্রী', '#2a6a9a'); box(136, 16, 214, 222, 'দ্বিবীজপত্রী', '#9a4a2a'); place([[186, 80], [290, 80], [68, 80], [68, 170], [186, 170], [290, 170]]);
      E('path', { d: 'M150 58H326', stroke: FK.alpha('#9a4a2a', .5), 'stroke-dasharray': '3 3' }, g); B.tx(g, 238, 50, 'B&H: একই গোত্র Nymphaeaceae', { fs: 8.6, a: 'middle', c: '#8a4a20' }); }
    if (ty === 'phy') { /* ক্ল্যাডোগ্রাম: মূল বাঁয়ে, পাতা ডানে */
      const L = (pts, c = FK.alpha(C.fg, .6)) => E('path', { d: pts.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(''), stroke: c, 'stroke-width': 1.6, fill: 'none' }, g);
      const ys = { sha: 34, kac: 76, ric: 112, pad: 150, man: 188, mus: 224 }, xl = 250;
      L([[20, 91], [44, 91]]); L([[44, 34], [44, 148]]); L([[44, 34], [xl, 34]]); /* শাপলা প্রথমে আলাদা */
      L([[44, 148], [84, 148]]); L([[84, 94], [84, 202]]); /* বাকিরা */
      L([[84, 94], [140, 94]]); L([[140, 76], [140, 112]]); L([[140, 76], [xl, 76]], '#2a6a9a'); L([[140, 112], [xl, 112]], '#2a6a9a');
      L([[84, 202], [128, 202]]); L([[128, 150], [128, 206]]); L([[128, 150], [xl, 150]], '#9a4a2a'); L([[128, 206], [180, 206]]); L([[180, 188], [180, 224]]); L([[180, 188], [xl, 188]], '#9a4a2a'); L([[180, 224], [xl, 224]], '#9a4a2a');
      [['sha', 'শাপলা'], ['kac', 'কচুরিপানা'], ['ric', 'ধান'], ['pad', 'পদ্ম'], ['man', 'আম'], ['mus', 'সরিষা']].forEach(([k, n]) => { B.icon(g, k, xl + 26, ys[k], .95); B.tx(g, xl + 52, ys[k] + 4, n, { fs: 9.6, c: C.fg }); });
      B.tx(g, 150, 66, 'একবীজপত্রী', { fs: 9, c: '#2a6a9a', w: 700 }); B.tx(g, 136, 142, 'ইউডাইকট', { fs: 9, c: '#9a4a2a', w: 700 }); B.tx(g, 60, 26, 'আদি শাখা', { fs: 9, c: C.mu });
      B.tx(g, 20, 248, 'শাখার মিলনবিন্দু = সাধারণ পূর্বপুরুষ', { fs: 9, c: C.mu }); }
    B.tx(g, 180, 270, CT[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 290, { art: 'সহজ, কিন্তু সম্পর্ক ভুল দেখাতে পারে', nat: 'অনেক বৈশিষ্ট্য — কিন্তু বিবর্তন বিবেচনা করে না', phy: 'চেহারা নয়, বংশধারা — শাপলা ও পদ্ম দূর-আত্মীয়' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ থিওফ্রাস্টাস: স্বভাব অনুযায়ী চার দল ═════════ */
const person = (g, x, y, h) => { const s = h / 170, gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${f1(s)})` }, g);
  E('circle', { cx: 0, cy: -158, r: 12, fill: '#c8ccd2' }, gg); E('path', { d: 'M-16 -142H16L20 -80H12L10 -2H2L0 -70L-2 -2H-10L-12 -80H-20Z', fill: '#c8ccd2' }, gg); };
const tree = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M-7 0C-6 -18 -6 -30 -4 -40C-12 -48 -20 -52 -26 -56M-4 -40L-2 -58M6 0C5 -18 4 -30 4 -42C12 -50 20 -54 26 -58', stroke: B.TS('bark').c, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('path', { d: 'M-7 0C-6 -18 -6 -30 -4 -40L4 -42C4 -30 5 -18 6 0Z', fill: B.lin(gg, 'bark', 0), stroke: B.TS('bark').dk, 'stroke-width': .6 }, gg);
  [[-30, -66, 22], [0, -80, 26], [30, -66, 22], [-16, -92, 20], [18, -94, 20], [-36, -82, 16], [38, -84, 16], [0, -104, 16]].forEach(([cx, cy, r], i) => E('path', { d: `M${cx - r} ${cy}C${cx - r} ${cy - r * .9} ${cx + r} ${cy - r * .9} ${cx + r} ${cy}C${cx + r} ${cy + r * .7} ${cx - r} ${cy + r * .7} ${cx - r} ${cy}Z`, fill: B.vol(gg, 'leaf'), stroke: '#2e5a1a', 'stroke-width': .6 }, gg));
  for (let i = 0; i < 40; i++) { const a = B.rnd(i) * 2 * PI, r = B.rnd(i + 9) * 44; E('path', { d: B.ellD(Math.cos(a) * r, -80 + Math.sin(a) * r * .55, 4, 1.6, a * 57), fill: '#3a7a2a', opacity: .5 }, gg); }
  return gg; };
const shrub = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  [-.5, -.25, 0, .22, .45].forEach((a, i) => E('path', { d: `M${i - 2} 0Q${f1(Math.sin(a) * 20)} -30 ${f1(Math.sin(a) * 34)} -60`, stroke: '#7a5a3a', 'stroke-width': 2.2, fill: 'none' }, gg));
  for (let i = 0; i < 46; i++) { const a = -PI / 2 + (B.rnd(i) - .5) * 2.2, r = 18 + B.rnd(i + 3) * 42; E('path', { d: leafD(Math.cos(a) * r * .8, -4 + Math.sin(a) * r, a + (B.rnd(i + 7) - .5), 9, 3.6), fill: B.TS('leaf').c, stroke: '#2e5a1a', 'stroke-width': .35 }, gg); }
  [[-20, -48], [14, -56], [-4, -66], [26, -36], [-30, -30]].forEach(([fx, fy]) => { for (let p = 0; p < 5; p++) { const a = p * 2 * PI / 5; E('path', { d: B.ellD(fx + Math.cos(a) * 4, fy + Math.sin(a) * 4, 4.6, 3, a * 57), fill: '#d8303a', stroke: '#8a1424', 'stroke-width': .35 }, gg); } E('path', { d: `M${fx} ${fy}l6 -6`, stroke: '#f0d040', 'stroke-width': 1 }, gg); });
  return gg; };
const undershrub = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M0 0V-14M0 -10L-8 -18M0 -12L8 -20', stroke: '#7a5a3a', 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('path', { d: 'M-8 -18Q-12 -30 -14 -42M8 -20Q12 -32 13 -44M0 -14V-46', stroke: '#6a9a3a', 'stroke-width': 1.2, fill: 'none' }, gg);
  [[-14, -42], [13, -44], [0, -46]].forEach(([sx, sy]) => { for (let k = 0; k < 4; k++) [1, -1].forEach(sd => E('path', { d: leafD(sx * (1 - k * .2), sy + 6 + k * 6, sd > 0 ? -.4 : -PI + .4, 7, 2.8), fill: B.TS('leaf').c, stroke: '#2e5a1a', 'stroke-width': .3 }, gg));
    for (let k = 0; k < 6; k++) E('circle', { cx: f1(sx), cy: f1(sy - k * 2.2), r: .9, fill: '#8a5a9a' }, gg); });
  return gg; };
const HB = {
  tree: ['বৃক্ষ', 'বৃক্ষ (Tree) — আম', 'একটি মোটা, শক্ত কাষ্ঠল প্রধান কাণ্ড (গুঁড়ি), মাটি থেকে কিছু উঁচুতে শাখা-প্রশাখা; উঁচু ও দীর্ঘজীবী। উদাহরণ: আম, কাঁঠাল, বট।'],
  shrub: ['গুল্ম', 'গুল্ম (Shrub) — জবা', 'মাঝারি উচ্চতার কাষ্ঠল উদ্ভিদ; গোড়া থেকেই একাধিক শাখা-কাণ্ড, স্পষ্ট একক গুঁড়ি নেই। উদাহরণ: জবা, গোলাপ, মেহেদি।'],
  under: ['উপগুল্ম', 'উপগুল্ম (Undershrub) — তুলসী', 'ছোট উদ্ভিদ; গোড়ার দিক শক্ত ও কাষ্ঠল, ওপরের দিক নরম ও সবুজ। উদাহরণ: তুলসী, বাসক (ছোট অবস্থায়)।'],
  herb: ['বীরুৎ', 'বীরুৎ (Herb) — সরিষা', 'নরম, সবুজ, অকাষ্ঠল কাণ্ড; সাধারণত ছোট ও স্বল্পজীবী (প্রায়ই এক মৌসুম)। উদাহরণ: সরিষা, ধান, শাকসবজি।']
};
V.habitForms = Object.assign({}, B.seg({
  id: 'hbf', t: 'থিওফ্রাস্টাসের শ্রেণিবিন্যাস: স্বভাব অনুযায়ী চার দল', H: 290, def: 'tree', types: HB,
  cap: 'গ্রিক দার্শনিক থিওফ্রাস্টাস (খ্রিস্টপূর্ব প্রায় 371–287) তাঁর Historia Plantarum গ্রন্থে প্রায় 480 প্রকার উদ্ভিদকে আকার ও স্বভাব (habit) অনুযায়ী বৃক্ষ, গুল্ম, উপগুল্ম ও বীরুৎ — এ চার দলে ভাগ করেন। পাশের ধূসর মানুষটি প্রায় 1.7 মিটার, তুলনার জন্য।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 232, fill: FK.alpha('#eef4f8', .6) }, g); E('rect', { x: 0, y: 214, width: 360, height: 18, fill: B.lin(g, 'soil', 90) }, g);
    /* উচ্চতার মাপকাঠি */
    const Y0 = 214, m = 60; for (let h = 0; h <= 3; h++) { E('path', { d: `M14 ${Y0 - h * m}h6`, stroke: FK.alpha(C.fg, .5), 'stroke-width': 1 }, g); B.tx(g, 24, Y0 - h * m + 3, h + ' মি', { fs: 8.4, c: C.mu }); } E('path', { d: `M17 ${Y0}V${Y0 - 3 * m}`, stroke: FK.alpha(C.fg, .3), 'stroke-width': 1 }, g);
    person(g, 60, Y0, 1.7 * m);
    const sel = k => { const on = k === ty; return { op: on ? 1 : .32 }; };
    const G = (k, fn) => { const gg = E('g', { opacity: sel(k).op }, g); fn(gg); };
    G('tree', gg => tree(gg, 128, Y0, 1.45)); G('shrub', gg => shrub(gg, 236, Y0, 1.2)); G('under', gg => undershrub(gg, 294, Y0, 1.6)); G('herb', gg => B.mustard(gg, 340, Y0, .62));
    [['tree', 128, 'বৃক্ষ'], ['shrub', 236, 'গুল্ম'], ['under', 294, 'উপগুল্ম'], ['herb', 340, 'বীরুৎ']].forEach(([k, x, n]) => B.tx(g, x, 229, n, { fs: 10, a: 'middle', w: k === ty ? 700 : 400, c: k === ty ? '#1e4a10' : C.fg }));
    B.tx(g, 180, 254, HB[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 274, { tree: 'একক মোটা কাষ্ঠল কাণ্ড; আম গাছ আসলে 10–30 মি — এখানে ছোট করে আঁকা', shrub: 'গোড়া থেকে বহু কাষ্ঠল শাখা', under: 'গোড়া কাষ্ঠল, আগা নরম', herb: 'নরম সবুজ কাণ্ড, ছোট' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));
})();
