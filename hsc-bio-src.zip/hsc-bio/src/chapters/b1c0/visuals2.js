/* ═══════════════════════════════════════════════════════════════════
   visuals2 — শ্রেণিবিন্যাসের একক ও নামকরণ:
   rankNest (একক — নেস্টেড স্তর, ধান/আম/সরিষা/কাঁঠাল), speciesTest (প্রজাতির জৈবিক ধারণা),
   binomialAnatomy (দ্বিপদ নামের অংশ), commonNames (এক উদ্ভিদ, বহু স্থানীয় নাম)
   সহায়ক: B.mangoTwig, B.jackTree, B.equid
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits, leafD = B.leafD;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ এককের স্তর (নেস্টেড) ═════════ */
const RK = [['জগৎ', 'Kingdom'], ['বিভাগ', 'Division'], ['শ্রেণি', 'Class'], ['বর্গ', 'Order'], ['গোত্র', 'Family'], ['গণ', 'Genus'], ['প্রজাতি', 'Species']];
const RX = {
  ric: ['ধান', ['Plantae', 'Magnoliophyta', 'Liliopsida', 'Poales', 'Poaceae', 'Oryza', 'Oryza sativa'], 'ric', 'একবীজপত্রী; ঘাস গোত্রে গম, ভুট্টা, বাঁশ, আখও আছে।'],
  man: ['আম', ['Plantae', 'Magnoliophyta', 'Magnoliopsida', 'Sapindales', 'Anacardiaceae', 'Mangifera', 'Mangifera indica'], 'man', 'দ্বিবীজপত্রী; একই গোত্রে কাজুবাদাম, আমড়া।'],
  mus: ['সরিষা', ['Plantae', 'Magnoliophyta', 'Magnoliopsida', 'Brassicales', 'Brassicaceae', 'Brassica', 'Brassica napus'], 'mus', 'দ্বিবীজপত্রী; একই গণে বাঁধাকপি, ফুলকপি (Brassica oleracea)।'],
  jac: ['কাঁঠাল', ['Plantae', 'Magnoliophyta', 'Magnoliopsida', 'Rosales', 'Moraceae', 'Artocarpus', 'Artocarpus heterophyllus'], 'man', 'দ্বিবীজপত্রী; একই গোত্রে বট, ডুমুর, তুঁত।']
};
const END = ['', 'phyta', 'opsida', 'ales', 'aceae', '', ''];
V.rankNest = Object.assign({}, B.seg({
  id: 'rkn', t: 'শ্রেণিবিন্যাসের সাতটি প্রধান একক', H: 300, def: 'ric', types: Object.fromEntries(Object.entries(RX).map(([k, v]) => [k, [v[0], v[0] + ' — ' + v[1][6], v[3]]])),
  cap: 'প্রতিটি একক তার ওপরের এককের ভেতরে থাকে — জগৎ সবচেয়ে বড়, প্রজাতি সবচেয়ে ছোট ও মৌলিক একক। বিভাগ, শ্রেণি, বর্গ ও গোত্রের নামের শেষাংশ নির্দিষ্ট (-phyta, -opsida, -ales, -aceae)। বর্গের নাম পদ্ধতিভেদে আলাদা হতে পারে (যেমন ক্রনকুইস্ট পদ্ধতিতে ধান Cyperales, আধুনিক APG পদ্ধতিতে Poales)।',
  art(g, C, ty) { const R = RX[ty][1], cols = ['#5a7a3a', '#3a7a5a', '#2a6a8a', '#5a5a9a', '#8a5a8a', '#9a5a3a', '#a8402a'];
    RK.forEach(([bn, en], i) => { const x = 8 + i * 13, y = 8 + i * 25, w = 344 - i * 26, h = 256 - i * 32, c = cols[i];
      E('rect', { x, y, width: w, height: h, rx: 10, fill: FK.alpha(c, i === 6 ? .16 : .07), stroke: c, 'stroke-width': i === 6 ? 1.8 : 1.1 }, g);
      const it = i >= 5 ? 'font-style:italic' : '';
      const nm = R[i], e = END[i], base = e && nm.endsWith(e) ? nm.slice(0, -e.length) : nm;
      B.tx(g, x + 8, y + 15, `${bn} (${en}):`, { fs: 9.6, c, w: 700 });
      const lg = i === 6 && nm.length > 16, t = B.tx(g, lg ? x + 8 : x + 8 + (bn.length + en.length) * 5.6 + 22, lg ? y + 32 : y + 15, '', { fs: lg ? 11 : 10, c: C.fg, st: it, w: i === 6 ? 700 : null });
      t.textContent = base; if (e) { const sp = E('tspan', { fill: c, 'font-weight': 700, 'text-decoration': 'underline' }, t); sp.textContent = e; } });
    B.icon(g, RX[ty][2], 186, 226, 1);
    B.tx(g, 180, 290, 'ভেতরে যেতে যেতে: সদস্য কমে, মিল বাড়ে', { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ প্রজাতির জৈবিক ধারণা ═════════ */
B.equid = (g, x, y, s, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), col = o.col || '#8a6a4a', dk = o.dk || '#4a3420';
  /* দেহ, ঘাড়, মাথা — ডানমুখী */
  E('path', { d: 'M-26 -20C-30 -26 -24 -32 -12 -32L14 -32C20 -34 24 -40 26 -48L30 -58C32 -62 38 -62 40 -58L44 -50C46 -46 44 -44 40 -44L34 -42C32 -36 28 -24 26 -18C24 -12 18 -10 12 -10L-18 -10C-24 -10 -26 -14 -26 -20Z', fill: col, stroke: dk, 'stroke-width': .8 }, gg);
  /* কান */
  const ear = o.ear || 6; E('path', { d: `M31 -58L${f1(30 - ear * .2)} ${f1(-58 - ear)}L34 -59Z`, fill: col, stroke: dk, 'stroke-width': .7 }, gg);
  E('path', { d: `M34 -59L${f1(34 + ear * .1)} ${f1(-59 - ear)}L37 -59Z`, fill: col, stroke: dk, 'stroke-width': .7 }, gg);
  /* কেশর ও লেজ */
  E('path', { d: 'M28 -56C22 -50 18 -40 14 -32', stroke: o.mane || dk, 'stroke-width': o.mane ? 3 : 1.6, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('path', { d: `M-26 -24C-32 -20 -34 -10 ${o.tuft ? '-32 0' : '-36 2'}`, stroke: dk, 'stroke-width': o.tuft ? 1 : 2.6, fill: 'none', 'stroke-linecap': 'round' }, gg); if (o.tuft) E('path', { d: B.ellD(-32, 2, 2, 3.4), fill: dk }, gg);
  /* পা ও খুর */
  [[-20, 0], [-12, 0], [14, 0], [22, 0]].forEach(([lx]) => { E('path', { d: `M${lx} -12V8`, stroke: col, 'stroke-width': 4.4, 'stroke-linecap': 'butt' }, gg); E('path', { d: `M${lx - 2.4} 8h4.8v2.6h-4.8Z`, fill: '#2a2018' }, gg); });
  E('circle', { cx: 38, cy: -52, r: 1, fill: '#111' }, gg); E('path', { d: 'M42 -46l2 1', stroke: dk, 'stroke-width': .6 }, gg);
  return gg; };
const rice = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  for (let i = 0; i < 7; i++) { const a = -PI / 2 + (i - 3) * .12; E('path', { d: `M0 0Q${f1(Math.cos(a) * 12)} ${f1(Math.sin(a) * 20)} ${f1(Math.cos(a) * 18 + (i - 3) * 2)} ${f1(Math.sin(a) * 40)}`, stroke: '#6aa03a', 'stroke-width': 1.3, fill: 'none' }, gg); }
  E('path', { d: 'M0 -34Q8 -48 22 -44', stroke: '#b89a3a', 'stroke-width': 1.2, fill: 'none' }, gg); for (let k = 0; k < 8; k++) { const u = k / 8; E('path', { d: B.ellD(lerp(4, 21, u), -44 + Math.sin(u * PI) * -4 + u * 2, 2.2, 1.1, 30), fill: '#e2c25a', stroke: '#9a7a20', 'stroke-width': .3 }, gg); }
  return gg; };
const wheat = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M0 0V-40', stroke: '#9ab050', 'stroke-width': 1.4 }, gg); for (let i = 0; i < 4; i++) E('path', { d: leafD(0, -6 - i * 7, i % 2 ? -.5 : -PI + .5, 16, 2.4), fill: '#8ab048', stroke: '#4a6a22', 'stroke-width': .3 }, gg);
  for (let k = 0; k < 7; k++) [1, -1].forEach(sd => { const yy = -42 - k * 3.6; E('path', { d: B.ellD(sd * 2.2, yy, 2, 2.8, sd * 20), fill: '#e6c868', stroke: '#9a7a20', 'stroke-width': .3 }, gg); E('path', { d: `M${sd * 2.6} ${yy - 2}l${sd * 3} -9`, stroke: '#c8aa48', 'stroke-width': .4 }, gg); });
  return gg; };
const ST = {
  same: ['একই প্রজাতি', 'BRRI ধান28 × BRRI ধান29 (দুটিই Oryza sativa)', 'একই প্রজাতির দুটি জাতের মধ্যে পরাগায়ন ও নিষেক স্বাভাবিকভাবে হয় এবং সংকর বীজ থেকে উর্বর গাছ জন্মায়, যা আবার বীজ দেয় — তাই এরা একই প্রজাতি।'],
  diff: ['ভিন্ন প্রজাতি', 'ধান (Oryza sativa) × গম (Triticum aestivum)', 'ধানের পরাগরেণু গমের গর্ভমুণ্ডে অঙ্কুরিত হয়ে নিষেক ঘটাতে পারে না — প্রজনন-বিচ্ছিন্নতা। তাই এরা ভিন্ন প্রজাতি (এমনকি ভিন্ন গণ)।'],
  mule: ['বন্ধ্যা সংকর', 'ঘোড়া (Equus caballus) × গাধা (Equus asinus) → খচ্চর', 'নিকট-সম্পর্কিত দুটি প্রজাতির মিলনে সংকর (খচ্চর) জন্মালেও সে সাধারণত বন্ধ্যা — ঘোড়ার 64 ও গাধার 62 ক্রোমোজোম থেকে খচ্চর পায় 63টি, যা মিয়োসিসে ঠিকমতো জোড়া বাঁধে না। তাই ঘোড়া ও গাধা আলাদা প্রজাতি।']
};
V.speciesTest = Object.assign({}, B.seg({
  id: 'spt', t: 'প্রজাতি: প্রজননভিত্তিক সংজ্ঞা', H: 270, def: 'same', types: ST,
  cap: 'আর্নস্ট মেয়ারের (1942) জৈবিক প্রজাতি ধারণা: যেসব জীব নিজেদের মধ্যে প্রাকৃতিকভাবে প্রজনন করে উর্বর সন্তান জন্ম দিতে পারে এবং অন্য দল থেকে প্রজননগতভাবে বিচ্ছিন্ন — তারা একটি প্রজাতি। উদ্ভিদে অনেক সময় আকৃতিগত মিলও প্রজাতি চেনায় ব্যবহৃত হয়।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 200, fill: FK.alpha('#f2f0e6', .7) }, g);
    const xmark = (x, y) => { E('path', { d: `M${x - 7} ${y - 7}L${x + 7} ${y + 7}M${x + 7} ${y - 7}L${x - 7} ${y + 7}`, stroke: '#a8302a', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, g); };
    B.tx(g, 180, 78, '×', { fs: 24, a: 'middle', w: 700, c: C.mu });
    if (ty === 'same') { rice(g, 90, 120, 1.6); rice(g, 270, 120, 1.6); B.tx(g, 90, 140, 'BRRI ধান28', { fs: 10, a: 'middle', c: C.fg }); B.tx(g, 270, 140, 'BRRI ধান29', { fs: 10, a: 'middle', c: C.fg });
      B.arrow(g, 180, 98, 180, 150, '#3a7a3a', { w: 1.6 }); rice(g, 180, 196, 1.2); B.tx(g, 236, 176, 'উর্বর সংকর → বীজ দেয়', { fs: 10, c: '#2a6a2a', w: 700 }); }
    if (ty === 'diff') { rice(g, 90, 120, 1.6); wheat(g, 270, 128, 1.5); B.tx(g, 90, 140, 'ধান', { fs: 10, a: 'middle', c: C.fg }); B.tx(g, 270, 146, 'গম', { fs: 10, a: 'middle', c: C.fg });
      B.arrow(g, 180, 98, 180, 150, '#a8302a', { w: 1.6 }); xmark(180, 168); B.tx(g, 200, 172, 'নিষেক হয় না — সংকর নেই', { fs: 10, c: '#a8302a', w: 700 }); }
    if (ty === 'mule') { B.equid(g, 80, 110, 1.15, { col: '#8a5a3a', dk: '#3a2414', ear: 6, mane: '#3a2414' }); B.equid(g, 262, 110, 1.05, { col: '#9a9488', dk: '#4a463e', ear: 14, tuft: true });
      B.tx(g, 90, 136, 'ঘোড়া (2n = 64)', { fs: 10, a: 'middle', c: C.fg }); B.tx(g, 270, 136, 'গাধা (2n = 62)', { fs: 10, a: 'middle', c: C.fg });
      B.arrow(g, 180, 98, 180, 132, '#a86a10', { w: 1.6 }); B.equid(g, 170, 192, .8, { col: '#8a6a50', dk: '#3a2818', ear: 10, tuft: true }); B.tx(g, 214, 172, 'খচ্চর (2n = 63) — বন্ধ্যা', { fs: 10, c: '#8a4a10', w: 700 }); }
    B.tx(g, 180, 226, ST[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 248, { same: 'একই প্রজাতি — অবাধে প্রজনন, উর্বর সন্তান', diff: 'ভিন্ন প্রজাতি — প্রজনন-বিচ্ছিন্নতা', mule: 'সংকর জন্মালেও বন্ধ্যা — তাই ভিন্ন প্রজাতি' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ আমের শাখা: বল্লমাকার পাতার গুচ্ছ, ঝুলন্ত ড্রুপ ফল ═════════ */
B.mangoTwig = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), M = B.TS('mango');
  E('path', { d: 'M-70 -6C-40 -10 -10 -12 20 -20', stroke: '#6a4a2a', 'stroke-width': 3.2, fill: 'none', 'stroke-linecap': 'round' }, gg);
  [[-PI + .6, 42], [-PI + 1.1, 46], [-PI / 2 - .2, 44], [-PI / 2 + .4, 46], [-.7, 44], [-.2, 40], [.5, 36], [-PI + 1.8, 40]].forEach(([a, L], i) => {
    E('path', { d: leafD(20, -20, a, L, 7.2), fill: B.vol(gg, 'leaf'), stroke: '#2e5a1a', 'stroke-width': .5 }, gg);
    const c = Math.cos(a), sn = Math.sin(a); E('path', { d: `M20 -20L${f1(20 + c * L * .96)} ${f1(-20 + sn * L * .96)}`, stroke: '#d8e8a0', 'stroke-width': .6 }, gg);
    for (let k = 1; k < 7; k++) { const u = k / 7, px = 20 + c * L * u, py = -20 + sn * L * u; [1, -1].forEach(sd => E('path', { d: `M${f1(px)} ${f1(py)}l${f1(Math.cos(a + sd * .9) * 5.4)} ${f1(Math.sin(a + sd * .9) * 5.4)}`, stroke: FK.alpha('#d8e8a0', .7), 'stroke-width': .35 }, gg)); } });
  /* ফলের বোঁটা ও ফল */
  E('path', { d: 'M-30 -9C-32 4 -30 16 -26 24', stroke: '#5a7a2a', 'stroke-width': 1.4, fill: 'none' }, gg);
  E('path', { d: 'M-26 24C-38 26 -44 42 -40 56C-36 70 -22 76 -12 70C-4 64 -2 52 -6 40C-10 30 -16 24 -26 24Z', fill: B.vol(gg, 'mango', { cx: .35, cy: .3 }), stroke: M.dk, 'stroke-width': .8 }, gg);
  E('path', { d: 'M-34 40C-30 36 -24 36 -20 40', stroke: FK.alpha('#5a8a2a', .5), 'stroke-width': 3, fill: 'none' }, gg);
  return gg; };

V.binomialAnatomy = Object.assign({ t: 'দ্বিপদ নামের গঠন', k: ['2d', 'int', 'quiz'], cap: 'লিনিয়াসের (1753) প্রবর্তিত দ্বিপদ নামকরণ: প্রতিটি প্রজাতির নাম দুই পদে — গণ নাম + প্রজাতিক বিশেষণ, শেষে নামদাতার সংক্ষিপ্ত নাম। ছাপার সময় দুই পদ ইটালিক, হাতে লিখলে প্রতিটি পদের নিচে আলাদা দাগ; লেখকের নাম ইটালিক হয় না।' },
  BK.diagram({ W: 360, H: 300, label: 'দ্বিপদ নাম',
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      E('rect', { x: 0, y: 150, width: 360, height: 150, fill: FK.alpha('#eef4e4', .6) }, g);
      B.mangoTwig(P('plant'), 214, 206, 1.08);
      /* ছাপা রূপ */
      const ty = 78, t1 = B.tx(P('gen'), 20, ty, 'Mangifera', { fs: 26, c: C.fg, st: 'font-style:italic;font-family:Georgia,serif' }); t1.setAttribute('textLength', 132);
      const t2 = B.tx(P('epi'), 160, ty, 'indica', { fs: 26, c: C.fg, st: 'font-style:italic;font-family:Georgia,serif' }); t2.setAttribute('textLength', 76);
      const t3 = B.tx(P('auth'), 244, ty, 'L.', { fs: 26, c: '#8a4a2a', st: 'font-family:Georgia,serif' }); t3.setAttribute('textLength', 22);
      E('circle', { cx: 31, cy: 68, r: 12, fill: 'none', stroke: '#c0392b', 'stroke-width': 1.2, 'stroke-dasharray': '3 2' }, P('cap'));
      /* হাতে লেখা রূপ: প্রতিটি পদের নিচে আলাদা দাগ */
      const hw = (gg, x, w, s) => { B.tx(gg, x, 134, s, { fs: 19, c: '#2a3a6a', st: "font-family:'Segoe Script','Comic Sans MS',cursive" }); E('path', { d: `M${x} 140q${w / 2} 2 ${w} 0`, stroke: '#2a3a6a', 'stroke-width': 1.3, fill: 'none' }, gg); };
      hw(P('hand'), 20, 104, 'Mangifera'); hw(P('hand'), 132, 56, 'indica');
      B.tx(g, 20, 112, 'হাতে লেখা হলে:', { fs: 9.6, c: C.mu });
      hits(this.parts, part, 14); },
    parts: [
      { id: 'gen', bn: 'গণ নাম (Generic name)', lb: 'গণ নাম', en: 'Genus', fn: 'প্রথম পদ; বিশেষ্য, এক শব্দের, প্রথম অক্ষর বড় হাতের। একই গণের সব প্রজাতি এ নাম ভাগ করে (Mangifera indica, Mangifera sylvatica)।', a: [84, 64], l: [104, 24], an: 'middle' },
      { id: 'epi', bn: 'প্রজাতিক বিশেষণ (Specific epithet)', lb: 'প্রজাতিক বিশেষণ', en: 'Specific epithet', fn: 'দ্বিতীয় পদ; সব অক্ষর ছোট হাতের; প্রায়ই বৈশিষ্ট্য, স্থান বা ব্যক্তির নাম নির্দেশ করে — indica = ভারতীয় উপমহাদেশের। একা ব্যবহার করা যায় না।', a: [196, 62], l: [196, 24], an: 'middle' },
      { id: 'auth', bn: 'নামদাতার সংক্ষিপ্ত নাম (Author citation)', lb: 'নামদাতা', en: 'Author', fn: 'যিনি প্রথম বৈধভাবে নামটি প্রকাশ করেন তাঁর নামের সংক্ষেপ — L. মানে লিনিয়াস; সোজা অক্ষরে লেখা হয়, ইটালিক নয়।', a: [255, 66], l: [340, 30], an: 'end' },
      { id: 'cap', bn: 'গণ নামের প্রথম অক্ষর বড় হাতের', lb: 'বড় হাতের অক্ষর', en: 'Capital initial', fn: 'গণ নাম সবসময় বড় হাতের অক্ষরে শুরু; প্রজাতিক বিশেষণ সবসময় ছোট হাতের অক্ষরে — ব্যক্তির নাম থেকে এলেও।', a: [24, 58], l: [8, 40], an: 'start' },
      { id: 'hand', bn: 'হাতে লেখার নিয়ম', lb: 'পৃথক নিম্নরেখা', en: 'Underline each word', fn: 'হাতে লেখার সময় ইটালিক সম্ভব নয়, তাই গণ নাম ও প্রজাতিক বিশেষণের নিচে আলাদা আলাদা দাগ টানতে হয়।', a: [190, 140], l: [300, 128], an: 'start' },
      { id: 'plant', bn: 'আম (Mangifera indica L.) — গোত্র Anacardiaceae', lb: 'আম গাছের শাখা', en: 'Mango', fn: 'বাংলাদেশের জাতীয় বৃক্ষ। বল্লমাকার সরল পাতা, মাংসল ড্রুপ ফল (শক্ত আঁটির ভেতরে একটি বীজ)।', a: [196, 254], l: [100, 286], an: 'end' }
    ]
  }));

/* ═════════ কাঁঠাল গাছ: কাণ্ডে ফল (কাণ্ডজ ফলন) ═════════ */
B.jackTree = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), Bk = B.TS('bark');
  E('path', { d: 'M-8 0C-8 -20 -7 -40 -6 -56L6 -56C7 -40 8 -20 8 0Z', fill: B.lin(gg, 'bark', 0), stroke: Bk.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M-5 -50L-22 -70M5 -50L22 -72M0 -56V-78', stroke: Bk.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, gg);
  for (let i = 0; i < 26; i++) { const a = B.rnd(i) * 2 * PI, r = 18 + B.rnd(i + 30) * 20; E('path', { d: B.ellD(Math.cos(a) * r * 1.2, -80 + Math.sin(a) * r * .7, 8, 4.4, a * 57 + 20), fill: B.TS('leaf').c, stroke: '#2e5a1a', 'stroke-width': .4 }, gg); }
  const jf = (fx, fy, r) => { E('path', { d: `M${fx} ${fy - r * 1.4}V${fy - r * 1.6}`, stroke: '#5a4a2a', 'stroke-width': 1 }, gg); E('path', { d: B.ellD(fx, fy, r * .8, r * 1.4), fill: '#a8b84a', stroke: '#5a6a1a', 'stroke-width': .6 }, gg);
    for (let k = 0; k < 10; k++) E('circle', { cx: f1(fx + (B.rnd(k + fx) - .5) * r * 1.2), cy: f1(fy + (B.rnd(k + fy) - .5) * r * 2.2), r: .8, fill: '#6a7a2a' }, gg); };
  jf(-11, -18, 6); jf(11, -32, 7); jf(-11, -44, 5.4);
  return gg; };

const CN = {
  aam: ['আম', 'Mangifera indica L.', [['আম', 'বাংলা'], ['Mango', 'ইংরেজি'], ['Aam', 'হিন্দি'], ['Mangue', 'ফরাসি'], ['Manga', 'পর্তুগিজ'], ['Mangga', 'মালয়']], 'বিভিন্ন ভাষায় একই গাছের ভিন্ন নাম — কিন্তু বৈজ্ঞানিক নাম সারা পৃথিবীতে একটিই: Mangifera indica L.।'],
  jac: ['কাঁঠাল', 'Artocarpus heterophyllus Lam.', [['কাঁঠাল', 'বাংলা'], ['Jackfruit', 'ইংরেজি'], ['Kathal', 'হিন্দি'], ['Pala', 'তামিল'], ['Nangka', 'মালয়'], ['Jaca', 'পর্তুগিজ']], 'বাংলাদেশের জাতীয় ফল। Lam. = ফরাসি উদ্ভিদবিদ লামার্ক, যিনি নামটি প্রকাশ করেন।']
};
V.commonNames = Object.assign({}, B.seg({
  id: 'cnm', t: 'এক উদ্ভিদ, বহু নাম — তাই বৈজ্ঞানিক নাম', H: 290, def: 'aam', types: Object.fromEntries(Object.entries(CN).map(([k, v]) => [k, [v[0], v[0] + ' — ' + v[1], v[3]]])),
  cap: 'স্থানীয় নাম অঞ্চল ও ভাষাভেদে বদলায়, আবার একই নামে ভিন্ন উদ্ভিদকেও ডাকা হয় — এতে বিভ্রান্তি হয়। বৈজ্ঞানিক নাম ল্যাটিন (বা ল্যাটিনকৃত), এক উদ্ভিদের একটিই বৈধ নাম, এবং সারা পৃথিবীতে একই।',
  art(g, C, ty) { const [bn, sci, names] = CN[ty];
    E('rect', { x: 0, y: 0, width: 360, height: 290, fill: FK.alpha('#f4f1e6', .6) }, g);
    if (ty === 'aam') B.mangoTwig(g, 206, 140, .86); else { E('path', { d: 'M120 200H240', stroke: B.TS('grass').c, 'stroke-width': 4 }, g); B.jackTree(g, 180, 200, 1.35); }
    const pos = [[46, 40], [314, 40], [30, 120], [330, 120], [56, 196], [304, 196]];
    names.forEach(([n, l], i) => { const [x, y] = pos[i]; E('rect', { x: x - 40, y: y - 15, width: 80, height: 32, rx: 8, fill: C.sf, stroke: FK.alpha(C.fg, .25) }, g);
      B.tx(g, x, y, n, { fs: 11, a: 'middle', w: 700, c: C.fg }); B.tx(g, x, y + 12, l, { fs: 8.8, a: 'middle', c: C.mu }); });
    E('rect', { x: 70, y: 232, width: 220, height: 34, rx: 10, fill: FK.alpha('#2a6a3a', .12), stroke: '#2a6a3a', 'stroke-width': 1.4 }, g);
    const t = B.tx(g, 180, 254, '', { fs: 13, a: 'middle', w: 700, c: '#1e4a28' }); const pr = sci.split(' '), au = pr.pop(); const it = E('tspan', { 'font-style': 'italic' }, t); it.textContent = pr.join(' ') + ' '; const a2 = E('tspan', {}, t); a2.textContent = au;
    B.tx(g, 180, 282, 'বৈজ্ঞানিক নাম — একটিই, সারা বিশ্বে', { fs: 10, a: 'middle', c: C.mu });
    pos.forEach(([x, y]) => E('path', { d: `M${x} ${y + 18}L${f1(lerp(x, 180, .5))} ${f1(lerp(y + 18, 230, .55))}`, stroke: FK.alpha('#2a6a3a', .35), 'stroke-width': 1, 'stroke-dasharray': '3 3' }, g)); }
}));
})();
