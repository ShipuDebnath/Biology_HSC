/* ═══════════════════════════════════════════════════════════════════
   visuals0a — শারীরস্থান ও কলাবিদ্যার চিত্রের সহায়ক (B100 এ যোগ হয়)
   লক্ষ্য: কার্টুন নয়, পাঠ্যবই/অ্যাটলাসের মতো — বাস্তব টিস্যুর রং, তিন ধাপের গ্রেডিয়েন্টে আয়তন,
   সরু গাঢ় সীমারেখা, পেশিতন্তু/চর্বি/যকৃৎকোষের নকশা (pattern), মসৃণ বক্ররেখা (Catmull-Rom),
   নলাকার অঙ্গে স্তরে স্তরে স্ট্রোক দিয়ে চকচকে নল, H&E রঞ্জনে কোষ।
   সব গ্রেডিয়েন্ট/প্যাটার্ন/মার্কার svg প্রতি একবার তৈরি হয় (memo) — প্রতি ফ্রেমে নতুন defs নয়।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, BK = window.BK, T = BK.T, B = window.B100, PI = Math.PI;

/* টিস্যুর রং: [হালকা, মূল, গাঢ়] */
const TS0 = {
  pyel: ['#f7e58a', '#e2c23c', '#9a7a14'],  /* মটরবীজ হলুদ */
  pgrn: ['#cfe39a', '#8fb048', '#4e6c1c'],  /* মটরবীজ সবুজ */
  leaf: ['#bfe0a0', '#6fa848', '#3a6a22'],  /* পাতা */
  stem: ['#d4e8b0', '#8ab860', '#4a7a2c'],  /* কাণ্ড */
  pflw: ['#d8b4e8', '#9a5ab8', '#5a2a7a'],  /* বেগুনি ফুল */
  wflw: ['#ffffff', '#ece8f0', '#a8a0b0'],  /* সাদা ফুল */
  rflw: ['#f6a0a8', '#d8384a', '#8a1424'],  /* লাল ফুল */
  pkflw: ['#fbd8e0', '#ef9ab0', '#b0506a'], /* গোলাপি ফুল */
  ypod: ['#f4eb9a', '#d8c84a', '#8a7a18'],  /* হলুদ শুঁটি */
  chrA: ['#cfe0f6', '#6a92cc', '#2c4f88'],  /* ক্রোমোজোম (পিতৃ) */
  chrB: ['#f8d4d8', '#d27884', '#8c3442'],  /* ক্রোমোজোম (মাতৃ) */
  fur: ['#d9b48a', '#a87a4c', '#5e3e20'],   /* বাদামি লোম */
  furG: ['#d8d4cc', '#a19a8e', '#5c564c'],  /* ধূসর লোম */
  furD: ['#8a7058', '#5a4430', '#2c2014'],  /* গাঢ় লোম */
  fthr: ['#f4efe4', '#d8cdb6', '#8f826a'],  /* সাদাটে পালক */
  goose: ['#d9d2c4', '#a59a86', '#5f5646'], /* গ্রেল্যাগ রাজহাঁসের ধূসর-বাদামি পালক */
  beak: ['#fcd58a', '#eaa040', '#a8601a'],  /* কমলা ঠোঁট/পা */
  egg: ['#fbf8f0', '#ebe3d0', '#aca286'],   /* ডিম */
  silk: ['#ffffff', '#eef2f6', '#9fb0c0'],  /* রেশম সুতা */
  spdr: ['#c8a46a', '#8a6230', '#45301a'],  /* মাকড়সার দেহ */
  beeY: ['#f6d27a', '#d89a2a', '#8a5a12'],  /* মৌমাছির হলুদাভ খণ্ড */
  beeB: ['#7a6050', '#3e2e24', '#1a120c'],  /* মৌমাছির গাঢ় খণ্ড */
  wing: ['#f4f8fc', '#dde7f0', '#93a5b8'],  /* স্বচ্ছ ডানা */
  wax: ['#fbefc0', '#ecd37a', '#b0922e'],   /* মোম */
  honey: ['#f8d070', '#d89420', '#8a5a08'], /* মধু */
  fish: ['#d6dcc4', '#98a47c', '#56603e'],  /* তেলাপিয়া (জলপাই-ধূসর) */
  toad: ['#d8c49a', '#a8905a', '#62502a'],  /* ব্যাঙ */
  wtr: ['#e6f2fa', '#b8d8ec', '#5f90b4'],   /* পানি */
  soil: ['#e4d2b4', '#b89a6c', '#6e5634'],  /* মাটি */
  grass: ['#d6e8b4', '#9ac060', '#5a8030'], /* ঘাস */
  wood: ['#d8b88c', '#a07848', '#5c4022'],  /* কাঠ */
  metal: ['#eef0f2', '#c4c8cc', '#7a8088'], /* ধাতু */
  shell: ['#efe2c8', '#c9ad7c', '#7e6538'], /* শামুকের খোলস */
  snail: ['#e8d4c0', '#c49c80', '#7a5640'], /* শামুকের দেহ */
  tit: ['#9ac4e8', '#3a78b8', '#1c4070'],   /* নীল টিট পাখি */
  ttY: ['#fbeb98', '#e8c838', '#9a8010'],   /* টিটের হলুদ বুক */
  muc: ['#fad6d2', '#eba39e', '#b35e5e'],   /* শ্লেষ্মাস্তর (সাধারণ) */
  stom: ['#f8cbc5', '#e1918b', '#a64f4e'],  /* পাকস্থলী */
  int: ['#f8d3c4', '#e4a28e', '#a96350'],   /* ক্ষুদ্রান্ত্র */
  colon: ['#f3d8c6', '#dbae90', '#9b6c4f'], /* বৃহদন্ত্র */
  eso: ['#f6d2cd', '#df9f99', '#a35e5a'],   /* অন্ননালি */
  mus: ['#f0a497', '#c95d50', '#86302a'],   /* পেশি */
  sub: ['#fdf1ea', '#f2d4c5', '#c19885'],   /* সাবমিউকোসা (যোজক টিস্যু) */
  ser: ['#fcf6ea', '#eedcbd', '#b39869'],   /* সেরোসা */
  liv: ['#cd7a62', '#9c4433', '#5a2219'],   /* যকৃৎ */
  gb: ['#bfd683', '#789c37', '#44601a'],    /* পিত্তথলি */
  bile: ['#d3df86', '#94ac3e', '#5b6e1d'],  /* পিত্তরস/নালি */
  pan: ['#f9e6c3', '#e9c38e', '#ae8350'],   /* অগ্ন্যাশয় */
  fat: ['#fff7cf', '#f3da7c', '#c09f3a'],   /* চর্বি */
  art: ['#f48d80', '#c9352b', '#80201a'],   /* ধমনি */
  vein: ['#97aae2', '#4060ab', '#223a75'],  /* শিরা */
  port: ['#b49ad6', '#7656a8', '#45306d'],  /* পোর্টাল শিরা (পুষ্টিসমৃদ্ধ, অক্সিজেন কম) */
  lym: ['#fdfae6', '#ece4b7', '#a99d5c'],   /* লসিকা/ল্যাকটিয়াল (দুধসাদা) */
  nrv: ['#fdf1b6', '#ebca4e', '#a3831a'],   /* স্নায়ু */
  ena: ['#ffffff', '#f4f1e8', '#c9c2ad'],   /* এনামেল */
  den: ['#fcf2d8', '#e9d6a3', '#a98f55'],   /* ডেন্টিন */
  pulp: ['#fac3bc', '#e2827b', '#a24843'],  /* পাল্প */
  cem: ['#f5ecd2', '#dcc99a', '#9c8653'],   /* সিমেন্টাম */
  bone: ['#f8f2e4', '#e3d6b6', '#a29270'],  /* অস্থি */
  gum: ['#f9c1c5', '#e58c93', '#a3525a'],   /* মাড়ি */
  tng: ['#f6aeb1', '#d8747b', '#96424a'],   /* জিহ্বা */
  skin: ['#f2d3b8', '#d9a682', '#99694a'],  /* ত্বক */
  cart: ['#f0f5f8', '#cfdee7', '#87a0b0'],  /* তরুণাস্থি */
  cyt: ['#fbe5ee', '#efbcd2', '#b77898'],   /* সাইটোপ্লাজম (ইওসিন) */
  nuc: ['#9585cf', '#5c4c9e', '#31266a'],   /* নিউক্লিয়াস (হেমাটক্সিলিন) */
  muco: ['#f1f4fc', '#d6def1', '#8a99c0'],  /* মিউসিন (গবলেট কোষ) */
  zym: ['#f6dcc0', '#d9a46d', '#94622e'],   /* জাইমোজেন দানা */
  food: ['#ecdcb3', '#c9a86a', '#876833'],  /* খাদ্য/কাইম */
  feces: ['#c7a27a', '#8b6440', '#553a20'], /* মল */
  air: ['#eef6fc', '#cfe4f3', '#7aa2c1'],
  mar: ['#e88a7c', '#c0473a', '#7c2219'],   /* লাল অস্থিমজ্জা */
  ymar: ['#fdf0b8', '#eed06e', '#b0902e'],  /* হলুদ অস্থিমজ্জা (চর্বি) */
  spg: ['#f6ecd4', '#e0cfa4', '#9d8a5e'],   /* স্পঞ্জি অস্থির ট্র্যাবেকুলি */
  peri: ['#f7dccb', '#e4b69c', '#a8735a'],  /* পেরিঅস্টিয়াম */
  tnd: ['#fbfbf6', '#e6e6da', '#a3a392'],   /* টেনডন (রুপালি-সাদা) */
  lig: ['#f7f3e6', '#e2d9bd', '#a29775'],   /* লিগামেন্ট */
  syn: ['#eef7fb', '#cfe7f2', '#86b3c8'],   /* সাইনোভিয়াল তরল */
  fcart: ['#f3f1ea', '#dcd6c4', '#9b937a'], /* তন্তুময় তরুণাস্থি (মেনিসকাস) */
  ecart: ['#f6eef2', '#e3cfd9', '#a5869a'], /* স্থিতিস্থাপক তরুণাস্থি */
  tend2: ['#fff8ec', '#f0dfc0', '#b89f72'], /* টেনডনের প্রান্ত */
  gm: ['#f1d9d3', '#d9aea6', '#9a6d66'],    /* ধূসর পদার্থ (তাজা মস্তিষ্ক, গোলাপি-ধূসর) */
  wm: ['#fdf9f1', '#efe6d6', '#b3a68e'],    /* শ্বেত পদার্থ */
  csf: ['#eef7fc', '#cfe6f4', '#7fa9c4'],   /* সেরিব্রোস্পাইনাল তরল / ভেন্ট্রিকল */
  dura: ['#f3e3d6', '#d9bba3', '#9a7a62'],  /* ডুরা ম্যাটার */
  myel: ['#fffdf6', '#f2ecd8', '#b9ad8a'],  /* মায়েলিন আবরণ */
  axn: ['#f6e3a6', '#dfbf5c', '#9c7e24'],   /* অ্যাক্সন/নিউরনের সাইটোপ্লাজম */
  scl: ['#ffffff', '#f2efe8', '#b9b3a4'],   /* স্ক্লেরা */
  cho: ['#8a5a4a', '#5a3328', '#2e1712'],   /* কোরয়েড (রঞ্জকযুক্ত) */
  ret: ['#f8c9a8', '#e59a72', '#a65e3c'],   /* রেটিনা */
  iris: ['#a98a5e', '#6f5530', '#3e2e16'],  /* আইরিস (বাদামি) */
  lens: ['#fbfcff', '#e3ecf6', '#9fb3c9'],  /* লেন্স */
  vit: ['#f6fbfe', '#e6f2f9', '#a9c6d8'],   /* ভিট্রিয়াস ও অ্যাকুয়াস রস */
  cor: ['#f4fbff', '#dcebf5', '#8fb0c6'],   /* কর্নিয়া */
  endo: ['#f9e0d4', '#e8ae96', '#ad6c53'],  /* অন্তঃক্ষরা গ্রন্থি (সাধারণ) */
  thy: ['#ecaa98', '#c56a55', '#83382a'],   /* থাইরয়েড (লালচে) */
  coll: ['#fff3e0', '#f6dcae', '#c49c55'],  /* কলয়েড */
  adc: ['#fbe7a9', '#eec860', '#ad8822'],   /* অ্যাড্রিনাল কর্টেক্স (হলুদ, লিপিডযুক্ত) */
  adm: ['#d7a39c', '#a8635a', '#6c342d'],   /* অ্যাড্রিনাল মেডুলা */
  isl: ['#f7eef4', '#e3cadd', '#a5829c'],   /* আইলেট অব ল্যাঙ্গারহ্যান্স (হালকা রঞ্জিত) */
  perl: ['#f8f3e9', '#e8dcc3', '#a8977a'],  /* পেরিলিম্ফ/এন্ডোলিম্ফ থলি */
  nucP: ['#d9d2f0', '#b8aee0', '#3a2a7a'],  /* হালকা (ইউক্রোমাটিক) নিউক্লিয়াস */
  tes: ['#f6d6d0', '#e3aaa0', '#a86860'],   /* শুক্রাশয় ও সেমিনিফেরাস নালিকা */
  tun: ['#fbf8f2', '#ece4d4', '#a89a7e'],   /* টিউনিকা অ্যালবুজিনিয়া (সাদা তন্তুময়) */
  glnd: ['#f4dcc0', '#e0b98c', '#a07a4a'],  /* সেমিনাল ভেসিকল, প্রস্টেট */
  ut: ['#f2b8b0', '#d97f78', '#994a46'],    /* জরায়ু মায়োমেট্রিয়াম */
  endm: ['#f8cfd4', '#ea98a4', '#ac5868'],  /* এন্ডোমেট্রিয়াম */
  ova: ['#f6e0d0', '#e8bfa0', '#ab7f5e'],   /* ডিম্বাশয়ের স্ট্রোমা */
  amn: ['#eef7fc', '#d4e9f5', '#86afc8'],   /* অ্যামনিয়ন ও অ্যামনিওটিক তরল */
  plac: ['#c86a72', '#9a3a46', '#5e1c26'],  /* অমরা */
  fet: ['#f8d8c8', '#eab49c', '#b07860'],   /* ভ্রূণ */
  ecto: ['#cfe2f8', '#8ab4e6', '#3a6aa8'],  /* এক্টোডার্ম (নীল) */
  meso: ['#f8d0d0', '#e88c8c', '#a84444'],  /* মেসোডার্ম (লাল) */
  endo3: ['#fbf0b8', '#efd462', '#a88a1a']  /* এন্ডোডার্ম (হলুদ) */,
  kera: ['#f6ead2', '#e2c99a', '#a68a58'],  /* কেরাটিন স্তর */
  epid: ['#f6d9c6', '#e5b495', '#a5735a'],  /* জীবিত এপিডার্মিস */
  derm: ['#f8e2dc', '#ecbcb2', '#b0776c'],  /* ডার্মিস */
  neu: ['#f3e3ef', '#dcbcd6', '#8f5e8a'],   /* নিউট্রোফিল সাইটোপ্লাজম */
  mac: ['#e9e4f4', '#c9bde6', '#6c5aa0'],   /* ম্যাক্রোফেজ */
  bcl: ['#dcecf8', '#9fc6e8', '#3a6a9a'],   /* B কোষ */
  tcl: ['#dff2e3', '#a6d8b0', '#3e7d4c'],   /* T কোষ */
  ab: ['#fbe6c4', '#f0b85a', '#a8701a'],    /* অ্যান্টিবডি */
  bact: ['#d8e6b8', '#a9c46c', '#5e7a2a'],  /* ব্যাকটেরিয়া */
  vir: ['#f6d4d4', '#e08a8a', '#9a3a3a'],   /* ভাইরাস */
  lymn: ['#f2e6d8', '#dcc0a0', '#8f6e4c'],  /* লসিকাগ্রন্থি */
  /* ─── উদ্ভিদ শ্রেণিবিন্যাসের রং ─── */
  cwall: ['#e8f2d0', '#b8d08a', '#6a8a3a'], /* সেলুলোজ কোষপ্রাচীর */
  pcyt: ['#f4f8e8', '#dfe9c6', '#8f9f6a'],  /* উদ্ভিদকোষের সাইটোপ্লাজম */
  chlo: ['#a8d878', '#5aa040', '#2a6020'],  /* ক্লোরোপ্লাস্ট */
  vac: ['#eef6fb', '#cfe4f0', '#7ea6c0'],   /* কোষরস গহ্বর */
  mito: ['#f8d2b8', '#e09a6a', '#9a5a30'],  /* মাইটোকন্ড্রিয়া */
  starch: ['#ffffff', '#ece8dc', '#a8a08a'],/* শ্বেতসার দানা */
  bark: ['#b89878', '#80603e', '#4a3420'],  /* গাছের বাকল */
  mstd: ['#fff3a0', '#f2d22a', '#a88a10'],  /* সরিষা ফুল */
  frond: ['#c6e4a0', '#78b048', '#3c6c20'], /* ফার্নের পাতা */
  moss: ['#cfe8a0', '#88b84a', '#4a7424'],  /* মস */
  algaG: ['#c8f0a8', '#6cc04a', '#2e7a24'], /* সবুজ শৈবাল */
  cone: ['#e6c890', '#b88a48', '#6e4a1c'],  /* স্ট্রোবিলাস / কোন */
  rice: ['#f4e6a8', '#d8bc58', '#8e7424'],  /* ধানের শিষ */
  mango: ['#f8d870', '#e8a430', '#9a6010'], /* পাকা আম */
  lily: ['#ffffff', '#f2f0f6', '#b0a8c0'],  /* শাপলার সাদা পাপড়ি */
  pad: ['#bde0a0', '#6aa84a', '#2e6020'],   /* শাপলার ভাসমান পাতা */
  mush: ['#f6eee0', '#dcc8a8', '#8a7050'],  /* মাশরুমের টুপি */
  gill: ['#e8b8a8', '#b07868', '#6a3e34'],  /* মাশরুমের ফুলকা */
  arch: ['#f6d6a8', '#e0a050', '#9a6020'],  /* আর্কিয়া */
  prot: ['#e4f0f8', '#a8c8e0', '#4a7aa0']   /* প্রোটোজোয়া */
};
const TS = B.TS = k => { const a = TS0[k] || TS0.muc; return { lt: a[0], c: a[1], dk: a[2] }; };

/* ─── defs: memo ─── */
let gid = 0;
const defs = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };
const memo = (svg, key, mk) => { const m = svg._b100 || (svg._b100 = {}); return m[key] || (m[key] = mk()); };
const svgOf = g => g.ownerSVGElement || g;

/* আয়তন: তিন ধাপের গোলাকার গ্রেডিয়েন্ট (আলো ওপর-বাঁ থেকে) */
B.vol = (g, k, o = {}) => { const svg = svgOf(g), t = TS(k), key = 'v|' + k + '|' + (o.cx || '') + (o.cy || '') + (o.r || ''); return memo(svg, key, () => {
  const id = 'b100v' + (++gid), gr = E('radialGradient', { id, cx: o.cx != null ? o.cx : .36, cy: o.cy != null ? o.cy : .3, r: o.r != null ? o.r : .85 }, defs(svg));
  E('stop', { offset: 0, 'stop-color': t.lt }, gr); E('stop', { offset: .55, 'stop-color': t.c }, gr); E('stop', { offset: 1, 'stop-color': t.dk }, gr); return `url(#${id})`; }); };
/* রৈখিক: হালকা → মূল → গাঢ় */
B.lin = (g, k, a = 90, o = {}) => { const svg = svgOf(g), t = TS(k), key = 'l|' + k + '|' + a + '|' + (o.rev ? 1 : 0); return memo(svg, key, () => {
  const id = 'b100l' + (++gid), r = a * PI / 180, gr = E('linearGradient', { id, x1: (.5 - Math.cos(r) / 2).toFixed(3), y1: (.5 - Math.sin(r) / 2).toFixed(3), x2: (.5 + Math.cos(r) / 2).toFixed(3), y2: (.5 + Math.sin(r) / 2).toFixed(3) }, defs(svg));
  const s = o.rev ? [t.dk, t.c, t.lt] : [t.lt, t.c, t.dk]; s.forEach((c, i) => E('stop', { offset: i / 2, 'stop-color': c }, gr)); return `url(#${id})`; }); };
/* নলের মতো আড়াআড়ি (নালি, রক্তনালি): গাঢ় → হালকা → মূল → গাঢ় */
B.cyl = (g, k, a = 90) => { const svg = svgOf(g), t = TS(k); return memo(svg, 'c|' + k + '|' + a, () => {
  const id = 'b100c' + (++gid), r = a * PI / 180, gr = E('linearGradient', { id, x1: (.5 - Math.cos(r) / 2).toFixed(3), y1: (.5 - Math.sin(r) / 2).toFixed(3), x2: (.5 + Math.cos(r) / 2).toFixed(3), y2: (.5 + Math.sin(r) / 2).toFixed(3) }, defs(svg));
  [[0, t.dk], [.3, t.lt], [.6, t.c], [1, t.dk]].forEach(([o, c]) => E('stop', { offset: o, 'stop-color': c }, gr)); return `url(#${id})`; }); };

/* নকশা (pattern): kind = line | dot | hex | fat | cross | wave; col; o = { s (ফাঁক), a (কোণ), w (রেখার পুরুত্ব) } */
B.pat = (g, kind, col, o = {}) => { const svg = svgOf(g), s = o.s || 5, a = o.a || 0, w = o.w || .6; return memo(svg, 'p|' + kind + '|' + col + '|' + s + '|' + a + '|' + w, () => {
  const id = 'b100p' + (++gid), P = E('pattern', { id, patternUnits: 'userSpaceOnUse', width: kind === 'hex' ? s * 1.732 : s, height: kind === 'hex' ? s * 3 : s, patternTransform: a ? `rotate(${a})` : null }, defs(svg));
  if (kind === 'line') E('path', { d: `M0 ${s / 2}H${s}`, stroke: col, 'stroke-width': w }, P);
  else if (kind === 'cross') E('path', { d: `M0 ${s / 2}H${s}M${s / 2} 0V${s}`, stroke: col, 'stroke-width': w }, P);
  else if (kind === 'dot') { E('circle', { cx: s * .3, cy: s * .3, r: w, fill: col }, P); E('circle', { cx: s * .8, cy: s * .75, r: w * .8, fill: col }, P); }
  else if (kind === 'fat') { E('circle', { cx: s / 2, cy: s / 2, r: s * .44, fill: 'none', stroke: col, 'stroke-width': w }, P); }
  else if (kind === 'wave') E('path', { d: `M0 ${s / 2}q${s / 4} ${-s / 3} ${s / 2} 0t${s / 2} 0`, stroke: col, 'stroke-width': w, fill: 'none' }, P);
  else if (kind === 'hex') { const h = s * 1.732; E('path', { d: `M0 0L${h / 2} ${s / 2}V${s * 1.5}L0 ${s * 2}M${h / 2} ${s * 1.5}L${h} ${s * 2}M${h / 2} ${s / 2}L${h} 0M0 ${s * 2}V${s * 3}M${h} ${s * 2}V${s * 3}`, stroke: col, 'stroke-width': w, fill: 'none' }, P); }
  return `url(#${id})`; }); };
/* ক্লিপ: একটি আকৃতির ভেতরে নকশা আঁকতে */
B.clip = (g, key, d) => { const svg = svgOf(g); return memo(svg, 'k|' + key, () => { const id = 'b100k' + (++gid), cp = E('clipPath', { id }, defs(svg)); E('path', { d }, cp); return `url(#${id})`; }); };
/* তীরমুখ মার্কার (রঙ অনুযায়ী) */
B.mk = (g, col, s = 6) => { const svg = svgOf(g); return memo(svg, 'm|' + col + '|' + s, () => { const id = 'b100m' + (++gid), m = E('marker', { id, viewBox: '0 0 10 10', refX: 8, refY: 5, markerWidth: s, markerHeight: s, orient: 'auto-start-reverse', markerUnits: 'userSpaceOnUse' }, defs(svg)); E('path', { d: 'M0 0L10 5L0 10L3 5Z', fill: col }, m); return `url(#${id})`; }); };

/* ─── জ্যামিতি ─── */
const f1 = v => (+v).toFixed(1);
/* Catmull-Rom → কিউবিক বেজিয়ার; k = টান (০.৫ স্বাভাবিক) */
B.smooth = (pts, closed, k = .5) => {
  const n = pts.length; if (n < 2) return ''; const P = i => closed ? pts[(i + n) % n] : pts[Math.max(0, Math.min(n - 1, i))];
  let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
  for (let i = 0; i < (closed ? n : n - 1); i++) { const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    d += `C${f1(p1[0] + (p2[0] - p0[0]) * k / 3)} ${f1(p1[1] + (p2[1] - p0[1]) * k / 3)} ${f1(p2[0] - (p3[0] - p1[0]) * k / 3)} ${f1(p2[1] - (p3[1] - p1[1]) * k / 3)} ${f1(p2[0])} ${f1(p2[1])}`; }
  return d + (closed ? 'Z' : '');
};
/* বক্ররেখার নমুনা বিন্দু (Catmull-Rom দিয়ে ঘন করা) */
B.dense = (pts, per = 8, closed) => { const n = pts.length, out = [], P = i => closed ? pts[(i + n) % n] : pts[Math.max(0, Math.min(n - 1, i))];
  for (let i = 0; i < (closed ? n : n - 1); i++) { const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    for (let j = 0; j < per; j++) { const t = j / per, t2 = t * t, t3 = t2 * t; out.push([0, 1].map(c => .5 * ((2 * p1[c]) + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3))); } }
  if (!closed) out.push(pts[n - 1].slice()); return out; };
/* সমান ফাঁকে পুনর্নমুনা: [[x, y, nx, ny]] — n = বাম দিকের অভিলম্ব */
B.resample = (pts, step) => { const out = []; let acc = 0;
  for (let i = 1; i < pts.length; i++) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], L = Math.hypot(x1 - x0, y1 - y0); if (!L) continue; const tx = (x1 - x0) / L, ty = (y1 - y0) / L;
    while (acc <= L) { out.push([x0 + tx * acc, y0 + ty * acc, -ty, tx]); acc += step; } acc -= L; }
  return out; };
/* মধ্যরেখা ও প্রস্থ থেকে নলের বাইরের সীমা (বন্ধ পথ); w = সংখ্যা বা u→প্রস্থ */
B.ribbon = (pts, w) => { const D = B.dense(pts, 6), L = [], R = [], n = D.length;
  for (let i = 0; i < n; i++) { const a = D[Math.max(0, i - 1)], b = D[Math.min(n - 1, i + 1)], l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, nx = -(b[1] - a[1]) / l, ny = (b[0] - a[0]) / l, ww = (typeof w === 'function' ? w(i / (n - 1)) : w) / 2;
    L.push([D[i][0] + nx * ww, D[i][1] + ny * ww]); R.push([D[i][0] - nx * ww, D[i][1] - ny * ww]); }
  const pl = p => p.map(q => f1(q[0]) + ' ' + f1(q[1])).join('L');
  return 'M' + pl(L) + 'L' + pl(R.reverse()) + 'Z'; };

/* ─── অঙ্কন ─── */
/* আয়তনওয়ালা অঙ্গ: গ্রেডিয়েন্ট ভরাট + সরু গাঢ় সীমা + ঐচ্ছিক নকশা ও চকচকে আভা */
B.organ = (g, d, k, o = {}) => { const t = TS(k);
  const p = E('path', { d, fill: o.flat ? t.c : o.lin != null ? B.lin(g, k, o.lin) : B.vol(g, k, o.gr || {}), stroke: o.st || t.dk, 'stroke-width': o.sw != null ? o.sw : 1, 'stroke-linejoin': 'round', opacity: o.op != null ? o.op : 1 }, g);
  if (o.pat) E('path', { d, fill: B.pat(g, o.pat, FK.alpha(t.dk, o.pa != null ? o.pa : .28), o.po || {}), stroke: 'none', opacity: o.op != null ? o.op : 1 }, g);
  if (o.hl) E('path', { d: o.hl, fill: 'none', stroke: '#fff', 'stroke-width': o.hlw || 2.2, opacity: .32, 'stroke-linecap': 'round' }, g);
  return p; };
/* নল: মধ্যরেখা বরাবর স্তরে স্তরে স্ট্রোক — সীমা, ভরাট, চকচকে আভা */
B.tube = (g, d, w, k, o = {}) => { const t = TS(k), sw = o.sw != null ? o.sw : 1, cap = o.cap || 'round';
  E('path', { d, stroke: t.dk, 'stroke-width': w + 2 * sw, fill: 'none', 'stroke-linecap': cap, 'stroke-linejoin': 'round', opacity: o.op != null ? o.op : 1 }, g);
  E('path', { d, stroke: t.c, 'stroke-width': w, fill: 'none', 'stroke-linecap': cap, 'stroke-linejoin': 'round', opacity: o.op != null ? o.op : 1 }, g);
  if (w > 3 && o.hl !== false) E('path', { d, stroke: t.lt, 'stroke-width': Math.max(1, w * .34), fill: 'none', 'stroke-linecap': cap, 'stroke-linejoin': 'round', opacity: .8, transform: `translate(${f1(-w * .12)} ${f1(-w * .16)})` }, g);
};
/* লেখা — পটভূমির রঙের আবরণসহ, যাতে অঙ্গের ওপরেও পড়া যায় */
/* রঙের প্যালেট একবার পড়ে একই কাজের ভেতরে পুনর্ব্যবহার — প্রতিটি লেখায় getComputedStyle এড়ানো (ধীর ফোনে ফ্রেম-রেট বাঁচে) */
let PCv = null; const PCC = () => PCv || (PCv = FK.P());
try { new MutationObserver(() => { PCv = null; }).observe(document.documentElement, { attributes: true }); const mq = matchMedia('(prefers-color-scheme: dark)'); mq.addEventListener && mq.addEventListener('change', () => { PCv = null; }); } catch (e) { }
B.tx = (g, x, y, s, o = {}) => { const C = PCC(), st = `paint-order:stroke;stroke:${o.halo || C.sf};stroke-width:${o.hw || 2.6}px;stroke-linejoin:round` + (o.st ? ';' + o.st : ''), at = { x, y, class: 'fk-t' + (o.cls ? ' ' + o.cls : ''), style: `font-size:${o.fs || 10}px;fill:${o.c || C.fg};${st}` };
  if (o.a) at['text-anchor'] = o.a; if (o.w) at['font-weight'] = o.w;
  const el = E('text', at, g); if (typeof s !== 'string' || s.indexOf('<') < 0) { el.textContent = s; return el; } el.innerHTML = s.indexOf('<su') >= 0 ? s.replace(/<sub>(.*?)<\/sub>/g, '<tspan baseline-shift="sub" font-size="75%">$1</tspan>').replace(/<sup>(.*?)<\/sup>/g, '<tspan baseline-shift="super" font-size="75%">$1</tspan>') : s; return el; };
/* লেবেল রেখা: বিন্দু → (ঐচ্ছিক কনুই) → লেখা */
B.lead = (g, C, ax, ay, lx, ly, s, o = {}) => {
  const an = o.a || (lx < ax ? 'end' : 'start'), ex = o.ex;   /* ex = লেখার কাছে অনুভূমিক অংশের দৈর্ঘ্য */
  const d = ex ? `M${ax} ${ay}L${lx - (an === 'end' ? -ex : ex)} ${ly}H${lx}` : `M${ax} ${ay}L${lx} ${ly}`;
  E('path', { d, stroke: o.lc || FK.alpha(C.fg, .55), 'stroke-width': .75, fill: 'none' }, g);
  E('circle', { cx: ax, cy: ay, r: o.r || 1.7, fill: o.dc || C.fg }, g);
  return B.tx(g, lx + (an === 'end' ? -2.5 : an === 'start' ? 2.5 : 0), ly + 3.4, s, { fs: o.fs || 9.6, a: an, w: o.w || 520, c: o.c || C.fg });
};
/* বাঁকা তীর (মার্কারসহ) */
B.carrow = (g, d, col, o = {}) => E('path', { d, stroke: col, 'stroke-width': o.w || 1.4, fill: 'none', 'stroke-dasharray': o.dash || null, 'marker-end': B.mk(g, col, o.s || 6), opacity: o.op != null ? o.op : 1, 'stroke-linecap': 'round' }, g);
/* স্কেল দণ্ড */
B.scale = (g, C, x, y, len, s) => { E('path', { d: `M${x} ${y - 3}v6M${x} ${y}h${len}M${x + len} ${y - 3}v6`, stroke: C.fg, 'stroke-width': 1 }, g); T(g, x + len / 2, y - 5, s, { fs: 8.5, a: 'middle', c: C.mu }); };

/* ─── কলাবিদ্যা (H&E) ─── */
/* নিউক্লিয়াস: ডিম্বাকার, ক্রোমাটিনের দানাসহ */
B.nuc = (g, x, y, rx, ry, a = 0, o = {}) => { const t = TS(o.k || 'nuc');
  E('ellipse', { cx: f1(x), cy: f1(y), rx, ry, fill: t.c, stroke: t.dk, 'stroke-width': .5, transform: a ? `rotate(${f1(a)} ${f1(x)} ${f1(y)})` : null, opacity: o.op != null ? o.op : 1 }, g);
  if (rx > 2.2 && o.chr !== false) E('circle', { cx: f1(x + rx * .2), cy: f1(y - ry * .15), r: Math.min(rx, ry) * .28, fill: t.dk, opacity: .8 }, g); };
/* স্তম্ভাকার আবরণী: base = তলের বিন্দু (ক্রমানুসারে), h = কোষের উচ্চতা, অভিলম্ব বাঁ দিকে (out = 1) বা ডানে (-1)
   o = { cw (কোষের প্রস্থ), gob (প্রতি কয়টিতে একটি গবলেট), bb (ব্রাশ বর্ডার), k (সাইটোপ্লাজম), seed } */
B.ellD = (cx, cy, rx, ry, deg = 0) => { const r = deg * PI / 180, dx = rx * Math.cos(r), dy = rx * Math.sin(r); return `M${f1(cx + dx)} ${f1(cy + dy)}A${f1(rx)} ${f1(ry)} ${f1(deg)} 1 0 ${f1(cx - dx)} ${f1(cy - dy)}A${f1(rx)} ${f1(ry)} ${f1(deg)} 1 0 ${f1(cx + dx)} ${f1(cy + dy)}Z`; };
/* কোষগুলো কয়েকটি পথে একত্র করে আঁকা হয় (শত শত আলাদা উপাদানের বদলে) — অ্যানিমেশনের সময় পুনরায় আঁকা সস্তা হয় */
B.colEpi = (g, base, h, o = {}) => { const cw = o.cw || 7, out = o.out || 1, S = B.resample(B.dense(base, 6), cw), tc = TS(o.k || 'cyt'), tm = TS('muco'), tn = TS('nuc');
  let dC = '', dG = '', dM = '', dN = '', dTop = '';
  const q = (a, b, c, d) => `M${f1(a[0])} ${f1(a[1])}L${f1(b[0])} ${f1(b[1])}L${f1(c[0])} ${f1(c[1])}L${f1(d[0])} ${f1(d[1])}Z`;
  for (let i = 0; i < S.length - 1; i++) {
    const [x0, y0, nx0, ny0] = S[i], [x1, y1, nx1, ny1] = S[i + 1], hh = h * (.92 + B.rnd((o.seed || 1) * 7 + i) * .16);
    const a = [x0, y0], b = [x1, y1], c = [x1 + nx1 * out * hh, y1 + ny1 * out * hh], dd = [x0 + nx0 * out * hh, y0 + ny0 * out * hh];
    const gob = o.gob && i % o.gob === Math.floor(o.gob / 2), mx = (x0 + x1) / 2, my = (y0 + y1) / 2, nx = (nx0 + nx1) / 2 * out, ny = (ny0 + ny1) / 2 * out, ang = Math.atan2(ny, nx) * 180 / PI;
    if (gob) { dG += q(a, b, c, dd); dM += B.ellD(mx + nx * hh * .62, my + ny * hh * .62, hh * .3, cw * .42, ang); dN += B.ellD(mx + nx * hh * .16, my + ny * hh * .16, cw * .18, cw * .3, ang); }
    else { dC += q(a, b, c, dd); dN += B.ellD(mx + nx * hh * .28, my + ny * hh * .28, Math.min(hh * .2, cw * .5), cw * .26, ang); }
  }
  E('path', { d: dC, fill: tc.c, stroke: tc.dk, 'stroke-width': .45 }, g);
  if (dG) { E('path', { d: dG, fill: tm.lt, stroke: tc.dk, 'stroke-width': .45 }, g); E('path', { d: dM, fill: tm.c, stroke: tm.dk, 'stroke-width': .4 }, g); }
  E('path', { d: dN, fill: tn.c, stroke: tn.dk, 'stroke-width': .4 }, g);
  if (o.bb) { let d = ''; S.forEach(([x, y, nx, ny]) => { const px = x + nx * out * h, py = y + ny * out * h, ox = nx * out, oy = ny * out; for (let j = 0; j < 3; j++) { const qx = px + (j - 1) * cw * .3 * -oy, qy = py + (j - 1) * cw * .3 * ox; d += `M${f1(qx)} ${f1(qy)}l${f1(ox * 2.6)} ${f1(oy * 2.6)}`; } }); E('path', { d, stroke: tc.dk, 'stroke-width': .5, opacity: .8 }, g); }
  return S;
};
/* বক্ররেখাকে অভিলম্ব বরাবর d দূরত্বে সরানো (বাম দিকে ধনাত্মক) */
B.offset = (pts, d, per = 6) => { const D = B.dense(pts, per), n = D.length;
  return D.map((p, i) => { const a = D[Math.max(0, i - 1)], b = D[Math.min(n - 1, i + 1)], l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; return [p[0] - (b[1] - a[1]) / l * d, p[1] + (b[0] - a[0]) / l * d]; }); };
/* লোহিত কণিকা (কৈশিকনালিতে) */
B.rbc = (g, x, y, r = 2.4, op = 1) => { const t = TS('art'); E('ellipse', { cx: f1(x), cy: f1(y), rx: r, ry: r * .8, fill: t.c, stroke: t.dk, 'stroke-width': .4, opacity: op }, g); E('ellipse', { cx: f1(x), cy: f1(y), rx: r * .45, ry: r * .3, fill: t.dk, opacity: .35 * op }, g); };
/* পেশিস্তর (প্রস্থচ্ছেদে বৃত্তাকার পেশির তন্তু = রেখা; লম্ব পেশি = বিন্দু) */
B.musLayer = (g, d, key, kind, o = {}) => { const t = TS('mus'); B.organ(g, d, 'mus', { flat: o.flat, lin: o.lin, sw: .8 });
  const cp = B.clip(g, key, d), gg = E('g', { 'clip-path': cp }, g);
  if (kind === 'circ') E('path', { d, fill: B.pat(g, 'line', FK.alpha(t.dk, .45), { s: o.s || 3.2, a: o.a || 0, w: .55 }), stroke: 'none' }, gg);
  else E('path', { d, fill: B.pat(g, 'dot', FK.alpha(t.dk, .55), { s: o.s || 4, w: .7 }), stroke: 'none' }, gg);
  return gg; };

/* ─── অণু ও এনজাইম (প্রক্রিয়ার চিত্রে) ─── */
/* গ্লুকোজ একক ষড়ভুজ (শ্বেতসারের শিকল) */
B.hexU = (g, x, y, r, col, o = {}) => { let d = ''; for (let i = 0; i < 6; i++) { const a = PI / 6 + i * PI / 3; d += (i ? 'L' : 'M') + f1(x + r * Math.cos(a)) + ' ' + f1(y + r * Math.sin(a)); } return E('path', { d: d + 'Z', fill: o.fill || FK.alpha(col, .25), stroke: col, 'stroke-width': o.sw || 1.1, opacity: o.op != null ? o.op : 1 }, g); };
/* অ্যামাইনো অ্যাসিড পুঁতি */
B.bead = (g, x, y, r, col, o = {}) => E('circle', { cx: f1(x), cy: f1(y), r, fill: o.fill || FK.alpha(col, .3), stroke: col, 'stroke-width': o.sw || 1.1, opacity: o.op != null ? o.op : 1 }, g);
/* এনজাইম (প্যাকম্যান আকৃতির খাঁজসহ) — a = মুখের দিক (ডিগ্রি) */
B.enz = (g, x, y, r, col, a = 0, open = .5, s) => { const C = FK.P(), h = open * .9, a0 = (a * PI / 180) + h, a1 = (a * PI / 180) - h + 2 * PI;
  E('path', { d: `M${f1(x)} ${f1(y)}L${f1(x + r * Math.cos(a0))} ${f1(y + r * Math.sin(a0))}A${r} ${r} 0 1 1 ${f1(x + r * Math.cos(a1))} ${f1(y + r * Math.sin(a1))}Z`, fill: FK.alpha(col, .85), stroke: C.fg, 'stroke-width': .8 }, g);
  if (s) B.tx(g, x - r * .25 * Math.cos(a * PI / 180), y + 3.5 - r * .25 * Math.sin(a * PI / 180), s, { fs: 8, a: 'middle', w: 650, c: '#fff', halo: FK.alpha('#000', .25), hw: 1.6 }); };
/* ঝিল্লি (ফসফোলিপিড দ্বিস্তর) — উল্লম্ব, x বরাবর */
B.vmem = (g, x, y0, y1, o = {}) => { const t = TS(o.k || 'nrv'), sp = o.sp || 7; let d = '';
  for (let y = y0 + sp / 2; y < y1; y += sp) { if ((o.gaps || []).some(([a, b]) => y > a && y < b)) continue; d += `M${x - 6} ${f1(y)}h3.4M${x + 2.6} ${f1(y)}h3.4`; E('circle', { cx: x - 7.5, cy: f1(y), r: 2.3, fill: t.c, stroke: t.dk, 'stroke-width': .4 }, g); E('circle', { cx: x + 7.5, cy: f1(y), r: 2.3, fill: t.c, stroke: t.dk, 'stroke-width': .4 }, g); }
  E('path', { d, stroke: t.dk, 'stroke-width': .7, opacity: .6 }, g); };
/* বাহক প্রোটিন (ঝিল্লির ভেতরে) — উল্লম্ব ঝিল্লিতে */
B.carrier = (g, x, y, col, s, o = {}) => { const C = FK.P(), w = o.w || 15, h = o.h || 26, op = o.open || 0;
  E('path', { d: `M${x - w / 2} ${y - h / 2}q${-3} ${h / 2} 0 ${h}h${w * .42 - op * 2}v${-h}Z`, fill: FK.alpha(col, .75), stroke: C.fg, 'stroke-width': .7 }, g);
  E('path', { d: `M${x + w / 2} ${y - h / 2}q3 ${h / 2} 0 ${h}h${-(w * .42 - op * 2)}v${-h}Z`, fill: FK.alpha(col, .75), stroke: C.fg, 'stroke-width': .7 }, g);
  if (s) B.tx(g, x, y - h / 2 - 4, s, { fs: 7.8, a: 'middle', w: 600, c: C.fg }); };
})();
