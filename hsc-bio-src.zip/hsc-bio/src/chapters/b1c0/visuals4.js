/* ═══════════════════════════════════════════════════════════════════
   visuals4 — লিনিয়াসের যৌন পদ্ধতি:
   linnaeusClasses (পুংকেশরের সংখ্যা, দৈর্ঘ্য ও যুক্ততা অনুযায়ী শ্রেণি — নমুনা ফুলের পুংস্তবক),
   linnaeusWorks (লিনিয়াসের জীবন ও প্রধান গ্রন্থ — সময়রেখা)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, leafD = B.leafD;
const lerp = (a, b, t) => a + (b - a) * t;

/* ─── পুংকেশর ও গর্ভকেশরের পার্শ্বচিত্র (ফুলের মাঝখানের অংশ) ─── */
const BASE = 196, CX = 180;
const anther = (g, x, y, s = 1, col = '#e8b830') => { E('path', { d: B.ellD(x - 2.2 * s, y, 2.4 * s, 5.2 * s), fill: col, stroke: '#8a6a10', 'stroke-width': .5 }, g); E('path', { d: B.ellD(x + 2.2 * s, y, 2.4 * s, 5.2 * s), fill: col, stroke: '#8a6a10', 'stroke-width': .5 }, g); };
const fil = (g, x0, x1, y1, w = 1.4) => E('path', { d: `M${f1(x0)} ${BASE}Q${f1(x0)} ${f1((BASE + y1) / 2)} ${f1(x1)} ${f1(y1 + 5)}`, stroke: '#d8c890', 'stroke-width': w, fill: 'none' }, g);
const pistil = (g, h = 112, styles = 1, col = '#8ab048') => { E('path', { d: `M${CX - 11} ${BASE}C${CX - 13} ${BASE - 16} ${CX - 8} ${BASE - 26} ${CX} ${BASE - 28}C${CX + 8} ${BASE - 26} ${CX + 13} ${BASE - 16} ${CX + 11} ${BASE}Z`, fill: B.vol(g, 'leaf'), stroke: '#3a6a22', 'stroke-width': .7 }, g);
  for (let i = 0; i < styles; i++) { const dx = styles === 1 ? 0 : (i - (styles - 1) / 2) * 8; E('path', { d: `M${CX + dx * .3} ${BASE - 28}Q${CX + dx * .6} ${BASE - h * .7} ${CX + dx} ${BASE - h}`, stroke: col, 'stroke-width': 1.6, fill: 'none' }, g);
    E('circle', { cx: f1(CX + dx), cy: BASE - h, r: 3.4, fill: '#b8d060', stroke: '#5a7a22', 'stroke-width': .6 }, g); } };
const petals = (g, col, n = 5) => { for (let i = 0; i < n; i++) { const a = -PI / 2 + (i - (n - 1) / 2) * (PI * .8 / (n - 1)); E('path', { d: leafD(CX, BASE, a, 120, 34), fill: FK.alpha(col, .22), stroke: FK.alpha(col, .5), 'stroke-width': .8 }, g); } };
const recept = g => { E('path', { d: `M${CX - 40} ${BASE}Q${CX} ${BASE + 8} ${CX + 40} ${BASE}Q${CX} ${BASE + 22} ${CX - 40} ${BASE}Z`, fill: '#9ab860', stroke: '#4a6a22', 'stroke-width': .7 }, g); E('path', { d: `M${CX} ${BASE + 14}V${BASE + 40}`, stroke: '#6a9a3a', 'stroke-width': 3 }, g); };

const LC = {
  mon: ['Monandria', 'শ্রেণি 1 — Monandria (একটি পুংকেশর) · আদা', 'একটিমাত্র উর্বর পুংকেশর। লিনিয়াস আদা ও আদা-জাতীয় (Zingiber) উদ্ভিদ এ শ্রেণিতে রাখেন।'],
  hex: ['Hexandria', 'শ্রেণি 6 — Hexandria (ছয়টি সমান পুংকেশর) · ধান', 'ছয়টি পৃথক, প্রায় সমান দৈর্ঘ্যের পুংকেশর। ধানে (Oryza) ছয়টি পুংকেশর ও দুটি গর্ভদণ্ড — তাই Hexandria শ্রেণি, Digynia বর্গ।'],
  tet: ['টেট্রাডাইনামিয়া', 'শ্রেণি 15 — Tetradynamia (চারটি লম্বা, দুটি খাটো) · সরিষা', 'ছয়টি পুংকেশর — ভেতরের চারটি লম্বা, বাইরের দুটি খাটো (চতুর্দীর্ঘ পুংকেশর)। সরিষা ও Brassicaceae গোত্রের বৈশিষ্ট্য।'],
  mad: ['মনাডেলফিয়া', 'শ্রেণি 16 — Monadelphia (পুংদণ্ড এক গুচ্ছে) · জবা', 'সব পুংদণ্ড জুড়ে একটি নল তৈরি করে, যার ভেতর দিয়ে গর্ভদণ্ড যায় (একগুচ্ছ পুংকেশর)। জবা ও Malvaceae গোত্র।'],
  dad: ['ডায়াডেলফিয়া', 'শ্রেণি 17 — Diadelphia (পুংদণ্ড দুই গুচ্ছে) · মটর', '10টি পুংকেশরের 9টির দণ্ড জুড়ে একটি গুচ্ছ, 1টি আলাদা (9 + 1, দ্বিগুচ্ছ)। মটর ও শিম জাতীয় উদ্ভিদ।'],
  syn: ['সিনজেনেসিয়া', 'শ্রেণি 19 — Syngenesia (পরাগধানী জুড়ে নল) · সূর্যমুখী', 'পুংদণ্ড আলাদা কিন্তু পরাগধানীগুলো পরস্পর জুড়ে গর্ভদণ্ডের চারপাশে নল তৈরি করে (যুক্তপরাগী)। সূর্যমুখী ও Compositae (Asteraceae)।'],
  cry: ['ক্রিপ্টোগ্যামিয়া', 'শ্রেণি 24 — Cryptogamia (প্রজনন অঙ্গ "লুকানো") · ফার্ন', 'দৃশ্যমান ফুল নেই — শৈবাল, ছত্রাক, মস ও ফার্ন। লিনিয়াসের সময় এদের প্রজনন অজানা ছিল, তাই "লুকানো বিবাহ" (crypto = গোপন, gamia = বিবাহ)।']
};
V.linnaeusClasses = Object.assign({}, B.seg({
  id: 'lnc', t: 'লিনিয়াসের যৌন পদ্ধতি: পুংকেশর দেখে শ্রেণি', H: 290, def: 'tet', types: LC,
  cap: 'লিনিয়াস (Species Plantarum, 1753) সপুষ্পক উদ্ভিদকে পুংকেশরের সংখ্যা, আপেক্ষিক দৈর্ঘ্য ও যুক্ততা দেখে 23টি শ্রেণিতে এবং অপুষ্পক সবাইকে 24তম শ্রেণি Cryptogamia তে রাখেন; গর্ভদণ্ডের সংখ্যা দেখে বর্গ (Monogynia, Digynia …)। চিত্রে ফুলের পাপড়ি হালকা করে, মাঝের পুংস্তবক ও গর্ভকেশর বড় করে দেখানো হয়েছে।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 240, fill: FK.alpha('#f6f2ea', .7) }, g);
    if (ty === 'cry') { const F = B.TS('frond'); E('path', { d: leafD(70, 140, -.18, 220, 46), fill: B.vol(g, 'frond'), stroke: F.dk, 'stroke-width': .8 }, g); E('path', { d: 'M70 140L286 102', stroke: F.dk, 'stroke-width': 1 }, g);
      for (let k = 0; k < 9; k++) { const u = .15 + k * .09, x = lerp(70, 286, u), y = lerp(140, 102, u); [1, -1].forEach(sd => { const sx = x + sd * 3, sy = y + sd * 16 * (1 - u * .6); E('circle', { cx: f1(sx), cy: f1(sy), r: 4.4, fill: '#9a5a20', stroke: '#5a3010', 'stroke-width': .5 }, g); E('path', { d: B.ellD(sx - .6, sy - .6, 4.6, 4.6), fill: 'none', stroke: FK.alpha('#f0e0b0', .8), 'stroke-width': .5 }, g); }); }
      B.labL(g, 140, 112, 140, 40, 'সোরাস (রেণুধর গুচ্ছ) — পাতার নিচে', C, 'middle'); B.tx(g, 180, 200, 'ফুল নেই — ফুলের অঙ্গ দিয়ে শ্রেণি করা যায় না', { fs: 10, a: 'middle', c: C.mu }); }
    else { petals(g, ty === 'tet' ? '#e8c820' : ty === 'mad' ? '#d8303a' : ty === 'dad' ? '#a878c8' : ty === 'syn' ? '#e8a820' : '#c8a878', ty === 'tet' ? 4 : 5); recept(g); }
    if (ty === 'mon') { pistil(g, 112); fil(g, CX + 18, CX + 20, 96, 2.2); anther(g, CX + 20, 96, 1.3); B.labL(g, CX + 24, 96, 300, 70, 'একটি পুংকেশর', C, 'start'); }
    if (ty === 'hex') { pistil(g, 104, 2); [-34, -22, -12, 12, 22, 34].forEach(d => { fil(g, CX + d * .5, CX + d, 112); anther(g, CX + d, 112); }); B.labL(g, CX + 34, 112, 300, 80, '6টি সমান পুংকেশর', C, 'start'); B.labL(g, CX - 4, BASE - 104, 14, 50, 'দুটি গর্ভমুণ্ড (Digynia)', C, 'start'); }
    if (ty === 'tet') { pistil(g, 118); [-24, -10, 10, 24].forEach(d => { fil(g, CX + d * .4, CX + d, 92); anther(g, CX + d, 92); }); [-42, 42].forEach(d => { fil(g, CX + d * .5, CX + d, 140); anther(g, CX + d, 140); });
      B.labL(g, CX + 24, 92, 300, 60, '4টি লম্বা', C, 'start'); B.labL(g, CX + 42, 140, 300, 140, '2টি খাটো', C, 'start'); }
    if (ty === 'mad') { /* পুংদণ্ডের নল (staminal column), ওপরে বহু পরাগধানী, ভেতর দিয়ে গর্ভদণ্ড */
      E('path', { d: `M${CX - 7} ${BASE}L${CX - 4} ${BASE - 120}H${CX + 4}L${CX + 7} ${BASE}Z`, fill: '#e88890', stroke: '#9a3040', 'stroke-width': .7 }, g);
      for (let k = 0; k < 16; k++) { const y = BASE - 60 - k * 4, sd = k % 2 ? 1 : -1; E('path', { d: `M${CX + sd * 4.4} ${y}l${sd * 6} -3`, stroke: '#e8a0a8', 'stroke-width': .8 }, g); anther(g, CX + sd * 11, y - 3, .55, '#f2d040'); }
      E('path', { d: `M${CX} ${BASE - 120}V${BASE - 140}`, stroke: '#c03040', 'stroke-width': 1.4 }, g); for (let k = 0; k < 5; k++) E('circle', { cx: CX - 8 + k * 4, cy: BASE - 142 - Math.abs(k - 2) * 1.5, r: 2.2, fill: '#c03040' }, g);
      B.labL(g, CX + 6, BASE - 40, 352, 176, 'পুংদণ্ডের নল (এক গুচ্ছ)', C, 'end'); B.labL(g, CX + 12, BASE - 100, 290, 70, 'অনেক পরাগধানী', C, 'start'); B.labL(g, CX - 4, BASE - 142, 70, 40, 'গর্ভমুণ্ড', C, 'end'); }
    if (ty === 'dad') { pistil(g, 104); E('path', { d: `M${CX - 16} ${BASE}C${CX - 18} ${BASE - 40} ${CX - 14} ${BASE - 70} ${CX - 8} ${BASE - 88}H${CX + 8}C${CX + 14} ${BASE - 70} ${CX + 18} ${BASE - 40} ${CX + 16} ${BASE}Z`, fill: FK.alpha('#e8e0b0', .85), stroke: '#a89a50', 'stroke-width': .8 }, g);
      for (let k = 0; k < 9; k++) { const x = CX - 14 + k * 3.5; E('path', { d: `M${f1(x)} ${BASE - 86}l${f1((k - 4) * .6)} -10`, stroke: '#d8c890', 'stroke-width': 1 }, g); anther(g, x + (k - 4) * .6, BASE - 100, .6); }
      fil(g, CX + 26, CX + 30, 92); anther(g, CX + 30, 92, .8); B.labL(g, CX - 14, BASE - 50, 60, 150, '9টি জোড়া পুংদণ্ড', C, 'end'); B.labL(g, CX + 30, 92, 300, 70, '1টি মুক্ত পুংকেশর', C, 'start'); }
    if (ty === 'syn') { pistil(g, 124, 1, '#c8a040'); [-12, -6, 0, 6, 12].forEach(d => fil(g, CX + d * .6, CX + d * .5, 118));
      E('path', { d: `M${CX - 8} ${BASE - 78}H${CX + 8}V${BASE - 112}H${CX - 8}Z`, fill: '#e8b830', stroke: '#8a6a10', 'stroke-width': .7 }, g); for (let k = -2; k <= 2; k++) E('path', { d: `M${CX + k * 3.2} ${BASE - 78}V${BASE - 112}`, stroke: '#8a6a10', 'stroke-width': .4 }, g);
      E('path', { d: `M${CX - 3} ${BASE - 124}l-5 -6M${CX + 3} ${BASE - 124}l5 -6`, stroke: '#c8a040', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, g);
      B.labL(g, CX + 8, BASE - 96, 290, 80, 'জোড়া পরাগধানীর নল', C, 'start'); B.labL(g, CX + 4, BASE - 50, 290, 150, 'পৃথক পুংদণ্ড (5টি)', C, 'start'); B.labL(g, CX - 6, BASE - 128, 70, 46, 'দ্বিখণ্ডিত গর্ভমুণ্ড', C, 'end'); }
    if (ty !== 'cry' && ty !== 'mad' && ty !== 'syn') B.labL(g, CX - 9, BASE - 12, 56, 186, 'গর্ভাশয়', C, 'end');
    B.tx(g, 180, 262, LC[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 282, ty === 'cry' ? 'অপুষ্পক উদ্ভিদ' : 'শ্রেণি = পুংকেশর · বর্গ = গর্ভদণ্ডের সংখ্যা', { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ লিনিয়াসের সময়রেখা ═════════ */
const LW = [[1707, 'জন্ম', ['রসহুল্ট, সুইডেন (23 মে)'], 36, 'start'], [1735, 'Systema Naturae', ['প্রকৃতির শ্রেণিবিন্যাস', 'দুই জীবরাজ্য'], 172, 'end'], [1737, 'Genera Plantarum', ['উদ্ভিদের গণের বর্ণনা'], 88, 'end'], [1751, 'Philosophia Botanica', ['উদ্ভিদবিদ্যার নিয়মকানুন'], 214, 'middle'], [1753, 'Species Plantarum', ['দ্বিপদ নামের সূচনা', 'নামকরণের শুরু: 1 মে 1753'], 36, 'start'], [1778, 'মৃত্যু', ['উপসালা, সুইডেন'], 172, 'end']];
V.linnaeusWorks = Object.assign({ t: 'ক্যারোলাস লিনিয়াস (1707–1778): জীবন ও গ্রন্থ', k: ['2d', 'int'], cap: 'সুইডিশ উদ্ভিদবিদ ক্যারোলাস লিনিয়াসকে "শ্রেণিবিন্যাসবিদ্যার জনক" বলা হয়। তাঁর Species Plantarum (1753) প্রকাশের তারিখ 1 মে 1753 উদ্ভিদের বৈজ্ঞানিক নামের অগ্রাধিকার গণনার শুরু — এর আগের নাম নামকরণ নিয়মে গ্রহণযোগ্য নয়।' }, B.seg({
  id: 'lnw', t: 'লিনিয়াসের সময়রেখা', H: 270, def: 'tl', types: { tl: ['সময়রেখা', 'লিনিয়াসের প্রধান গ্রন্থ', 'বিন্দুতে চাপ নয় — বছর অনুযায়ী সাজানো সময়রেখা।'] },
  art(g, C) { const X = y => 30 + (y - 1700) / 80 * 300, Y = 132;
    E('path', { d: `M24 ${Y}H340`, stroke: FK.alpha(C.fg, .5), 'stroke-width': 2 }, g);
    for (let y = 1700; y <= 1780; y += 10) { E('path', { d: `M${f1(X(y))} ${Y - 4}V${Y + 4}`, stroke: FK.alpha(C.fg, .5) }, g); B.tx(g, X(y), Y + 16, String(y), { fs: 8.6, a: 'middle', c: C.mu }); }
    LW.forEach(([yr, tt, ds, yy, an]) => { const x = X(yr), key = yr === 1753, up = yy < Y;
      E('path', { d: `M${f1(x)} ${Y}V${up ? yy + 8 + ds.length * 13 : yy - 14}`, stroke: key ? '#a8302a' : FK.alpha(C.fg, .4), 'stroke-width': key ? 1.6 : 1 }, g);
      E('circle', { cx: f1(x), cy: Y, r: key ? 6 : 4, fill: key ? '#a8302a' : '#3a6a8a', stroke: C.sf, 'stroke-width': 1.5 }, g);
      const tx = an === 'start' ? x - 4 : an === 'end' ? x + 4 : x;
      B.tx(g, tx, yy, `${yr} · ${tt}`, { fs: 10, a: an, w: 700, c: key ? '#a8302a' : C.fg });
      ds.forEach((d, k) => B.tx(g, tx, yy + 14 + k * 13, d, { fs: 8.8, a: an, c: C.mu })); });
    B.tx(g, 180, 258, 'অবদান: দ্বিপদ নামকরণ, শ্রেণিবিন্যাসের স্তর (জগৎ–শ্রেণি–বর্গ–গণ–প্রজাতি), যৌন পদ্ধতি', { fs: 9.6, a: 'middle', c: C.mu }); }
}));
})();
