/* ═══════════════════════════════════════════════════════════════════
   visuals5 — বেনথাম ও হুকারের প্রাকৃতিক শ্রেণিবিন্যাস:
   bhChart (Genera Plantarum এর ছক — শ্রেণি, উপশ্রেণি, সিরিজ ও গোত্রের সংখ্যা),
   corollaTypes (পৃথকদলী / যুক্তদলী / একক পুষ্পপুট), ovaryPosition (থ্যালামিফ্লোরি, ডিসসিফ্লোরি, ক্যালিসিফ্লোরি),
   dicotMonocot (দ্বিবীজপত্রী বনাম একবীজপত্রী — পাতা, বীজ, ফুল, মূল, কাণ্ড)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, leafD = B.leafD, P2 = B.P2;
const lerp = (a, b, t) => a + (b - a) * t;

/* ═════════ বেনথাম ও হুকারের ছক ═════════ */
const BH = {
  all: ['পূর্ণ ছক', 'বীজী উদ্ভিদ (Phanerogams) — 3 শ্রেণি, 202 গোত্র', 'Genera Plantarum (1862–1883, তিন খণ্ড) এ শুধু বীজী উদ্ভিদের 202টি গোত্র (তাঁদের ভাষায় "natural order"), 7,569টি গণ ও প্রায় 97,205টি প্রজাতি বর্ণিত। তিন শ্রেণি: দ্বিবীজপত্রী (165 গোত্র), নগ্নবীজী (3 গোত্র) ও একবীজপত্রী (34 গোত্র)। নগ্নবীজীকে দ্বিবীজপত্রী ও একবীজপত্রীর মাঝে রাখা এ পদ্ধতির প্রধান ত্রুটি।'],
  dic: ['দ্বিবীজপত্রী', 'শ্রেণি (১): Dicotyledons — 3 উপশ্রেণি, 165 গোত্র', 'দলমণ্ডলের গঠন দেখে তিন উপশ্রেণি: Polypetalae (পাপড়ি পৃথক, 84 গোত্র), Gamopetalae (পাপড়ি যুক্ত, 45 গোত্র) ও Monochlamydeae (পুষ্পপুট একস্তরী বা নেই, 36 গোত্র)। গর্ভাশয়ের অবস্থান ও চাকতি দেখে সিরিজ।'],
  mon: ['একবীজপত্রী', 'শ্রেণি (৩): Monocotyledons — 7 সিরিজ, 34 গোত্র', 'সাতটি সিরিজ: Microspermae (অর্কিড), Epigynae (কলা, আদা), Coronarieae (লিলি), Calycinae (তাল-নারকেল), Nudiflorae (কচু), Apocarpae (জলজ উদ্ভিদ) ও Glumaceae (ধান-ঘাস, মুথা) — শেষে রাখা হয়েছে।']
};
V.bhChart = Object.assign({}, B.seg({
  id: 'bhc', t: 'বেনথাম ও হুকারের শ্রেণিবিন্যাসের ছক', H: 320, def: 'all', types: BH,
  cap: 'জর্জ বেনথাম ও জোসেফ ডাল্টন হুকার কিউ উদ্যানের (লন্ডন) হার্বেরিয়ামের বাস্তব নমুনা পরীক্ষা করে এ প্রাকৃতিক পদ্ধতি তৈরি করেন। বন্ধনীর সংখ্যা = গোত্রের সংখ্যা। এখনো অনেক হার্বেরিয়ামে নমুনা সাজাতে এ পদ্ধতি ব্যবহৃত হয়।',
  art(g, C, ty) {
    const N = (x, y, w, t, sub, c, o = {}) => { E('rect', { x: x - w / 2, y: y - 13, width: w, height: sub ? 30 : 26, rx: 8, fill: FK.alpha(c, o.on === false ? .04 : .13), stroke: FK.alpha(c, o.on === false ? .35 : 1), 'stroke-width': o.on ? 1.8 : 1 }, g);
      B.tx(g, x, y + 2, t, { fs: o.fs || 9.6, a: 'middle', w: 700, c: o.on === false ? FK.alpha(C.fg, .45) : c }); if (sub) B.tx(g, x, y + 13, sub, { fs: 8, a: 'middle', c: C.mu }); };
    const L = (x0, y0, x1, y1) => E('path', { d: `M${x0} ${y0}V${(y0 + y1) / 2}H${x1}V${y1}`, stroke: FK.alpha(C.fg, .4), 'stroke-width': 1, fill: 'none' }, g);
    if (ty === 'all') {
      N(180, 22, 200, 'বীজী উদ্ভিদ (Phanerogams) — 202', '', '#3a4a2a', { fs: 10 });
      L(180, 35, 66, 66); L(180, 35, 180, 66); L(180, 35, 296, 66);
      N(66, 78, 112, 'দ্বিবীজপত্রী (165)', 'Dicotyledons', '#9a4a2a'); N(180, 78, 96, 'নগ্নবীজী (3)', 'Gymnospermae', '#8a6a2a'); N(296, 78, 112, 'একবীজপত্রী (34)', 'Monocotyledons', '#2a6a9a');
      L(66, 93, 36, 124); L(66, 93, 104, 124); L(66, 93, 66, 196);
      N(36, 136, 66, 'পৃথকদলী (84)', 'Polypetalae', '#a85a20'); N(104, 136, 66, 'যুক্তদলী (45)', 'Gamopetalae', '#a8402a'); N(66, 208, 118, 'একক পুষ্পপুট (36)', 'Monochlamydeae', '#7a5a4a');
      E('path', { d: 'M36 151V172M104 151V172', stroke: FK.alpha(C.fg, .3) }, g); B.tx(g, 36, 182, '3 সিরিজ', { fs: 8.4, a: 'middle', c: C.mu }); B.tx(g, 104, 182, '3 সিরিজ', { fs: 8.4, a: 'middle', c: C.mu }); B.tx(g, 66, 236, '8 সিরিজ', { fs: 8.4, a: 'middle', c: C.mu });
      E('path', { d: 'M180 93V124', stroke: FK.alpha(C.fg, .3) }, g); B.tx(g, 190, 136, 'Gnetaceae, Coniferae,', { fs: 8.4, a: 'middle', c: C.mu }); B.tx(g, 190, 148, 'Cycadaceae', { fs: 8.4, a: 'middle', c: C.mu });
      E('path', { d: 'M296 93V124', stroke: FK.alpha(C.fg, .3) }, g); B.tx(g, 296, 136, '7 সিরিজ', { fs: 8.4, a: 'middle', c: C.mu }); B.tx(g, 296, 148, 'শেষে Glumaceae (ঘাস)', { fs: 8.4, a: 'middle', c: C.mu });
      E('path', { d: 'M150 176C170 196 196 196 214 176', stroke: '#c0392b', 'stroke-width': 1.4, fill: 'none', 'marker-end': B.mk(g, '#c0392b', 5) }, g); B.tx(g, 182, 212, 'ত্রুটি: নগ্নবীজী মাঝে', { fs: 9, a: 'middle', c: '#a8302a', w: 700 });
      B.tx(g, 180, 262, '7,569 গণ · প্রায় 97,205 প্রজাতি · 1862–1883', { fs: 10, a: 'middle', c: C.fg }); }
    if (ty === 'dic') {
      N(180, 22, 180, 'দ্বিবীজপত্রী (165 গোত্র)', '', '#9a4a2a', { fs: 10 }); L(180, 35, 62, 58); L(180, 35, 180, 58); L(180, 35, 300, 58);
      N(62, 70, 110, 'Polypetalae (84)', 'পাপড়ি পৃথক', '#a85a20'); N(180, 70, 110, 'Gamopetalae (45)', 'পাপড়ি যুক্ত', '#a8402a'); N(300, 70, 112, 'Monochlamydeae (36)', 'পুষ্পপুট একস্তরী', '#7a5a4a');
      const S = (x, y, t, n, ex, c) => { E('rect', { x: x - 54, y: y - 12, width: 108, height: 40, rx: 7, fill: C.sf, stroke: FK.alpha(c, .6) }, g); B.tx(g, x, y + 2, `${t} (${n})`, { fs: 9, a: 'middle', w: 700, c }); B.tx(g, x, y + 16, ex, { fs: 8.2, a: 'middle', c: C.mu }); };
      [['Thalamiflorae', 34, 'জবা, সরিষা'], ['Disciflorae', 23, 'লেবু, কুল'], ['Calyciflorae', 27, 'মটর, লাউ']].forEach(([t, n, ex], i) => { L(62, 85, 62, 104 + i * 48); S(62, 118 + i * 48, t, n, ex, '#a85a20'); });
      [['Inferae', 9, 'সূর্যমুখী'], ['Heteromerae', 12, 'সফেদা'], ['Bicarpellatae', 24, 'ধুতুরা, তুলসী']].forEach(([t, n, ex], i) => { L(180, 85, 180, 104 + i * 48); S(180, 118 + i * 48, t, n, ex, '#a8402a'); });
      E('path', { d: 'M300 85V106', stroke: FK.alpha(C.fg, .4) }, g); E('rect', { x: 246, y: 106, width: 108, height: 120, rx: 7, fill: C.sf, stroke: FK.alpha('#7a5a4a', .6) }, g);
      ['Curvembryeae', 'Multiovulatae Aquaticae', 'Multiovulatae Terrestres', 'Microembryeae', 'Daphnales', 'Achlamydosporeae', 'Unisexuales', 'Ordines Anomali'].forEach((s, i) => B.tx(g, 300, 120 + i * 13.4, s, { fs: 7.8, a: 'middle', c: '#5a4030' }));
      B.tx(g, 300, 240, 'যেমন লাল শাক, ভেরেন্ডা', { fs: 8.2, a: 'middle', c: C.mu });
      B.tx(g, 180, 268, 'সিরিজ: ফুলের থ্যালামাস, চাকতি ও গর্ভাশয়ের অবস্থান দেখে', { fs: 9.6, a: 'middle', c: C.fg }); }
    if (ty === 'mon') {
      N(180, 22, 200, 'একবীজপত্রী (34 গোত্র) — 7 সিরিজ', '', '#2a6a9a', { fs: 10 });
      const MS = [['Microspermae', 'অর্কিড', 'গর্ভাশয় নিম্ন, বীজ অতি ক্ষুদ্র'], ['Epigynae', 'কলা, আদা', 'গর্ভাশয় নিম্ন, পুষ্পপুট পাপড়ির মতো'], ['Coronarieae', 'রসুন, লিলি', 'গর্ভাশয় ঊর্ধ্ব, পুষ্পপুট রঙিন'], ['Calycinae', 'তাল, নারকেল', 'পুষ্পপুট বৃতির মতো শক্ত'], ['Nudiflorae', 'কচু, কেয়া', 'পুষ্পপুট নেই বা ক্ষুদ্র'], ['Apocarpae', 'Sagittaria, Potamogeton', 'গর্ভপত্র পৃথক (জলজ)'], ['Glumaceae', 'ধান, মুথা', 'ফুল শুষ্ক মঞ্জরিপত্রে (গ্লুম) ঢাকা']];
      MS.forEach(([t, ex, d], i) => { const y = 54 + i * 30; E('path', { d: `M24 ${i ? y - 30 : 36}V${y}H40`, stroke: FK.alpha(C.fg, .4), fill: 'none' }, g); E('rect', { x: 40, y: y - 12, width: 312, height: 24, rx: 6, fill: FK.alpha('#2a6a9a', i === 6 ? .16 : .07), stroke: FK.alpha('#2a6a9a', .5) }, g);
        B.tx(g, 48, y + 4, `${i + 1}. ${t}`, { fs: 9.4, w: 700, c: '#1e4a70' }); B.tx(g, 146, y + 4, ex, { fs: 9, c: C.fg, w: 600 }); B.tx(g, 348, y + 4, d, { fs: 8.2, a: 'end', c: C.mu }); });
      B.tx(g, 180, 268, 'অর্কিডকে প্রথমে আর ঘাসকে সবার শেষে রাখা হয়েছে', { fs: 9.6, a: 'middle', c: C.fg }); }
    B.tx(g, 180, 296, BH[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg }); }
}));

/* ═════════ দলমণ্ডল: পৃথকদলী, যুক্তদলী, একক পুষ্পপুট ═════════ */
const CR = {
  pol: ['পৃথকদলী', 'Polypetalae — সরিষার ফুল (ওপর থেকে)', 'পাপড়িগুলো আলাদা আলাদা, পরস্পর জোড়া লাগেনি। সরিষার চারটি পাপড়ি যোগচিহ্নের মতো সাজানো (ক্রুশাকার), প্রতিটির সরু নখ ও চওড়া ফলক; চারটি বৃত্যংশও পৃথক।'],
  gam: ['যুক্তদলী', 'Gamopetalae — ধুতুরার ফুল (পাশ থেকে)', 'পাপড়িগুলো জোড়া লেগে নল বা ফানেল তৈরি করে, শুধু আগায় খাঁজ বা খণ্ড থাকে। ধুতুরার লম্বা ফানেলাকার দলমণ্ডল, পাঁচটি সূচালো খণ্ড।'],
  mch: ['একক পুষ্পপুট', 'Monochlamydeae — লাল শাকের ফুল (বড় করে)', 'বৃতি ও দলমণ্ডল আলাদা নয় — একটিমাত্র স্তরের পুষ্পপুট (পেরিয়ান্থ), প্রায়ই সবুজ বা শুষ্ক; কখনো পুষ্পপুট থাকেই না। লাল শাকের (Amaranthus) ছোট ফুলে পাঁচটি শুষ্ক পুষ্পপুট খণ্ড।']
};
V.corollaTypes = Object.assign({}, B.seg({
  id: 'crt', t: 'দ্বিবীজপত্রীর তিন উপশ্রেণি: দলমণ্ডলের গঠন', H: 280, def: 'pol', types: CR,
  cap: 'বেনথাম ও হুকার দ্বিবীজপত্রীকে দলমণ্ডলের (পাপড়ির) গঠন অনুযায়ী তিন উপশ্রেণিতে ভাগ করেন। ফুলের মাপ অনুপাতে নয় — লাল শাকের ফুল আসলে মাত্র কয়েক মিলিমিটার।',
  art(g, C, ty) { E('rect', { x: 0, y: 0, width: 360, height: 232, fill: FK.alpha('#f6f4ec', .7) }, g); const cx = 180, cy = 116;
    if (ty === 'pol') { const Y = B.TS('mstd');
      for (let i = 0; i < 4; i++) { const a = i * PI / 2 + PI / 4; E('path', { d: leafD(cx + Math.cos(a) * 8, cy + Math.sin(a) * 8, a, 22, 4), fill: '#9ab860', stroke: '#4a6a22', 'stroke-width': .6 }, g); }
      for (let i = 0; i < 4; i++) { const a = i * PI / 2, c = Math.cos(a), s = Math.sin(a), q = (u, v) => [cx + u * c - v * s, cy + u * s + v * c];
        const p = [q(10, -3), q(30, -4), q(44, -20), q(70, -18), q(78, 0), q(70, 18), q(44, 20), q(30, 4), q(10, 3)]; E('path', { d: sm(p, true, .35), fill: B.vol(g, 'mstd'), stroke: Y.dk, 'stroke-width': .8 }, g);
        for (let k = -1; k <= 1; k++) E('path', { d: P2([q(32, k * 1.5), q(70, k * 10)]), stroke: FK.alpha(Y.dk, .4), 'stroke-width': .5 }, g); }
      for (let i = 0; i < 6; i++) { const a = i * PI / 3 + .3, r = i % 3 === 0 ? 9 : 14; E('circle', { cx: f1(cx + Math.cos(a) * r), cy: f1(cy + Math.sin(a) * r), r: 3, fill: '#e0b020', stroke: '#8a6a10', 'stroke-width': .4 }, g); }
      E('circle', { cx, cy, r: 4.2, fill: '#8ab048', stroke: '#3a6a22' }, g);
      B.labL(g, cx + 60, cy, 300, 40, 'পৃথক পাপড়ি (4টি)', C, 'start'); B.labL(g, cx + 26, cy - 1, 352, 200, 'পাপড়ির নখ (সরু গোড়া)', C, 'end'); B.labL(g, cx - 18, cy - 20, 40, 40, 'বৃত্যংশ (4টি, পৃথক)', C, 'start'); }
    if (ty === 'gam') { /* ফানেলাকার যুক্ত দলমণ্ডল, পাশ থেকে */
      E('path', { d: 'M60 120C70 112 84 110 100 112C100 120 100 124 100 128C84 130 70 128 60 120Z', fill: '#9ab860', stroke: '#4a6a22', 'stroke-width': .7 }, g);
      E('path', { d: 'M96 112L104 110L104 130L96 128Z', fill: '#7a9a40' }, g);
      E('path', { d: 'M100 113C150 110 200 102 250 76C262 70 268 64 276 54L300 72L312 96L300 120L300 144L312 158L276 186C268 176 262 170 250 164C200 138 150 130 100 127Z', fill: B.lin(g, 'lily', 0), stroke: '#a8a0b0', 'stroke-width': .9 }, g);
      for (let k = 0; k < 5; k++) E('path', { d: `M100 ${f1(116 + k * 2.6)}C160 ${f1(112 + k * 4)} 230 ${f1(70 + k * 26)} ${f1(288 + (k % 2) * 10)} ${f1(64 + k * 28)}`, stroke: FK.alpha('#8a7aa0', .35), 'stroke-width': .7, fill: 'none' }, g);
      E('path', { d: 'M276 54l-8 -10M312 96l12 -4M312 158l12 4M276 186l-8 10', stroke: '#a8a0b0', 'stroke-width': 1.2, 'stroke-linecap': 'round' }, g);
      B.labL(g, 190, 116, 190, 210, 'জোড়া লাগা পাপড়ির নল', C, 'middle'); B.labL(g, 304, 72, 330, 30, 'খণ্ড (5টি)', C, 'end'); B.labL(g, 76, 118, 40, 40, 'বৃতি (যুক্ত)', C, 'start'); }
    if (ty === 'mch') { /* একস্তরী পুষ্পপুট: পাঁচটি শুষ্ক খণ্ড, ওপর থেকে */
      for (let i = 0; i < 5; i++) { const a = -PI / 2 + i * 2 * PI / 5; E('path', { d: leafD(cx, cy, a, 64, 16), fill: B.lin(g, 'leaf', 90), stroke: '#5a7a2a', 'stroke-width': .8 }, g); E('path', { d: `M${cx} ${cy}L${f1(cx + Math.cos(a) * 60)} ${f1(cy + Math.sin(a) * 60)}`, stroke: '#a8302a', 'stroke-width': 1.2 }, g); }
      for (let i = 0; i < 5; i++) { const a = -PI / 2 + PI / 5 + i * 2 * PI / 5; E('path', { d: `M${cx} ${cy}L${f1(cx + Math.cos(a) * 26)} ${f1(cy + Math.sin(a) * 26)}`, stroke: '#c8c090', 'stroke-width': 1 }, g); E('path', { d: B.ellD(cx + Math.cos(a) * 28, cy + Math.sin(a) * 28, 3.6, 2.2, a * 57), fill: '#e0c040', stroke: '#8a6a10', 'stroke-width': .4 }, g); }
      E('circle', { cx, cy, r: 8, fill: '#8ab048', stroke: '#3a6a22' }, g); for (let k = 0; k < 3; k++) E('path', { d: `M${cx} ${cy}l${f1(Math.cos(k * 2.1) * 12)} ${f1(Math.sin(k * 2.1) * 12)}`, stroke: '#b05a8a', 'stroke-width': 1.4, 'stroke-linecap': 'round' }, g);
      B.labL(g, cx + 50, cy - 40, 352, 30, 'পুষ্পপুট খণ্ড (একস্তরী)', C, 'end'); B.labL(g, cx + 22, cy + 18, 300, 190, 'পুংকেশর', C, 'start'); B.labL(g, cx - 6, cy - 6, 40, 40, 'গর্ভমুণ্ড (3টি)', C, 'start');
      B.tx(g, 60, 210, 'বৃতি-দল আলাদা নেই', { fs: 9.6, a: 'middle', c: '#a8302a' }); }
    B.tx(g, 180, 252, CR[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 272, { pol: 'পাপড়ি আলাদা — যেমন সরিষা, জবা, মটর', gam: 'পাপড়ি যুক্ত — যেমন ধুতুরা, সূর্যমুখী, তুলসী', mch: 'একটি পুষ্পপুট স্তর — যেমন লাল শাক, ভেরেন্ডা' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ পৃথকদলীর তিন সিরিজ: গর্ভাশয়ের অবস্থান (লম্বচ্ছেদ) ═════════ */
const OP = {
  tha: ['থ্যালামিফ্লোরি', 'Thalamiflorae — গর্ভপাদ (থ্যালামাস) উঁচু, গর্ভাশয় ঊর্ধ্ব', 'পুষ্পাক্ষ বা থ্যালামাস উত্তল/শঙ্কু আকার; বৃতি, দল ও পুংকেশর গর্ভাশয়ের নিচ থেকে বের হয় (গর্ভপাদ-নিম্ন, hypogynous)। চাকতি নেই। উদাহরণ: জবা, সরিষা, শাপলা।'],
  dis: ['ডিসসিফ্লোরি', 'Disciflorae — গর্ভাশয়ের নিচে মধুক্ষরা চাকতি', 'গর্ভাশয় ঊর্ধ্ব, কিন্তু তার নিচে থ্যালামাস ফুলে গোল চাকতি (disc) তৈরি করে, যা প্রায়ই মধু নিঃসরণ করে। উদাহরণ: লেবু, কমলা, কুল।'],
  cal: ['ক্যালিসিফ্লোরি', 'Calyciflorae — পেয়ালার মতো থ্যালামাস, গর্ভাশয় অর্ধ-নিম্ন বা নিম্ন', 'থ্যালামাস পেয়ালা বা নলের মতো হয়ে বৃতির সাথে যুক্ত; দল ও পুংকেশর পেয়ালার কিনারা থেকে বের হয় (পেরিজাইনাস বা এপিজাইনাস)। উদাহরণ: মটর, গোলাপ, লাউ।']
};
V.ovaryPosition = Object.assign({}, B.seg({
  id: 'ovp', t: 'পৃথকদলীর সিরিজ: ফুলের লম্বচ্ছেদ', H: 280, def: 'tha', types: OP,
  cap: 'ফুলের লম্বচ্ছেদের রেখাচিত্র। সবুজ = থ্যালামাস ও বৃতি, হলুদ = চাকতি, গোলাপি = পাপড়ি, বাদামি = পুংকেশর, সবুজাভ = গর্ভকেশর (ভেতরে ডিম্বক)।',
  art(g, C, ty) { E('rect', { x: 0, y: 0, width: 360, height: 232, fill: FK.alpha('#f6f4ec', .7) }, g);
    const cx = 180, by = 196, TH = '#8ab048', TD = '#3a6a22';
    E('path', { d: `M${cx - 4} ${by + 30}V${by}H${cx + 4}V${by + 30}Z`, fill: TH, stroke: TD, 'stroke-width': .6 }, g);
    const ovary = (oy, inf) => { E('path', { d: `M${cx - 18} ${oy}C${cx - 20} ${oy - 18} ${cx - 12} ${oy - 34} ${cx} ${oy - 36}C${cx + 12} ${oy - 34} ${cx + 20} ${oy - 18} ${cx + 18} ${oy}Z`, fill: FK.alpha('#c8e0a0', inf ? .6 : 1), stroke: '#4a7a2a', 'stroke-width': .9 }, g);
      E('path', { d: `M${cx} ${oy - 2}V${oy - 32}`, stroke: '#4a7a2a', 'stroke-width': .6 }, g); [[-7, -10], [7, -10], [-7, -22], [7, -22]].forEach(([dx, dy]) => E('path', { d: B.ellD(cx + dx, oy + dy, 3.4, 4.4), fill: '#f6f0d8', stroke: '#8a7a3a', 'stroke-width': .5 }, g));
      E('path', { d: `M${cx} ${oy - 36}V${oy - 86}`, stroke: '#4a7a2a', 'stroke-width': 2 }, g); E('path', { d: B.ellD(cx, oy - 88, 6, 3), fill: '#b8d060', stroke: '#4a7a2a', 'stroke-width': .6 }, g); };
    const stamen = (x0, y0, side, h = 70) => { E('path', { d: `M${x0} ${y0}Q${x0 + side * 4} ${y0 - h * .6} ${x0 + side * 8} ${y0 - h}`, stroke: '#a88a50', 'stroke-width': 1.2, fill: 'none' }, g); E('path', { d: B.ellD(x0 + side * 8, y0 - h - 4, 2.6, 5.2), fill: '#e0b030', stroke: '#8a6a10', 'stroke-width': .4 }, g); };
    const petal = (x0, y0, side) => E('path', { d: `M${x0} ${y0}C${x0 + side * 30} ${y0 - 20} ${x0 + side * 70} ${y0 - 70} ${x0 + side * 96} ${y0 - 100}C${x0 + side * 104} ${y0 - 84} ${x0 + side * 70} ${y0 - 30} ${x0 + side * 6} ${y0 + 4}Z`, fill: FK.alpha('#f0a0b8', .7), stroke: '#b0506a', 'stroke-width': .7 }, g);
    const sepal = (x0, y0, side) => E('path', { d: `M${x0} ${y0}C${x0 + side * 20} ${y0 - 4} ${x0 + side * 40} ${y0 - 24} ${x0 + side * 50} ${y0 - 44}C${x0 + side * 30} ${y0 - 30} ${x0 + side * 14} ${y0 - 14} ${x0 + side * 2} ${y0 - 6}Z`, fill: TH, stroke: TD, 'stroke-width': .7 }, g);
    if (ty === 'tha') { E('path', { d: `M${cx - 26} ${by}C${cx - 24} ${by - 10} ${cx - 16} ${by - 22} ${cx} ${by - 24}C${cx + 16} ${by - 22} ${cx + 24} ${by - 10} ${cx + 26} ${by}Z`, fill: TH, stroke: TD, 'stroke-width': .8 }, g);
      [-1, 1].forEach(sd => { sepal(cx + sd * 24, by - 2, sd); petal(cx + sd * 20, by - 10, sd); stamen(cx + sd * 16, by - 18, sd, 64); }); ovary(by - 22, false);
      B.labL(g, cx + 22, by - 8, 300, 214, 'উত্তল থ্যালামাস', C, 'start'); B.labL(g, cx + 14, by - 40, 300, 150, 'ঊর্ধ্ব গর্ভাশয়', C, 'start'); }
    if (ty === 'dis') { E('path', { d: `M${cx - 26} ${by}C${cx - 24} ${by - 6} ${cx - 16} ${by - 12} ${cx} ${by - 12}C${cx + 16} ${by - 12} ${cx + 24} ${by - 6} ${cx + 26} ${by}Z`, fill: TH, stroke: TD, 'stroke-width': .8 }, g);
      E('path', { d: `M${cx - 24} ${by - 10}C${cx - 24} ${by - 22} ${cx + 24} ${by - 22} ${cx + 24} ${by - 10}C${cx + 16} ${by - 6} ${cx - 16} ${by - 6} ${cx - 24} ${by - 10}Z`, fill: '#f2d050', stroke: '#a88a10', 'stroke-width': .8 }, g);
      [-1, 1].forEach(sd => { sepal(cx + sd * 24, by - 2, sd); petal(cx + sd * 26, by - 8, sd); stamen(cx + sd * 25, by - 14, sd, 60); }); ovary(by - 20, false);
      B.labL(g, cx + 20, by - 15, 300, 214, 'মধুক্ষরা চাকতি', C, 'start'); B.labL(g, cx + 14, by - 40, 300, 150, 'ঊর্ধ্ব গর্ভাশয়', C, 'start'); }
    if (ty === 'cal') { /* পেয়ালার মতো থ্যালামাস (হাইপ্যান্থিয়াম) — পেরিজাইনাস */
      E('path', { d: `M${cx - 46} ${by - 54}C${cx - 44} ${by - 20} ${cx - 30} ${by} ${cx} ${by}C${cx + 30} ${by} ${cx + 44} ${by - 20} ${cx + 46} ${by - 54}L${cx + 40} ${by - 54}C${cx + 38} ${by - 26} ${cx + 26} ${by - 8} ${cx} ${by - 8}C${cx - 26} ${by - 8} ${cx - 38} ${by - 26} ${cx - 40} ${by - 54}Z`, fill: TH, stroke: TD, 'stroke-width': .8 }, g);
      [-1, 1].forEach(sd => { sepal(cx + sd * 46, by - 54, sd); petal(cx + sd * 42, by - 56, sd); stamen(cx + sd * 38, by - 54, sd, 50); }); ovary(by - 8, true);
      B.labL(g, cx + 42, by - 30, 352, 214, 'পেয়ালাকার থ্যালামাস', C, 'end'); B.labL(g, cx + 42, by - 56, 352, 40, 'পেয়ালার কিনারায় দল ও পুংকেশর', C, 'end'); }
    B.labL(g, cx - 56, by - 70, 40, 40, ty === 'cal' ? 'বৃতি (পেয়ালার কিনারায়)' : 'বৃতি', C, 'start');
    B.tx(g, 180, 252, OP[ty][1], { fs: 10, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 272, { tha: 'উদাহরণ: জবা, সরিষা', dis: 'উদাহরণ: লেবু, কমলা', cal: 'উদাহরণ: মটর, গোলাপ, লাউ' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ দ্বিবীজপত্রী বনাম একবীজপত্রী ═════════ */
const DM = {
  leaf: ['পাতা', 'শিরাবিন্যাস: জালিকা বনাম সমান্তরাল', 'দ্বিবীজপত্রীর পাতায় মধ্যশিরা থেকে শাখা-প্রশাখা জালের মতো ছড়ায় (জালিকা শিরাবিন্যাস, যেমন আম); একবীজপত্রীর পাতায় শিরাগুলো গোড়া থেকে আগা পর্যন্ত প্রায় সমান্তরাল (যেমন ধান, কলা)।'],
  seed: ['বীজ', 'বীজপত্র: দুটি বনাম একটি', 'দ্বিবীজপত্রীর বীজের ভ্রূণে দুটি বীজপত্র (যেমন ছোলা, শিম — সাধারণত সস্য নেই, খাদ্য বীজপত্রে); একবীজপত্রীর বীজে একটি বীজপত্র (ভুট্টায় স্কুটেলাম), খাদ্য প্রধানত সস্যে।'],
  flw: ['ফুল', 'পুষ্পাংশ: 4 বা 5 এর গুণিতক বনাম 3 এর গুণিতক', 'দ্বিবীজপত্রীর ফুলের অংশ সাধারণত 4 বা 5 টি করে (সরিষায় 4, জবায় 5); একবীজপত্রীর ফুলের অংশ 3 টি করে বা 3 এর গুণিতকে (লিলি, রসুনে 3 + 3 পুষ্পপুট খণ্ড, 6 পুংকেশর)।'],
  root: ['মূল', 'মূলতন্ত্র: প্রধান মূল বনাম গুচ্ছমূল', 'দ্বিবীজপত্রীতে ভ্রূণমূল থেকে স্থায়ী প্রধান মূল ও শাখামূল (যেমন সরিষা, আম); একবীজপত্রীতে ভ্রূণমূল শিগগির নষ্ট হয়, কাণ্ডের গোড়া থেকে অনেক সমান মোটা গুচ্ছমূল জন্মায় (যেমন ধান)।'],
  stem: ['কাণ্ড', 'কাণ্ডের প্রস্থচ্ছেদ: বলয়ে সাজানো বনাম ছড়ানো ভাস্কুলার বান্ডল', 'দ্বিবীজপত্রী কাণ্ডে ভাস্কুলার বান্ডল একটি বলয়ে সাজানো, খোলা (ক্যাম্বিয়ামসহ), তাই গৌণ বৃদ্ধি হয়; একবীজপত্রীতে বান্ডল সারা কাণ্ডে ছড়ানো, বন্ধ (ক্যাম্বিয়াম নেই)।']
};
V.dicotMonocot = Object.assign({}, B.seg({
  id: 'dmc', t: 'দ্বিবীজপত্রী বনাম একবীজপত্রী', H: 280, def: 'leaf', types: DM,
  cap: 'বেনথাম ও হুকারসহ প্রায় সব শ্রেণিবিন্যাস পদ্ধতিতে আবৃতবীজী উদ্ভিদকে এ দুই দলে ভাগ করা হয়। বাম পাশে দ্বিবীজপত্রী, ডান পাশে একবীজপত্রী।',
  art(g, C, ty) { E('rect', { x: 0, y: 0, width: 178, height: 232, fill: FK.alpha('#9a4a2a', .06) }, g); E('rect', { x: 182, y: 0, width: 178, height: 232, fill: FK.alpha('#2a6a9a', .06) }, g);
    B.tx(g, 89, 18, 'দ্বিবীজপত্রী', { fs: 10.4, a: 'middle', w: 700, c: '#8a3a1a' }); B.tx(g, 271, 18, 'একবীজপত্রী', { fs: 10.4, a: 'middle', w: 700, c: '#1e5a8a' });
    const LF = B.TS('leaf');
    if (ty === 'leaf') { E('path', { d: leafD(89, 210, -PI / 2, 176, 46), fill: B.vol(g, 'leaf'), stroke: LF.dk, 'stroke-width': .8 }, g); E('path', { d: 'M89 210V36', stroke: '#d8e8a0', 'stroke-width': 1.6 }, g);
      for (let k = 1; k < 9; k++) { const y = 200 - k * 19; [1, -1].forEach(sd => { const x1 = 89 + sd * 36 * Math.sin(k / 9 * PI), y1 = y - 16; E('path', { d: `M89 ${y}Q${f1(89 + sd * 12)} ${y - 8} ${f1(x1)} ${f1(y1)}`, stroke: '#d8e8a0', 'stroke-width': .9, fill: 'none' }, g);
        for (let j = 1; j < 4; j++) { const px = lerp(89, x1, j / 4), py = lerp(y, y1, j / 4); E('path', { d: `M${f1(px)} ${f1(py)}l${f1(sd * 4)} ${-9}`, stroke: FK.alpha('#d8e8a0', .7), 'stroke-width': .45 }, g); } }); }
      E('path', { d: 'M271 214C258 160 256 90 271 30C286 90 284 160 271 214Z', fill: B.vol(g, 'leaf'), stroke: LF.dk, 'stroke-width': .8 }, g);
      for (let k = -3; k <= 3; k++) E('path', { d: `M271 212C${271 + k * 4} 160 ${271 + k * 4.4} 90 271 32`, stroke: FK.alpha('#d8e8a0', k ? .75 : 1), 'stroke-width': k ? .6 : 1.3, fill: 'none' }, g);
      B.tx(g, 89, 226, 'জালিকা শিরাবিন্যাস (আম)', { fs: 9.4, a: 'middle', c: C.fg }); B.tx(g, 271, 226, 'সমান্তরাল শিরাবিন্যাস (ধান)', { fs: 9.4, a: 'middle', c: C.fg }); }
    if (ty === 'seed') { /* ছোলা: দুটি বীজপত্র খোলা; ভুট্টা: লম্বচ্ছেদ */
      [-1, 1].forEach(sd => E('path', { d: `M89 120C${89 + sd * 10} 70 ${89 + sd * 66} 70 ${89 + sd * 66} 120C${89 + sd * 66} 170 ${89 + sd * 10} 172 89 124Z`, fill: '#f0dca0', stroke: '#9a7a3a', 'stroke-width': .9 }, g));
      E('path', { d: 'M86 120C80 112 82 100 88 96M92 120C98 112 96 100 90 96', stroke: '#c8a860', 'stroke-width': 1.4, fill: 'none' }, g); E('path', { d: 'M89 124V148', stroke: '#c8a860', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g);
      B.labL(g, 50, 120, 20, 60, 'বীজপত্র 1', C, 'start'); B.labL(g, 128, 120, 160, 60, 'বীজপত্র 2', C, 'end'); B.labL(g, 89, 98, 89, 44, 'ভ্রূণমুকুল', C, 'middle'); B.labL(g, 89, 146, 60, 196, 'ভ্রূণমূল', C, 'middle');
      E('path', { d: 'M236 196C226 160 228 80 262 52C292 46 316 66 316 110C316 160 300 196 272 204C256 206 242 204 236 196Z', fill: '#f4e2a8', stroke: '#a8883a', 'stroke-width': .9 }, g);
      E('path', { d: 'M242 190C236 160 238 120 250 100C258 120 260 160 254 192Z', fill: '#f8f0d0', stroke: '#c8a860', 'stroke-width': .7 }, g); E('path', { d: 'M248 186V120', stroke: '#c8a860', 'stroke-width': 1.6 }, g);
      B.labL(g, 290, 110, 340, 60, 'সস্য', C, 'end'); B.labL(g, 254, 150, 210, 150, 'বীজপত্র (স্কুটেলাম)', C, 'end'); B.labL(g, 248, 125, 220, 90, 'ভ্রূণ', C, 'end');
      B.tx(g, 89, 226, 'ছোলা — দুটি বীজপত্র', { fs: 9.4, a: 'middle', c: C.fg }); B.tx(g, 271, 226, 'ভুট্টা — একটি বীজপত্র', { fs: 9.4, a: 'middle', c: C.fg }); }
    if (ty === 'flw') { for (let i = 0; i < 5; i++) { const a = -PI / 2 + i * 2 * PI / 5; E('path', { d: leafD(89, 118, a, 66, 22), fill: '#e8506a', stroke: '#8a1a30', 'stroke-width': .7 }, g); }
      E('circle', { cx: 89, cy: 118, r: 5, fill: '#f0d040' }, g); B.tx(g, 89, 210, '5টি পাপড়ি (জবা)', { fs: 9.4, a: 'middle', c: C.fg });
      for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3, out = i % 2 === 0; E('path', { d: leafD(271, 118, a, out ? 70 : 62, out ? 18 : 16), fill: out ? '#f6f0f8' : '#ffffff', stroke: '#a89ab8', 'stroke-width': .8 }, g); }
      for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3 + PI / 6; E('path', { d: `M271 118l${f1(Math.cos(a) * 24)} ${f1(Math.sin(a) * 24)}`, stroke: '#a8a060', 'stroke-width': 1 }, g); E('path', { d: B.ellD(271 + Math.cos(a) * 27, 118 + Math.sin(a) * 27, 4, 1.8, a * 57), fill: '#c8902a' }, g); }
      E('circle', { cx: 271, cy: 118, r: 4.6, fill: '#8ab048' }, g); B.tx(g, 271, 210, '3 + 3 পুষ্পপুট, 6 পুংকেশর (লিলি)', { fs: 9.4, a: 'middle', c: C.fg }); }
    if (ty === 'root') { E('rect', { x: 0, y: 70, width: 360, height: 162, fill: B.lin(g, 'soil', 90), opacity: .55 }, g);
      E('path', { d: 'M89 30V70', stroke: '#6a9a3a', 'stroke-width': 3 }, g); E('path', { d: 'M89 70C88 110 90 160 89 214', stroke: '#8a6a40', 'stroke-width': 3.6, fill: 'none', 'stroke-linecap': 'round' }, g);
      for (let k = 0; k < 9; k++) { const y = 84 + k * 14, sd = k % 2 ? 1 : -1, L = 46 - k * 3.6; E('path', { d: `M89 ${y}q${sd * L * .5} 4 ${sd * L} ${f1(14 + k)}`, stroke: '#8a6a40', 'stroke-width': 1.3, fill: 'none' }, g); }
      for (let i = 0; i < 9; i++) E('path', { d: `M271 70C${f1(271 + (i - 4) * 6)} 110 ${f1(271 + (i - 4) * 14)} 150 ${f1(271 + (i - 4) * 12 + B.rnd(i) * 6)} ${f1(196 + B.rnd(i + 4) * 14)}`, stroke: '#8a6a40', 'stroke-width': 1.4, fill: 'none' }, g);
      for (let i = 0; i < 5; i++) E('path', { d: `M${271 + (i - 2) * 3} 70V30`, stroke: '#6a9a3a', 'stroke-width': 1.6 }, g);
      B.tx(g, 89, 226, 'প্রধান মূল ও শাখামূল', { fs: 9.4, a: 'middle', c: C.fg, w: 600 }); B.tx(g, 271, 226, 'গুচ্ছমূল', { fs: 9.4, a: 'middle', c: C.fg, w: 600 }); }
    if (ty === 'stem') { const vb = (x, y, r, open) => { E('path', { d: B.ellD(x, y, r * 1.05, r * 1.35), fill: '#f8ecd0', stroke: '#a8883a', 'stroke-width': .5 }, g); E('path', { d: B.ellD(x, y - r * .5, r * .75, r * .55), fill: '#c8d8f0', stroke: '#4a6a9a', 'stroke-width': .4 }, g); E('path', { d: B.ellD(x, y + r * .55, r * .75, r * .55), fill: '#d8a070', stroke: '#8a5a2a', 'stroke-width': .4 }, g); if (open) E('path', { d: `M${x - r * .8} ${y}H${x + r * .8}`, stroke: '#3a8a3a', 'stroke-width': .9 }, g); };
      E('circle', { cx: 89, cy: 118, r: 74, fill: '#eef6e0', stroke: '#5a8a3a', 'stroke-width': 1.4 }, g);
      for (let i = 0; i < 12; i++) { const a = i / 12 * 2 * PI; const gg = E('g', { transform: `rotate(${f1(a * 180 / PI - 90)} ${f1(89 + Math.cos(a) * 46)} ${f1(118 + Math.sin(a) * 46)})` }, g); const save = g; g = gg; vb(89 + Math.cos(a) * 46, 118 + Math.sin(a) * 46, 7.4, true); g = save; }
      E('circle', { cx: 271, cy: 118, r: 74, fill: '#eef6e0', stroke: '#5a8a3a', 'stroke-width': 1.4 }, g);
      for (let i = 0; i < 34; i++) { const a = B.rnd(i) * 2 * PI, r = Math.sqrt(B.rnd(i + 50)) * 62; vb(271 + Math.cos(a) * r, 118 + Math.sin(a) * r, 4.4 + (r > 44 ? 0 : 1.6), false); }
      B.tx(g, 89, 210, 'বলয়ে সাজানো, খোলা বান্ডল', { fs: 9.4, a: 'middle', c: C.fg }); B.tx(g, 271, 210, 'ছড়ানো, বন্ধ বান্ডল', { fs: 9.4, a: 'middle', c: C.fg });
      B.tx(g, 180, 226, 'নীল = জাইলেম · বাদামি = ফ্লোয়েম · সবুজ রেখা = ক্যাম্বিয়াম', { fs: 8.6, a: 'middle', c: C.mu }); }
    B.tx(g, 180, 252, DM[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 272, { leaf: 'উদাহরণ: আম, জবা বনাম ধান, কলা', seed: 'ভ্রূণের বীজপত্রের সংখ্যা থেকেই দুই দলের নাম', flw: 'পুষ্পাংশের সংখ্যা', root: 'মূলতন্ত্রের ধরন', stem: 'অভ্যন্তরীণ গঠন' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));
})();
