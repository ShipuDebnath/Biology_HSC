/* ═══════════════════════════════════════════════════════════════════
   visuals6 — জীবজগতের রাজ্য:
   kingdomTimeline (2 → 3 → 4 → 5 → 6 রাজ্য → 3 ডোমেইন), fiveKChart (মারগুলিস ও শোয়ার্জের পঞ্চজগৎ ছক),
   kingdomCards (প্রতিটি রাজ্যের নমুনা জীবের রেখাচিত্র), prokEuk (আদিকোষ বনাম প্রকৃতকোষ),
   threeDomains (উসের তিন ডোমেইনের জাতিজনি গাছ), sixKingdom (ছয় রাজ্য ও আর্কিয়া বনাম ব্যাকটেরিয়া)
   সহায়ক: B.bacterium, B.nostoc, B.chlamy, B.amoeba, B.mushroom, B.fishSide
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, B = window.B100, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits, leafD = B.leafD, P2 = B.P2;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const KC = { mon: '#8a6a2a', pro: '#2a7a8a', fun: '#8a5a7a', pla: '#3a7a2a', ani: '#a8402a', arc: '#b0601a', eub: '#7a7a2a', euk: '#2a5a7a' };

/* ═════════ নমুনা জীবের আঁকা ═════════ */
B.bacterium = (g, x, y, s = 1, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${o.rot || 0}) scale(${s})` }, g), Bt = B.TS('bact');
  if (o.flag !== false) E('path', { d: 'M40 0C52 -8 58 8 70 0S88 -8 98 0', stroke: '#6a5a3a', 'stroke-width': 1.2, fill: 'none' }, gg);
  if (o.pili) for (let i = 0; i < 14; i++) { const a = i / 14 * 2 * PI, px = Math.cos(a) * 38, py = Math.sin(a) * 15; E('path', { d: `M${f1(px)} ${f1(py)}l${f1(Math.cos(a) * 7)} ${f1(Math.sin(a) * 7)}`, stroke: '#8a7a5a', 'stroke-width': .5 }, gg); }
  if (o.cap) E('rect', { x: -44, y: -21, width: 88, height: 42, rx: 21, fill: FK.alpha('#e8e0c8', .6), stroke: FK.alpha('#a8986a', .6), 'stroke-dasharray': '2 2' }, gg);
  E('rect', { x: -40, y: -17, width: 80, height: 34, rx: 17, fill: Bt.c, stroke: Bt.dk, 'stroke-width': 1.6 }, gg);
  E('rect', { x: -37, y: -14, width: 74, height: 28, rx: 14, fill: Bt.lt, stroke: '#4a6a8a', 'stroke-width': .7 }, gg);
  /* নিউক্লিয়য়েড: জট পাকানো বৃত্তাকার DNA */
  let d = ''; for (let k = 0; k <= 80; k++) { const t = k / 80 * 2 * PI; d += (k ? 'L' : 'M') + f1(Math.cos(t) * 14 + Math.sin(t * 5) * 4) + ' ' + f1(Math.sin(t) * 6 + Math.cos(t * 7) * 2.6); } E('path', { d: d + 'Z', stroke: '#5a3a8a', 'stroke-width': .8, fill: FK.alpha('#c8b8e8', .5) }, gg);
  if (o.plas !== false) E('circle', { cx: 24, cy: 6, r: 3.4, fill: 'none', stroke: '#8a3a6a', 'stroke-width': .7 }, gg);
  for (let i = 0; i < 26; i++) { const px = -32 + B.rnd(i) * 64, py = -10 + B.rnd(i + 40) * 20; if (Math.abs(px) < 18 && Math.abs(py) < 8) continue; E('circle', { cx: f1(px), cy: f1(py), r: .9, fill: '#5a4a2a' }, gg); }
  return gg; };
B.nostoc = (g, x, y, s = 1, n = 9) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: `M-6 0H${(n - 1) * 11 + 6}`, stroke: FK.alpha('#7ab0a0', .4), 'stroke-width': 14, 'stroke-linecap': 'round' }, gg);
  for (let i = 0; i < n; i++) { const het = i === 4; E('circle', { cx: i * 11, cy: Math.sin(i * .9) * 2, r: het ? 5.4 : 5, fill: het ? '#e8e0a0' : '#4aa088', stroke: het ? '#8a8a3a' : '#1e6a58', 'stroke-width': het ? 1.2 : .6 }, gg); } return gg; };
B.chlamy = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M-4 -28C-14 -44 -22 -56 -18 -72M4 -28C14 -44 22 -56 18 -72', stroke: '#5a6a4a', 'stroke-width': 1, fill: 'none' }, gg);
  E('path', { d: B.ellD(0, 0, 22, 29), fill: '#f2f8e6', stroke: '#6a8a4a', 'stroke-width': 1.4 }, gg);
  E('path', { d: 'M-20 -4C-22 14 -12 28 0 28C12 28 22 14 20 -4C16 8 8 16 0 16C-8 16 -16 8 -20 -4Z', fill: B.vol(gg, 'chlo'), stroke: '#2a6020', 'stroke-width': .7 }, gg);
  E('circle', { cx: 0, cy: 20, r: 4.6, fill: '#d8e8b0', stroke: '#2a6020', 'stroke-width': .6 }, gg);
  E('circle', { cx: 0, cy: -4, r: 6.4, fill: '#c8b8e0', stroke: '#5a4a8a', 'stroke-width': .6 }, gg); E('circle', { cx: 0, cy: -4, r: 2, fill: '#5a4a8a' }, gg);
  E('path', { d: B.ellD(15, -4, 2.6, 3.6), fill: '#d0302a' }, gg);
  E('circle', { cx: -5, cy: -20, r: 2.6, fill: '#e8f4fa', stroke: '#6a9ab0', 'stroke-width': .5 }, gg); E('circle', { cx: 5, cy: -20, r: 2.6, fill: '#e8f4fa', stroke: '#6a9ab0', 'stroke-width': .5 }, gg);
  return gg; };
B.amoeba = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M-30 -4C-40 -18 -30 -30 -16 -24C-10 -36 6 -36 10 -24C22 -30 38 -24 34 -10C46 -4 44 12 30 14C30 28 14 32 4 24C-6 34 -24 30 -24 18C-38 18 -42 6 -30 -4Z', fill: '#eef4fa', stroke: '#5a7a9a', 'stroke-width': 1.1 }, gg);
  E('path', { d: 'M-24 -2C-30 -12 -22 -22 -12 -18C-6 -28 6 -28 8 -18C18 -22 30 -18 28 -8C36 -2 34 10 24 10C22 22 10 24 4 18C-4 26 -18 22 -18 14C-28 12 -30 4 -24 -2Z', fill: '#dce8f4', stroke: 'none' }, gg);
  E('path', { d: B.ellD(-2, 0, 7, 5.6), fill: '#c8b8e0', stroke: '#5a4a8a', 'stroke-width': .6 }, gg);
  E('circle', { cx: 16, cy: -8, r: 4.4, fill: '#fff', stroke: '#6a9ab0', 'stroke-width': .6 }, gg); [[-16, 6], [10, 12], [-6, -16]].forEach(([fx, fy]) => E('circle', { cx: fx, cy: fy, r: 3, fill: '#e8d8b0', stroke: '#9a8a5a', 'stroke-width': .5 }, gg));
  return gg; };
B.mushroom = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), M = B.TS('mush');
  for (let i = 0; i < 16; i++) { const a = PI * (.1 + B.rnd(i) * .8), L = 20 + B.rnd(i + 5) * 30; E('path', { d: `M${f1((B.rnd(i + 9) - .5) * 10)} 2Q${f1(Math.cos(a) * L * .5)} ${f1(8 + Math.sin(a) * L * .3)} ${f1(Math.cos(a) * L)} ${f1(10 + Math.sin(a) * L * .5)}`, stroke: '#e8e0d0', 'stroke-width': .8, fill: 'none' }, gg); }
  E('path', { d: 'M-7 2C-8 -20 -6 -40 -5 -54H5C6 -40 8 -20 7 2Z', fill: B.lin(gg, 'mush', 0), stroke: M.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M-12 -40C-8 -36 8 -36 12 -40L9 -44C4 -42 -4 -42 -9 -44Z', fill: '#efe6d4', stroke: M.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M-40 -54C-40 -74 -22 -86 0 -86C22 -86 40 -74 40 -54Z', fill: B.vol(gg, 'mush'), stroke: M.dk, 'stroke-width': .9 }, gg);
  E('path', { d: 'M-40 -54C-28 -50 28 -50 40 -54C30 -52 -30 -52 -40 -54Z', fill: B.TS('gill').c }, gg); for (let i = 0; i < 17; i++) E('path', { d: `M${-38 + i * 4.75} -54L${f1(lerp(-38 + i * 4.75, 0, .2))} -51`, stroke: B.TS('gill').dk, 'stroke-width': .5 }, gg);
  for (let i = 0; i < 8; i++) E('path', { d: B.ellD(-24 + B.rnd(i) * 48, -64 - B.rnd(i + 3) * 16, 2.4, 1.4, B.rnd(i) * 180), fill: FK.alpha(M.dk, .35) }, gg);
  return gg; };
B.fishSide = (g, x, y, s = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), F = B.TS('fish');
  E('path', { d: 'M-46 0L-62 -14L-58 0L-62 14Z', fill: '#9a8a70', stroke: '#5a4a30', 'stroke-width': .6 }, gg);
  E('path', { d: 'M-10 -18C-4 -28 12 -28 18 -20Z', fill: '#9a8a70', stroke: '#5a4a30', 'stroke-width': .5 }, gg);
  E('path', { d: 'M46 -2C42 -14 26 -22 6 -22C-18 -22 -38 -12 -46 0C-38 12 -18 20 6 20C26 20 42 12 46 2Z', fill: B.lin(gg, 'fish', 90), stroke: F.dk, 'stroke-width': .8 }, gg);
  for (let r = 0; r < 5; r++) for (let c = 0; c < 9; c++) { const sx = -32 + c * 7 + (r % 2) * 3.5, sy = -14 + r * 6.6; E('path', { d: `M${f1(sx)} ${f1(sy - 3)}a3.4 3.4 0 0 1 0 6.6`, stroke: FK.alpha(F.dk, .35), 'stroke-width': .5, fill: 'none' }, gg); }
  E('path', { d: 'M28 -16Q22 0 28 16', stroke: F.dk, 'stroke-width': .8, fill: 'none' }, gg); E('path', { d: 'M18 6C10 10 6 16 4 20C12 18 18 14 20 10Z', fill: '#a89a78', stroke: '#5a4a30', 'stroke-width': .4 }, gg);
  E('circle', { cx: 36, cy: -6, r: 3.4, fill: '#f0e0a0', stroke: '#3a3018', 'stroke-width': .5 }, gg); E('circle', { cx: 36.6, cy: -6, r: 1.6, fill: '#111' }, gg); E('path', { d: 'M46 2l-4 1', stroke: F.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M-30 0H24', stroke: FK.alpha(F.dk, .3), 'stroke-width': .6 }, gg);
  return gg; };

/* ═════════ রাজ্যের সংখ্যা বৃদ্ধির ইতিহাস ═════════ */
const KT = [
  { t: 'লিনিয়াস, 1735', en: 'Two kingdoms', d: 'জীবজগৎ দুই রাজ্যে — উদ্ভিদ (Plantae: চলনহীন, সালোকসংশ্লেষী — ছত্রাক ও শৈবালসহ) ও প্রাণী (Animalia: চলনক্ষম, খাদ্য গ্রহণ করে)। অণুজীব তখন প্রায় অজানা।', k: [['pla', 'উদ্ভিদ', 'Plantae', 'উদ্ভিদ, শৈবাল, ছত্রাক'], ['ani', 'প্রাণী', 'Animalia', 'প্রাণী']] },
  { t: 'হেকেল, 1866', en: 'Three kingdoms', d: 'অণুবীক্ষণে দেখা এককোষী জীব উদ্ভিদও নয়, প্রাণীও নয় — তাদের জন্য তৃতীয় রাজ্য প্রোটিস্টা (Protista)।', k: [['pro', 'প্রোটিস্টা', 'Protista', 'এককোষী জীব, ব্যাকটেরিয়া'], ['pla', 'উদ্ভিদ', 'Plantae', 'উদ্ভিদ, ছত্রাক'], ['ani', 'প্রাণী', 'Animalia', 'প্রাণী']] },
  { t: 'কোপল্যান্ড, 1938', en: 'Four kingdoms', d: 'ইলেকট্রন অণুবীক্ষণে দেখা গেল ব্যাকটেরিয়ার নিউক্লিয়াস নেই — আদিকোষীদের আলাদা রাজ্য মনেরা (Monera); বাকি এককোষী ও ছত্রাক প্রোটোক্টিস্টায়।', k: [['mon', 'মনেরা', 'Monera', 'ব্যাকটেরিয়া, সায়ানো-ব্যাকটেরিয়া'], ['pro', 'প্রোটোক্টিস্টা', 'Protoctista', 'প্রোটোজোয়া, শৈবাল, ছত্রাক'], ['pla', 'উদ্ভিদ', 'Plantae', 'উদ্ভিদ'], ['ani', 'প্রাণী', 'Animalia', 'প্রাণী']] },
  { t: 'হুইটেকার, 1969', en: 'Five kingdoms', d: 'পুষ্টির ধরনে ছত্রাক আলাদা — শোষণ করে খায়, সালোকসংশ্লেষণ করে না। কোষের ধরন, কোষসংখ্যা ও পুষ্টি দেখে পাঁচ রাজ্য: মনেরা, প্রোটিস্টা, ফানজাই, প্লান্টি, অ্যানিমেলিয়া।', k: [['mon', 'মনেরা', 'Monera', 'আদিকোষী'], ['pro', 'প্রোটিস্টা', 'Protista', 'এককোষী প্রকৃতকোষী'], ['fun', 'ফানজাই', 'Fungi', 'শোষণকারী'], ['pla', 'প্লান্টি', 'Plantae', 'সালোকসংশ্লেষী'], ['ani', 'অ্যানিমেলিয়া', 'Animalia', 'ভক্ষণকারী']] },
  { t: 'উস ও সহকর্মী, 1977', en: 'Six kingdoms', d: 'রাইবোসোমাল RNA এর ক্রম তুলনা করে কার্ল উস দেখান, আদিকোষীরা দুই ভিন্ন দল — আর্কিব্যাকটেরিয়া ও ইউব্যাকটেরিয়া। মনেরা ভেঙে ছয় রাজ্য।', k: [['arc', 'আর্কি', 'Archaebacteria', 'চরম পরিবেশ'], ['eub', 'ইউব্যাক্টি', 'Eubacteria', 'সাধারণ ব্যাকটেরিয়া'], ['pro', 'প্রোটিস্টা', 'Protista', ''], ['fun', 'ফানজাই', 'Fungi', ''], ['pla', 'প্লান্টি', 'Plantae', ''], ['ani', 'অ্যানিমেলিয়া', 'Animalia', '']] },
  { t: 'উস, ক্যান্ডলার ও হুইলিস, 1990', en: 'Three domains', d: 'রাজ্যের ওপরে আরও বড় একক ডোমেইন: ব্যাকটেরিয়া, আর্কিয়া ও ইউক্যারিয়া। প্রকৃতকোষী সব রাজ্য (প্রোটিস্টা, ছত্রাক, উদ্ভিদ, প্রাণী) ইউক্যারিয়ায়।', k: [['eub', 'ব্যাকটেরিয়া', 'Bacteria', 'ডোমেইন'], ['arc', 'আর্কিয়া', 'Archaea', 'ডোমেইন'], ['euk', 'ইউক্যারিয়া', 'Eukarya', 'ডোমেইন: প্রোটিস্টা, ছত্রাক, উদ্ভিদ, প্রাণী']] }
];
V.kingdomTimeline = Object.assign({ t: 'জীবরাজ্যের সংখ্যা বৃদ্ধির ইতিহাস', k: ['2d', 'anim', 'steps'], cap: 'নতুন যন্ত্র (অণুবীক্ষণ, ইলেকট্রন অণুবীক্ষণ) ও নতুন তথ্য (পুষ্টির ধরন, রাইবোসোমাল RNA) আসার সাথে সাথে রাজ্যের সংখ্যা 2 থেকে 3, 4, 5, 6 হয়েছে এবং শেষে রাজ্যের ওপরে তিনটি ডোমেইন এসেছে। (কোপল্যান্ডের চার রাজ্য প্রথম 1938 সালে, বিস্তারিত 1956 সালের বইয়ে।)' },
  BK.steps({ W: 360, H: 270, label: 'রাজ্যের ইতিহাস', dur: 3.6, stages: KT,
    draw(g, C, s, u) { const ks = KT[s].k, n = ks.length, W = 340 / n, k = FK.ease(cl(u * 1.6));
      B.cacheG(g, 'kt' + s, gg => {
        /* বছরের রেখা */
        const yrs = [1735, 1866, 1938, 1969, 1977, 1990], X = y => 24 + (y - 1720) / 280 * 312;
        E('path', { d: 'M20 236H340', stroke: FK.alpha(C.fg, .35), 'stroke-width': 1.2 }, gg);
        yrs.forEach((y, i) => { E('circle', { cx: f1(X(y)), cy: 236, r: i === s ? 5 : 3, fill: i <= s ? '#2a6a8a' : FK.alpha(C.fg, .25) }, gg); B.tx(gg, X(y), i % 2 ? 258 : 252, String(y), { fs: 8.4, a: 'middle', c: i === s ? '#2a6a8a' : C.mu, w: i === s ? 700 : 400 }); });
        B.tx(gg, 180, 22, `${KT[s].t} — ${['2 রাজ্য', '3 রাজ্য', '4 রাজ্য', '5 রাজ্য', '6 রাজ্য', '3 ডোমেইন'][s]}`, { fs: 11, a: 'middle', w: 700, c: C.fg }); });
      const done = s === 0 || k >= 1, isNew = key2 => s > 0 && !KT[s - 1].k.some(q => q[0] === key2);
      const box = (gg, i, h) => { const [key, bn, la, mem] = ks[i], x = 10 + i * W, c = KC[key], nw = isNew(key), y = 200 - h;
        E('rect', { x: f1(x + 2), y: f1(y), width: f1(W - 4), height: f1(h), rx: 10, fill: FK.alpha(c, nw ? .2 : .1), stroke: c, 'stroke-width': nw ? 2 : 1.1 }, gg);
        if (h > 120) { B.tx(gg, x + W / 2, y + 22, bn, { fs: n > 4 ? 9 : 10.4, a: 'middle', w: 700, c }); B.tx(gg, x + W / 2, y + 36, la, { fs: n > 4 ? 7.4 : 8.6, a: 'middle', c: C.mu, st: 'font-style:italic' });
          (mem || '').split(', ').forEach((m, j) => m && B.tx(gg, x + W / 2, y + 64 + j * 16, m, { fs: n > 4 ? 7.8 : 9.6, a: 'middle', c: C.fg }));
          if (nw) B.tx(gg, x + W / 2, 214, 'নতুন', { fs: 8.6, a: 'middle', w: 700, c }); } };
      /* পুরোনো বাক্স (ও শেষ অবস্থা) স্থির স্তরে; শুধু নতুন বাক্সের বাড়া প্রতি ফ্রেমে */
      B.cacheG(g, 'ktb' + (s * 10 + (done ? 1 : 0)), gg => ks.forEach((q, i) => { if (done || !isNew(q[0])) box(gg, i, 160); }));
      if (!done) ks.forEach((q, i) => { if (isNew(q[0])) box(g, i, lerp(40, 160, k)); });
    }
  }));

/* ═════════ মারগুলিস ও শোয়ার্জের পঞ্চজগৎ ছক ═════════ */
V.fiveKChart = Object.assign({ t: 'মারগুলিস ও শোয়ার্জের পঞ্চজগৎ (1982)', k: ['2d', 'int'], cap: 'লিন মারগুলিস ও কার্লিন শোয়ার্জ (Five Kingdoms, 1982) হুইটেকারের পাঁচ রাজ্যকে দুই অধিজগতে (superkingdom) সাজান: আদিকোষী (Prokaryotae) ও প্রকৃতকোষী (Eukaryotae)। তাঁদের মতে উদ্ভিদ শুধু ভ্রূণ গঠনকারী সবুজ উদ্ভিদ (মস থেকে সপুষ্পক); শৈবাল প্রোটোক্টিস্টায়।' }, B.seg({
  id: 'fkc', t: 'পঞ্চজগৎ', H: 330, def: 'all', types: { all: ['ছক', 'দুই অধিজগৎ, পাঁচ রাজ্য', 'কোষের ধরন → অধিজগৎ; কোষসংখ্যা, পুষ্টি ও বিকাশের ধরন → রাজ্য।'] },
  art(g, C) {
    const N = (x, y, w, t, sub, c) => { E('rect', { x: x - w / 2, y: y - 13, width: w, height: 30, rx: 8, fill: FK.alpha(c, .13), stroke: c, 'stroke-width': 1.2 }, g); B.tx(g, x, y + 2, t, { fs: 9.6, a: 'middle', w: 700, c }); B.tx(g, x, y + 13, sub, { fs: 7.8, a: 'middle', c: C.mu, st: 'font-style:italic' }); };
    const L = (x0, y0, x1, y1) => E('path', { d: `M${x0} ${y0}V${(y0 + y1) / 2}H${x1}V${y1}`, stroke: FK.alpha(C.fg, .4), 'stroke-width': 1, fill: 'none' }, g);
    N(180, 22, 120, 'জীবজগৎ', 'Living organisms', '#3a4a5a'); L(180, 37, 72, 58); L(180, 37, 234, 58);
    N(72, 70, 84, 'আদিকোষী', 'Prokaryotae', '#8a6a2a'); N(234, 70, 120, 'প্রকৃতকোষী', 'Eukaryotae', '#2a5a7a');
    const xs = [72, 140, 204, 266, 326], ks = [['mon', 'মনেরা', 'Monera'], ['pro', 'প্রোটোক্টিস্টা', 'Protoctista'], ['fun', 'ফানজাই', 'Fungi'], ['pla', 'প্লান্টি', 'Plantae'], ['ani', 'অ্যানিমেলিয়া', 'Animalia']];
    L(72, 85, 72, 110); [1, 2, 3, 4].forEach(i => L(234, 85, xs[i], 110));
    ks.forEach(([k, bn, la], i) => N(xs[i], 122, i ? 62 : 66, bn, la, KC[k]));
    /* বৈশিষ্ট্যের সারি */
    const rows = [['কোষ', ['আদি', 'প্রকৃত', 'প্রকৃত', 'প্রকৃত', 'প্রকৃত']], ['কোষসংখ্যা', ['এককোষী', 'এক/বহু, সরল', 'প্রধানত বহু', 'বহুকোষী', 'বহুকোষী']], ['পুষ্টি', ['নানা ধরন', 'নানা ধরন', 'শোষণ', 'সালোক-সংশ্লেষণ', 'ভক্ষণ']], ['বিকাশ', ['—', 'ভ্রূণ নেই', 'রেণু থেকে', 'ভ্রূণ থেকে', 'ব্লাস্টুলা থেকে']]];
    rows.forEach(([h, vals], r) => { const y = 162 + r * 24; E('rect', { x: 4, y: y - 10, width: 352, height: 22, fill: r % 2 ? 'none' : FK.alpha(C.fg, .04) }, g);
      vals.forEach((v, i) => B.tx(g, xs[i], y + 5, v, { fs: 8.2, a: 'middle', c: C.fg })); });
    ['কোষ', 'কোষসংখ্যা', 'পুষ্টি', 'বিকাশ'].forEach((h, r) => B.tx(g, 6, 162 + r * 24 + 5, h, { fs: 8.2, c: C.mu, w: 700 }));
    /* নমুনা */
    const ex = ['ব্যাকটেরিয়া, Nostoc', 'অ্যামিবা, শৈবাল', 'মাশরুম, ইস্ট', 'মস, ফার্ন, আম', 'হাইড্রা, মাছ'];
    ex.forEach((e, i) => e.split(', ').forEach((p, j) => B.tx(g, xs[i], 268 + j * 12, p, { fs: 8.2, a: 'middle', c: KC[ks[i][0]], w: 600 })));
    B.tx(g, 180, 314, 'উদাহরণ', { fs: 8.6, a: 'middle', c: C.mu }); }
}));

/* ═════════ প্রতিটি রাজ্যের নমুনা জীব ═════════ */
const KK = {
  mon: ['মনেরা', 'মনেরা — ব্যাকটেরিয়া (E. coli) ও Nostoc', 'আদিকোষী: সুগঠিত নিউক্লিয়াস ও ঝিল্লিযুক্ত অঙ্গাণু নেই; DNA নিউক্লিয়য়েডে; 70S রাইবোসোম; কোষপ্রাচীরে পেপটিডোগ্লাইকান। সায়ানোব্যাকটেরিয়া (Nostoc) সালোকসংশ্লেষণ করে; হেটারোসিস্টে নাইট্রোজেন সংবন্ধন হয়।'],
  pro: ['প্রোটোক্টিস্টা', 'প্রোটোক্টিস্টা — Chlamydomonas ও অ্যামিবা', 'প্রকৃতকোষী, প্রধানত এককোষী বা সরল বহুকোষী; ভ্রূণ হয় না। কেউ সালোকসংশ্লেষী (শৈবাল — Chlamydomonas এর পেয়ালাকৃতি ক্লোরোপ্লাস্ট ও চক্ষুবিন্দু), কেউ ভক্ষণকারী (প্রোটোজোয়া — অ্যামিবার ক্ষণপদ)।'],
  fun: ['ফানজাই', 'ফানজাই — মাশরুম (Agaricus)', 'প্রকৃতকোষী, অধিকাংশ বহুকোষী সূত্রাকার (হাইফা ও মাইসেলিয়াম); কোষপ্রাচীরে কাইটিন; ক্লোরোফিল নেই — মৃত জৈব বস্তু থেকে খাদ্য শোষণ করে (মৃতজীবী) বা পরজীবী; রেণু দিয়ে বংশবিস্তার।'],
  pla: ['প্লান্টি', 'প্লান্টি — ফার্ন ও সরিষা', 'প্রকৃতকোষী, বহুকোষী; সেলুলোজের কোষপ্রাচীর; ক্লোরোফিল-a ও b দিয়ে সালোকসংশ্লেষণ; জাইগোট থেকে ভ্রূণ গঠিত হয়। মস, ফার্ন, নগ্নবীজী ও আবৃতবীজী।'],
  ani: ['অ্যানিমেলিয়া', 'অ্যানিমেলিয়া — রুই মাছ', 'প্রকৃতকোষী, বহুকোষী; কোষপ্রাচীর নেই; খাদ্য গ্রহণ করে পরিপাক করে (ভক্ষণকারী); জাইগোট থেকে ব্লাস্টুলা দশা হয়ে বিকাশ; সাধারণত চলনক্ষম ও স্নায়ুতন্ত্র আছে।']
};
V.kingdomCards = Object.assign({}, B.seg({
  id: 'kkc', t: 'পাঁচ রাজ্যের নমুনা জীব', H: 290, def: 'mon', types: KK,
  cap: 'প্রতিটি রাজ্যের পরিচিত সদস্যের রেখাচিত্র। মাপ অনুপাতে নয়: ব্যাকটেরিয়া প্রায় 2 মাইক্রোমিটার, Chlamydomonas প্রায় 10–20 মাইক্রোমিটার, অ্যামিবা প্রায় 0.5 মিলিমিটার।',
  art(g, C, ty) { const c = KC[ty]; E('rect', { x: 0, y: 0, width: 360, height: 236, fill: FK.alpha(c, .06) }, g);
    if (ty === 'mon') { B.bacterium(g, 150, 90, 1.6, { pili: true, cap: true }); B.nostoc(g, 120, 196, 1.2);
      B.labL(g, 86, 76, 30, 26, 'কোষপ্রাচীর', C, 'start'); B.labL(g, 150, 92, 150, 26, 'নিউক্লিয়য়েড (DNA)', C, 'middle'); B.labL(g, 188, 100, 300, 140, 'প্লাজমিড', C, 'start'); B.labL(g, 270, 90, 330, 40, 'ফ্ল্যাজেলাম', C, 'end'); B.labL(g, 116, 104, 40, 140, 'রাইবোসোম', C, 'start');
      B.labL(g, 168, 196, 250, 222, 'হেটারোসিস্ট (Nostoc)', C, 'start'); }
    if (ty === 'pro') { B.chlamy(g, 100, 136, 2.2); B.amoeba(g, 270, 132, 1.5);
      B.labL(g, 100, 172, 30, 220, 'পেয়ালাকৃতি ক্লোরোপ্লাস্ট', C, 'start'); B.labL(g, 133, 127, 160, 60, 'চক্ষুবিন্দু', C, 'start'); B.labL(g, 80, 30, 20, 16, 'দুটি ফ্ল্যাজেলা', C, 'start'); B.labL(g, 100, 180, 160, 222, 'পাইরিনয়েড', C, 'start');
      B.labL(g, 237, 126, 220, 60, 'ক্ষণপদ', C, 'middle'); B.labL(g, 267, 132, 300, 220, 'নিউক্লিয়াস', C, 'middle'); B.labL(g, 294, 120, 340, 60, 'সংকোচনশীল গহ্বর', C, 'end'); }
    if (ty === 'fun') { E('rect', { x: 0, y: 194, width: 360, height: 42, fill: B.lin(g, 'soil', 90) }, g); B.mushroom(g, 180, 196, 1.9);
      B.labL(g, 150, 46, 60, 30, 'টুপি (পাইলিয়াস)', C, 'start'); B.labL(g, 220, 94, 300, 64, 'ফুলকা (রেণু তৈরি)', C, 'start'); B.labL(g, 196, 116, 300, 120, 'অ্যানুলাস', C, 'start'); B.labL(g, 184, 160, 300, 170, 'বৃন্ত (স্টাইপ)', C, 'start'); B.labL(g, 140, 212, 40, 220, 'মাইসেলিয়াম (হাইফার জাল)', C, 'start'); }
    if (ty === 'pla') { E('rect', { x: 0, y: 194, width: 360, height: 42, fill: B.lin(g, 'soil', 90) }, g); B.fern(g, 110, 192, 1.45); B.mustard(g, 270, 194, 1.25);
      B.tx(g, 110, 26, 'ফার্ন (পরিবহন টিস্যু, রেণু)', { fs: 9.4, a: 'middle', c: C.fg }); B.tx(g, 270, 26, 'সরিষা (ফুল, বীজ)', { fs: 9.4, a: 'middle', c: C.fg }); }
    if (ty === 'ani') { E('rect', { x: 0, y: 0, width: 360, height: 236, fill: B.lin(g, 'wtr', 90), opacity: .7 }, g); B.fishSide(g, 180, 118, 2.6);
      B.labL(g, 270, 102, 320, 40, 'চোখ', C, 'end'); B.labL(g, 252, 118, 320, 190, 'কানকো', C, 'end'); B.labL(g, 196, 58, 210, 24, 'পৃষ্ঠপাখনা', C, 'middle'); B.labL(g, 22, 118, 30, 40, 'পুচ্ছপাখনা', C, 'start'); B.labL(g, 120, 100, 80, 200, 'আঁইশ', C, 'middle'); }
    B.tx(g, 180, 256, KK[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 276, { mon: 'আদিকোষী · এককোষী', pro: 'প্রকৃতকোষী · প্রধানত এককোষী · ভ্রূণ নেই', fun: 'প্রকৃতকোষী · শোষণকারী · কাইটিনের প্রাচীর', pla: 'প্রকৃতকোষী · সালোকসংশ্লেষী · ভ্রূণ আছে', ani: 'প্রকৃতকোষী · ভক্ষণকারী · কোষপ্রাচীর নেই' }[ty], { fs: 10, a: 'middle', c: C.mu }); }
}));

/* ═════════ আদিকোষ বনাম প্রকৃতকোষ ═════════ */
V.prokEuk = Object.assign({ t: 'আদিকোষী বনাম প্রকৃতকোষী কোষ', k: ['2d', 'int', 'quiz'], cap: 'বাঁয়ে একটি ব্যাকটেরিয়া কোষ (আদিকোষী, প্রায় 1–5 মাইক্রোমিটার), ডানে একটি প্রকৃতকোষী কোষের অংশ (প্রায় 10–100 মাইক্রোমিটার) — মাপ অনুপাতে নয়। এ পার্থক্যই পঞ্চজগতের দুই অধিজগৎ ও তিন ডোমেইনের মূল ভিত্তি।' },
  BK.diagram({ W: 360, H: 300, label: 'আদি ও প্রকৃত কোষ',
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      E('path', { d: 'M150 10V290', stroke: FK.alpha(C.fg, .2), 'stroke-dasharray': '4 4' }, g);
      B.tx(g, 76, 296, 'আদিকোষী (ব্যাকটেরিয়া)', { fs: 9.6, a: 'middle', w: 700, c: '#8a6a2a' }); B.tx(g, 256, 296, 'প্রকৃতকোষী', { fs: 9.6, a: 'middle', w: 700, c: '#2a5a7a' });
      B.bacterium(P('pwall'), 104, 124, 1.4, { plas: true, flag: true, rot: 90 });
      E('circle', { cx: 104, cy: 124, r: 16, fill: 'transparent' }, P('nucleoid')); E('circle', { cx: 96, cy: 158, r: 6, fill: 'transparent' }, P('plas')); E('circle', { cx: 112, cy: 92, r: 8, fill: 'transparent' }, P('rib70'));
      /* প্রকৃতকোষ */
      const X0 = 160, Y0 = 34, X1 = 352, Y1 = 266;
      E('path', { d: `M${X0 + 20} ${Y0}C${X1 - 20} ${Y0 - 8} ${X1 + 4} ${Y0 + 40} ${X1} ${(Y0 + Y1) / 2}C${X1 + 4} ${Y1 - 30} ${X1 - 30} ${Y1 + 4} ${(X0 + X1) / 2} ${Y1}C${X0 + 10} ${Y1 + 2} ${X0 - 4} ${Y1 - 40} ${X0} ${(Y0 + Y1) / 2}C${X0 - 4} ${Y0 + 30} ${X0 + 4} ${Y0 + 2} ${X0 + 20} ${Y0}Z`, fill: '#fbf3ea', stroke: '#6a5a8a', 'stroke-width': 1.4 }, P('emem'));
      const nx = 248, ny = 150; E('path', { d: B.ellD(nx, ny, 40, 34), fill: B.vol(g, 'nucP'), stroke: '#3a2a7a', 'stroke-width': 2.6 }, P('enuc')); for (let i = 0; i < 16; i++) { const a = i / 16 * 2 * PI; E('circle', { cx: f1(nx + Math.cos(a) * 40), cy: f1(ny + Math.sin(a) * 34), r: 1.4, fill: '#fbf3ea' }, P('enuc')); }
      E('circle', { cx: nx + 8, cy: ny - 4, r: 10, fill: '#5a4a9a' }, P('enuc'));
      for (let k = 0; k < 4; k++) E('path', { d: `M${nx - 52 - k * 6} ${ny - 40 + k * 4}C${nx - 70} ${ny} ${nx - 66} ${ny + 30} ${nx - 46 - k * 3} ${ny + 46 + k * 4}`, stroke: '#8a7aa8', 'stroke-width': 3, fill: 'none', opacity: .7 }, P('er'));
      for (let k = 0; k < 18; k++) { const t = k / 18; E('circle', { cx: f1(nx - 62 - Math.sin(t * PI) * 6 + (k % 2) * 4), cy: f1(ny - 36 + t * 80), r: 1.3, fill: '#4a3a2a' }, P('er')); }
      for (let k = 0; k < 4; k++) E('path', { d: `M${300 - k * 2} ${210 + k * 7}q16 -6 32 0`, stroke: '#c8902a', 'stroke-width': 3.4, fill: 'none', 'stroke-linecap': 'round' }, P('golgi'));
      [[300, 74, 20], [196, 230, 60], [320, 150, 90]].forEach(([x, y, a]) => { const gg = E('g', { transform: `translate(${x} ${y}) rotate(${a})` }, P('emito')); E('path', { d: B.ellD(0, 0, 16, 7.6), fill: B.vol(g, 'mito'), stroke: '#9a5a30', 'stroke-width': .8 }, gg); E('path', { d: 'M-11 -5V2M-5 5V-2M1 -5V2M7 5V-2M12 -4V1', stroke: '#9a5a30', 'stroke-width': .7 }, gg); });
      for (let i = 0; i < 30; i++) { const x = 176 + B.rnd(i) * 170, y = 48 + B.rnd(i + 30) * 210; if (Math.hypot(x - nx, (y - ny) * 1.15) < 56) continue; E('circle', { cx: f1(x), cy: f1(y), r: 1.3, fill: '#4a3a2a' }, P('rib80')); }
      hits(this.parts, part, 12); },
    parts: [
      { id: 'nucleoid', bn: 'নিউক্লিয়য়েড', lb: 'নিউক্লিয়য়েড', en: 'Nucleoid', fn: 'আদিকোষে DNA (সাধারণত একটি বৃত্তাকার ক্রোমোজোম) সাইটোপ্লাজমের একটি অঞ্চলে থাকে — নিউক্লিয়ার আবরণ নেই।', a: [104, 124], l: [6, 124], an: 'start' },
      { id: 'pwall', bn: 'কোষপ্রাচীর (পেপটিডোগ্লাইকান) ও ফ্ল্যাজেলাম', lb: 'কোষপ্রাচীর', en: 'Cell wall', fn: 'ব্যাকটেরিয়ার কোষপ্রাচীরে পেপটিডোগ্লাইকান (মিউরিন)। ফ্ল্যাজেলাম গঠনে সরল, ঘুরে ঘুরে চলে।', a: [82, 80], l: [6, 40], an: 'start' },
      { id: 'plas', bn: 'প্লাজমিড', lb: 'প্লাজমিড', en: 'Plasmid', fn: 'প্রধান DNA ছাড়া ছোট বৃত্তাকার DNA — অনেক সময় অ্যান্টিবায়োটিক প্রতিরোধের জিন বহন করে।', a: [96, 158], l: [6, 200], an: 'start' },
      { id: 'rib70', bn: '70S রাইবোসোম', lb: '70S রাইবোসোম', en: '70S ribosome', fn: 'আদিকোষের রাইবোসোম ছোট (70S); কোনো ঝিল্লিবদ্ধ অঙ্গাণু (মাইটোকন্ড্রিয়া, ER, গলজি) নেই।', a: [112, 92], l: [144, 16], an: 'end' },
      { id: 'enuc', bn: 'নিউক্লিয়াস (দ্বিস্তরী আবরণ)', lb: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'প্রকৃতকোষে DNA নিউক্লিয়ার আবরণে ঘেরা, আবরণে ছিদ্র; একাধিক রৈখিক ক্রোমোজোম ও নিউক্লিওলাস।', a: [248, 120], l: [256, 22], an: 'middle' },
      { id: 'emito', bn: 'মাইটোকন্ড্রিয়া', lb: 'মাইটোকন্ড্রিয়া', en: 'Mitochondria', fn: 'দ্বিস্তরী ঝিল্লির অঙ্গাণু, শ্বসনে ATP তৈরি করে — শুধু প্রকৃতকোষে।', a: [312, 74], l: [352, 40], an: 'end' },
      { id: 'er', bn: 'এন্ডোপ্লাজমিক রেটিকুলাম', lb: 'ER (রাইবোসোমযুক্ত)', en: 'Endoplasmic reticulum', fn: 'ঝিল্লির জালিকা; অমসৃণ ER এর গায়ে রাইবোসোম — প্রোটিন তৈরি ও পরিবহন।', a: [184, 150], l: [160, 272], an: 'start' },
      { id: 'golgi', bn: 'গলজি বস্তু', lb: 'গলজি বস্তু', en: 'Golgi body', fn: 'চ্যাপ্টা থলির স্তূপ — প্রোটিন ও লিপিড প্রক্রিয়াকরণ ও প্যাকেজিং।', a: [316, 216], l: [352, 256], an: 'end' },
      { id: 'rib80', bn: '80S রাইবোসোম', lb: '80S রাইবোসোম', en: '80S ribosome', fn: 'প্রকৃতকোষের সাইটোপ্লাজমে বড় (80S) রাইবোসোম।', a: [330, 112], l: [352, 100], an: 'end' },
      { id: 'emem', bn: 'কোষঝিল্লি', lb: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'উভয় কোষেই আছে। প্রকৃতকোষে ঝিল্লিতে স্টেরল (যেমন কোলেস্টেরল) থাকে।', a: [350, 176], l: [352, 178], an: 'end' }
    ]
  }));

/* ═════════ তিন ডোমেইন ═════════ */
V.threeDomains = Object.assign({ t: 'কার্ল উসের তিন ডোমেইন (1990)', k: ['2d', 'int'], cap: '16S/18S রাইবোসোমাল RNA এর ক্রম তুলনা করে তৈরি জাতিজনি গাছ (সরলীকৃত)। আর্কিয়া দেখতে ব্যাকটেরিয়ার মতো আদিকোষী হলেও জিন ও প্রোটিন তৈরির যন্ত্রে প্রকৃতকোষীদের (ইউক্যারিয়া) বেশি কাছের।' }, B.seg({
  id: 'tdm', t: 'তিন ডোমেইন', H: 300, def: 'tr', types: { tr: ['গাছ', 'ব্যাকটেরিয়া, আর্কিয়া, ইউক্যারিয়া', 'গাছের মূলে সব জীবের শেষ সাধারণ পূর্বপুরুষ (LUCA)।'] },
  art(g, C) { const L = (pts, c, w = 3) => E('path', { d: sm(pts, false, .4), stroke: c, 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round' }, g);
    E('rect', { x: 0, y: 0, width: 360, height: 300, fill: FK.alpha('#f4f2ea', .6) }, g);
    L([[180, 270], [180, 236], [176, 210]], '#5a5a5a', 4); E('circle', { cx: 180, cy: 270, r: 6, fill: '#5a5a5a' }, g); B.tx(g, 196, 274, 'LUCA — সাধারণ পূর্বপুরুষ', { fs: 9, c: C.fg });
    L([[176, 210], [120, 170], [70, 110], [54, 60]], KC.eub, 4); L([[176, 210], [220, 176], [240, 150]], '#7a5a5a', 4); L([[240, 150], [236, 110], [218, 60]], KC.arc, 4); L([[240, 150], [286, 110], [312, 60]], '#2a5a7a', 4);
    [[[96, 140], [52, 120]], [[80, 120], [100, 76]], [[64, 90], [30, 70]]].forEach(([a, b]) => L([a, b], KC.eub, 1.6));
    [[[290, 106], [270, 70]], [[300, 90], [340, 80]], [[306, 76], [296, 46]]].forEach(([a, b]) => L([a, b], '#2a5a7a', 1.6));
    [[[234, 104], [252, 74]], [[226, 84], [200, 70]]].forEach(([a, b]) => L([a, b], KC.arc, 1.6));
    B.tx(g, 54, 36, 'ব্যাকটেরিয়া', { fs: 11, a: 'middle', w: 700, c: KC.eub }); B.tx(g, 54, 50, 'Bacteria', { fs: 8.6, a: 'middle', c: C.mu, st: 'font-style:italic' });
    B.tx(g, 214, 36, 'আর্কিয়া', { fs: 11, a: 'middle', w: 700, c: KC.arc }); B.tx(g, 214, 50, 'Archaea', { fs: 8.6, a: 'middle', c: C.mu, st: 'font-style:italic' });
    B.tx(g, 314, 36, 'ইউক্যারিয়া', { fs: 11, a: 'middle', w: 700, c: '#2a5a7a' }); B.tx(g, 314, 50, 'Eukarya', { fs: 8.6, a: 'middle', c: C.mu, st: 'font-style:italic' });
    B.bacterium(g, 62, 196, .45, { plas: false }); B.tx(g, 62, 222, 'E. coli, Nostoc', { fs: 8.4, a: 'middle', c: C.fg }); B.tx(g, 62, 236, 'আদিকোষী', { fs: 8.2, a: 'middle', c: C.mu });
    B.tx(g, 300, 196, 'প্রোটিস্টা, ছত্রাক,', { fs: 8.4, a: 'middle', c: C.fg }); B.tx(g, 300, 208, 'উদ্ভিদ, প্রাণী', { fs: 8.4, a: 'middle', c: C.fg }); B.tx(g, 300, 222, 'প্রকৃতকোষী', { fs: 8.2, a: 'middle', c: C.mu });
    B.tx(g, 268, 150, 'আর্কিয়া ও ইউক্যারিয়ার', { fs: 8.2, a: 'start', c: '#7a5a5a' }); B.tx(g, 268, 162, 'সাধারণ পূর্বপুরুষ', { fs: 8.2, a: 'start', c: '#7a5a5a' });
    B.tx(g, 196, 124, 'মিথেনোজেন,', { fs: 8.2, a: 'end', c: KC.arc }); B.tx(g, 196, 136, 'হ্যালোফাইল', { fs: 8.2, a: 'end', c: KC.arc }); }
}));

/* ═════════ ছয় রাজ্য ═════════ */
const SK = {
  six: ['ছয় রাজ্য', 'উস ও সহকর্মীদের ছয় রাজ্য (1977)', 'মনেরা রাজ্য ভেঙে আর্কিব্যাকটেরিয়া ও ইউব্যাকটেরিয়া — দুটি আলাদা রাজ্য; সাথে প্রোটিস্টা, ফানজাই, প্লান্টি ও অ্যানিমেলিয়া। পাঠ্যবইয়ে প্রচলিত "ষষ্ঠরাজ্য শ্রেণিবিন্যাস" এটিই। (টমাস ক্যাভালিয়ার-স্মিথ 1998 সালে ভিন্ন ছয় রাজ্য প্রস্তাব করেন: Bacteria, Protozoa, Chromista, Fungi, Plantae, Animalia।)'],
  arc: ['আর্কি বনাম ইউব্যাক্টি', 'আর্কিব্যাকটেরিয়া বনাম ইউব্যাকটেরিয়া', 'দুটিই আদিকোষী ও এককোষী, কিন্তু রাসায়নিক গঠনে ভিন্ন: আর্কিয়ার কোষপ্রাচীরে পেপটিডোগ্লাইকান নেই, ঝিল্লির লিপিড ইথার-বন্ধনযুক্ত; ইউব্যাকটেরিয়ার প্রাচীরে পেপটিডোগ্লাইকান, লিপিড এস্টার-বন্ধনযুক্ত।']
};
V.sixKingdom = Object.assign({}, B.seg({
  id: 'skg', t: 'ষষ্ঠরাজ্য শ্রেণিবিন্যাস', H: 300, def: 'six', types: SK,
  cap: 'ছয় রাজ্য পদ্ধতিতে আদিকোষীরা দুই রাজ্যে বিভক্ত। আর্কিয়া প্রায়ই চরম পরিবেশে থাকে — উষ্ণ প্রস্রবণ (থার্মোফাইল), অতি লবণাক্ত পানি (হ্যালোফাইল) — তবে ধানক্ষেতের কাদা ও গরুর পাকস্থলীর মিথেন তৈরিকারী মিথেনোজেনও আর্কিয়া।',
  art(g, C, ty) { E('rect', { x: 0, y: 0, width: 360, height: 252, fill: FK.alpha('#f4f2ea', .6) }, g);
    if (ty === 'six') { const ks = [['arc', 'আর্কি-ব্যাকটেরিয়া', 'Archaebacteria', ['মিথেনোজেন', 'হ্যালোফাইল', 'থার্মোফাইল']], ['eub', 'ইউ-ব্যাকটেরিয়া', 'Eubacteria', ['E. coli', 'Rhizobium', 'Nostoc']], ['pro', 'প্রোটিস্টা', 'Protista', ['অ্যামিবা', 'ইউগ্লিনা', 'শৈবাল']], ['fun', 'ফানজাই', 'Fungi', ['মাশরুম', 'ইস্ট', 'Penicillium']], ['pla', 'প্লান্টি', 'Plantae', ['মস', 'ফার্ন', 'আম']], ['ani', 'অ্যানিমেলিয়া', 'Animalia', ['হাইড্রা', 'মাছ', 'মানুষ']]];
      E('rect', { x: 6, y: 34, width: 114, height: 210, rx: 10, fill: 'none', stroke: FK.alpha('#8a6a2a', .7), 'stroke-dasharray': '4 3' }, g); B.tx(g, 63, 26, 'আদিকোষী', { fs: 9.6, a: 'middle', w: 700, c: '#8a6a2a' });
      E('rect', { x: 124, y: 34, width: 230, height: 210, rx: 10, fill: 'none', stroke: FK.alpha('#2a5a7a', .7), 'stroke-dasharray': '4 3' }, g); B.tx(g, 239, 26, 'প্রকৃতকোষী', { fs: 9.6, a: 'middle', w: 700, c: '#2a5a7a' });
      ks.forEach(([k, bn, la, ex], i) => { const x = 10 + i * 57 + (i >= 2 ? 6 : 0), c = KC[k]; E('rect', { x, y: 42, width: 52, height: 196, rx: 8, fill: FK.alpha(c, .1), stroke: c }, g);
        bn.split('-').forEach((p, j) => B.tx(g, x + 26, 60 + j * 12, p + (bn.includes('-') && j === 0 ? '-' : ''), { fs: 8.6, a: 'middle', w: 700, c }));
        B.tx(g, x + 26, 96, la.length > 11 ? la.slice(0, 6) + '-' : la, { fs: 7, a: 'middle', c: C.mu, st: 'font-style:italic' }); if (la.length > 11) B.tx(g, x + 26, 106, la.slice(6), { fs: 7, a: 'middle', c: C.mu, st: 'font-style:italic' });
        ex.forEach((e, j) => B.tx(g, x + 26, 140 + j * 18, e, { fs: 8, a: 'middle', c: C.fg, st: /^[A-Z]/.test(e) ? 'font-style:italic' : '' })); }); }
    if (ty === 'arc') { const rows = [['কোষপ্রাচীর', 'পেপটিডোগ্লাইকান নেই', 'পেপটিডোগ্লাইকান আছে'], ['ঝিল্লির লিপিড', 'ইথার-বন্ধন, শাখাযুক্ত', 'এস্টার-বন্ধন, সোজা শিকল'], ['RNA পলিমারেজ', 'জটিল (প্রকৃতকোষীর মতো)', 'সরল'], ['বাসস্থান', 'প্রায়ই চরম পরিবেশ', 'প্রায় সর্বত্র'], ['উদাহরণ', 'Methanobacterium, Halobacterium', 'E. coli, Rhizobium, Nostoc']];
      B.tx(g, 150, 30, 'আর্কিব্যাকটেরিয়া', { fs: 10.4, a: 'middle', w: 700, c: KC.arc }); B.tx(g, 278, 30, 'ইউব্যাকটেরিয়া', { fs: 10.4, a: 'middle', w: 700, c: KC.eub });
      rows.forEach(([h, a, b], r) => { const y = 54 + r * 38; E('rect', { x: 6, y: y - 14, width: 348, height: 34, rx: 6, fill: r % 2 ? 'none' : FK.alpha(C.fg, .05) }, g); B.tx(g, 12, y + 6, h, { fs: 9, w: 700, c: C.mu });
        [[a, 150], [b, 278]].forEach(([s, x]) => { const ws = s.split(', '); if (ws.length > 1 && s.length > 22) ws.forEach((w2, j) => B.tx(g, x, y + j * 12, w2 + (j < ws.length - 1 ? ',' : ''), { fs: 8.6, a: 'middle', c: C.fg, st: /^[A-Z]/.test(w2) ? 'font-style:italic' : '' })); else B.tx(g, x, y + 6, s, { fs: 8.8, a: 'middle', c: C.fg }); }); }); }
    B.tx(g, 180, 270, SK[ty][1], { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 290, ty === 'six' ? 'মনেরা ভেঙে দুই রাজ্য — মোট ছয়' : 'আদিকোষী হলেও রসায়নে ভিন্ন', { fs: 10, a: 'middle', c: C.mu }); }
}));
})();
