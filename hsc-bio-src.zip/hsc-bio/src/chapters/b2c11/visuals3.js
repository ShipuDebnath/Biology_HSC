/* ═══════════════════════════════════════════════════════════════════
   visuals3 — মেন্ডেলীয় অনুপাতের ব্যতিক্রম: lethalGene, complementGene, epistasis, polygenic
   সহায়ক: B.mouse (ইঁদুর, পার্শ্বদৃশ্য), B.seedling (চারা), B.squash (চ্যাপ্টা লাউজাতীয় ফল), B.grain (গমের দানা)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B211, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ─── ইঁদুর: col = { f: লোম, d: গাঢ়, e: চোখ } ─── */
const FUR = { yel: { f: '#e2b85a', d: '#a87a28', e: '#1a1a1a' }, agt: { f: '#8a7256', d: '#4e3e2c', e: '#1a1a1a', tick: '#c8a878' }, blk: { f: '#38322e', d: '#141210', e: '#000' }, alb: { f: '#f6f2ec', d: '#c8beb2', e: '#d04050' } };
B.mouse = (g, x, y, s = 1, k = 'agt', o = {}) => { x = +x; y = +y; const c = FUR[k], m = (dx, dy) => f1(x + dx * s) + ' ' + f1(y + dy * s);
  E('path', { d: `M${m(-24, 6)}C${m(-40, 10)} ${m(-52, 2)} ${m(-50, -10)}C${m(-49, -16)} ${m(-44, -14)} ${m(-46, -8)}`, stroke: '#d8a8a0', 'stroke-width': 1.6 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: `M${m(-26, 4)}C${m(-28, -12)} ${m(-10, -18)} ${m(8, -15)}C${m(18, -14)} ${m(24, -10)} ${m(30, -6)}C${m(36, -3)} ${m(40, 0)} ${m(42, 2)}C${m(38, 6)} ${m(30, 8)} ${m(22, 9)}C${m(10, 12)} ${m(-12, 13)} ${m(-22, 10)}Z`, fill: c.f, stroke: c.d, 'stroke-width': .9 }, g);
  if (c.tick) { let d = ''; for (let i = 0; i < 26; i++) { const dx = -20 + B.rnd(i) * 50, dy = -12 + B.rnd(i + 30) * 18; d += `M${m(dx, dy)}l${f1(2 * s)} ${f1(-1 * s)}`; } E('path', { d, stroke: c.tick, 'stroke-width': .7 * s }, g); }
  E('path', { d: `M${m(22, -10)}C${m(18, -24)} ${m(30, -26)} ${m(30, -14)}Z`, fill: c.f, stroke: c.d, 'stroke-width': .8 }, g); E('path', { d: `M${m(23, -12)}C${m(21, -20)} ${m(28, -22)} ${m(28, -14)}Z`, fill: '#e8b0b0', opacity: k === 'blk' ? .4 : .8 }, g);
  E('circle', { cx: f1(x + 33 * s), cy: f1(y - 4 * s), r: f1(1.8 * s), fill: c.e }, g); E('circle', { cx: f1(x + 42.5 * s), cy: f1(y + 2 * s), r: f1(1.2 * s), fill: '#d08080' }, g);
  E('path', { d: `M${m(40, 2)}l${f1(8 * s)} ${f1(-2 * s)}M${m(40, 3)}l${f1(8 * s)} ${f1(2 * s)}`, stroke: FK.alpha(c.d, .6), 'stroke-width': .5 }, g);
  E('path', { d: `M${m(-10, 12)}l${f1(-2 * s)} ${f1(5 * s)}M${m(16, 10)}l${f1(2 * s)} ${f1(5 * s)}`, stroke: '#d8a8a0', 'stroke-width': 2 * s, 'stroke-linecap': 'round' }, g); };
/* ─── চারা: tone = পাতার রং ─── */
B.seedling = (g, x, y, s = 1, col = '#5a9a3a', dk = '#2e5a1a') => { x = +x; y = +y; E('path', { d: B.ellD(x, y + 1, 14 * s, 3 * s, 0), fill: '#8a6a4a', opacity: .35 }, g); E('path', { d: `M${f1(x)} ${f1(y)}Q${f1(x - 2 * s)} ${f1(y - 14 * s)} ${f1(x)} ${f1(y - 26 * s)}`, stroke: dk, 'stroke-width': 1.6 * s, fill: 'none' }, g);
  [-1, 1].forEach(sd => E('path', { d: `M${f1(x)} ${f1(y - 26 * s)}C${f1(x + sd * 6 * s)} ${f1(y - 36 * s)} ${f1(x + sd * 18 * s)} ${f1(y - 34 * s)} ${f1(x + sd * 20 * s)} ${f1(y - 28 * s)}C${f1(x + sd * 14 * s)} ${f1(y - 22 * s)} ${f1(x + sd * 6 * s)} ${f1(y - 22 * s)} ${f1(x)} ${f1(y - 26 * s)}Z`, fill: col, stroke: dk, 'stroke-width': .7 }, g)); };
/* ─── চ্যাপ্টা স্কোয়াশ (খাঁজকাটা চাকতি, পাশ থেকে) ─── */
const SQ = { W: ['#f6f2e2', '#cfc6a6'], Y: ['#f2cc40', '#a8821a'], G: ['#7aa84a', '#3e6a1e'] };
B.squash = (g, x, y, r, k) => { x = +x; y = +y; const [c, d] = SQ[k], P = []; for (let i = 0; i < 48; i++) { const a = i / 48 * 2 * PI, rr = r * (1 + .07 * Math.cos(a * 10)); P.push([x + Math.cos(a) * rr, y + Math.sin(a) * rr * .5]); }
  E('path', { d: sm(P, true, .5), fill: c, stroke: d, 'stroke-width': .9 }, g); let rib = ''; for (let i = 0; i < 10; i++) { const a = (i + .5) / 10 * PI; rib += `M${f1(x + Math.cos(a) * r * .15)} ${f1(y - r * .12)}Q${f1(x + Math.cos(a) * r * .9)} ${f1(y + Math.sin(a) * r * .1)} ${f1(x + Math.cos(a) * r * .95)} ${f1(y + Math.sin(a) * r * .45)}`; } E('path', { d: rib, stroke: FK.alpha(d, .45), 'stroke-width': .8, fill: 'none' }, g);
  E('path', { d: `M${f1(x)} ${f1(y - r * .45)}v${f1(-r * .25)}`, stroke: '#6a8a3a', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); };
/* ─── গমের দানা: n = প্রকট অ্যালিলের সংখ্যা, N = মোট সর্বোচ্চ ─── */
const grainCol = (n, N) => { const t = n / N; const a = [244, 232, 200], b = [150, 54, 24]; return `rgb(${a.map((v, i) => Math.round(lerp(v, b[i], t))).join(',')})`; };
B.grain = (g, x, y, r, n, N, a = 0) => { x = +x; y = +y; const c = grainCol(n, N); E('path', { d: B.ellD(x, y, r, r * .62, a), fill: c, stroke: FK.alpha('#5a3a1a', .6), 'stroke-width': .7 }, g); const ra = a * PI / 180; E('path', { d: `M${f1(x - Math.cos(ra) * r * .7)} ${f1(y - Math.sin(ra) * r * .7)}L${f1(x + Math.cos(ra) * r * .7)} ${f1(y + Math.sin(ra) * r * .7)}`, stroke: FK.alpha('#5a3a1a', .35), 'stroke-width': .8 }, g); };

/* ═════════ লিথাল জিন ═════════ */
const LG = {
  mouse: ['হলুদ ইঁদুর (প্রকট লিথাল)', 'হলুদ ইঁদুর: 2 : 1 অনুপাত', 'ফরাসি বিজ্ঞানী কুয়েনো (1905) দেখেন, দুটি হলুদ ইঁদুরের সন্তান সবসময় 2 হলুদ : 1 অ্যাগুটি (ধূসর-বাদামি) — কখনো খাঁটি হলুদ নয়। কারণ হলুদ অ্যালিল A<sup>Y</sup> লোমের রঙে প্রকট, কিন্তু জীবনধারণে প্রচ্ছন্ন লিথাল: A<sup>Y</sup>A<sup>Y</sup> ভ্রূণ জরায়ুতেই মারা যায়। তাই 1 : 2 : 1 এর বদলে জীবিত সন্তানে 2 : 1।', 0],
  plant: ['স্ন্যাপড্রাগন (প্রচ্ছন্ন লিথাল)', 'স্ন্যাপড্রাগনের সোনালি পাতা: 1 : 2 অনুপাত', 'বাউর (1907) দেখেন, স্ন্যাপড্রাগনের সোনালি-হলুদ পাতার (অরিয়া) দুটি গাছের সন্তান 1 সবুজ : 2 সোনালি : 1 সাদা; সাদা চারায় ক্লোরোফিল নেই বলে খাদ্য তৈরি করতে না পেরে কয়েক দিনের মধ্যে মারা যায়। জীবিত অনুপাত 1 সবুজ (GG) : 2 সোনালি (Gg)। লিথাল অ্যালিল g সমযুগ্মী অবস্থায় (gg) মৃত্যু ঘটায় — প্রচ্ছন্ন লিথাল।', 1],
  human: ['মানুষে উদাহরণ', 'মানুষে লিথাল ও অর্ধলিথাল জিন', 'মানুষে কিছু জিন সমযুগ্মী অবস্থায় মৃত্যু বা গুরুতর রোগ ঘটায়: থ্যালাসেমিয়া মেজর (চিকিৎসা ছাড়া শৈশবে মৃত্যু), সিকেল সেল রোগ, টে-স্যাক্স রোগ (শিশুকালে মৃত্যু)। প্রকট লিথালের উদাহরণ হান্টিংটন রোগ — দেরিতে (প্রায় 30–50 বছরে) প্রকাশ পায় বলে বংশে টিকে থাকে। যে জিন মৃত্যু না ঘটিয়ে আয়ু বা প্রজননক্ষমতা কমায় তাকে অর্ধলিথাল বলে।', 2]
};
V.lethalGene = Object.assign({}, B.seg({
  id: 'lth', t: 'লিথাল জিন', H: 280, def: 'mouse', types: Object.fromEntries(Object.entries(LG).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'যে জিন সমযুগ্মী (কখনো অসমযুগ্মী) অবস্থায় জীবের মৃত্যু ঘটায়, তাকে লিথাল বা মারণ জিন বলে। এতে একসংকরের 3 : 1 অনুপাত বদলে 2 : 1 (বা 1 : 2) হয়ে যায়, কারণ একটি জিনোটাইপ শ্রেণি জীবিত থাকে না।',
  art(g, C, ty) { B.cacheG(g, 'lth' + LG[ty][3], gg => {
    if (ty === 'mouse') { B.mouse(gg, 72, 54, .9, 'yel'); B.mouse(gg, 278, 54, .9, 'yel'); B.tx(gg, 175, 60, '×', { fs: 20, a: 'middle' }); B.gt(gg, 72, 86, 'A<tspan baseline-shift="super" font-size="70%">Y</tspan>A', { a: 'middle' }); B.gt(gg, 278, 86, 'A<tspan baseline-shift="super" font-size="70%">Y</tspan>A', { a: 'middle' });
      const G = ['A<tspan baseline-shift="super" font-size="70%">Y</tspan>', 'A'], K = [['dead', 'yel'], ['yel', 'agt']];
      B.punnett(gg, C, 120, 118, 80, 62, G, G, (q, x, y, w, h, i, j) => { const k = K[i][j]; if (k === 'dead') { E('path', { d: B.ellD(x + w / 2, y + 26, 18, 13, 0), fill: '#e8e2da', stroke: '#9a8a7a', 'stroke-width': .9, 'stroke-dasharray': '3 2' }, q); E('path', { d: `M${x + w / 2 - 8} ${y + 26}q8 -10 16 0`, stroke: '#9a8a7a', 'stroke-width': .8, fill: 'none' }, q); B.tx(q, x + w / 2, y + 54, 'ভ্রূণেই মৃত', { fs: 9, a: 'middle', w: 700, c: '#a8201a' }); } else { B.mouse(q, x + w / 2 - 6, y + 28, .62, k); B.tx(q, x + w / 2, y + 56, k === 'yel' ? 'হলুদ' : 'অ্যাগুটি', { fs: 9, a: 'middle', c: C.fg }); } }, { gfs: 8.6, fill: (i, j) => i + j === 0 ? '#f4eeee' : '#fbf8ef' });
      B.tx(gg, 180, 266, 'জীবিত সন্তান: 2 হলুদ (A<tspan baseline-shift="super" font-size="70%">Y</tspan>A) : 1 অ্যাগুটি (AA)', { fs: 10.6, a: 'middle', w: 700, c: C.fg }); }
    if (ty === 'plant') { [['#c8c440', '#7a7a1a'], ['#c8c440', '#7a7a1a']].forEach(([c, d], i) => B.seedling(gg, i ? 278 : 72, 84, 1.3, c, d)); B.tx(gg, 175, 64, '×', { fs: 20, a: 'middle' }); B.gt(gg, 72, 102, 'Gg (সোনালি)', { a: 'middle', fs: 11 }); B.gt(gg, 278, 102, 'Gg (সোনালি)', { a: 'middle', fs: 11 });
      const SC = { GG: ['#4a9a3a', '#24601a', 'সবুজ'], Gg: ['#c8c440', '#7a7a1a', 'সোনালি'], gg: ['#f4f2ea', '#b8b0a0', 'সাদা — মৃত'] };
      B.punnett(gg, C, 120, 130, 80, 58, ['G', 'g'], ['G', 'g'], (q, x, y, w, h, i, j) => { const gt = B.ord('Gg'[i] + 'Gg'[j]), [c, d, n] = SC[gt]; const qq = gt === 'gg' ? E('g', { opacity: .7 }, q) : q; B.seedling(qq, x + w / 2, y + 40, .9, c, d); if (gt === 'gg') E('path', { d: `M${x + w / 2 + 10} ${y + 10}q4 14 -2 30`, stroke: '#b8b0a0', 'stroke-width': .8, fill: 'none', 'stroke-dasharray': '2 2' }, q); B.tx(q, x + w / 2, y + 54, n, { fs: 8.8, a: 'middle', w: 700, c: gt === 'gg' ? '#a8201a' : C.fg }); });
      B.tx(gg, 180, 266, 'জীবিত: 1 সবুজ (GG) : 2 সোনালি (Gg) — 1 : 2', { fs: 10.6, a: 'middle', w: 700, c: C.fg }); }
    if (ty === 'human') { const R = [['থ্যালাসেমিয়া মেজর', 'প্রচ্ছন্ন, অর্ধলিথাল', 'হিমোগ্লোবিনের গ্লোবিন শৃঙ্খল কম — নিয়মিত রক্ত না দিলে শৈশবে মৃত্যু'], ['সিকেল সেল রোগ', 'প্রচ্ছন্ন, অর্ধলিথাল', 'HbS — কাস্তে আকৃতির লোহিত কণিকা'], ['টে-স্যাক্স রোগ', 'প্রচ্ছন্ন লিথাল', 'স্নায়ুকোষে লিপিড জমে শিশুকালে মৃত্যু'], ['হান্টিংটন রোগ', 'প্রকট, দেরিতে প্রকাশ', 'প্রজননের পরে লক্ষণ — তাই বংশে থেকে যায়']];
      R.forEach(([a, b, c], i) => { const y = 26 + i * 62; E('rect', { x: 8, y, width: 344, height: 54, rx: 8, fill: i % 2 ? '#fbf8f0' : '#f6f2ea', stroke: FK.alpha(C.fg, .12) }, gg); B.tx(gg, 18, y + 20, a, { fs: 11.6, w: 700, c: '#7a2a3a' }); B.tx(gg, 342, y + 20, b, { fs: 9.8, a: 'end', c: '#2a5a90', w: 700 }); B.tx(gg, 18, y + 40, c, { fs: 9.8, c: C.fg }); }); } }); },
  anim(g, C, ty, t) { if (ty === 'human') return; const k = .5 + .5 * Math.sin(t * 2.4); const [x, y, w, h] = ty === 'mouse' ? [120, 118, 80, 62] : [200, 188, 80, 58]; E('rect', { x, y, width: w, height: h, fill: 'none', stroke: '#c0392b', 'stroke-width': 2, opacity: f1(.25 + k * .6) }, g); }
}));

/* ─── 4 × 4 দ্বিসংকর বর্গের সাধারণ রূপ: ফিনোটাইপ ফাংশন phen(gt) → শ্রেণি ─── */
const G4 = (a, b) => ['AB', 'Ab', 'aB', 'ab'];
const gtOf = (x, y, L) => B.ord(x[0] + y[0]) + B.ord(x[1] + y[1]);
const grid16 = (gg, C, L, x0, y0, cw, ch, cls, draw, fill) => { const GA = [L[0] + L[1], L[0] + L[1].toLowerCase(), L[0].toLowerCase() + L[1], L[0].toLowerCase() + L[1].toLowerCase()];
  B.punnett(gg, C, x0, y0, cw, ch, GA, GA, (q, x, y, w, h, i, j) => { const gt = gtOf(GA[i], GA[j]), k = cls(gt); draw(q, x, y, w, h, k, gt); B.gt(q, x + w / 2, y + h - 4, gt, { a: 'middle', fs: 8, c: C.mu }); }, { gfs: 8.6, fill: (i, j) => fill(cls(gtOf(GA[i], GA[j]))) }); };

/* ═════════ পরিপূরক জিন ═════════ */
const cpC = gt => /C/.test(gt) && /P/.test(gt) ? 'pur' : 'wht';
const CPG = {
  cross: ['P ও F1', 'দুই সাদা থেকে বেগুনি', 'বেটসন ও পানেট (1906) মিষ্টি মটরের (Lathyrus odoratus) দুটি ভিন্ন সাদা ফুলের জাত (CCpp ও ccPP) ক্রস করে অবাক হন — F<sub>1</sub> এর সব ফুল বেগুনি (CcPp)! প্রতিটি সাদা জাতে রঞ্জক তৈরির পথের একটি ধাপ অচল, কিন্তু দুটি ভিন্ন ধাপ; F<sub>1</sub> এ দুই জাতের সচল অ্যালিল একসাথে এসে পুরো পথ সম্পূর্ণ করে।'],
  f2: ['F2: 9 : 7', 'F2: 9 বেগুনি : 7 সাদা', 'F<sub>2</sub> তে যেসব গাছে অন্তত একটি C ও অন্তত একটি P আছে (C_P_, 9/16) সেগুলো বেগুনি; বাকি C_pp (3), ccP_ (3) ও ccpp (1) — মোট 7/16 সাদা। দুটি প্রকট জিন একে অপরের পরিপূরক — একা কেউ বৈশিষ্ট্য প্রকাশ করতে পারে না।'],
  path: ['জৈব-রাসায়নিক পথ', 'কেন দুটি জিনই লাগে', 'রঞ্জক অ্যান্থোসায়ানিন তৈরি হয় দুই ধাপে: বর্ণহীন পূর্বসূরি → (জিন C এর এনজাইম) → বর্ণহীন মধ্যবর্তী → (জিন P এর এনজাইম) → বেগুনি রঞ্জক। cc হলে প্রথম ধাপ, pp হলে দ্বিতীয় ধাপ বন্ধ — যেকোনো একটি বন্ধ হলেই ফুল সাদা।']
};
V.complementGene = Object.assign({}, B.seg({
  id: 'cpg', t: 'পরিপূরক জিন: মিষ্টি মটর', H: 290, def: 'f2', types: CPG,
  cap: 'দুটি ভিন্ন লোকাসের প্রকট জিন যখন একসাথে থাকলেই কেবল একটি বৈশিষ্ট্য প্রকাশ পায়, তাদের পরিপূরক জিন বলে — দ্বিসংকরের 9 : 3 : 3 : 1 বদলে 9 : 7। এটি জিনের মিথস্ক্রিয়ার একটি উদাহরণ।',
  art(g, C, ty) { B.cacheG(g, 'cpg' + Object.keys(CPG).indexOf(ty), gg => {
    if (ty === 'cross') { B.peaFlower(gg, 70, 84, 1.5, 'wflw'); B.peaFlower(gg, 282, 84, 1.5, 'wflw'); B.tx(gg, 178, 76, '×', { fs: 20, a: 'middle' }); B.gt(gg, 74, 122, 'CCpp', { a: 'middle' }); B.gt(gg, 286, 122, 'ccPP', { a: 'middle' }); B.tx(gg, 74, 138, 'সাদা জাত ১', { fs: 10, a: 'middle', c: C.mu }); B.tx(gg, 286, 138, 'সাদা জাত ২', { fs: 10, a: 'middle', c: C.mu }); E('path', { d: 'M96 150L160 186M262 150L198 186', stroke: FK.alpha(C.fg, .4), 'stroke-width': 1.2, 'marker-end': B.mk(gg, FK.alpha(C.fg, .5), 6) }, gg); B.peaFlower(gg, 176, 232, 1.5, 'pflw'); B.gt(gg, 180, 270, 'F<tspan baseline-shift="sub" font-size="75%">1</tspan>: CcPp — সব বেগুনি', { a: 'middle', c: '#5a2a7a' }); }
    if (ty === 'f2') { grid16(gg, C, 'CP', 70, 34, 68, 50, cpC, (q, x, y, w, h, k) => B.peaFlower(q, x + w / 2 - 2, y + 26, .72, k === 'pur' ? 'pflw' : 'wflw'), k => k === 'pur' ? '#f4eef8' : '#fbfbf8'); B.tx(gg, 180, 282, '9 বেগুনি (C_P_) : 7 সাদা (C_pp, ccP_, ccpp)', { fs: 10.8, a: 'middle', w: 700, c: C.fg }); }
    if (ty === 'path') { const box = (x, t, c, f) => { E('rect', { x: x - 48, y: 96, width: 96, height: 46, rx: 9, fill: f, stroke: c, 'stroke-width': 1 }, gg); B.tx(gg, x, 116, t[0], { fs: 10.6, a: 'middle', w: 700, c: C.fg }); B.tx(gg, x, 132, t[1], { fs: 9.4, a: 'middle', c: C.mu }); }; box(62, ['পূর্বসূরি', 'বর্ণহীন'], '#b8b0a0', '#fbfaf6'); box(180, ['মধ্যবর্তী', 'বর্ণহীন'], '#b8b0a0', '#fbfaf6'); box(298, ['অ্যান্থোসায়ানিন', 'বেগুনি'], '#7a3aa8', '#efe2f6');
      [[110, 132, 'C', 'এনজাইম ১'], [228, 250, 'P', 'এনজাইম ২']].forEach(([a, b, k, n]) => { E('path', { d: `M${a} 119H${b}`, stroke: '#3a7a4a', 'stroke-width': 2, 'marker-end': B.mk(gg, '#3a7a4a', 7) }, gg); B.gt(gg, (a + b) / 2, 88, k, { a: 'middle', fs: 13, c: '#2e6a3e' }); B.tx(gg, (a + b) / 2, 160, n, { fs: 9.4, a: 'middle', c: '#2e6a3e' }); });
      [['ccP_', 'প্রথম ধাপ বন্ধ → সাদা', 196], ['C_pp', 'দ্বিতীয় ধাপ বন্ধ → সাদা', 220], ['C_P_', 'দুই ধাপই চালু → বেগুনি', 244]].forEach(([a, b, y], i) => { B.gt(gg, 60, y, a, { a: 'middle', fs: 11 }); B.tx(gg, 96, y, b, { fs: 10.4, c: i === 2 ? '#5a2a7a' : C.fg, w: i === 2 ? 700 : 400 }); }); } }); },
  anim(g, C, ty, t) { if (ty === 'path') { const u = (t * .35) % 1, x = u < .5 ? lerp(110, 132, u * 2) : lerp(228, 250, (u - .5) * 2); E('circle', { cx: f1(x), cy: 119, r: 4, fill: u < .5 ? '#b8b0a0' : '#9a5ab8' }, g); } else if (ty === 'f2') { const k = .5 + .5 * Math.sin(t * 2); E('rect', { x: 70, y: 34, width: 272, height: 200, fill: 'none', stroke: '#9a5ab8', 'stroke-width': 1.4, opacity: f1(.2 + k * .5) }, g); } }
}));

/* ═════════ এপিস্ট্যাসিস ═════════ */
const sqC = gt => /W/.test(gt) ? 'W' : /Y/.test(gt) ? 'Y' : 'G';
const msC = gt => !/C/.test(gt) ? 'alb' : /A/.test(gt) ? 'agt' : 'blk';
const EP = {
  dom: ['প্রকট (12 : 3 : 1)', 'প্রকট এপিস্ট্যাসিস: স্কোয়াশের ফলের রং', 'গ্রীষ্মকালীন স্কোয়াশে W অ্যালিল (যেকোনো মাত্রায়) রঞ্জক তৈরি থামিয়ে ফল সাদা করে, ফলে অন্য লোকাসের Y (হলুদ) বা y (সবুজ) প্রকাশ পায় না। W হলো এপিস্ট্যাটিক (দমনকারী), Y/y হাইপোস্ট্যাটিক (দমিত)। F<sub>2</sub>: 12 সাদা (W_ _ _) : 3 হলুদ (wwY_) : 1 সবুজ (wwyy)। কুকুরের লোমের রঙেও একই অনুপাত দেখা যায়।'],
  rec: ['প্রচ্ছন্ন (9 : 3 : 4)', 'প্রচ্ছন্ন এপিস্ট্যাসিস: ইঁদুরের লোমের রং', 'ইঁদুরে C অ্যালিল রঞ্জক (মেলানিন) তৈরির জন্য দরকার; cc হলে কোনো রঞ্জক নেই — অ্যালবিনো (সাদা লোম, লাল চোখ), অন্য লোকাসের A (অ্যাগুটি) বা a (কালো) যাই থাকুক। প্রচ্ছন্ন সমযুগ্মী cc এপিস্ট্যাটিক। F<sub>2</sub>: 9 অ্যাগুটি (C_A_) : 3 কালো (C_aa) : 4 অ্যালবিনো (cc_ _)। পেঁয়াজের খোসার রঙেও এমন হয়।']
};
V.epistasis = Object.assign({}, B.seg({
  id: 'eps', t: 'এপিস্ট্যাসিস: এক জিন আরেক জিনকে ঢেকে দেয়', H: 296, def: 'rec', types: EP,
  cap: 'একটি লোকাসের জিন যখন ভিন্ন লোকাসের আরেকটি জিনের প্রকাশ দমন করে, তাকে এপিস্ট্যাসিস বলে (বেটসন, 1909)। প্রকটতা ঘটে একই লোকাসের দুই অ্যালিলের মধ্যে, আর এপিস্ট্যাসিস ঘটে ভিন্ন লোকাসের জিনের মধ্যে। দুটি ক্ষেত্রেই মোট 16 অংশ থাকে, শুধু শ্রেণিগুলো একত্রিত হয়।',
  art(g, C, ty) { B.cacheG(g, 'eps' + (ty === 'dom' ? 0 : 1), gg => {
    if (ty === 'dom') { grid16(gg, C, 'WY', 70, 34, 68, 50, sqC, (q, x, y, w, h, k) => B.squash(q, x + w / 2, y + 22, 17, k), k => ({ W: '#fbfbf6', Y: '#fdf6dc', G: '#eef6e4' })[k]); B.tx(gg, 180, 254, '12 সাদা : 3 হলুদ : 1 সবুজ', { fs: 12, a: 'middle', w: 700, c: C.fg }); [['W', 'সাদা (W_ _ _)'], ['Y', 'হলুদ (wwY_)'], ['G', 'সবুজ (wwyy)']].forEach(([k, n], i) => { B.squash(gg, 40 + i * 116, 278, 10, k); B.gt(gg, 56 + i * 116, 282, n, { fs: 9.6, w: 400 }); }); }
    else { grid16(gg, C, 'CA', 70, 34, 68, 50, msC, (q, x, y, w, h, k) => B.mouse(q, x + w / 2 - 6, y + 22, .46, k), k => ({ agt: '#f6f2ea', blk: '#ecebea', alb: '#fdf8f8' })[k]); B.tx(gg, 180, 254, '9 অ্যাগুটি : 3 কালো : 4 অ্যালবিনো', { fs: 12, a: 'middle', w: 700, c: C.fg }); [['agt', 'অ্যাগুটি (C_A_)'], ['blk', 'কালো (C_aa)'], ['alb', 'অ্যালবিনো (cc_ _)']].forEach(([k, n], i) => { B.mouse(gg, 32 + i * 116, 280, .3, k); B.gt(gg, 52 + i * 116, 284, n, { fs: 9.6, w: 400 }); }); } }); },
  anim(g, C, ty, t) { const fn = ty === 'dom' ? sqC : msC, key = ty === 'dom' ? 'WY' : 'CA', tgt = ty === 'dom' ? 'W' : 'alb', GA = [key, key[0] + key[1].toLowerCase(), key[0].toLowerCase() + key[1], key.toLowerCase()], cells = []; for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) if (fn(gtOf(GA[i], GA[j])) === tgt) cells.push([i, j]); const [i, j] = cells[Math.floor(t * 2) % cells.length]; E('rect', { x: 70 + j * 68, y: 34 + i * 50, width: 68, height: 50, fill: 'none', stroke: '#c0392b', 'stroke-width': 2.2 }, g); }
}));

/* ═════════ পলিজেনিক বংশগতি ═════════ */
const binom = n => { const r = [1]; for (let i = 0; i < n; i++) { for (let j = r.length; j > 0; j--) r[j] = (r[j] || 0) + r[j - 1]; } return r; };
const PG = {
  g1: ['1 জোড়া', '1 জোড়া জিন: 1 : 2 : 1', 'একটি জোড়া (R<sub>1</sub>r<sub>1</sub> এর মতো) হলে F<sub>2</sub> তে 3টি শ্রেণি — গাঢ় লাল, মাঝারি, সাদা — 1 : 2 : 1 (প্রতিটি প্রকট অ্যালিল সমান পরিমাণ রং যোগ করে, তাই অসমযুগ্মী মাঝামাঝি)।', 1],
  g2: ['2 জোড়া', '2 জোড়া জিন: 1 : 4 : 6 : 4 : 1', 'নিলসন-এহলে (1909) গমের লাল ও সাদা দানার জাত ক্রস করে F<sub>2</sub> তে 15 লাল (বিভিন্ন গাঢ়ত্বের) : 1 সাদা পান। লাল রঙের মাত্রা ধরলে 5টি শ্রেণি: 4, 3, 2, 1 ও 0টি প্রকট অ্যালিল — অনুপাত 1 : 4 : 6 : 4 : 1 (মোট 16)।', 2],
  g3: ['3 জোড়া', '3 জোড়া জিন: 1 : 6 : 15 : 20 : 15 : 6 : 1', 'তিন জোড়ায় 7টি শ্রেণি, মোট 64 — অনুপাত 1 : 6 : 15 : 20 : 15 : 6 : 1। চরম শ্রেণি (সবচেয়ে গাঢ় বা সাদা) প্রতি 64 এ মাত্র 1টি। জোড়ার সংখ্যা n হলে শ্রেণির সংখ্যা 2n + 1 এবং চরম রূপের অনুপাত (1/4)<sup>n</sup>।', 3],
  many: ['অনেক জোড়া + পরিবেশ', 'অবিচ্ছিন্ন প্রকরণ: বেল আকৃতির বণ্টন', 'অনেক জোড়া জিন এবং পরিবেশের প্রভাব (পুষ্টি, আলো, রোদ) একসাথে কাজ করলে শ্রেণিগুলো আলাদা করে চেনা যায় না — বণ্টন মসৃণ বেল আকৃতির (স্বাভাবিক বণ্টন)। মানুষের উচ্চতা, ত্বকের রং, বুদ্ধিমত্তা, রক্তচাপ এভাবে নিয়ন্ত্রিত — এদের পরিমাণগত বৈশিষ্ট্য বলে।', 8]
};
V.polygenic = Object.assign({}, B.seg({
  id: 'plg', t: 'পলিজেনিক বংশগতি: গমের দানার রং', H: 270, def: 'g2', types: Object.fromEntries(Object.entries(PG).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'একাধিক জোড়া জিন একই বৈশিষ্ট্যের ওপর যোগাত্মক প্রভাব ফেললে তাকে পলিজেনিক বা বহুজিনীয় বংশগতি বলে — প্রতিটি প্রকট অ্যালিল সমান পরিমাণ প্রভাব যোগ করে। জোড়া যত বাড়ে, শ্রেণি তত বাড়ে এবং বণ্টন তত মসৃণ বেল আকৃতির হয় (অবিচ্ছিন্ন প্রকরণ)।',
  art(g, C, ty) { const n = PG[ty][3], ki = Object.keys(PG).indexOf(ty); B.cacheG(g, 'plg' + ki, gg => {
    const X0 = 40, X1 = 340, Y0 = 200, H = 150; E('path', { d: `M${X0} ${Y0}H${X1}M${X0} ${Y0}V${Y0 - H - 6}`, stroke: FK.alpha(C.fg, .55), 'stroke-width': 1.1, fill: 'none' }, gg); B.tx(gg, 12, 30, 'F<sub>2</sub> এর অংশ', { fs: 9.6, c: C.mu });
    if (n <= 3) { const b = binom(2 * n), tot = b.reduce((a, v) => a + v, 0), mx = Math.max(...b), w = (X1 - X0) / b.length; b.forEach((v, i) => { const k = 2 * n - i, h = v / mx * H, x = X0 + i * w; E('rect', { x: x + 3, y: Y0 - h, width: w - 6, height: h, fill: grainCol(k, 2 * n), stroke: FK.alpha('#5a3a1a', .5), 'stroke-width': .7 }, gg); B.tx(gg, x + w / 2, Y0 - h - 6, String(v), { fs: 11, a: 'middle', w: 700, c: C.fg }); B.grain(gg, x + w / 2, Y0 + 18, Math.min(11, w * .3), k, 2 * n, 70); B.tx(gg, x + w / 2, Y0 + 44, k + 'টি', { fs: 9, a: 'middle', c: C.mu }); });
      B.tx(gg, 180, 262, 'মোট ' + tot + '  ·  শ্রেণি ' + (2 * n + 1) + 'টি  ·  প্রকট অ্যালিলের সংখ্যা অনুযায়ী রং', { fs: 10, a: 'middle', w: 700, c: C.fg }); }
    else { const b = binom(16), mx = Math.max(...b), w = (X1 - X0) / b.length; b.forEach((v, i) => { const h = v / mx * H * .92; E('rect', { x: X0 + i * w + 1, y: Y0 - h, width: w - 2, height: h, fill: grainCol(16 - i, 16), opacity: .55 }, gg); }); let d = ''; for (let i = 0; i <= 80; i++) { const x = i / 80, z = (x - .5) / .13; d += (i ? 'L' : 'M') + f1(X0 + x * (X1 - X0)) + ' ' + f1(Y0 - Math.exp(-z * z / 2) * H); } E('path', { d, stroke: '#a8201a', 'stroke-width': 2, fill: 'none' }, gg); B.tx(gg, X0, Y0 + 18, 'গাঢ়', { fs: 9.6, c: C.mu }); B.tx(gg, X1, Y0 + 18, 'হালকা', { fs: 9.6, a: 'end', c: C.mu }); B.tx(gg, 180, Y0 + 18, 'গড়', { fs: 9.6, a: 'middle', c: C.mu }); B.tx(gg, 180, 250, 'জিন + পরিবেশ → মসৃণ বেল আকৃতির (স্বাভাবিক) বণ্টন', { fs: 10.6, a: 'middle', w: 700, c: '#a8201a' }); } }); },
  anim(g, C, ty, t) { const n = PG[ty][3]; if (n > 3) { const x = 180 + Math.sin(t) * 60; E('path', { d: `M${f1(x)} 50V200`, stroke: FK.alpha('#2a5a90', .5), 'stroke-dasharray': '3 3' }, g); return; } const L = 2 * n + 1, i = Math.floor(t * 1.5) % L, w = 300 / L; E('rect', { x: f1(40 + i * w + 1), y: 46, width: f1(w - 2), height: 200, rx: 4, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); }
}));
})();
