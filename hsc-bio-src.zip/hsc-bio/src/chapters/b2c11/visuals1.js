/* ═══════════════════════════════════════════════════════════════════
   visuals1 — মেন্ডেলের পরীক্ষা ও একসংকর ক্রস:
   mendelTraits, alleleLocus, monohybrid, punnettMono, testCross
   সহায়ক: B.peaSeed, B.peaFlower, B.peaPod, B.peaPlant, B.chrom, B.gam, B.punnett, B.gt
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B211, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ─── মটরবীজ: o = { wr: কুঞ্চিত, col: 'y' | 'g', a: কোণ } ─── */
B.peaSeed = (g, x, y, r, o = {}) => { x = +x; y = +y; const k = o.col === 'g' ? 'pgrn' : 'pyel', t = B.TS(k), a = o.a || 0;
  let d; if (o.wr) { const P = []; for (let i = 0; i < 22; i++) { const u = i / 22 * 2 * PI, rr = r * (.9 + .045 * Math.sin(u * 3 + a * 3) + .035 * Math.sin(u * 7 + 1) + .02 * Math.sin(u * 11 + a)); P.push([x + Math.cos(u + a) * rr, y + Math.sin(u + a) * rr * .9]); } d = sm(P, true, .45); }
  else d = B.ellD(x, y, r, r * .92, a * 57);
  E('path', { d, fill: B.vol(g, k), stroke: t.dk, 'stroke-width': .8 }, g);
  if (o.wr) { let w = ''; for (let i = 0; i < 6; i++) { const u = a + i * 1.05 + .4, r0 = r * (.15 + (i % 2) * .2), r1 = r * .8; w += `M${f1(x + Math.cos(u) * r0)} ${f1(y + Math.sin(u) * r0)}Q${f1(x + Math.cos(u + .35) * r * .5)} ${f1(y + Math.sin(u + .35) * r * .5)} ${f1(x + Math.cos(u + .1) * r1)} ${f1(y + Math.sin(u + .1) * r1)}`; } E('path', { d: w, stroke: FK.alpha(t.dk, .5), 'stroke-width': 1.1, fill: 'none', 'stroke-linecap': 'round' }, g); }
  /* নাভি (হাইলাম) */ E('path', { d: B.ellD(x + Math.cos(a + 2.2) * r * .62, y + Math.sin(a + 2.2) * r * .6, r * .2, r * .09, (a + 2.2) * 57 + 90), fill: '#6a5a3a', opacity: .75 }, g);
  E('path', { d: B.ellD(x - r * .32, y - r * .34, r * .26, r * .14, -30), fill: '#fff', opacity: .45 }, g); };

/* ─── মটরফুল (পার্শ্বদৃশ্য, প্যাপিলিওনেসিয়াস): পতাকা, দুই পক্ষ, নৌকা, বৃতি ─── */
B.peaFlower = (g, x, y, s = 1, tone = 'pflw', o = {}) => { x = +x; y = +y; const t = B.TS(tone), lf = B.TS('leaf'), m = (dx, dy) => f1(x + dx * s) + ' ' + f1(y + dy * s), fl = o.flip ? -1 : 1, M = (dx, dy) => m(dx * fl, dy);
  E('path', { d: `M${M(-24, 16)}Q${M(-16, 12)} ${M(-8, 6)}`, stroke: lf.c, 'stroke-width': 1.6 * s, fill: 'none' }, g);
  E('path', { d: `M${M(-4, -12)}C${M(-12, -34)} ${M(14, -40)} ${M(22, -22)}C${M(26, -12)} ${M(18, -2)} ${M(4, 0)}Z`, fill: t.lt, stroke: t.dk, 'stroke-width': .8 }, g);
  E('path', { d: `M${M(2, -6)}Q${M(6, -22)} ${M(14, -30)}M${M(2, -6)}Q${M(12, -18)} ${M(20, -20)}M${M(2, -6)}Q${M(2, -20)} ${M(2, -32)}`, stroke: FK.alpha(t.dk, .45), 'stroke-width': .6 * s, fill: 'none' }, g);
  E('path', { d: `M${M(-2, -2)}C${M(6, -12)} ${M(22, -10)} ${M(24, 0)}C${M(22, 8)} ${M(8, 8)} ${M(-2, 4)}Z`, fill: t.c, stroke: t.dk, 'stroke-width': .7, opacity: .95 }, g);
  E('path', { d: `M${M(0, 4)}C${M(8, 4)} ${M(20, 6)} ${M(26, 4)}C${M(22, 12)} ${M(8, 13)} ${M(0, 9)}Z`, fill: t.lt, stroke: t.dk, 'stroke-width': .7 }, g);
  E('path', { d: `M${M(-8, 3)}C${M(-8, -2)} ${M(-2, -4)} ${M(1, -1)}L${M(1, 7)}C${M(-3, 9)} ${M(-8, 8)} ${M(-8, 3)}Z`, fill: lf.c, stroke: lf.dk, 'stroke-width': .7 }, g);
  E('path', { d: `M${M(-6, -4)}l${f1(-3 * s * fl)} ${f1(-5 * s)}M${M(-1, -4)}l${f1(1 * s * fl)} ${f1(-6 * s)}`, stroke: lf.dk, 'stroke-width': .8 * s }, g); };

/* ─── শুঁটি: o = { con: সংকুচিত, col: 'g' | 'y', n: বীজসংখ্যা } ─── */
B.peaPod = (g, x, y, L, a = 0, o = {}) => { x = +x; y = +y; const k = o.col === 'y' ? 'ypod' : 'leaf', t = B.TS(k), n = o.n || 6, ca = Math.cos(a), sa = Math.sin(a), P = (u, v) => [x + ca * u - sa * v, y + sa * u + ca * v];
  const top = [], bot = []; for (let i = 0; i <= 40; i++) { const u = i / 40, base = Math.sin(u * PI) ** .7, wav = o.con ? .55 + .45 * Math.abs(Math.sin(u * n * PI)) : 1; top.push(P((u - .5) * L, -L * .16 * base * wav)); bot.push(P((u - .5) * L, L * .1 * base * (o.con ? .6 + .4 * Math.abs(Math.sin(u * n * PI)) : 1))); }
  const d = 'M' + top.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'L' + bot.reverse().map(p => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  E('path', { d, fill: B.vol(g, k), stroke: t.dk, 'stroke-width': .9 }, g);
  const sd = []; for (let i = 0; i <= 20; i++) sd.push(P((i / 20 - .5) * L * .94, -L * .03 * Math.sin(i / 20 * PI))); E('path', { d: 'M' + sd.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L'), stroke: FK.alpha(t.dk, .45), 'stroke-width': .7, fill: 'none' }, g);
  if (!o.con) for (let i = 0; i < n; i++) { const [px, py] = P(((i + .5) / n - .5) * L * .82, -L * .03); E('path', { d: B.ellD(px, py, L * .045, L * .04, 0), fill: 'none', stroke: FK.alpha(t.dk, .25), 'stroke-width': .7 }, g); }
  const [bx, by] = P(L * .5, 0), [ex, ey] = P(L * .58, -L * .04); E('path', { d: `M${f1(bx)} ${f1(by)}L${f1(ex)} ${f1(ey)}`, stroke: t.dk, 'stroke-width': 1.2 }, g);
  const [cx, cy] = P(-L * .5, 0), lf = B.TS('leaf'); E('path', { d: B.ellD(cx, cy, L * .05, L * .07, a * 57), fill: lf.c, stroke: lf.dk, 'stroke-width': .6 }, g); };

/* ─── পাতা (যৌগিক): জোড়া পত্রক + আকর্ষী ─── */
const leaflet = (g, x, y, a, L, k = 'leaf') => { const t = B.TS(k), ca = Math.cos(a), sa = Math.sin(a), P = (u, v) => f1(x + ca * u - sa * v) + ' ' + f1(y + sa * u + ca * v);
  E('path', { d: `M${P(0, 0)}C${P(L * .25, -L * .34)} ${P(L * .8, -L * .3)} ${P(L, 0)}C${P(L * .8, L * .3)} ${P(L * .25, L * .34)} ${P(0, 0)}Z`, fill: t.c, stroke: t.dk, 'stroke-width': .6 }, g);
  E('path', { d: `M${P(0, 0)}L${P(L * .9, 0)}`, stroke: t.dk, 'stroke-width': .5, opacity: .6 }, g); };
const tendril = (g, x, y, a, L) => { const t = B.TS('stem'); let d = `M${f1(x)} ${f1(y)}`; for (let i = 1; i <= 14; i++) { const u = i / 14, rr = L * (1 - u * .7), aa = a + u * 5.5; d += `L${f1(x + Math.cos(a) * L * u * .8 + Math.cos(aa) * rr * .18)} ${f1(y + Math.sin(a) * L * u * .8 + Math.sin(aa) * rr * .18)}`; } E('path', { d, stroke: t.c, 'stroke-width': .8, fill: 'none' }, g); };
/* ─── মটর গাছ: h = উচ্চতা (px); o = { term: শীর্ষস্থ ফুল, tone, nodes } ─── */
B.peaPlant = (g, x, y, h, o = {}) => { x = +x; y = +y; const n = o.nodes || Math.max(3, Math.round(h / 26)), st = B.TS('stem'), tone = o.tone || 'pflw';
  E('path', { d: B.ellD(x, y + 2, 20 * (o.ls || 1), 3.4 * (o.ls || 1), 0), fill: '#8a6a4a', opacity: .3 }, g);
  const P = []; for (let i = 0; i <= n; i++) P.push([x + (i % 2 ? 2 : -2) * (o.ls || 1) * (i ? 1 : 0), y - h * i / n]);
  const sw0 = Math.max(1.6, 2.6 * (o.ls || 1)); E('path', { d: 'M' + P.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L'), stroke: st.dk, 'stroke-width': sw0, fill: 'none', 'stroke-linejoin': 'round' }, g); E('path', { d: 'M' + P.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L'), stroke: st.c, 'stroke-width': sw0 * .55, fill: 'none', 'stroke-linejoin': 'round' }, g);
  for (let i = 1; i <= n; i++) { const [nx, ny] = P[i], sd = i % 2 ? 1 : -1, s = o.ls || 1;
    /* উপপত্র */ leaflet(g, nx, ny, PI / 2 + sd * .9, 9 * s, 'leaf'); leaflet(g, nx, ny, PI / 2 - sd * .9 + PI, 6 * s, 'leaf');
    if (i < n || o.term) { const rx = nx + sd * 13 * s, ry = ny - 6 * s; E('path', { d: `M${f1(nx)} ${f1(ny)}L${f1(rx)} ${f1(ry)}`, stroke: st.c, 'stroke-width': .9 }, g); leaflet(g, rx - sd * 6 * s, ry + 2, -PI / 2 + sd * .5, 9 * s); leaflet(g, rx - sd * 6 * s, ry + 2, PI / 2 + sd * .9, 9 * s); leaflet(g, rx, ry, -PI / 2 + sd * .6, 9 * s); leaflet(g, rx, ry, PI / 2 + sd * 1.1, 9 * s); tendril(g, rx, ry, -PI / 2 + sd * .8, 12 * s); }
    if (!o.term && i >= 2 && i <= n - 1 && (i % 2 === 0 || n < 5)) B.peaFlower(g, nx - sd * 8 * s, ny - 2, .34 * s * (o.fs || 1), tone, { flip: sd > 0 }); }
  if (o.term) { const [tx, ty] = P[n]; [[-10, -6, 1], [8, -8, 0], [-2, -16, 1], [12, 2, 0]].forEach(([dx, dy, fl]) => B.peaFlower(g, tx + dx * (o.ls || 1), ty + dy * (o.ls || 1), .34 * (o.ls || 1) * (o.fs || 1), tone, { flip: !!fl })); }
  else { const [tx, ty] = P[n]; tendril(g, tx, ty, -PI / 2, 14); } };

/* ─── ক্রোমোজোম (একক ক্রোমাটিড দণ্ড): o = { tone, cen: সেন্ট্রোমিয়ারের অবস্থান 0–1, bands } ─── */
B.chrom = (g, x, y, h, o = {}) => { x = +x; y = +y; const t = B.TS(o.tone || 'chrA'), w = o.w || 9, c = y + h * (o.cen != null ? o.cen : .38), r = w / 2;
  const d = `M${f1(x - r)} ${f1(y + r)}A${r} ${r} 0 0 1 ${f1(x + r)} ${f1(y + r)}L${f1(x + r)} ${f1(c - 3)}Q${f1(x + r * .45)} ${f1(c)} ${f1(x + r)} ${f1(c + 3)}L${f1(x + r)} ${f1(y + h - r)}A${r} ${r} 0 0 1 ${f1(x - r)} ${f1(y + h - r)}L${f1(x - r)} ${f1(c + 3)}Q${f1(x - r * .45)} ${f1(c)} ${f1(x - r)} ${f1(c - 3)}Z`;
  E('path', { d, fill: B.lin(g, o.tone || 'chrA', 0), stroke: t.dk, 'stroke-width': .9 }, g);
  let bd = ''; (o.bands || [.12, .22, .55, .7, .86]).forEach(b => { const yy = y + h * b; bd += `M${f1(x - r + .6)} ${f1(yy)}h${f1(w - 1.2)}`; }); E('path', { d: bd, stroke: FK.alpha(t.dk, .45), 'stroke-width': 1.6 }, g);
  return { c, at: u => y + h * u }; };
/* ─── গ্যামেট বৃত্ত ─── */
B.gam = (g, x, y, r, txt, col = '#2a5a90', o = {}) => { E('circle', { cx: f1(x), cy: f1(y), r, fill: o.fill || FK.alpha(col, .1), stroke: col, 'stroke-width': 1.2 }, g); B.tx(g, x, y + 4.2, txt, { fs: o.fs || 12, a: 'middle', w: 700, c: col, st: 'font-style:italic' }); };
/* ─── জিনোটাইপ লেখা (ইটালিক) ─── */
B.gt = (g, x, y, s, o = {}) => B.tx(g, x, y, s, Object.assign({ fs: 12, w: 700, st: 'font-style:italic' }, o));
/* ─── পানেট বর্গ: rows/cols = গ্যামেট, cell(g, x, y, w, h, r, c) ─── */
B.punnett = (g, C, x, y, cw, ch, rows, cols, cell, o = {}) => { const R = rows.length, Cn = cols.length, hc = o.hc || '#2a5a90', hr = o.hr || '#a8304a';
  cols.forEach((c, j) => B.gam(g, x + cw * (j + .5), y - 16, Math.min(13, cw * .36), c, hc, { fs: o.gfs || 11 }));
  rows.forEach((r, i) => B.gam(g, x - 18, y + ch * (i + .5), Math.min(13, ch * .36), r, hr, { fs: o.gfs || 11 }));
  for (let i = 0; i < R; i++) for (let j = 0; j < Cn; j++) { const cx = x + j * cw, cy = y + i * ch; E('rect', { x: cx, y: cy, width: cw, height: ch, fill: o.fill ? o.fill(i, j) : '#fffdf6', stroke: FK.alpha(C.fg, .3), 'stroke-width': .8 }, g); cell(g, cx, cy, cw, ch, i, j); }
  E('rect', { x, y, width: cw * Cn, height: ch * R, fill: 'none', stroke: FK.alpha(C.fg, .6), 'stroke-width': 1.2 }, g); };
/* জিনোটাইপ সাজানো: প্রকট বড় হাতের অক্ষর আগে */
B.ord = s => s.split('').sort((a, b) => a.toLowerCase() === b.toLowerCase() ? (a < b ? -1 : 1) : a.toLowerCase() < b.toLowerCase() ? -1 : 1).join('');

/* ═════════ মেন্ডেলের সাতটি বৈশিষ্ট্য ═════════ */
const MT = {
  shape: ['বীজের আকৃতি', 'বীজের আকৃতি: গোল (R) বনাম কুঞ্চিত (r)', 'F<sub>2</sub> তে মেন্ডেল পান 5474টি গোল ও 1850টি কুঞ্চিত বীজ — অনুপাত 2.96 : 1। কুঞ্চিত বীজে স্টার্চ-শাখাকারী এনজাইমের (SBEI) জিন অকার্যকর — স্টার্চ কম, শর্করা বেশি; পানি টেনে বীজ ফুলে ওঠে, শুকালে কুঁচকে যায়।', ['গোল', 'কুঞ্চিত', 'R', 'r', 5474, 1850]],
  col: ['বীজপত্রের রং', 'বীজপত্রের রং: হলুদ (Y) বনাম সবুজ (y)', 'F<sub>2</sub> তে 6022টি হলুদ ও 2001টি সবুজ বীজ — অনুপাত 3.01 : 1। সবুজ বীজে পাকার সময় ক্লোরোফিল ভাঙার এনজাইমের (SGR) জিন অকার্যকর।', ['হলুদ', 'সবুজ', 'Y', 'y', 6022, 2001]],
  flw: ['ফুলের রং', 'ফুলের রং: বেগুনি (P) বনাম সাদা (p)', 'F<sub>2</sub> তে 705টি বেগুনি ও 224টি সাদা ফুলের গাছ — অনুপাত 3.15 : 1। মেন্ডেল আসলে বীজত্বকের রং (ধূসর বনাম সাদা) লিখেছিলেন, যা ফুলের রঙের সাথে একসাথে নির্ধারিত হয়; সাদা ফুলে অ্যান্থোসায়ানিন রঞ্জক তৈরির একটি নিয়ন্ত্রক জিন অকার্যকর।', ['বেগুনি', 'সাদা', 'P', 'p', 705, 224]],
  pod: ['শুঁটির আকৃতি', 'শুঁটির আকৃতি: স্ফীত (I) বনাম সংকুচিত (i)', 'F<sub>2</sub> তে 882টি স্ফীত ও 299টি সংকুচিত শুঁটির গাছ — অনুপাত 2.95 : 1। সংকুচিত শুঁটিতে বীজের মাঝে খোসা ভেতরে বসে যায়।', ['স্ফীত', 'সংকুচিত', 'I', 'i', 882, 299]],
  podc: ['শুঁটির রং', 'অপরিপক্ব শুঁটির রং: সবুজ (G) বনাম হলুদ (g)', 'F<sub>2</sub> তে 428টি সবুজ ও 152টি হলুদ শুঁটির গাছ — অনুপাত 2.82 : 1।', ['সবুজ', 'হলুদ', 'G', 'g', 428, 152]],
  pos: ['ফুলের অবস্থান', 'ফুলের অবস্থান: কাক্ষিক (A) বনাম শীর্ষস্থ (a)', 'F<sub>2</sub> তে 651টি কাক্ষিক ও 207টি শীর্ষস্থ ফুলের গাছ — অনুপাত 3.14 : 1। কাক্ষিক: কাণ্ড বরাবর পাতার কক্ষে ফুল; শীর্ষস্থ: কাণ্ডের মাথায় গুচ্ছাকারে।', ['কাক্ষিক', 'শীর্ষস্থ', 'A', 'a', 651, 207]],
  ht: ['কাণ্ডের দৈর্ঘ্য', 'কাণ্ডের দৈর্ঘ্য: লম্বা (T) বনাম খাটো (t)', 'F<sub>2</sub> তে 787টি লম্বা ও 277টি খাটো গাছ — অনুপাত 2.84 : 1। লম্বা গাছ প্রায় 1.8–2 মিটার, খাটো প্রায় 0.3–0.5 মিটার; খাটো গাছে জিবেরেলিন হরমোন তৈরির একটি এনজাইমের জিন ত্রুটিপূর্ণ।', ['লম্বা', 'খাটো', 'T', 't', 787, 277]]
};
V.mendelTraits = Object.assign({}, B.seg({
  id: 'mtr', t: 'মেন্ডেলের বেছে নেওয়া মটরের সাতটি বৈশিষ্ট্য', H: 270, def: 'shape', types: Object.fromEntries(Object.entries(MT).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'গ্রেগর জোহান মেন্ডেল (1822–1884) 1856–1863 সালে ব্রুনোর (বর্তমান চেক প্রজাতন্ত্রের ব্রনো) মঠের বাগানে মটরশুঁটি (Pisum sativum) গাছে পরীক্ষা চালান। প্রতিটি বৈশিষ্ট্যের দুটি স্পষ্ট বিপরীত রূপ — একটি প্রকট, অপরটি প্রচ্ছন্ন। F<sub>2</sub> প্রজন্মে প্রতিটির অনুপাত প্রায় 3 : 1।',
  art(g, C, ty) { const [dn, rn, Da, ra, nd, nr] = MT[ty][3], ki = Object.keys(MT).indexOf(ty);
    B.cacheG(g, 'mtr' + ki, gg => {
      E('rect', { x: 8, y: 8, width: 168, height: 206, rx: 10, fill: '#fbfaf2', stroke: FK.alpha(C.fg, .15), 'stroke-width': .8 }, gg); E('rect', { x: 184, y: 8, width: 168, height: 206, rx: 10, fill: '#f6f4f8', stroke: FK.alpha(C.fg, .15), 'stroke-width': .8 }, gg);
      B.tx(gg, 92, 28, 'প্রকট: ' + dn, { fs: 12.6, a: 'middle', w: 700, c: '#2e6a3e' }); B.tx(gg, 268, 28, 'প্রচ্ছন্ন: ' + rn, { fs: 12.6, a: 'middle', w: 700, c: '#7a3a5a' });
      B.gt(gg, 92, 204, Da + Da + ' বা ' + Da + ra, { fs: 11, a: 'middle', c: '#2e6a3e' }); B.gt(gg, 268, 204, ra + ra, { fs: 11, a: 'middle', c: '#7a3a5a' });
      const L = 92, R = 268, cy = 112;
      if (ty === 'shape' || ty === 'col') { [[-26, -14, .3], [24, -18, 1.4], [0, 22, 2.6]].forEach(([dx, dy, a], i) => { B.peaSeed(gg, L + dx, cy + dy, 22, { col: ty === 'col' ? 'y' : 'y', a }); B.peaSeed(gg, R + dx, cy + dy, 22, { wr: ty === 'shape', col: ty === 'col' ? 'g' : 'y', a }); }); }
      if (ty === 'flw') { B.peaFlower(gg, L - 4, cy + 14, 2.4, 'pflw'); B.peaFlower(gg, R - 4, cy + 14, 2.4, 'wflw'); }
      if (ty === 'pod' || ty === 'podc') { B.peaPod(gg, L, cy - 20, 130, -.12, { col: 'g' }); B.peaPod(gg, L, cy + 36, 120, -.05, { col: 'g' }); B.peaPod(gg, R, cy - 20, 130, -.12, { con: ty === 'pod', col: ty === 'podc' ? 'y' : 'g' }); B.peaPod(gg, R, cy + 36, 120, -.05, { con: ty === 'pod', col: ty === 'podc' ? 'y' : 'g' }); }
      if (ty === 'pos') { B.peaPlant(gg, L, 192, 128, { nodes: 6, ls: 1.2 }); B.peaPlant(gg, R, 192, 128, { nodes: 6, term: true, ls: 1.2 }); }
      if (ty === 'ht') { B.peaPlant(gg, L, 190, 156, { nodes: 7, ls: 1.15 }); B.peaPlant(gg, R, 190, 40, { nodes: 3, ls: 1.15 }); E('path', { d: 'M150 190V36M146 36h8M146 190h8', stroke: FK.alpha(C.fg, .5), 'stroke-width': 1 }, gg); B.tx(gg, 146, 112, '≈ 2 মি', { fs: 9.6, a: 'end', c: C.mu }); E('path', { d: 'M318 190V150M314 150h8M314 190h8', stroke: FK.alpha(C.fg, .5), 'stroke-width': 1 }, gg); B.tx(gg, 314, 146, '≈ 0.3 মি', { fs: 9.6, a: 'end', c: C.mu }); }
      /* F2 দণ্ড */ const tot = nd + nr, w = 344 * nd / tot; E('rect', { x: 8, y: 226, width: w, height: 18, rx: 4, fill: '#7aa860' }, gg); E('rect', { x: 8 + w, y: 226, width: 344 - w, height: 18, rx: 4, fill: '#b07a9a' }, gg);
      B.tx(gg, 14, 239, String(nd), { fs: 10.4, w: 700, c: '#fff', halo: '#7aa860', hw: .5 }); B.tx(gg, 346, 239, String(nr), { fs: 10.4, a: 'end', w: 700, c: '#fff', halo: '#b07a9a', hw: .5 });
      B.tx(gg, 180, 262, 'F<sub>2</sub> পর্যবেক্ষণ: ' + nd + ' : ' + nr + ' = ' + (nd / nr).toFixed(2) + ' : 1', { fs: 10.4, a: 'middle', w: 700, c: C.fg }); }); },
  anim(g, C, ty, t) { const k = .5 + .5 * Math.sin(t * 2); E('rect', { x: 8 + (k > .5 ? 0 : 176), y: 8, width: 168, height: 206, rx: 10, fill: 'none', stroke: k > .5 ? '#2e6a3e' : '#7a3a5a', 'stroke-width': 1.6, opacity: f1(.25 + Math.abs(k - .5)) }, g); }
}));

/* ═════════ জিন, লোকাস ও অ্যালিল ═════════ */
const AL = [[.16, 'T', 't'], [.55, 'R', 'R'], [.78, 'y', 'y']], CX1 = 150, CX2 = 200, CY0 = 34, CH = 220;
V.alleleLocus = Object.assign({ t: 'জিন, লোকাস ও অ্যালিল', k: ['2d', 'anim', 'int', 'quiz'], cap: 'একজোড়া সমসংস্থ ক্রোমোজোম — একটি পিতা থেকে (নীল), একটি মাতা থেকে (গোলাপি)। দুটিতে একই ক্রমে একই জিনগুলো থাকে; ক্রোমোজোমে জিনের নির্দিষ্ট অবস্থান লোকাস। একই লোকাসে থাকা একই জিনের বিকল্প রূপগুলো অ্যালিল (যেমন T ও t)। জীবের অ্যালিল-গঠন জিনোটাইপ (এখানে Tt RR yy), আর তার বাহ্যিক প্রকাশ ফিনোটাইপ (লম্বা, গোল, সবুজ বীজ)।' },
  BK.diagram({ W: 360, H: 290, label: 'অ্যালিল', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      const a = B.chrom(P('hom'), CX1, CY0, CH, { tone: 'chrA', w: 14, cen: .38, bands: [.08, .27, .46, .66, .88] }); B.chrom(P('hom'), CX2, CY0, CH, { tone: 'chrB', w: 14, cen: .38, bands: [.08, .27, .46, .66, .88] });
      AL.forEach(([u, p, m], i) => { const y = CY0 + CH * u, gp = P(i === 0 ? 'het' : i === 1 ? 'homd' : 'homr');
        [CX1, CX2].forEach((x, j) => E('rect', { x: x - 7, y: y - 4, width: 14, height: 8, fill: j ? '#b03a4a' : '#2a4a8a' }, gp));
        E('path', { d: `M${CX1 + 9} ${f1(y)}H${CX2 - 9}`, stroke: FK.alpha(C.fg, .5), 'stroke-width': 1, 'stroke-dasharray': '2 2' }, gp);
        B.gt(gp, CX1 - 14, y + 4.5, p, { fs: 15, a: 'end', c: '#2a4a8a' }); B.gt(gp, CX2 + 14, y + 4.5, m, { fs: 15, c: '#b03a4a' }); });
      E('path', { d: `M${CX1 - 8} ${f1(a.c)}h-6M${CX2 + 8} ${f1(a.c)}h6`, stroke: FK.alpha(C.fg, .4) }, P('cen'));
      B.tx(g, CX1, CY0 - 12, 'পিতৃ', { fs: 10, a: 'middle', c: '#2a4a8a' }); B.tx(g, CX2, CY0 - 12, 'মাতৃ', { fs: 10, a: 'middle', c: '#b03a4a' });
      E('rect', { x: 96, y: 262, width: 168, height: 22, rx: 6, fill: FK.alpha('#3a7a4a', .08) }, P('gtype')); B.tx(P('gtype'), 180, 277, 'জিনোটাইপ: <tspan font-style="italic">Tt RR yy</tspan>', { fs: 11, a: 'middle', w: 700, c: '#2e6a3e' });
      hits(this.parts, part, 12); },
    idle(g, C, t) { const i = Math.floor(t * .6) % 3, y = CY0 + CH * AL[i][0], k = (t * .6) % 1; E('rect', { x: CX1 - 12, y: y - 9, width: CX2 - CX1 + 24, height: 18, rx: 6, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6, opacity: f1(Math.sin(k * PI)) }, g); },
    parts: [
      { id: 'hom', bn: 'সমসংস্থ ক্রোমোজোম জোড়া', lb: 'সমসংস্থ ক্রোমোজোম', en: 'Homologous chromosomes', fn: 'আকার, সেন্ট্রোমিয়ারের অবস্থান ও জিনের ক্রমে একই রকম একজোড়া ক্রোমোজোম — একটি পিতার শুক্রাণু, অন্যটি মাতার ডিম্বাণু থেকে আসে। মিয়োসিসে এরা জোড় বাঁধে ও আলাদা হয়।', a: [CX1 - 7, CY0 + CH * .36], l: [14, 120], an: 'start' },
      { id: 'cen', bn: 'সেন্ট্রোমিয়ার', lb: 'সেন্ট্রোমিয়ার', en: 'Centromere', fn: 'ক্রোমোজোমের সংকুচিত অংশ — বিভাজনে এখানে স্পিন্ডল তন্তু যুক্ত হয়।', a: [CX2 + 8, CY0 + CH * .38], l: [352, 124], an: 'end' },
      { id: 'het', bn: 'অসমযুগ্মী লোকাস (Tt)', lb: 'অসমযুগ্মী (Tt)', en: 'Heterozygous', fn: 'একটি লোকাসে দুটি ভিন্ন অ্যালিল (T ও t) থাকলে জীবটি ওই বৈশিষ্ট্যে অসমযুগ্মী বা হেটারোজাইগাস; প্রকট T প্রকাশিত হয় — গাছ লম্বা।', a: [CX2 + 7, CY0 + CH * .16], l: [352, 56], an: 'end' },
      { id: 'homd', bn: 'সমযুগ্মী প্রকট (RR)', lb: 'সমযুগ্মী প্রকট (RR)', en: 'Homozygous dominant', fn: 'দুটি অ্যালিলই একই প্রকট রূপ (R R) — বীজ গোল; এ জীব থেকে সব গ্যামেটে R যায় (বিশুদ্ধ বা খাঁটি বৈশিষ্ট্য)।', a: [CX2 + 7, CY0 + CH * .55], l: [352, 176], an: 'end' },
      { id: 'homr', bn: 'সমযুগ্মী প্রচ্ছন্ন (yy)', lb: 'সমযুগ্মী প্রচ্ছন্ন (yy)', en: 'Homozygous recessive', fn: 'দুটি অ্যালিলই প্রচ্ছন্ন (y y) — শুধু এ অবস্থাতেই প্রচ্ছন্ন বৈশিষ্ট্য (সবুজ বীজ) প্রকাশিত হয়।', a: [CX2 + 7, CY0 + CH * .78], l: [352, 236], an: 'end' },
      { id: 'locus', bn: 'লোকাস', lb: 'লোকাস', en: 'Locus', fn: 'ক্রোমোজোমে কোনো জিনের নির্দিষ্ট অবস্থান (বহুবচনে লোসাই)। সমসংস্থ ক্রোমোজোমে একই জিনের লোকাস একই জায়গায়।', a: [CX1, CY0 + CH * .55], l: [14, 176], an: 'start' },
      { id: 'allele', bn: 'অ্যালিল (অ্যালিলোমর্ফ)', lb: 'অ্যালিল', en: 'Allele', fn: 'একই লোকাসে অবস্থিত একই জিনের বিকল্প রূপ — যেমন লম্বা কাণ্ডের T ও খাটো কাণ্ডের t। মেন্ডেল এদের "ফ্যাক্টর" বলেছিলেন; একজোড়া বিপরীত বৈশিষ্ট্যের জন্য দায়ী ফ্যাক্টর জোড়া।', a: [CX1 - 16, CY0 + CH * .16], l: [14, 56], an: 'start' },
      { id: 'gene', bn: 'জিন', lb: 'জিন', en: 'Gene', fn: 'DNA এর নির্দিষ্ট অংশ যা একটি বৈশিষ্ট্যের (সাধারণত একটি প্রোটিন বা RNA এর) সংকেত বহন করে — বংশগতির একক। 1909 সালে জোহানসেন "জিন" শব্দটি প্রস্তাব করেন।', a: [CX1, CY0 + CH * .78], l: [14, 236], an: 'start' },
      { id: 'gtype', bn: 'জিনোটাইপ ও ফিনোটাইপ', lb: 'জিনোটাইপ', en: 'Genotype', fn: 'জিনোটাইপ: জীবের অ্যালিলের গঠন (Tt RR yy)। ফিনোটাইপ: জিনোটাইপ ও পরিবেশের মিলিত বাহ্যিক প্রকাশ (লম্বা, গোল বীজ, সবুজ বীজপত্র)।', a: [100, 273], l: [92, 280], an: 'end' }
    ]
  }));

/* ছোট গাছের প্রতীক: লম্বা বা খাটো */
const tinyPlant = (g, x, y, tall, s = 1, tone) => B.peaPlant(g, x, y, (tall ? 44 : 14) * s, { nodes: tall ? 4 : 2, ls: .48 * s, tone });

/* ═════════ একসংকর ক্রস ═════════ */
const MH = [
  { t: 'P প্রজন্ম', en: 'Parental generation', d: 'বিশুদ্ধ লম্বা (TT) ও বিশুদ্ধ খাটো (tt) মটরগাছের মধ্যে কৃত্রিম পরাগায়ন করা হলো। বিশুদ্ধ মানে বহু প্রজন্ম স্ব-পরাগায়নেও একই বৈশিষ্ট্য দেয় (সমযুগ্মী)।' },
  { t: 'গ্যামেট সৃষ্টি', en: 'Gametes', d: 'মিয়োসিসে ফ্যাক্টর জোড়া পৃথক হয় — TT গাছের সব গ্যামেট T, tt গাছের সব গ্যামেট t। প্রতিটি গ্যামেটে প্রতিটি ফ্যাক্টরের মাত্র একটি থাকে (গ্যামেটের বিশুদ্ধতা)।' },
  { t: 'F1 প্রজন্ম', en: 'First filial generation', d: 'T ও t গ্যামেটের মিলনে সব সন্তান Tt — সবাই লম্বা। খাটো বৈশিষ্ট্য হারিয়ে যায়নি, প্রচ্ছন্ন অবস্থায় আছে; লম্বা বৈশিষ্ট্য প্রকট।' },
  { t: 'F1 এর স্ব-পরাগায়ন', en: 'Selfing F1', d: 'Tt গাছের পুং ও স্ত্রী গ্যামেট দুই রকম — অর্ধেক T, অর্ধেক t, সমান সম্ভাবনায়।' },
  { t: 'F2 প্রজন্ম', en: 'Second filial generation', d: 'গ্যামেটের এলোমেলো মিলনে জিনোটাইপ 1 TT : 2 Tt : 1 tt এবং ফিনোটাইপ 3 লম্বা : 1 খাটো। খাটো বৈশিষ্ট্য আবার ফিরে আসে — প্রমাণ করে ফ্যাক্টর মিশে যায় না, পৃথক থাকে।' }
];
V.monohybrid = Object.assign({ t: 'একসংকর ক্রস ও মেন্ডেলের প্রথম সূত্র', k: ['2d', 'anim', 'steps'], cap: 'মেন্ডেলের প্রথম সূত্র (পৃথকীকরণ সূত্র): জীবের প্রতিটি বৈশিষ্ট্য একজোড়া ফ্যাক্টর দিয়ে নিয়ন্ত্রিত; গ্যামেট তৈরির সময় জোড়ার ফ্যাক্টর দুটি পরস্পর থেকে পৃথক হয়ে ভিন্ন গ্যামেটে যায় এবং কখনো মিশে যায় না। ফলে F<sub>2</sub> তে ফিনোটাইপ অনুপাত 3 : 1 এবং জিনোটাইপ অনুপাত 1 : 2 : 1।' },
  BK.steps({ W: 360, H: 300, label: 'একসংকর ক্রস', dur: 3.2, stages: MH,
    draw(g, C, s, u) {
      B.cacheG(g, 'mhb' + s, gg => { B.tx(gg, 8, 18, ['P', 'গ্যামেট', 'F<sub>1</sub>', 'F<sub>1</sub> × F<sub>1</sub>', 'F<sub>2</sub>'][s], { fs: 12, w: 700, c: '#a8201a' });
        if (s <= 1) { tinyPlant(gg, 96, 140, true, 2); tinyPlant(gg, 264, 140, false, 2); B.tx(gg, 180, 100, '×', { fs: 22, a: 'middle', c: C.fg }); B.gt(gg, 96, 162, 'TT', { a: 'middle', c: '#2e6a3e' }); B.gt(gg, 264, 162, 'tt', { a: 'middle', c: '#7a3a5a' }); B.tx(gg, 96, 178, 'বিশুদ্ধ লম্বা', { fs: 10, a: 'middle', c: C.mu }); B.tx(gg, 264, 178, 'বিশুদ্ধ খাটো', { fs: 10, a: 'middle', c: C.mu }); }
        if (s === 2) { tinyPlant(gg, 180, 210, true, 2.4); B.gt(gg, 180, 232, 'Tt', { a: 'middle', fs: 14, c: '#2e6a3e' }); B.tx(gg, 180, 250, 'সব সন্তান লম্বা (অসমযুগ্মী)', { fs: 10.4, a: 'middle', c: C.fg }); B.gam(gg, 120, 60, 14, 'T', '#2e6a3e'); B.gam(gg, 240, 60, 14, 't', '#7a3a5a'); E('path', { d: 'M130 72L168 100M230 72L192 100', stroke: FK.alpha(C.fg, .5), 'stroke-width': 1.2, 'marker-end': B.mk(gg, FK.alpha(C.fg, .6), 6) }, gg); }
        if (s === 3) { tinyPlant(gg, 180, 150, true, 2); B.gt(gg, 180, 172, 'Tt', { a: 'middle', fs: 14, c: '#2e6a3e' }); B.tx(gg, 90, 210, 'পুং গ্যামেট', { fs: 10, a: 'middle', c: '#2a5a90' }); B.tx(gg, 270, 210, 'স্ত্রী গ্যামেট', { fs: 10, a: 'middle', c: '#a8304a' }); }
        if (s === 4) { B.punnett(gg, C, 120, 74, 92, 88, ['T', 't'], ['T', 't'], (q, x, y, w, h, i, j) => { const gt = B.ord(['T', 't'][i] + ['T', 't'][j]), tall = gt.includes('T'); tinyPlant(q, x + 30, y + h - 12, tall, 1.3); B.gt(q, x + 66, y + h / 2 + 4, gt, { a: 'middle', fs: 13, c: tall ? '#2e6a3e' : '#7a3a5a' }); }, { fill: (i, j) => i + j === 2 ? '#f6eef4' : '#f2f8ee' }); B.tx(gg, 180, 44, 'পুং গ্যামেট', { fs: 9.6, a: 'middle', c: '#2a5a90' }); B.tx(gg, 86, 160, 'স্ত্রী', { fs: 9.6, a: 'end', c: '#a8304a' });
          B.tx(gg, 180, 276, 'ফিনোটাইপ 3 লম্বা : 1 খাটো  ·  জিনোটাইপ 1 TT : 2 Tt : 1 tt', { fs: 10.4, a: 'middle', w: 700, c: C.fg }); } });
      if (s === 1) { [[96, 'T', '#2e6a3e'], [264, 't', '#7a3a5a']].forEach(([x, a, c], i) => { for (let k = 0; k < 3; k++) { const v = cl(u * 1.4 - k * .15); B.gam(g, x - 30 + k * 30, lerp(170, 230, v), 12, a, c); } }); }
      if (s === 3) { const v = cl(u * 1.3); ['T', 't'].forEach((a, i) => { B.gam(g, lerp(180, 66 + i * 48, v), lerp(160, 244, v), 13, a, '#2a5a90'); B.gam(g, lerp(180, 246 + i * 48, v), lerp(160, 244, v), 13, a, '#a8304a'); }); }
      if (s === 2 || s === 4) { const k = .5 + .5 * Math.sin(u * PI * 4); if (s === 4) E('rect', { x: 120, y: 74 + 88, width: 92, height: 88, fill: 'none', stroke: '#7a3a5a', 'stroke-width': 2, opacity: f1(.2 + k * .6) }, g); } }
  }));
/* steps চিপে F1/F2 এর বদলে সাবস্ক্রিপ্ট দরকার নেই — চিপ লেখা সাধারণ পাঠ্য */

/* ═════════ যেকোনো একসংকর ক্রসের পানেট বর্গ ═════════ */
const PM = { 'TT_TT': 'TT × TT', 'TT_Tt': 'TT × Tt', 'TT_tt': 'TT × tt', 'Tt_Tt': 'Tt × Tt', 'Tt_tt': 'Tt × tt', 'tt_tt': 'tt × tt' };
const PMD = {
  'TT_TT': 'দুই বিশুদ্ধ লম্বা গাছের সব সন্তান TT — বিশুদ্ধ লম্বা।', 'TT_Tt': 'সব সন্তান লম্বা, কিন্তু অর্ধেক TT ও অর্ধেক Tt — ফিনোটাইপ দেখে জিনোটাইপ বোঝা যায় না।', 'TT_tt': 'মেন্ডেলের প্রথম ক্রস — সব সন্তান Tt (F<sub>1</sub>), সবাই লম্বা।',
  'Tt_Tt': 'F<sub>1</sub> × F<sub>1</sub> — জিনোটাইপ 1 : 2 : 1, ফিনোটাইপ 3 : 1 (একসংকর অনুপাত)।', 'Tt_tt': 'টেস্ট ক্রস — 1 Tt লম্বা : 1 tt খাটো; অসমযুগ্মী পিতামাতা দুই রকম গ্যামেট সমান হারে দেয় তার প্রত্যক্ষ প্রমাণ।', 'tt_tt': 'দুই খাটো গাছের সব সন্তান খাটো — প্রচ্ছন্ন বৈশিষ্ট্য সবসময় বিশুদ্ধ।' };
V.punnettMono = Object.assign({}, B.seg({
  id: 'pmn', t: 'পানেট বর্গ: যেকোনো একসংকর ক্রস', H: 290, def: 'Tt_Tt', types: Object.fromEntries(Object.keys(PM).map(k => [k, [PM[k], 'ক্রস: ' + PM[k], PMD[k]]])),
  cap: 'পানেট বর্গ (রেজিনাল্ড পানেট, 1905) — ওপরে একজন পিতা বা মাতার গ্যামেট, বাঁয়ে অন্যজনের; প্রতিটি ঘরে দুই গ্যামেটের মিলনে সম্ভাব্য সন্তানের জিনোটাইপ। প্রতিটি ঘরের সম্ভাবনা সমান (1/4)। একটি পিতামাতা থেকে একই অক্ষরের দুটি গ্যামেট থাকলেও দুটি ঘর ধরা হয়, তাই অনুপাত সবসময় 4 ঘরের ভিত্তিতে।',
  art(g, C, ty) { const [p1, p2] = ty.split('_'), ki = Object.keys(PM).indexOf(ty); B.cacheG(g, 'pmn' + ki, gg => {
    tinyPlant(gg, 70, 70, p1.includes('T'), 1.1); tinyPlant(gg, 290, 70, p2.includes('T'), 1.1); B.gt(gg, 70, 88, p1, { a: 'middle', c: '#a8304a' }); B.gt(gg, 290, 88, p2, { a: 'middle', c: '#2a5a90' }); B.tx(gg, 180, 60, '×', { fs: 20, a: 'middle' });
    const cnt = {}; B.punnett(gg, C, 136, 124, 64, 56, p1.split(''), p2.split(''), (q, x, y, w, h, i, j) => { const gt = B.ord(p1[i] + p2[j]), tall = gt.includes('T'); cnt[gt] = (cnt[gt] || 0) + 1; tinyPlant(q, x + 18, y + h - 8, tall, .9); B.gt(q, x + 46, y + h / 2 + 4, gt, { a: 'middle', c: tall ? '#2e6a3e' : '#7a3a5a' }); }, { fill: (i, j) => B.ord(p1[i] + p2[j]) === 'tt' ? '#f6eef4' : '#f2f8ee' });
    const gts = ['TT', 'Tt', 'tt'].filter(k => cnt[k]); B.tx(gg, 14, 254, 'জিনোটাইপ: ' + gts.map(k => cnt[k] + ' <tspan font-style="italic">' + k + '</tspan>').join(' : '), { fs: 10.6, w: 700, c: C.fg });
    const tl = (cnt.TT || 0) + (cnt.Tt || 0), dw = cnt.tt || 0; B.tx(gg, 14, 274, 'ফিনোটাইপ: ' + [tl ? tl + ' লম্বা' : '', dw ? dw + ' খাটো' : ''].filter(Boolean).join(' : '), { fs: 10.6, w: 700, c: '#2e6a3e' });
    let x = 200; [['#7aa860', tl], ['#b07a9a', dw]].forEach(([c, n]) => { if (!n) return; E('rect', { x, y: 262, width: n * 37, height: 16, rx: 3, fill: c }, gg); x += n * 37; }); }); },
  anim(g, C, ty, t) { const i = Math.floor(t * 1.2) % 4, r = i >> 1, c = i & 1; E('rect', { x: 136 + c * 64, y: 124 + r * 56, width: 64, height: 56, fill: 'none', stroke: '#e0a030', 'stroke-width': 2.4 }, g); E('path', { d: `M${136 + c * 64 + 32} 116V${124 + r * 56}M128 ${124 + r * 56 + 28}H${136 + c * 64}`, stroke: '#e0a030', 'stroke-width': 1, 'stroke-dasharray': '3 3' }, g); }
}));

/* ═════════ টেস্ট ক্রস ও ব্যাক ক্রস ═════════ */
const TC = {
  tc1: ['টেস্ট ক্রস: TT', 'অজানা লম্বা গাছ TT হলে', 'অজানা জিনোটাইপের লম্বা গাছকে প্রচ্ছন্ন সমযুগ্মী খাটো (tt) গাছের সাথে ক্রস করলে সব সন্তান লম্বা (Tt) — অর্থাৎ অজানা গাছটি সমযুগ্মী TT। প্রচ্ছন্ন পিতামাতা কেবল t দেয়, তাই সন্তানের ফিনোটাইপ সরাসরি অজানা পিতামাতার গ্যামেট বলে দেয়।', ['TT', 'tt']],
  tc2: ['টেস্ট ক্রস: Tt', 'অজানা লম্বা গাছ Tt হলে', 'সন্তানের অর্ধেক লম্বা (Tt), অর্ধেক খাটো (tt) — অনুপাত 1 : 1; অর্থাৎ অজানা গাছটি অসমযুগ্মী। F<sub>1</sub> কে প্রচ্ছন্ন পিতামাতার সাথে এ ক্রসকে টেস্ট ক্রস বলে — একসংকরে অনুপাত 1 : 1, দ্বিসংকরে 1 : 1 : 1 : 1।', ['Tt', 'tt']],
  bc: ['ব্যাক ক্রস', 'ব্যাক ক্রস: F1 × প্রকট পিতামাতা', 'F<sub>1</sub> সন্তানকে তার যেকোনো পিতা বা মাতার সাথে ক্রস করাকে ব্যাক ক্রস বলে। প্রকট পিতামাতার (TT) সাথে করলে সব সন্তান লম্বা (1 TT : 1 Tt); প্রচ্ছন্ন পিতামাতার (tt) সাথে করলে সেটি টেস্ট ক্রস। তাই সব টেস্ট ক্রস ব্যাক ক্রস হতে পারে, কিন্তু সব ব্যাক ক্রস টেস্ট ক্রস নয়।', ['Tt', 'TT']]
};
V.testCross = Object.assign({}, B.seg({
  id: 'tcx', t: 'টেস্ট ক্রস ও ব্যাক ক্রস', H: 280, def: 'tc2', types: Object.fromEntries(Object.entries(TC).map(([k, v]) => [k, [v[0], v[1], v[2]]])),
  cap: 'লম্বা গাছ TT না Tt — বাইরে থেকে বোঝা যায় না। টেস্ট ক্রস (প্রচ্ছন্ন সমযুগ্মীর সাথে ক্রস) সন্তানের অনুপাত দেখে অজানা জিনোটাইপ নির্ণয় করে। নিচে 8টি সন্তানের নমুনা।',
  art(g, C, ty) { const [p1, p2] = TC[ty][3], ki = Object.keys(TC).indexOf(ty); B.cacheG(g, 'tcx' + ki, gg => {
    tinyPlant(gg, 60, 74, true, 1.2); tinyPlant(gg, 300, 74, p2.includes('T'), 1.2); B.gt(gg, 60, 94, ty === 'bc' ? 'Tt (F<tspan baseline-shift="sub" font-size="75%">1</tspan>)' : '? (' + p1 + ')', { a: 'middle', c: '#2e6a3e' }); B.gt(gg, 300, 94, p2, { a: 'middle', c: p2 === 'tt' ? '#7a3a5a' : '#2e6a3e' }); B.tx(gg, 180, 60, '×', { fs: 20, a: 'middle' });
    B.punnett(gg, C, 120, 40, 60, 40, p1.split(''), p2.split('').slice(0, 1).concat(p2.split('').slice(1)), (q, x, y, w, h, i, j) => { const gt = B.ord(p1[i] + p2[j]); B.gt(q, x + w / 2, y + h / 2 + 4, gt, { a: 'middle', c: gt.includes('T') ? '#2e6a3e' : '#7a3a5a' }); }, { gfs: 10 });
    for (let k = 0; k < 8; k++) { const gt = B.ord(p1[k % 2] + p2[(k >> 1) % 2]), tall = gt.includes('T'); tinyPlant(gg, 30 + k * 43, 232, tall, 1); B.gt(gg, 30 + k * 43, 250, gt, { a: 'middle', fs: 10, c: tall ? '#2e6a3e' : '#7a3a5a' }); }
    const nt = [0, 1, 2, 3].filter(k => B.ord(p1[k % 2] + p2[k >> 1]).includes('T')).length; B.tx(gg, 180, 272, nt === 4 ? 'সব লম্বা' : nt + ' লম্বা : ' + (4 - nt) + ' খাটো = 1 : 1', { fs: 11, a: 'middle', w: 700, c: '#2e6a3e' }); B.tx(gg, 8, 150, 'সন্তান', { fs: 10, c: C.mu }); }); },
  anim(g, C, ty, t) { const k = Math.floor(t * 2) % 8; E('rect', { x: 30 + k * 43 - 18, y: 170, width: 36, height: 88, rx: 6, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.4 }, g); }
}));
})();
