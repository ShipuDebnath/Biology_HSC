/* ═══════════════════════════════════════════════════════════════════
   visuals5 — রক্তের গ্রুপ ও Rh ফ্যাক্টর: aboAntigen, aboCross, transfusionChart, bloodTypeSlide, rhPregnancy
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B211, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), ez = t => t * t * (3 - 2 * t);
const sup = s => `<tspan baseline-shift="super" font-size="68%">${s}</tspan>`, IA = 'I' + sup('A'), IB = 'I' + sup('B'), Ii = 'i';
const AC = { A: '#2a7ac0', B: '#e0a020' };
/* লোহিত কণিকা + অ্যান্টিজেন (A ত্রিভুজ, B বৃত্ত, H ছোট দণ্ড) */
const rbcAg = (g, x, y, r, ags, o = {}) => { x = +x; y = +y; E('path', { d: B.ellD(x, y, r, r * .9, 0), fill: B.rbcG(g), stroke: '#8a2a2a', 'stroke-width': .8 }, g); E('path', { d: B.ellD(x, y, r * .45, r * .38, 0), fill: FK.alpha('#8a2a2a', .15) }, g);
  const n = o.n || 12; for (let i = 0; i < n; i++) { const a = i / n * 2 * PI + .13, k = ags.length ? ags[i % ags.length] : 'H', px = x + Math.cos(a) * (r + 4), py = y + Math.sin(a) * (r * .9 + 4); E('path', { d: `M${f1(x + Math.cos(a) * r)} ${f1(y + Math.sin(a) * r * .9)}L${f1(px)} ${f1(py)}`, stroke: '#6a5a4a', 'stroke-width': .8 }, g);
    if (k === 'A') E('path', { d: `M${f1(px - 3.4)} ${f1(py + 2.6)}L${f1(px)} ${f1(py - 3.4)}L${f1(px + 3.4)} ${f1(py + 2.6)}Z`, fill: AC.A, stroke: '#1a4a80', 'stroke-width': .5 }, g); else if (k === 'B') E('circle', { cx: f1(px), cy: f1(py), r: 3, fill: AC.B, stroke: '#8a6010', 'stroke-width': .5 }, g); else if (k === 'D') E('rect', { x: f1(px - 2.4), y: f1(py - 2.4), width: 4.8, height: 4.8, fill: '#3a9a5a', stroke: '#1a5a3a', 'stroke-width': .5 }, g); else E('circle', { cx: f1(px), cy: f1(py), r: 1.4, fill: '#8a7a6a' }, g); } };
/* অ্যান্টিবডি (IgM কে সরল Y দিয়ে): k = 'A' বা 'B' — বাহুর মাথায় পরিপূরক খাঁজ */
const anti = (g, x, y, k, s = 1, a = -PI / 2) => { const c = k === 'A' ? '#1a4a80' : k === 'B' ? '#8a6010' : '#3a6a3a', L = 8 * s, ca = Math.cos(a), sa = Math.sin(a), hx = x + ca * L, hy = y + sa * L; let d = `M${f1(x)} ${f1(y)}L${f1(hx)} ${f1(hy)}`; [-.6, .6].forEach(da => d += `M${f1(hx)} ${f1(hy)}l${f1(Math.cos(a + da) * L)} ${f1(Math.sin(a + da) * L)}`); E('path', { d, stroke: c, 'stroke-width': 1.8 * s, fill: 'none', 'stroke-linecap': 'round' }, g); };

/* ═════════ ABO গ্রুপ: অ্যান্টিজেন ও অ্যান্টিবডি ═════════ */
const AB = {
  A: ['A', 'A গ্রুপ', 'লোহিত কণিকায় A অ্যান্টিজেন; রক্তরসে অ্যান্টি-B অ্যান্টিবডি। জিনোটাইপ I<sup>A</sup>I<sup>A</sup> বা I<sup>A</sup>i।', [['A'], ['B'], [IA + IA, IA + Ii]]],
  B: ['B', 'B গ্রুপ', 'লোহিত কণিকায় B অ্যান্টিজেন; রক্তরসে অ্যান্টি-A অ্যান্টিবডি। জিনোটাইপ I<sup>B</sup>I<sup>B</sup> বা I<sup>B</sup>i।', [['B'], ['A'], [IB + IB, IB + Ii]]],
  AB: ['AB', 'AB গ্রুপ', 'কণিকায় A ও B দুটি অ্যান্টিজেনই (সমপ্রকটতা); রক্তরসে কোনো অ্যান্টি-A বা অ্যান্টি-B নেই — তাই যেকোনো ABO গ্রুপের লোহিত কণিকা নিতে পারে (সর্বজনীন গ্রহীতা)। জিনোটাইপ শুধু I<sup>A</sup>I<sup>B</sup>।', [['A', 'B'], [], [IA + IB]]],
  O: ['O', 'O গ্রুপ', 'কণিকায় A বা B কোনোটিই নেই (শুধু ভিত্তি পদার্থ H); রক্তরসে অ্যান্টি-A ও অ্যান্টি-B দুটিই আছে। এর লোহিত কণিকা সবাইকে দেওয়া যায় (সর্বজনীন দাতা)। জিনোটাইপ শুধু ii (প্রচ্ছন্ন সমযুগ্মী)।', [[], ['A', 'B'], [Ii + Ii]]]
};
V.aboAntigen = Object.assign({}, B.seg({
  id: 'abo', t: 'ABO রক্তের গ্রুপ: অ্যান্টিজেন ও অ্যান্টিবডি', H: 270, def: 'A', types: Object.fromEntries(Object.entries(AB).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'কার্ল ল্যান্ডস্টাইনার (1900–1901) ABO রক্তের গ্রুপ আবিষ্কার করেন (নোবেল 1930)। গ্রুপ নির্ধারিত হয় লোহিত কণিকার ঝিল্লির গ্লাইকোপ্রোটিন-শর্করা অ্যান্টিজেন দিয়ে। নিয়ম: যে অ্যান্টিজেন কণিকায় নেই, তার বিরুদ্ধে অ্যান্টিবডি রক্তরসে থাকে (ল্যান্ডস্টাইনারের নীতি)। জিন একটি লোকাসে, তিনটি অ্যালিল: I<sup>A</sup>, I<sup>B</sup> (পরস্পর সমপ্রকট) ও i (দুটির কাছেই প্রচ্ছন্ন) — বহু অ্যালিলের (মাল্টিপল অ্যালিল) উদাহরণ।',
  art(g, C, ty) { const [ag, ab, gt] = AB[ty][3]; B.cacheG(g, 'abo' + Object.keys(AB).indexOf(ty), gg => {
    B.tx(gg, 180, 26, AB[ty][1], { fs: 15, a: 'middle', w: 700, c: '#8a2a2a' });
    E('rect', { x: 8, y: 40, width: 166, height: 150, rx: 10, fill: '#fbf2f0', stroke: FK.alpha('#8a2a2a', .2) }, gg); E('rect', { x: 186, y: 40, width: 166, height: 150, rx: 10, fill: '#fbf8e6', stroke: FK.alpha('#8a7a2a', .25) }, gg);
    B.tx(gg, 91, 58, 'লোহিত কণিকায় অ্যান্টিজেন', { fs: 10, a: 'middle', w: 700, c: '#8a2a2a' }); B.tx(gg, 269, 58, 'রক্তরসে অ্যান্টিবডি', { fs: 10, a: 'middle', w: 700, c: '#6a5a1a' });
    rbcAg(gg, 91, 120, 38, ag); B.tx(gg, 91, 182, ag.length ? ag.join(' ও ') + ' অ্যান্টিজেন' : 'A বা B নেই (শুধু H)', { fs: 10, a: 'middle', c: C.fg });
    if (ab.length) { for (let i = 0; i < 10; i++) { const k = ab[i % ab.length]; anti(gg, 210 + (i % 5) * 30, 104 + Math.floor(i / 5) * 40 + (i % 2) * 6, k, 1.1, -PI / 2 + (B.rnd(i) - .5) * .8); } B.tx(gg, 269, 182, ab.map(k => 'অ্যান্টি-' + k).join(' ও '), { fs: 10, a: 'middle', c: C.fg }); } else B.tx(gg, 269, 120, 'অ্যান্টি-A ও অ্যান্টি-B নেই', { fs: 10.4, a: 'middle', c: C.mu });
    B.tx(gg, 180, 214, 'জিনোটাইপ: ' + gt.join(' বা '), { fs: 12, a: 'middle', w: 700, c: C.fg, st: 'font-style:italic' });
    E('path', { d: 'M24 244l4 -7l4 7z', fill: AC.A }, gg); B.tx(gg, 38, 246, 'A অ্যান্টিজেন', { fs: 9.6, c: '#1a4a80' }); E('circle', { cx: 132, cy: 242, r: 3.4, fill: AC.B }, gg); B.tx(gg, 140, 246, 'B অ্যান্টিজেন', { fs: 9.6, c: '#8a6010' }); anti(gg, 238, 248, 'A', .8); B.tx(gg, 252, 246, 'অ্যান্টিবডি (IgM)', { fs: 9.6, c: C.fg }); }); },
  anim(g, C, ty, t) { const k = .5 + .5 * Math.sin(t * 2.2); E('circle', { cx: 91, cy: 120, r: f1(48 + k * 3), fill: 'none', stroke: '#c0392b', 'stroke-width': 1, 'stroke-dasharray': '3 4', opacity: f1(.3 + k * .4) }, g); }
}));

/* ═════════ ABO এর বংশগতি ═════════ */
const AL = { A: IA, B: IB, o: Ii }, grp = (a, b) => { const s = [a, b]; return s.includes('A') && s.includes('B') ? 'AB' : s.includes('A') ? 'A' : s.includes('B') ? 'B' : 'O'; };
const GC = { A: '#2a7ac0', B: '#c08a10', AB: '#7a3aa8', O: '#6a6a6a' };
const AX = {
  ao_bo: ['A (IAi) × B (IBi)', 'I<sup>A</sup>i × I<sup>B</sup>i', 'A গ্রুপের বাবা ও B গ্রুপের মা — দুজনেই অসমযুগ্মী হলে চার সন্তানের চার রকম গ্রুপ সম্ভব: A, B, AB ও O — প্রতিটি 1/4। দুই O নয় এমন পিতামাতারও O সন্তান হতে পারে।', ['A', 'o'], ['B', 'o']],
  aa_oo: ['A (IAIA) × O', 'I<sup>A</sup>I<sup>A</sup> × ii', 'সব সন্তান A গ্রুপ (I<sup>A</sup>i) — অসমযুগ্মী।', ['A', 'A'], ['o', 'o']],
  ab_oo: ['AB × O', 'I<sup>A</sup>I<sup>B</sup> × ii', 'সন্তান অর্ধেক A (I<sup>A</sup>i), অর্ধেক B (I<sup>B</sup>i) — কোনো সন্তান AB বা O নয়, পিতামাতার কারও গ্রুপই পায় না!', ['A', 'B'], ['o', 'o']],
  ab_ab: ['AB × AB', 'I<sup>A</sup>I<sup>B</sup> × I<sup>A</sup>I<sup>B</sup>', '1 A : 2 AB : 1 B — সমপ্রকটতার 1 : 2 : 1 অনুপাত; O সন্তান অসম্ভব।', ['A', 'B'], ['A', 'B']],
  oo_oo: ['O × O', 'ii × ii', 'সব সন্তান O — প্রচ্ছন্ন বৈশিষ্ট্য সবসময় বিশুদ্ধ। O × O দম্পতির A বা B সন্তান জৈবিকভাবে সম্ভব নয় — পিতৃত্ব নির্ণয়ে এ যুক্তি কাজে লাগে (তবে শুধু বাদ দিতে পারে, প্রমাণ করতে পারে না; চূড়ান্ত প্রমাণে DNA পরীক্ষা)।', ['o', 'o'], ['o', 'o']]
};
V.aboCross = Object.assign({}, B.seg({
  id: 'abx', t: 'রক্তের গ্রুপের বংশগতি', H: 270, def: 'ao_bo', types: Object.fromEntries(Object.entries(AX).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'ABO গ্রুপ একটি লোকাসের তিনটি অ্যালিল দিয়ে নিয়ন্ত্রিত — প্রত্যেক মানুষের দেহে এর যেকোনো দুটি থাকে, তাই 6 রকম জিনোটাইপ ও 4 রকম ফিনোটাইপ। I<sup>A</sup> ও I<sup>B</sup> পরস্পর সমপ্রকট, দুটিই i এর ওপর প্রকট।',
  art(g, C, ty) { const [, , , p1, p2] = AX[ty], ki = Object.keys(AX).indexOf(ty); B.cacheG(g, 'abx' + ki, gg => {
    const g1 = grp(p1[0], p1[1]), g2 = grp(p2[0], p2[1]); B.gt(gg, 70, 40, AL[p1[0]] + AL[p1[1]], { a: 'middle', fs: 14 }); B.tx(gg, 70, 58, 'বাবা: ' + g1 + ' গ্রুপ', { fs: 10, a: 'middle', w: 700, c: GC[g1] }); B.gt(gg, 290, 40, AL[p2[0]] + AL[p2[1]], { a: 'middle', fs: 14 }); B.tx(gg, 290, 58, 'মা: ' + g2 + ' গ্রুপ', { fs: 10, a: 'middle', w: 700, c: GC[g2] }); B.tx(gg, 180, 46, '×', { fs: 20, a: 'middle' });
    const cnt = {}; B.punnett(gg, C, 120, 96, 80, 62, p2.map(a => AL[a]), p1.map(a => AL[a]), (q, x, y, w, h, i, j) => { const gp = grp(p2[i], p1[j]); cnt[gp] = (cnt[gp] || 0) + 1; rbcAg(q, x + 22, y + 30, 13, gp === 'AB' ? ['A', 'B'] : gp === 'O' ? [] : [gp], { n: 8 }); B.tx(q, x + 58, y + 26, gp, { fs: 14, a: 'middle', w: 700, c: GC[gp] }); B.tx(q, x + 58, y + 44, AL[p2[i]] + AL[p1[j]], { fs: 9.6, a: 'middle', c: C.mu, st: 'font-style:italic' }); }, { gfs: 10 });
    B.tx(gg, 180, 254, 'সন্তানের গ্রুপ: ' + ['A', 'AB', 'B', 'O'].filter(k => cnt[k]).map(k => cnt[k] + ' ' + k).join(' : '), { fs: 11, a: 'middle', w: 700, c: C.fg }); }); },
  anim(g, C, ty, t) { const i = Math.floor(t * 1.2) % 4; E('rect', { x: 120 + (i & 1) * 80, y: 96 + (i >> 1) * 62, width: 80, height: 62, fill: 'none', stroke: '#e0a030', 'stroke-width': 2.2 }, g); }
}));

/* ═════════ রক্ত সঞ্চালনের সামঞ্জস্য ═════════ */
const GR = ['O', 'A', 'B', 'AB'], ok = (d, r) => d === 'O' || r === 'AB' || d === r, TX0 = 120, TY0 = 66, TW = 56, TH = 44;
V.transfusionChart = Object.assign({ t: 'রক্ত সঞ্চালনে ABO সামঞ্জস্য', k: ['2d', 'anim', 'int', 'quiz'], cap: 'সারি = দাতার লোহিত কণিকা, কলাম = গ্রহীতা। সবুজ ঘরে দেওয়া যায়; লাল ঘরে গ্রহীতার রক্তরসের অ্যান্টিবডি দাতার কণিকার অ্যান্টিজেনে লেগে অ্যাগ্লুটিনেশন ও হিমোলাইসিস ঘটায় — জ্বর, কাঁপুনি, কিডনি বিকল, এমনকি মৃত্যু। মূল বিবেচ্য দাতার কণিকার অ্যান্টিজেন ও গ্রহীতার অ্যান্টিবডি। বাস্তবে সবসময় একই গ্রুপ (ও Rh) দেওয়া হয় এবং আগে ক্রস-ম্যাচ পরীক্ষা করা হয়।' },
  BK.diagram({ W: 360, H: 290, label: 'সঞ্চালন', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      B.tx(g, TX0 + TW * 2, 26, 'গ্রহীতা', { fs: 11, a: 'middle', w: 700, c: C.fg }); B.tx(g, 82, TY0 - 12, 'দাতা ↓', { fs: 11, a: 'middle', w: 700, c: C.fg });
      GR.forEach((r, j) => B.tx(g, TX0 + TW * (j + .5), TY0 - 12, r, { fs: 13, a: 'middle', w: 700, c: GC[r] }));
      GR.forEach((d, i) => { const gp = P('d' + d); rbcAg(gp, 88, TY0 + TH * (i + .5), 12, d === 'AB' ? ['A', 'B'] : d === 'O' ? [] : [d], { n: 8 });
        GR.forEach((r, j) => { const x = TX0 + TW * j, y = TY0 + TH * i, o = ok(d, r); E('rect', { x, y, width: TW, height: TH, fill: o ? '#e4f2dc' : '#f8e0dc', stroke: '#fff', 'stroke-width': 2 }, gp); if (o) B.okm(gp, x + TW / 2 - 4, y + TH / 2, 6, '#2e7a3e'); else E('path', { d: `M${x + TW / 2 - 6} ${y + TH / 2 - 6}l12 12M${x + TW / 2 + 6} ${y + TH / 2 - 6}l-12 12`, stroke: '#b03a2a', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, gp); }); });
      E('rect', { x: TX0, y: TY0, width: TW * 4, height: TH * 4, fill: 'none', stroke: FK.alpha(C.fg, .4) }, g);
      B.tx(g, 180, 268, 'O: সর্বজনীন দাতা  ·  AB: সর্বজনীন গ্রহীতা', { fs: 10.6, a: 'middle', w: 700, c: '#8a2a2a' });
      hits(this.parts, part, 14); },
    idle(g, C, t) { const i = Math.floor(t * .7) % 4; E('rect', { x: TX0, y: TY0 + TH * i, width: TW * 4, height: TH, fill: 'none', stroke: '#e0a030', 'stroke-width': 2 }, g); },
    parts: [
      { id: 'dO', bn: 'O গ্রুপ দাতা', lb: 'O', en: 'Universal donor', fn: 'কণিকায় A বা B অ্যান্টিজেন নেই, তাই গ্রহীতার অ্যান্টিবডি লাগার কিছু নেই — জরুরি অবস্থায় যেকোনো গ্রুপকে O নেগেটিভ লোহিত কণিকা দেওয়া হয়। কিন্তু O মানুষ শুধু O রক্ত নিতে পারে, কারণ তার রক্তরসে অ্যান্টি-A ও অ্যান্টি-B দুটিই আছে।', a: [68, TY0 + TH * .5], l: [14, TY0 + TH * .5 + 4], an: 'start' },
      { id: 'dA', bn: 'A গ্রুপ দাতা', lb: 'A', en: 'Group A donor', fn: 'A ও AB গ্রহীতাকে দিতে পারে; O ও B গ্রহীতার অ্যান্টি-A একে আক্রমণ করবে। A মানুষ A ও O থেকে নিতে পারে।', a: [68, TY0 + TH * 1.5], l: [14, TY0 + TH * 1.5 + 4], an: 'start' },
      { id: 'dB', bn: 'B গ্রুপ দাতা', lb: 'B', en: 'Group B donor', fn: 'B ও AB গ্রহীতাকে দিতে পারে। B মানুষ B ও O থেকে নিতে পারে। বাংলাদেশে B ও O গ্রুপ সবচেয়ে বেশি পাওয়া যায়।', a: [68, TY0 + TH * 2.5], l: [14, TY0 + TH * 2.5 + 4], an: 'start' },
      { id: 'dAB', bn: 'AB গ্রুপ দাতা', lb: 'AB', en: 'Universal recipient', fn: 'কণিকায় A ও B দুটিই — শুধু AB গ্রহীতাকে দেওয়া যায়। কিন্তু AB মানুষের রক্তরসে কোনো অ্যান্টিবডি নেই, তাই চারটি গ্রুপ থেকেই লোহিত কণিকা নিতে পারে — সর্বজনীন গ্রহীতা।', a: [68, TY0 + TH * 3.5], l: [14, TY0 + TH * 3.5 + 4], an: 'start' }
    ]
  }));

/* ═════════ স্লাইডে রক্তের গ্রুপ নির্ণয় ═════════ */
const BT = { Ap: ['A+', [1, 0, 1]], Bp: ['B+', [0, 1, 1]], ABp: ['AB+', [1, 1, 1]], On: ['O−', [0, 0, 0]], Op: ['O+', [0, 0, 1]] };
const drop = (g, x, y, r, agg, seed) => { E('path', { d: B.ellD(x, y, r, r * .9, 0), fill: agg ? '#f6dcd8' : '#c8383a', stroke: '#8a2a2a', 'stroke-width': .8, opacity: agg ? 1 : .92 }, g); if (agg) { let d = ''; for (let i = 0; i < 16; i++) { const a = B.rnd(seed + i) * 2 * PI, rr = B.rnd(seed + i + 40) * r * .7; const cx = x + Math.cos(a) * rr, cy = y + Math.sin(a) * rr * .9, s = 2.6 + B.rnd(seed + i * 3) * 4; for (let k = 0; k < 5; k++) d += B.ellD(cx + (B.rnd(seed + i * 9 + k) - .5) * s * 1.6, cy + (B.rnd(seed + i * 7 + k) - .5) * s * 1.6, s * .5, s * .45, 0); } E('path', { d, fill: '#a82a2a' }, g); } else { let d = ''; for (let i = 0; i < 30; i++) { const a = B.rnd(seed + i) * 2 * PI, rr = B.rnd(seed + i + 40) * r * .8; d += B.ellD(x + Math.cos(a) * rr, y + Math.sin(a) * rr * .9, 1.4, 1.4, 0); } E('path', { d, fill: '#9a1e20', opacity: .6 }, g); } };
V.bloodTypeSlide = Object.assign({}, B.seg({
  id: 'bts', t: 'স্লাইডে রক্তের গ্রুপ নির্ণয়', H: 250, def: 'Ap', types: Object.fromEntries(Object.entries(BT).map(([k, v]) => [k, [v[0], v[0] + ' রক্ত', 'তিন ফোঁটা রক্তে যথাক্রমে অ্যান্টি-A, অ্যান্টি-B ও অ্যান্টি-D সিরাম মেশানো হয়। যে ফোঁটায় লোহিত কণিকা দলা পাকায় (অ্যাগ্লুটিনেশন), সেই অ্যান্টিজেন রক্তে আছে। ' + (v[0] === 'O−' ? 'কোনো ফোঁটায় দলা নেই — A, B বা D কোনো অ্যান্টিজেন নেই: O নেগেটিভ।' : 'ফলাফল: ' + ['A', 'B', 'D (Rh)'].filter((_, i) => v[1][i]).join(', ') + ' অ্যান্টিজেন আছে — ' + v[0] + '।')]])),
  cap: 'এ পরীক্ষা অ্যান্টিজেন-অ্যান্টিবডির অ্যাগ্লুটিনেশন বিক্রিয়ার ওপর ভিত্তি করে। দলা পাকানো ফোঁটায় লাল কণিকার দানা ও স্বচ্ছ রস দেখা যায়, দলা না পাকালে ফোঁটা সমভাবে লাল থাকে।',
  art(g, C, ty) { const r = BT[ty][1], ki = Object.keys(BT).indexOf(ty); B.cacheG(g, 'bts' + ki, gg => {
    E('rect', { x: 14, y: 50, width: 332, height: 120, rx: 6, fill: '#eef4f8', stroke: '#9ab0c0', 'stroke-width': 1.2 }, gg); E('rect', { x: 14, y: 50, width: 332, height: 120, rx: 6, fill: 'none', stroke: '#fff', 'stroke-width': 3, opacity: .6 }, gg);
    [['অ্যান্টি-A', '#2a7ac0'], ['অ্যান্টি-B', '#c08a10'], ['অ্যান্টি-D', '#3a8a5a']].forEach(([n, c], i) => { const x = 70 + i * 110; B.tx(gg, x, 40, n, { fs: 11, a: 'middle', w: 700, c }); drop(gg, x, 110, 36, r[i], ki * 50 + i * 13); B.tx(gg, x, 192, r[i] ? 'দলা (+)' : 'দলা নেই (−)', { fs: 10.4, a: 'middle', w: 700, c: r[i] ? '#a8201a' : C.mu }); });
    B.tx(gg, 180, 226, 'ফলাফল: ' + BT[ty][0], { fs: 15, a: 'middle', w: 700, c: '#8a2a2a' }); }); },
  anim(g, C, ty, t) { const i = Math.floor(t * .9) % 3; E('circle', { cx: 70 + i * 110, cy: 110, r: 42, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); }
}));

/* ═════════ Rh ফ্যাক্টর ও গর্ভধারণে জটিলতা ═════════ */
const RH = [
  { t: 'Rh অসামঞ্জস্য', en: 'Rh− mother, Rh+ fetus', d: 'Rh ফ্যাক্টর (D অ্যান্টিজেন) প্রকট অ্যালিল D দিয়ে নিয়ন্ত্রিত: DD বা Dd = Rh পজিটিভ, dd = Rh নেগেটিভ। Rh নেগেটিভ মা (dd) ও Rh পজিটিভ বাবার (DD বা Dd) সন্তান Rh পজিটিভ (Dd) হতে পারে। স্বাভাবিকভাবে Rh নেগেটিভ মানুষের রক্তে অ্যান্টি-D থাকে না।' },
  { t: 'প্রথম প্রসব: সংবেদনশীলতা', en: 'Sensitisation', d: 'প্রথম গর্ভে সাধারণত সমস্যা হয় না। প্রসবের সময় (বা গর্ভপাত, আঘাতে) অমরা ছিঁড়ে ভ্রূণের Rh পজিটিভ কণিকা মায়ের রক্তে ঢোকে; মায়ের প্রতিরক্ষাতন্ত্র অ্যান্টি-D অ্যান্টিবডি ও স্মৃতি কোষ তৈরি করে — মা এখন সংবেদনশীল।' },
  { t: 'দ্বিতীয় গর্ভ: আক্রমণ', en: 'Second Rh+ pregnancy', d: 'পরের Rh পজিটিভ গর্ভে মায়ের স্মৃতি কোষ দ্রুত প্রচুর অ্যান্টি-D (IgG) তৈরি করে; IgG অমরা পার হয়ে ভ্রূণের লোহিত কণিকায় লেগে সেগুলো ধ্বংস (হিমোলাইসিস) করে।' },
  { t: 'এরিথ্রোব্লাস্টোসিস ফিটালিস', en: 'Haemolytic disease of the newborn', d: 'ভ্রূণে তীব্র রক্তশূন্যতা, অপরিণত লোহিত কণিকা (এরিথ্রোব্লাস্ট) রক্তে আসে, বিলিরুবিন বেড়ে তীব্র জন্ডিস; গুরুতর হলে দেহে পানি জমে (হাইড্রপস) গর্ভেই মৃত্যু, বা জন্মের পর মস্তিষ্কের ক্ষতি (কার্নিক্টেরাস)। নবজাতকের রক্ত বদল (এক্সচেঞ্জ ট্রান্সফিউশন) লাগতে পারে।' },
  { t: 'প্রতিরোধ: অ্যান্টি-D ইনজেকশন', en: 'Anti-D prophylaxis', d: 'Rh নেগেটিভ মাকে গর্ভের প্রায় 28 সপ্তাহে এবং Rh পজিটিভ সন্তান প্রসবের 72 ঘণ্টার মধ্যে অ্যান্টি-D ইমিউনোগ্লোবিউলিন দেওয়া হয়। এটি মায়ের রক্তে ঢোকা ভ্রূণের কণিকাকে মায়ের প্রতিরক্ষাতন্ত্র চেনার আগেই সরিয়ে দেয় — ফলে মায়ের স্মৃতি কোষ তৈরি হয় না (নিষ্ক্রিয় প্রতিরক্ষা দিয়ে সক্রিয় সাড়া ঠেকানো)।' }
];
const uterus = (g, x, y, s, fetusCol) => { E('path', { d: `M${f1(x - 46 * s)} ${f1(y - 10 * s)}C${f1(x - 50 * s)} ${f1(y - 60 * s)} ${f1(x + 50 * s)} ${f1(y - 60 * s)} ${f1(x + 46 * s)} ${f1(y - 10 * s)}C${f1(x + 44 * s)} ${f1(y + 30 * s)} ${f1(x + 14 * s)} ${f1(y + 46 * s)} ${f1(x)} ${f1(y + 54 * s)}C${f1(x - 14 * s)} ${f1(y + 46 * s)} ${f1(x - 44 * s)} ${f1(y + 30 * s)} ${f1(x - 46 * s)} ${f1(y - 10 * s)}Z`, fill: '#f6d0cc', stroke: '#b06a64', 'stroke-width': 1.4 }, g);
  E('path', { d: B.ellD(x, y - 4 * s, 34 * s, 36 * s, 0), fill: '#eef4fa', stroke: '#a8b8c8', 'stroke-width': .8 }, g); E('path', { d: `M${f1(x + 22 * s)} ${f1(y - 36 * s)}q14 -4 16 8q-4 8 -16 4Z`, fill: '#c06a6a', stroke: '#8a3a3a', 'stroke-width': .7 }, g);
  E('path', { d: `M${f1(x - 4 * s)} ${f1(y - 26 * s)}C${f1(x - 22 * s)} ${f1(y - 24 * s)} ${f1(x - 24 * s)} ${f1(y + 4 * s)} ${f1(x - 12 * s)} ${f1(y + 16 * s)}C${f1(x - 2 * s)} ${f1(y + 24 * s)} ${f1(x + 16 * s)} ${f1(y + 18 * s)} ${f1(x + 14 * s)} ${f1(y + 2 * s)}C${f1(x + 12 * s)} ${f1(y - 8 * s)} ${f1(x + 2 * s)} ${f1(y - 10 * s)} ${f1(x - 4 * s)} ${f1(y - 26 * s)}Z`, fill: fetusCol || '#f2c4a8', stroke: '#b07a5a', 'stroke-width': .8 }, g);
  E('circle', { cx: f1(x - 6 * s), cy: f1(y - 20 * s), r: f1(11 * s), fill: fetusCol || '#f2c4a8', stroke: '#b07a5a', 'stroke-width': .8 }, g); E('path', { d: `M${f1(x + 10 * s)} ${f1(y + 2 * s)}Q${f1(x + 24 * s)} ${f1(y - 10 * s)} ${f1(x + 28 * s)} ${f1(y - 28 * s)}`, stroke: '#c8a0a8', 'stroke-width': 2.2 * s, fill: 'none' }, g); };
V.rhPregnancy = Object.assign({ t: 'Rh ফ্যাক্টর ও গর্ভধারণে জটিলতা', k: ['2d', 'anim', 'steps'], cap: 'Rh ফ্যাক্টর ল্যান্ডস্টাইনার ও ভিনার (1940) রেসাস বানরের রক্ত নিয়ে পরীক্ষায় আবিষ্কার করেন — তাই নাম Rh। বাংলাদেশে Rh নেগেটিভ মানুষ মাত্র প্রায় 2–3%, তাই এ জটিলতা কম হলেও গর্ভকালীন রক্তের গ্রুপ পরীক্ষা জরুরি। ABO অ্যান্টিবডি মূলত IgM বলে অমরা পার হয় না, কিন্তু অ্যান্টি-D IgG — এখানেই বিপদ।' },
  BK.steps({ W: 360, H: 270, label: 'Rh অসামঞ্জস্য', dur: 3.4, stages: RH,
    draw(g, C, s, u) {
      B.cacheG(g, 'rhb' + Math.min(s, 3) + (s === 4 ? 9 : 0), gg => { E('path', { d: 'M8 214H352V262H8Z', fill: FK.alpha('#8a2a2a', .05) }, gg); uterus(gg, 120, 120, 1.25, s === 3 ? '#f0d890' : null); B.tx(gg, 30, 50, 'মা: Rh−', { fs: 11, w: 700, c: '#2a5a90' }); B.tx(gg, 120, 106, 'ভ্রূণ: Rh+', { fs: 10, a: 'middle', w: 700, c: '#a8201a' }); B.tx(gg, 160, 70, 'অমরা', { fs: 9.4, c: '#8a3a3a' }); });
      B.cacheG(g, 'rhl' + s, gl => { B.tx(gl, 8, 18, RH[s].t, { fs: 11, w: 700, c: '#a8201a' });
        if (s === 0) { B.tx(gl, 250, 70, 'বাবা: Rh+ (DD/Dd)', { fs: 10.4, w: 700, c: '#a8201a' }); B.tx(gl, 250, 92, 'মা: Rh− (dd)', { fs: 10.4, w: 700, c: '#2a5a90' }); B.tx(gl, 250, 114, 'সন্তান: Dd → Rh+', { fs: 10.4, w: 700, c: C.fg }); }
        if (s === 1) B.tx(gl, 250, 70, 'প্রসবে ভ্রূণের কণিকা মায়ের রক্তে', { fs: 9.8, w: 700, c: C.fg });
        if (s >= 1) B.tx(gl, 14, 232, s === 1 ? 'মায়ের রক্তে: অ্যান্টি-D তৈরি শুরু + স্মৃতি কোষ' : s === 4 ? 'অ্যান্টি-D ইমিউনোগ্লোবিউলিন: 28 সপ্তাহে ও প্রসবের 72 ঘণ্টার মধ্যে' : 'মায়ের রক্তে প্রচুর অ্যান্টি-D (IgG)', { fs: 10, w: 700, c: '#2a5a90' });
        if (s === 3) { ['তীব্র রক্তশূন্যতা', 'জন্ডিস (বিলিরুবিন বৃদ্ধি)', 'হাইড্রপস ফিটালিস', 'এরিথ্রোব্লাস্ট রক্তে'].forEach((t, i) => { E('circle', { cx: 240, cy: 64 + i * 26, r: 3, fill: '#a8201a' }, gl); B.tx(gl, 248, 68 + i * 26, t, { fs: 10, c: C.fg }); }); }
        if (s === 4) { B.tx(gl, 250, 70, 'ভ্রূণের কণিকা সরিয়ে দেয়', { fs: 10, w: 700, c: '#2e6a3e' }); B.tx(gl, 250, 90, 'মায়ের স্মৃতি কোষ তৈরি হয় না', { fs: 10, w: 700, c: '#2e6a3e' }); } });
      /* গতিশীল: কণিকা ও অ্যান্টিবডি */
      if (s === 0) { const k = .5 + .5 * Math.sin(u * PI * 4); for (let i = 0; i < 4; i++) rbcAg(g, 70 + i * 18, 190, 6, ['D'], { n: 6 }); }
      if (s === 1) { for (let i = 0; i < 5; i++) { const v = cl(u * 1.4 - i * .12); B.rbcFace(g, f1(lerp(150, 210 + i * 26, v)), f1(lerp(84, 200, v)), 6); } if (u > .6) for (let i = 0; i < 6; i++) anti(g, 220 + i * 20, 246, 'D', .8); }
      if (s === 2 || s === 3) { for (let i = 0; i < 8; i++) { const v = (u * .8 + i / 8) % 1; anti(g, f1(lerp(250, 150, v)), f1(lerp(240, 90, v) + Math.sin(i) * 10), 'D', .9, PI + .6); } if (s === 3) for (let i = 0; i < 6; i++) { const a = i * 1.05 + u * 2, r = 10 + u * 14; E('circle', { cx: f1(116 + Math.cos(a) * r), cy: f1(124 + Math.sin(a) * r), r: 2, fill: '#c0392b', opacity: f1(1 - u * .6) }, g); } }
      if (s === 4) { for (let i = 0; i < 5; i++) { const v = cl(u * 1.4 - i * .1); B.rbcFace(g, 230 + i * 24, 196, 6); anti(g, 230 + i * 24, f1(lerp(250, 206, v)), 'D', .8); } } }
  }));
})();
