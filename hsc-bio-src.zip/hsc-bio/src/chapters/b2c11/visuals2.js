/* ═══════════════════════════════════════════════════════════════════
   visuals2 — দ্বিসংকর ক্রস, ক্রোমোজোম তত্ত্ব, অসম্পূর্ণ প্রকটতা ও সমপ্রকটতা:
   dihybrid, dihybridGrid, chromTheory, incompleteDom, codominance
   সহায়ক: B.mirabilis (সন্ধ্যামালতীর ফুল, সম্মুখদৃশ্য), B.cellC (কোষ)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B211, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v)), ez = t => t * t * (3 - 2 * t);
const seedOf = gt => ({ wr: !/R/.test(gt), col: /Y/.test(gt) ? 'y' : 'g' });
const phen = gt => (/R/.test(gt) ? 'গোল' : 'কুঞ্চিত') + ' ' + (/Y/.test(gt) ? 'হলুদ' : 'সবুজ');

/* ═════════ দ্বিসংকর ক্রস ═════════ */
const DH = [
  { t: 'P প্রজন্ম', en: 'Parents', d: 'বিশুদ্ধ গোল-হলুদ (RRYY) ও বিশুদ্ধ কুঞ্চিত-সবুজ (rryy) বীজের গাছের মধ্যে ক্রস — দুটি বৈশিষ্ট্য একসাথে বিবেচনা (দ্বিসংকর)।' },
  { t: 'P এর গ্যামেট', en: 'Gametes', d: 'প্রতিটি গ্যামেট প্রতিটি জোড়ার একটি করে ফ্যাক্টর পায়: RRYY থেকে শুধু RY, rryy থেকে শুধু ry।' },
  { t: 'F1 প্রজন্ম', en: 'F1 dihybrid', d: 'সব সন্তান RrYy — গোল ও হলুদ। দুই প্রকট বৈশিষ্ট্যই প্রকাশিত।' },
  { t: 'F1 এর গ্যামেট', en: 'Independent assortment', d: 'RrYy থেকে চার রকম গ্যামেট সমান হারে: RY, Ry, rY, ry (প্রতিটি 1/4)। এক জোড়ার ফ্যাক্টর অন্য জোড়ার ফ্যাক্টরের সাথে স্বাধীনভাবে মেশে — এটিই স্বাধীন সঞ্চারণ।' },
  { t: 'F2 প্রজন্ম', en: 'F2 ratio', d: '16টি সমান সম্ভাব্য মিলনে 4 রকম ফিনোটাইপ — 9 গোল-হলুদ : 3 গোল-সবুজ : 3 কুঞ্চিত-হলুদ : 1 কুঞ্চিত-সবুজ; জিনোটাইপ 9 রকম। মেন্ডেল পেয়েছিলেন 315 : 108 : 101 : 32 (মোট 556)।' }
];
V.dihybrid = Object.assign({ t: 'দ্বিসংকর ক্রস ও মেন্ডেলের দ্বিতীয় সূত্র', k: ['2d', 'anim', 'steps'], cap: 'মেন্ডেলের দ্বিতীয় সূত্র (স্বাধীন সঞ্চারণ সূত্র): দুই বা ততোধিক জোড়া বিপরীত বৈশিষ্ট্যের ক্রসে গ্যামেট তৈরির সময় প্রতিটি জোড়ার ফ্যাক্টর অন্য জোড়ার ফ্যাক্টর থেকে স্বাধীনভাবে পৃথক হয় ও এলোমেলোভাবে গ্যামেটে যায়। ফলে F<sub>2</sub> তে 9 : 3 : 3 : 1 অনুপাত — যা আসলে দুটি স্বাধীন 3 : 1 এর গুণফল (3 : 1)<sup>2</sup>। শর্ত: জিন দুটি ভিন্ন ক্রোমোজোমে (বা অনেক দূরে) থাকতে হবে।' },
  BK.steps({ W: 360, H: 290, label: 'দ্বিসংকর ক্রস', dur: 3.2, stages: DH,
    draw(g, C, s, u) {
      B.cacheG(g, 'dhb' + s, gg => { B.tx(gg, 8, 18, ['P', 'P এর গ্যামেট', 'F<sub>1</sub>', 'F<sub>1</sub> এর গ্যামেট', 'F<sub>2</sub>'][s], { fs: 12, w: 700, c: '#a8201a' });
        if (s <= 1) { [[90, 'RRYY', {}], [270, 'rryy', { wr: true, col: 'g' }]].forEach(([x, gt, o]) => { [[-14, -6], [12, -10], [0, 14]].forEach(([dx, dy], i) => B.peaSeed(gg, x + dx, 84 + dy, 15, Object.assign({ a: i }, o))); B.gt(gg, x, 126, gt, { a: 'middle', c: o.wr ? '#7a3a5a' : '#2e6a3e' }); B.tx(gg, x, 142, phen(gt), { fs: 10, a: 'middle', c: C.mu }); }); B.tx(gg, 180, 92, '×', { fs: 22, a: 'middle' }); }
        if (s === 2) { B.gam(gg, 120, 54, 16, 'RY', '#2e6a3e', { fs: 11 }); B.gam(gg, 240, 54, 16, 'ry', '#7a3a5a', { fs: 11 }); E('path', { d: 'M132 68L166 104M228 68L194 104', stroke: FK.alpha(C.fg, .5), 'stroke-width': 1.2, 'marker-end': B.mk(gg, FK.alpha(C.fg, .6), 6) }, gg); [[-22, 0], [0, -6], [22, 2], [-10, 20], [12, 22]].forEach(([dx, dy], i) => B.peaSeed(gg, 180 + dx, 150 + dy, 13, { a: i * 1.3 })); B.gt(gg, 180, 204, 'RrYy', { a: 'middle', fs: 14, c: '#2e6a3e' }); B.tx(gg, 180, 222, 'সব গোল-হলুদ', { fs: 10.4, a: 'middle', c: C.fg }); }
        if (s === 3) { B.peaSeed(gg, 180, 70, 22, {}); B.gt(gg, 180, 108, 'RrYy', { a: 'middle', fs: 13, c: '#2e6a3e' }); B.tx(gg, 180, 262, 'প্রতিটি গ্যামেটের সম্ভাবনা 1/2 × 1/2 = 1/4', { fs: 10.4, a: 'middle', w: 700, c: C.fg }); }
        if (s === 4) { const cls = [['RY', 9, 315], ['Ry', 3, 108], ['rY', 3, 101], ['ry', 1, 32]]; cls.forEach(([k, n, m], i) => { const x = 50 + i * 87, sd = seedOf(k); for (let j = 0; j < n; j++) B.peaSeed(gg, x - 24 + (j % 3) * 24, 70 + Math.floor(j / 3) * 24, 10, Object.assign({ a: j }, sd)); B.tx(gg, x, 162, phen(k), { fs: 10, a: 'middle', w: 700, c: C.fg }); B.tx(gg, x, 184, String(n), { fs: 18, a: 'middle', w: 700, c: '#2a5a90' }); B.tx(gg, x, 202, 'মেন্ডেল: ' + m, { fs: 9.6, a: 'middle', c: C.mu }); });
          B.tx(gg, 180, 236, '9 : 3 : 3 : 1', { fs: 16, a: 'middle', w: 700, c: '#a8201a' }); B.tx(gg, 180, 258, '= (3 গোল : 1 কুঞ্চিত) × (3 হলুদ : 1 সবুজ)', { fs: 10.4, a: 'middle', c: C.fg }); B.tx(gg, 180, 276, 'গোল : কুঞ্চিত = 416 : 140 ≈ 3 : 1;  হলুদ : সবুজ = 416 : 140 ≈ 3 : 1', { fs: 9.4, a: 'middle', c: C.mu }); } });
      if (s === 1) { [[90, 'RY', '#2e6a3e'], [270, 'ry', '#7a3a5a']].forEach(([x, a, c]) => { for (let k = 0; k < 3; k++) { const v = cl(u * 1.4 - k * .15); B.gam(g, x - 34 + k * 34, lerp(150, 210, ez(v)), 14, a, c, { fs: 10 }); } }); }
      if (s === 3) { const G = [['RY', '#2e6a3e'], ['Ry', '#5a8a3a'], ['rY', '#9a7a20'], ['ry', '#7a3a5a']]; G.forEach(([a, c], i) => { const v = ez(cl(u * 1.4 - i * .1)), tx = 54 + i * 84; B.gam(g, lerp(180, tx, v), lerp(120, 200, v), 18, a, c, { fs: 12 }); if (v > .9) B.tx(g, tx, 236, '1/4', { fs: 11, a: 'middle', w: 700, c }); }); }
      if (s === 4) { const i = Math.floor(u * 4) % 4; E('rect', { x: 50 + i * 87 - 42, y: 50, width: 84, height: 160, rx: 8, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); } }
  }));

/* ═════════ দ্বিসংকর পানেট বর্গ (4 × 4) ═════════ */
const GM = ['RY', 'Ry', 'rY', 'ry'], KL = { all: null, ry: 'RY', rg: 'Ry', wy: 'rY', wg: 'ry' };
const DG = {
  all: ['সব', '16টি সম্ভাব্য মিলন', 'F<sub>1</sub> (RrYy) এর চার রকম পুং ও চার রকম স্ত্রী গ্যামেটের 4 × 4 = 16টি সমান সম্ভাব্য মিলন। 9 রকম জিনোটাইপ ও 4 রকম ফিনোটাইপ পাওয়া যায়।'],
  ry: ['গোল-হলুদ 9', 'গোল-হলুদ (R_Y_): 9/16', 'অন্তত একটি R ও একটি Y আছে এমন ঘর — জিনোটাইপ: 1 RRYY, 2 RRYy, 2 RrYY, 4 RrYy। কর্ণ বরাবর মাঝের 4টি ঘরে RrYy।'],
  rg: ['গোল-সবুজ 3', 'গোল-সবুজ (R_yy): 3/16', 'জিনোটাইপ: 1 RRyy, 2 Rryy — নতুন সমন্বয় (পুনঃসংযোজিত ফিনোটাইপ), যা P প্রজন্মে ছিল না।'],
  wy: ['কুঞ্চিত-হলুদ 3', 'কুঞ্চিত-হলুদ (rrY_): 3/16', 'জিনোটাইপ: 1 rrYY, 2 rrYy — আরেকটি নতুন সমন্বয়।'],
  wg: ['কুঞ্চিত-সবুজ 1', 'কুঞ্চিত-সবুজ (rryy): 1/16', 'একমাত্র ঘর যেখানে দুটি বৈশিষ্ট্যই প্রচ্ছন্ন সমযুগ্মী — কোণের ঘর।']
};
const cls4 = gt => (/R/.test(gt) ? 'R' : 'r') + (/Y/.test(gt) ? 'Y' : 'y');
const gt4 = (a, b) => B.ord(a[0] + b[0]) + B.ord(a[1] + b[1]);
V.dihybridGrid = Object.assign({}, B.seg({
  id: 'dhg', t: 'দ্বিসংকর পানেট বর্গ', H: 280, def: 'all', types: DG,
  cap: 'বোতাম চেপে প্রতিটি ফিনোটাইপ শ্রেণির ঘরগুলো দেখো। গোল/কুঞ্চিত ও হলুদ/সবুজ আলাদা আলাদাভাবে গুনলে প্রতিটি 12 : 4 = 3 : 1 — অর্থাৎ দুই জোড়া স্বাধীনভাবে বংশানুক্রমিত হয়।',
  art(g, C, ty) { const hl = KL[ty], ki = Object.keys(DG).indexOf(ty); B.cacheG(g, 'dhg' + ki, gg => {
    B.punnett(gg, C, 56, 38, 72, 52, GM, GM, (q, x, y, w, h, i, j) => { const gt = gt4(GM[i], GM[j]), on = !hl || cls4(gt) === hl, gq = on ? q : E('g', { opacity: .22 }, q); B.peaSeed(gq, x + 16, y + 26, 11, Object.assign({ a: i + j }, seedOf(gt))); B.gt(gq, x + 50, y + 30, gt, { a: 'middle', fs: 9.6, c: C.fg }); }, { gfs: 9.6, fill: (i, j) => { const k = cls4(gt4(GM[i], GM[j])); return !hl || k === hl ? ({ RY: '#f6f8e8', Ry: '#eef6e6', rY: '#fbf4e2', ry: '#f2eef6' })[k] : '#fbfbf8'; } });
    B.tx(gg, 200, 16, 'পুং গ্যামেট', { fs: 9.6, a: 'middle', c: '#2a5a90' }); B.tx(gg, 10, 150, 'স্ত্রী', { fs: 9.6, c: '#a8304a' });
    const n = { RY: 9, Ry: 3, rY: 3, ry: 1 }; B.tx(gg, 180, 270, hl ? phen(hl) + ': ' + n[hl] + '/16' : '9 গোল-হলুদ : 3 গোল-সবুজ : 3 কুঞ্চিত-হলুদ : 1 কুঞ্চিত-সবুজ', { fs: 10.6, a: 'middle', w: 700, c: C.fg }); }); },
  anim(g, C, ty, t) { const hl = KL[ty]; const cells = []; for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) if (!hl || cls4(gt4(GM[i], GM[j])) === hl) cells.push([i, j]); const [i, j] = cells[Math.floor(t * 2) % cells.length]; E('rect', { x: 56 + j * 72, y: 38 + i * 52, width: 72, height: 52, fill: 'none', stroke: '#e0a030', 'stroke-width': 2.4 }, g); }
}));

/* ═════════ বংশগতির ক্রোমোজোম তত্ত্ব ═════════ */
const CT = [
  { t: 'দুই জোড়া ক্রোমোজোম', en: 'Diploid cell (RrYy)', d: 'RrYy উদ্ভিদের একটি জননমাতৃকোষ: বড় জোড়ায় R/r, ছোট জোড়ায় Y/y লোকাস। প্রতিটি জোড়ার একটি পিতৃ (নীল), একটি মাতৃ (গোলাপি)। মেন্ডেলের "ফ্যাক্টর জোড়া" = সমসংস্থ ক্রোমোজোমে অ্যালিল জোড়া।' },
  { t: 'মেটাফেজ-I: বিন্যাস ১', en: 'Arrangement 1', d: 'মিয়োসিস-I এ সমসংস্থ জোড়াগুলো বিষুবীয় তলে সাজে। এক বিন্যাসে R ও Y একই দিকে — ফলে গ্যামেট RY ও ry।' },
  { t: 'মেটাফেজ-I: বিন্যাস ২', en: 'Arrangement 2', d: 'সমান সম্ভাবনায় অন্য বিন্যাসে R ও y একই দিকে — ফলে গ্যামেট Ry ও rY। কোন জোড়া কোন দিকে মুখ করবে তা অন্য জোড়ার ওপর নির্ভর করে না — এটিই স্বাধীন সঞ্চারণের কোষীয় ভিত্তি।' },
  { t: 'অ্যানাফেজ-I: পৃথকীকরণ', en: 'Segregation', d: 'সমসংস্থ ক্রোমোজোম বিপরীত মেরুতে যায় — R থেকে r, Y থেকে y আলাদা হয়। এটিই মেন্ডেলের পৃথকীকরণ সূত্রের কোষীয় ভিত্তি।' },
  { t: 'চার রকম গ্যামেট', en: 'Four gamete types', d: 'অনেক কোষ মিলিয়ে চার রকম গ্যামেট সমান হারে: RY, ry, Ry, rY। সাটন ও বোভেরি (1902–1903) এভাবে দেখান যে মেন্ডেলের ফ্যাক্টরের আচরণ ক্রোমোজোমের আচরণের সাথে হুবহু মেলে — জিন ক্রোমোজোমে থাকে।' }
];
/* ক্রোমোজোম + অ্যালিল চিহ্ন */
const chA = (g, x, y, h, tone, al, u0 = .3) => { const c = B.chrom(g, x, y, h, { tone, w: 9, cen: .45, bands: [] }), yy = y + h * u0; E('rect', { x: x - 4.5, y: yy - 3, width: 9, height: 6, fill: tone === 'chrA' ? '#2a4a8a' : '#b03a4a' }, g); B.gt(g, x + 9, yy + 4, al, { fs: 11, c: tone === 'chrA' ? '#2a4a8a' : '#b03a4a' }); };
V.chromTheory = Object.assign({ t: 'বংশগতির ক্রোমোজোম তত্ত্ব', k: ['2d', 'anim', 'steps'], cap: 'সাটন-বোভেরির ক্রোমোজোম তত্ত্ব: জিন ক্রোমোজোমে নির্দিষ্ট লোকাসে থাকে; সমসংস্থ ক্রোমোজোম জোড়ায় থাকে এবং মিয়োসিসে পৃথক হয় (পৃথকীকরণ); ভিন্ন জোড়া স্বাধীনভাবে বিন্যস্ত হয় (স্বাধীন সঞ্চারণ); নিষেকে জোড়া আবার পূর্ণ হয়। পরে মরগান (1910) ড্রসোফিলার সাদা চোখের জিনকে X ক্রোমোজোমে স্থাপন করে তত্ত্বটি প্রমাণ করেন।' },
  BK.steps({ W: 360, H: 270, label: 'ক্রোমোজোম তত্ত্ব', dur: 3.2, stages: CT,
    draw(g, C, s, u) { const cx = 180, cy = 136;
      B.cacheG(g, 'ctl' + s, gl => B.tx(gl, 8, 18, CT[s].t, { fs: 11, w: 700, c: '#a8201a' }));
      if (s <= 3) { B.cacheG(g, 'ctc', gg => { E('path', { d: B.ellD(cx, cy, 150, 108, 0), fill: '#fbf3ec', stroke: '#c0a088', 'stroke-width': 1.2 }, gg); }); }
      if (s === 0) { B.cacheG(g, 'ct0', gg => { chA(gg, 120, 70, 120, 'chrA', 'R'); chA(gg, 146, 76, 120, 'chrB', 'r'); chA(gg, 220, 100, 64, 'chrA', 'Y', .35); chA(gg, 246, 96, 64, 'chrB', 'y', .35); B.tx(gg, 133, 214, 'বড় জোড়া', { fs: 9.6, a: 'middle', c: C.mu }); B.tx(gg, 233, 186, 'ছোট জোড়া', { fs: 9.6, a: 'middle', c: C.mu }); }); }
      if (s >= 1 && s <= 3) { const arr = s === 2 ? 1 : 0, sep = s === 3 ? ez(cl(u * 1.2)) * 46 : 0;
        if (s < 3) E('path', { d: `M${cx} 36V236`, stroke: FK.alpha('#8a6a4a', .4), 'stroke-width': 1, 'stroke-dasharray': '4 4' }, g);
        /* স্পিন্ডল */ E('path', { d: `M40 ${cy}L${cx - 14} 80M40 ${cy}L${cx - 14} 190M320 ${cy}L${cx + 14} 80M320 ${cy}L${cx + 14} 190`, stroke: FK.alpha('#8a8a6a', .35), 'stroke-width': .8 }, g);
        /* বড় জোড়া (ওপরে) ও ছোট জোড়া (নিচে); arr 0: R ও Y বাঁয়ে */
        const L1 = arr === 0 ? ['chrA', 'R'] : ['chrA', 'R'], R1 = ['chrB', 'r'], L2 = arr === 0 ? ['chrA', 'Y'] : ['chrB', 'y'], R2 = arr === 0 ? ['chrB', 'y'] : ['chrA', 'Y'];
        chA(g, cx - 10 - sep, 50, 90, L1[0], L1[1]); chA(g, cx + 10 + sep, 50, 90, R1[0], R1[1]); chA(g, cx - 10 - sep, 160, 56, L2[0], L2[1], .35); chA(g, cx + 10 + sep, 160, 56, R2[0], R2[1], .35);
        B.cacheG(g, 'cts' + s, gg => { if (s < 3) B.tx(gg, cx, 254, 'বিষুবীয় তল', { fs: 9.4, a: 'middle', c: '#8a6a4a' }); const gm = arr === 0 ? ['RY', 'ry'] : ['Ry', 'rY']; B.gam(gg, 40, 236, 15, gm[0], '#2a5a90', { fs: 10 }); B.gam(gg, 320, 236, 15, gm[1], '#a8304a', { fs: 10 }); }); }
      if (s === 4) B.cacheG(g, 'ct4', gg => { [['RY', 'chrA', 'R', 'chrA', 'Y'], ['ry', 'chrB', 'r', 'chrB', 'y'], ['Ry', 'chrA', 'R', 'chrB', 'y'], ['rY', 'chrB', 'r', 'chrA', 'Y']].forEach(([k, t1, a1, t2, a2], i) => { const x = 50 + i * 87; E('path', { d: B.ellD(x, 120, 36, 52, 0), fill: '#fbf3ec', stroke: '#c0a088', 'stroke-width': 1 }, gg); chA(gg, x - 10, 80, 60, t1, a1); chA(gg, x + 8, 110, 36, t2, a2, .35); B.gt(gg, x, 196, k, { a: 'middle', fs: 13, c: C.fg }); B.tx(gg, x, 214, '1/4', { fs: 10.4, a: 'middle', w: 700, c: '#2a5a90' }); }); B.tx(gg, 180, 250, 'বিন্যাস ১ → RY, ry;  বিন্যাস ২ → Ry, rY', { fs: 10.4, a: 'middle', w: 700, c: C.fg }); });
      if (s === 4) { const i = Math.floor(u * 8) % 4; E('path', { d: B.ellD(50 + i * 87, 120, 40, 56, 0), fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); } }
  }));

/* ─── সন্ধ্যামালতী ফুল (সম্মুখদৃশ্য): পাঁচ খাঁজের যুক্ত পাপড়ি, নল, পুংকেশর ─── */
B.mirabilis = (g, x, y, r, tone) => { x = +x; y = +y; const t = B.TS(tone), P = []; for (let i = 0; i < 60; i++) { const a = i / 60 * 2 * PI - PI / 2, rr = r * (.9 + .1 * Math.cos(a * 5 + PI / 2 * 5)); P.push([x + Math.cos(a) * rr, y + Math.sin(a) * rr]); }
  E('path', { d: sm(P, true, .5), fill: B.vol(g, tone, { cx: .5, cy: .5, r: .6 }), stroke: t.dk, 'stroke-width': .8 }, g);
  let v = ''; for (let i = 0; i < 5; i++) { const a = -PI / 2 + PI / 5 + i * 2 * PI / 5; v += `M${f1(x + Math.cos(a) * r * .2)} ${f1(y + Math.sin(a) * r * .2)}L${f1(x + Math.cos(a) * r * .86)} ${f1(y + Math.sin(a) * r * .86)}`; } E('path', { d: v, stroke: FK.alpha(t.dk, .35), 'stroke-width': .8 }, g);
  E('circle', { cx: x, cy: y, r: r * .2, fill: t.dk, opacity: .55 }, g); for (let i = 0; i < 5; i++) { const a = i * 1.26 + .3; E('path', { d: `M${f1(x)} ${f1(y)}L${f1(x + Math.cos(a) * r * .42)} ${f1(y + Math.sin(a) * r * .42)}`, stroke: '#e8d8a0', 'stroke-width': .8 }, g); E('circle', { cx: f1(x + Math.cos(a) * r * .44), cy: f1(y + Math.sin(a) * r * .44), r: 1.6, fill: '#f0d040' }, g); } };
const FCOL = { RR: 'rflw', Rr: 'pkflw', rr: 'wflw' }, FN = { RR: 'লাল', Rr: 'গোলাপি', rr: 'সাদা' };

/* ═════════ অসম্পূর্ণ প্রকটতা ═════════ */
const ID = {
  p: ['P ও F1', 'লাল × সাদা → গোলাপি', 'সন্ধ্যামালতী (Mirabilis jalapa) গাছে লাল (RR) ও সাদা (rr) ফুলের গাছের ক্রসে F<sub>1</sub> এর সব ফুল গোলাপি (Rr) — কোনো অ্যালিলই পূর্ণ প্রকট নয়; ফিনোটাইপ দুই পিতামাতার মাঝামাঝি। কারণ: R অ্যালিল লাল রঞ্জক তৈরির এনজাইম দেয়, একটি মাত্র R থাকলে রঞ্জক অর্ধেক তৈরি হয়। কার্ল কোরেন্স (1903) এ পরীক্ষা করেন।'],
  f2: ['F2', 'F2: 1 লাল : 2 গোলাপি : 1 সাদা', 'F<sub>1</sub> গোলাপি গাছের স্ব-পরাগায়নে F<sub>2</sub> তে 1 লাল : 2 গোলাপি : 1 সাদা — এখানে ফিনোটাইপ ও জিনোটাইপ অনুপাত একই (1 : 2 : 1), কারণ প্রতিটি জিনোটাইপ আলাদা ফিনোটাইপ দেয়। লাল ও সাদা রং আবার ফিরে আসা প্রমাণ করে অ্যালিল মিশে যায়নি — মেন্ডেলের পৃথকীকরণ সূত্র ঠিকই আছে, শুধু প্রকটতা অসম্পূর্ণ।']
};
V.incompleteDom = Object.assign({}, B.seg({
  id: 'idm', t: 'অসম্পূর্ণ প্রকটতা: সন্ধ্যামালতী', H: 270, def: 'p', types: ID,
  cap: 'অসম্পূর্ণ প্রকটতায় অসমযুগ্মী (Rr) জীবের ফিনোটাইপ দুই সমযুগ্মীর মাঝামাঝি। অন্য উদাহরণ: স্ন্যাপড্রাগন (Antirrhinum) এর ফুলের রং, আন্দালুসীয় মুরগির পালকের রং।',
  art(g, C, ty) { B.cacheG(g, 'idm' + (ty === 'p' ? 0 : 1), gg => {
    if (ty === 'p') { B.mirabilis(gg, 80, 76, 34, 'rflw'); B.mirabilis(gg, 280, 76, 34, 'wflw'); B.gt(gg, 80, 130, 'RR', { a: 'middle', c: '#a8201a' }); B.gt(gg, 280, 130, 'rr', { a: 'middle', c: '#6a6a7a' }); B.tx(gg, 180, 84, '×', { fs: 22, a: 'middle' }); B.tx(gg, 80, 146, 'লাল', { fs: 10, a: 'middle', c: C.mu }); B.tx(gg, 280, 146, 'সাদা', { fs: 10, a: 'middle', c: C.mu });
      E('path', { d: 'M100 156L160 186M260 156L200 186', stroke: FK.alpha(C.fg, .4), 'stroke-width': 1.2, 'marker-end': B.mk(gg, FK.alpha(C.fg, .5), 6) }, gg); [[-56, 0], [0, -6], [56, 0]].forEach(([dx, dy]) => B.mirabilis(gg, 180 + dx, 214 + dy, 24, 'pkflw')); B.gt(gg, 180, 260, 'F<tspan baseline-shift="sub" font-size="75%">1</tspan>: Rr — সব গোলাপি', { a: 'middle', c: '#b0506a' }); }
    else { B.punnett(gg, C, 120, 44, 80, 80, ['R', 'r'], ['R', 'r'], (q, x, y, w, h, i, j) => { const gt = B.ord('Rr'[i] + 'Rr'[j]); B.mirabilis(q, x + w / 2, y + h / 2 - 8, 24, FCOL[gt]); B.gt(q, x + w / 2, y + h - 6, gt, { a: 'middle', fs: 11 }); });
      [['RR', 1], ['Rr', 2], ['rr', 1]].forEach(([k, n], i) => { const x = 70 + i * 110; E('rect', { x: x - 44, y: 220, width: 88, height: 40, rx: 8, fill: FK.alpha('#b0506a', .06), stroke: FK.alpha('#b0506a', .3) }, gg); B.tx(gg, x, 238, n + ' ' + FN[k], { fs: 11, a: 'middle', w: 700, c: C.fg }); B.gt(gg, x, 254, k, { a: 'middle', fs: 10.4, c: C.mu }); }); } }); },
  anim(g, C, ty, t) { if (ty === 'p') { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx: 180, cy: 208, r: f1(30 + k * 3), fill: 'none', stroke: '#b0506a', 'stroke-width': 1, opacity: f1(.3 + k * .4) }, g); } else { const i = Math.floor(t * 1.2) % 4; E('rect', { x: 120 + (i & 1) * 80, y: 44 + (i >> 1) * 80, width: 80, height: 80, fill: 'none', stroke: '#e0a030', 'stroke-width': 2.4 }, g); } }
}));

/* ═════════ সমপ্রকটতা ═════════ */
const CD = {
  roan: ['রোন গবাদি পশু', 'শর্টহর্ন গরুর রোন রং', 'লাল (RR) ও সাদা (WW) লোমের শর্টহর্ন গরুর ক্রসে F<sub>1</sub> (RW) রোন — লোম গোলাপি নয়, বরং লাল ও সাদা লোম পাশাপাশি মিশে থাকে। দুই অ্যালিলই নিজ নিজ বৈশিষ্ট্য পূর্ণভাবে প্রকাশ করে — এটি সমপ্রকটতা। F<sub>2</sub> তে 1 লাল : 2 রোন : 1 সাদা।'],
  ab: ['AB রক্তের গ্রুপ', 'মানুষের AB রক্তের গ্রুপ', 'I<sup>A</sup> অ্যালিল লোহিত কণিকার গায়ে A অ্যান্টিজেন এবং I<sup>B</sup> অ্যালিল B অ্যান্টিজেন তৈরি করে। I<sup>A</sup>I<sup>B</sup> জিনোটাইপের মানুষের কণিকায় দুটি অ্যান্টিজেনই পূর্ণ মাত্রায় থাকে — মাঝামাঝি নয়, বরং দুটিই একসাথে। তাই AB গ্রুপ সমপ্রকটতার আদর্শ উদাহরণ। MN রক্তের গ্রুপও (L<sup>M</sup>L<sup>N</sup>) এমন।']
};
const hairs = (g, x0, y0, w, h, cols, seed) => { const byC = {}; for (let i = 0; i < 150; i++) { const x = x0 + 4 + B.rnd(seed + i) * (w - 30), y = y0 + 10 + B.rnd(seed + i + 99) * (h - 26), a = -PI / 2 + 1.1 + (B.rnd(seed + i * 3) - .5) * .35, L = h * (.16 + B.rnd(seed + i * 7) * .1), c = cols[Math.floor(B.rnd(seed + i * 11) * cols.length)]; (byC[c] = byC[c] || []).push(`M${f1(x)} ${f1(y)}q${f1(Math.cos(a) * L * .5 + 3)} ${f1(Math.sin(a) * L * .5)} ${f1(Math.cos(a) * L)} ${f1(Math.sin(a) * L)}`); } Object.entries(byC).forEach(([c, d]) => E('path', { d: d.join(''), stroke: c, 'stroke-width': 1.1, fill: 'none', 'stroke-linecap': 'round' }, g)); };
const rbcAg = (g, x, y, r, ags) => { E('path', { d: B.ellD(x, y, r, r * .9, 0), fill: B.rbcG(g), stroke: '#8a2a2a', 'stroke-width': .8 }, g); E('path', { d: B.ellD(x, y, r * .45, r * .38, 0), fill: FK.alpha('#8a2a2a', .15) }, g); const n = 12; for (let i = 0; i < n; i++) { const a = i / n * 2 * PI, k = ags[i % ags.length], px = x + Math.cos(a) * (r + 4), py = y + Math.sin(a) * (r * .9 + 4); E('path', { d: `M${f1(x + Math.cos(a) * r)} ${f1(y + Math.sin(a) * r * .9)}L${f1(px)} ${f1(py)}`, stroke: '#6a5a4a', 'stroke-width': .8 }, g); if (k === 'A') E('path', { d: `M${f1(px - 3.4)} ${f1(py + 2.6)}L${f1(px)} ${f1(py - 3.4)}L${f1(px + 3.4)} ${f1(py + 2.6)}Z`, fill: '#2a7ac0', stroke: '#1a4a80', 'stroke-width': .5 }, g); if (k === 'B') E('circle', { cx: f1(px), cy: f1(py), r: 3, fill: '#e0a020', stroke: '#8a6010', 'stroke-width': .5 }, g); } };
V.codominance = Object.assign({}, B.seg({
  id: 'cdm', t: 'সমপ্রকটতা (সহপ্রকটতা)', H: 260, def: 'ab', types: CD,
  cap: 'সমপ্রকটতায় অসমযুগ্মী জীবে দুটি অ্যালিলই একসাথে ও পূর্ণভাবে প্রকাশিত হয় — অসম্পূর্ণ প্রকটতার মতো মাঝামাঝি "মিশ্র" নয়। ফিনোটাইপ ও জিনোটাইপ অনুপাত দুটিই 1 : 2 : 1।',
  art(g, C, ty) { B.cacheG(g, 'cdm' + (ty === 'roan' ? 0 : 1), gg => {
    const X = [62, 180, 298];
    if (ty === 'roan') { [['#a8401a', '#8a2a10'], ['#a8401a', '#f6f2ea', '#8a2a10', '#ece6da'], ['#f6f2ea', '#e4ddd0']].forEach((cols, i) => { const x = X[i]; E('rect', { x: x - 48, y: 40, width: 96, height: 110, rx: 10, fill: '#e8c8a8', stroke: '#b08060', 'stroke-width': .8 }, gg); E('path', { d: `M${x - 48} 150H${x + 48}`, stroke: '#b08060' }, gg); hairs(gg, x - 46, 44, 92, 104, cols, i * 31 + 5); }); [['RR', 'লাল'], ['RW', 'রোন'], ['WW', 'সাদা']].forEach(([k, n], i) => { B.gt(gg, X[i], 172, k, { a: 'middle', c: C.fg }); B.tx(gg, X[i], 190, n, { fs: 11, a: 'middle', w: 700, c: C.fg }); }); B.tx(gg, 180, 214, 'লোমের নিকটদৃশ্য (চামড়ার ছোট অংশ)', { fs: 9.6, a: 'middle', c: C.mu }); B.tx(gg, 180, 240, 'রোন: লাল ও সাদা লোম পাশাপাশি — দুই অ্যালিলই প্রকাশিত', { fs: 10.4, a: 'middle', w: 700, c: '#8a4a2a' }); }
    else { [['A'], ['A', 'B'], ['B']].forEach((ags, i) => rbcAg(gg, X[i], 90, 34, ags)); [['I<tspan baseline-shift="super" font-size="70%">A</tspan>I<tspan baseline-shift="super" font-size="70%">A</tspan>', 'A গ্রুপ'], ['I<tspan baseline-shift="super" font-size="70%">A</tspan>I<tspan baseline-shift="super" font-size="70%">B</tspan>', 'AB গ্রুপ'], ['I<tspan baseline-shift="super" font-size="70%">B</tspan>I<tspan baseline-shift="super" font-size="70%">B</tspan>', 'B গ্রুপ']].forEach(([k, n], i) => { B.gt(gg, X[i], 156, k, { a: 'middle', fs: 13, c: C.fg }); B.tx(gg, X[i], 174, n, { fs: 11, a: 'middle', w: 700, c: C.fg }); });
      E('path', { d: 'M24 204l4 -7l4 7z', fill: '#2a7ac0' }, gg); B.tx(gg, 38, 206, 'A অ্যান্টিজেন', { fs: 9.8, c: '#1a4a80' }); E('circle', { cx: 134, cy: 202, r: 3.4, fill: '#e0a020' }, gg); B.tx(gg, 142, 206, 'B অ্যান্টিজেন', { fs: 9.8, c: '#8a6010' }); B.tx(gg, 180, 236, 'AB কণিকায় A ও B দুই অ্যান্টিজেনই পূর্ণভাবে উপস্থিত', { fs: 10.4, a: 'middle', w: 700, c: C.fg }); } }); },
  anim(g, C, ty, t) { const k = .5 + .5 * Math.sin(t * 2.2); E('rect', { x: 180 - 56, y: 32, width: 112, height: 166, rx: 12, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.4, opacity: f1(.25 + k * .55) }, g); }
}));
})();
