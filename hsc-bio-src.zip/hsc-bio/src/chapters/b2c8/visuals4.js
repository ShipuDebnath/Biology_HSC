/* ═══════════════════════════════════════════════════════════════════
   visuals4 — চোখ: eyeSection, retina, accommodation, pupil, eyeDefects  (+ B.eyeH)
   মাপ: 1 মিলিমিটার = 8 একক (s = 1); অক্ষীয় দৈর্ঘ্য প্রায় 24 মিলিমিটার, কর্নিয়ার বক্রতা-ব্যাসার্ধ প্রায় 7.9 মিলিমিটার
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B28, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const pol = (r, deg) => [r * Math.cos(deg * PI / 180), r * Math.sin(deg * PI / 180)];
const arcD = (r, a0, a1, n = 40) => { let d = ''; for (let i = 0; i <= n; i++) { const [x, y] = pol(r, a0 + (a1 - a0) * i / n); d += (i ? 'L' : 'M') + f1(x) + ' ' + f1(y); } return d; };
const ringD = (r0, r1, a0, a1) => { const o = arcD(r1, a0, a1), i = arcD(r0, a1, a0).replace('M', 'L'); return o + i + 'Z'; };
/* লেন্স: সামনের তল কম বাঁকা, পেছনের তল বেশি — k = উপযোজন (1 শিথিল … 1.35 সর্বোচ্চ) */
const lensD = (cx, k = 1) => { const ry = 37 / Math.sqrt(k), a = 14 * k, p = 18 * k; return `M${f1(cx)} ${f1(-ry)}C${f1(cx - a)} ${f1(-ry * .7)} ${f1(cx - a)} ${f1(ry * .7)} ${f1(cx)} ${f1(ry)}C${f1(cx + p)} ${f1(ry * .7)} ${f1(cx + p)} ${f1(-ry * .7)} ${f1(cx)} ${f1(-ry)}Z`; };
const CORN_C = -40.4, CORN_R = 63.6;
/* o: { x, y, s, P(part), lensK, axial, cloudy, iol, pupil (মিমি), muscles, label } */
B.eyeH = (g, C, o = {}) => { const s = o.s || 1, ax = o.axial || 1, k = o.lensK || 1, P = o.P || (() => g), tr = `translate(${o.x || 0} ${o.y || 0}) scale(${s})`;
  const G = {}, Q = n => G[n] || (G[n] = E('g', { transform: tr }, P(n))), post = n => { const q = Q(n); return ax === 1 ? q : E('g', { transform: `translate(-60 0) scale(${ax} 1) translate(60 0)` }, q); };
  if (o.muscles) [-1, 1].forEach(sd => { const [x0, y0] = pol(96, sd * 118); E('path', { d: B.ribbon([[x0 - 2, y0 + sd * 2], [x0 + 40, y0 - sd * 6], [x0 + 110, y0 - sd * 2], [176, sd * 50]], u => 10 + u * 6), fill: B.vol(Q('mus'), 'mus'), stroke: B.TS('mus').dk, 'stroke-width': .7 }, Q('mus')); });
  /* দর্শন স্নায়ু */ const on = post('opt'); const [nx, ny] = pol(92, 12); E('path', { d: `M${f1(nx - 6)} ${f1(ny - 16)}Q${f1(nx + 30)} ${f1(ny - 14)} 176 ${f1(ny - 12)}V${f1(ny + 14)}Q${f1(nx + 30)} ${f1(ny + 16)} ${f1(nx - 6)} ${f1(ny + 16)}Z`, fill: B.vol(on, 'dura'), stroke: B.TS('dura').dk, 'stroke-width': .8 }, on);
  E('path', { d: `M${f1(nx)} ${f1(ny - 11)}Q${f1(nx + 30)} ${f1(ny - 10)} 176 ${f1(ny - 9)}V${f1(ny + 10)}Q${f1(nx + 30)} ${f1(ny + 11)} ${f1(nx)} ${f1(ny + 11)}Z`, fill: B.TS('nrv').lt, stroke: B.TS('nrv').dk, 'stroke-width': .5 }, on); E('path', { d: `M${f1(nx - 10)} ${f1(ny - 1)}H176M${f1(nx - 10)} ${f1(ny + 2.4)}H176`, stroke: B.TS('art').c, 'stroke-width': 1.4 }, on); E('path', { d: `M${f1(nx - 10)} ${f1(ny + 2.4)}H176`, stroke: B.TS('vein').c, 'stroke-width': 1.4 }, on);
  /* স্ক্লেরা, কোরয়েড, রেটিনা */ const sc = post('scl'); E('path', { d: ringD(90, 96, -151, 151), fill: B.vol(sc, 'scl'), stroke: B.TS('scl').dk, 'stroke-width': .8 }, sc);
  E('path', { d: ringD(86.4, 90, -128, 128), fill: B.TS('cho').c, stroke: 'none' }, post('cho'));
  E('path', { d: ringD(82, 86.4, -128, 128), fill: B.TS('ret').c, stroke: B.TS('ret').dk, 'stroke-width': .4 }, post('ret'));
  /* ভিট্রিয়াস */ E('path', { d: arcD(82, -128, 128) + `L${f1(-50)} ${f1(-40)}Q-40 0 -50 40Z`, fill: FK.alpha(B.TS('vit').c, .85), stroke: 'none' }, post('vit'));
  /* পীতবিন্দু (ফোভিয়া) ও অন্ধবিন্দু */ E('path', { d: `M80 -9Q76 0 80 9`, stroke: '#e8c020', 'stroke-width': 3.4, fill: 'none' }, post('fov')); E('path', { d: `M${f1(nx - 12)} ${f1(ny - 9)}Q${f1(nx - 18)} ${f1(ny)} ${f1(nx - 12)} ${f1(ny + 9)}`, stroke: '#f8e8c8', 'stroke-width': 4, fill: 'none' }, post('disc'));
  /* সিলিয়ারি বডি */ [-1, 1].forEach(sd => { const pts = [pol(90, sd * 152), [-72, sd * 47], [-66, sd * 52], [-62, sd * 50], [-60, sd * 58], pol(90, sd * 128)]; B.organ(Q('cil'), sm(pts, true, .4), 'cho', { sw: .5, flat: 1 }); E('path', { d: sm([[-74, sd * 46], [-66, sd * 50], [-60, sd * 56]], false, .5), stroke: B.TS('mus').c, 'stroke-width': 2.4, fill: 'none', opacity: .8 }, Q('cil')); });
  /* সাসপেনসরি লিগামেন্ট */ let z = ''; const ly = 37 / Math.sqrt(k); [-1, 1].forEach(sd => { for (let i = 0; i < 5; i++) z += `M${f1(-66 + i * 1.6)} ${f1(sd * (51 - i * .4))}L${f1(-58 + i * 1.6 - 2)} ${f1(sd * (ly - 1))}`; }); E('path', { d: z, stroke: '#a89a7a', 'stroke-width': .5 }, Q('zon'));
  /* লেন্স */ const lg = Q('lens'); B.organ(lg, lensD(-72, k), 'lens', { sw: .8, gr: { cx: .4, cy: .35, r: .8 } }); if (o.cloudy) E('path', { d: lensD(-72, k), fill: '#d8d0b8', opacity: .85 }, lg); if (o.iol) { E('path', { d: lensD(-72, .9), fill: '#eef4ff', stroke: '#6a8ac0', 'stroke-width': .8 }, lg); E('path', { d: 'M-66 -32Q-62 -44 -66 -48M-66 32Q-62 44 -66 48', stroke: '#6a8ac0', 'stroke-width': 1, fill: 'none' }, lg); }
  /* অ্যাকুয়াস রস (সম্মুখ প্রকোষ্ঠ) */ const yl = 46; E('path', { d: `M-84.3 ${-yl}A${CORN_R} ${CORN_R} 0 0 0 -84.3 ${yl}L-77 44V${(o.pupil || 1.75) * 8}L-77 ${-(o.pupil || 1.75) * 8}V-44Z`, fill: FK.alpha(B.TS('vit').c, .9), stroke: 'none' }, Q('aq'));
  /* আইরিস ও তারারন্ধ্র */ const pr = (o.pupil || 1.75) * 8; [-1, 1].forEach(sd => { E('path', { d: `M-78 ${sd * pr}C-80 ${sd * (pr + 8)} -80 ${sd * 30} -80 ${sd * 44}L-74 ${sd * 44}C-74 ${sd * 30} -74 ${sd * (pr + 8)} -75 ${sd * pr}Z`, fill: B.TS('iris').c, stroke: B.TS('iris').dk, 'stroke-width': .6 }, Q('iris')); });
  /* কর্নিয়া ও কনজাংটিভা */ E('path', { d: `M-84.3 -46A${CORN_R} ${CORN_R} 0 0 0 -84.3 46L-80 45.6A${CORN_R - 4} ${CORN_R - 4} 0 0 1 -80 -45.6Z`, fill: B.TS('cor').c, stroke: B.TS('cor').dk, 'stroke-width': .7 }, Q('cor'));
  [-1, 1].forEach(sd => E('path', { d: arcD(97.4, sd * 151, sd * 120), stroke: '#e8a8a8', 'stroke-width': 1.2, fill: 'none' }, Q('conj')));
  /* শ্লেম নালি */ [-1, 1].forEach(sd => E('path', { d: B.ellD(-83, sd * 44, 2, 1.3, 0), fill: B.TS('vein').c }, Q('aq')));
  return B.eyeA(o); };
B.eyeA = (o = {}) => { const s = o.s || 1, ax = o.axial || 1, [nx, ny] = pol(92, 12);
  const A = (x, y) => [(o.x || 0) + s * x, (o.y || 0) + s * y], AP = (x, y) => A(-60 + (x + 60) * ax, y);
  return { cor: A(-98, -20), aq: A(-88, -26), iris: A(-78, 30), pupil: A(-77, 0), lens: A(-66, 10), cil: A(-66, -56), zon: A(-62, -44), conj: A(-86, 54), scl: AP(...pol(93, -60)), cho: AP(...pol(88.2, 70)), ret: AP(...pol(84, 100)), vit: AP(10, -30), fov: AP(79, 0), disc: AP(nx - 15, ny + 4), opt: AP(140, ny), mus: A(40, -98), retX: -60 + 142 * ax }; };


const preset = (ctx, k, v, dig = 0, unit = '') => { ctx.v[k] = v; const el = ctx.root && ctx.root.querySelector ? ctx.root.querySelector(`[data-sl="${k}"]`) : null; if (el) { el.value = v; const o2 = ctx.root.querySelector(`[data-slo="${k}"]`); if (o2) o2.textContent = FK.n(v, dig) + unit; } };

/* ═════════ চোখের অনুভূমিক ছেদ ═════════ */
const EO = { x: 178, y: 150, s: .92, muscles: true }, EA = B.eyeA(EO);
V.eyeSection = Object.assign({ t: 'চোখের গঠন (অনুভূমিক লম্বচ্ছেদ)', k: ['2d', 'anim', 'int', 'quiz'], cap: 'চোখের গোলকের প্রাচীরে তিন স্তর: বাইরে তন্তুময় স্তর (সামনে স্বচ্ছ কর্নিয়া, বাকি সাদা স্ক্লেরা), মাঝে রক্তনালিময় স্তর বা ইউভিয়া (কোরয়েড, সিলিয়ারি বডি, আইরিস) এবং ভেতরে স্নায়ু স্তর (রেটিনা)। লেন্স গোলককে দুই প্রকোষ্ঠে ভাগ করে — সামনে অ্যাকুয়াস রস, পেছনে ভিট্রিয়াস রস। আকার বাস্তবের অনুপাতে (অক্ষীয় দৈর্ঘ্য প্রায় 24 মিলিমিটার)। হলুদ রেখা দূরের আলো — কর্নিয়া (প্রায় দুই-তৃতীয়াংশ প্রতিসরণ) ও লেন্সে বেঁকে পীতবিন্দুতে মিলিত হয়।' },
  BK.diagram({ W: 360, H: 300, label: 'চোখের লম্বচ্ছেদ', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)); B.eyeH(g, C, Object.assign({ P }, EO)); hits(this.parts, part, 8); },
    idle(g, C, t) { const u = (t * .35) % 1, X = x => EO.x + x * EO.s, Y = y => EO.y + y * EO.s; [-24, -10, 10, 24].forEach(h => { const d = `M0 ${f1(Y(h))}L${f1(X(-104 + h * h / 128))} ${f1(Y(h))}L${f1(X(-72))} ${f1(Y(h * .72))}L${f1(X(80))} ${f1(Y(0))}`; E('path', { d, stroke: '#e8b020', 'stroke-width': 1, fill: 'none', opacity: .8, 'stroke-dasharray': '6 4', 'stroke-dashoffset': f1(-u * 40) }, g); }); },
    parts: [
      { id: 'cil', bn: 'সিলিয়ারি বডি ও সিলিয়ারি পেশি', lb: 'সিলিয়ারি বডি', en: 'Ciliary body', fn: 'কোরয়েডের সামনের পুরু অংশ — ভেতরের মসৃণ সিলিয়ারি পেশি সংকুচিত-প্রসারিত হয়ে লেন্সের বক্রতা বদলায় (উপযোজন); সিলিয়ারি প্রবর্ধক অ্যাকুয়াস রস ক্ষরণ করে।', a: EA.cil, l: [72, 64], an: 'end' },
      { id: 'zon', bn: 'সাসপেনসরি লিগামেন্ট (জোনিউল)', lb: 'সাসপেনসরি লিগামেন্ট', en: 'Suspensory ligament', fn: 'লেন্সকে সিলিয়ারি বডির সাথে ঝুলিয়ে রাখা সূক্ষ্ম তন্তু — টানটান হলে লেন্স চ্যাপ্টা, ঢিলা হলে লেন্স গোলাকার হয়।', a: EA.zon, l: [88, 92], an: 'end' },
      { id: 'aq', bn: 'অ্যাকুয়াস রস (সম্মুখ প্রকোষ্ঠ)', lb: 'অ্যাকুয়াস রস', en: 'Aqueous humour', fn: 'কর্নিয়া ও লেন্সের মাঝে পানির মতো স্বচ্ছ তরল — কর্নিয়া ও লেন্সকে পুষ্টি দেয়, চোখের চাপ বজায় রাখে; শ্লেম নালি দিয়ে বের হয়। নিষ্কাশন বাধা পেলে চাপ বেড়ে গ্লুকোমা হয়।', a: EA.aq, l: [72, 120], an: 'end' },
      { id: 'cor', bn: 'কর্নিয়া (অচ্ছোদপটল)', lb: 'কর্নিয়া', en: 'Cornea', fn: 'স্ক্লেরার সামনের স্বচ্ছ, রক্তনালিহীন, উত্তল অংশ — আলো প্রবেশ করে এবং চোখের মোট প্রতিসরণের প্রায় দুই-তৃতীয়াংশ (প্রায় 40 ডায়অপ্টার) এখানে হয়। কর্নিয়া দান করে প্রতিস্থাপন করা যায়।', a: EA.cor, l: [72, 148], an: 'end' },
      { id: 'pupil', bn: 'তারারন্ধ্র (পিউপিল)', lb: 'তারারন্ধ্র', en: 'Pupil', fn: 'আইরিসের মাঝের গোল ছিদ্র — আলো কম-বেশি হলে আইরিসের পেশি এর আকার (প্রায় 2–8 মিলিমিটার) বদলে ভেতরে আলোর পরিমাণ নিয়ন্ত্রণ করে।', a: EA.pupil, l: [72, 176], an: 'end' },
      { id: 'lens', bn: 'লেন্স (মণি)', lb: 'লেন্স', en: 'Lens', fn: 'আইরিসের পেছনে স্বচ্ছ, স্থিতিস্থাপক, দ্বি-উত্তল প্রোটিনের (ক্রিস্টালিন) লেন্স — বক্রতা বদলে কাছের ও দূরের বস্তুর প্রতিবিম্ব রেটিনায় ফেলে। বয়সে অস্বচ্ছ হলে ছানি।', a: EA.lens, l: [72, 204], an: 'end' },
      { id: 'iris', bn: 'আইরিস (কনীনিকা)', lb: 'আইরিস', en: 'Iris', fn: 'রঞ্জকযুক্ত পর্দা — চোখের রং দেয়; বৃত্তাকার (সংকোচক) ও অরীয় (প্রসারক) মসৃণ পেশি দিয়ে তারারন্ধ্রের আকার বদলায়।', a: EA.iris, l: [72, 232], an: 'end' },
      { id: 'conj', bn: 'কনজাংটিভা', lb: 'কনজাংটিভা', en: 'Conjunctiva', fn: 'চোখের পাতার ভেতর ও স্ক্লেরার সামনের অংশ ঢাকা পাতলা স্বচ্ছ শ্লেষ্মা ঝিল্লি — প্রদাহে চোখ লাল (কনজাংটিভাইটিস বা চোখ ওঠা)।', a: EA.conj, l: [72, 260], an: 'end' },
      { id: 'vit', bn: 'ভিট্রিয়াস রস (কাচাভ রস)', lb: 'ভিট্রিয়াস রস', en: 'Vitreous humour', fn: 'লেন্সের পেছনের বড় প্রকোষ্ঠে স্বচ্ছ জেলির মতো পদার্থ — গোলকের আকার ধরে রাখে ও রেটিনাকে জায়গায় চেপে রাখে।', a: EA.vit, l: [140, 18], an: 'middle' },
      { id: 'mus', bn: 'চোখের বহিঃপেশি (রেক্টাস)', lb: 'বহিঃপেশি', en: 'Extraocular muscle', fn: 'প্রতি চোখে 6টি কঙ্কাল পেশি (4টি রেক্টাস, 2টি অবলিক) স্ক্লেরায় যুক্ত — চোখের গোলক ঘোরায়; করোটিক স্নায়ু III, IV ও VI নিয়ন্ত্রণ করে।', a: EA.mus, l: [236, 18], an: 'middle' },
      { id: 'scl', bn: 'স্ক্লেরা (শ্বেতমণ্ডল)', lb: 'স্ক্লেরা', en: 'Sclera', fn: 'বাইরের সাদা, শক্ত, অস্বচ্ছ তন্তুময় স্তর — গোলকের আকার ও সুরক্ষা দেয়, বহিঃপেশি যুক্ত হয়।', a: EA.scl, l: [296, 48], an: 'start' },
      { id: 'fov', bn: 'পীতবিন্দু (ফোভিয়া সেন্ট্রালিস)', lb: 'পীতবিন্দু', en: 'Fovea (yellow spot)', fn: 'লেন্সের ঠিক বিপরীতে রেটিনার ছোট গর্ত — শুধু কোন কোষ, খুব ঘন; সবচেয়ে স্পষ্ট ও রঙিন দেখা এখানে। কিছু পড়তে চোখ এমনভাবে ঘোরাই যাতে প্রতিবিম্ব এখানে পড়ে।', a: EA.fov, l: [296, 120], an: 'start' },
      { id: 'disc', bn: 'অন্ধবিন্দু (অপটিক ডিস্ক)', lb: 'অন্ধবিন্দু', en: 'Blind spot', fn: 'যেখানে স্নায়ুতন্তু ও রক্তনালি রেটিনা ছেড়ে দর্শন স্নায়ুতে যায় — কোনো রড বা কোন নেই, তাই এখানে পড়া প্রতিবিম্ব দেখা যায় না।', a: EA.disc, l: [252, 270], an: 'middle' },
      { id: 'opt', bn: 'দর্শন স্নায়ু (অপটিক নার্ভ)', lb: 'দর্শন স্নায়ু', en: 'Optic nerve', fn: 'প্রায় 10 লক্ষ গ্যাংলিয়ন কোষের অ্যাক্সন — সংকেত মস্তিষ্কের দর্শন কেন্দ্রে নেয়; মাঝ দিয়ে কেন্দ্রীয় রেটিনাল ধমনি ও শিরা চলে। দ্বিতীয় করোটিক স্নায়ু।', a: EA.opt, l: [318, 238], an: 'middle' },
      { id: 'ret', bn: 'রেটিনা (অক্ষিপট)', lb: 'রেটিনা', en: 'Retina', fn: 'সবচেয়ে ভেতরের আলোক-সংবেদী স্নায়ু স্তর — রড (প্রায় 12 কোটি, মৃদু আলো) ও কোন (প্রায় 60 লক্ষ, রং) আলোকে স্নায়ু সংকেতে বদলায়।', a: EA.ret, l: [150, 292], an: 'middle' },
      { id: 'cho', bn: 'কোরয়েড', lb: 'কোরয়েড', en: 'Choroid', fn: 'স্ক্লেরা ও রেটিনার মাঝে রক্তনালি ও কালো রঞ্জকে ভরা স্তর — রেটিনাকে পুষ্টি দেয় এবং বাড়তি আলো শুষে প্রতিফলন রোধ করে (ক্যামেরার কালো ভেতরের মতো)।', a: EA.cho, l: [210, 292], an: 'middle' }
    ]
  }));

/* ═════════ রেটিনার স্তর ═════════ */
const RODX = [24, 36, 60, 72, 96, 108, 132, 144, 168, 180, 204, 216], CONX = [48, 120, 156, 228 - 36];
const rod = (g, x) => { E('rect', { x: x - 2.6, y: 214, width: 5.2, height: 44, rx: 1.4, fill: '#c8a0d8', stroke: '#6a4a88', 'stroke-width': .5 }, g); let d = ''; for (let y = 218; y < 256; y += 3) d += `M${x - 2.4} ${y}h4.8`; E('path', { d, stroke: '#8a6aa8', 'stroke-width': .4 }, g); E('rect', { x: x - 2.4, y: 196, width: 4.8, height: 18, rx: 1, fill: '#f0d8b8', stroke: '#a8805a', 'stroke-width': .5 }, g); E('path', { d: `M${x} 196V164`, stroke: '#a8805a', 'stroke-width': 1.2 }, g); E('path', { d: B.ellD(x, 184 + (x % 24 ? 4 : -2), 2.8, 3.8, 0), fill: B.TS('nuc').c }, g); E('circle', { cx: x, cy: 162, r: 2.2, fill: '#e8c890', stroke: '#a8805a', 'stroke-width': .5 }, g); };
const cone = (g, x) => { E('path', { d: `M${x - 4.6} 214L${x - 1.4} 242H${x + 1.4}L${x + 4.6} 214Z`, fill: '#e8b048', stroke: '#9a6a10', 'stroke-width': .5 }, g); let d = ''; for (let y = 218; y < 240; y += 3) { const w = 4.4 * (1 - (y - 214) / 32); d += `M${x - w} ${y}h${2 * w}`; } E('path', { d, stroke: '#b8801a', 'stroke-width': .4 }, g); E('rect', { x: x - 4.6, y: 194, width: 9.2, height: 20, rx: 3, fill: '#f0d8b8', stroke: '#a8805a', 'stroke-width': .5 }, g); E('path', { d: B.ellD(x, 180, 3.4, 4.4, 0), fill: B.TS('nuc').c }, g); E('path', { d: `M${x} 186V166`, stroke: '#a8805a', 'stroke-width': 1.6 }, g); E('path', { d: `M${x - 4} 162h8l-1 4h-6Z`, fill: '#e8c890', stroke: '#a8805a', 'stroke-width': .5 }, g); };
const BIP = [[42, 'r'], [78, 'c48'], [114, 'r'], [150, 'c120'], [186, 'r']], GAN = [60, 120, 190];
V.retina = Object.assign({ t: 'রেটিনার কোষস্তর', k: ['2d', 'anim', 'int', 'quiz'], cap: 'রেটিনার একটি ছোট অংশের লম্বচ্ছেদ, ওপরে ভিট্রিয়াসের দিক। অবাক করা বিষয়: আলোকে সব স্নায়ু স্তর পেরিয়ে একেবারে পেছনের রড ও কোনে পৌঁছাতে হয় (উল্টো রেটিনা)। সংকেত ফেরে উল্টো দিকে — আলোকগ্রাহক → বাইপোলার কোষ → গ্যাংলিয়ন কোষ → দর্শন স্নায়ু। অনেক রড একটি বাইপোলারে মেলে (মৃদু আলোয় সংবেদী কিন্তু ঝাপসা), প্রতিটি কোন প্রায় নিজস্ব পথ পায় (স্পষ্ট, রঙিন)।' },
  BK.diagram({ W: 360, H: 300, label: 'রেটিনা', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      /* কোরয়েড ও রঞ্জক আবরণী */ E('rect', { x: 12, y: 276, width: 228, height: 24, fill: FK.alpha(B.TS('cho').lt, .7) }, P('cho')); [30, 90, 150, 210].forEach(x => E('path', { d: B.ellD(x, 288, 9, 5, 0), fill: B.TS('art').c, stroke: B.TS('art').dk, 'stroke-width': .5 }, P('cho')));
      E('rect', { x: 12, y: 250, width: 228, height: 26, fill: '#6a4a3a' }, P('rpe')); let mel = ''; for (let i = 0; i < 90; i++) mel += B.ellD(14 + (i * 23) % 224, 252 + (i * 7) % 22, 1, 1, 0); E('path', { d: mel, fill: '#2a1a12' }, P('rpe')); let rb = ''; for (let x = 12; x < 240; x += 19) rb += `M${x} 250V276`; E('path', { d: rb, stroke: '#4a3020', 'stroke-width': .6 }, P('rpe'));
      RODX.forEach(x => rod(P('rod'), x)); CONX.forEach(x => cone(P('cone'), x));
      /* বাইপোলার */ BIP.forEach(([x, t]) => { const gg = P('bip'); const tg = t === 'r' ? RODX.filter(r => Math.abs(r - x) < 22) : [+t.slice(1)]; tg.forEach(tx => E('path', { d: `M${x} 132Q${(x + tx) / 2} 150 ${tx} 160`, stroke: '#6a9a5a', 'stroke-width': 1, fill: 'none' }, gg)); E('path', { d: `M${x} 120V100`, stroke: '#6a9a5a', 'stroke-width': 1.4 }, gg); E('path', { d: B.ellD(x, 126, 4.6, 7, 0), fill: '#b8d8a8', stroke: '#4a7a3a', 'stroke-width': .6 }, gg); E('path', { d: B.ellD(x, 126, 2.4, 3.4, 0), fill: B.TS('nuc').c }, gg); });
      /* আনুভূমিক ও অ্যামাক্রাইন */ E('path', { d: 'M30 152Q100 144 200 152', stroke: '#c07a5a', 'stroke-width': 1.2, fill: 'none' }, P('hz')); E('path', { d: B.ellD(100, 146, 7, 4, 0), fill: '#e8b8a0', stroke: '#a05a3a', 'stroke-width': .6 }, P('hz')); E('path', { d: 'M60 104Q130 98 210 104', stroke: '#c07a5a', 'stroke-width': 1, fill: 'none' }, P('hz')); E('path', { d: B.ellD(134, 110, 6, 4.6, 0), fill: '#e8b8a0', stroke: '#a05a3a', 'stroke-width': .6 }, P('hz'));
      /* গ্যাংলিয়ন কোষ ও স্নায়ুতন্তু */ GAN.forEach((x, i) => { const gg = P('gan'); BIP.filter(([bx]) => Math.abs(bx - x) < 40).forEach(([bx]) => E('path', { d: `M${x} 78Q${(x + bx) / 2} 92 ${bx} 100`, stroke: '#d0a020', 'stroke-width': 1, fill: 'none' }, gg)); E('path', { d: `M${x} 64Q${x - 10} 52 ${x - 30} 50H12`, stroke: '#d0a020', 'stroke-width': 1.6, fill: 'none' }, P('nfl')); B.organ(gg, B.ellD(x, 72, 8, 7, 0), 'axn', { sw: .6 }); E('path', { d: B.ellD(x, 72, 3.4, 3.4, 0), fill: B.TS('nucP').c, stroke: B.TS('nuc').dk, 'stroke-width': .4 }, gg); });
      E('path', { d: 'M12 44H240', stroke: '#9aa8c0', 'stroke-width': 1.4 }, P('nfl')); B.tx(P('nfl'), 14, 40, '← দর্শন স্নায়ুর দিকে', { fs: 8.4, c: C.mu });
      /* আলো */ E('path', { d: 'M246 14V40', stroke: '#e8b020', 'stroke-width': 2.4, 'marker-end': B.mk(g, '#e8b020', 6) }, P('light'));
      hits(this.parts, part, 8); },
    idle(g, C, t) { const u = (t * .45) % 1; if (u < .55) { const y = 16 + u / .55 * 210; [36, 120, 180].forEach(x => E('circle', { cx: x, cy: f1(y), r: 2.4, fill: '#ffd030', opacity: .9 }, g)); } else { const v = (u - .55) / .45, A = B.alongC([[120, 214], [120, 162], [150, 132], [150, 100], [120, 76], [100, 52], [12, 50]]), [x, y] = A(v); E('circle', { cx: f1(x), cy: f1(y), r: 3, fill: '#2a7ad0', stroke: '#fff', 'stroke-width': .8 }, g); } },
    parts: [
      { id: 'light', bn: 'আলো প্রবেশের দিক', lb: 'আলো ↓', en: 'Incoming light', fn: 'আলো ভিট্রিয়াস থেকে এসে স্বচ্ছ স্নায়ু স্তর পেরিয়ে পেছনের আলোকগ্রাহকে পৌঁছায়।', a: [246, 26], l: [262, 22], an: 'start' },
      { id: 'nfl', bn: 'স্নায়ুতন্তু স্তর', lb: 'স্নায়ুতন্তু স্তর', en: 'Nerve fibre layer', fn: 'গ্যাংলিয়ন কোষের অ্যাক্সন রেটিনার ভেতরের তল বরাবর অন্ধবিন্দুতে গিয়ে দর্শন স্নায়ু তৈরি করে।', a: [200, 50], l: [262, 52], an: 'start' },
      { id: 'gan', bn: 'গ্যাংলিয়ন কোষ', lb: 'গ্যাংলিয়ন কোষ', en: 'Ganglion cells', fn: 'বাইপোলার কোষ থেকে সংকেত পেয়ে কার্যবিভব তৈরি করে — রেটিনার একমাত্র কোষ যা কার্যবিভব পাঠায়।', a: [190, 72], l: [262, 78], an: 'start' },
      { id: 'hz', bn: 'আনুভূমিক ও অ্যামাক্রাইন কোষ', lb: 'আনুভূমিক কোষ', en: 'Horizontal, amacrine cells', fn: 'পাশাপাশি কোষগুলোর সংকেত মিলিয়ে বৈপরীত্য (কিনারা) স্পষ্ট করে।', a: [200, 152], l: [262, 152], an: 'start' },
      { id: 'bip', bn: 'বাইপোলার কোষ', lb: 'বাইপোলার কোষ', en: 'Bipolar cells', fn: 'আলোকগ্রাহক ও গ্যাংলিয়ন কোষের মাঝে সংযোগকারী দ্বি-মেরু নিউরন।', a: [186, 126], l: [262, 118], an: 'start' },
      { id: 'cone', bn: 'কোন কোষ (শঙ্কু)', lb: 'কোন কোষ', en: 'Cones', fn: 'শঙ্কু আকৃতির বাইরের খণ্ড — আয়োডপসিন রঞ্জক; উজ্জ্বল আলোয় রং ও সূক্ষ্ম বিবরণ দেখায়। তিন ধরন: লাল, সবুজ, নীল সংবেদী; কোনো ধরন না থাকলে বর্ণান্ধতা।', a: [192, 228], l: [262, 210], an: 'start' },
      { id: 'rod', bn: 'রড কোষ (দণ্ড)', lb: 'রড কোষ', en: 'Rods', fn: 'লম্বা দণ্ডাকার বাইরের খণ্ডে চাকতির স্তূপ — রোডপসিন রঞ্জক (ভিটামিন A থেকে তৈরি); মৃদু আলোয় সাদা-কালো দেখায়। ভিটামিন A এর অভাবে রাতকানা।', a: [216, 236], l: [262, 240], an: 'start' },
      { id: 'rpe', bn: 'রঞ্জক আবরণী', lb: 'রঞ্জক আবরণী', en: 'Pigment epithelium', fn: 'মেলানিনভরা কোষস্তর — অতিরিক্ত আলো শোষণ করে, আলোকগ্রাহকের পুরনো চাকতি খেয়ে ফেলে ও ভিটামিন A জোগায়।', a: [200, 264], l: [262, 268], an: 'start' },
      { id: 'cho', bn: 'কোরয়েড (রক্তনালি)', lb: 'কোরয়েড', en: 'Choroid', fn: 'রেটিনার বাইরের স্তরে রক্ত জোগায়।', a: [210, 288], l: [262, 292], an: 'start' }
    ]
  }));

/* ═════════ উপযোজন ═════════ */
const ACO = { x: 228, y: 120, s: .62 };
const AC = {
  far: ['দূরের বস্তু', 'দূরের বস্তু দেখা (6 মিটার বা বেশি)', 'সিলিয়ারি পেশি শিথিল → সিলিয়ারি বডির বলয় চওড়া → সাসপেনসরি লিগামেন্ট টানটান → লেন্স চ্যাপ্টা ও পাতলা, প্রতিসরণ ক্ষমতা কম। প্রায় সমান্তরাল রশ্মি রেটিনায় মিলিত হয়।'],
  near: ['কাছের বস্তু', 'কাছের বস্তু দেখা (প্রায় 25 সেন্টিমিটার)', 'সিলিয়ারি পেশি সংকুচিত → বলয় ছোট → লিগামেন্ট ঢিলা → স্থিতিস্থাপক লেন্স নিজে থেকে গোলাকার ও মোটা, ক্ষমতা বাড়ে (প্রায় 4 ডায়অপ্টার বেশি)। একই সাথে তারারন্ধ্র ছোট হয় ও দুই চোখ ভেতরে ঘোরে।']
};
V.accommodation = Object.assign({}, B.seg({
  id: 'acc', t: 'উপযোজন: কাছে ও দূরে দেখা', H: 250, def: 'far', types: AC,
  sl: [{ k: 'd', l: 'বস্তুর দূরত্ব (সেমি)', min: 25, max: 600, step: 5, val: 600 }],
  cap: 'লেন্সের বক্রতা বদলে ভিন্ন দূরত্বের বস্তুর প্রতিবিম্ব রেটিনায় ফেলাকে উপযোজন বলে। সুস্থ তরুণ চোখের নিকট বিন্দু প্রায় 25 সেন্টিমিটার, দূর বিন্দু অসীম। প্রয়োজনীয় বাড়তি ক্ষমতা ≈ 100 ÷ দূরত্ব (সেমি) ডায়অপ্টার। বস্তুর দূরত্ব পর্দায় মাপমতো নয়।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; preset(ctx, 'd', ty === 'far' ? 600 : 25); } const d = ctx.v.d, A = 100 / d, k = 1 + Math.min(4, A) / 4 * .32;
    B.eyeH(g, C, Object.assign({ lensK: k }, ACO));
    B.tx(g, 10, 214, `বাড়তি ক্ষমতা ≈ ${FK.n(A, 1)} D`, { fs: 10.4, w: 700, c: '#a8201a' }); B.tx(g, 10, 232, A > 1 ? 'সিলিয়ারি পেশি সংকুচিত, লিগামেন্ট ঢিলা, লেন্স মোটা' : 'সিলিয়ারি পেশি শিথিল, লিগামেন্ট টানটান, লেন্স পাতলা', { fs: 9.2, c: C.mu }); },
  anim(g, C, ty, t, ctx) { const d = ctx.v.d || 600, X = x => ACO.x + x * ACO.s, Y = y => ACO.y + y * ACO.s, u = (t * .4) % 1, xo = 150 - 132 * Math.log(d / 25) / Math.log(24), far = d >= 600;
    if (!far) { E('path', { d: `M${f1(xo)} ${ACO.y}v-20`, stroke: '#2a6ab0', 'stroke-width': 2, 'marker-end': B.mk(g, '#2a6ab0', 5) }, g); E('circle', { cx: f1(xo), cy: ACO.y, r: 2.6, fill: '#2a6ab0' }, g); }
    [-22, -9, 9, 22].forEach(h => { const y0 = far ? Y(h) : ACO.y, x0 = far ? 0 : xo, dd = `M${f1(x0)} ${f1(y0)}L${f1(X(-103))} ${f1(Y(h))}L${f1(X(-72))} ${f1(Y(h * .74))}L${f1(X(80))} ${f1(Y(0))}`; E('path', { d: dd, stroke: '#e8a010', 'stroke-width': 1, fill: 'none', 'stroke-dasharray': '6 4', 'stroke-dashoffset': f1(-u * 40) }, g); });
    E('circle', { cx: f1(X(80)), cy: f1(Y(0)), r: 2.6, fill: '#c0392b' }, g); }
}));

/* ═════════ তারারন্ধ্রের প্রতিবর্ত ═════════ */
const PU = {
  bright: ['উজ্জ্বল আলো', 'উজ্জ্বল আলোয় তারারন্ধ্র ছোট', 'আইরিসের বৃত্তাকার সংকোচক পেশি (স্ফিংক্টার) সংকুচিত হয় — প্যারাসিমপ্যাথেটিক তন্তু, করোটিক স্নায়ু III। রেটিনা অতিরিক্ত আলো থেকে রক্ষা পায়, ছবি আরও তীক্ষ্ণ হয়।'],
  dim: ['আবছা আলো', 'আবছা আলোয় তারারন্ধ্র বড়', 'আইরিসের অরীয় প্রসারক পেশি (ডাইলেটর) সংকুচিত হয় — সিমপ্যাথেটিক তন্তু। বেশি আলো ঢোকে। ভয় বা উত্তেজনায়ও তারারন্ধ্র বড় হয়।']
};
V.pupil = Object.assign({}, B.seg({
  id: 'pup', t: 'আলোর প্রতি তারারন্ধ্রের সাড়া', H: 240, def: 'bright', types: PU,
  sl: [{ k: 'L', l: 'আলোর তীব্রতা', min: 0, max: 100, step: 1, val: 90 }],
  cap: 'আলো এক চোখে পড়লে দুই চোখের তারারন্ধ্রই ছোট হয় (সম্মতিসূচক প্রতিবর্ত) — কেন্দ্র মধ্যমস্তিষ্কে। ডাক্তাররা টর্চ ফেলে এটি পরীক্ষা করেন। সামনে থেকে দেখা চোখ; তারারন্ধ্রের ব্যাস প্রায় 2 থেকে 8 মিলিমিটার।',
  art(g, C, ty, ctx) { if (ctx.last !== ty) { ctx.last = ty; preset(ctx, 'L', ty === 'bright' ? 90 : 10); } const L = ctx.v.L, dmm = 8 - 6 * L / 100, cx = 180, cy = 116, R = 54, pr = dmm / 12 * R * 1.0;
    E('rect', { x: 0, y: 0, width: 360, height: 240, fill: FK.alpha('#ffe9a0', .08 + L / 100 * .4) }, g);
    E('path', { d: `M${cx - 120} ${cy}Q${cx} ${cy - 92} ${cx + 120} ${cy}Q${cx} ${cy + 92} ${cx - 120} ${cy}Z`, fill: '#fbf8f2', stroke: B.TS('skin').dk, 'stroke-width': 1.4 }, g);
    const ig = E('g', {}, g); E('circle', { cx, cy, r: R, fill: B.TS('iris').c, stroke: B.TS('iris').dk, 'stroke-width': 1.2 }, ig); let rad = ''; for (let i = 0; i < 72; i++) { const a = i / 72 * 2 * PI, r0 = pr + 3, r1 = R - 3 - (i % 3) * 2; rad += `M${f1(cx + Math.cos(a) * r0)} ${f1(cy + Math.sin(a) * r0)}L${f1(cx + Math.cos(a + .05) * r1)} ${f1(cy + Math.sin(a + .05) * r1)}`; } E('path', { d: rad, stroke: L < 50 ? '#c09a5a' : '#8a6a3a', 'stroke-width': L < 50 ? 1.1 : .7, opacity: .8 }, ig);
    E('circle', { cx, cy, r: f1(pr + 6), fill: 'none', stroke: L >= 50 ? '#d0a060' : '#7a5a30', 'stroke-width': L >= 50 ? 4 : 2, opacity: .85 }, ig); E('circle', { cx, cy, r: f1(pr), fill: '#0a0a0a' }, ig); E('circle', { cx: cx - R * .3, cy: cy - R * .3, r: 5, fill: '#fff', opacity: .8 }, ig);
    B.tx(g, 180, 214, `তারারন্ধ্রের ব্যাস ≈ ${FK.n(dmm, 1)} মিলিমিটার`, { fs: 10.6, a: 'middle', w: 700, c: '#a8201a' }); B.tx(g, 180, 232, L >= 50 ? 'বৃত্তাকার পেশি সংকুচিত (প্যারাসিমপ্যাথেটিক)' : 'অরীয় পেশি সংকুচিত (সিমপ্যাথেটিক)', { fs: 9.4, a: 'middle', c: C.mu });
    B.tx(g, 300, 40, 'অরীয় পেশি', { fs: 8.6, a: 'middle', c: C.mu }); B.lead(g, C, 222, 90, 290, 46, '', {}); B.tx(g, 60, 40, 'বৃত্তাকার পেশি', { fs: 8.6, a: 'middle', c: C.mu }); B.lead(g, C, f1(cx - pr - 6), cy, 70, 46, '', {}); }
}));

/* ═════════ চোখের ত্রুটি ও সংশোধন ═════════ */
const ED = {
  myo: ['মায়োপিয়া', 'মায়োপিয়া বা ক্ষীণদৃষ্টি (দূরের জিনিস ঝাপসা)', 'চোখের গোলক বেশি লম্বা বা লেন্স-কর্নিয়া বেশি উত্তল — দূরের বস্তুর প্রতিবিম্ব রেটিনার সামনে পড়ে। সংশোধন: অবতল (ঋণাত্মক) লেন্সের চশমা রশ্মিকে একটু ছড়িয়ে দেয়।', { ax: 1.08, P: 0, corr: -3.6 }],
  hyp: ['হাইপারমেট্রোপিয়া', 'হাইপারমেট্রোপিয়া বা দূরদৃষ্টি (কাছের জিনিস ঝাপসা)', 'গোলক খাটো বা লেন্সের ক্ষমতা কম — প্রতিবিম্ব রেটিনার পেছনে পড়ে। সংশোধন: উত্তল (ধনাত্মক) লেন্স।', { ax: .93, P: 0, corr: 3.6 }],
  pres: ['প্রেসবায়োপিয়া', 'প্রেসবায়োপিয়া (বয়সজনিত, প্রায় 40 বছরের পর)', 'লেন্স স্থিতিস্থাপকতা হারায় ও সিলিয়ারি পেশি দুর্বল হয় — কাছের বস্তুর জন্য লেন্স আর মোটা হয় না; নিকট বিন্দু দূরে সরে যায়। সংশোধন: পড়ার জন্য উত্তল লেন্স বা দ্বি-ফোকাস (বাইফোকাল) চশমা।', { ax: 1, P: 0, near: 1, corr: 3.5 }],
  ast: ['অ্যাস্টিগম্যাটিজম', 'অ্যাস্টিগম্যাটিজম বা বিষমদৃষ্টি', 'কর্নিয়ার বক্রতা সব দিকে সমান নয় — এক তলের রশ্মি এক জায়গায়, অন্য তলের রশ্মি আরেক জায়গায় মেলে; কিছু রেখা স্পষ্ট, কিছু ঝাপসা। সংশোধন: সিলিন্ড্রিক্যাল লেন্স।', { ax: 1, P: 0, ast: 1 }],
  cat: ['ছানি', 'ছানি (ক্যাটারাক্ট)', 'বয়স, ডায়াবেটিস, অতিবেগুনি রশ্মি বা আঘাতে লেন্সের প্রোটিন জমাট বেঁধে অস্বচ্ছ হয় — দৃষ্টি ঘোলা। সংশোধন: অস্ত্রোপচারে ঘোলা লেন্স সরিয়ে কৃত্রিম লেন্স (IOL) বসানো।', { ax: 1, P: 0, cat: 1 }]
};
const EDO = s => ({ x: 236, s: .5, y: s });
V.eyeDefects = Object.assign({}, B.seg({
  id: 'edef', t: 'দৃষ্টির ত্রুটি ও সংশোধন', H: 290, def: 'myo', types: Object.fromEntries(Object.entries(ED).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'ওপরে ত্রুটিযুক্ত চোখ, নিচে সংশোধনের পর। লেন্সের ক্ষমতা ডায়অপ্টারে (D) = 1 ÷ ফোকাস দূরত্ব (মিটার); অবতল লেন্স ঋণাত্মক, উত্তল লেন্স ধনাত্মক। চিত্রের ক্ষমতার মান উদাহরণমাত্র।',
  art(g, C, ty) { const o = ED[ty][3]; B.cacheG(g, 'edb_' + ty, gg => { [70, 210].forEach((y, i) => { const fix = i === 1; B.eyeH(gg, C, Object.assign({ axial: o.ax, lensK: o.near && !o.cat ? 1.04 : 1, cloudy: o.cat && !fix, iol: o.cat && fix }, EDO(y)));
      if (fix && o.corr) { const x = 120, h = 30, cv = o.corr < 0; E('path', { d: cv ? `M${x - 5} ${y - h}Q${x + 3} ${y} ${x - 5} ${y + h}H${x + 5}Q${x - 3} ${y} ${x + 5} ${y - h}Z` : `M${x} ${y - h}Q${x + 10} ${y} ${x} ${y + h}Q${x - 10} ${y} ${x} ${y - h}Z`, fill: '#dbeaf8', stroke: '#4a7ab0', 'stroke-width': 1 }, gg); B.tx(gg, x, y + h + 12, (cv ? 'অবতল ' : 'উত্তল ') + (o.corr > 0 ? '+' : '') + o.corr + ' D', { fs: 8.6, a: 'middle', w: 700, c: '#2a5a90' }); }
      if (fix && o.ast) { E('rect', { x: 114, y: y - 30, width: 10, height: 60, rx: 3, fill: '#dbeaf8', stroke: '#4a7ab0', 'stroke-width': 1 }, gg); B.tx(gg, 119, y + 42, 'সিলিন্ড্রিক্যাল', { fs: 8.6, a: 'middle', w: 700, c: '#2a5a90' }); }
      B.tx(gg, 8, y - 48, fix ? 'সংশোধনের পর' : 'ত্রুটি', { fs: 10, w: 700, c: fix ? '#2a7a4a' : '#a8201a' }); }); }); },
  anim(g, C, ty, t) { const o = ED[ty][3], u = (t * .4) % 1;
    [70, 210].forEach((y0, i) => { const fix = i === 1, s = .5, X = x => 236 + x * s, Y = y => y0 + y * s, retX = -60 + 142 * o.ax;
      /* ফোকাস বিন্দু (মিমি → একক): v = 1336 ÷ ক্ষমতা; প্রধান তল x = -96 */ const L = o.near ? 4 : 0, Pw = 60 + (o.near ? .5 : 0) + (fix && o.corr ? o.corr : 0) - L, fx = fix && (o.ast || o.cat) ? retX : -96 + 1336 / Pw * 8, src = o.near ? 30 : 0;
      const rays = o.ast && !fix ? [[-22, retX - 14, '#e8a010'], [-9, retX - 14, '#e8a010'], [9, retX + 12, '#2a8ad0'], [22, retX + 12, '#2a8ad0']] : [-22, -9, 9, 22].map(h => [h, fx, '#e8a010']);
      rays.forEach(([h, f, col]) => { const bend = fix && o.corr, xl = 120, yl = !bend ? null : o.near ? y0 + (Y(h) - y0) * (xl - src) / (X(-103) - src) * 1.35 : Y(h / (o.corr < 0 ? 1.12 : .88)), y1 = o.near ? y0 : bend ? yl : Y(h), x1 = o.near ? src : 0; let d = `M${f1(x1)} ${f1(y1)}` + (bend ? `L${xl} ${f1(yl)}` : '') + `L${f1(X(-103))} ${f1(Y(h))}L${f1(X(-72))} ${f1(Y(h * .74))}L${f1(X(f))} ${f1(Y(0))}`; if (f > retX) d += ''; E('path', { d, stroke: col, 'stroke-width': 1, fill: 'none', 'stroke-dasharray': '6 4', 'stroke-dashoffset': f1(-u * 40), opacity: o.cat && !fix && Math.abs(h) > 15 ? .3 : 1 }, g); });
      if (o.near) { E('path', { d: `M${src} ${y0}v-14`, stroke: '#2a6ab0', 'stroke-width': 2, 'marker-end': B.mk(g, '#2a6ab0', 5) }, g); }
      const good = fix || false; E('circle', { cx: f1(X(o.ast && !fix ? retX : fx)), cy: f1(Y(0)), r: 3, fill: good ? '#2a9a5a' : '#c0392b' }, g); }); }
}));
})();
