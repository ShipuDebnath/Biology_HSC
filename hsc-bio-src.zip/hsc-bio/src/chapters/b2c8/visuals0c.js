/* ═══════════════════════════════════════════════════════════════════
   visuals0c — অধ্যায় ৬ (রেচন) এর শারীরস্থান-জ্যামিতি (B28 এ যোগ হয়)
   বৃক্কের সম্মুখ-ছেদ (kidneySec — কর্টেক্স, পিরামিড, কলাম, ক্যালিক্স, পেলভিস, রক্তনালির শাখা),
   নেফ্রনের পথ (NEPH — নালিকার প্রতিটি অংশের মধ্যরেখা), নেফ্রন আঁকা (nephronDraw), কোষ-ঝিল্লির পরিবহন চিহ্ন।
   রঙ: কর্টেক্স লালচে-বাদামি দানাদার, মেডুলার পিরামিড গাঢ় ও রেখাযুক্ত, ক্যালিক্স-পেলভিস সাদাটে,
   সাইনাসের চর্বি হলুদাভ, ধমনি লাল, শিরা নীল, মূত্র হলুদ; নালিকার অংশ আলাদা আলাদা রঙে (পাঠ্যবইয়ের প্রথা)।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, BK = window.BK, T = BK.T, B = window.B28, PI = Math.PI;
const f1 = v => (+v).toFixed(1);
const sm = (p, c, k) => B.smooth(p, c, k);
B.f1 = f1; B.sm = sm;
const hits = (parts, part, r = 14) => parts.forEach(p => E('circle', { cx: p.a[0], cy: p.a[1], r, fill: 'transparent' }, part(p.id)));
B.hits = hits;
/* পথ বরাবর কণা */
const AC = new WeakMap();
B.alongC = (pts, per = 6) => { let f = AC.get(pts); if (!f) { f = B.along(per ? B.dense(pts, per) : pts); AC.set(pts, f); } return f; };
/* স্থির অংশ একবার এঁকে প্রতি ফ্রেমে আবার জুড়ে দেওয়া (svg বদলালে নতুন করে) */
B.cacheG = (g, key, fn) => { const svg = g.ownerSVGElement || g, slot = key.replace(/\d+$/, ''), lm = svg._lm || (svg._lm = {}), LS = svg._ls || (svg._ls = []);
  let L = lm[slot]; if (!L) { L = E('g', {}, svg); svg.insertBefore(L, g); lm[slot] = L; LS.push(L); }
  if (L._k !== key) { L.innerHTML = ''; fn(L); L._k = key; }
  if (!svg._sch) { svg._sch = 1; svg._used = new Set(); queueMicrotask(() => { svg._sch = 0; LS.forEach(x => { const v = svg._used.has(x) ? '' : 'none'; if (x.style.display !== v) x.style.display = v; }); }); }
  svg._used.add(L); return L; };
B.flow = (g, pts, t, n, sp, dir, col, r = 1.8, op = .9) => { const A = B.alongC(pts); for (let i = 0; i < n; i++) { let u = (t * sp + i / n) % 1; if (dir < 0) u = 1 - u; const [x, y] = A(u); E('circle', { cx: f1(x), cy: f1(y), r, fill: col, opacity: op }, g); } };
const memo = (svg, key, mk) => { const m = svg._b28s || (svg._b28s = {}); return m[key] || (m[key] = mk()); };
const svgOf = g => g.ownerSVGElement || g;
let gid = 0;
const defs = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };

/* ─── কোষ ও ঝিল্লির পরিবহন চিহ্ন ───
   পাম্প (Na+/K+-ATPase): বৃত্তে ATP; চ্যানেল: দুটি দণ্ড; বাহক: ডিম্বাকার */
B.pump = (g, x, y, s = 'ATP', col = '#e0a030') => { E('circle', { cx: x, cy: y, r: 7, fill: FK.alpha(col, .85), stroke: '#7a5410', 'stroke-width': .8 }, g); B.tx(g, x, y + 2.6, s, { fs: 6.4, a: 'middle', w: 700, c: '#3a2500', halo: FK.alpha('#fff', .5), hw: 1 }); };
B.chan = (g, x, y, col = '#4a8ac8', vert = true, open = 1) => { const w = 2.6 + open * 1.5; if (vert) { E('rect', { x: x - w - 3, y: y - 8, width: 3, height: 16, rx: 1.4, fill: col, stroke: FK.alpha('#000', .3), 'stroke-width': .4 }, g); E('rect', { x: x + w, y: y - 8, width: 3, height: 16, rx: 1.4, fill: col, stroke: FK.alpha('#000', .3), 'stroke-width': .4 }, g); } else { E('rect', { x: x - 8, y: y - w - 3, width: 16, height: 3, rx: 1.4, fill: col }, g); E('rect', { x: x - 8, y: y + w, width: 16, height: 3, rx: 1.4, fill: col }, g); } };
B.carr = (g, x, y, col = '#7a6ac8', rx = 5.5, ry = 8) => E('ellipse', { cx: x, cy: y, rx, ry, fill: FK.alpha(col, .8), stroke: FK.alpha('#000', .3), 'stroke-width': .5 }, g);
/* ছোট কণা (আয়ন) লেবেলসহ */
const MT = new Map();
B.mol = (g, x, y, s, col, r = 6.5, fs = 6.6) => { const key = s + '|' + col + '|' + r + '|' + fs; let t = MT.get(key);
  if (!t) { t = document.createElementNS('http://www.w3.org/2000/svg', 'g'); E('circle', { cx: 0, cy: 0, r, fill: col, stroke: FK.alpha('#000', .35), 'stroke-width': .5 }, t); B.tx(t, 0, 2.4, s, { fs, a: 'middle', w: 700, c: '#fff', halo: FK.alpha('#000', .35), hw: 1.4 }); MT.set(key, t); }
  const n = t.cloneNode(true); n.setAttribute('transform', `translate(${f1(x)} ${f1(y)})`); g.appendChild(n); return n; };
/* তীর (সোজা) */
B.arr = (g, x0, y0, x1, y1, col, w = 1.4, o = {}) => E('path', { d: `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}`, stroke: col, 'stroke-width': w, 'marker-end': B.mk(g, col, o.s || 6), fill: 'none', 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1 }, g);
/* নালিকার আবরণী কোষের প্রস্থচ্ছেদ: cx, cy, R (বাইরের), r (লুমেন), n কোষ, o = { bb (ব্রাশ বর্ডার), k (রং), h (কোষের উচ্চতার অনুপাত), cil } */
})();
