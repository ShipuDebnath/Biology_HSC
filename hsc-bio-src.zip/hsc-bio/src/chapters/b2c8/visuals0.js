/* ═══════════════════════════════════════════════════════════════════
   visuals0 — ২য় পত্র অধ্যায় ৮ (সমন্বয় ও নিয়ন্ত্রণ) এর সহায়ক B28 — B22 এর অনুলিপি + শারীরস্থান-চিত্রের নতুন সহায়ক (প্রতিটি অধ্যায় নিজস্ব সহায়ক রাখে)
   (অধ্যায় ১২ এর B12 থেকে অনুলিপি, মানচিত্রের তথ্য বাদ — প্রতিটি অধ্যায় নিজস্ব সহায়ক রাখে, যাতে আলাদাভাবে লোড হলেও চলে)
   seg, gseg, ch / chH, axes, curve, area, along, poly, ion, dot, blob, lab, chip, mem, node, hot, dna, flask, dish
   রঙের নিয়ম: শারীরস্থানের চিত্রে বাস্তব টিস্যুর রং (visuals0a.js এর B28.TS) — শ্লেষ্মাস্তর গোলাপি, পেশি লালচে, যকৃৎ লালচে-বাদামি,
   পিত্ত সবুজাভ, ধমনি লাল, শিরা নীল, লসিকা হলদে-সাদা, স্নায়ু হলুদ; কোষবিদ্যার চিত্রে H&E রঞ্জন (নিউক্লিয়াস বেগুনি, সাইটোপ্লাজম গোলাপি)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B28 = window.B28 = {};
const PI = Math.PI;
const bn = B28.bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const rnd = B28.rnd = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
B28.cl = cl;

/* রাসায়নিক সংকেত */
const tok = s => { const out = [], re = /_\{([^}]*)\}|_(\d+)|\^\{([^}]*)\}|\^(\d*[+\-−])/g; let i = 0, m; while ((m = re.exec(s))) { if (m.index > i) out.push([s.slice(i, m.index), 0]); if (m[1] != null || m[2] != null) out.push([m[1] != null ? m[1] : m[2], 1]); else out.push([(m[3] != null ? m[3] : m[4]).replace('-', '−'), 2]); i = re.lastIndex; } if (i < s.length) out.push([s.slice(i), 0]); return out; };
B28.ch = s => { let off = 0; return tok(s).map(([t, l]) => { const o = l === 1 ? 3.5 : l === 2 ? -5 : 0, dy = o - off; off = o; return `<tspan dy="${dy}"${l ? ' font-size="72%"' : ''}>${t}</tspan>`; }).join(''); };
B28.chH = s => tok(s).map(([t, l]) => l === 1 ? `<sub>${t}</sub>` : l === 2 ? `<sup>${t}</sup>` : t).join('');
const ch = B28.ch, chH = B28.chH;

/* ধরন বদলানো চিত্র
   o: { id, t, k?, cap, W?, H? (সংখ্যা বা ty→সংখ্যা), types:{key:[বোতাম, শিরোনাম, বর্ণনা, নোট?]}, def,
        sl?:[{k,l,min,max,step,val,unit,d}], art(g,C,ty,ctx), anim?(g,C,ty,t,ctx), tap?(x,y,ty,ctx)→html, more?(ty,ctx)→html } */
B28.seg = o => ({
  t: o.t, k: o.k || ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `${Object.keys(o.types).length > 1 ? `<div class="fk-row">${X.seg(o.id, Object.keys(o.types).map(k => [k, o.types[k][0]]), o.def)}</div>` : ''}<div class="fk-stage bk-stage" data-k="st"></div>${(o.sl || []).map(s => `<div class="fk-row">${FK.sl(s.k, s.l, s.min, s.max, s.step, s.val, s.unit || '')}</div>`).join('')}<div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = o.W || 360;
    let ty = o.def, C, svg, ga, gd, tt = 0;
    const ctx = { root, v: {}, sel: o.sel != null ? o.sel : null };
    (o.sl || []).forEach(s => { ctx.v[s.k] = s.val; });
    const defInfo = () => { const a = o.types[ty]; return `<b>${a[1] || a[0]}</b> — ${a[2]}${a[3] ? `<div class="small">${a[3]}</div>` : ''}${o.more ? o.more(ty, ctx) || '' : ''}`; };
    const info = h => { $('info').innerHTML = h; };
    const frame = () => { gd.innerHTML = ''; if (o.anim) o.anim(gd, C, ty, tt, ctx); };
    const redraw = () => { ga.innerHTML = ''; o.art(ga, C, ty, ctx); frame(); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const h = typeof o.H === 'function' ? o.H(ty) : (o.H || 260);
      svg = E('svg', { viewBox: `0 0 ${W} ${h}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.types[ty][1] || o.types[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: h, rx: 12, fill: C.sf }, svg);
      ga = E('g', {}, svg); gd = E('g', { style: 'pointer-events:none' }, svg); ctx.svg = svg; ctx.C = C;
      redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo());
    };
    ctx.info = info; ctx.redraw = redraw; ctx.def = defInfo;
    root.addEventListener('click', e => {
      if (!o.tap || !svg || !svg.contains(e.target)) return;
      const m = svg.getScreenCTM(); if (!m) return; const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const q = p.matrixTransform(m.inverse());
      const h = o.tap(q.x, q.y, ty, ctx); if (h) info(h); redraw();
    });
    (o.sl || []).forEach(s => FK.bindSl(root, s.k, v => { ctx.v[s.k] = v; redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo()); }, s.unit || '', s.d != null ? s.d : 0));
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, o.id, v => { ty = v; tt = 0; ctx.sel = o.sel != null ? o.sel : null; ctx.selInfo = null; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* অক্ষ: b = [x, y, w, h]; o = { xr, yr, lx, ly, xt, yt, xf } → P(u, v) */
B28.axes = (g, C, b, o) => {
  const [x, y, w, h] = b, xr = o.xr, yr = o.yr, P = (u, v) => [x + (u - xr[0]) / (xr[1] - xr[0]) * w, y + h - (v - yr[0]) / (yr[1] - yr[0]) * h];
  (o.yt || []).forEach(t => { const [, py] = P(xr[0], t); E('path', { d: `M${x} ${py}H${x + w}`, stroke: C.ln, 'stroke-width': .6, opacity: .45 }, g); T(g, x - 5, py + 3.5, o.yf ? o.yf(t) : String(t), { fs: 9.5, a: 'end', c: C.mu }); });
  (o.xt || []).forEach(t => { const [px] = P(t, yr[0]); E('path', { d: `M${px} ${y + h}v4`, stroke: C.mu, 'stroke-width': 1 }, g); T(g, px, y + h + 14, o.xf ? o.xf(t) : String(t), { fs: 9.5, a: 'middle', c: C.mu }); });
  E('path', { d: `M${x} ${y - 6}V${y + h}H${x + w + 6}`, stroke: C.fg, 'stroke-width': 1.3, fill: 'none' }, g);
  E('path', { d: `M${x} ${y - 10}l-3.5 7h7z`, fill: C.fg }, g); E('path', { d: `M${x + w + 10} ${y + h}l-7 -3.5v7z`, fill: C.fg }, g);
  if (o.lx) T(g, x + w + 8, y + h + 28, o.lx, { fs: 10.5, a: 'end', c: C.mu });
  if (o.ly) T(g, x + 6, y - 4, o.ly, { fs: 10.5, c: C.mu });
  return P;
};
B28.curve = (g, P, f, a, b, at, n = 64) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } return E('path', Object.assign({ d, fill: 'none', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, at), g); };
B28.area = (g, P, f, a, b, y0, at, n = 48) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } const [xb] = P(b, y0), [xa, ya] = P(a, y0); d += `L${xb} ${ya}L${xa} ${ya}Z`; return E('path', Object.assign({ d, stroke: 'none' }, at), g); };
/* রেখা বরাবর u (০→১) অবস্থানের বিন্দু */
B28.along = (pts, u) => {
  let L = 0; const sg = [];
  for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); sg.push(l); L += l; }
  let d = (((u % 1) + 1) % 1) * L;
  for (let i = 0; i < sg.length; i++) { if (d <= sg[i]) { const k = sg[i] ? d / sg[i] : 0; return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k]; } d -= sg[i]; }
  return pts[pts.length - 1];
};
B28.poly = (g, pts, at) => E('path', Object.assign({ d: pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(''), fill: 'none' }, at), g);
/* আয়ন বা অণুর বল */
B28.ion = (g, x, y, s, R, r = 10, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.lt, stroke: R.dk, 'stroke-width': 1.1, opacity: o.op != null ? o.op : 1 }, g); T(g, x, y + 3.2, ch(s), { fs: o.fs || 8.5, a: 'middle', w: 650, c: R.ink }); };
B28.dot = (g, x, y, r, c, op = 1) => E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r, fill: c, opacity: op }, g);
B28.blob = (g, x, y, r, o = {}) => {
  const n = o.n || 7, sd = o.seed || 1; let d = '';
  for (let i = 0; i <= n; i++) { const a = i / n * PI * 2 + (o.rot || 0), rr = r * (1 + (rnd(sd * 31 + (i % n)) - .5) * (o.j != null ? o.j : .16)); d += (i ? 'L' : 'M') + (x + rr * Math.cos(a)).toFixed(1) + ' ' + (y + rr * Math.sin(a)).toFixed(1); }
  return E('path', { d: d + 'Z', fill: o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || 1, 'stroke-linejoin': 'round' }, g);
};
/* লেবেল রেখা ও লেখা */
B28.lab = (g, ax, ay, lx, ly, s, C, o = {}) => {
  E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': .9, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2, fill: C.fg }, g);
  const an = o.a || (lx < ax ? 'end' : 'start'); T(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 4, s, { fs: o.fs || 11, a: an, w: 560, c: o.c || C.fg });
};
/* চিপ (গোল কোণের লেবেল) */
B28.chip = (g, x, y, s, R, o = {}) => { const w = o.w || 60, h = o.h || 18; E('rect', { x: x - (o.a === 'start' ? 0 : w / 2), y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.c, 'stroke-width': 1 }, g); T(g, x + (o.a === 'start' ? w / 2 : 0), y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
/* ঝিল্লি (দ্বিস্তরী লিপিড) — অনুভূমিক */
B28.mem = (g, C, x0, x1, y, o = {}) => {
  const R = o.R || BK.ramp(2), sp = o.sp || 9, gaps = o.gaps || [];
  E('rect', { x: x0, y: y - 8, width: x1 - x0, height: 16, fill: FK.alpha(R.c, .14) }, g);
  let d = '';
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; d += `M${x.toFixed(1)} ${y - 5}v3.2M${x.toFixed(1)} ${y + 1.8}v3.2`; }
  E('path', { d, stroke: R.dk, 'stroke-width': 1, opacity: .55 }, g);
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; E('circle', { cx: x, cy: y - 7, r: 3, fill: R.c }, g); E('circle', { cx: x, cy: y + 7, r: 3, fill: R.c }, g); }
};

/* লেখচিত্র-ধরন: o.types[k] = { b, t, d, f, xr, xt, lx, ly, read?(x) → নোট, mk?:[[x, লেখা]] } */
B28.gseg = o => {
  const ty = {}; Object.keys(o.types).forEach(k => { const G = o.types[k]; ty[k] = [G.b, G.t, G.d]; });
  const box = [46, 34, 284, 160];
  return B28.seg({
    id: o.id, t: o.t, cap: o.cap, k: ['graph', 'anim', 'int'], H: 236, def: o.def, types: ty,
    art(g, C, k, ctx) {
      const G = o.types[k], R = BK.ramp(G.c != null ? G.c : 0);
      const P = B28.axes(g, C, box, { xr: G.xr, yr: [0, 1.08], lx: G.lx, ly: G.ly || 'আপেক্ষিক হার', xt: G.xt, yt: [.5, 1], yf: v => v === 1 ? 'সর্বোচ্চ' : '' });
      ctx.P = P; ctx.G = G;
      B28.area(g, P, G.f, G.xr[0], G.xr[1], 0, { fill: FK.alpha(R.c, .13) });
      B28.curve(g, P, G.f, G.xr[0], G.xr[1], { stroke: R.c, 'stroke-width': 3 });
      (G.mk || []).forEach(([xv, s, up, an]) => { const [px, py] = P(xv, G.f(xv)); E('circle', { cx: px, cy: py, r: 3.2, fill: R.dk }, g); T(g, px + (an ? 7 : 0), py + (up ? -9 : 17), s, { fs: 9.8, a: an || 'middle', w: 560, c: R.ink }); });
      if (ctx.sel != null) { const [px, py] = P(ctx.sel, G.f(ctx.sel)), [, pb] = P(ctx.sel, 0), [pa] = P(G.xr[0], 0); E('path', { d: `M${px} ${pb}V${py}H${pa}`, stroke: C.mu, 'stroke-dasharray': '3 3', fill: 'none' }, g); E('circle', { cx: px, cy: py, r: 5, fill: R.c, stroke: C.sf, 'stroke-width': 2 }, g); }
    },
    anim(g, C, k, t, ctx) {
      const G = ctx.G, P = ctx.P; if (!G || !t) return; const R = BK.ramp(G.c != null ? G.c : 0), u = (1 - Math.cos(t * .7)) / 2, xv = G.xr[0] + u * (G.xr[1] - G.xr[0]), [px, py] = P(xv, G.f(xv));
      E('circle', { cx: px, cy: py, r: 9, fill: FK.alpha(R.c, .25) }, g); E('circle', { cx: px, cy: py, r: 4.5, fill: R.dk }, g);
    },
    tap(x, y, k, ctx) {
      const G = ctx.G; if (!G || x < box[0] - 4 || x > box[0] + box[2] + 4 || y > box[1] + box[3] + 6) return null;
      const xv = cl(G.xr[0] + (x - box[0]) / box[2] * (G.xr[1] - G.xr[0]), G.xr[0], G.xr[1]); ctx.sel = xv;
      const v = Math.round(G.f(xv) * 100);
      return `<b>${G.lx}: ${FK.n(xv, G.dp != null ? G.dp : 0)}${G.u || ''}</b> → আপেক্ষিক হার ≈ <b>${v}%</b> (সর্বোচ্চের তুলনায়)${G.read ? `<div class="small">${G.read(xv)}</div>` : ''}<div class="small muted">এটি প্রবণতা বোঝানোর লেখচিত্র — মান উদ্ভিদভেদে বদলায়।</div>`;
    }
  });
};
B28.node = (g, x, y, s, R, w = 64, h = 22, o = {}) => { E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: o.rx != null ? o.rx : 7, fill: o.fill || FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': o.sw || 1.1 }, g); T(g, x, y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };

/* ═══ অধ্যায় ১১ এর নতুন সহায়ক ═══ */
/* বৃত্তচাপ: কোণ ডিগ্রিতে, ০° = ওপরে, ঘড়ির কাঁটার দিকে */
const pol = B28.pol = (cx, cy, r, a) => { const t = (a - 90) * PI / 180; return [cx + r * Math.cos(t), cy + r * Math.sin(t)]; };
B28.arc = (cx, cy, r, a0, a1) => { const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1), big = ((a1 - a0) % 360 + 360) % 360 > 180 ? 1 : 0; return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${big} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`; };
/* নিকটতম বিন্দু: H = [[x, y, ...], ...] → সবচেয়ে কাছের উপাদান (r এর মধ্যে) */
B28.hot = (H, x, y, r = 30) => { let b = null, bd = r; H.forEach(h => { const d = Math.hypot(h[0] - x, h[1] - y); if (d < bd) { bd = d; b = h; } }); return b; };
const COMP = { A: 'T', T: 'A', G: 'C', C: 'G' };
B28.comp = s => s.split('').map(c => COMP[c] || c).join('');
/* দ্বিসূত্রক DNA: ওপরের সূত্র seq (5'→3'), নিচে পরিপূরক। o = { w (প্রতি ক্ষারক), gap, cut:[উপরের কাটা, নিচের কাটা], sep (কাটার পর দুই অংশের দূরত্ব), top/bot: false হলে সেই সূত্র আঁকবে না, op, lab (5'/3' দেখাবে), from, to } */
B28.dna = (g, C, x, y, seq, o = {}) => {
  const w = o.w || 15, gap = o.gap || 24, n = seq.length, cs = B28.comp(seq), cut = o.cut, sep = o.sep || 0, a = o.from || 0, b = o.to != null ? o.to : n;
  const xs = (i, strand) => x + i * w + (cut && sep ? (i >= cut[strand] ? sep / 2 : -sep / 2) : 0);
  const Rb = BK.ramp(9);
  [0, 1].forEach(s => {
    if ((s === 0 && o.top === false) || (s === 1 && o.bot === false)) return;
    const yy = s ? y + gap : y, str = s ? cs : seq;
    const segs = cut ? [[a, cut[s]], [cut[s], b]] : [[a, b]];
    segs.forEach(([i0, i1]) => { if (i1 <= i0) return; E('path', { d: `M${xs(i0, s) + 1} ${yy + (s ? 9 : -9)}H${xs(i1 - 1, s) + w - 1}`, stroke: Rb.dk, 'stroke-width': 2.2, 'stroke-linecap': 'round', opacity: o.op != null ? o.op : 1 }, g); });
    for (let i = a; i < b; i++) {
      const R = BK.base(str[i]), px = xs(i, s);
      E('rect', { x: px + 1, y: yy - (s ? 0 : 8) - (s ? 0 : 0), width: w - 2, height: 8, rx: 1.5, fill: R.c, opacity: o.op != null ? o.op : 1 }, g);
      if (w >= 12) T(g, px + w / 2, yy + (s ? 21 : -14), str[i], { fs: o.fs || 9, a: 'middle', w: 700, c: R.ink });
    }
  });
  if (o.lab) { T(g, x - 6 - (cut && sep ? sep / 2 : 0), y - 1, "5'", { fs: 8.5, a: 'end', c: C.mu }); T(g, x + n * w + 6 + (cut && sep ? sep / 2 : 0), y - 1, "3'", { fs: 8.5, c: C.mu }); T(g, x - 6 - (cut && sep ? sep / 2 : 0), y + gap + 8, "3'", { fs: 8.5, a: 'end', c: C.mu }); T(g, x + n * w + 6 + (cut && sep ? sep / 2 : 0), y + gap + 8, "5'", { fs: 8.5, c: C.mu }); }
};
/* প্লাসমিড: o = { genes:[[a0, a1, ramp, লেখা]], sites:[[a, লেখা]], ins:[a0, a1] (ঢোকানো জিন — অ্যাম্বার), sw, lab, fs } */
B28.plasmid = (g, C, cx, cy, r, o = {}) => {
  const Rp = BK.ramp(3);
  E('circle', { cx, cy, r: r + 2.5, fill: 'none', stroke: Rp.dk, 'stroke-width': 1.2 }, g); E('circle', { cx, cy, r: r - 2.5, fill: 'none', stroke: Rp.dk, 'stroke-width': 1.2 }, g);
  E('circle', { cx, cy, r, fill: 'none', stroke: FK.alpha(Rp.c, .35), 'stroke-width': 4 }, g);
  (o.genes || []).forEach(([a0, a1, ri, s]) => { const R = BK.ramp(ri); E('path', { d: B28.arc(cx, cy, r, a0, a1), stroke: R.c, 'stroke-width': o.sw || 9, fill: 'none', 'stroke-linecap': 'butt' }, g); if (s) { const m = (a0 + a1) / 2, [lx, ly] = pol(cx, cy, r - (o.sw || 9) - 9, m); T(g, lx, ly + 3.5, s, { fs: o.fs || 9, a: 'middle', w: 650, c: R.ink }); } });
  if (o.ins) { const R = BK.ramp(6); E('path', { d: B28.arc(cx, cy, r, o.ins[0], o.ins[1]), stroke: R.c, 'stroke-width': (o.sw || 9) + 2, fill: 'none' }, g); }
  (o.sites || []).forEach(([a, s]) => { const [x0, y0] = pol(cx, cy, r + 4, a), [x1, y1] = pol(cx, cy, r + 13, a), [lx, ly] = pol(cx, cy, r + 22, a); E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: BK.ramp(4).dk, 'stroke-width': 1.5 }, g); T(g, lx, ly + 3.5, s, { fs: o.fs || 9, a: lx < cx - 4 ? 'end' : lx > cx + 4 ? 'start' : 'middle', w: 600, c: BK.ramp(4).ink }); });
};
/* ব্যাকটেরিয়া কোষ (ক্যাপসুল আকৃতি): o = { chromo, plas (সংখ্যা), pr (প্লাসমিডের রং ৩/৬ মিশ্র), op, fill } */
B28.bac = (g, C, x, y, w, h, o = {}) => {
  const R = BK.ramp(0); E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.dk, 'stroke-width': 1.3, opacity: o.op != null ? o.op : 1 }, g);
  if (o.chromo !== false) { let d = `M${x - w * .28} ${y}`; for (let i = 1; i <= 8; i++) d += `Q${x - w * .28 + (i - .5) * w * .07} ${y + (i % 2 ? -h * .22 : h * .22)} ${x - w * .28 + i * w * .07} ${y}`; E('path', { d, stroke: BK.ramp(9).dk, 'stroke-width': 1.3, fill: 'none', opacity: o.op != null ? o.op : 1 }, g); }
  for (let i = 0; i < (o.plas || 0); i++) { const px = x + w * .3 + (i % 2) * 7 - 3, py = y - h * .22 + Math.floor(i / 2) * 9; E('circle', { cx: px, cy: py, r: 3.2, fill: 'none', stroke: (o.pr === 6 ? BK.ramp(6) : BK.ramp(3)).dk, 'stroke-width': 1.6, opacity: o.op != null ? o.op : 1 }, g); }
};
/* কনিক্যাল ফ্লাস্ক — মাধ্যমসহ */
B28.flask = (g, C, x, y, s = 1, o = {}) => { E('path', { d: `M${x - 10 * s} ${y - 60 * s}V${y - 34 * s}L${x - 34 * s} ${y}H${x + 34 * s}L${x + 10 * s} ${y - 34 * s}V${y - 60 * s}Z`, fill: FK.alpha(BK.ramp(5).c, .08), stroke: C.fg, 'stroke-width': 1.3 }, g); E('path', { d: `M${x - 26 * s} ${y - 12 * s}H${x + 26 * s}L${x + 34 * s} ${y}H${x - 34 * s}Z`, fill: FK.alpha(BK.ramp(o.med != null ? o.med : 6).c, .45) }, g); E('rect', { x: x - 12 * s, y: y - 66 * s, width: 24 * s, height: 8 * s, rx: 2, fill: '#e5e5e5', stroke: C.mu }, g); };
/* পেট্রিডিশ (ওপর থেকে) — o.col: [[dx, dy, r, রং]] কলোনি */
B28.dish = (g, C, x, y, r, o = {}) => { E('circle', { cx: x, cy: y, r: r + 3, fill: 'none', stroke: C.mu, 'stroke-width': 1.2 }, g); E('circle', { cx: x, cy: y, r, fill: FK.alpha(BK.ramp(o.med != null ? o.med : 6).c, .22), stroke: C.mu, 'stroke-width': .8 }, g); (o.col || []).forEach(([dx, dy, cr, c]) => E('circle', { cx: x + dx, cy: y + dy, r: cr, fill: c, stroke: FK.alpha('#000', .25), 'stroke-width': .6 }, g)); if (o.lab) T(g, x, y + r + 16, o.lab, { fs: o.fs || 9.5, a: 'middle', w: 600, c: o.lc || C.fg }); };

/* ছোট সহায়ক — তীর, টিক, ক্রস, তুলনা */
B28.arrow = (g, x0, y0, x1, y1, c, o = {}) => { const a = Math.atan2(y1 - y0, x1 - x0), h = o.h || 6; E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: c, 'stroke-width': o.w || 1.6, 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1, fill: 'none' }, g); E('path', { d: `M${x1} ${y1}l${-h * Math.cos(a - .45)} ${-h * Math.sin(a - .45)}l${h * Math.cos(a - .45) - h * Math.cos(a + .45)} ${h * Math.sin(a - .45) - h * Math.sin(a + .45)}Z`, fill: c, opacity: o.op != null ? o.op : 1 }, g); };
B28.okm = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y}l${r * .7} ${r * .7}l${r * 1.3} ${-r * 1.4}`, stroke: c, 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
B28.cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
/* নির্বাচিত হটস্পটে বৃত্ত ও হটস্পট বাছাই */
B28.ring = (g, x, y, r, on, R) => { if (on) E('circle', { cx: x, cy: y, r, fill: 'none', stroke: (R || BK.ramp(4)).dk, 'stroke-width': 2.2 }, g); };
B28.pick = (ctx, H, x, y, r) => { const h = B28.hot(H, x, y, r || 24); if (!h) return ''; ctx.sel = h[2]; return h[3]; };
})();
