/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.৮ — DNA
   dnaDims : দ্বৈত হেলিক্সের মাপজোক (20 Å, 34 Å, 3.4 Å, 36°) + ক্যালকুলেটর
             (বেস পেয়ার → দৈর্ঘ্য, পাক, নিউক্লিওটাইড); হেলিক্স ধীরে ঘোরে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

V.dnaDims = Object.assign({
  t: 'দ্বৈত হেলিক্সের মাপজোক ও হিসাব', k: ['2d', 'anim', 'int'],
  cap: 'একটি পূর্ণ পাক (<b>34 Å</b>) জুড়ে <b>১০টি</b> বেস পেয়ার, পরপর দুটির দূরত্ব <b>3.4 Å</b>, ব্যাস <b>20 Å</b>। লক্ষ করো দুই সূত্রের তীর উল্টো দিকে — <b>অ্যান্টিপ্যারালাল</b>। নিচের স্লাইডার টেনে বেস পেয়ার বদলাও — দৈর্ঘ্য, পাক ও নিউক্লিওটাইডের হিসাব সাথে সাথে দেখাবে।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    ${FK.sl('bp', 'বেস পেয়ার', 10, 5000, 10, 1500, '')}
    <div class="bk-info" data-k="calc" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 380, H = 350, CX = 150, TOP = 46, PITCH = 240, AMP = 46, LEN = PITCH * 1.08;
    let svg, strands, rungs, ph = 0;

    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'DNA-র মাপজোক' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      rungs = E('g', {}, svg);
      strands = E('g', {}, svg);
      const ink = C.mu, Ra = BK.base('A'), Rg = BK.ramp(10), Rp = BK.ramp(6);

      /* ব্যাস — উপরে বন্ধনী */
      E('path', { d: `M${CX - AMP} 30h${2 * AMP}M${CX - AMP} 25v10M${CX + AMP} 25v10`, stroke: Rp.dk, 'stroke-width': 1.6, fill: 'none' }, svg);
      T(svg, CX, 20, 'ব্যাস 20 Å', { fs: 11.5, a: 'middle', w: 650, c: Rp.ink });
      /* এক পাক — ডানে বন্ধনী */
      const bx = CX + AMP + 30;
      E('path', { d: `M${bx} ${TOP}v${PITCH}M${bx - 5} ${TOP}h10M${bx - 5} ${TOP + PITCH}h10`, stroke: Rg.dk, 'stroke-width': 1.6, fill: 'none' }, svg);
      T(svg, bx + 9, TOP + PITCH / 2 - 6, 'এক পাক', { fs: 11, w: 620, c: Rg.ink });
      T(svg, bx + 9, TOP + PITCH / 2 + 10, '34 Å', { fs: 12.5, w: 700, c: Rg.ink });
      T(svg, bx + 9, TOP + PITCH / 2 + 26, '= 10 bp', { fs: 10.5, w: 560, c: ink });
      /* 3.4 Å — দুই ধাপের মাঝে */
      const y1 = TOP + PITCH * 2 / 10, y2 = TOP + PITCH * 3 / 10;
      E('path', { d: `M${CX - AMP - 22} ${y1}v${y2 - y1}M${CX - AMP - 26} ${y1}h8M${CX - AMP - 26} ${y2}h8`, stroke: Ra.dk, 'stroke-width': 1.6, fill: 'none' }, svg);
      T(svg, CX - AMP - 30, (y1 + y2) / 2 + 4, '3.4 Å', { fs: 11.5, a: 'end', w: 700, c: Ra.ink });
      T(svg, CX - AMP - 30, (y1 + y2) / 2 + 19, 'কোণ 36°', { fs: 9.5, a: 'end', w: 560, c: ink });
      /* ৫′/৩′ প্রান্ত */
      T(svg, CX - AMP - 8, TOP - 6, "৫′", { fs: 11, a: 'end', w: 650, c: BK.ramp(9).ink });
      T(svg, CX - AMP - 8, TOP + LEN + 16, "৩′", { fs: 11, a: 'end', w: 650, c: BK.ramp(9).ink });
      T(svg, CX + AMP + 8, TOP - 6, "৩′", { fs: 11, a: 'start', w: 650, c: BK.ramp(2).ink });
      T(svg, CX + AMP + 8, TOP + LEN + 16, "৫′", { fs: 11, a: 'start', w: 650, c: BK.ramp(2).ink });
      T(svg, CX, H - 10, 'দুই সূত্র উল্টো দিকে — অ্যান্টিপ্যারালাল', { fs: 10.5, a: 'middle', w: 560, c: ink });
      paint();
    };

    /* প্রতি ফ্রেমে কেবল সূত্র ও ধাপ (দুটি স্তর) নতুন করে আঁকা হয় */
    const paint = () => {
      if (!strands) return;
      const C = FK.P(), RS1 = BK.ramp(9), RS2 = BK.ramp(2);
      const BC = { A: BK.base('A').c, T: BK.base('T').c, G: BK.base('G').c, C: BK.base('C').c };
      const seq = 'ATGCGTACGATGCAT';
      strands.innerHTML = ''; rungs.innerHTML = '';
      const N = 12, L = LEN;
      const xs = (y, s) => CX + s * AMP * Math.sin(2 * Math.PI * (y - TOP) / PITCH + ph);
      for (let i = 0; i <= N; i++) {
        const y = TOP + PITCH * i / 10;
        if (y > TOP + L) break;
        const xa = xs(y, 1), xb = xs(y, -1), depth = Math.cos(2 * Math.PI * (y - TOP) / PITCH + ph);
        const b = seq[i % seq.length], pb = { A: 'T', T: 'A', G: 'C', C: 'G' }[b];
        const mid = (xa + xb) / 2;
        E('path', { d: `M${xa} ${y}H${mid}`, stroke: FK.alpha(BC[b], .5 + .4 * Math.abs(depth)), 'stroke-width': 5, 'stroke-linecap': 'round' }, rungs);
        E('path', { d: `M${mid} ${y}H${xb}`, stroke: FK.alpha(BC[pb], .5 + .4 * Math.abs(depth)), 'stroke-width': 5, 'stroke-linecap': 'round' }, rungs);
      }
      [[1, RS1, 1], [-1, RS2, -1]].forEach(([s, R, dir]) => {
        const d = [];
        for (let y = TOP; y <= TOP + L; y += 4) d.push(`${y === TOP ? 'M' : 'L'}${xs(y, s).toFixed(1)} ${y}`);
        E('path', { d: d.join(''), fill: 'none', stroke: R.c, 'stroke-width': 4, 'stroke-linecap': 'round' }, strands);
        /* দিক নির্দেশক তীর */
        const ya = dir > 0 ? TOP + L - 14 : TOP + 14, xa = xs(ya, s);
        E('path', { d: `M${xa - 6} ${ya - dir * 8}L${xa} ${ya}L${xa + 6} ${ya - dir * 8}`, fill: 'none', stroke: R.dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, strands);
      });
    };

    const calc = v => {
      const bp = Math.round(v), len = bp * 3.4, nm = len / 10, um = nm / 1000;
      $('calc').innerHTML = `<b>${bp} বেস পেয়ার (bp)</b>`
        + `<div class="small">দৈর্ঘ্য = ${bp} × 3.4 Å = <b>${len.toFixed(0)} Å</b> = ${nm.toFixed(1)} nm = ${um.toFixed(3)} μm</div>`
        + `<div class="small">পাকের সংখ্যা = ${bp} ÷ 10 = <b>${Math.round(bp / 10)}</b></div>`
        + `<div class="small">নিউক্লিওটাইড = 2 × ${bp} = <b>${2 * bp}</b> (দুই সূত্র)</div>`;
    };

    FK.bindSl(root, 'bp', calc, '', 0);
    build(); calc(1500);
    const A = X.anim(root, dt => { ph += dt * .55; paint(); }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── ২. tRNA-র ক্লোভার পাতা মডেল ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;

V.tRNAleaf = Object.assign({
  t: 'tRNA — ক্লোভার পাতা মডেল', k: ['2d', 'anim', 'int', 'game'],
  cap: 'উপরে <b>গ্রাহক বাহু</b> — ৩′ প্রান্তের <b>CCA</b>-তে অ্যামিনো অ্যাসিড (মিথিওনিন) বসে আছে। নিচে <b>অ্যান্টিকোডন</b> ৩′-UAC-৫′, যা mRNA-র কোডন ৫′-AUG-৩′ এর সাথে জোড় বাঁধছে। বাঁয়ে <b>DHU লুপ</b>, ডানে <b>TψC লুপ</b>। লেবেল-কুইজ দিয়ে নিজেকে যাচাই করো।'
}, BK.diagram({
  W: 360, H: 380, label: 'tRNA-র ক্লোভার পাতা মডেল',
  art(g, C, part) {
    const svg = g.ownerSVGElement;
    const Rs = BK.ramp(5), Ra = BK.ramp(2), Rd = BK.ramp(9), Rt = BK.ramp(10), Rx = BK.ramp(8), Rm = BK.ramp(6), Rv = BK.ramp(4);
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    /* দ্বিসূত্রক বাহু: দুটি সমান্তরাল রেখা ও মাঝে ধাপ */
    const stem = (gp, x1, y1, x2, y2, n, R) => {
      const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy), nx = -dy / L * 7, ny = dx / L * 7;
      E('path', { d: `M${x1 + nx} ${y1 + ny}L${x2 + nx} ${y2 + ny}M${x1 - nx} ${y1 - ny}L${x2 - nx} ${y2 - ny}`, stroke: R.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, gp);
      for (let i = 1; i < n; i++) { const t = i / n, x = x1 + dx * t, y = y1 + dy * t;
        E('path', { d: `M${x + nx} ${y + ny}L${x - nx} ${y - ny}`, stroke: FK.alpha(R.c, .8), 'stroke-width': 2.4 }, gp); }
    };
    const loop = (gp, cx, cy, r, R) => E('circle', { cx, cy, r, fill: FK.alpha(R.lt, .55), stroke: R.dk, 'stroke-width': 3 }, gp);
    const CX = 180, CY = 196;

    /* গ্রাহক বাহু — উপরে */
    const acc = P('acc');
    stem(acc, CX, CY - 30, CX, 78, 7, Rs);
    E('path', { d: `M${CX + 7} 78L${CX + 7} 48`, stroke: Rs.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, acc);
    T(acc, CX + 16, 66, 'C', { fs: 11, w: 700, c: Rs.ink }); T(acc, CX + 16, 55, 'C', { fs: 11, w: 700, c: Rs.ink }); T(acc, CX + 16, 44, 'A', { fs: 11, w: 700, c: Rs.ink });
    T(acc, CX - 14, 84, "৫′", { fs: 10.5, a: 'end', w: 650, c: C.mu });
    T(acc, CX + 30, 40, "৩′", { fs: 10.5, w: 650, c: C.mu });

    /* অ্যামিনো অ্যাসিড */
    const aa = P('aa');
    E('circle', { cx: CX + 7, cy: 30, r: 13, fill: BK.lg(svg, Ra.lt, Ra.c, { a: 90 }), stroke: Ra.dk, 'stroke-width': 1.8 }, aa);
    T(aa, CX + 7, 34, 'Met', { fs: 9.5, a: 'middle', w: 700, c: Ra.ink });

    /* DHU বাহু ও লুপ — বাঁয়ে */
    const dhu = P('dhu');
    stem(dhu, CX - 26, CY, CX - 78, CY, 4, Rd);
    loop(dhu, CX - 104, CY, 26, Rd);
    T(dhu, CX - 104, CY + 4, 'DHU', { fs: 10, a: 'middle', w: 700, c: Rd.ink });

    /* TψC বাহু ও লুপ — ডানে */
    const tpc = P('tpc');
    stem(tpc, CX + 26, CY, CX + 78, CY, 4, Rt);
    loop(tpc, CX + 104, CY, 26, Rt);
    T(tpc, CX + 104, CY + 4, 'TψC', { fs: 10, a: 'middle', w: 700, c: Rt.ink });

    /* অতিরিক্ত বাহু — নিচে ডানে ছোট ফোলা */
    const vr = P('var');
    E('path', { d: `M${CX + 22} ${CY + 30}q22 6 26 22`, fill: 'none', stroke: Rx.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, vr);
    E('circle', { cx: CX + 50, cy: CY + 56, r: 7, fill: FK.alpha(Rx.lt, .7), stroke: Rx.dk, 'stroke-width': 2 }, vr);

    /* কেন্দ্র সংযোগ */
    E('circle', { cx: CX, cy: CY, r: 26, fill: 'none', stroke: FK.alpha(C.mu, .5), 'stroke-width': 3 }, g);

    /* অ্যান্টিকোডন বাহু ও লুপ — নিচে */
    const ac = P('ac');
    stem(ac, CX, CY + 26, CX, CY + 86, 5, Rm);
    loop(ac, CX, CY + 112, 26, Rm);
    ['U', 'A', 'C'].forEach((b, i) => {
      const x = CX - 16 + i * 16, y = CY + 132;
      E('rect', { x: x - 7, y: y - 9, width: 14, height: 18, rx: 3, fill: Rm.c }, ac);
      T(ac, x, y + 4, b, { fs: 10.5, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    });

    /* mRNA কোডন */
    const mr = P('mrna');
    E('path', { d: `M60 ${CY + 166}H300`, stroke: Rv.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, mr);
    ['A', 'U', 'G'].forEach((b, i) => {
      const x = CX - 16 + i * 16, y = CY + 166;
      E('rect', { x: x - 7, y: y - 1, width: 14, height: 18, rx: 3, fill: Rv.c }, mr);
      T(mr, x, y + 13, b, { fs: 10.5, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    });
    T(mr, 56, CY + 170, "৫′", { fs: 10.5, a: 'end', w: 650, c: C.mu });
    T(mr, 304, CY + 170, "৩′", { fs: 10.5, w: 650, c: C.mu });
  },
  /* অ্যামিনো অ্যাসিড দুলছে; কোডন-অ্যান্টিকোডনের হাইড্রোজেন বন্ধন টিমটিম */
  idle(g, C, t) {
    const CX = 180, CY = 196, Ra = BK.ramp(2);
    const b = Math.sin(t * 2.2) * 3;
    E('circle', { cx: CX + 7, cy: 30 + b, r: 17, fill: 'none', stroke: FK.alpha(Ra.c, .3 + .2 * Math.sin(t * 2.2)), 'stroke-width': 2 }, g);
    for (let i = 0; i < 3; i++) {
      const x = CX - 16 + i * 16, a = .35 + .35 * Math.sin(t * 3 + i);
      E('path', { d: `M${x} ${CY + 142}V${CY + 164}`, stroke: FK.alpha(C.acc, a), 'stroke-width': 2.2, 'stroke-dasharray': '3 3' }, g);
    }
  },
  parts: [
    { id: 'acc', bn: 'গ্রাহক বাহু (CCA)', lb: 'গ্রাহক বাহু', en: 'Acceptor arm', fn: 'tRNA-র দুই প্রান্ত মিলে তৈরি বাহু। <b>৩′ প্রান্তে CCA</b> ক্রম থাকে এবং শেষ অ্যাডেনিনের −OH-এ নির্দিষ্ট অ্যামিনো অ্যাসিড যুক্ত হয়। ৫′ প্রান্তে সাধারণত G থাকে।', a: [180, 120], l: [300, 100], an: 'end' },
    { id: 'aa', bn: 'অ্যামিনো অ্যাসিড', en: 'Amino acid', fn: 'অ্যামিনোঅ্যাসাইল-tRNA সিনথেটেজ এনজাইম ATP খরচ করে সঠিক অ্যামিনো অ্যাসিডটি সঠিক tRNA-র CCA প্রান্তে জুড়ে দেয়। এখানে অ্যান্টিকোডন UAC, তাই অ্যামিনো অ্যাসিড <b>মিথিওনিন (Met)</b> — প্রোটিন সংশ্লেষণের প্রথম অ্যামিনো অ্যাসিড।', a: [192, 30], l: [300, 30], an: 'end' },
    { id: 'dhu', bn: 'DHU লুপ', en: 'DHU loop', fn: 'বাঁ দিকের লুপ; এতে <b>ডাইহাইড্রোইউরাসিল</b> নামের বিরল ক্ষারক থাকে। অ্যামিনোঅ্যাসাইল-tRNA সিনথেটেজ এনজাইম এই অংশ দেখে tRNA-টিকে চেনে।', a: [92, 172], l: [36, 140], an: 'start' },
    { id: 'tpc', bn: 'TψC লুপ', en: 'TψC loop', fn: 'ডান দিকের লুপ; এতে <b>থাইমিন, সিউডোইউরাসিল (ψ) ও সাইটোসিন</b> থাকে। এই অংশ tRNA-কে রাইবোসোমের সাথে যুক্ত হতে সাহায্য করে।', a: [268, 172], l: [326, 140], an: 'end' },
    { id: 'var', bn: 'অতিরিক্ত বাহু', en: 'Variable arm', fn: 'অ্যান্টিকোডন ও TψC বাহুর মাঝে ছোট বাহু; এর আকার tRNA-ভেদে আলাদা — এটি দেখেও বিভিন্ন tRNA আলাদা করা যায়।', a: [230, 252], l: [330, 270], an: 'end' },
    { id: 'ac', bn: 'অ্যান্টিকোডন লুপ', lb: 'অ্যান্টিকোডন', en: 'Anticodon loop', fn: 'গ্রাহক বাহুর বিপরীত প্রান্তে; এতে তিন ক্ষারকের <b>অ্যান্টিকোডন</b> (এখানে ৩′-UAC-৫′), যা mRNA-র কোডনের সাথে পরিপূরক ও বিপরীতমুখীভাবে জোড় বাঁধে। কোডনের তৃতীয় ক্ষারকে জোড় কিছুটা ঢিলা হতে পারে — <b>ওয়াবল</b>।', a: [164, 296], l: [36, 286], an: 'start' },
    { id: 'mrna', bn: 'mRNA-র কোডন', lb: 'কোডন', en: 'mRNA codon', fn: 'mRNA-র ৫′-AUG-৩′ কোডন — প্রারম্ভিক কোডন, মিথিওনিন নির্দেশ করে। কোডন থাকে <b>mRNA-তে</b>, অ্যান্টিকোডন থাকে <b>tRNA-তে</b>।', a: [212, 372], l: [330, 356], an: 'end' }
  ]
}));
})();
