/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.২ — প্রাচীর ও ঝিল্লি
   wallLayers   : কোষপ্রাচীরের স্তর (মধ্যপর্দা → প্রাথমিক → সেকেন্ডারি), কূপ ও প্লাজমোডেজমাটা
   fluidMosaic  : ফ্লুইড-মোজাইক মডেল — উপাদান ভাসে (fluid), লেবেল-কুইজ, জুম
   memTransport : পর্দা দিয়ে পদার্থ পরিবহনের ৫ পদ্ধতি — ধাপে ধাপে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

/* ───────── ১. কোষপ্রাচীরের স্তর ───────── */
V.wallLayers = Object.assign({
  t: 'কোষপ্রাচীরের স্তরবিন্যাস', k: ['2d', 'int', 'game'],
  cap: 'দুটি পাশাপাশি কোষের সীমানা বড় করে দেখানো হলো। বাইরে থেকে ভেতরে: মধ্যপর্দা → প্রাথমিক প্রাচীর → সেকেন্ডারি প্রাচীর → কোষঝিল্লি। পরীক্ষায় সেকেন্ডারি প্রাচীর ভুল করে বাইরে আঁকা হয় — এখানে দেখো এটি সবচেয়ে ভেতরে।'
}, BK.diagram({
  W: 420, H: 312, label: 'কোষপ্রাচীরের স্তর ও প্লাজমোডেজমাটা',
  art(g, C, part) {
    const svg = g.ownerSVGElement, dk = C.dark;
    const Rw = BK.org('wall'), Rm = BK.org('mem'), Rc = BK.org('cyto'), Rp = BK.ramp(4), Rs = BK.ramp(6);
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Y0 = 26, Y1 = 274;   /* কেন্দ্র ২১০ ধরে প্রতিসম: ঝিল্লি ৯৬|৩২৪, সেকেন্ডারি ৩০, প্রাথমিক ৪০, মধ্যপর্দা ৮৮ */
    /* দুই পাশের সাইটোপ্লাজম */
    const cy = P('cyto');
    E('rect', { x: 10, y: Y0, width: 86, height: Y1 - Y0, rx: 6, fill: dk ? 'rgba(251,191,36,.08)' : '#fffbeb' }, cy);
    E('rect', { x: 324, y: Y0, width: 86, height: Y1 - Y0, rx: 6, fill: dk ? 'rgba(251,191,36,.08)' : '#fffbeb' }, cy);
    T(cy, 53, 46, 'কোষ ১', { fs: 11.5, a: 'middle', w: 560, c: C.mu }); T(cy, 367, 46, 'কোষ ২', { fs: 11.5, a: 'middle', w: 560, c: C.mu });
    /* সেকেন্ডারি (ভেতরে, পুরু, লিগনিনসহ) */
    const sec = P('sec');
    [[96, 30], [294, 30]].forEach(([x, w]) => E('rect', { x, y: Y0, width: w, height: Y1 - Y0, fill: BK.lg(svg, Rs.lt, Rs.c, { a: 0 }) }, sec));
    for (let y = Y0 + 9; y < Y1; y += 15) { E('path', { d: `M100 ${y}h22M298 ${y}h22`, stroke: FK.alpha(Rs.dk, .45), 'stroke-width': 1 }, sec); }   /* লিগনিনের স্তর */
    /* প্রাথমিক (পাতলা, স্থিতিস্থাপক) */
    const pri = P('pri');
    [[126, 40], [254, 40]].forEach(([x, w]) => E('rect', { x, y: Y0, width: w, height: Y1 - Y0, fill: BK.lg(svg, Rw.lt, FK.alpha(Rw.c, .75), { a: 0 }) }, pri));
    /* মধ্যপর্দা (মাঝখানে) */
    const mid = P('mid');
    E('rect', { x: 166, y: Y0, width: 88, height: Y1 - Y0, fill: BK.lg(svg, Rp.lt, FK.alpha(Rp.c, .55), { a: 0 }) }, mid);
    for (let i = 0; i < 12; i++) E('circle', { cx: 180 + (i % 3) * 25, cy: Y0 + 18 + Math.floor(i / 3) * 62, r: 2.3, fill: FK.alpha(Rp.dk, .55) }, mid);
    /* কোষঝিল্লি — দ্বিস্তর রেখা */
    const mm = P('mem');
    [96, 324].forEach(x => { E('path', { d: `M${x} ${Y0}V${Y1}`, stroke: Rm.c, 'stroke-width': 2.4 }, mm);
      E('path', { d: `M${x + (x < 200 ? 3.2 : -3.2)} ${Y0}V${Y1}`, stroke: FK.alpha(Rm.c, .6), 'stroke-width': 1.2 }, mm); });
    /* কূপ ও প্লাজমোডেজমাটা */
    const pd = P('pd');
    [112, 188].forEach(yc => {
      E('rect', { x: 96, y: yc - 13, width: 228, height: 26, fill: dk ? 'rgba(251,191,36,.10)' : '#fffbeb' }, pd);   /* কূপ: পাতলা অঞ্চল */
      E('path', { d: `M96 ${yc - 13}h228M96 ${yc + 13}h228`, stroke: FK.alpha(C.mu, .5), 'stroke-width': .9, 'stroke-dasharray': '3 3' }, pd);
      [-5, 0, 5].forEach(d => E('path', { d: `M96 ${yc + d}H324`, stroke: BK.org('cyto2').c, 'stroke-width': 1.8, 'stroke-linecap': 'round' }, pd));
    });
    T(g, 210, 306, 'কূপের ভেতর দিয়ে প্লাজমোডেজমাটা — দুই কোষের সাইটোপ্লাজম যুক্ত', { fs: 10.5, a: 'middle', w: 500, c: C.mu });
  },
  parts: [
    { id: 'mid', bn: 'মধ্যপর্দা', en: 'Middle lamella', fn: 'সবচেয়ে বাইরের স্তর, দুই কোষের ঠিক মাঝে। উপাদান ক্যালসিয়াম ও ম্যাগনেসিয়াম পেকটেট। পাশাপাশি দুটি কোষকে আঠার মতো জুড়ে রাখে। ফল পাকার সময় পেকটিনেজ এনজাইম একে গলিয়ে দেয়, তাই ফল নরম হয়।', a: [210, 62], l: [210, 18], an: 'middle' },
    { id: 'pri', bn: 'প্রাথমিক প্রাচীর', en: 'Primary wall', fn: 'মধ্যপর্দার ভেতরে; সেলুলোজ, হেমিসেলুলোজ ও পেকটিন দিয়ে গঠিত। পাতলা (1–3 μm), স্থিতিস্থাপক ও বর্ধনশীল — তাই কোষ বড় হওয়ার সময় এটিও বাড়ে। সব জীবন্ত উদ্ভিদকোষে থাকে।', a: [146, 262], l: [58, 282] },
    { id: 'sec', bn: 'সেকেন্ডারি প্রাচীর', en: 'Secondary wall', fn: 'সবচেয়ে ভেতরে, কোষঝিল্লি ঘেঁষে। সেলুলোজের সাথে প্রচুর লিগনিন জমে বলে পুরু (3–10 μm), শক্ত ও অস্থিতিস্থাপক। কেবল পরিণত ও যান্ত্রিক টিস্যুতে — জাইলেম ও স্ক্লেরেনকাইমায় — তৈরি হয়।', a: [111, 232], l: [58, 250] },
    { id: 'mem', bn: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'প্রাচীরের ঠিক ভেতরে জীবন্ত, বৈষম্যভেদ্য পর্দা (7.5–10 nm)। প্রাচীর সম্পূর্ণ ভেদ্য, তাই পদার্থ চলাচলের আসল নিয়ন্ত্রণ এখানেই হয়।', a: [96, 150], l: [60, 150] },
    { id: 'pd', bn: 'কূপ ও প্লাজমোডেজমাটা', lb: 'প্লাজমোডেজমাটা', en: 'Pit & plasmodesmata', le: 'Plasmodesmata', fn: 'প্রাচীরের পাতলা অঞ্চল = কূপ; তার ভেতর দিয়ে যাওয়া জীবন্ত সাইটোপ্লাজমিক সূত্র = প্লাজমোডেজমাটা। এর মাধ্যমে পানি, খনিজ, হরমোন ও সংকেত অণু কোষ থেকে কোষে যায় — এই পথকে সিমপ্লাস্ট পথ বলে।', a: [250, 112], l: [344, 86] },
    { id: 'cyto', bn: 'সাইটোপ্লাজম', en: 'Cytoplasm', fn: 'প্রাচীর ও ঝিল্লির ভেতরের জীবন্ত অংশ। লক্ষ করো — প্রাচীর দুই কোষের বাইরে, আর সাইটোপ্লাজম ভেতরে; প্লাজমোডেজমাটা এই দুই সাইটোপ্লাজমকে যুক্ত করে।', a: [70, 60], l: [70, 44], an: 'middle' }
  ]
}));

/* ───────── ২. ফ্লুইড-মোজাইক মডেল ───────── */
const HEADY = 150, TAILD = 30;
V.fluidMosaic = Object.assign({
  t: 'ফ্লুইড-মোজাইক মডেল', k: ['2d', 'anim', 'int', 'game'],
  cap: 'সিঙ্গার ও নিকলসন, ১৯৭২। লক্ষ করো অণুগুলো পাশাপাশি <b>ভাসছে</b> — এটিই "ফ্লুইড"; আর প্রোটিন অসমভাবে ছড়ানো — এটিই "মোজাইক"। শর্করা কেবল বাইরের তলে (পর্দার অপ্রতিসাম্য)। "লেবেল-কুইজ" দিয়ে চিহ্নিত চিত্র আঁকার অনুশীলন করো।'
}, BK.diagram({
  W: 420, H: 290, label: 'কোষঝিল্লির ফ্লুইড-মোজাইক মডেল',
  art(g, C, part) {
    const svg = g.ownerSVGElement;
    const Rl = BK.ramp(6), Rp = BK.ramp(1), Rg = BK.ramp(7), Rch = BK.ramp(9), Rpe = BK.ramp(4);
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    /* বাইরে ও ভেতরের পানি-পরিবেশ */
    E('rect', { x: 0, y: 0, width: 420, height: HEADY - 34, fill: FK.alpha(BK.ramp(5).c, .07) }, P('out'));
    E('rect', { x: 0, y: HEADY + 34, width: 420, height: 290 - HEADY - 34, fill: FK.alpha(BK.ramp(5).c, .04) }, P('out'));
    T(g, 12, 18, 'কোষের বাইরে', { fs: 10.5, w: 560, c: C.mu }); T(g, 12, 284, 'কোষের ভেতরে (সাইটোপ্লাজম)', { fs: 10.5, w: 560, c: C.mu });
    /* ফসফোলিপিড দ্বিস্তর — প্রোটিনের জায়গা বাদ দিয়ে */
    const lip = P('lipid'), SKIP = [[112, 56], [226, 34], [318, 30]];
    const hidden = x => SKIP.some(([a, w]) => x > a - 9 && x < a + w + 9);
    for (let x = 10; x < 414; x += 11) {
      if (hidden(x)) continue;
      [[-1, HEADY - TAILD], [1, HEADY + TAILD]].forEach(([s, y]) => {
        E('path', { d: `M${x - 2.4} ${y + s * 2}l-1.2 ${s * 20}M${x + 2.4} ${y + s * 2}l1.2 ${s * 20}`, stroke: FK.alpha(Rl.dk, .75), 'stroke-width': 1.5, 'stroke-linecap': 'round' }, lip);
        E('circle', { cx: x, cy: y, r: 4.6, fill: BK.rg(svg, Rl.lt, Rl.c), stroke: Rl.dk, 'stroke-width': .9 }, lip);
      });
    }
    /* অন্তঃস্থ (ট্রান্সমেমব্রেন) প্রোটিন */
    const ip = P('integ');
    E('path', { d: `M112 ${HEADY - 44}q-9 44 0 88h26q9 -44 0 -88z`, fill: BK.lg(svg, Rp.lt, Rp.c, { a: 70 }), stroke: Rp.dk, 'stroke-width': 1.5 }, ip);
    E('path', { d: `M148 ${HEADY - 42}h30v84h-30z`, fill: BK.lg(svg, Rp.lt, Rp.c, { a: 70 }), stroke: Rp.dk, 'stroke-width': 1.5, rx: 6 }, ip);
    E('path', { d: `M226 ${HEADY - 42}q-7 42 0 84h34q7 -42 0 -84z`, fill: BK.lg(svg, Rp.lt, Rp.c, { a: 70 }), stroke: Rp.dk, 'stroke-width': 1.5 }, ip);
    E('path', { d: `M238 ${HEADY - 42}v84`, stroke: FK.alpha(Rp.dk, .5), 'stroke-width': 8, 'stroke-linecap': 'round' }, ip);   /* চ্যানেলের ছিদ্র */
    E('path', { d: `M318 ${HEADY - 40}q-6 40 0 80h30q6 -40 0 -80z`, fill: BK.lg(svg, Rp.lt, Rp.c, { a: 70 }), stroke: Rp.dk, 'stroke-width': 1.5 }, ip);
    /* প্রান্তীয় প্রোটিন */
    const pp = P('peri');
    E('ellipse', { cx: 70, cy: HEADY + 38, rx: 17, ry: 9, fill: BK.lg(svg, Rpe.lt, Rpe.c, { a: 20 }), stroke: Rpe.dk, 'stroke-width': 1.3 }, pp);
    E('ellipse', { cx: 282, cy: HEADY - 38, rx: 15, ry: 8.5, fill: BK.lg(svg, Rpe.lt, Rpe.c, { a: 20 }), stroke: Rpe.dk, 'stroke-width': 1.3 }, pp);
    /* কোলেস্টেরল — লিপিডের ফাঁকে */
    const ch = P('chol');
    [[62, -1], [196, -1], [92, 1], [358, 1], [268, 1]].forEach(([x, s]) => {
      E('rect', { x: x - 3, y: HEADY + s * (TAILD - 16), width: 6, height: 17, rx: 3, fill: Rch.c, stroke: Rch.dk, 'stroke-width': .8 }, ch); });
    /* গ্লাইকোপ্রোটিন ও গ্লাইকোলিপিড — কেবল বাইরের তলে */
    const gl = P('glyco');
    const sugar = (x, y, n) => { for (let i = 0; i < n; i++) { const a = -1.6 + i * .55, px = x + Math.cos(a) * (10 + i * 5), py = y - Math.abs(Math.sin(a)) * 5 - 9 - i * 4;
      E('path', { d: `M${x} ${y}L${px} ${py}`, stroke: FK.alpha(Rg.dk, .7), 'stroke-width': 1.1 }, gl);
      E('circle', { cx: px, cy: py, r: 3.1, fill: Rg.c, stroke: Rg.dk, 'stroke-width': .8 }, gl); } };
    sugar(125, HEADY - 44, 3); sugar(243, HEADY - 42, 4); sugar(333, HEADY - 40, 3);   /* গ্লাইকোপ্রোটিন */
    sugar(178, HEADY - 30, 2);                                                          /* গ্লাইকোলিপিড */
  },
  /* "ফ্লুইড": অণুগুলো পাশাপাশি ধীরে ভেসে চলে */
  idle(g, C, t) {
    const Rl = BK.ramp(6), Rpe = BK.ramp(4);
    for (let i = 0; i < 5; i++) {
      const x = 30 + ((t * 9 + i * 86) % 380), s = i % 2 ? 1 : -1, y = HEADY + s * TAILD;
      E('path', { d: `M${x - 2.4} ${y + s * 2}l-1.2 ${s * 20}M${x + 2.4} ${y + s * 2}l1.2 ${s * 20}`, stroke: FK.alpha(Rl.dk, .5), 'stroke-width': 1.5, 'stroke-linecap': 'round' }, g);
      E('circle', { cx: x, cy: y, r: 4.6, fill: FK.alpha(Rl.c, .8) }, g);
    }
    const px = 60 + 40 * Math.sin(t * .5);
    E('ellipse', { cx: px, cy: HEADY + 38, rx: 17, ry: 9, fill: FK.alpha(Rpe.c, .35) }, g);
    const ar = 196 + 26 * Math.sin(t * .42);
    E('path', { d: `M${ar - 16} 22h32`, stroke: FK.alpha(C.mu, .5), 'stroke-width': 1.3, 'stroke-linecap': 'round' }, g);
    T(g, 210, 18, 'অণুগুলো পাশাপাশি ভাসছে — তাই "ফ্লুইড"', { fs: 10.5, a: 'middle', w: 500, c: C.mu });
  },
  parts: [
    { id: 'lipid', bn: 'ফসফোলিপিড দ্বিস্তর', lb: 'ফসফোলিপিড', en: 'Phospholipid bilayer', fn: 'পর্দার মূল কাঠামো। প্রতিটি অণুর <b>মাথা</b> ফসফেটযুক্ত ও পানিপ্রিয় (হাইড্রোফিলিক) — তাই দুদিকে বাইরে; <b>লেজ</b> ফ্যাটি অ্যাসিডের ও পানিবিমুখ (হাইড্রোফোবিক) — তাই ভেতরে মুখোমুখি। এই সজ্জা পানিতে আপনা-আপনি তৈরি হয়।', a: [36, 176], l: [20, 214] },
    { id: 'integ', bn: 'অন্তঃস্থ প্রোটিন', en: 'Integral protein', fn: 'লিপিড স্তরের ভেতরে গেঁথে থাকে; অনেকগুলো দুই পাশ ভেদ করে থাকে (ট্রান্সমেমব্রেন)। এগুলোই চ্যানেল, বাহক ও পাম্পের কাজ করে — অর্থাৎ পদার্থ পরিবহনের আসল পথ। শক্তিশালী ডিটারজেন্ট ছাড়া আলাদা করা যায় না।', a: [240, 190], l: [240, 250], an: 'middle' },
    { id: 'peri', bn: 'প্রান্তীয় প্রোটিন', en: 'Peripheral protein', fn: 'পর্দার উপরিতলে আলগাভাবে লেগে থাকে, লিপিড স্তর ভেদ করে না। এনজাইম বা কাঠামো ধরে রাখার কাজ করে এবং লবণ-দ্রবণেই সহজে আলাদা করা যায়।', a: [70, 188], l: [48, 254] },
    { id: 'glyco', bn: 'গ্লাইকোপ্রোটিন ও গ্লাইকোলিপিড', lb: 'গ্লাইকোক্যালিক্স', en: 'Glycoprotein & glycolipid', le: 'Glycocalyx', fn: 'প্রোটিন বা লিপিডের সাথে যুক্ত শর্করার শাখা, একসাথে গ্লাইকোক্যালিক্স। কেবল <b>বাইরের তলে</b> থাকে (পর্দার অপ্রতিসাম্য)। কোষ চেনা, কোষে কোষে সংযুক্তি ও রোগ-প্রতিরোধে কাজ করে — রক্তের গ্রুপ A, B, AB, O এই শর্করা দিয়েই নির্ধারিত।', a: [250, 92], l: [330, 52] },
    { id: 'chol', bn: 'কোলেস্টেরল', en: 'Cholesterol', fn: 'লিপিড অণুর ফাঁকে বসে পর্দার তারল্য নিয়ন্ত্রণ করে — ঠান্ডায় জমতে দেয় না, গরমে অতিরিক্ত তরল হতে দেয় না। প্রাণিকোষে উল্লেখযোগ্য পরিমাণে থাকে।', a: [196, 136], l: [150, 56] },
    { id: 'out', bn: 'পর্দার দুই পাশ', lb: 'বাইরে ও ভেতরে', en: 'Extracellular & cytoplasmic side', fn: 'দুই তলের উপাদান এক নয় — শর্করা কেবল বাইরের তলে, আর বহু প্রান্তীয় প্রোটিন কেবল ভেতরের তলে। একে পর্দার <b>অপ্রতিসাম্য</b> (asymmetry) বলে।', a: [392, 40], l: [392, 76], an: 'end' }
  ]
}));

/* ───────── ৩. পর্দা দিয়ে পদার্থ পরিবহন ───────── */
V.memTransport = Object.assign({
  t: 'কোষঝিল্লি দিয়ে পদার্থ পরিবহন', k: ['anim', 'steps', 'int'],
  cap: 'পাঁচটি পদ্ধতি পাশাপাশি। নিয়ম একটাই — পদার্থ ঘনত্বের <b>ঢাল বেয়ে নিচে</b> গেলে শক্তি লাগে না, আর <b>ঢালের বিপরীতে</b> গেলে ATP লাগে। সময়রেখা টেনে যেকোনো ধাপে থামো।'
}, BK.steps({
  W: 360, H: 250, label: 'পর্দা দিয়ে পদার্থ পরিবহনের পদ্ধতি', dur: 3.4,
  stages: [
    { t: 'ব্যাপন', en: 'Diffusion', d: 'ছোট ও চর্বিতে দ্রবণীয় অণু (O₂, CO₂) সরাসরি লিপিড স্তর ভেদ করে বেশি ঘনত্ব থেকে কম ঘনত্বে যায়। কোনো প্রোটিন বা ATP লাগে না।' },
    { t: 'অভিস্রবণ', en: 'Osmosis', d: 'বৈষম্যভেদ্য পর্দার মধ্য দিয়ে কেবল <b>পানির</b> অণু বেশি ঘনত্বের (কম দ্রব) দিক থেকে কম ঘনত্বের দিকে যায়। অ্যাকোয়াপোরিন প্রোটিন একে দ্রুত করে। ATP লাগে না।' },
    { t: 'সহজলভ্য ব্যাপন', en: 'Facilitated diffusion', d: 'বড় বা আধানযুক্ত অণু (গ্লুকোজ, অ্যামিনো অ্যাসিড, আয়ন) নিজে লিপিড ভেদ করতে পারে না — বাহক বা চ্যানেল প্রোটিনের সাহায্য নেয়। তবু ঢাল বেয়েই যায়, তাই <b>ATP লাগে না</b>।' },
    { t: 'সক্রিয় পরিবহন', en: 'Active transport', d: 'পদার্থ <b>কম ঘনত্ব থেকে বেশি ঘনত্বে</b> অর্থাৎ ঢালের বিপরীতে যায়, তাই <b>ATP ব্যয় হয়</b>। উদাহরণ: সোডিয়াম-পটাশিয়াম পাম্প (3 Na⁺ বাইরে, 2 K⁺ ভেতরে)।' },
    { t: 'এন্ডো ও এক্সোসাইটোসিস', en: 'Endo- & exocytosis', d: 'খুব বড় কণা বা অণু পর্দা ভেদ করতে পারে না। পর্দা ভাঁজ হয়ে থলিতে মুড়ে ভেতরে নেয় (এন্ডোসাইটোসিস) বা থলি পর্দার সাথে মিশে বাইরে ছাড়ে (এক্সোসাইটোসিস)। ATP লাগে।' }
  ],
  draw(g, C, s, u) {
    const Rl = BK.ramp(6), Rp = BK.ramp(1), Rd = BK.ramp(4), Rw = BK.ramp(5), Ra = BK.ramp(10);
    const MY = 125, W = 360;
    /* পর্দা */
    for (let x = 8; x < 354; x += 10) [[-1, MY - 12], [1, MY + 12]].forEach(([sg, y]) => {
      E('path', { d: `M${x} ${y + sg * 2}v${sg * 9}`, stroke: FK.alpha(Rl.dk, .7), 'stroke-width': 1.3, 'stroke-linecap': 'round' }, g);
      E('circle', { cx: x, cy: y, r: 3.4, fill: FK.alpha(Rl.c, .95) }, g); });
    T(g, 8, 20, 'বাইরে', { fs: 10.5, w: 560, c: C.mu }); T(g, 8, 240, 'ভেতরে', { fs: 10.5, w: 560, c: C.mu });
    const mov = (x, y0, y1, col, r) => E('circle', { cx: x, cy: y0 + (y1 - y0) * u, cy2: 0, r: r || 5, fill: col }, g);
    if (s === 0) { [70, 150, 240].forEach((x, i) => mov(x, 40 + i * 8, 200 + i * 6, Rd.c)); T(g, 300, 60, 'O₂, CO₂', { fs: 11, a: 'middle', w: 560, c: Rd.ink }); T(g, 180, 236, 'শক্তি লাগে না', { fs: 11, a: 'middle', w: 560, c: BK.ramp(10).ink }); }
    if (s === 1) { [60, 120, 200, 280].forEach((x, i) => mov(x, 36 + i * 10, 205 - i * 5, Rw.c, 4)); T(g, 300, 54, 'H₂O', { fs: 11.5, a: 'middle', w: 560, c: Rw.ink }); T(g, 180, 236, 'বৈষম্যভেদ্য পর্দা দিয়ে কেবল পানি', { fs: 11, a: 'middle', w: 560, c: C.mu }); }
    if (s >= 2) {   /* বাহক প্রোটিন */
      E('path', { d: `M150 ${MY - 26}q-7 26 0 52h40q7 -26 0 -52z`, fill: BK.lg(g.ownerSVGElement, Rp.lt, Rp.c, { a: 70 }), stroke: Rp.dk, 'stroke-width': 1.5 }, g);
      if (s === 2) { E('path', { d: `M166 ${MY - 26}v52`, stroke: FK.alpha(Rp.dk, .45), 'stroke-width': 9, 'stroke-linecap': 'round' }, g);
        mov(170, 40, 210, Ra.c, 6); T(g, 280, 60, 'গ্লুকোজ', { fs: 11, a: 'middle', w: 560, c: Ra.ink }); T(g, 180, 236, 'প্রোটিন লাগে, ATP লাগে না', { fs: 11, a: 'middle', w: 560, c: BK.ramp(10).ink }); }
      if (s === 3) { mov(170, 210, 40, BK.ramp(0).c, 6);
        E('circle', { cx: 212, cy: MY + 36, r: 9, fill: BK.ramp(2).c }, g); T(g, 212, MY + 40, 'ATP', { fs: 8.5, a: 'middle', w: 650, c: '#fff', st: 'stroke:none' }); 
        BK.arrow(g, 204, MY + 28, 186, MY + 10, BK.ramp(2).ink, 1.5);
        T(g, 280, 60, 'কম → বেশি', { fs: 11, a: 'middle', w: 560, c: BK.ramp(4).ink }); T(g, 180, 236, 'ঢালের বিপরীতে — ATP ব্যয় হয়', { fs: 11, a: 'middle', w: 560, c: BK.ramp(4).ink }); }
    }
    if (s === 4) {
      const d = FK.ease(u), cx = 90, cy = 60 + d * 110;
      E('circle', { cx, cy, r: 13, fill: BK.ramp(3).c, stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g);
      if (d > .35) E('circle', { cx, cy, r: 19, fill: 'none', stroke: FK.alpha(Rl.c, .9), 'stroke-width': 3.5, 'stroke-dasharray': d < .75 ? '7 6' : null }, g);
      T(g, cx, 36, 'এন্ডোসাইটোসিস', { fs: 11, a: 'middle', w: 560, c: BK.ramp(3).ink });
      const ex = 272, ey = 200 - d * 120;
      E('circle', { cx: ex, cy: ey, r: 11, fill: BK.ramp(8).c, stroke: BK.ramp(8).dk, 'stroke-width': 1.4 }, g);
      if (d < .7) E('circle', { cx: ex, cy: ey, r: 17, fill: 'none', stroke: FK.alpha(Rl.c, .9), 'stroke-width': 3.5 }, g);
      T(g, ex, 236, 'এক্সোসাইটোসিস', { fs: 11, a: 'middle', w: 560, c: BK.ramp(8).ink });
    }
  }
}));
})();
