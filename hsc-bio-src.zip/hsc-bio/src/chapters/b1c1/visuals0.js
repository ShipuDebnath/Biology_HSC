/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · কোষ ও এর গঠন — চিত্র (BK কিট)
   cellPlant  : আদর্শ উদ্ভিদকোষ — ১৫টি অংশ, বাস্তবসম্মত অন্তর্গঠন, সাইক্লোসিস চলমান
   cmpProEu   : আদিকোষ বনাম প্রকৃতকোষ — সারণি ও যাচাই খেলা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const OX = 10;                       /* লেবেলের জায়গা রাখতে কোষ ডানে সরানো */
const W = 440, H = 362;
const rot = (g, x, y, a) => E('g', { transform: `rotate(${a} ${x} ${y})` }, g);

/* ───── ক্লোরোপ্লাস্ট: দ্বিস্তরী আবরণ + গ্রানা (থাইলাকয়েডের স্তূপ) + স্ট্রোমা লামেলি + স্টার্চ দানা ───── */
const chloro = (g, svg, cx, cy, ang, sc = 1, lite) => {
  const R = BK.org('chloro'), gg = rot(g, cx, cy, ang), rx = 21 * sc, ry = 12 * sc;
  if (lite) { E('ellipse', { cx, cy, rx, ry, fill: R.c, stroke: R.dk, 'stroke-width': 1.2 }, gg);
    [-8, 0, 8].forEach(dx => E('rect', { x: cx + dx * sc - 2.2 * sc, y: cy - 3 * sc, width: 4.4 * sc, height: 6 * sc, rx: .6, fill: R.dk }, gg)); return; }
  E('ellipse', { cx, cy, rx, ry, fill: BK.rg(svg, R.lt, R.c), stroke: R.dk, 'stroke-width': 1.5 * sc }, gg);
  E('ellipse', { cx, cy, rx: rx - 2.4 * sc, ry: ry - 2.4 * sc, fill: 'none', stroke: FK.alpha(R.dk, .5), 'stroke-width': .9 * sc }, gg);  /* ভেতরের আবরণ */
  const G = [-12, -4, 5, 13];
  G.forEach((dx, i) => { const n = 4 + (i % 2), hh = 1.5 * sc;                     /* গ্রানাম = থাইলাকয়েড চাকতির স্তূপ */
    for (let k = 0; k < n; k++) E('rect', { x: cx + dx * sc - 2.6 * sc, y: cy - (n * hh) / 2 + k * hh - .2, width: 5.2 * sc, height: hh * .78, rx: .5, fill: R.dk }, gg);
  });
  E('path', { d: `M${cx - 12 * sc} ${cy - 1.6 * sc}H${cx + 13 * sc}M${cx - 12 * sc} ${cy + 2 * sc}H${cx + 13 * sc}`, stroke: FK.alpha(R.dk, .55), 'stroke-width': .7 * sc, fill: 'none' }, gg);  /* স্ট্রোমা লামেলি */
  E('ellipse', { cx: cx - 17 * sc, cy: cy + 2 * sc, rx: 3.4 * sc, ry: 2.6 * sc, fill: FK.dark() ? '#e9ecef' : '#fff', opacity: .85 }, gg);   /* স্টার্চ দানা */
};
/* ───── মাইটোকন্ড্রিয়ন: বহিঃ ও অন্তঃপর্দা, ভাঁজ হয়ে ক্রিস্টি, ভেতরে ম্যাট্রিক্স ───── */
const mito = (g, svg, cx, cy, ang, sc = 1) => {
  const R = BK.org('mito'), gg = rot(g, cx, cy, ang), rx = 20 * sc, ry = 11 * sc;
  E('ellipse', { cx, cy, rx, ry, fill: BK.rg(svg, R.lt, R.c), stroke: R.dk, 'stroke-width': 1.5 * sc }, gg);       /* বহিঃপর্দা */
  E('ellipse', { cx, cy, rx: rx - 2.6 * sc, ry: ry - 2.6 * sc, fill: FK.alpha(R.lt, .55), stroke: 'none' }, gg);   /* ম্যাট্রিক্স */
  let d = '';                                                                                                      /* ক্রিস্টি: অন্তঃপর্দার আঙুলের মতো ভাঁজ */
  for (let i = 0; i < 6; i++) { const x = cx - 13 * sc + i * 5.2 * sc, up = i % 2 ? 1 : -1, y0 = cy + up * (ry - 2.6 * sc);
    d += `M${x - 2.4 * sc} ${y0}q${2.4 * sc} ${-up * 11 * sc} ${4.8 * sc} 0`; }
  E('path', { d, stroke: R.dk, 'stroke-width': 1.25 * sc, fill: 'none', 'stroke-linecap': 'round' }, gg);
};

V.cellPlant = Object.assign({
  t: 'একটি আদর্শ উদ্ভিদকোষ', k: ['2d', 'int', 'anim', 'game'],
  cap: 'অংশে বা লেবেলে চাপ দিলে নাম ও কাজ দেখাবে; দুই আঙুলে বা +/− বোতামে বড় করে ভেতরের গঠন (ক্রিস্টি, গ্রানা, নিউক্লিয়ার ছিদ্র) দেখা যাবে। "লেবেল-কুইজ" এ নাম দেখে ঠিক অংশ খুঁজতে হবে। জীবন্ত কোষে সাইটোপ্লাজম ঘোরে — সেটিই সাইক্লোসিস।'
}, BK.diagram({
  W, H, label: 'আদর্শ উদ্ভিদকোষের লেবেলযুক্ত চিত্র',
  art(g0, C, part) {
    const g = E('g', { transform: `translate(${OX},0)` }, g0), svg = g0.ownerSVGElement || g0.closest('svg'), dk = C.dark;
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rw = BK.org('wall'), Rm = BK.org('mem'), Rc = BK.org('cyto'), Rn = BK.org('nucleus'),
          Rer = BK.org('er'), Rg = BK.org('golgi'), Rv = BK.org('vacuole'), Rp = BK.org('peroxi'), Rk = BK.org('cytoskel'), Rr = BK.org('ribo');
    const IN = { x: 98, y: 28, w: 214, h: 300 };                      /* কোষঝিল্লির ভেতরের আয়তক্ষেত্র */

    /* ── সাইটোপ্লাজম ── */
    E('rect', Object.assign({}, IN, { rx: 16, fill: dk ? 'rgba(251,191,36,.07)' : '#fffbeb' }), P('cyto'));

    /* ── কোষপ্রাচীর: মধ্যপর্দা + প্রাথমিক প্রাচীর, সেলুলোজ তন্তুর রেখা, প্লাজমোডেজমাটার ফাঁক ── */
    const w = P('wall');
    E('rect', { x: 88, y: 18, width: 234, height: 320, rx: 22, fill: 'none', stroke: FK.alpha(Rw.dk, .55), 'stroke-width': 12 }, w);   /* মধ্যপর্দা */
    E('rect', { x: 88, y: 18, width: 234, height: 320, rx: 22, fill: 'none', stroke: BK.lg(svg, Rw.lt, Rw.c, { a: 120 }), 'stroke-width': 8 }, w);
    for (let i = 0; i < 26; i++) { const t = i / 26 * 4, side = Math.floor(t), f = t - side;   /* সেলুলোজ মাইক্রোফাইব্রিল */
      const pts = [[88 + 234 * f, 18], [322, 18 + 320 * f], [322 - 234 * f, 338], [88, 338 - 320 * f]][side];
      if (!pts) continue; const vert = side % 2;
      E('path', { d: vert ? `M${pts[0] - 4} ${pts[1]}h8` : `M${pts[0]} ${pts[1] - 4}v8`, stroke: FK.alpha(Rw.dk, .35), 'stroke-width': .9 }, w); }
    [[88, 118], [88, 236], [322, 150], [322, 262], [196, 18], [196, 338]].forEach(([x, y]) => { const h = y === 18 || y === 338;
      E('rect', { x: x - (h ? 4 : 7), y: y - (h ? 7 : 4), width: h ? 8 : 14, height: h ? 14 : 8, rx: 2, fill: C.sf }, w); });

    /* ── কোষঝিল্লি: দ্বিস্তরী ফসফোলিপিড (দুটি রেখা) ── */
    const m = P('mem');
    E('rect', Object.assign({}, IN, { rx: 16, fill: 'none', stroke: Rm.c, 'stroke-width': 2.2 }), m);
    E('rect', { x: IN.x + 2.6, y: IN.y + 2.6, width: IN.w - 5.2, height: IN.h - 5.2, rx: 14, fill: 'none', stroke: FK.alpha(Rm.c, .6), 'stroke-width': 1.1 }, m);

    /* ── কোষ গহ্বর: টোনোপ্লাস্ট + কোষরস ── */
    const v = P('vac');
    E('ellipse', { cx: 214, cy: 186, rx: 70, ry: 86, fill: BK.rg(svg, FK.alpha(Rv.lt, dk ? .5 : .85), FK.alpha(Rv.c, dk ? .35 : .45)), stroke: Rv.c, 'stroke-width': 2 }, v);
    E('ellipse', { cx: 214, cy: 186, rx: 66.5, ry: 82.5, fill: 'none', stroke: FK.alpha(Rv.c, .45), 'stroke-width': 1 }, v);
    T(v, 214, 190, 'কোষরস', { fs: 10, a: 'middle', c: FK.alpha(Rv.dk, .75), w: 500 });

    /* ── নিউক্লিয়াস: দ্বিস্তরী পর্দা, ছিদ্র, ক্রোমাটিন, নিউক্লিওলাস ── */
    const n = P('nuc'); const nx = 146, ny = 86, nr = 33;
    E('circle', { cx: nx, cy: ny, r: nr, fill: BK.rg(svg, Rn.lt, FK.alpha(Rn.c, dk ? .55 : .75)), stroke: Rn.dk, 'stroke-width': 2.4 }, n);
    E('circle', { cx: nx, cy: ny, r: nr - 3.4, fill: 'none', stroke: FK.alpha(Rn.dk, .5), 'stroke-width': 1 }, n);
    for (let i = 0; i < 9; i++) { const a = i * 2 * Math.PI / 9 + .3, x = nx + (nr - 1.7) * Math.cos(a), y = ny + (nr - 1.7) * Math.sin(a);   /* নিউক্লিয়ার ছিদ্র */
      E('circle', { cx: x, cy: y, r: 2.5, fill: C.sf, stroke: Rn.dk, 'stroke-width': 1 }, n); }
    for (let i = 0; i < 7; i++) { const a = i * 1.05, r0 = 8 + (i % 3) * 6;   /* ক্রোমাটিন সুতো */
      E('path', { d: `M${nx + r0 * Math.cos(a)} ${ny + r0 * Math.sin(a)}q6 4 3 9t-7 5`, stroke: Rn.dk, 'stroke-width': 1.4, fill: 'none', opacity: .55, 'stroke-linecap': 'round' }, n); }
    const nl = P('nucl');
    E('circle', { cx: nx + 10, cy: ny - 9, r: 9.5, fill: BK.rg(svg, FK.alpha(Rn.c, .9), Rn.dk) }, nl);
    for (let i = 0; i < 6; i++) E('circle', { cx: nx + 10 + (Math.random = null, [-4, 2, 5, -1, 3, -5][i]), cy: ny - 9 + [2, -4, 3, 5, -2, -1][i], r: 1.1, fill: FK.alpha('#fff', .45) }, nl);

    /* ── অমসৃণ ER: নিউক্লিয়ার পর্দা থেকে বেরিয়েছে, গায়ে রাইবোসোম ── */
    const er = P('er');
    const erY = [52, 64, 76];
    erY.forEach((y, i) => E('path', { d: `M${nx + nr - 4} ${ny - 26 + i * 7}q14 ${-6 + i * 2} 30 ${-2 + i}t34 ${2 - i}t26 ${1 + i}`, stroke: Rer.c, 'stroke-width': 3.4, fill: 'none', 'stroke-linecap': 'round', opacity: .95 }, er));
    const sm = P('smer');   /* মসৃণ ER: নলাকার, রাইবোসোমহীন */
    E('path', { d: 'M120 246q12 -10 24 0t24 -2', stroke: Rer.c, 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round', opacity: .6 }, sm);
    E('path', { d: 'M118 258q14 -8 26 2t22 -4', stroke: Rer.c, 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round', opacity: .6 }, sm);
    const rb = P('ribo');
    erY.forEach((y, i) => { for (let k = 0; k < 11; k++) { const x = nx + nr + 2 + k * 8.4, yy = ny - 26 + i * 7 - 4.6 + Math.sin(k * .9 + i) * 1.6;
      if (x < 300) E('circle', { cx: x, cy: yy, r: 1.8, fill: Rr.c, opacity: .9 }, rb); } });
    for (let i = 0; i < 9; i++) E('circle', { cx: 112 + (i % 3) * 7, cy: 112 + Math.floor(i / 3) * 8, r: 1.9, fill: Rr.dk, opacity: .8 }, rb);   /* মুক্ত রাইবোসোম */

    /* ── গলগি বডি: সিস ও ট্রান্স তল, ৫টি সিস্টার্নি, মুকুলিত ভেসিকল ── */
    const go = P('golgi');
    for (let i = 0; i < 5; i++) { const y = 138 + i * 7.5, wd = 30 - Math.abs(i - 2) * 2.5;
      E('path', { d: `M${116 + i * 1.2} ${y}q${wd / 2} ${-7 + i * .8} ${wd} 0`, stroke: i === 0 ? FK.alpha(Rg.c, .75) : Rg.c, 'stroke-width': 3.6, fill: 'none', 'stroke-linecap': 'round' }, go); }
    [[152, 150, 3], [155, 163, 2.4], [148, 175, 2]].forEach(([x, y, r]) => E('circle', { cx: x, cy: y, r, fill: Rg.c, stroke: Rg.dk, 'stroke-width': .8 }, go));
    T(go, 114, 133, 'সিস', { fs: 8.5, c: FK.alpha(Rg.dk, .8), w: 560 }); T(go, 114, 182, 'ট্রান্স', { fs: 8.5, c: FK.alpha(Rg.dk, .8), w: 560 });

    /* ── পারঅক্সিসোম: কেলাসাকার কেন্দ্র ── */
    const px = P('perox');
    E('circle', { cx: 288, cy: 96, r: 9, fill: BK.rg(svg, Rp.lt, Rp.c), stroke: Rp.dk, 'stroke-width': 1.3 }, px);
    E('rect', { x: 284.5, y: 92.5, width: 7, height: 7, rx: 1, fill: Rp.dk, opacity: .75, transform: 'rotate(18 288 96)' }, px);

    /* ── কোষীয় কঙ্কাল: মাইক্রোটিউবিউল ── */
    const ck = P('skel');
    [['M106 196q22 14 16 42', 1.3], ['M300 210q-20 18 -10 44', 1.3], ['M150 300q26 -12 48 -4', 1.2], ['M276 60q10 24 -2 40', 1.2]].forEach(([d, lw]) =>
      E('path', { d, stroke: Rk.c, 'stroke-width': lw, fill: 'none', opacity: .5, 'stroke-dasharray': '5 3' }, ck));

    /* ── মাইটোকন্ড্রিয়া ও ক্লোরোপ্লাস্ট ── */
    const mi = P('mito'); mito(mi, svg, 122, 212, 72); mito(mi, svg, 186, 310, 4);
    const ch = P('chl'); [[292, 148, 74], [296, 238, 102], [244, 306, 8], [120, 290, 24]].forEach(([x, y, a]) => chloro(ch, svg, x, y, a));
  },
  /* সাইক্লোসিস: জীবন্ত কোষে সাইটোপ্লাজম কোষ গহ্বরের চারপাশে ধীরে ঘোরে, সাথে ক্লোরোপ্লাস্টও */
  idle(g, C, t) {
    const svg = g.ownerSVGElement, cx = 214 + OX, cy = 186, rx = 84, ry = 98, R = BK.org('chloro'), Rr = BK.org('ribo');
    for (let i = 0; i < 8; i++) {
      const a = t * 0.24 + i * 2 * Math.PI / 8, x = cx + rx * Math.cos(a), y = cy + ry * Math.sin(a);
      if (i % 2) chloro(g, svg, x, y, (a * 180 / Math.PI + 95) % 180, .62, true);
      else E('circle', { cx: x, cy: y, r: 2.4, fill: Rr.dk, opacity: .6 }, g);
    }
    const ar = t * 0.24 + 0.4;
    E('path', { d: `M${cx + (rx + 14) * Math.cos(ar)} ${cy + (ry + 14) * Math.sin(ar)}a${rx + 14} ${ry + 14} 0 0 1 ${(rx + 14) * (Math.cos(ar + .5) - Math.cos(ar))} ${(ry + 14) * (Math.sin(ar + .5) - Math.sin(ar))}`, stroke: FK.alpha(C.mu, .4), 'stroke-width': 1.4, fill: 'none', 'stroke-linecap': 'round' }, g);
    T(g, cx, 352, 'সাইক্লোসিস — সাইটোপ্লাজম ঘুরছে', { fs: 10.5, a: 'middle', w: 500, c: C.mu });
  },
  parts: [
    { id: 'wall', bn: 'কোষপ্রাচীর', en: 'Cell wall', fn: 'সেলুলোজ, হেমিসেলুলোজ ও পেকটিনের জড় স্তর। বাইরের মধ্যপর্দা (middle lamella) পাশের কোষের সাথে জোড়া লাগায়, ভেতরে প্রাথমিক প্রাচীরে সেলুলোজের মাইক্রোফাইব্রিল জালের মতো সাজানো। কোষকে আকৃতি, দৃঢ়তা ও সুরক্ষা দেয়; প্রাণিকোষে থাকে না।', a: [91, 44], l: [78, 34] },
    { id: 'nuc', bn: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'দ্বিস্তরী নিউক্লিয়ার পর্দা, যাতে অসংখ্য নিউক্লিয়ার ছিদ্র (চিত্রে ফাঁকা বৃত্ত) — এগুলো দিয়ে mRNA বেরোয় ও প্রোটিন ঢোকে। ভেতরে ক্রোমাটিন (DNA + হিস্টোন) ও নিউক্লিওলাস। কোষের সব কাজ নিয়ন্ত্রণ করে, বংশগতির বৈশিষ্ট্য বহন করে।', a: [120, 96], l: [76, 86] },
    { id: 'nucl', bn: 'নিউক্লিওলাস', en: 'Nucleolus', fn: 'নিউক্লিয়াসের ভেতরের পর্দাবিহীন গাঢ় অংশ। rRNA তৈরি করে ও রাইবোসোমের উপএকক গঠন করে, তাই প্রোটিন-ব্যস্ত কোষে বড় থাকে।', a: [152, 78], l: [76, 62] },
    { id: 'er', bn: 'অমসৃণ এন্ডোপ্লাজমিক রেটিকুলাম', lb: 'অমসৃণ ER', en: 'Rough endoplasmic reticulum', le: 'Rough ER', fn: 'নিউক্লিয়ার পর্দার সাথে যুক্ত চ্যাপ্টা থলির জালিকা; গায়ে রাইবোসোম লেগে থাকায় অমসৃণ দেখায়। এখানে তৈরি প্রোটিন ভাঁজ হয়ে গলগিতে পাঠানো হয়।', a: [250, 62], l: [330, 78] },
    { id: 'ribo', bn: 'রাইবোসোম', en: 'Ribosome', fn: 'পর্দাবিহীন ক্ষুদ্র কণা (rRNA + প্রোটিন); প্রকৃতকোষে 80S, মাইটোকন্ড্রিয়া ও প্লাস্টিডে 70S। প্রোটিন সংশ্লেষণের স্থান — ER-এর গায়ে লেগে বা সাইটোপ্লাজমে মুক্ত অবস্থায়।', a: [214, 48], l: [330, 30] },
    { id: 'perox', bn: 'পারঅক্সিসোম', en: 'Peroxisome', fn: 'একক পর্দাবেষ্টিত ক্ষুদ্র অঙ্গাণু, ভেতরে প্রায়ই এনজাইমের কেলাসাকার কেন্দ্র। ক্যাটালেজ এনজাইম বিষাক্ত H₂O₂ ভেঙে পানি ও অক্সিজেন করে; পাতায় আলোকশ্বসনেও অংশ নেয়।', a: [296, 96], l: [330, 102] },
    { id: 'vac', bn: 'কোষ গহ্বর', en: 'Vacuole', fn: 'টোনোপ্লাস্ট নামের একক পর্দায় ঘেরা বড় থলি, ভেতরে কোষরস (পানি, খনিজ, রঞ্জক, বর্জ্য)। পরিণত উদ্ভিদকোষে প্রায় ৯০% জায়গা নেয়, রসস্ফীতি (টার্গর) দিয়ে কোষকে টানটান রাখে।', a: [280, 170], l: [330, 150] },
    { id: 'mem', bn: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'ফসফোলিপিডের দ্বিস্তর, তাতে ভাসমান প্রোটিন — ফ্লুইড-মোজাইক মডেল। অর্ধভেদ্য: কোষে কী ঢুকবে ও বেরোবে তা নিয়ন্ত্রণ করে।', a: [312, 224], l: [330, 206] },
    { id: 'skel', bn: 'কোষীয় কঙ্কাল', en: 'Cytoskeleton', fn: 'মাইক্রোটিউবিউল ও মাইক্রোফিলামেন্টের জাল। কোষের আকৃতি ধরে রাখে, অঙ্গাণু সরায় এবং সাইক্লোসিস ঘটায়।', a: [300, 240], l: [330, 250] },
    { id: 'chl', bn: 'ক্লোরোপ্লাস্ট', en: 'Chloroplast', fn: 'দ্বিস্তরী আবরণে ঘেরা সবুজ প্লাস্টিড। ভেতরে থাইলাকয়েড চাকতি স্তূপ হয়ে গ্রানাম, গ্রানামগুলো স্ট্রোমা লামেলি দিয়ে যুক্ত; চারপাশে স্ট্রোমা ও স্টার্চ দানা। ক্লোরোফিল আলো শোষণ করে সালোকসংশ্লেষণ ঘটায়। নিজস্ব DNA ও 70S রাইবোসোম আছে।', a: [268, 306], l: [330, 300] },
    { id: 'mito', bn: 'মাইটোকন্ড্রিয়া', en: 'Mitochondrion', fn: 'দ্বিস্তরী পর্দা — বহিঃপর্দা মসৃণ, অন্তঃপর্দা ভাঁজ হয়ে ক্রিস্টি তৈরি করে (চিত্রে ভেতরের আঙুলের মতো ভাঁজ), ভেতরে তরল ম্যাট্রিক্স। ক্রেবস চক্র ও ইলেকট্রন স্থানান্তর এখানেই ঘটে, ATP তৈরি হয় — তাই একে কোষের শক্তিঘর বলে। যে কোষে শক্তি বেশি লাগে সেখানে সংখ্যা বেশি।', a: [126, 212], l: [76, 206] },
    { id: 'golgi', bn: 'গলগি বডি', en: 'Golgi body', fn: 'চ্যাপ্টা থলির (সিস্টার্নি) স্তূপ। ER-মুখী সিস তল দিয়ে প্রোটিন ঢোকে, ট্রান্স তল দিয়ে ভেসিকলে মুড়ে বেরোয়। প্রক্রিয়াজাতকরণ ও ক্ষরণের কেন্দ্র; উদ্ভিদে কোষপ্লেট ও কোষপ্রাচীরের উপাদান জোগায়।', a: [122, 158], l: [76, 150] },
    { id: 'smer', bn: 'মসৃণ এন্ডোপ্লাজমিক রেটিকুলাম', lb: 'মসৃণ ER', en: 'Smooth endoplasmic reticulum', le: 'Smooth ER', fn: 'রাইবোসোমবিহীন নলাকার জালিকা। লিপিড ও স্টেরয়েড তৈরি করে, বিষাক্ত পদার্থ নিষ্ক্রিয় করে এবং Ca²⁺ জমা রাখে।', a: [128, 252], l: [76, 252] },
    { id: 'cyto', bn: 'সাইটোপ্লাজম', en: 'Cytoplasm', fn: 'কোষঝিল্লি ও নিউক্লিয়াসের মাঝের অর্ধতরল অংশ (সাইটোসল + অঙ্গাণু)। গ্লাইকোলাইসিসসহ বহু বিপাক এখানেই ঘটে; জীবন্ত কোষে এটি ধীরে ঘোরে — সাইক্লোসিস।', a: [112, 300], l: [76, 306] }
  ].map(p => Object.assign(p, { a: [p.a[0] + OX, p.a[1]], l: [p.l[0] + OX, p.l[1]] }))
}));

V.cmpProEu = Object.assign({
  t: 'আদিকোষ বনাম প্রকৃতকোষ', k: ['info', 'game'],
  cap: '"যাচাই খেলা" তে একটি বৈশিষ্ট্য দেখাবে — সেটি আদিকোষের না প্রকৃতকোষের, বলো।'
}, BK.compare({
  a: 'আদিকোষ', b: 'প্রকৃতকোষ',
  rows: [
    ['নিউক্লিয়াস', 'সুগঠিত নিউক্লিয়াস নেই; DNA সাইটোপ্লাজমে নিউক্লিওয়েড রূপে থাকে', 'সুগঠিত নিউক্লিয়াস আছে'],
    ['নিউক্লিয়ার পর্দা ও নিউক্লিওলাস', 'অনুপস্থিত', 'উপস্থিত'],
    ['ক্রোমোসোম', 'একটি, বৃত্তাকার DNA; হিস্টোন প্রোটিন নেই', 'একাধিক, সূত্রাকার; হিস্টোন প্রোটিনযুক্ত'],
    ['রাইবোসোম', '70S', '80S (মাইটোকন্ড্রিয়া ও প্লাস্টিডে 70S)'],
    ['পর্দাবেষ্টিত অঙ্গাণু', 'মাইটোকন্ড্রিয়া, প্লাস্টিড, গলগি বডি, ER নেই', 'মাইটোকন্ড্রিয়া, গলগি বডি, ER আছে (উদ্ভিদে প্লাস্টিডও)'],
    ['কোষ বিভাজন', 'দ্বিবিভাজন (অ্যামাইটোসিস)', 'মাইটোসিস ও মায়োসিস'],
    ['আকার', 'সাধারণত 1–10 μm', 'সাধারণত 10–100 μm'],
    ['উদাহরণ', 'ব্যাকটেরিয়া, সায়ানোব্যাকটেরিয়া', 'উদ্ভিদ, প্রাণী, ছত্রাক, শৈবাল']
  ]
}));
})();
