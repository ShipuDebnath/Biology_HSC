/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.১১ — জিন ও জেনেটিক কোড
   codonTable : জেনেটিক কোড টেবিল — কোডন ছুঁয়ে অ্যামিনো অ্যাসিড, কোডন সংখ্যা,
                এবং mRNA অনুবাদক (মিউটেশন খেলা: নীরব / মিসসেন্স / ননসেন্স / ফ্রেমশিফট)
   lacOperon  : ল্যাক অপেরন — চার অবস্থা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B = 'UCAG', AA1 = 'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG';
const CODE = {}; for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) for (let k = 0; k < 4; k++) CODE[B[i] + B[j] + B[k]] = AA1[16 * i + 4 * j + k];
const NM = { F: ['ফিনাইলঅ্যালানিন', 'Phe'], L: ['লিউসিন', 'Leu'], S: ['সেরিন', 'Ser'], Y: ['টাইরোসিন', 'Tyr'], C: ['সিস্টিন', 'Cys'], W: ['ট্রিপটোফ্যান', 'Trp'], P: ['প্রোলিন', 'Pro'], H: ['হিস্টিডিন', 'His'], Q: ['গ্লুটামিন', 'Gln'], R: ['আর্জিনিন', 'Arg'], I: ['আইসোলিউসিন', 'Ile'], M: ['মিথিওনিন', 'Met'], T: ['থ্রিওনিন', 'Thr'], N: ['অ্যাসপারাজিন', 'Asn'], K: ['লাইসিন', 'Lys'], V: ['ভ্যালিন', 'Val'], A: ['অ্যালানিন', 'Ala'], D: ['অ্যাসপারটিক অ্যাসিড', 'Asp'], E: ['গ্লুটামিক অ্যাসিড', 'Glu'], G: ['গ্লাইসিন', 'Gly'], '*': ['স্টপ', 'STOP'] };
const CNT = {}; Object.values(CODE).forEach(a => CNT[a] = (CNT[a] || 0) + 1);
/* পানিবিমুখ / পানিপ্রিয় / আধানযুক্ত — রঙের দল */
const GRP = a => a === '*' ? 0 : 'FLIMVWAP'.includes(a) ? 1 : 'DEKRH'.includes(a) ? 2 : 3;
const MRNA = { n: ['AUG', 'UUU', 'GGC', 'UCA', 'UGG', 'UAA'] };
const MUTS = [
  ['n', 'স্বাভাবিক', s => s],
  ['si', 'নীরব', s => s.replace('UUU', 'UUC')],
  ['mi', 'মিসসেন্স', s => s.replace('GGC', 'AGC')],
  ['no', 'ননসেন্স', s => s.replace('UGG', 'UGA')],
  ['fs', 'ফ্রেমশিফট', s => s.slice(0, 12) + 'A' + s.slice(12)]
];
const MNOTE = {
  n: 'স্বাভাবিক জিন — ৫টি অ্যামিনো অ্যাসিড, তারপর UAA-তে থামে।',
  si: 'UUU → UUC: দুটিই ফিনাইলঅ্যালানিন। প্রোটিন অপরিবর্তিত — <b>নীরব মিউটেশন</b> (অপভ্রংশতার ফল)।',
  mi: 'GGC → AGC: গ্লাইসিনের জায়গায় সেরিন। একটি অ্যামিনো অ্যাসিড বদলেছে — <b>মিসসেন্স মিউটেশন</b> (সিকেল সেল এমনই)।',
  no: 'UGG → UGA: ট্রিপটোফ্যানের জায়গায় স্টপ! প্রোটিন অসম্পূর্ণ — <b>ননসেন্স মিউটেশন</b>।',
  fs: 'চতুর্থ কোডনের পর একটি A যোগ — এরপর সব কোডন বদলে গেছে, মূল স্টপও হারিয়েছে — <b>ফ্রেমশিফট মিউটেশন</b>।'
};

V.codonTable = Object.assign({
  t: 'জেনেটিক কোড টেবিল ও মিউটেশন খেলা', k: ['2d', 'int', 'game'],
  cap: 'উপরে পুরো কোড টেবিল — সারি = প্রথম ক্ষারক, কলাম = দ্বিতীয়, ঘরের ভেতরে = তৃতীয়। যেকোনো কোডন ছুঁয়ে দেখো কোন অ্যামিনো অ্যাসিড ও তার কয়টি কোডন। নিচে একটি mRNA — মিউটেশনের ধরন বদলে দেখো প্রোটিনে কী ঘটে।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    <div class="bk-info" data-k="pick" aria-live="polite"></div>
    <div class="fk-row">${X.seg('mut', MUTS.map(m => [m[0], m[1]]), 'n')}</div>
    <div class="fk-stage bk-stage" data-k="tr"></div>
    <div class="bk-info" data-k="mnote" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    let sel = 'AUG', mut = 'n';
    const colOf = (a, C) => [BK.ramp(4), BK.ramp(2), BK.ramp(5), BK.ramp(10)][GRP(a)];
    const table = () => {
      const C = FK.P(); $('st').innerHTML = '';
      const W = 380, H = 352, X0 = 26, Y0 = 34, CW = 87, CH = 72;
      const svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'জেনেটিক কোড টেবিল' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      for (let j = 0; j < 4; j++) T(svg, X0 + j * CW + CW / 2, 22, B[j], { fs: 13, a: 'middle', w: 700, c: C.mu });
      T(svg, 12, 16, '১ম↓ ২য়→', { fs: 8, w: 520, c: C.mu });
      for (let i = 0; i < 4; i++) {
        T(svg, 12, Y0 + i * CH + CH / 2 + 4, B[i], { fs: 13, a: 'middle', w: 700, c: C.mu });
        for (let j = 0; j < 4; j++) {
          E('rect', { x: X0 + j * CW + 1, y: Y0 + i * CH + 1, width: CW - 2, height: CH - 2, rx: 6, fill: FK.alpha(C.mu, .06), stroke: FK.alpha(C.mu, .25) }, svg);
          for (let k = 0; k < 4; k++) {
            const cod = B[i] + B[j] + B[k], a = CODE[cod], R = colOf(a, C), on = cod === sel, same = CODE[sel] === a;
            const x = X0 + j * CW + 4, y = Y0 + i * CH + 4 + k * 16.5, w = CW - 8;
            const g = E('g', { 'data-cod': cod, style: 'cursor:pointer' }, svg);
            E('rect', { x, y, width: w, height: 15, rx: 4, fill: on ? R.c : same ? FK.alpha(R.c, .45) : FK.alpha(R.lt, .55), stroke: on ? R.dk : 'none', 'stroke-width': 1.6 }, g);
            T(g, x + 4, y + 11.5, cod, { fs: 9.5, w: 700, c: on ? '#fff' : C.fg, st: 'stroke:none' });
            T(g, x + w - 4, y + 11.5, NM[a][1], { fs: 9, a: 'end', w: 650, c: on ? '#fff' : R.ink, st: 'stroke:none' });
          }
        }
      }
      [[BK.ramp(2), 'পানিবিমুখ'], [BK.ramp(5), 'আধানযুক্ত'], [BK.ramp(10), 'পানিপ্রিয়'], [BK.ramp(4), 'স্টপ']].forEach(([R, lab], i) => {
        E('rect', { x: 26 + i * 90, y: H - 22, width: 12, height: 10, rx: 3, fill: R.c }, svg);
        T(svg, 42 + i * 90, H - 13, lab, { fs: 9.5, w: 560, c: C.mu });
      });
      svg.addEventListener('click', e => { const g = e.target.closest('[data-cod]'); if (!g) return; sel = g.dataset.cod; table(); pick(); });
    };
    const pick = () => {
      const a = CODE[sel], n = CNT[a], others = Object.keys(CODE).filter(c => CODE[c] === a);
      const extra = sel === 'AUG' ? ' — <b>প্রারম্ভিক কোডন</b>' : a === '*' ? ' — ট্রান্সলেশন থামায়; এখানে মুক্তি ফ্যাক্টর বসে' : '';
      $('pick').innerHTML = `<b>${sel}</b> → ${NM[a][0]} (${NM[a][1]})${extra}`
        + `<div class="small">${a === '*' ? 'স্টপ কোডন' : 'এই অ্যামিনো অ্যাসিডের'} মোট <b>${FK.bn(n)}টি</b> কোডন: ${others.join(', ')}${n > 1 && a !== '*' ? ' — অপভ্রংশতা' : n === 1 ? ' — একটিমাত্র কোডন' : ''}</div>`;
    };
    const transl = () => {
      const C = FK.P(); $('tr').innerHTML = '';
      const m = MUTS.find(x => x[0] === mut), seq = m[2](MRNA.n.join(''));
      const W = 380, H = 128;
      const svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'mRNA অনুবাদ' }, $('tr'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const base = MRNA.n.join('');
      let stop = false;
      for (let i = 0; i * 3 + 3 <= seq.length && i < 6; i++) {
        const cod = seq.slice(i * 3, i * 3 + 3), a = CODE[cod], changed = cod !== base.slice(i * 3, i * 3 + 3);
        const x = 14 + i * 60, R = colOf(a, C);
        E('rect', { x, y: 18, width: 54, height: 24, rx: 5, fill: changed ? FK.alpha(BK.ramp(4).c, .25) : FK.alpha(BK.ramp(9).lt, .6), stroke: changed ? BK.ramp(4).dk : FK.alpha(C.mu, .4), 'stroke-width': changed ? 2 : 1 }, svg);
        T(svg, x + 27, 35, cod, { fs: 12, a: 'middle', w: 700, c: C.fg });
        if (!stop) {
          E('path', { d: `M${x + 27} 46V58`, stroke: FK.alpha(C.mu, .5), 'stroke-width': 1.4 }, svg);
          E('circle', { cx: x + 27, cy: 76, r: 17, fill: a === '*' ? FK.alpha(R.c, .3) : R.c, stroke: R.dk, 'stroke-width': 1.4 }, svg);
          T(svg, x + 27, 80, NM[a][1], { fs: 10, a: 'middle', w: 700, c: a === '*' ? R.ink : '#fff', st: 'stroke:none' });
        } else {
          T(svg, x + 27, 80, '—', { fs: 12, a: 'middle', w: 600, c: FK.alpha(C.mu, .6) });
        }
        if (a === '*') stop = true;
      }
      T(svg, 14, 114, "৫′ → ৩′ দিকে পড়া হয়", { fs: 10, w: 560, c: C.mu });
      $('mnote').innerHTML = MNOTE[mut];
    };
    X.onSeg(root, 'mut', v => { mut = v; transl(); });
    table(); pick(); transl();
    const onT = () => { table(); transl(); };
    document.addEventListener('bk-lang', onT);
    return () => document.removeEventListener('bk-lang', onT);
  }
});

/* ───────── ২. ল্যাক অপেরন ───────── */
V.lacOperon = Object.assign({
  t: 'ল্যাক অপেরন — চালু ও বন্ধ', k: ['2d', 'anim'],
  cap: 'ল্যাকটোজ না থাকলে <b>রিপ্রেসর</b> অপারেটরে বসে RNA পলিমারেজের পথ আটকায়। ল্যাকটোজ এলে সেটি রিপ্রেসরে যুক্ত হয়ে তাকে সরিয়ে দেয় — তিনটি জিন থেকে একটিমাত্র mRNA ও তিনটি এনজাইম। শেষ ধাপে দেখো গ্লুকোজের প্রভাব।'
}, BK.steps({
  W: 380, H: 250, label: 'ল্যাক অপেরন', dur: 3.4,
  stages: [
    { t: 'ল্যাকটোজ নেই', en: 'Repressed', d: 'নিয়ন্ত্রক জিন <b>lacI</b> রিপ্রেসর তৈরি করে; রিপ্রেসর <b>অপারেটরে</b> বসে থাকে — RNA পলিমারেজ এগোতে পারে না। অপেরন <b>বন্ধ</b>।' },
    { t: 'ল্যাকটোজ এল', en: 'Inducer binds', d: 'ল্যাকটোজ (অ্যালোল্যাকটোজ) <b>ইনডিউসার</b> হিসেবে রিপ্রেসরে যুক্ত হয়; রিপ্রেসরের আকৃতি বদলে যায় এবং সেটি অপারেটর থেকে <b>সরে যায়</b>।' },
    { t: 'ট্রান্সক্রিপশন', en: 'Transcription', d: 'RNA পলিমারেজ lacZ, lacY ও lacA পেরিয়ে একটিমাত্র <b>পলিসিস্ট্রনিক mRNA</b> তৈরি করে।' },
    { t: 'তিন এনজাইম', en: 'Three enzymes', d: 'একটি mRNA থেকে <b>β-গ্যালাক্টোসাইডেজ</b>, <b>পারমিয়েজ</b> ও <b>ট্রান্সঅ্যাসিটাইলেজ</b> তৈরি হয় — ল্যাকটোজ ভাঙা শুরু।' },
    { t: 'গ্লুকোজও থাকলে', en: 'Glucose present', d: 'গ্লুকোজ বেশি থাকলে <b>cAMP কম</b>, তাই <b>CAP</b> প্রোমোটারে বসে না — রিপ্রেসর সরে গেলেও ট্রান্সক্রিপশন খুব দুর্বল। ব্যাকটেরিয়া আগে গ্লুকোজই খায়।' }
  ],
  draw(g, C, s, u) {
    const Rd = BK.ramp(9), Rrep = BK.ramp(4), Rpol = BK.ramp(6), Rl = BK.ramp(2), Rz = BK.ramp(10), Ry = BK.ramp(5), Ra = BK.ramp(8), Rcap = BK.ramp(3);
    const Y = 120, e = FK.ease(Math.min(1, u * 1.4));
    /* DNA */
    E('path', { d: `M14 ${Y}H368`, stroke: Rd.dk, 'stroke-width': 6, 'stroke-linecap': 'round' }, g);
    const box = (x, w, R, lab) => { E('rect', { x, y: Y - 11, width: w, height: 22, rx: 4, fill: R.c }, g); T(g, x + w / 2, Y + 4, lab, { fs: 10, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' }); };
    box(18, 40, BK.ramp(9), 'lacI');
    box(74, 38, Rcap, 'P');
    box(114, 30, Rrep, 'O');
    box(148, 78, Rz, 'lacZ');
    box(228, 70, Ry, 'lacY');
    box(300, 62, Ra, 'lacA');
    T(g, 38, Y + 26, 'নিয়ন্ত্রক জিন', { fs: 9, a: 'middle', w: 560, c: C.mu });
    T(g, 93, Y + 26, 'প্রোমোটার', { fs: 9, a: 'middle', w: 560, c: C.mu });
    T(g, 129, Y + 38, 'অপারেটর', { fs: 9, a: 'middle', w: 560, c: C.mu });
    /* রিপ্রেসর */
    const repOn = s === 0 ? 1 : s === 1 ? 1 - e : 0;
    const rx = 129, ry = Y - 26 - (1 - repOn) * 36, rxx = rx - (1 - repOn) * 50;
    E('path', { d: `M${rxx - 18} ${ry + 12}Q${rxx - 18} ${ry - 14} ${rxx} ${ry - 14}Q${rxx + 18} ${ry - 14} ${rxx + 18} ${ry + 12}L${rxx + 8} ${ry + 12}L${rxx + 8} ${ry + 4}L${rxx - 8} ${ry + 4}L${rxx - 8} ${ry + 12}Z`, fill: Rrep.c, stroke: Rrep.dk, 'stroke-width': 1.6 }, g);
    T(g, rxx, ry - 2, 'R', { fs: 11, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    T(g, rxx, ry - 20, 'রিপ্রেসর', { fs: 9.5, a: 'middle', w: 600, c: Rrep.ink });
    /* ল্যাকটোজ */
    if (s >= 1) {
      const lx = s === 1 ? 60 + (rxx + 10 - 60) * e : rxx + 10, ly = s === 1 ? 40 + (ry - 4 - 40) * e : ry - 4;
      E('path', { d: `M${lx} ${ly - 7}l7 4v7l-7 4l-7 -4v-7z`, fill: Rl.c, stroke: Rl.dk, 'stroke-width': 1.2 }, g);
      if (s === 1) T(g, 60, 30, 'ল্যাকটোজ', { fs: 10, a: 'middle', w: 600, c: Rl.ink });
    }
    /* RNA পলিমারেজ */
    const pStart = 93, pEnd = 360;
    const px = s <= 1 ? pStart : s === 2 ? pStart + (pEnd - pStart) * e : s === 4 ? pStart + 50 * e : pEnd;
    const pa = s === 4 ? .45 : 1;
    E('ellipse', { cx: px, cy: Y - 28, rx: 20, ry: 15, fill: FK.alpha(Rpol.c, .6 * pa + .2), stroke: Rpol.dk, 'stroke-width': 1.6, opacity: pa }, g);
    T(g, px, Y - 24, 'Pol', { fs: 9.5, a: 'middle', w: 700, c: Rpol.ink });
    if (s === 0) { E('path', { d: `M${pStart + 14} ${Y - 44}l14 10M${pStart + 28} ${Y - 44}l-14 10`, stroke: Rrep.dk, 'stroke-width': 2.4 }, g); T(g, 220, 44, 'অপেরন বন্ধ — ট্রান্সক্রিপশন নেই', { fs: 12, a: 'middle', w: 650, c: Rrep.ink }); }
    /* mRNA */
    if (s >= 2 && s <= 3) {
      const len = s === 2 ? (px - 148) : 214;
      if (len > 0) {
        const d = []; for (let x = 0; x <= len; x += 5) d.push(`${x ? 'L' : 'M'}${148 + x} ${Y + 52 + 4 * Math.sin(x / 12)}`);
        E('path', { d: d.join(''), fill: 'none', stroke: Rl.c, 'stroke-width': 4, 'stroke-linecap': 'round' }, g);
        T(g, 255, Y + 74, 'পলিসিস্ট্রনিক mRNA', { fs: 10, a: 'middle', w: 600, c: Rl.ink });
      }
    }
    if (s === 3) {
      [[187, Rz, 'β-গ্যালাক্টো-সাইডেজ'], [263, Ry, 'পারমিয়েজ'], [331, Ra, 'ট্রান্স-অ্যাসিটাইলেজ']].forEach(([x, R, lab], i) => {
        const a = Math.max(0, Math.min(1, e * 3 - i));
        E('circle', { cx: x, cy: 40, r: 12 * a + .1, fill: R.c, stroke: R.dk, 'stroke-width': 1.4 }, g);
        if (a > .5) lab.split('-').forEach((part, k) => T(g, x, 64 + k * 11, part + (k === 0 && lab.includes('-') ? '-' : ''), { fs: 9, a: 'middle', w: 600, c: R.ink }));
      });
    }
    if (s === 4) {
      [[40, 30], [70, 44], [100, 28]].forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 8, fill: BK.ramp(10).c }, g); });
      T(g, 70, 64, 'গ্লুকোজ বেশি', { fs: 10, a: 'middle', w: 600, c: BK.ramp(10).ink });
      E('rect', { x: 52, y: Y - 64, width: 28, height: 18, rx: 4, fill: 'none', stroke: FK.alpha(Rcap.dk, .6), 'stroke-dasharray': '4 3' }, g);
      T(g, 66, Y - 51, 'CAP?', { fs: 9, a: 'middle', w: 650, c: Rcap.ink });
      T(g, 250, 44, 'cAMP কম → CAP বসে না → দুর্বল', { fs: 11, a: 'middle', w: 600, c: C.mu });
    }
    T(g, 190, 238, ['রিপ্রেসর অপারেটরে = বন্ধ', 'ইনডিউসার রিপ্রেসরকে সরায়', 'P → O → Z → Y → A', 'এক mRNA, তিন এনজাইম', 'দুই চাবি: ল্যাকটোজ আছে + গ্লুকোজ নেই'][s], { fs: 11, a: 'middle', w: 600, c: C.mu });
  }
}));
})();
