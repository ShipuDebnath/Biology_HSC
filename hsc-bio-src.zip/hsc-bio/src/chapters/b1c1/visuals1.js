/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · DNA — ত্রিমাত্রিক দ্বি-হেলিক্স (FK.s3; Three.js থাকলে সেটিও চলে)
   dnaHelix : ঘুরিয়ে দেখা যায়, ক্ষারক-জোড় চেনা যায়, স্লাইডারে দুই সূত্রক খুলে যায় (রেপ্লিকেশন)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, BK = window.BK, v3 = FK.v3;
const RISE = 0.62, R = 2.0, STEP = 36 * FK.D, OFF = 142 * FK.D, N = 17;   /* ১৭ জোড় = প্রায় ২ পাক; সস্তা ফোনে হালকা রাখতে */   /* B-DNA: ১০ জোড়ায় এক পাক, ব্যাস ~2 nm */
/* ক্ষারক: পরিপূরক, হাইড্রোজেন বন্ধনের সংখ্যা, আর পিউরিন(2 রিং, বড়) না পিরিমিডিন(1 রিং, ছোট) */
const PAIR = { A: ['T', 2, 1], T: ['A', 2, 0], G: ['C', 3, 1], C: ['G', 3, 0] };   /* [পরিপূরক, H-বন্ধন, পিউরিন?] */
const SEQ = 'ATGCGATTACGCTAGCA'.split('');
V.dnaHelix = Object.assign({
  t: 'DNA-এর দ্বি-হেলিক্স (ত্রিমাত্রিক)', k: ['3d', 'anim', 'int'],
  cap: 'আঙুল দিয়ে ঘুরিয়ে দেখো। B-DNA: ডানাবর্ত, প্রতি পাকে 10টি ক্ষারক জোড়, পাকের দৈর্ঘ্য 34 Å, ব্যাস 20 Å, পরপর দুই জোড়ার দূরত্ব 3.4 Å। স্লাইডার টানলে দুই সূত্রক খুলে যায় — রেপ্লিকেশনের সময় ঠিক এভাবেই হেলিকেজ এনজাইম খোলে।'
}, BK.model3d({
  label: 'DNA দ্বি-হেলিক্সের ত্রিমাত্রিক মডেল', yaw: -0.5, pitch: 0.12, dist: 21, h: 340,
  ctrl: FK.sl('open', 'সূত্রক খোলা', 0, 100, 1, 0, '%'),
  wire(root, ctx, S) { FK.bindSl(root, 'open', v => { ctx.open = v / 100; S.frame(); }, '%', 0); },
  parts: [
    { id: 'bb', bn: 'শর্করা-ফসফেট মেরুদণ্ড', en: 'Sugar-phosphate backbone', fn: 'ডিঅক্সিরাইবোজ শর্করা ও ফসফেট পর্যায়ক্রমে ফসফোডাইএস্টার বন্ধনে যুক্ত হয়ে সূত্রকের কাঠামো বানায়। দুটি সূত্রক বিপরীতমুখী (অ্যান্টিপ্যারালাল): একটি 5′→3′, অন্যটি 3′→5′।' },
    { id: 'bp', bn: 'ক্ষারক জোড়', en: 'Base pair', fn: 'পিউরিন (A, G — দুই রিং, চিত্রে মোটা ও লম্বা) সবসময় পিরিমিডিনের (T, C — এক রিং, সরু ও খাটো) সাথে জোড় বাঁধে, তাই হেলিক্সের ব্যাস সর্বত্র সমান (20 Å)। A=T দুটি হাইড্রোজেন বন্ধন, G≡C তিনটি। এই পরিপূরকতার জন্যই চারগাফের সূত্র — A = T এবং G = C।' },
    { id: 'hb', bn: 'হাইড্রোজেন বন্ধন', en: 'Hydrogen bond', fn: 'দুই সূত্রককে ধরে রাখে। দুর্বল বলেই রেপ্লিকেশন ও ট্রান্সক্রিপশনের সময় এনজাইম সহজে খুলতে পারে। G≡C বেশি (তিনটি) বলে GC-সমৃদ্ধ DNA গলতে বেশি তাপ লাগে।' },
    { id: 'phos', bn: 'ফসফেট গ্রুপ', en: 'Phosphate group', fn: 'চিত্রে ছোট কমলা গুটি। পরপর দুটি শর্করার 5′ ও 3′ কার্বনকে ফসফোডাইএস্টার বন্ধনে জোড়া লাগায়। ফসফেটের ঋণাত্মক আধানের জন্যই DNA অম্লধর্মী ও পানিতে দ্রবণীয়।', a: [0, 0], l: [0, 0] },
    { id: 'sugar', bn: 'ডিঅক্সিরাইবোজ শর্করা', en: 'Deoxyribose sugar', fn: 'চিত্রে ধূসর-নীল গুটি — পাঁচ কার্বনবিশিষ্ট পেন্টোজ শর্করা। RNA-র রাইবোজের তুলনায় এর 2′ কার্বনে একটি অক্সিজেন কম (deoxy = অক্সিজেনহীন), তাই DNA বেশি স্থায়ী।', a: [0, 0], l: [0, 0] },
    { id: 'nucl', bn: 'নিউক্লিওটাইড', en: 'Nucleotide', fn: 'DNA-র একক: ফসফেট + ডিঅক্সিরাইবোজ শর্করা + একটি ক্ষারক। শুধু শর্করা ও ক্ষারক হলে সেটি নিউক্লিওসাইড; ফসফেট যোগ হলে নিউক্লিওটাইড। চিত্রে লাল বৃত্ত দিয়ে একটি একক দেখানো হলো।', a: [0, 0], l: [0, 0] },
    { id: 'maj', bn: 'প্রধান খাঁজ', en: 'Major groove', fn: 'দুই মেরুদণ্ডের মাঝে চওড়া ফাঁক (প্রায় 22 Å)। নিয়ন্ত্রক প্রোটিন এখান দিয়েই ক্ষারক চিনে DNA-তে যুক্ত হয়।' },
    { id: 'min', bn: 'গৌণ খাঁজ', en: 'Minor groove', fn: 'সরু ফাঁক (প্রায় 12 Å)। প্রধান ও গৌণ খাঁজ পর্যায়ক্রমে আসে বলেই DNA-র পৃষ্ঠ সর্পিল দেখায়।' }
  ],
  draw(S, ctx) {
    const C = FK.P(), M = FK.mat(), op = ctx.open || 0, Z0 = -N * RISE / 2, sel = ctx.sel, L = BK.lang;
    const dim = id => (sel && sel !== id) ? .22 : 1;
    const PH = BK.ramp(6), SG = BK.ramp(9), BC = { A: BK.base('A'), T: BK.base('T'), G: BK.base('G'), C: BK.base('C') };   /* ফ্রেমের শুরুতে একবারই — ভেতরে ডাকলে ফোন ধীর হয় */
    const openFrom = N - Math.round(op * (N - 2));
    const sepAt = i => i >= openFrom ? (i - openFrom + 1) / Math.max(1, N - openFrom) * op : 0;
    const pt = (i, strand, half) => { const sp = sepAt(i);
      const a = (i + (half || 0)) * STEP + (strand ? OFF : 0), rr = R + sp * 5.5, zz = Z0 + (i + (half || 0)) * RISE + sp * 1.2 * (strand ? -1 : 1);
      return [rr * Math.cos(a), rr * Math.sin(a), zz]; };

    /* ── মেরুদণ্ড: ফসফেট (গুটি) — শর্করা (গুটি) পর্যায়ক্রমে, মাঝে ফসফোডাইএস্টার বন্ধন ── */
    for (let st = 0; st < 2; st++) {
      const bc = st ? M.blue : M.gold;
      for (let i = 0; i < N - 1; i++) { const a = pt(i, st), m = pt(i, st, .5), b = pt(i + 1, st);
        S.path([a, m], bc, { id: 'bb', w: 9, a: dim('bb') });
        S.path([m, b], bc, { id: 'bb', w: 9, a: dim('bb') }); }
      for (let i = 0; i < N; i++) {
        S.sphere(pt(i, st), .38, SG.c, { id: 'sugar', a: dim('sugar') });            /* ডিঅক্সিরাইবোজ */
        if (i < N - 1) S.sphere(pt(i, st, .5), .32, PH.c, { id: 'phos', a: dim('phos') });   /* ফসফেট */
      }
    }

    /* ── ক্ষারক জোড়: পিউরিন লম্বা ও মোটা, পিরিমিডিন খাটো ও সরু; H-বন্ধন ২ বা ৩ ── */
    for (let i = 0; i < N; i++) {
      const b1 = SEQ[i % SEQ.length], [b2, nH, pur1] = PAIR[b1];
      const R1 = BC[b1], R2 = BC[b2], p1 = pt(i, 0), p2 = pt(i, 1), sep = sepAt(i);
      const f = pur1 ? .58 : .42;                      /* পিউরিন বেশি দূর পর্যন্ত আসে */
      const r1 = pur1 ? .26 : .19, r2 = pur1 ? .19 : .26;
      if (sep > .02) {
        const ax1 = [0, 0, p1[2]], ax2 = [0, 0, p2[2]];
        S.cyl(p1, v3.add(p1, v3.mul(v3.norm(v3.sub(ax1, p1)), pur1 ? 1.2 : .9)), r1, R1.c, { id: 'bp', a: dim('bp'), caps: false, seg: 4 });
        S.cyl(p2, v3.add(p2, v3.mul(v3.norm(v3.sub(ax2, p2)), pur1 ? .9 : 1.2)), r2, R2.c, { id: 'bp', a: dim('bp'), caps: false, seg: 4 });
      } else {
        const m1 = v3.add(p1, v3.mul(v3.sub(p2, p1), f - .04)), m2 = v3.add(p1, v3.mul(v3.sub(p2, p1), f + .04));
        S.cyl(p1, m1, r1, R1.c, { id: 'bp', a: dim('bp'), caps: false, seg: 4 });
        S.cyl(p2, m2, r2, R2.c, { id: 'bp', a: dim('bp'), caps: false, seg: 4 });
        const g = v3.sub(m2, m1), per = [-g[1], g[0], 0], u = v3.len(per) > 1e-6 ? v3.mul(v3.norm(per), .17) : [0, 0, .17];
        for (let h = 0; h < nH; h++) { const o = v3.mul(u, h - (nH - 1) / 2);
          S.line(v3.add(m1, o), v3.add(m2, o), C.mu, { id: 'hb', lw: 1.2, a: dim('hb') * .95 }); }
      }
      if (L !== 'off' && i % 4 === 1 && i < openFrom - 1)
        S.text([p1[0] * 1.95, p1[1] * 1.95, p1[2]], b1 + (nH === 3 ? '≡' : '=') + b2, R1.ink, { size: 11.5, bold: true });
    }

    /* ── একটি নিউক্লিওটাইড আলাদা করে চেনানো (ফসফেট + শর্করা + ক্ষারক) ── */
    if (sel === 'nucl' || (!sel && L !== 'off')) {
      const i = Math.min(N - 2, 4), p = pt(i, 0);
      S.ring(p, [0, 0, 1], 1.5, M.red, { n: 18, lw: 1.6, a: sel === 'nucl' ? 1 : .55 });
      if (sel === 'nucl') S.text(v3.add(p, [0, 0, 1.9]), 'একটি নিউক্লিওটাইড', M.red, { size: 11.5, bold: true });
    }

    /* ── খাঁজ ও প্রান্ত ── */
    if (L !== 'off') {
      const mk = (i, c, side, txt) => { const d = side * 6.4, p = [d * Math.cos(S.yaw), d * Math.sin(S.yaw), Z0 + i * RISE];
        S.text(p, txt, c, { size: 11, bold: true }); };
      mk(7, BK.ramp(3).ink, 1, L === 'en' ? 'Major groove' : 'প্রধান খাঁজ');
      mk(12, BK.ramp(0).ink, -1, L === 'en' ? 'Minor groove' : 'গৌণ খাঁজ');
      S.text([0, 0, Z0 + N * RISE + 1.1], '5′ ——— 3′', M.gold, { size: 11.5, bold: true });
      S.text([0, 0, Z0 - 1.2], '3′ ——— 5′', M.blue, { size: 11.5, bold: true });
    }
    if (op > .05) S.text([0, 0, Z0 + N * RISE + 2.5], 'রেপ্লিকেশন ফর্ক', BK.ramp(4).ink, { size: 12, bold: true });
  }
}));
})();
