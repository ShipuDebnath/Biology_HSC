/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.৭ — নিউক্লিক অ্যাসিড
   nucleotide : নিউক্লিওটাইড গড়ার খেলা — ক্ষারক ও শর্করা বেছে নাও,
                ফসফেট যোগ করো; নিউক্লিওসাইড ↔ নিউক্লিওটাইড স্পষ্ট হয়
   baseTypes  : পাঁচটি ক্ষারক — পিউরিন (দ্বিচক্রী) ও পিরিমিডিন (একচক্রী),
                A–T ২টি ও G–C ৩টি হাইড্রোজেন বন্ধনসহ
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

/* ───────── ১. নিউক্লিওটাইড গড়ার খেলা ───────── */
const BASES = {
  A: { bn: 'অ্যাডেনিন', en: 'Adenine', cls: 'পিউরিন', ring: 2, ri: 7 },
  G: { bn: 'গুয়ানিন', en: 'Guanine', cls: 'পিউরিন', ring: 2, ri: 9 },
  C: { bn: 'সাইটোসিন', en: 'Cytosine', cls: 'পিরিমিডিন', ring: 1, ri: 5 },
  T: { bn: 'থাইমিন', en: 'Thymine', cls: 'পিরিমিডিন', ring: 1, ri: 4 },
  U: { bn: 'ইউরাসিল', en: 'Uracil', cls: 'পিরিমিডিন', ring: 1, ri: 2 }
};
/* নিউক্লিওসাইড ও নিউক্লিওটাইডের নাম */
const NAME = {
  A: ['অ্যাডেনোসিন', 'অ্যাডেনাইলিক অ্যাসিড', 'AMP'],
  G: ['গুয়ানোসিন', 'গুয়ানাইলিক অ্যাসিড', 'GMP'],
  C: ['সাইটিডিন', 'সাইটিডাইলিক অ্যাসিড', 'CMP'],
  T: ['থাইমিডিন', 'থাইমিডাইলিক অ্যাসিড', 'TMP'],
  U: ['ইউরিডিন', 'ইউরিডাইলিক অ্যাসিড', 'UMP']
};

V.nucleotide = Object.assign({
  t: 'নিউক্লিওটাইড গড়ার খেলা', k: ['2d', 'anim', 'int', 'game'],
  cap: 'ক্ষারক বেছে নাও, শর্করা বদলাও, আর <b>ফসফেট</b> যোগ করো বা সরাও — নিচে নামটিও সাথে সাথে বদলে যাবে। <b>ফসফেট ছাড়া = নিউক্লিওসাইড, ফসফেটসহ = নিউক্লিওটাইড</b>। লক্ষ করো ক্ষারক বসে <b>১′</b> কার্বনে আর ফসফেট <b>৫′</b> কার্বনে।',
  html: () => `<div class="fk-row">${X.seg('base', [['A', 'A'], ['G', 'G'], ['C', 'C'], ['T', 'T'], ['U', 'U']], 'A')}</div>
    <div class="fk-row">${X.seg('sugar', [['d', 'ডিঅক্সিরাইবোজ'], ['r', 'রাইবোজ']], 'd')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="fk-row">${FK.btn('ph', '<span data-lbl>ফসফেট সরাও</span>', 'plus')}</div>
    <div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 376, H = 268;
    let C, svg, b = 'A', sug = 'd', ph = 1, tt = 0, pulse = null, px0 = 0, py0 = 0, pcol = '#888';

    const nameOf = () => {
      const [ns, nt, ab] = NAME[b], d = sug === 'd';
      return ph ? `${d ? 'ডিঅক্সি' : ''}${nt} (${d ? 'd' : ''}${ab})` : `${d ? 'ডিঅক্সি' : ''}${ns}`;
    };
    const info = () => {
      const B = BASES[b], ok = (sug === 'd' && b === 'U') || (sug === 'r' && b === 'T');
      $('info').innerHTML = `<b>${nameOf()}</b> <span class="chip ${ph ? 'acc' : ''}">${ph ? 'নিউক্লিওটাইড' : 'নিউক্লিওসাইড'}</span>`
        + `<div class="small">${B.bn} (${B.en}) — ${B.cls}, ${FK.bn(B.ring)}টি রিং। উপাদান: ক্ষারক + ${sug === 'd' ? 'ডিঅক্সিরাইবোজ' : 'রাইবোজ'}${ph ? ' + ফসফেট' : ''} = ${FK.bn(ph ? 3 : 2)}টি।</div>`
        + (ok ? `<div class="small fk-no"><b>লক্ষ করো:</b> ${b === 'U' ? 'ইউরাসিল DNA-তে থাকে না — এটি কেবল RNA-র ক্ষারক (রাইবোজের সাথে)।' : 'থাইমিন RNA-তে থাকে না — এটি কেবল DNA-র ক্ষারক (ডিঅক্সিরাইবোজের সাথে)।'}</div>` : '');
    };

    const draw = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'নিউক্লিওটাইডের গঠন' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const B = BASES[b], Rb = BK.ramp(B.ri), Rs = BK.ramp(sug === 'd' ? 6 : 10), Rp = BK.ramp(2);
      const SX = 166, SY = 152, r = 40;                       /* শর্করার পঞ্চভুজ */
      const pt = i => { const a = -Math.PI / 2 + 2 * Math.PI * i / 5; return [SX + r * Math.cos(a), SY + r * Math.sin(a)]; };
      /* পঞ্চভুজের শীর্ষ: 0 = উপরে (O), 1 = ১′ (ডান-উপর), 2 = ২′ (ডান-নিচ), 3 = ৩′ (বাঁ-নিচ), 4 = ৪′ (বাঁ-উপর) */
      const P = [0, 1, 2, 3, 4].map(pt);
      E('path', { d: P.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join('') + 'Z', fill: BK.lg(svg, Rs.lt, Rs.c, { a: 100 }), stroke: Rs.dk, 'stroke-width': 2 }, svg);
      T(svg, P[0][0], P[0][1] - 7, 'O', { fs: 11, a: 'middle', w: 650, c: Rs.ink });
      [[1, "১′"], [2, "২′"], [3, "৩′"], [4, "৪′"]].forEach(([i, lab]) => T(svg, P[i][0] + (i === 1 || i === 2 ? 11 : -11), P[i][1] + 4, lab, { fs: 10.5, a: i === 1 || i === 2 ? 'start' : 'end', w: 600, c: Rs.ink }));
      T(svg, SX, SY + 6, sug === 'd' ? 'ডিঅক্সিরাইবোজ' : 'রাইবোজ', { fs: 10.5, a: 'middle', w: 620, c: Rs.ink });

      /* ২′ কার্বনে −OH বা −H */
      const o2 = P[2];
      E('path', { d: `M${o2[0]} ${o2[1]}l16 18`, stroke: Rs.dk, 'stroke-width': 1.6 }, svg);
      T(svg, o2[0] + 20, o2[1] + 26, sug === 'd' ? '−H' : '−OH', { fs: 11.5, a: 'start', w: 650, c: sug === 'd' ? C.mu : BK.ramp(0).ink });
      /* ৩′ কার্বনে −OH (পরের নিউক্লিওটাইড এখানে যুক্ত হয়) */
      const o3 = P[3];
      E('path', { d: `M${o3[0]} ${o3[1]}l-14 20`, stroke: Rs.dk, 'stroke-width': 1.6 }, svg);
      T(svg, o3[0] - 18, o3[1] + 28, '−OH', { fs: 11, a: 'end', w: 600, c: C.mu });

      /* ক্ষারক — ১′ কার্বনে, গ্লাইকোসাইডিক বন্ধন */
      const b1 = P[1];
      E('path', { d: `M${b1[0]} ${b1[1]}L${b1[0] + 44} ${b1[1] - 34}`, stroke: Rb.dk, 'stroke-width': 2.2 }, svg);
      T(svg, b1[0] + 30, b1[1] - 2, 'গ্লাইকোসাইডিক', { fs: 9, a: 'middle', w: 520, c: C.mu });
      const bx = b1[0] + 44, by = b1[1] - 34;
      const hex = (cx, cy, rr) => Array.from({ length: 6 }, (_, i) => { const a = Math.PI / 6 + 2 * Math.PI * i / 6; return `${i ? 'L' : 'M'}${(cx + rr * Math.cos(a)).toFixed(1)} ${(cy + rr * Math.sin(a)).toFixed(1)}`; }).join('') + 'Z';
      E('path', { d: hex(bx + 18, by - 10, 20), fill: BK.lg(svg, Rb.lt, Rb.c, { a: 80 }), stroke: Rb.dk, 'stroke-width': 1.8 }, svg);
      if (B.ring === 2) {   /* পিউরিন: দ্বিতীয় (পাঁচ সদস্যের) রিং */
        const px = bx + 48, py = by - 18;
        E('path', { d: Array.from({ length: 5 }, (_, i) => { const a = -Math.PI / 2 + 2 * Math.PI * i / 5; return `${i ? 'L' : 'M'}${(px + 15 * Math.cos(a)).toFixed(1)} ${(py + 15 * Math.sin(a)).toFixed(1)}`; }).join('') + 'Z', fill: FK.alpha(Rb.c, .8), stroke: Rb.dk, 'stroke-width': 1.8 }, svg);
      }
      T(svg, bx + 26, by - 42, `${B.bn} (${b})`, { fs: 11.5, a: 'middle', w: 650, c: Rb.ink });
      T(svg, bx + 26, by - 28, B.cls + ' · ' + FK.bn(B.ring) + ' রিং', { fs: 9.5, a: 'middle', w: 520, c: C.mu });

      /* ফসফেট — ৫′ কার্বনে (৪′ শীর্ষ থেকে উপরে) */
      const p4 = P[4];
      if (ph) {
        E('path', { d: `M${p4[0]} ${p4[1]}L${p4[0] - 34} ${p4[1] - 26}`, stroke: Rp.dk, 'stroke-width': 2.2 }, svg);
        E('circle', { cx: p4[0] - 52, cy: p4[1] - 36, r: 20, fill: BK.lg(svg, Rp.lt, Rp.c, { a: 90 }), stroke: Rp.dk, 'stroke-width': 1.8 }, svg);
        T(svg, p4[0] - 52, p4[1] - 32, 'P', { fs: 15, a: 'middle', w: 700, c: Rp.ink });
        T(svg, p4[0] - 52, p4[1] - 62, 'ফসফেট', { fs: 10.5, a: 'middle', w: 600, c: Rp.ink });
        T(svg, p4[0] - 6, p4[1] - 10, "৫′", { fs: 10.5, a: 'end', w: 600, c: Rs.ink });
      } else {
        E('circle', { cx: p4[0] - 52, cy: p4[1] - 36, r: 20, fill: 'none', stroke: FK.alpha(C.mu, .5), 'stroke-width': 1.6, 'stroke-dasharray': '5 4' }, svg);
        T(svg, p4[0] - 52, p4[1] - 32, '?', { fs: 15, a: 'middle', w: 650, c: C.mu });
        T(svg, p4[0] - 52, p4[1] - 62, 'ফসফেট নেই', { fs: 10, a: 'middle', w: 560, c: C.mu });
        T(svg, p4[0] - 6, p4[1] - 10, "৫′", { fs: 10.5, a: 'end', w: 600, c: Rs.ink });
      }

      /* উপরে হিসাব */
      T(svg, 188, 24, ph ? 'ক্ষারক + শর্করা + ফসফেট = নিউক্লিওটাইড' : 'ক্ষারক + শর্করা = নিউক্লিওসাইড', { fs: 12.5, a: 'middle', w: 620, c: ph ? Rp.ink : C.mu });
      T(svg, 188, 254, nameOf(), { fs: 12, a: 'middle', w: 620, c: Rb.ink });
      /* স্পন্দনের জন্য আলাদা স্তর — প্রতি ফ্রেমে কেবল এটুকু বদলায়, পুরো ছবি নয় */
      pulse = E('g', { style: 'pointer-events:none' }, svg);
      px0 = p4[0] - 52; py0 = p4[1] - 36; pcol = Rp.c;
    };

    const sync = () => { const el = root.querySelector('[data-lbl]'); if (el) el.textContent = ph ? 'ফসফেট সরাও' : 'ফসফেট যোগ করো'; };
    X.onSeg(root, 'base', v => { b = v; draw(); info(); sync(); });
    X.onSeg(root, 'sugar', v => { sug = v; draw(); info(); sync(); });
    FK.on(root, 'ph', () => { ph = ph ? 0 : 1; draw(); info(); sync(); });
    const A = X.anim(root, dt => {
      tt += dt; if (!pulse) return; pulse.innerHTML = '';
      if (!ph) return;
      const k = .5 + .5 * Math.sin(tt * 3);
      E('circle', { cx: px0, cy: py0, r: 20 + 6 * k, fill: 'none', stroke: FK.alpha(pcol, .34 * (1 - k * .6)), 'stroke-width': 2 }, pulse);
    }, { paused: false });
    draw(); info(); sync();
    const onT = () => draw();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── ২. পাঁচটি ক্ষারক ও ক্ষারক-জোড় ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

V.baseTypes = Object.assign({
  t: 'পিউরিন, পিরিমিডিন ও ক্ষারক-জোড়', k: ['2d', 'anim', 'int', 'game'],
  cap: 'বাঁয়ে <b>পিউরিন</b> — দুটি রিং, ৪টি নাইট্রোজেন (A, G)। ডানে <b>পিরিমিডিন</b> — একটি রিং, ২টি নাইট্রোজেন (T, C, U)। নিচে জোড় বাঁধা দেখো: <b>A–T ২টি</b> ও <b>G–C ৩টি</b> হাইড্রোজেন বন্ধন। লক্ষ করো দুটি জোড়ের মোট প্রস্থ একই — তাই হেলিক্সের দুই মেরুদণ্ডের দূরত্ব সব জায়গায় সমান থাকে।'
}, BK.diagram({
  W: 400, H: 358, label: 'পিউরিন, পিরিমিডিন ও ক্ষারক-জোড়',
  art(g, C, part) {
    const svg = g.ownerSVGElement;
    const RA = BK.base('A'), RG = BK.base('G'), RC = BK.base('C'), RT = BK.base('T'), RU = BK.ramp(2), Rb = BK.ramp(9);
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const hex = (cx, cy, r) => Array.from({ length: 6 }, (_, i) => { const a = Math.PI / 6 + 2 * Math.PI * i / 6; return `${i ? 'L' : 'M'}${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`; }).join('') + 'Z';
    const pen = (cx, cy, r) => Array.from({ length: 5 }, (_, i) => { const a = -Math.PI / 2 + 2 * Math.PI * i / 5; return `${i ? 'L' : 'M'}${(cx + r * Math.cos(a)).toFixed(1)} ${(cy + r * Math.sin(a)).toFixed(1)}`; }).join('') + 'Z';
    /* পিউরিন (দুই রিং) আঁকার সহায়ক */
    const purine = (gp, x, y, R, lab) => {
      E('path', { d: hex(x, y, 19), fill: BK.lg(svg, R.lt, R.c, { a: 80 }), stroke: R.dk, 'stroke-width': 1.8 }, gp);
      E('path', { d: pen(x + 27, y - 7, 14), fill: FK.alpha(R.c, .85), stroke: R.dk, 'stroke-width': 1.8 }, gp);
      T(gp, x + 10, y + 4, lab, { fs: 14, a: 'middle', w: 700, c: R.ink });
    };
    const pyrim = (gp, x, y, R, lab) => {
      E('path', { d: hex(x, y, 19), fill: BK.lg(svg, R.lt, R.c, { a: 80 }), stroke: R.dk, 'stroke-width': 1.8 }, gp);
      T(gp, x, y + 5, lab, { fs: 14, a: 'middle', w: 700, c: R.ink });
    };

    /* উপরের দুই কলাম: পিউরিন ও পিরিমিডিন */
    const pu = P('pu');
    purine(pu, 62, 78, RA, 'A'); purine(pu, 62, 134, RG, 'G');
    T(pu, 62, 46, 'পিউরিন — ২ রিং', { fs: 11.5, a: 'middle', w: 620, c: RA.ink });
    T(pu, 62, 164, '৪টি নাইট্রোজেন · বড়', { fs: 9.5, a: 'middle', w: 520, c: C.mu });
    const py = P('py');
    pyrim(py, 250, 72, RT, 'T'); pyrim(py, 310, 72, RC, 'C'); pyrim(py, 280, 128, RU, 'U');
    T(py, 280, 46, 'পিরিমিডিন — ১ রিং', { fs: 11.5, a: 'middle', w: 620, c: RC.ink });
    T(py, 280, 164, '২টি নাইট্রোজেন · ছোট', { fs: 9.5, a: 'middle', w: 520, c: C.mu });
    E('path', { d: 'M156 56V158', stroke: FK.alpha(C.mu, .35), 'stroke-width': 1.2, 'stroke-dasharray': '5 4' }, g);
    T(g, 250, 92, 'DNA', { fs: 8.5, a: 'middle', w: 520, c: C.mu });
    T(g, 310, 92, 'উভয়ে', { fs: 8.5, a: 'middle', w: 520, c: C.mu });
    T(g, 280, 148, 'RNA', { fs: 8.5, a: 'middle', w: 520, c: C.mu });

    /* নিচে দুটি ক্ষারক-জোড় */
    const pairRow = (gp, y, LR, LL, Rr, Rl, n) => {
      E('path', { d: `M24 ${y}h34`, stroke: Rb.dk, 'stroke-width': 3 }, gp);     /* বাঁ মেরুদণ্ড */
      E('path', { d: `M342 ${y}h34`, stroke: Rb.dk, 'stroke-width': 3 }, gp);    /* ডান মেরুদণ্ড */
      purine(gp, 86, y, Rr, LR);
      pyrim(gp, 310, y, Rl, LL);
      for (let k = 0; k < n; k++) {
        const yy = y - (n - 1) * 6 + k * 12;
        E('path', { d: `M128 ${yy}H291`, stroke: FK.alpha(C.mu, .85), 'stroke-width': 1.8, 'stroke-dasharray': '4 4' }, gp);
      }
    };
    const bp1 = P('bp1'); pairRow(bp1, 248, 'A', 'T', RA, RT, 2);
    const bp2 = P('bp2'); pairRow(bp2, 310, 'G', 'C', RG, RC, 3);
    E('path', { d: 'M24 186h352', stroke: FK.alpha(C.mu, .3), 'stroke-width': 1 }, g);
    T(g, 200, 348, 'দুই জোড়ের প্রস্থ সমান — তাই হেলিক্স সর্বত্র 2 nm চওড়া', { fs: 10, a: 'middle', w: 520, c: C.mu });
  },
  /* হাইড্রোজেন বন্ধন টিমটিম করে — দুর্বল বন্ধন বোঝাতে */
  idle(g, C, t) {
    [[248, 2], [310, 3]].forEach(([y, n]) => {
      for (let k = 0; k < n; k++) {
        const yy = y - (n - 1) * 6 + k * 12, a = .25 + .25 * Math.sin(t * 2.4 + k * 1.1 + y);
        E('path', { d: `M128 ${yy}H291`, stroke: FK.alpha(C.acc, a), 'stroke-width': 3.4 }, g);
      }
    });
    const u = (t * .22) % 1;
    E('circle', { cx: 24 + u * 352, cy: 186, r: 3.4, fill: FK.alpha(BK.ramp(9).c, .55) }, g);
    T(g, 200, 202, 'হাইড্রোজেন বন্ধন দুর্বল — তাই DNA সহজে খোলে', { fs: 9.5, a: 'middle', w: 520, c: C.mu });
  },
  parts: [
    { id: 'pu', bn: 'পিউরিন', en: 'Purine', fn: '<b>দ্বিচক্রী</b> ক্ষারক — একটি ৬ সদস্যের ও একটি ৫ সদস্যের রিং জোড়া লেগে তৈরি; মোট ৯টি পরমাণু, তার মধ্যে <b>৪টি নাইট্রোজেন</b>। সদস্য দুটি: <b>অ্যাডেনিন (A)</b> ও <b>গুয়ানিন (G)</b> — দুটিই DNA ও RNA উভয়ে থাকে। গুয়ানিন নামটি এসেছে পাখির বিষ্ঠা <i>guano</i> থেকে।', a: [62, 106], l: [26, 178] },
    { id: 'py', bn: 'পিরিমিডিন', en: 'Pyrimidine', fn: '<b>একচক্রী</b> ক্ষারক — একটিমাত্র ৬ সদস্যের রিং, <b>২টি নাইট্রোজেন</b>। সদস্য তিনটি: <b>থাইমিন (T)</b> কেবল DNA-তে, <b>ইউরাসিল (U)</b> কেবল RNA-তে এবং <b>সাইটোসিন (C)</b> উভয়ে। থাইমিন আসলে ইউরাসিল + একটি মিথাইল গ্রুপ।', a: [280, 100], l: [374, 178], an: 'end' },
    { id: 'bp1', bn: 'A – T জোড়', en: 'A–T pair', fn: 'অ্যাডেনিন ও থাইমিনের মধ্যে <b>২টি</b> হাইড্রোজেন বন্ধন (RNA-তে A–U)। চারগাফের সূত্র অনুযায়ী দ্বিসূত্রক DNA-তে তাই <b>A = T</b>। বন্ধন কম বলে A–T সমৃদ্ধ অংশ তুলনামূলক সহজে খোলে — রেপ্লিকেশন এমন অঞ্চল থেকেই শুরু হয়।', lb: 'A – T · ২টি বন্ধন', a: [210, 248], l: [210, 226], an: 'middle' },
    { id: 'bp2', bn: 'G – C জোড়', en: 'G–C pair', fn: 'গুয়ানিন ও সাইটোসিনের মধ্যে <b>৩টি</b> হাইড্রোজেন বন্ধন, তাই এই জোড় বেশি শক্ত। <b>G = C</b>। যে DNA-তে G–C বেশি, তা গলাতে বেশি তাপ লাগে — উষ্ণ প্রস্রবণের ব্যাকটেরিয়ায় তাই G–C-র পরিমাণ বেশি।', lb: 'G – C · ৩টি বন্ধন', a: [210, 310], l: [210, 288], an: 'middle' }
  ]
}));
})();
