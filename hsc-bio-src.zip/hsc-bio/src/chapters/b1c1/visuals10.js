/* ═══════════════════════════════════════════════════════════════════
   visuals10 — §১.১ ও §১.৩-এর বাকি চিত্র
   cellScale  : কোষের আকার ও পরিমাপের একক — লগ স্কেল
   ribosome   : রাইবোসোম — দুই উপএকক, mRNA, A-P-E সাইট
   erTypes    : অমসৃণ ও মসৃণ ER
   golgiFlow  : ER → গলগি → নিঃসরণ — প্রোটিনের যাত্রা
   lysoCycle  : লাইসোসোমের কাজ — ফ্যাগোসাইটোসিস ও অটোফ্যাজি
   ═══════════════════════════════════════════════════════════════════ */

/* ───────── ১. কোষের আকার ও একক ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* [নাম, আকার μm-এ, রং-র‍্যাম্প] */
const OB = [
  ['হাইড্রোজেন পরমাণু', 0.0001, 9], ['DNA-র ব্যাস', 0.002, 5], ['রাইবোসোম', 0.025, 6],
  ['HIV ভাইরাস', 0.1, 4], ['মাইকোপ্লাজমা (ক্ষুদ্রতম কোষ)', 0.2, 2], ['মাইটোকন্ড্রিয়া', 1, 3],
  ['E. coli ব্যাকটেরিয়া', 2, 10], ['লোহিত রক্তকণিকা', 7.5, 4], ['আদর্শ উদ্ভিদকোষ', 50, 10],
  ['মানব ডিম্বাণু', 100, 8], ['উটপাখির ডিম (বৃহত্তম কোষ)', 150000, 6], ['স্নায়ুকোষ (দীর্ঘতম, ~1 m)', 1000000, 5]
];
const fmt = v => v >= 1000 ? (+v.toPrecision(3)).toLocaleString('en') : +v.toPrecision(3) + '';
V.cellScale = Object.assign({
  t: 'কোষের আকার ও পরিমাপের একক', k: ['2d', 'anim', 'int'],
  cap: 'বাঁ থেকে ডানে প্রতিটি দাগে আকার <b>১০ গুণ</b> বাড়ে (লগ স্কেল)। স্লাইডার টেনে বস্তু বেছে নাও — নিচে দেখো তার মাপ Å, nm, μm ও mm-এ, আর কোন যন্ত্রে তাকে দেখা যায়।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    ${FK.sl('ob', 'বস্তু', 0, OB.length - 1, 1, 7, '')}
    <div class="bk-info" data-k="calc" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 340, H = 200, X0 = 18, X1 = 322, LMIN = -4, LMAX = 6, Y = 100;
    const xo = um => X0 + (Math.log10(um) - LMIN) / (LMAX - LMIN) * (X1 - X0);
    let svg, pulse, idx = 7, ph = 0;
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'কোষের আকারের লগ স্কেল' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      /* দেখার যন্ত্রের পরিসর */
      [[0.0002, 0.2, BK.ramp(3), 'ইলেকট্রন অণুবীক্ষণ'], [0.2, 100, BK.ramp(10), 'আলোক অণুবীক্ষণ'], [100, 1e6, BK.ramp(6), 'খালি চোখ']].forEach(([a, b, R, lab], i) => {
        const xa = xo(a), xb = xo(b);
        E('rect', { x: xa, y: 14 + i * 22, width: xb - xa, height: 18, rx: 9, fill: FK.alpha(R.c, .28), stroke: R.dk, 'stroke-width': 1 }, svg);
        T(svg, (xa + xb) / 2, 27.5 + i * 22, lab, { fs: 11, a: 'middle', w: 600, c: R.ink });
      });
      /* অক্ষ */
      E('path', { d: `M${X0} ${Y}H${X1}`, stroke: C.mu, 'stroke-width': 2 }, svg);
      const lab = { '-4': '1 Å', '-3': '1 nm', '0': '1 μm', '3': '1 mm', '4': '1 cm', '6': '1 m' };
      for (let L = LMIN; L <= LMAX; L++) {
        const x = xo(Math.pow(10, L));
        E('path', { d: `M${x} ${Y - 5}V${Y + 5}`, stroke: C.mu, 'stroke-width': 1.4 }, svg);
        if (lab[L]) T(svg, x, Y + 20, lab[L], { fs: 11, a: 'middle', w: 600, c: C.mu });
      }
      /* বস্তুর বিন্দু */
      OB.forEach(([n, um, r], i) => {
        const R = BK.ramp(r), x = xo(um), on = i === idx;
        E('circle', { cx: x, cy: Y, r: on ? 7 : 4.5, fill: on ? R.c : FK.alpha(R.c, .6), stroke: R.dk, 'stroke-width': on ? 2 : 1, 'data-i': i, style: 'cursor:pointer' }, svg);
      });
      const [n, um, r] = OB[idx], R = BK.ramp(r), x = xo(um);
      pulse = E('circle', { cx: x, cy: Y, r: 10, fill: 'none', stroke: R.c, 'stroke-width': 2 }, svg);
      /* তুলনামূলক বৃত্ত: পরের বস্তুর তুলনায় */
      const ax = Math.max(80, Math.min(260, x));
      E('path', { d: `M${x} ${Y + 8}L${ax} ${Y + 40}`, stroke: FK.alpha(R.dk, .6), 'stroke-width': 1.2 }, svg);
      T(svg, ax, Y + 56, n, { fs: 13.5, a: 'middle', w: 650, c: R.ink });
      T(svg, ax, Y + 76, `≈ ${fmt(um)} μm`, { fs: 13, a: 'middle', w: 600, c: C.fg });
      svg.addEventListener('click', e => { const c = e.target.closest('[data-i]'); if (!c) return; sl.set(+c.dataset.i); });
    };
    const calc = v => {
      idx = Math.round(v); build();
      const um = OB[idx][1], A = um * 1e4, nm = um * 1e3, mm = um / 1e3;
      const tool = um < 0.2 ? 'কেবল <b>ইলেকট্রন অণুবীক্ষণ</b> যন্ত্রে দেখা যায়' : um < 100 ? '<b>আলোক অণুবীক্ষণ</b> যন্ত্রে দেখা যায়' : '<b>খালি চোখে</b> দেখা যায়';
      $('calc').innerHTML = `<b>${OB[idx][0]}</b> — ${tool}`
        + `<div class="small">${fmt(A)} Å = ${fmt(nm)} nm = <b>${fmt(um)} μm</b> = ${fmt(mm)} mm</div>`
        + `<div class="small">মনে রাখো: 1 mm = 1000 μm · 1 μm = 1000 nm · 1 nm = 10 Å</div>`;
    };
    const sl = FK.bindSl(root, 'ob', calc, '', 0);
    calc(7);
    const A = X.anim(root, dt => { ph += dt * 3; if (pulse) { pulse.setAttribute('r', 9 + 4 * Math.abs(Math.sin(ph))); pulse.setAttribute('opacity', .4 + .5 * Math.abs(Math.cos(ph))); } }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── ২. রাইবোসোম ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.ribosome = Object.assign({
  t: 'রাইবোসোম — গঠন ও কাজের স্থান', k: ['2d', 'anim', 'int', 'game'],
  cap: 'রাইবোসোম দুটি উপএককে গঠিত — প্রকৃতকোষে <b>60S + 40S = 80S</b>, আদিকোষে <b>50S + 30S = 70S</b>। দুই উপএককের মাঝ দিয়ে mRNA চলে; বড় উপএককে <b>E, P, A</b> তিনটি সাইট। কোনো পর্দা নেই — তাই একে পর্দাবিহীন অঙ্গাণু বলে।'
}, BK.diagram({
  W: 360, H: 300, label: 'রাইবোসোমের গঠন',
  art(g, C, part) {
    const svg = g.ownerSVGElement, P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rl = BK.ramp(5), Rs = BK.ramp(10), Rm = BK.ramp(4), Rt = BK.ramp(6), Ra = BK.ramp(2), Rp = BK.ramp(3);
    const big = P('big');
    E('path', { d: 'M70 150Q60 70 180 60Q300 70 290 150Q240 162 180 160Q120 162 70 150Z', fill: BK.lg(svg, Rl.lt, Rl.c, { a: 90 }), stroke: Rl.dk, 'stroke-width': 2 }, big);
    T(big, 252, 104, '60S', { fs: 13, a: 'middle', w: 700, c: Rl.ink });
    const small = P('small');
    E('path', { d: 'M86 180Q110 168 180 170Q250 168 274 180Q284 226 180 232Q76 226 86 180Z', fill: BK.lg(svg, Rs.lt, Rs.c, { a: 90 }), stroke: Rs.dk, 'stroke-width': 2 }, small);
    T(small, 180, 214, '40S', { fs: 13, a: 'middle', w: 700, c: Rs.ink });
    const sites = P('sites');
    [['E', 128], ['P', 180], ['A', 232]].forEach(([s, x]) => {
      E('rect', { x: x - 22, y: 112, width: 44, height: 46, rx: 8, fill: FK.alpha('#fff', .35), stroke: FK.alpha(Rl.dk, .7), 'stroke-dasharray': '4 3' }, sites);
      T(sites, x, 128, s, { fs: 12, a: 'middle', w: 700, c: Rl.ink });
    });
    const tr = P('trna');
    E('path', { d: 'M180 158V132M172 132h16', stroke: Rt.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, tr);
    E('circle', { cx: 180, cy: 104, r: 9, fill: Ra.c, stroke: Ra.dk }, tr);
    E('circle', { cx: 166, cy: 92, r: 8, fill: Rp.c, stroke: Rp.dk }, tr);
    E('circle', { cx: 152, cy: 80, r: 8, fill: Ra.c, stroke: Ra.dk }, tr);
    const mr = P('mrna');
    E('path', { d: 'M20 166H340', stroke: Rm.dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, mr);
    T(mr, 22, 186, "৫′", { fs: 13, w: 650, c: C.mu }); T(mr, 326, 186, "৩′", { fs: 13, w: 650, c: C.mu });
  },
  idle(g, C, t) {
    const Rm = BK.ramp(4), o = (t * 14) % 24;
    for (let x = 24 - o; x < 340; x += 24) E('path', { d: `M${x} 162v8`, stroke: FK.alpha(Rm.lt, .9), 'stroke-width': 2 }, g);
    const Ra = BK.ramp(2);
    E('circle', { cx: 152 - 2 * Math.sin(t * 2), cy: 80 - 2 * Math.cos(t * 2), r: 12, fill: 'none', stroke: FK.alpha(Ra.c, .35 + .25 * Math.sin(t * 2)), 'stroke-width': 2 }, g);
  },
  parts: [
    { id: 'big', bn: 'বড় উপএকক (60S)', lb: 'বড় উপএকক', en: 'Large subunit', fn: 'প্রকৃতকোষে <b>60S</b> (28S, 5.8S ও 5S rRNA + প্রায় ৪৯টি প্রোটিন); আদিকোষে 50S। এতেই <b>পেপটাইডিল ট্রান্সফারেজ</b> থাকে যা পেপটাইড বন্ধন গড়ে — এটি আসলে একটি rRNA (রাইবোজাইম)।', a: [250, 80], l: [340, 40], an: 'end' },
    { id: 'small', bn: 'ছোট উপএকক (40S)', lb: 'ছোট উপএকক', en: 'Small subunit', fn: 'প্রকৃতকোষে <b>40S</b> (18S rRNA + প্রায় ৩৩টি প্রোটিন); আদিকোষে 30S। mRNA প্রথমে এখানেই যুক্ত হয়। দুই উপএকক যুক্ত থাকতে <b>Mg²⁺</b> আয়ন লাগে।', a: [240, 220], l: [340, 270], an: 'end' },
    { id: 'sites', bn: 'E, P ও A সাইট', lb: 'E-P-A সাইট', en: 'tRNA sites', fn: '<b>A (অ্যামাইনোঅ্যাসাইল)</b> — নতুন tRNA আসে; <b>P (পেপটাইডিল)</b> — বাড়ন্ত শিকলধারী tRNA থাকে; <b>E (এক্সিট)</b> — খালি tRNA বেরিয়ে যায়।', a: [232, 130], l: [340, 120], an: 'end' },
    { id: 'trna', bn: 'tRNA ও পেপটাইড শিকল', lb: 'tRNA', en: 'tRNA + peptide', fn: 'P সাইটে বসা tRNA বাড়ন্ত পলিপেপটাইড শিকল ধরে রাখে; শিকলটি বড় উপএককের একটি সুড়ঙ্গ দিয়ে বেরিয়ে আসে।', a: [160, 86], l: [20, 50], an: 'start' },
    { id: 'mrna', bn: 'mRNA', en: 'mRNA', fn: 'দুই উপএককের ফাঁক দিয়ে mRNA <b>৫′ → ৩′</b> দিকে এক কোডন করে সরে। একটি mRNA-তে একসাথে অনেক রাইবোসোম বসলে তাকে <b>পলিরাইবোসোম বা পলিসোম</b> বলে।', a: [60, 166], l: [20, 260], an: 'start' }
  ]
}));
})();

/* ───────── ৩. অমসৃণ ও মসৃণ ER ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.erTypes = Object.assign({
  t: 'এন্ডোপ্লাজমিক রেটিকুলাম — অমসৃণ ও মসৃণ', k: ['2d', 'anim', 'int', 'game'],
  cap: 'বাঁয়ে <b>অমসৃণ ER</b> — চ্যাপ্টা থলির (সিস্টার্নি) গায়ে রাইবোসোম, প্রোটিন তৈরি করে; নিউক্লিয়ার পর্দার সাথে যুক্ত। ডানে <b>মসৃণ ER</b> — রাইবোসোমবিহীন নালিকা, লিপিড ও স্টেরয়েড তৈরি এবং বিষনাশ করে।'
}, BK.diagram({
  W: 360, H: 290, label: 'অমসৃণ ও মসৃণ ER',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rn = BK.org('nucleus'), Rr = BK.ramp(3), Rb = BK.ramp(5), Rs = BK.ramp(6), Rl = BK.ramp(2);
    const nu = P('nuc');
    E('path', { d: 'M0 30Q60 40 64 145Q60 250 0 260', fill: FK.alpha(Rn.lt || Rn.c, .5), stroke: Rn.dk || Rn.c, 'stroke-width': 3 }, nu);
    T(nu, 6, 150, 'নিউক্লিয়াস', { fs: 11, w: 600, c: C.mu, a: 'start' });
    const rer = P('rer');
    const cis = [];
    for (let i = 0; i < 4; i++) {
      const y = 60 + i * 44;
      const d = `M70 ${y}Q120 ${y - 12} 170 ${y}Q186 ${y + 8} 170 ${y + 16}Q120 ${y + 26} 70 ${y + 16}`;
      E('path', { d, fill: FK.alpha(Rr.lt, .7), stroke: Rr.dk, 'stroke-width': 2 }, rer);
      cis.push(y);
    }
    const rib = P('rib');
    cis.forEach(y => { for (let x = 80; x <= 166; x += 12) { E('circle', { cx: x, cy: y - 5 + (x % 24 ? 0 : -2), r: 3, fill: Rb.c }, rib); E('circle', { cx: x + 6, cy: y + 22, r: 3, fill: Rb.c }, rib); } });
    const ser = P('ser');
    E('path', { d: 'M196 70q30 -20 50 10t50 0t44 30M200 130q40 -24 60 6t70 -6M210 190q20 30 60 10t70 20M246 80q-10 50 14 56M300 104q10 50 -20 96', fill: 'none', stroke: Rs.dk, 'stroke-width': 9, 'stroke-linecap': 'round', opacity: .85 }, ser);
    E('path', { d: 'M196 70q30 -20 50 10t50 0t44 30M200 130q40 -24 60 6t70 -6M210 190q20 30 60 10t70 20M246 80q-10 50 14 56M300 104q10 50 -20 96', fill: 'none', stroke: FK.alpha(Rs.lt, .9), 'stroke-width': 5, 'stroke-linecap': 'round' }, ser);
    const lip = P('lip');
    [[262, 160], [316, 160], [230, 236]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 6, fill: Rl.c, stroke: Rl.dk }, lip));
  },
  idle(g, C, t) {
    const Rb = BK.ramp(5);
    for (let i = 0; i < 4; i++) { const x = 80 + ((t * 18 + i * 26) % 90), y = 60 + i * 44 - 16 - ((t * 10 + i * 5) % 14);
      E('path', { d: `M${x} ${y + 8}q3 -4 6 0t6 0`, stroke: FK.alpha(Rb.dk, .55), 'stroke-width': 1.6, fill: 'none' }, g); }
  },
  parts: [
    { id: 'nuc', bn: 'নিউক্লিয়ার পর্দা', en: 'Nuclear envelope', fn: 'নিউক্লিয়াসের বাইরের পর্দা অমসৃণ ER-এর সাথে <b>অবিচ্ছিন্ন</b> — তাই ER নিউক্লিয়াস ও কোষঝিল্লির মধ্যে যোগাযোগের পথ।', a: [50, 220], l: [20, 280], an: 'start' },
    { id: 'rer', bn: 'অমসৃণ ER (সিস্টার্নি)', lb: 'অমসৃণ ER', en: 'Rough ER', fn: 'চ্যাপ্টা, সমান্তরাল থলি বা <b>সিস্টার্নি</b>। রাইবোসোমে তৈরি প্রোটিন এর গহ্বরে ঢুকে ভাঁজ হয় ও গ্লাইকোসাইলেশন শুরু হয়; পরে ভেসিকলে করে গলগিতে যায়। অগ্ন্যাশয় ও প্লাজমা কোষে প্রচুর।', a: [120, 110], l: [120, 22], an: 'middle' },
    { id: 'rib', bn: 'সংযুক্ত রাইবোসোম', lb: 'রাইবোসোম', en: 'Bound ribosomes', fn: 'রাইবোসোমের বড় উপএকক <b>রাইবোফরিন</b> প্রোটিনের মাধ্যমে ER-এর গায়ে আটকে থাকে — এগুলো নিঃসরণযোগ্য ও ঝিল্লির প্রোটিন তৈরি করে।', a: [86, 55], l: [20, 18], an: 'start' },
    { id: 'ser', bn: 'মসৃণ ER (নালিকা)', lb: 'মসৃণ ER', en: 'Smooth ER', fn: 'রাইবোসোমবিহীন শাখান্বিত <b>নালিকা ও ভেসিকল</b>। কাজ: লিপিড, ফসফোলিপিড ও স্টেরয়েড হরমোন তৈরি; যকৃতে ওষুধ ও বিষ নিষ্ক্রিয়করণ; গ্লাইকোজেন ভাঙা; পেশিতে (সারকোপ্লাজমিক রেটিকুলাম) Ca²⁺ সঞ্চয়।', a: [300, 104], l: [340, 40], an: 'end' },
    { id: 'lip', bn: 'লিপিড বিন্দু', en: 'Lipid droplets', fn: 'মসৃণ ER-এ তৈরি লিপিড ও স্টেরয়েড — যেমন শুক্রাশয় ও অ্যাড্রিনাল গ্রন্থির কোষে স্টেরয়েড হরমোন।', a: [316, 160], l: [340, 270], an: 'end' }
  ]
}));
})();

/* ───────── ৪. প্রোটিনের যাত্রা: ER → গলগি → বাইরে ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.golgiFlow = Object.assign({
  t: 'গলগি বডি — প্রোটিনের প্যাকেজিং ও প্রেরণ', k: ['2d', 'anim'],
  cap: 'অমসৃণ ER-এ তৈরি প্রোটিন ভেসিকলে করে গলগির <b>সিস (গ্রহণ) তলে</b> ঢোকে, সিস্টার্নি পেরিয়ে পরিবর্তিত হয়, আর <b>ট্রান্স (প্রেরণ) তল</b> থেকে নিঃসরণ ভেসিকল বা লাইসোসোম হয়ে বেরোয়। একে কোষের "ডাকঘর" বলা হয়।'
}, BK.steps({
  W: 380, H: 250, label: 'ER থেকে গলগি হয়ে নিঃসরণ', dur: 3.2,
  stages: [
    { t: 'ER-এ প্রোটিন', en: 'Synthesis in RER', d: 'অমসৃণ ER-এর রাইবোসোমে প্রোটিন তৈরি হয়ে ER-এর গহ্বরে ঢোকে; এখানে ভাঁজ হয় ও শর্করা যুক্ত হওয়া শুরু হয়।' },
    { t: 'পরিবহন ভেসিকল', en: 'Transport vesicle', d: 'ER-এর পর্দা ফুলে <b>পরিবহন ভেসিকল</b> তৈরি হয় এবং প্রোটিন নিয়ে গলগির <b>সিস তলের</b> দিকে যায়।' },
    { t: 'সিস্টার্নিতে পরিবর্তন', en: 'Modification', d: 'সিস থেকে মাঝের হয়ে ট্রান্স সিস্টার্নিতে যেতে যেতে প্রোটিনে শর্করা যুক্ত হয় (<b>গ্লাইকোপ্রোটিন</b>), ছাঁটাই হয় ও ঠিকানা-চিহ্ন বসে।' },
    { t: 'ট্রান্স তল থেকে প্রেরণ', en: 'Sorting', d: 'ট্রান্স তল থেকে তিন ধরনের ভেসিকল: <b>নিঃসরণ ভেসিকল</b>, <b>লাইসোসোম</b> এবং কোষঝিল্লিতে যাওয়ার ভেসিকল।' },
    { t: 'এক্সোসাইটোসিস', en: 'Exocytosis', d: 'নিঃসরণ ভেসিকল কোষঝিল্লির সাথে মিশে প্রোটিন (যেমন ইনসুলিন, পাচক রস, মিউকাস) কোষের <b>বাইরে</b> ছেড়ে দেয়।' }
  ],
  draw(g, C, s, u) {
    const Rr = BK.ramp(3), Rg = BK.ramp(6), Rp = BK.ramp(4), Rv = BK.ramp(5), Rl = BK.ramp(8), Rm = BK.org('mem');
    const e = FK.ease(Math.min(1, u * 1.3));
    /* ER */
    for (let i = 0; i < 3; i++) { const y = 70 + i * 40; E('path', { d: `M14 ${y}Q50 ${y - 8} 80 ${y}Q90 ${y + 7} 80 ${y + 14}Q50 ${y + 22} 14 ${y + 14}`, fill: FK.alpha(Rr.lt, .7), stroke: Rr.dk, 'stroke-width': 1.8 }, g);
      for (let x = 20; x < 80; x += 10) E('circle', { cx: x, cy: y - 4, r: 2.4, fill: BK.ramp(5).c }, g); }
    T(g, 48, 36, 'অমসৃণ ER', { fs: 12.5, a: 'middle', w: 600, c: Rr.ink });
    /* গলগি: ৫টি বাঁকা সিস্টার্নি */
    for (let i = 0; i < 5; i++) { const x = 150 + i * 16; E('path', { d: `M${x} 60Q${x + 22} 125 ${x} 190`, fill: 'none', stroke: Rg.c, 'stroke-width': 11, 'stroke-linecap': 'round', opacity: .85 }, g); }
    T(g, 150, 210, 'সিস', { fs: 12.5, a: 'middle', w: 600, c: Rg.ink }); T(g, 226, 210, 'ট্রান্স', { fs: 12.5, a: 'middle', w: 600, c: Rg.ink });
    T(g, 190, 36, 'গলগি বডি', { fs: 12.5, a: 'middle', w: 600, c: Rg.ink });
    /* কোষঝিল্লি */
    E('path', { d: 'M350 26Q340 125 350 236', fill: 'none', stroke: Rm.c || C.mu, 'stroke-width': 5 }, g);
    T(g, 340, 16, 'কোষঝিল্লি', { fs: 12.5, a: 'end', w: 600, c: C.mu });
    const prot = (x, y, col) => E('path', { d: `M${x - 4} ${y}q2 -4 4 0t4 0`, stroke: col, 'stroke-width': 2, fill: 'none' }, g);
    if (s === 0) { for (let i = 0; i < 3; i++) prot(40 + 14 * i * e, 77 + i * 40, Rp.dk); }
    if (s === 1) { const x = 84 + (140 - 84) * e, y = 110 + Math.sin(e * 3) * 6; E('circle', { cx: x, cy: y, r: 13, fill: FK.alpha(Rv.lt, .7), stroke: Rv.dk, 'stroke-width': 1.6 }, g); prot(x, y, Rp.dk); }
    if (s === 2) { const x = 150 + 76 * e; E('circle', { cx: x, cy: 125, r: 6, fill: FK.alpha(Rp.c, .5 + .5 * e), stroke: Rp.dk }, g);
      for (let k = 0; k < Math.floor(e * 4); k++) E('circle', { cx: x + 6 + k * 3, cy: 119 - k * 2, r: 2, fill: BK.ramp(10).c }, g);
      T(g, 190, 232, 'শর্করা যুক্ত হচ্ছে → গ্লাইকোপ্রোটিন', { fs: 12.5, a: 'middle', w: 600, c: Rp.ink }); }
    if (s >= 3) {
      const k = s === 3 ? e : 1;
      [[Rv, 'নিঃসরণ', 80], [Rl, 'লাইসোসোম', 160], [BK.ramp(10), 'ঝিল্লির', 120]].forEach(([R, lab, y], i) => {
        const x = 240 + (s === 4 && i === 0 ? 100 * e : 60 * k * (i === 1 ? .7 : 1));
        const yy = s === 4 && i === 0 ? y : 125 + (y - 125) * k;
        if (!(s === 4 && i === 0 && e > .9)) E('circle', { cx: x, cy: yy, r: 13, fill: FK.alpha(R.lt, .75), stroke: R.dk, 'stroke-width': 1.6 }, g);
        T(g, x - 16, yy + 5, lab, { fs: 12.5, a: 'end', w: 600, c: R.ink });
      });
    }
    if (s === 4) for (let i = 0; i < 4; i++) { const t = Math.max(0, e - .7) / .3; if (t > 0) prot(352 + 6 * t + i * 2, 60 + i * 12, Rp.dk); }
  }
}));
})();

/* ───────── ৫. লাইসোসোমের কাজ ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.lysoCycle = Object.assign({
  t: 'লাইসোসোম — অন্তঃকোষীয় পরিপাক', k: ['2d', 'anim'],
  cap: 'গলগি থেকে তৈরি <b>প্রাথমিক লাইসোসোম</b> (pH ~4.8, প্রায় ৪০ ধরনের হাইড্রোলাইটিক এনজাইম) খাদ্য-থলি বা জীর্ণ অঙ্গাণুর সাথে মিশে <b>গৌণ লাইসোসোম</b> হয়, ভেতরে পরিপাক ঘটে, অপাচ্য অংশ <b>অবশিষ্ট বস্তু</b> হিসেবে বাইরে যায়।'
}, BK.steps({
  W: 380, H: 240, label: 'লাইসোসোমের পরিপাক চক্র', dur: 3.2,
  stages: [
    { t: 'প্রাথমিক লাইসোসোম', en: 'Primary lysosome', d: 'গলগির ট্রান্স তল থেকে একক পর্দাবেষ্টিত থলি হিসেবে তৈরি — ভেতরে নিষ্ক্রিয় অবস্থায় <b>অ্যাসিড হাইড্রোলেজ</b> এনজাইম।' },
    { t: 'ফ্যাগোসাইটোসিস', en: 'Phagocytosis', d: 'কোষঝিল্লি ব্যাকটেরিয়া বা খাদ্যকণা ঘিরে ভেতরে নিয়ে <b>ফ্যাগোসোম</b> তৈরি করে (শ্বেতকণিকায় এভাবে জীবাণু ধ্বংস)।' },
    { t: 'গৌণ লাইসোসোম', en: 'Secondary lysosome', d: 'প্রাথমিক লাইসোসোম ফ্যাগোসোমের সাথে মিশে <b>গৌণ লাইসোসোম (পরিপাক গহ্বর)</b>; অম্লীয় pH-এ এনজাইম সক্রিয় হয়ে পরিপাক করে।' },
    { t: 'অবশিষ্ট বস্তু', en: 'Residual body', d: 'পাচিত সরল অণু সাইটোপ্লাজমে শোষিত হয়; অপাচ্য অংশ <b>অবশিষ্ট বস্তু</b> হয়ে এক্সোসাইটোসিসে বেরিয়ে যায়।' },
    { t: 'অটোফ্যাজি ও অটোলাইসিস', en: 'Autophagy', d: 'জীর্ণ মাইটোকন্ড্রিয়া ঘিরে <b>অটোফ্যাগোসোম</b> তৈরি হয়ে পরিপাক হয় (অটোফ্যাজি)। কোষ মারা গেলে পর্দা ফেটে সব এনজাইম বেরিয়ে কোষকেই পরিপাক করে — <b>অটোলাইসিস</b>, তাই নাম "আত্মঘাতী থলি"।' }
  ],
  draw(g, C, s, u) {
    const Rl = BK.ramp(8), Rb = BK.ramp(10), Rm = BK.org('mem'), Rmi = BK.org('mito'), Rg = BK.ramp(6);
    const e = FK.ease(Math.min(1, u * 1.3)), F = { fs: 13, a: 'middle', w: 600 };
    E('path', { d: 'M352 10Q338 120 352 236', fill: 'none', stroke: Rm.c || C.mu, 'stroke-width': 5 }, g);
    T(g, 340, 18, 'কোষঝিল্লি', { fs: 12, a: 'end', w: 600, c: C.mu });
    for (let i = 0; i < 3; i++) E('path', { d: `M${30 + i * 13} 140q22 40 0 84`, fill: 'none', stroke: Rg.c, 'stroke-width': 8, 'stroke-linecap': 'round' }, g);
    T(g, 50, 130, 'গলগি', Object.assign({ c: Rg.ink }, F));
    const lyso = (x, y, r, a) => { E('circle', { cx: x, cy: y, r, fill: FK.alpha(Rl.lt, a), stroke: Rl.dk, 'stroke-width': 2 }, g); for (let k = 0; k < 6; k++) E('circle', { cx: x + Math.cos(k * 1.05) * r * .55, cy: y + Math.sin(k * 1.05) * r * .55, r: 2.6, fill: Rl.dk }, g); };
    const bact = (x, y, sc) => E('rect', { x: x - 18 * sc, y: y - 9 * sc, width: 36 * sc, height: 18 * sc, rx: 9 * sc, fill: Rb.c, stroke: Rb.dk, 'stroke-width': 1.5 }, g);
    const px = 230, py = 100;
    if (s === 0) { lyso(80 + 70 * e, 180 - 60 * e, 20, .7); T(g, 150 + 0 * e, 80, 'প্রাথমিক লাইসোসোম', Object.assign({ c: Rl.ink }, F)); T(g, 150, 98, 'pH ≈ 4.8', Object.assign({ c: C.mu }, F, { fs: 12 })); }
    if (s === 1) { const x = 330 - 100 * e;
      bact(x, py, 1);
      E('path', { d: `M350 ${py - 50 + 10 * e}Q${x - 50} ${py} 350 ${py + 50 - 10 * e}`, fill: 'none', stroke: Rm.c || C.mu, 'stroke-width': 3.5 }, g);
      T(g, 240, 40, 'ব্যাকটেরিয়া গ্রহণ → ফ্যাগোসোম', Object.assign({ c: Rb.ink }, F));
      lyso(130, 150, 20, .7); }
    if (s === 2 || s === 3) {
      E('circle', { cx: px, cy: py, r: 38, fill: FK.alpha(Rl.lt, s === 2 ? .3 + .35 * e : .55), stroke: Rl.dk, 'stroke-width': 2.4 }, g);
      bact(px, py, s === 2 ? 1 - .5 * e : .45);
      if (s === 2) { lyso(130 + (px - 40 - 130) * e, 150 - (150 - py) * e, 20 * (1 - .5 * e), .7);
        for (let k = 0; k < 8; k++) { const a = k * .785 + u * 6; E('circle', { cx: px + Math.cos(a) * 26, cy: py + Math.sin(a) * 26, r: 2.6, fill: Rl.dk }, g); } }
      T(g, px, py - 48, s === 2 ? 'গৌণ লাইসোসোম' : 'অবশিষ্ট বস্তু', Object.assign({ c: Rl.ink }, F));
      if (s === 3) { for (let k = 0; k < 8; k++) { const a = k * .785; E('circle', { cx: px + Math.cos(a) * (42 + 50 * e), cy: py + Math.sin(a) * (42 + 40 * e), r: 3.2, fill: Rb.dk }, g); }
        T(g, 180, 222, 'সরল অণু সাইটোপ্লাজমে শোষিত', Object.assign({ c: C.mu }, F)); }
    }
    if (s === 4) { const mx = 230, my = 130;
      E('ellipse', { cx: mx, cy: my, rx: 40, ry: 20, fill: FK.alpha(Rmi.lt || Rmi.c, .7), stroke: Rmi.dk || Rmi.c, 'stroke-width': 2 }, g);
      E('path', { d: `M${mx - 32} ${my}q16 -14 32 0t32 0`, fill: 'none', stroke: Rmi.dk || Rmi.c, 'stroke-width': 1.6 }, g);
      E('ellipse', { cx: mx, cy: my, rx: 52, ry: 32, fill: 'none', stroke: Rl.dk, 'stroke-width': 2.6, 'stroke-dasharray': `${270 * e} 400` }, g);
      T(g, mx, my - 44, 'অটোফ্যাগোসোম', Object.assign({ c: Rl.ink }, F));
      T(g, mx, my + 54, 'জীর্ণ মাইটোকন্ড্রিয়া', Object.assign({ c: C.mu }, F, { fs: 12 }));
      lyso(110 + 60 * e, 90 + 20 * e, 18, .7);
    }
  }
}));
})();
