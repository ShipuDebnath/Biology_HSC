/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.১০ — রেপ্লিকেশন, ট্রান্সক্রিপশন, ট্রান্সলেশন
   meselson  : মেসেলসন-স্টাল — প্রজন্মভিত্তিক সূত্র ও CsCl ব্যান্ড
   replFork  : রেপ্লিকেশন ফর্ক — হেলিকেজ, প্রাইমার, লিডিং, ওকাজাকি, লাইগেজ
   transcribe: ট্রান্সক্রিপশন ও স্প্লাইসিং
   translate : রাইবোসোমে ট্রান্সলেশন — A/P/E সাইট, পেপটাইড শিকল
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const H_ = BK.ramp(4), L_ = BK.ramp(5);   /* ভারী (¹⁵N) ও হালকা (¹⁴N) সূত্রের রং */

/* ───────── ১. মেসেলসন ও স্টাল ───────── */
V.meselson = Object.assign({
  t: 'মেসেলসন-স্টালের পরীক্ষা', k: ['2d', 'anim'],
  cap: 'লাল = ভারী <b>¹⁵N</b> সূত্র, নীল = হালকা <b>¹⁴N</b> সূত্র। প্রতি প্রজন্মে বাঁয়ে DNA অণুগুলো আর ডানে CsCl টিউবের ব্যান্ড দেখো। লক্ষ করো — যত প্রজন্মই হোক, লাল সূত্র মাত্র <b>দুটি</b>, তাই মাঝারি DNA সবসময় ২টি।'
}, BK.steps({
  W: 360, H: 270, label: 'মেসেলসন-স্টালের পরীক্ষা', dur: 3.2,
  stages: [
    { t: 'প্রজন্ম ০', en: 'Generation 0', d: 'বহু প্রজন্ম <b>¹⁵N</b> মাধ্যমে চাষ — দুটি সূত্রই ভারী। সেন্ট্রিফিউজে একটি ব্যান্ড, <b>নিচে</b>।' },
    { t: 'প্রজন্ম ১', en: 'Generation 1', d: '¹⁴N মাধ্যমে একবার রেপ্লিকেশন — প্রতিটি DNA-তে একটি ভারী ও একটি হালকা সূত্র। একটি ব্যান্ড, <b>মাঝে</b>। <b>সংরক্ষণশীল পদ্ধতি বাতিল</b> (তাহলে উপরে ও নিচে দুটি ব্যান্ড হতো)।' },
    { t: 'প্রজন্ম ২', en: 'Generation 2', d: '৪টি DNA — ২টি মাঝারি, ২টি হালকা। দুটি ব্যান্ড, <b>মাঝে ও উপরে, ১ : ১</b>। <b>বিচ্ছুরিত পদ্ধতি বাতিল</b> (তাহলে একটিই ব্যান্ড হতো)।' },
    { t: 'প্রজন্ম ৩', en: 'Generation 3', d: '৮টি DNA — ২টি মাঝারি, ৬টি হালকা; অনুপাত <b>১ : ৩</b>। সিদ্ধান্ত: রেপ্লিকেশন <b>অর্ধ-সংরক্ষণশীল</b>।' }
  ],
  draw(g, C, s, u) {
    const n = Math.pow(2, s), mid = s === 0 ? 0 : 2, light = s === 0 ? 0 : n - 2, heavy = s === 0 ? 1 : 0;
    /* বাঁয়ে DNA অণু (জোড়া সূত্র) */
    const list = [];
    if (s === 0) list.push(['H', 'H']);
    else { list.push(['H', 'L'], ['L', 'H']); for (let i = 0; i < light; i++) list.push(['L', 'L']); }
    const cols = list.length > 4 ? 4 : list.length, rows = Math.ceil(list.length / cols);
    const ap = FK.ease(Math.min(1, u * 1.4));
    list.forEach((m, i) => {
      const cx = 30 + (i % cols) * 50, cy = 70 + Math.floor(i / cols) * (rows > 1 ? 62 : 0) + (rows > 1 ? 0 : 30);
      const sep = 6 + (1 - ap) * 6;
      [[-1, m[0]], [1, m[1]]].forEach(([sd, k]) => {
        const R = k === 'H' ? H_ : L_;
        E('rect', { x: cx + sd * sep - 3.5, y: cy - 26, width: 7, height: 52, rx: 3.5, fill: R.c, opacity: .25 + .75 * ap }, g);
      });
      for (let r = -20; r <= 20; r += 8) E('path', { d: `M${cx - sep + 3} ${cy + r}H${cx + sep - 3}`, stroke: FK.alpha(C.mu, .5 * ap), 'stroke-width': 1.3 }, g);
    });
    T(g, 100, 22, `মোট DNA = ${n}`, { fs: 12, a: 'middle', w: 650, c: C.fg });

    /* ডানে সেন্ট্রিফিউজ টিউব */
    const TX = 290, TY = 46, TH = 178;
    E('path', { d: `M${TX - 22} ${TY}V${TY + TH - 18}Q${TX - 22} ${TY + TH} ${TX} ${TY + TH}Q${TX + 22} ${TY + TH} ${TX + 22} ${TY + TH - 18}V${TY}`, fill: FK.alpha(C.mu, .08), stroke: FK.alpha(C.mu, .7), 'stroke-width': 1.6 }, g);
    const band = (y, col, w, lab) => {
      E('rect', { x: TX - 20, y: y - 4, width: 40, height: 8, rx: 4, fill: FK.alpha(col, .3 + .6 * ap * w) }, g);
      T(g, TX - 28, y + 4, lab, { fs: 10, a: 'end', w: 560, c: C.mu });
    };
    const yH = TY + 140, yM = TY + 95, yL = TY + 50;
    E('path', { d: `M${TX + 28} ${yL}V${yH}`, stroke: FK.alpha(C.mu, .35), 'stroke-width': 1 }, g);
    T(g, TX + 32, yL + 4, '¹⁴N', { fs: 9, w: 560, c: L_.ink });
    T(g, TX + 32, yH + 4, '¹⁵N', { fs: 9, w: 560, c: H_.ink });
    if (heavy) band(yH, H_.c, 1, 'ভারী');
    if (mid) band(yM, BK.ramp(8).c, mid / n, 'মাঝারি');
    if (light) band(yL, L_.c, light / n, 'হালকা');
    T(g, TX, TY + TH + 22, 'CsCl টিউব', { fs: 10, a: 'middle', w: 560, c: C.mu });
    if (s > 0) T(g, 100, 252, `মাঝারি : হালকা = ${mid} : ${light}`, { fs: 12, a: 'middle', w: 650, c: BK.ramp(8).ink });
  }
}));

/* ───────── ২. রেপ্লিকেশন ফর্ক ───────── */
V.replFork = Object.assign({
  t: 'রেপ্লিকেশন ফর্ক — এনজাইমের কাজ ধাপে ধাপে', k: ['2d', 'anim'],
  cap: 'ডান দিকে ফর্ক খুলছে। <b>উপরের</b> নতুন সূত্র (লিডিং) ফর্কের পেছন পেছন একটানা বাড়ছে; <b>নিচের</b> নতুন সূত্র (ল্যাগিং) ফর্কের উল্টো দিকে ছোট ছোট <b>ওকাজাকি খণ্ডে</b> তৈরি হচ্ছে — প্রতিটির মাথায় লাল <b>RNA প্রাইমার</b>। শেষ ধাপে লাইগেজ খণ্ডগুলো জোড়ে।'
}, BK.steps({
  W: 380, H: 260, label: 'রেপ্লিকেশন ফর্ক', dur: 3.4,
  stages: [
    { t: 'হেলিকেজ খোলে', en: 'Helicase', d: '<b>হেলিকেজ</b> ATP খরচ করে হাইড্রোজেন বন্ধন ভেঙে দুই সূত্র আলাদা করে — Y আকৃতির ফর্ক। <b>টপোআইসোমারেজ</b> সামনের টান কমায়, <b>SSB</b> খোলা সূত্র ধরে রাখে।' },
    { t: 'প্রাইমার বসে', en: 'Primase', d: '<b>প্রাইমেজ</b> দুই ছাঁচেই ছোট <b>RNA প্রাইমার</b> বসায় — কারণ DNA পলিমারেজ শূন্য থেকে শুরু করতে পারে না।' },
    { t: 'লিডিং সূত্র', en: 'Leading strand', d: '<b>DNA পলিমারেজ III</b> উপরের ছাঁচে (৩′ → ৫′) প্রাইমার থেকে <b>৫′ → ৩′</b> দিকে ফর্কের সাথে সাথে একটানা নতুন সূত্র গড়ে।' },
    { t: 'ওকাজাকি খণ্ড', en: 'Okazaki fragments', d: 'নিচের ছাঁচে পলিমারেজকে ফর্কের <b>উল্টো দিকে</b> যেতে হয় — তাই প্রতিবার নতুন প্রাইমার থেকে ছোট খণ্ড তৈরি হয়: <b>ল্যাগিং সূত্র</b>।' },
    { t: 'প্রাইমার সরে, লাইগেজ জোড়ে', en: 'Pol I + Ligase', d: '<b>DNA পলিমারেজ I</b> RNA প্রাইমার সরিয়ে DNA বসায়; <b>DNA লাইগেজ</b> খণ্ডগুলোর ফাঁকে ফসফোডাইএস্টার বন্ধন গড়ে — দুটি অভিন্ন DNA।' }
  ],
  draw(g, C, s, u) {
    const Rold = BK.ramp(9), Rnew = BK.ramp(10), Rp = BK.ramp(4), Rh = BK.ramp(6), Rl = BK.ramp(3);
    const FX = 250 + (s >= 2 ? 30 * Math.min(1, u) : 0), Y = 130, OPEN = 46;
    /* ফর্কের ডানে অখণ্ড দ্বিসূত্রক DNA */
    E('path', { d: `M${FX} ${Y - 6}H370M${FX} ${Y + 6}H370`, stroke: Rold.dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, g);
    for (let x = FX + 8; x < 368; x += 10) E('path', { d: `M${x} ${Y - 4}V${Y + 4}`, stroke: FK.alpha(C.mu, .6), 'stroke-width': 1.4 }, g);
    /* খোলা দুই ছাঁচ সূত্র */
    E('path', { d: `M${FX} ${Y - 6}L${FX - 40} ${Y - OPEN}H20`, fill: 'none', stroke: Rold.dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, g);
    E('path', { d: `M${FX} ${Y + 6}L${FX - 40} ${Y + OPEN}H20`, fill: 'none', stroke: Rold.dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, g);
    T(g, 14, Y - OPEN - 8, "৩′", { fs: 10.5, a: 'start', w: 650, c: Rold.ink });
    T(g, 14, Y + OPEN + 18, "৫′", { fs: 10.5, a: 'start', w: 650, c: Rold.ink });
    T(g, 372, Y - 12, "৫′", { fs: 10.5, a: 'end', w: 650, c: Rold.ink });
    /* হেলিকেজ */
    E('circle', { cx: FX, cy: Y, r: 13, fill: BK.lg(g.ownerSVGElement, Rh.lt, Rh.c, { a: 90 }), stroke: Rh.dk, 'stroke-width': 1.6 }, g);
    T(g, FX, Y + 4, 'H', { fs: 11, a: 'middle', w: 700, c: Rh.ink });
    if (s === 0) { T(g, FX + 22, Y - 22, 'হেলিকেজ', { fs: 11, w: 620, c: Rh.ink }); [0, 1, 2].forEach(i => E('circle', { cx: 60 + i * 50, cy: Y + OPEN - 10, r: 5, fill: FK.alpha(BK.ramp(8).c, .8) }, g)); T(g, 60, Y + OPEN - 22, 'SSB', { fs: 9.5, w: 600, c: BK.ramp(8).ink }); }

    const topY = Y - OPEN + 12, botY = Y + OPEN - 12, lead = FX - 40;
    /* লিডিং সূত্র — উপরে, ফর্কের দিকে একটানা */
    if (s >= 1) E('rect', { x: 30, y: topY - 4, width: 22, height: 8, rx: 4, fill: s >= 4 ? Rnew.c : Rp.c }, g);
    if (s >= 2) {
      const end = s === 2 ? 52 + (lead - 52) * FK.ease(u) : lead;
      E('path', { d: `M52 ${topY}H${end}`, stroke: Rnew.c, 'stroke-width': 7, 'stroke-linecap': 'round' }, g);
      E('path', { d: `M${end - 8} ${topY - 6}L${end} ${topY}L${end - 8} ${topY + 6}`, fill: 'none', stroke: Rnew.dk, 'stroke-width': 2 }, g);
      T(g, 120, topY + 22, 'লিডিং সূত্র (একটানা) ৫′ → ৩′', { fs: 10.5, a: 'middle', w: 600, c: Rnew.ink });
    }
    /* ল্যাগিং সূত্র — নিচে, ওকাজাকি খণ্ড */
    const frag = [[40, 110], [120, 190], [200, lead]];
    if (s >= 1) frag.forEach(([a, b], i) => {
      if (s === 1 && i < 2) return;
      E('rect', { x: b - 20, y: botY - 4, width: 20, height: 8, rx: 4, fill: s >= 4 ? Rnew.c : Rp.c }, g);
    });
    if (s >= 3) frag.forEach(([a, b], i) => {
      const prog = s === 3 ? Math.max(0, Math.min(1, u * 3 - (2 - i))) : 1;
      const x2 = b - 20 - (b - 20 - a) * FK.ease(prog);
      if (prog > 0) {
        E('path', { d: `M${b - 20} ${botY}H${x2}`, stroke: Rnew.c, 'stroke-width': 7, 'stroke-linecap': 'round' }, g);
        E('path', { d: `M${x2 + 8} ${botY - 6}L${x2} ${botY}L${x2 + 8} ${botY + 6}`, fill: 'none', stroke: Rnew.dk, 'stroke-width': 2 }, g);
      }
    });
    if (s >= 3) T(g, 120, botY - 14, 'ল্যাগিং সূত্র — ওকাজাকি খণ্ড', { fs: 10.5, a: 'middle', w: 600, c: Rnew.ink });
    if (s >= 4) [110, 190].forEach(x => {
      const k = FK.ease(u);
      E('circle', { cx: x, cy: botY, r: 7 + 3 * k, fill: 'none', stroke: FK.alpha(Rl.c, .4 + .5 * k), 'stroke-width': 2.4 }, g);
    });
    if (s >= 4) T(g, 150, botY + 26, 'লাইগেজ ফাঁক জোড়ে', { fs: 10.5, a: 'middle', w: 600, c: Rl.ink });
    if (s === 1) { T(g, 41, topY - 10, 'প্রাইমার', { fs: 10, a: 'middle', w: 600, c: Rp.ink }); T(g, 220, botY + 22, 'প্রাইমার (RNA)', { fs: 10, a: 'middle', w: 600, c: Rp.ink }); }
    /* লিজেন্ড */
    [[Rold, 'পুরোনো সূত্র'], [Rnew, 'নতুন সূত্র'], [Rp, 'RNA প্রাইমার']].forEach(([R, lab], i) => {
      E('rect', { x: 26 + i * 118, y: 236, width: 18, height: 8, rx: 4, fill: R.c }, g);
      T(g, 48 + i * 118, 244, lab, { fs: 10, w: 560, c: C.mu });
    });
  }
}));

/* ───────── ৩. ট্রান্সক্রিপশন ───────── */
V.transcribe = Object.assign({
  t: 'ট্রান্সক্রিপশন ও স্প্লাইসিং', k: ['2d', 'anim'],
  cap: 'RNA পলিমারেজ প্রোমোটারে বসে DNA খোলে এবং <b>ছাঁচ সূত্র</b> পড়ে mRNA গড়ে — DNA-র A-এর বিপরীতে <b>U</b>। শেষ দুই ধাপে প্রকৃতকোষের প্রক্রিয়াজাতকরণ: ক্যাপ ও পলি-A লেজ যোগ এবং <b>ইন্ট্রন</b> কেটে <b>এক্সন</b> জোড়া।'
}, BK.steps({
  W: 380, H: 250, label: 'ট্রান্সক্রিপশন', dur: 3.4,
  stages: [
    { t: 'সূচনা', en: 'Initiation', d: 'RNA পলিমারেজ ট্রান্সক্রিপশন ফ্যাক্টরের সাহায্যে <b>প্রোমোটার</b> (TATA বক্স) চিনে বসে এবং DNA-র ছোট অংশ খোলে।' },
    { t: 'প্রসারণ', en: 'Elongation', d: 'পলিমারেজ ছাঁচ সূত্র বরাবর এগোয়; নতুন RNA বাড়ে <b>৫′ → ৩′</b> দিকে। পেছনে DNA আবার জোড়া লাগে।' },
    { t: 'সমাপ্তি', en: 'Termination', d: '<b>টার্মিনেটর</b> ক্রমে পৌঁছালে pre-mRNA ও পলিমারেজ DNA থেকে আলাদা হয়।' },
    { t: 'ক্যাপ ও লেজ', en: 'Cap & poly-A', d: '৫′ প্রান্তে <b>৭-মিথাইল গুয়ানোসিন ক্যাপ</b>, ৩′ প্রান্তে <b>পলি-A লেজ</b> যোগ হয়।' },
    { t: 'স্প্লাইসিং', en: 'Splicing', d: '<b>ইন্ট্রন</b> কেটে বাদ, <b>এক্সন</b> জোড়া — পরিণত mRNA নিউক্লিয়ার ছিদ্র দিয়ে সাইটোপ্লাজমে যায়।' }
  ],
  draw(g, C, s, u) {
    const Rd = BK.ramp(9), Rpol = BK.ramp(6), Rr = BK.ramp(2), Rx = BK.ramp(10), Ri = BK.ramp(0), Rcap = BK.ramp(3), Rpro = BK.ramp(8);
    const Y = 70, X0 = 20, X1 = 360;
    if (s <= 2) {
      const px = s === 0 ? 70 : s === 1 ? 70 + 210 * FK.ease(u) : 290 + 40 * FK.ease(u);
      /* DNA — পলিমারেজের জায়গায় খোলা */
      const top = [], bot = [];
      for (let x = X0; x <= X1; x += 5) { const d = Math.abs(x - px) < 26 ? 16 * Math.cos((x - px) / 26 * Math.PI / 2) : 0; top.push(`${x === X0 ? 'M' : 'L'}${x} ${Y - 6 - d}`); bot.push(`${x === X0 ? 'M' : 'L'}${x} ${Y + 6 + d}`); }
      E('path', { d: top.join(''), fill: 'none', stroke: Rd.c, 'stroke-width': 4 }, g);
      E('path', { d: bot.join(''), fill: 'none', stroke: Rd.dk, 'stroke-width': 4 }, g);
      E('rect', { x: 46, y: Y - 14, width: 34, height: 28, rx: 4, fill: FK.alpha(Rpro.c, .25), stroke: FK.alpha(Rpro.dk, .7), 'stroke-dasharray': '3 3' }, g);
      T(g, 63, Y - 20, 'প্রোমোটার', { fs: 9.5, a: 'middle', w: 600, c: Rpro.ink });
      E('rect', { x: 316, y: Y - 14, width: 30, height: 28, rx: 4, fill: FK.alpha(Ri.c, .18), stroke: FK.alpha(Ri.dk, .6), 'stroke-dasharray': '3 3' }, g);
      T(g, 331, Y - 20, 'টার্মিনেটর', { fs: 9.5, a: 'middle', w: 600, c: Ri.ink });
      T(g, X0, Y + 34, 'ছাঁচ সূত্র ৩′ → ৫′', { fs: 9.5, w: 560, c: Rd.ink });
      /* পলিমারেজ */
      E('ellipse', { cx: px, cy: Y, rx: 28, ry: 24, fill: FK.alpha(Rpol.c, .55), stroke: Rpol.dk, 'stroke-width': 1.8 }, g);
      T(g, px, Y + 4, 'RNA Pol', { fs: 9, a: 'middle', w: 700, c: Rpol.ink });
      /* নতুন RNA — পলিমারেজ থেকে নিচে বেরিয়ে আসছে */
      if (s >= 1) {
        const len = Math.max(0, px - 80);
        const d = []; for (let x = 0; x <= len; x += 5) d.push(`${x ? 'L' : 'M'}${px - 10 - x} ${Y + 30 + Math.min(40, x * .3) + 4 * Math.sin(x / 14)}`);
        E('path', { d: d.join(''), fill: 'none', stroke: Rr.c, 'stroke-width': 4, 'stroke-linecap': 'round' }, g);
        T(g, px - 20, Y + 56, 'RNA ৫′ → ৩′', { fs: 10, a: 'end', w: 600, c: Rr.ink });
      }
      /* ক্ষারক জোড়ের উদাহরণ */
      T(g, 190, 186, 'DNA ছাঁচ:  T  A  C  G  A', { fs: 12, a: 'middle', w: 650, c: Rd.ink });
      T(g, 190, 208, 'mRNA     :  A  U  G  C  U', { fs: 12, a: 'middle', w: 650, c: Rr.ink });
      T(g, 190, 232, 'A-এর বিপরীতে U — RNA-তে থাইমিন নেই', { fs: 10, a: 'middle', w: 560, c: C.mu });
    } else {
      /* pre-mRNA: ক্যাপ – এক্সন১ – ইন্ট্রন – এক্সন২ – ইন্ট্রন – এক্সন৩ – লেজ */
      const segs = [['e', 'এক্সন ১', 70], ['i', 'ইন্ট্রন', 50], ['e', 'এক্সন ২', 60], ['i', 'ইন্ট্রন', 44], ['e', 'এক্সন ৩', 60]];
      const k = s === 4 ? FK.ease(u) : 0;
      let x = 58;
      const Y2 = 110;
      if (s >= 3) { const a = s === 3 ? FK.ease(u) : 1; E('circle', { cx: x - 14, cy: Y2, r: 10, fill: Rcap.c, opacity: a }, g); T(g, x - 14, Y2 - 18, 'ক্যাপ', { fs: 10, a: 'middle', w: 600, c: Rcap.ink }); }
      segs.forEach(([kind, lab, w]) => {
        if (kind === 'i') {
          const wv = w * (1 - k);
          if (wv > 2) { E('path', { d: `M${x} ${Y2}q${wv / 2} ${-40 * k - 4} ${wv} 0`, fill: 'none', stroke: Ri.c, 'stroke-width': 6, opacity: 1 - k * .7 }, g); if (k < .6) T(g, x + wv / 2, Y2 + 22, lab, { fs: 9.5, a: 'middle', w: 600, c: Ri.ink }); }
          x += wv;
        } else {
          E('rect', { x, y: Y2 - 7, width: w, height: 14, rx: 4, fill: Rx.c }, g);
          T(g, x + w / 2, Y2 + 24, lab, { fs: 9.5, a: 'middle', w: 600, c: Rx.ink });
          x += w;
        }
      });
      if (s >= 3) { const a = s === 3 ? FK.ease(u) : 1; E('path', { d: `M${x} ${Y2}h${34 * a}`, stroke: BK.ramp(8).c, 'stroke-width': 6, 'stroke-dasharray': '4 2' }, g); T(g, x + 18, Y2 - 14, 'পলি-A', { fs: 10, a: 'middle', w: 600, c: BK.ramp(8).ink }); }
      T(g, 190, 40, s === 3 ? 'pre-mRNA-তে ক্যাপ ও লেজ যোগ' : 'ইন্ট্রন বাদ — পরিণত mRNA', { fs: 12, a: 'middle', w: 650, c: C.fg });
      T(g, 190, 196, 'এক্সন থাকে · ইন্ট্রন বাদ যায়', { fs: 11.5, a: 'middle', w: 620, c: C.mu });
      if (s === 4) T(g, 190, 222, 'বিকল্প স্প্লাইসিংয়ে একই জিন থেকে একাধিক প্রোটিন', { fs: 10, a: 'middle', w: 560, c: C.mu });
    }
  }
}));

/* ───────── ৪. ট্রান্সলেশন ───────── */
V.translate = Object.assign({
  t: 'ট্রান্সলেশন — রাইবোসোমে প্রোটিন তৈরি', k: ['2d', 'anim'],
  cap: 'mRNA ৫′-AUG GCA UGG AAA UGA-৩′ পড়ে রাইবোসোম এগোচ্ছে। tRNA ঢোকে <b>A</b>-সাইটে, শিকল থাকে <b>P</b>-সাইটে, খালি tRNA বেরোয় <b>E</b> দিয়ে। শেষে স্টপ কোডন UGA-তে <b>মুক্তি ফ্যাক্টর</b> বসে এবং পেপটাইড মুক্ত হয়।'
}, BK.steps({
  W: 380, H: 270, label: 'ট্রান্সলেশন', dur: 3.2,
  stages: [
    { t: 'সূচনা', en: 'Initiation', d: 'ছোট উপএকক mRNA-তে বসে <b>AUG</b> খোঁজে; মিথিওনিন-tRNA (অ্যান্টিকোডন UAC) <b>P-সাইটে</b> বসে; বড় উপএকক যুক্ত হয়।' },
    { t: 'দ্বিতীয় tRNA', en: 'Elongation 1', d: 'অ্যালানিন-tRNA (CGU) <b>A-সাইটে</b> ঢোকে; <b>পেপটাইড বন্ধন</b> তৈরি হয় — Met–Ala।' },
    { t: 'স্থানান্তর', en: 'Translocation', d: 'রাইবোসোম এক কোডন সামনে সরে; খালি tRNA <b>E-সাইট</b> দিয়ে বেরোয়; ট্রিপটোফ্যান-tRNA ঢোকে — Met–Ala–Trp।' },
    { t: 'আরও প্রসারণ', en: 'Elongation 2', d: 'লাইসিন যুক্ত হয় — Met–Ala–Trp–Lys। প্রতিটি চক্র: ঢোকো → জোড়ো → সরো।' },
    { t: 'সমাপ্তি', en: 'Termination', d: '<b>UGA</b> স্টপ কোডন A-সাইটে — কোনো tRNA আসে না; <b>মুক্তি ফ্যাক্টর</b> বসে, পেপটাইড মুক্ত হয়, রাইবোসোম ভেঙে যায়।' }
  ],
  draw(g, C, s, u) {
    const Rm = BK.ramp(4), Rsm = BK.ramp(9), Rlg = BK.ramp(5), Rt = BK.ramp(6), Ra = BK.ramp(2), Rrf = BK.ramp(0);
    const cod = ['AUG', 'GCA', 'UGG', 'AAA', 'UGA'], anti = ['UAC', 'CGU', 'ACC', 'UUU', ''], aaN = ['Met', 'Ala', 'Trp', 'Lys'];
    const W = 46, MY = 200, M0 = 72, e = FK.ease(Math.min(1, u * 1.4));
    /* প্রতিটি ধাপে P-সাইট কোন কোডনে (স্থানান্তরের সময় মাঝপথে) */
    const P = [0, 0, e, 1 + e, 3][s];
    const cx = i => M0 + i * W + W / 2;
    /* mRNA */
    E('path', { d: `M${M0 - 50} ${MY}H${M0 + cod.length * W + 20}`, stroke: Rm.dk, 'stroke-width': 4 }, g);
    cod.forEach((c, i) => {
      E('rect', { x: M0 + i * W + 2, y: MY - 1, width: W - 4, height: 20, rx: 4, fill: c === 'UGA' ? FK.alpha(Rrf.c, .85) : FK.alpha(Rm.c, .85) }, g);
      T(g, cx(i), MY + 14, c, { fs: 11, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    });
    T(g, M0 - 54, MY + 14, "৫′", { fs: 10, a: 'end', w: 650, c: C.mu });
    T(g, M0 + cod.length * W + 24, MY + 14, "৩′", { fs: 10, w: 650, c: C.mu });
    /* রাইবোসোম: E | P | A — বাঁ কিনারা P-এর আগের কোডনে */
    const RX = M0 + (P - 1) * W;
    E('rect', { x: RX - 4, y: MY - 6, width: W * 3 + 8, height: 34, rx: 16, fill: FK.alpha(Rsm.c, .3), stroke: Rsm.dk, 'stroke-width': 1.6 }, g);
    E('path', { d: `M${RX - 6} ${MY - 8}Q${RX - 6} ${MY - 100} ${RX + W * 1.5} ${MY - 100}Q${RX + W * 3 + 6} ${MY - 100} ${RX + W * 3 + 6} ${MY - 8}Z`, fill: FK.alpha(Rlg.c, .2), stroke: Rlg.dk, 'stroke-width': 1.6 }, g);
    ['E', 'P', 'A'].forEach((lab, i) => {
      E('path', { d: `M${RX + (i + 1) * W} ${MY - 86}V${MY - 8}`, stroke: FK.alpha(Rlg.dk, i < 2 ? .25 : 0), 'stroke-width': 1, 'stroke-dasharray': '3 3' }, g);
      T(g, RX + i * W + W / 2, MY - 84, lab, { fs: 12, a: 'middle', w: 700, c: Rlg.ink });
    });
    /* tRNA */
    const tRNA = (x, an, a) => {
      if (a <= 0.02) return;
      E('path', { d: `M${x - 9} ${MY - 6}V${MY - 44}L${x - 16} ${MY - 54}M${x + 9} ${MY - 6}V${MY - 44}L${x + 16} ${MY - 54}`, fill: 'none', stroke: FK.alpha(Rt.dk, a), 'stroke-width': 3 }, g);
      E('rect', { x: x - 17, y: MY - 21, width: 34, height: 14, rx: 3, fill: FK.alpha(Rt.c, a) }, g);
      T(g, x, MY - 10, an, { fs: 9, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    };
    /* শিকল আঁকা: শেষ অ্যামিনো অ্যাসিড x-এর tRNA-র মাথায়, বাকিগুলো উপরে-বাঁয়ে */
    const chain = (x, n, lift) => {
      for (let j = 0; j < n; j++) {
        const k = n - 1 - j, X2 = x - k * 26 - lift, Y2 = MY - 66 - k * 10 - lift * .9;
        if (j < n - 1) E('path', { d: `M${X2} ${Y2}L${X2 + 26} ${Y2 + 10}`, stroke: Ra.dk, 'stroke-width': 2.2 }, g);
        E('circle', { cx: X2, cy: Y2, r: 12.5, fill: Ra.c, stroke: Ra.dk, 'stroke-width': 1.4 }, g);
        T(g, X2, Y2 + 4, aaN[j], { fs: 8.5, a: 'middle', w: 700, c: Ra.ink });
      }
    };
    let n = 1;
    if (s === 0) { tRNA(cx(0), anti[0], 1); chain(cx(0), 1, 0); }
    if (s === 1) { tRNA(cx(0), anti[0], 1); tRNA(cx(1), anti[1], e); n = e > .6 ? 2 : 1; chain(e > .6 ? cx(1) : cx(0), n, 0);
      if (e > .6) E('circle', { cx: cx(1) - 13, cy: MY - 71, r: 6, fill: 'none', stroke: FK.alpha(C.acc, .8), 'stroke-width': 2 }, g); }
    if (s === 2) { tRNA(cx(0), anti[0], 1 - e); tRNA(cx(1), anti[1], 1); tRNA(cx(2), anti[2], Math.max(0, e * 2 - 1)); n = e > .75 ? 3 : 2; chain(e > .75 ? cx(2) : cx(1), n, 0); }
    if (s === 3) { tRNA(cx(1), anti[1], 1 - e); tRNA(cx(2), anti[2], 1); tRNA(cx(3), anti[3], Math.max(0, e * 2 - 1)); n = e > .75 ? 4 : 3; chain(e > .75 ? cx(3) : cx(2), n, 0); }
    if (s === 4) {
      tRNA(cx(3), anti[3], 1 - e * .8); n = 4;
      E('rect', { x: cx(4) - 18, y: MY - 46, width: 36, height: 40, rx: 8, fill: FK.alpha(Rrf.c, .25 + .5 * e), stroke: Rrf.dk, 'stroke-width': 1.6 }, g);
      T(g, cx(4), MY - 22, 'RF', { fs: 11, a: 'middle', w: 700, c: Rrf.ink });
      T(g, cx(4), MY - 52, 'মুক্তি ফ্যাক্টর', { fs: 9, a: 'middle', w: 600, c: Rrf.ink });
      chain(cx(3), 4, e * 46);
    }
    T(g, 190, 24, aaN.slice(0, n).join(' – ') + (s === 4 ? '  ← মুক্ত পলিপেপটাইড' : ''), { fs: 12.5, a: 'middle', w: 650, c: Ra.ink });
    T(g, 190, 252, 'রাইবোসোম mRNA-তে ৫′ → ৩′ দিকে এক কোডন করে চলে', { fs: 10, a: 'middle', w: 560, c: C.mu });
  }
}));
})();
