/* ═══════════════════════════════════════════════════════════════════
   ১ম পত্র · অধ্যায় ১ · উপ-অধ্যায় ১.৬ — ক্রোমোসোম
   chromo3d     : মেটাফেজ ক্রোমোসোমের ত্রিমাত্রিক মডেল (দুই ক্রোমাটিড,
                  সেন্ট্রোমিয়ার, কাইনেটোকোর, স্পিন্ডল টান, স্যাটেলাইট)
   chromoParts  : ভৌত গঠনের চিহ্নিত চিত্র (লেবেল-কুইজসহ)
   chromoTypes  : সেন্ট্রোমিয়ারের অবস্থান অনুযায়ী চার প্রকার — V/L/J/I
   nucleosome   : DNA → নিউক্লিওজোম → সোলেনয়েড → ক্রোমাটিড, ধাপে ধাপে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, BK = window.BK;

/* ক্রোমাটিডের একটি বাহু: সেন্ট্রোমিয়ার থেকে প্রান্ত পর্যন্ত (z বরাবর, পর্দায় উপর-নিচ) */
const arm = (S, x, z0, len, dir, r, col, op) => {
  const n = 5;
  for (let i = 0; i < n; i++) {
    const a = [x, 0, z0 + dir * len * i / n], b = [x, 0, z0 + dir * len * (i + 1) / n];
    S.cyl(a, b, r * (1 - .14 * i / n), col, Object.assign({ seg: 8 }, op));
  }
};

V.chromo3d = Object.assign({
  t: 'মেটাফেজ ক্রোমোসোম — ত্রিমাত্রিক মডেল', k: ['3d', 'anim', 'int'],
  cap: 'আঙুল দিয়ে ঘুরিয়ে দেখো। দুটি <b>সিস্টার ক্রোমাটিড</b> একটি <b>সেন্ট্রোমিয়ারে</b> যুক্ত; সেন্ট্রোমিয়ারের দুই পাশে <b>কাইনেটোকোর</b>, যেখানে দুই মেরু থেকে আসা স্পিন্ডল তন্তু টান দিচ্ছে। উপরের বাহুতে <b>গৌণ খাঁজ ও স্যাটেলাইট</b>, দুই প্রান্তে <b>টেলোমিয়ার</b>। স্লাইডার টেনে সেন্ট্রোমিয়ারের অবস্থান বদলাও — মেটাসেন্ট্রিক থেকে টেলোসেন্ট্রিক পর্যন্ত আকৃতি বদলে যাবে।',
}, BK.model3d({
  label: 'মেটাফেজ ক্রোমোসোমের ত্রিমাত্রিক মডেল', yaw: -0.5, pitch: 0.18, dist: 22, h: 340,
  ctrl: FK.sl('cp', 'সেন্ট্রোমিয়ারের অবস্থান', 0, 100, 5, 50, '%'),
  wire(root, ctx, S) { FK.bindSl(root, 'cp', v => { ctx.cp = v; S.frame(); }, '%', 0); },
  parts: [
    { id: 'cd', bn: 'সিস্টার ক্রোমাটিড', en: 'Sister chromatids', fn: 'লম্বালম্বিভাবে বিভক্ত দুটি <b>অভিন্ন</b> অর্ধাংশ; ইন্টারফেজের S দশায় DNA রেপ্লিকেশনের ফলে তৈরি হয়। একই সেন্ট্রোমিয়ারে যুক্ত থাকে বলে এদের সিস্টার ক্রোমাটিড বলে। <b>অ্যানাফেজে</b> আলাদা হয়ে বিপরীত মেরুতে যায় এবং তখন প্রতিটি স্বাধীন ক্রোমোসোম হিসেবে গণ্য হয়।' },
    { id: 'cen', bn: 'সেন্ট্রোমিয়ার (মুখ্য খাঁজ)', lb: 'সেন্ট্রোমিয়ার', en: 'Centromere', fn: 'দুই ক্রোমাটিডের সংযোগস্থলে সংকুচিত, <b>রং না নেওয়া</b> অংশ। এটি ক্রোমোসোমকে দুটি বাহুতে ভাগ করে এবং এর অবস্থান দিয়েই প্রকারভেদ ঠিক হয়। সেন্ট্রোমিয়ার না থাকলে ক্রোমোসোম স্পিন্ডলের টান পায় না ও হারিয়ে যায়।' },
    { id: 'kin', bn: 'কাইনেটোকোর', en: 'Kinetochore', fn: 'সেন্ট্রোমিয়ারের দুই পাশে অবস্থিত চাকতির মতো <b>প্রোটিন</b> গঠন; প্রতি ক্রোমোসোমে দুটি (প্রতি ক্রোমাটিডে একটি)। এখানেই স্পিন্ডল তন্তু সরাসরি যুক্ত হয়। মেটাফেজের <b>স্পিন্ডল চেকপয়েন্ট</b> পরীক্ষা করে দেখে দুটি কাইনেটোকোরই বিপরীত মেরুতে আটকেছে কি না।' },
    { id: 'sp', bn: 'স্পিন্ডল তন্তু', en: 'Spindle fibre', fn: 'টিউবিউলিন প্রোটিনের তৈরি মাইক্রোটিউবিউল; দুই মেরু থেকে এসে কাইনেটোকোরে লাগে। অ্যানাফেজে ছোট হয়ে ক্রোমাটিড দুটিকে বিপরীত দিকে টেনে নেয়।' },
    { id: 'sec', bn: 'গৌণ খাঁজ ও স্যাটেলাইট', lb: 'গৌণ খাঁজ', en: 'Secondary constriction & satellite', fn: 'বাহুর দ্বিতীয় সংকোচন = <b>গৌণ খাঁজ</b>, যা <b>নিউক্লিওলার অর্গানাইজার</b> — এখানে rRNA-র জিন থাকে ও টেলোফেজে নিউক্লিওলাস গঠিত হয়। এর বাইরের গোলাকার প্রান্ত = <b>স্যাটেলাইট</b>; এমন ক্রোমোসোমকে <b>SAT-ক্রোমোসোম</b> বলে।' },
    { id: 'tel', bn: 'টেলোমিয়ার', en: 'Telomere', fn: 'দুই প্রান্তের বিশেষ ক্রম (মানুষে <b>TTAGGG</b>-এর পুনরাবৃত্তি)। প্রান্তকে ক্ষয়, ভাঙা ও পরস্পর জোড়া লাগা থেকে রক্ষা করে — জুতার ফিতার প্লাস্টিক মাথার মতো। প্রতি বিভাজনে ছোট হয়; <b>টেলোমারেজ</b> একে লম্বা করে, যা ক্যানসার কোষে অতিসক্রিয় থাকে।' }
  ],
  draw(S, ctx) {
    const C = FK.P(), L = BK.lang;
    const Rc = BK.org('chromatin'), Rk = BK.ramp(6), Rs = BK.ramp(9), Rt = BK.ramp(2), Rsat = BK.ramp(8);
    const dim = id => (ctx.sel && ctx.sel !== id) ? .16 : 1;
    /* স্লাইডার: ১০০ = সেন্ট্রোমিয়ার মাঝে, ০ = একেবারে প্রান্তে */
    const p = (ctx.cp == null ? 50 : ctx.cp) / 100;
    const TOT = 8.6, up = TOT * (.10 + .40 * p), dn = TOT - up;
    const dx = 1.05, R = .62, zc = (dn - up) / 2;   /* ছবির মাঝে বসানোর জন্য সরানো */

    /* দুই সিস্টার ক্রোমাটিড — x = ±dx, বাহু z বরাবর */
    [-1, 1].forEach(s => {
      const x = s * dx;
      if (up > .9) arm(S, x, zc + .45, up - .45, 1, R, Rc.c, { id: 'cd', a: dim('cd') });
      arm(S, x, zc - .45, dn - .45, -1, R, Rc.c, { id: 'cd', a: dim('cd') });
      S.sphere([x, 0, zc + up], R * .95, Rt.c, { id: 'tel', a: dim('tel') });
      S.sphere([x, 0, zc - dn], R * .95, Rt.c, { id: 'tel', a: dim('tel') });
    });

    /* সেন্ট্রোমিয়ার — দুই ক্রোমাটিডকে জোড়া সরু সংকোচন */
    S.cyl([-dx, 0, zc + .16], [dx, 0, zc + .16], .34, Rc.dk, { id: 'cen', a: dim('cen'), seg: 8 });
    S.cyl([-dx, 0, zc - .16], [dx, 0, zc - .16], .34, Rc.dk, { id: 'cen', a: dim('cen'), seg: 8 });

    /* কাইনেটোকোর — প্রতিটি ক্রোমাটিডের বাইরের দিকে চাকতি */
    [-1, 1].forEach(s => S.disc([s * (dx + .5), 0, zc], [1, 0, 0], .52, .26, Rk.c, { id: 'kin', a: dim('kin'), seg: 12 }));

    /* স্পিন্ডল তন্তু — দুই মেরু থেকে কাইনেটোকোরে; অ্যানাফেজের টান বোঝাতে স্পন্দিত */
    const t = ctx.t || 0, pull = .5 + .5 * Math.sin(t * 1.7);
    [-1, 1].forEach(s => {
      const px = s * (6.2 + .5 * pull);
      [-1, 0, 1].forEach(k => S.line([s * (dx + .6), k * .34, zc + k * .34], [px, k * .9, zc + k * .9], Rs.c, { w: 1.5, a: dim('sp') * .85 }));
      S.sphere([px + s * .4, 0, zc], .32, Rs.dk, { id: 'sp', a: dim('sp') });
    });

    /* গৌণ খাঁজ ও স্যাটেলাইট — উপরের বাহু যথেষ্ট লম্বা হলে */
    if (up > 3.2) {
      const gz = zc + up - 1.35;
      [-1, 1].forEach(s => {
        S.cyl([s * dx, 0, gz - .16], [s * dx, 0, gz + .16], .28, Rc.c, { id: 'sec', a: dim('sec'), seg: 7 });
        S.sphere([s * dx, 0, zc + up - .3], R * .8, Rsat.c, { id: 'sec', a: dim('sec') });
      });
    }

    if (L !== 'off') {
      const side = (d, z, txt, col) => S.text([d * 3.4 * Math.cos(S.yaw), d * 3.4 * Math.sin(S.yaw), z], txt, col, { size: 11, bold: true });
      side(-1, zc - 1.2, L === 'en' ? 'Centromere' : 'সেন্ট্রোমিয়ার', Rc.ink);
      side(1, zc + 1.4, L === 'en' ? 'Kinetochore' : 'কাইনেটোকোর', Rk.ink);
      if (up > 3.2) side(1, zc + up - .4, L === 'en' ? 'Satellite' : 'স্যাটেলাইট', Rsat.ink);
      S.text([0, 0, zc - dn - 1.3], L === 'en' ? 'telomere' : 'টেলোমিয়ার', Rt.ink, { size: 10.5, bold: true });
      const nm = p > .78 ? 'মেটাসেন্ট্রিক (V)' : p > .45 ? 'সাবমেটাসেন্ট্রিক (L)' : p > .12 ? 'অ্যাক্রোসেন্ট্রিক (J)' : 'টেলোসেন্ট্রিক (I)';
      const en = p > .78 ? 'Metacentric (V)' : p > .45 ? 'Submetacentric (L)' : p > .12 ? 'Acrocentric (J)' : 'Telocentric (I)';
      S.text([0, 0, zc + up + 1.6], L === 'en' ? en : nm, C.mu, { size: 11.5, bold: true });
    }
  }
}));
})();

/* ───────── ২. ক্রোমোসোমের ভৌত গঠন — চিহ্নিত চিত্র ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;

V.chromoParts = Object.assign({
  t: 'ক্রোমোসোমের ভৌত গঠন', k: ['2d', 'anim', 'int', 'game'],
  cap: 'গ অংশে সবচেয়ে বেশি আসা চিত্রটি। <b>লেবেল-কুইজ</b> চেপে নিজেকে যাচাই করো — পরীক্ষায় এই অংশগুলোই চিহ্নিত করতে হবে। লক্ষ করো সেন্ট্রোমিয়ার <b>সংকুচিত</b> ও রং নেয় না, আর স্যাটেলাইট থাকে <b>গৌণ খাঁজের বাইরে</b>।'
}, BK.diagram({
  W: 380, H: 330, label: 'ক্রোমোসোমের ভৌত গঠন',
  art(g, C, part) {
    const svg = g.ownerSVGElement;
    const Rc = BK.org('chromatin'), Rk = BK.ramp(6), Rt = BK.ramp(2), Rs = BK.ramp(8), Rm = BK.ramp(5), Rn = BK.ramp(9);
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const CY = 150, W = 20, GAP = 7;          /* সেন্ট্রোমিয়ারের y, ক্রোমাটিডের পুরুত্ব, মাঝের ফাঁক */
    const XL = 190 - GAP - W, XR = 190 + GAP; /* দুই ক্রোমাটিডের বাঁ কিনারা */
    const TOP = 52, BOT = 288, GY = 92;       /* উপরের ও নিচের প্রান্ত, গৌণ খাঁজের y */

    /* ম্যাট্রিক্স ও পেলিকল — ক্রোমাটিডের চারপাশে আবছা খাপ */
    const mx = P('mx');
    [XL, XR].forEach(x => E('rect', { x: x - 4, y: TOP - 4, width: W + 8, height: BOT - TOP + 8, rx: 13, fill: FK.alpha(Rm.c, .16), stroke: FK.alpha(Rm.dk, .45), 'stroke-width': 1.1, 'stroke-dasharray': '4 3' }, mx));

    /* দুই ক্রোমাটিড */
    const cd = P('cd');
    [XL, XR].forEach(x => {
      E('rect', { x, y: TOP, width: W, height: GY - 10 - TOP, rx: 9, fill: BK.lg(svg, Rc.lt, Rc.c, { a: 100 }), stroke: Rc.dk, 'stroke-width': 1.5 }, cd);           /* গৌণ খাঁজের উপরের টুকরা = স্যাটেলাইট-বাহু */
      E('rect', { x, y: GY + 10, width: W, height: CY - 16 - (GY + 10), rx: 9, fill: BK.lg(svg, Rc.lt, Rc.c, { a: 100 }), stroke: Rc.dk, 'stroke-width': 1.5 }, cd);  /* p বাহুর বাকি অংশ */
      E('rect', { x, y: CY + 16, width: W, height: BOT - (CY + 16), rx: 9, fill: BK.lg(svg, Rc.lt, Rc.c, { a: 100 }), stroke: Rc.dk, 'stroke-width': 1.5 }, cd);      /* q বাহু */
      for (let y = TOP + 16; y < BOT - 8; y += 22) { if (Math.abs(y - CY) < 22 || Math.abs(y - GY) < 14) continue;
        E('path', { d: `M${x + 3} ${y}h${W - 6}`, stroke: FK.alpha(Rc.dk, .38), 'stroke-width': 1.2 }, cd); }
    });

    /* সেন্ট্রোমিয়ার — সংকুচিত, রং নেয় না */
    const cen = P('cen');
    E('path', { d: `M${XL} ${CY - 16}q${W / 2} 16 0 32M${XL + W} ${CY - 16}q${-W / 2} 16 0 32M${XR} ${CY - 16}q${W / 2} 16 0 32M${XR + W} ${CY - 16}q${-W / 2} 16 0 32`, fill: 'none', stroke: Rc.dk, 'stroke-width': 1.5 }, cen);
    E('rect', { x: XL + 5, y: CY - 7, width: (XR + W) - (XL + 5) - 5, height: 14, rx: 6, fill: C.sf, stroke: Rc.dk, 'stroke-width': 1.4 }, cen);

    /* কাইনেটোকোর — দুই পাশে চাকতি */
    const kin = P('kin');
    [[XL - 7, -1], [XR + W + 7, 1]].forEach(([x, s]) => {
      E('ellipse', { cx: x, cy: CY, rx: 6, ry: 11, fill: Rk.c, stroke: Rk.dk, 'stroke-width': 1.3 }, kin);
      for (let k = -1; k <= 1; k++) E('path', { d: `M${x + s * 5} ${CY + k * 6}L${x + s * 46} ${CY + k * 26}`, stroke: FK.alpha(Rn.c, .75), 'stroke-width': 1.5 }, kin);
    });
    T(g, 190, CY + 46, 'স্পিন্ডল তন্তু দুই মেরুর দিকে টানে', { fs: 9.5, a: 'middle', w: 520, c: C.mu });

    /* গৌণ খাঁজ ও স্যাটেলাইট */
    const sec = P('sec');
    [XL, XR].forEach(x => {
      E('path', { d: `M${x} ${GY - 10}q${W / 2} 10 0 20M${x + W} ${GY - 10}q${-W / 2} 10 0 20`, fill: 'none', stroke: Rc.dk, 'stroke-width': 1.4 }, sec);
      E('rect', { x: x + 5, y: GY - 4, width: W - 10, height: 8, rx: 4, fill: C.sf, stroke: Rc.dk, 'stroke-width': 1.2 }, sec);
    });
    const sat = P('sat');
    [XL, XR].forEach(x => E('circle', { cx: x + W / 2, cy: TOP + 17, r: 8.5, fill: Rs.c, stroke: Rs.dk, 'stroke-width': 1.4 }, sat));

    /* টেলোমিয়ার — দুই প্রান্তের টুপি */
    const tel = P('tel');
    [XL, XR].forEach(x => {
      E('rect', { x: x + 2, y: TOP - 1, width: W - 4, height: 7, rx: 3.5, fill: Rt.c }, tel);
      E('rect', { x: x + 2, y: BOT - 6, width: W - 4, height: 7, rx: 3.5, fill: Rt.c }, tel);
    });

    /* বাহু চিহ্নিত করার বন্ধনী */
    const armg = P('arm');
    E('path', { d: `M${XL - 26} ${TOP}v${CY - 20 - TOP}`, stroke: FK.alpha(C.mu, .8), 'stroke-width': 1.3 }, armg);
    E('path', { d: `M${XL - 26} ${CY + 20}v${BOT - CY - 20}`, stroke: FK.alpha(C.mu, .8), 'stroke-width': 1.3 }, armg);
    T(armg, XL - 31, (TOP + CY) / 2, 'p', { fs: 13, a: 'end', w: 650, c: C.mu });
    T(armg, XL - 31, (CY + BOT) / 2, 'q', { fs: 13, a: 'end', w: 650, c: C.mu });

    T(g, 190, 318, 'ছোট বাহু = p · বড় বাহু = q · সেন্ট্রোমিয়ার রং নেয় না', { fs: 10.5, a: 'middle', w: 520, c: C.mu });
  },
  /* ক্রোমোনেমার কুণ্ডলী ভেতরে ঘুরছে; স্পিন্ডলের টান স্পন্দিত */
  idle(g, C, t) {
    const Rc = BK.org('chromatin'), Rn = BK.ramp(9);
    const XL = 163, XR = 197, W = 20, CY = 150;
    [XL, XR].forEach((x, i) => {
      const d = [];
      for (let y = 60; y < 284; y += 4) {
        const ph = t * 1.6 + (i ? Math.PI : 0) + y * .1;
        d.push(`${y === 60 ? 'M' : 'L'}${x + W / 2 + Math.sin(ph) * 5} ${y}`);
      }
      E('path', { d: d.join(''), fill: 'none', stroke: FK.alpha(Rc.dk, .45), 'stroke-width': 1.4 }, g);
    });
    const pull = .5 + .5 * Math.sin(t * 1.8);
    [[-1, 128], [1, 252]].forEach(([s, x]) => BK.arrow(g, x + s * 6, CY, x + s * (16 + pull * 10), CY, FK.alpha(Rn.dk, .5 + pull * .4), 2));
    T(g, 190, 30, 'ক্রোমোনেমা ভেতরে পেঁচিয়ে আছে', { fs: 10, a: 'middle', w: 520, c: C.mu });
  },
  parts: [
    { id: 'cd', bn: 'ক্রোমাটিড', en: 'Chromatid', fn: 'লম্বালম্বিভাবে বিভক্ত দুটি <b>অভিন্ন</b> অর্ধাংশ; একই সেন্ট্রোমিয়ারে যুক্ত বলে <b>সিস্টার ক্রোমাটিড</b>। S দশার রেপ্লিকেশনে তৈরি হয় এবং অ্যানাফেজে আলাদা হয়ে দুই মেরুতে যায়।', a: [206, 220], l: [300, 250], an: 'end' },
    { id: 'cen', bn: 'সেন্ট্রোমিয়ার (মুখ্য খাঁজ)', lb: 'সেন্ট্রোমিয়ার', en: 'Centromere', fn: 'দুই ক্রোমাটিডের সংযোগস্থলে সংকুচিত, <b>রং না নেওয়া</b> অংশ। ক্রোমোসোমকে দুটি বাহুতে ভাগ করে এবং এর অবস্থান দিয়েই প্রকারভেদ (মেটা/সাব/অ্যাক্রো/টেলো) নির্ধারিত হয়।', a: [190, 150], l: [300, 150], an: 'end' },
    { id: 'kin', bn: 'কাইনেটোকোর', en: 'Kinetochore', fn: 'সেন্ট্রোমিয়ারের দুই পাশে চাকতির মতো <b>প্রোটিন</b> গঠন (প্রতি ক্রোমোসোমে দুটি)। এখানেই <b>স্পিন্ডল তন্তু</b> যুক্ত হয়ে ক্রোমোসোমকে টানে।', a: [156, 150], l: [76, 118] },
    { id: 'sec', bn: 'গৌণ খাঁজ', en: 'Secondary constriction', fn: 'বাহুর দ্বিতীয় সংকোচন; এটিই <b>নিউক্লিওলার অর্গানাইজার</b> — এখানে rRNA-র জিন থাকে এবং টেলোফেজে নিউক্লিওলাস গঠিত হয়।', a: [168, 92], l: [66, 70] },
    { id: 'sat', bn: 'স্যাটেলাইট', en: 'Satellite', fn: 'গৌণ খাঁজের বাইরের গোলাকার প্রান্তীয় অংশ। স্যাটেলাইটযুক্ত ক্রোমোসোমকে <b>SAT-ক্রোমোসোম</b> বলে; মানুষের ২১ ও ২২ নম্বরসহ পাঁচ জোড়ায় এটি থাকে।', a: [207, 69], l: [300, 46], an: 'end' },
    { id: 'tel', bn: 'টেলোমিয়ার', en: 'Telomere', fn: 'দুই প্রান্তের বিশেষ ক্রম (মানুষে <b>TTAGGG</b>-এর পুনরাবৃত্তি)। প্রান্তকে ক্ষয় ও পরস্পর জোড়া লাগা থেকে রক্ষা করে; প্রতি বিভাজনে ছোট হয় বলে এটি কোষীয় বার্ধক্যের সাথে জড়িত।', a: [173, 286], l: [70, 300] },
    { id: 'arm', bn: 'বাহু (p ও q)', lb: 'বাহু', en: 'Arms', fn: 'সেন্ট্রোমিয়ারের দুই পাশের অংশ — <b>ছোটটি p</b> এবং <b>বড়টি q</b> বাহু। দুই বাহুর দৈর্ঘ্যের অনুপাত দেখেই ক্রোমোসোম শনাক্ত ও শ্রেণিবদ্ধ করা হয়।', a: [137, 210], l: [66, 240] },
    { id: 'mx', bn: 'ম্যাট্রিক্স ও পেলিকল', lb: 'ম্যাট্রিক্স', en: 'Matrix & pellicle', fn: 'ক্রোমোনেমাকে ঘিরে থাকা জেলির মতো অপ্রোটিন বস্তু = <b>ম্যাট্রিক্স</b>; তার বাইরের পাতলা আবরণ = <b>পেলিকল</b>। দুটিই রং গ্রহণ করে না।', a: [220, 120], l: [310, 100], an: 'end' }
  ]
}));
})();

/* ───────── ৩. সেন্ট্রোমিয়ারের অবস্থান অনুযায়ী চার প্রকার ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

V.chromoTypes = Object.assign({
  t: 'সেন্ট্রোমিয়ারের অবস্থান অনুযায়ী চার প্রকার', k: ['2d', 'anim'],
  cap: 'সেন্ট্রোমিয়ার মাঝ থেকে প্রান্তের দিকে সরতে থাকলে আকৃতি বদলায় <b>V → L → J → I</b>। চালিয়ে দেখো — অ্যানাফেজে স্পিন্ডলের টানে প্রতিটি কেমন আকৃতি নেয় তা ধাপে ধাপে দেখানো হয়েছে।'
}, BK.steps({
  W: 360, H: 272, label: 'ক্রোমোসোমের চার প্রকার', dur: 3.2,
  stages: [
    { t: 'মেটাসেন্ট্রিক', en: 'Metacentric', d: 'সেন্ট্রোমিয়ার <b>ঠিক মাঝখানে</b>; দুটি বাহু সমান দৈর্ঘ্যের। অ্যানাফেজে স্পিন্ডলের টানে দুই বাহু পিছিয়ে পড়ে <b>V</b> আকৃতি নেয়।' },
    { t: 'সাবমেটাসেন্ট্রিক', en: 'Submetacentric', d: 'সেন্ট্রোমিয়ার মাঝ থেকে <b>সামান্য সরে</b>; একটি বাহু কিছুটা ছোট। অ্যানাফেজে <b>L</b> আকৃতি। মানুষের বেশিরভাগ ক্রোমোসোম এই ধরনের।' },
    { t: 'অ্যাক্রোসেন্ট্রিক', en: 'Acrocentric', d: 'সেন্ট্রোমিয়ার <b>প্রান্তের খুব কাছে</b>; একটি বাহু খুব ছোট, অন্যটি খুব বড়। আকৃতি <b>J</b>। মানুষের ১৩, ১৪, ১৫, ২১ ও ২২ নম্বর — এই পাঁচ জোড়া অ্যাক্রোসেন্ট্রিক এবং এদেরই স্যাটেলাইট থাকে।' },
    { t: 'টেলোসেন্ট্রিক', en: 'Telocentric', d: 'সেন্ট্রোমিয়ার <b>একেবারে প্রান্তে</b>; একটিমাত্র বাহু থাকে। আকৃতি <b>I</b> বা দণ্ডাকার। মানুষে স্বাভাবিকভাবে এই ধরন থাকে না।' }
  ],
  draw(g, C, s, u) {
    const Rc = BK.org('chromatin'), Rk = BK.ramp(6), Rn = BK.ramp(9), Rg = BK.ramp(10);
    const frac = [.50, .32, .12, .0][s];                 /* উপরের বাহুর অনুপাত */
    const letter = ['V', 'L', 'J', 'I'][s];
    const CX = 150, TOTAL = 150, TOPY = 62, W = 17;
    const up = TOTAL * frac, dn = TOTAL - up, cy = TOPY + up;
    const bend = FK.ease(Math.min(1, u * 1.3)) * 26;      /* অ্যানাফেজের টানে বাহু পিছিয়ে পড়া */

    /* দুই ক্রোমাটিড, বাহু টানের সাথে বেঁকে যায় */
    [-1, 1].forEach(sd => {
      const x = CX + sd * 13;
      if (up > 6) E('path', { d: `M${x} ${cy}Q${x + sd * bend * .5} ${cy - up * .6} ${x + sd * bend} ${TOPY}`, fill: 'none', stroke: Rc.c, 'stroke-width': W, 'stroke-linecap': 'round' }, g);
      E('path', { d: `M${x} ${cy}Q${x + sd * bend * .35} ${cy + dn * .6} ${x + sd * bend * .7} ${TOPY + TOTAL}`, fill: 'none', stroke: Rc.c, 'stroke-width': W, 'stroke-linecap': 'round' }, g);
    });
    /* সেন্ট্রোমিয়ার */
    E('rect', { x: CX - 20, y: cy - 6, width: 40, height: 12, rx: 5, fill: C.sf, stroke: Rc.dk, 'stroke-width': 1.6 }, g);
    E('ellipse', { cx: CX - 26, cy, rx: 5, ry: 9, fill: Rk.c, stroke: Rk.dk, 'stroke-width': 1.2 }, g);
    E('ellipse', { cx: CX + 26, cy, rx: 5, ry: 9, fill: Rk.c, stroke: Rk.dk, 'stroke-width': 1.2 }, g);
    /* স্পিন্ডলের টান */
    [-1, 1].forEach(sd => BK.arrow(g, CX + sd * 32, cy, CX + sd * (46 + bend), cy, FK.alpha(Rn.dk, .75), 2));

    /* ডান পাশে বড় করে আকৃতির অক্ষর */
    T(g, 302, cy + 12, letter, { fs: 44, a: 'middle', w: 700, c: FK.alpha(Rg.c, .5) });
    T(g, 302, cy + 34, 'আকৃতি', { fs: 10, a: 'middle', w: 520, c: C.mu });

    /* বাঁ পাশে সেন্ট্রোমিয়ারের অবস্থান স্কেল */
    E('path', { d: `M46 ${TOPY}v${TOTAL}`, stroke: FK.alpha(C.mu, .5), 'stroke-width': 1.4 }, g);
    E('circle', { cx: 46, cy, r: 5.5, fill: Rc.dk }, g);
    T(g, 40, TOPY + 4, 'প্রান্ত', { fs: 9.5, a: 'end', w: 520, c: C.mu });
    T(g, 40, TOPY + TOTAL / 2, 'মাঝ', { fs: 9.5, a: 'end', w: 520, c: C.mu });
    T(g, 40, TOPY + TOTAL + 4, 'প্রান্ত', { fs: 9.5, a: 'end', w: 520, c: C.mu });

    T(g, 180, 30, ['সেন্ট্রোমিয়ার মাঝখানে — দুই বাহু সমান', 'সামান্য সরে — এক বাহু ছোট', 'প্রান্তের কাছে — এক বাহু খুব ছোট', 'একেবারে প্রান্তে — একটিই বাহু'][s], { fs: 11, a: 'middle', w: 560, c: Rc.ink });
    T(g, 180, 262, 'মনে রাখো: মাঝে V · সরলে L · প্রান্তে J · একেবারে প্রান্তে I', { fs: 10.5, a: 'middle', w: 520, c: C.mu });
  }
}));

/* ───────── ৪. নিউক্লিওজোম ও DNA প্যাকিংয়ের সিঁড়ি ───────── */
V.nucleosome = Object.assign({
  t: 'নিউক্লিওজোম — DNA কীভাবে ১০,০০০ গুণ ছোট হয়', k: ['2d', 'anim'],
  cap: 'প্রায় <b>২ মিটার</b> DNA কীভাবে ৫–১০ μm নিউক্লিয়াসে এঁটে যায় — ছয়টি ধাপে দেখানো হলো। প্রতিটি ধাপে ব্যাস কত তা লক্ষ করো: <b>2 → 11 → 30 → 300 → 700 → 1400 nm</b>। দ্বিতীয় ধাপেই নিউক্লিওজোম — ১৪৬ bp DNA হিস্টোন অষ্টককে ১¾ বার পেঁচায়।'
}, BK.steps({
  W: 360, H: 282, label: 'DNA প্যাকিংয়ের ধাপ', dur: 3.4,
  stages: [
    { t: 'DNA দ্বৈত হেলিক্স', en: 'DNA double helix', d: 'নগ্ন DNA সূত্র, ব্যাস <b>2 nm</b>। মানুষের এক কোষের সব DNA সোজা করলে দৈর্ঘ্য প্রায় <b>২ মিটার</b>।' },
    { t: 'নিউক্লিওজোম', en: 'Nucleosome', d: '<b>১৪৬ bp</b> DNA হিস্টোন অষ্টককে (H2A, H2B, H3, H4 — দুটি করে) প্রায় <b>১¾ বার</b> পেঁচায়। দুই নিউক্লিওজোমের মাঝে ≈৫০ bp লিংকার DNA, যাতে <b>H1</b> বসে। দেখতে "সুতোয় গাঁথা পুঁতির মালা" — ব্যাস <b>11 nm</b>। (কর্নবার্গ, ১৯৭৪)' },
    { t: 'সোলেনয়েড', en: 'Solenoid', d: 'পুঁতির মালা নিজেই পাক খেয়ে <b>30 nm</b> ব্যাসের কুণ্ডলী তৈরি করে; প্রতি পাকে প্রায় ৬টি নিউক্লিওজোম। H1 হিস্টোন এই পাক ধরে রাখে।' },
    { t: 'লুপ', en: 'Looped domain', d: 'সোলেনয়েড নন-হিস্টোন প্রোটিনের কাঠামোয় আটকে বড় বড় লুপ তৈরি করে — ব্যাস প্রায় <b>300 nm</b>।' },
    { t: 'কুণ্ডলী', en: 'Coiled fibre', d: 'লুপগুলো আরও পাক খেয়ে <b>700 nm</b> পুরু তন্তু গঠন করে। এ পর্যায়ে জিন আর পড়া যায় না।' },
    { t: 'মেটাফেজ ক্রোমাটিড', en: 'Metaphase chromatid', d: 'সবশেষে <b>1400 nm</b> পুরু ক্রোমাটিড — মোট সংকোচন প্রায় <b>১০,০০০ গুণ</b>। এখন DNA নিরাপদে বহনযোগ্য, কিন্তু জিন নিষ্ক্রিয়।' }
  ],
  draw(g, C, s, u) {
    const Rd = BK.base('A'), Rh = BK.ramp(4), Rl = BK.ramp(6), Rc = BK.org('chromatin'), Rn = BK.ramp(9);
    const MY = 128;
    const dash = (x0, x1, y, col, w) => E('path', { d: `M${x0} ${y}H${x1}`, stroke: col, 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round' }, g);

    if (s === 0) {                                    /* দ্বৈত হেলিক্স */
      [1, -1].forEach(sd => {
        const d = [];
        for (let x = 30; x <= 330; x += 5) d.push(`${x === 30 ? 'M' : 'L'}${x} ${MY + sd * 13 * Math.sin((x - 30) / 20 + u * 2)}`);
        E('path', { d: d.join(''), fill: 'none', stroke: Rd.c, 'stroke-width': 3 }, g);
      });
      for (let x = 36; x < 330; x += 12) {
        const y1 = MY + 13 * Math.sin((x - 30) / 20 + u * 2), y2 = MY - 13 * Math.sin((x - 30) / 20 + u * 2);
        E('path', { d: `M${x} ${y1}L${x} ${y2}`, stroke: FK.alpha(Rd.dk, .5), 'stroke-width': 1.3 }, g);
      }
      T(g, 180, 198, 'ব্যাস 2 nm · দৈর্ঘ্য প্রায় ২ মিটার', { fs: 11.5, a: 'middle', w: 560, c: Rd.ink });
    }
    if (s === 1) {                                    /* নিউক্লিওজোম — পুঁতির মালা */
      dash(24, 336, MY, FK.alpha(Rd.c, .9), 2.6);
      for (let i = 0; i < 4; i++) {
        const cx = 66 + i * 76, r = 21;
        E('circle', { cx, cy: MY, r, fill: BK.rg(g.ownerSVGElement, Rh.lt, Rh.c), stroke: Rh.dk, 'stroke-width': 1.6 }, g);
        /* DNA-র ১¾ পাক */
        for (let k = 0; k < 2; k++) E('ellipse', { cx, cy: MY, rx: r + 3 - k * 2, ry: r - 3 - k * 2, fill: 'none', stroke: Rd.c, 'stroke-width': 2.4, transform: `rotate(${-18 + k * 14} ${cx} ${MY})` }, g);
        /* H1 — লিংকারে */
        if (i < 3) E('circle', { cx: cx + 38, cy: MY - 11, r: 7, fill: Rl.c, stroke: Rl.dk, 'stroke-width': 1.3 }, g);
        if (i === 0) { T(g, cx, MY - 32, 'হিস্টোন অষ্টক', { fs: 10, a: 'middle', w: 560, c: Rh.ink }); T(g, cx + 38, MY - 24, 'H1', { fs: 10, a: 'middle', w: 620, c: Rl.ink }); }
      }
      T(g, 180, 192, '১৪৬ bp DNA · ১¾ পাক · ব্যাস 11 nm', { fs: 11.5, a: 'middle', w: 560, c: Rh.ink });
      T(g, 180, 212, 'সুতোয় গাঁথা পুঁতির মালা', { fs: 10.5, a: 'middle', w: 520, c: C.mu });
    }
    if (s === 2) {                                    /* সোলেনয়েড */
      for (let i = 0; i < 16; i++) {
        const a = i * .62 + u * .4, x = 62 + i * 15;
        E('circle', { cx: x, cy: MY + 22 * Math.sin(a), r: 11, fill: FK.alpha(Rh.c, .9), stroke: Rh.dk, 'stroke-width': 1.3 }, g);
      }
      E('path', { d: `M50 ${MY}h260`, stroke: FK.alpha(Rd.c, .45), 'stroke-width': 1.6, 'stroke-dasharray': '5 4' }, g);
      T(g, 180, 192, 'প্রতি পাকে ≈৬টি নিউক্লিওজোম · ব্যাস 30 nm', { fs: 11.5, a: 'middle', w: 560, c: Rh.ink });
    }
    if (s === 3) {                                    /* লুপ */
      E('path', { d: `M40 ${MY}H320`, stroke: Rn.dk, 'stroke-width': 3 }, g);
      for (let i = 0; i < 6; i++) {
        const x = 62 + i * 44, sd = i % 2 ? 1 : -1, h = 46 + 10 * Math.sin(u * 3 + i);
        E('path', { d: `M${x} ${MY}q${-14} ${sd * h} ${22} ${sd * h}q${36} 0 ${22} ${-sd * h}`, fill: 'none', stroke: Rh.c, 'stroke-width': 7, 'stroke-linecap': 'round' }, g);
      }
      T(g, 180, 214, 'নন-হিস্টোন প্রোটিনের কাঠামোয় আটকানো লুপ · 300 nm', { fs: 11, a: 'middle', w: 560, c: Rn.ink });
    }
    if (s === 4) {                                    /* কুণ্ডলী */
      const d = [];
      for (let i = 0; i <= 120; i++) { const t2 = i / 120, a = t2 * Math.PI * 7 + u * 1.2;
        d.push(`${i ? 'L' : 'M'}${40 + t2 * 280} ${MY + 34 * Math.sin(a)}`); }
      E('path', { d: d.join(''), fill: 'none', stroke: Rh.c, 'stroke-width': 13, 'stroke-linecap': 'round' }, g);
      E('path', { d: d.join(''), fill: 'none', stroke: FK.alpha(Rh.dk, .5), 'stroke-width': 3 }, g);
      T(g, 180, 198, 'পাকের উপর পাক · 700 nm', { fs: 11.5, a: 'middle', w: 560, c: Rh.ink });
    }
    if (s === 5) {                                    /* মেটাফেজ ক্রোমাটিড */
      [-1, 1].forEach(sd => E('rect', { x: 164 + sd * 22 - 13, y: 54, width: 26, height: 148, rx: 12, fill: BK.lg(g.ownerSVGElement, Rc.lt, Rc.c, { a: 100 }), stroke: Rc.dk, 'stroke-width': 1.6 }, g));
      E('rect', { x: 134, y: MY - 7, width: 60, height: 14, rx: 6, fill: C.sf, stroke: Rc.dk, 'stroke-width': 1.5 }, g);
      T(g, 180, 222, 'মোট সংকোচন প্রায় ১০,০০০ গুণ · 1400 nm', { fs: 11.5, a: 'middle', w: 560, c: Rc.ink });
    }
    T(g, 180, 28, ['2 nm', '11 nm', '30 nm', '300 nm', '700 nm', '1400 nm'][s] + ' — ' + ['নগ্ন DNA', 'নিউক্লিওজোম', 'সোলেনয়েড', 'লুপ', 'কুণ্ডলী', 'ক্রোমাটিড'][s], { fs: 12.5, a: 'middle', w: 620, c: C.fg });
    /* অগ্রগতির সিঁড়ি */
    for (let i = 0; i < 6; i++) E('rect', { x: 110 + i * 24, y: 268 - (6 + i * 2.4), width: 18, height: 6 + i * 2.4, rx: 2, fill: i <= s ? Rc.c : FK.alpha(C.mu, .22) }, g);
  }
}));
})();
