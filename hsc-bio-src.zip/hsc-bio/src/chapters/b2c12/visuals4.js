/* ═══════════════════════════════════════════════════════════════════
   visuals4 — প্রতিবর্তী ক্রিয়া ও সহজাত আবেগ:
   kneeJerk (হাঁটু-ঝাঁকুনি, একসিন্যাপ্সীয়), withdrawalArc (হাত সরিয়ে নেওয়া, লেবেলযুক্ত),
   weaverNest (বাবুই পাখির বাসা), cuckooEject (কোকিল-ছানার ডিম ফেলে দেওয়া)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, TP = B.tp, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const SEN = '#2a6ab0', MOT = '#c0392b', INT = '#7a4aa8';

/* ─── সুষুম্নাকাণ্ডের প্রস্থচ্ছেদ: শ্বেত পদার্থ, প্রজাপতি-আকৃতির ধূসর পদার্থ, কেন্দ্রীয় নালি, পৃষ্ঠমূল ও গ্যাংলিয়ন, অঙ্কমূল ─── */
const cord = (g, cx, cy, s) => { const W = B.TS('wm'), G = B.TS('gm'), N = B.TS('nrv');
  /* মূল: পৃষ্ঠমূল (ওপরে, গ্যাংলিয়নসহ) ও অঙ্কমূল (নিচে) মিলে স্পাইনাল স্নায়ু — ডান দিকে */
  E('path', { d: `M${cx + 26 * s} ${cy - 10 * s}Q${cx + 44 * s} ${cy - 18 * s} ${cx + 58 * s} ${cy - 12 * s}`, stroke: N.dk, 'stroke-width': 6 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: `M${cx + 26 * s} ${cy - 10 * s}Q${cx + 44 * s} ${cy - 18 * s} ${cx + 58 * s} ${cy - 12 * s}`, stroke: N.c, 'stroke-width': 4.4 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: `M${cx + 24 * s} ${cy + 10 * s}Q${cx + 44 * s} ${cy + 14 * s} ${cx + 62 * s} ${cy}`, stroke: N.dk, 'stroke-width': 6 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: `M${cx + 24 * s} ${cy + 10 * s}Q${cx + 44 * s} ${cy + 14 * s} ${cx + 62 * s} ${cy}`, stroke: N.c, 'stroke-width': 4.4 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: B.ellD(cx + 50 * s, cy - 14 * s, 8 * s, 5.4 * s, -10), fill: B.vol(g, 'nrv'), stroke: N.dk, 'stroke-width': .7 }, g);
  E('path', { d: `M${cx + 58 * s} ${cy - 12 * s}Q${cx + 70 * s} ${cy - 6 * s} ${cx + 78 * s} ${cy + 2 * s}M${cx + 62 * s} ${cy}L${cx + 78 * s} ${cy + 2 * s}`, stroke: N.dk, 'stroke-width': 5 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  /* শ্বেত ও ধূসর পদার্থ */
  E('path', { d: B.ellD(cx, cy, 30 * s, 24 * s), fill: B.vol(g, 'wm'), stroke: W.dk, 'stroke-width': .8 }, g);
  E('path', { d: `M${cx} ${cy - 24 * s}V${cy - 10 * s}M${cx} ${cy + 24 * s}V${cy + 12 * s}`, stroke: W.dk, 'stroke-width': .6 }, g);
  const H = [[-4, -4], [-8, -16], [-13, -19], [-12, -12], [-16, -2], [-18, 8], [-14, 16], [-6, 14], [-4, 6], [0, 5], [4, 6], [6, 14], [14, 16], [18, 8], [16, -2], [12, -12], [13, -19], [8, -16], [4, -4], [0, -3]];
  E('path', { d: sm(TP(H, cx, cy, s), true, .55), fill: B.vol(g, 'gm'), stroke: G.dk, 'stroke-width': .7 }, g);
  E('circle', { cx, cy: cy + 1 * s, r: 1.6 * s, fill: '#cfe6f4', stroke: '#7fa9c4', 'stroke-width': .5 }, g);
  return { drg: [cx + 50 * s, cy - 14 * s], dh: [cx + 10 * s, cy - 14 * s], vh: [cx + 13 * s, cy + 10 * s], mid: [cx + 6 * s, cy - 2 * s], out: [cx + 78 * s, cy + 2 * s], vr: [cx + 24 * s, cy + 10 * s], dr: [cx + 26 * s, cy - 10 * s] };
};
B.cord = cord;

/* ─── বসা অবস্থায় পা (ডান দিক থেকে): উরু অনুভূমিক, হাঁটুতে নিম্নপদ ঝোলানো; th = হাঁটুর কোণ (রেডিয়ান, সামনে ছোড়া) ─── */
const leg = (g, th, o = {}) => { const sk = B.TS('skin'), M = B.TS('mus'), K = [262, 178];
  /* উরু */
  E('path', { d: 'M150 150C190 144 236 146 262 158C272 164 274 186 266 196C236 200 190 202 150 200Z', fill: B.vol(g, 'skin'), stroke: sk.dk, 'stroke-width': .8 }, g);
  /* কোয়াড্রিসেপস (ওপরে, ত্বকের নিচে অর্ধস্বচ্ছ) ও হ্যামস্ট্রিং (নিচে) */
  const qc = o.q || 0, hm = o.h || 0;
  E('path', { d: `M156 156C190 ${f1(150 - qc * 3)} 228 ${f1(150 - qc * 3)} 252 162C246 170 220 ${f1(170 + qc)} 158 ${f1(172 + qc)}Z`, fill: FK.alpha(M.c, .72 + qc * .2), stroke: M.dk, 'stroke-width': .6 }, g);
  for (let i = 0; i < 8; i++) E('path', { d: `M${164 + i * 11} ${f1(160 - qc * 2)}l10 ${f1(4 + qc)}`, stroke: FK.alpha(M.dk, .4), 'stroke-width': .5 }, g);
  E('path', { d: 'M160 182C200 184 236 186 256 186C248 194 210 196 160 196Z', fill: FK.alpha(M.c, .45 - hm * .15), stroke: FK.alpha(M.dk, .6), 'stroke-width': .5, 'stroke-dasharray': hm ? '2 2' : null }, g);
  /* মাংসপেশি টাকু (কোয়াড্রিসেপসের ভেতরে) */
  E('path', { d: 'M196 160h22', stroke: '#2a6ab0', 'stroke-width': 3.4, 'stroke-linecap': 'round', opacity: .35 }, g);
  E('path', { d: 'M198 160q2 -3 4 0t4 0t4 0t4 0', stroke: '#2a6ab0', 'stroke-width': 1, fill: 'none' }, g);
  /* নিম্নপদ — হাঁটুর চারপাশে ঘোরে */
  const sh = E('g', { transform: `rotate(${f1(-th * 180 / PI)} ${K[0]} ${K[1]})` }, g);
  E('path', { d: 'M250 180C252 220 254 250 256 270C262 278 278 278 280 270C282 250 280 214 276 184Z', fill: B.vol(sh, 'skin'), stroke: sk.dk, 'stroke-width': .8 }, sh);
  E('path', { d: 'M254 268C254 280 260 290 290 292C300 292 302 284 292 280C282 276 280 270 280 264Z', fill: sk.c, stroke: sk.dk, 'stroke-width': .8 }, sh);
  E('path', { d: B.ellD(263, 182, 14, 19, 0), fill: B.vol(g, 'skin'), stroke: 'none' }, g);
  /* হাঁটুর বাটি ও প্যাটেলার টেনডন */
  E('path', { d: B.ellD(272, 168, 6, 8, 10), fill: B.vol(g, 'bone'), stroke: B.TS('bone').dk, 'stroke-width': .6 }, g);
  E('path', { d: 'M252 162C266 158 276 162 276 170', stroke: B.TS('tnd').dk, 'stroke-width': 3, fill: 'none' }, g);
  E('path', { d: `M274 176C278 182 ${f1(277 - th * 10)} ${f1(190 + th * 2)} ${f1(274 - th * 16)} ${f1(196 + th * 3)}`, stroke: '#dcdcd0', 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('path', { d: `M274 176C278 182 ${f1(277 - th * 10)} ${f1(190 + th * 2)} ${f1(274 - th * 16)} ${f1(196 + th * 3)}`, stroke: '#a3a392', 'stroke-width': .6, fill: 'none' }, g);
  return K; };
/* স্নায়ুপথ */
const RP = { sen: [[207, 160], [198, 132], [192, 100], [190, 84], [176, 66], [158, 56], [145, 52], [124, 53], [104, 59]], senC: [[104, 59], [90, 56], [79, 58], [76, 72], [80, 88]],
  mot: [[82, 93], [101, 93], [130, 95], [165, 79], [184, 82], [188, 104], [190, 132], [194, 158]],
  int: [[78, 62], [72, 74], [70, 84], [67, 95]], ham: [[67, 95], [100, 96], [165, 82], [182, 88], [184, 124], [188, 160], [196, 188]] };
const RX = [
  { t: 'হাতুড়ির আঘাত', en: 'Stimulus', d: 'হাঁটুর বাটির ঠিক নিচে প্যাটেলার টেনডনে রিফ্লেক্স-হাতুড়ি দিয়ে আলতো আঘাত করা হয় — টেনডন বসে গিয়ে উরুর সামনের কোয়াড্রিসেপস পেশিকে হঠাৎ টেনে লম্বা করে।' },
  { t: 'গ্রাহক: মাংসপেশি টাকু', en: 'Receptor — muscle spindle', d: 'পেশির ভেতরের টানা-গ্রাহক (মাংসপেশি টাকু) প্রসারিত হয়ে উদ্দীপনা তৈরি করে; সংবেদী নিউরনের তন্তু বেয়ে তা পৃষ্ঠমূলের গ্যাংলিয়ন হয়ে সুষুম্নাকাণ্ডে ঢোকে।' },
  { t: 'সুষুম্নাকাণ্ডে একটি সিন্যাপ্স', en: 'Monosynaptic integration', d: 'ধূসর পদার্থে সংবেদী নিউরন সরাসরি অঙ্কশৃঙ্গের মোটর নিউরনের সাথে একটিমাত্র সিন্যাপ্স গঠন করে — তাই এটি একসিন্যাপ্সীয় প্রতিবর্ত। মস্তিষ্কের সিদ্ধান্ত লাগে না।' },
  { t: 'মোটর নিউরন ও কার্যকারক', en: 'Effector', d: 'মোটর নিউরনের উদ্দীপনা অঙ্কমূল ও স্পাইনাল স্নায়ু হয়ে কোয়াড্রিসেপসে পৌঁছে সংকোচন ঘটায়। একই সাথে একটি বাধাদায়ী অন্তর্বর্তী নিউরন পেছনের হ্যামস্ট্রিংকে শিথিল রাখে (পারস্পরিক নিষেধ)।' },
  { t: 'সাড়া: পা সামনে ছোড়া', en: 'Response', d: 'নিম্নপদ হঠাৎ সামনে ছিটকে ওঠে — অনিচ্ছাকৃত, দ্রুত ও প্রতিবার একই রকম। সংকেতের একটি অংশ ওপরে মস্তিষ্কেও যায়, তাই সাড়ার পরে আমরা আঘাত টের পাই। চিকিৎসক এ প্রতিবর্ত দেখে সুষুম্নাকাণ্ডের ওই অংশ (L2–L4) ঠিক আছে কি না বোঝেন।' }
];
V.kneeJerk = Object.assign({ t: 'প্রতিবর্ত চাপ: হাঁটু-ঝাঁকুনি', k: ['2d', 'anim', 'steps'], cap: 'হাঁটু-ঝাঁকুনি প্রতিবর্তের পথ: মাংসপেশি টাকু (গ্রাহক) → সংবেদী নিউরন (নীল) → সুষুম্নাকাণ্ডে একটি সিন্যাপ্স → মোটর নিউরন (লাল) → কোয়াড্রিসেপস (কার্যকারক)। বেগুনি = হ্যামস্ট্রিংয়ের দিকে বাধাদায়ী পথ।' },
  BK.steps({ W: 360, H: 300, label: 'হাঁটু-ঝাঁকুনি প্রতিবর্ত', dur: 3.2, stages: RX,
    draw(g, C, s, u) {
      const th = s === 4 ? Math.sin(cl(u * 1.4) * PI) * .55 : 0, q = s >= 3 ? (s === 3 ? u : 1 - u * .6) : 0;
      B.cacheG(g, 'rxc', gg => { const c = cord(gg, 60, 76, 1.7); B.tx(gg, 60, 24, 'সুষুম্নাকাণ্ড (প্রস্থচ্ছেদ)', { fs: 9.6, a: 'middle', c: C.mu }); B.tx(gg, 150, 40, 'পৃষ্ঠমূলের গ্যাংলিয়ন', { fs: 9, a: 'middle', c: '#8a6a10' }); B.tx(gg, 30, 132, 'ধূসর পদার্থ', { fs: 9, c: '#9a6d66' }); });
      const hh = s >= 3 ? 1 : 0;
      B.cacheG(g, 'rxleg' + (Math.round(th * 300) * 10000 + Math.round(q * 100) * 10 + hh), gg => leg(gg, th, { q, h: hh }));
      /* নিউরন, পেশির নাম ও রং-সংকেত — স্থির স্তর */
      B.cacheG(g, 'rxn', gg => {
        const P = (k, col, w, dash) => E('path', { d: sm(RP[k], false, .5), stroke: col, 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round', 'stroke-dasharray': dash || null }, gg);
        P('sen', SEN, 1.6); P('senC', SEN, 1.6); P('mot', MOT, 1.6); P('int', INT, 1.4); P('ham', INT, 1.1, '3 2');
        E('circle', { cx: 145, cy: 52, r: 3.4, fill: SEN }, gg); E('circle', { cx: 82, cy: 93, r: 3.6, fill: MOT }, gg); E('circle', { cx: 70, cy: 84, r: 2.6, fill: INT }, gg);
        B.tx(gg, 214, 138, 'কোয়াড্রিসেপস', { fs: 9.6, a: 'middle', c: '#86302a', w: 600 }); B.tx(gg, 214, 212, 'হ্যামস্ট্রিং', { fs: 9.6, a: 'middle', c: '#86302a' });
        [[SEN, 'সংবেদী'], [MOT, 'মোটর'], [INT, 'বাধাদায়ী অন্তর্বর্তী']].forEach(([c, l], i) => { E('path', { d: `M${12 + i * 96} 290h16`, stroke: c, 'stroke-width': 2 }, gg); B.tx(gg, 32 + i * 96, 294, l, { fs: 9.6, c }); }); });
      /* উদ্দীপনার কণা */
      const dot = (k, v, col) => { const A = B.alongC(RP[k]); const [x, y] = A(cl(v)); E('circle', { cx: f1(x), cy: f1(y), r: 4, fill: col, stroke: '#fff', 'stroke-width': 1.2 }, g); };
      if (s === 1) dot('sen', u, SEN); if (s === 2) { dot('senC', u, SEN); if (u > .7) E('circle', { cx: 81, cy: 90, r: 8, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); }
      if (s === 3) { dot('mot', u, MOT); dot('ham', u, INT); }
      /* হাতুড়ি */
      const ha = s === 0 ? Math.sin(cl(u * 1.6) * PI) : 0;
      const hm = E('g', { transform: `rotate(${f1(-30 + ha * 30)} 318 166)` }, g);
      E('path', { d: 'M318 166L292 190', stroke: '#8a8070', 'stroke-width': 3, 'stroke-linecap': 'round' }, hm);
      E('path', { d: B.ellD(288, 192, 9, 5, -40), fill: '#b03a3a', stroke: '#6a1a1a', 'stroke-width': .7 }, hm);
      if (s === 0 && u > .4 && u < .8) for (let k = 0; k < 3; k++) E('path', { d: `M${284 - k * 4} ${180 + k * 6}l-6 -2`, stroke: '#e0a030', 'stroke-width': 1.4 }, g);
      if (s === 1) B.tx(g, 207, 152, 'টাকু', { fs: 9, a: 'middle', c: SEN });
    }
  }));

/* ═════════ হাত সরিয়ে নেওয়ার প্রতিবর্ত (বহুসিন্যাপ্সীয়) — লেবেলযুক্ত চিত্র ═════════ */
const WS = [[264, 224], [240, 216], [204, 208], [184, 160], [180, 124], [192, 100], [203, 85], [168, 62], [155, 58], [130, 60], [114, 65]], WC = [[114, 65], [98, 58], [88, 62], [84, 72], [84, 78]], WI = [[84, 78], [88, 90], [92, 99]], WM = [[92, 99], [111, 99], [140, 100], [172, 84], [203, 87], [198, 110], [184, 140], [176, 160]];
V.withdrawalArc = Object.assign({ t: 'প্রতিবর্ত চাপের অংশ: হাত সরিয়ে নেওয়া', k: ['2d', 'anim', 'int', 'quiz'], cap: 'গরম বা ধারালো কিছুতে হাত লাগলে চিন্তা করার আগেই হাত সরে যায়। পথ: ত্বকের ব্যথা-গ্রাহক → সংবেদী নিউরন → পৃষ্ঠমূল → অন্তর্বর্তী নিউরন (ধূসর পদার্থে) → মোটর নিউরন → অঙ্কমূল → বাইসেপস (কার্যকারক)। দুটি সিন্যাপ্স থাকায় এটি বহুসিন্যাপ্সীয় প্রতিবর্ত।' },
  BK.diagram({ W: 360, H: 300, label: 'হাত সরিয়ে নেওয়ার প্রতিবর্ত', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), sk = B.TS('skin'), M = B.TS('mus');
      const c = cord(P('cord'), 70, 82, 1.7);
      /* বাহু: কাঁধ থেকে কনুই (নিচে), কনুই থেকে হাত (ডানে) */
      E('path', { d: 'M150 130C168 126 182 132 190 150L204 200C206 212 196 218 186 214L162 168C156 156 148 144 150 130Z', fill: B.vol(g, 'skin'), stroke: sk.dk, 'stroke-width': .8 }, g);
      E('path', { d: 'M160 140C170 138 180 146 186 160L196 194C190 196 184 190 180 180L166 154Z', fill: FK.alpha(M.c, .75), stroke: M.dk, 'stroke-width': .6 }, P('eff'));
      E('path', { d: 'M188 206C210 210 240 214 262 214C272 216 274 226 264 228C240 230 212 226 190 220Z', fill: B.vol(g, 'skin'), stroke: sk.dk, 'stroke-width': .8 }, g);
      E('path', { d: 'M262 214C272 210 284 212 290 218C292 224 284 230 274 230L264 228Z', fill: sk.c, stroke: sk.dk, 'stroke-width': .8 }, g);
      /* আলপিন */
      E('path', { d: 'M266 262L266 232', stroke: '#8a9098', 'stroke-width': 1.6 }, g); E('circle', { cx: 266, cy: 264, r: 4, fill: '#c03a3a' }, g);
      /* ত্বকের গ্রাহক */
      E('circle', { cx: 264, cy: 224, r: 3, fill: '#f0c040', stroke: '#8a6a10', 'stroke-width': .6 }, P('rec'));
      E('path', { d: sm(WS, false), stroke: SEN, 'stroke-width': 1.8, fill: 'none' }, P('sen')); E('circle', { cx: 155, cy: 58, r: 3.6, fill: SEN }, P('sen'));
      E('path', { d: sm(WC, false), stroke: SEN, 'stroke-width': 1.8, fill: 'none' }, P('sen'));
      E('path', { d: sm(WI, false), stroke: INT, 'stroke-width': 1.8, fill: 'none' }, P('int')); E('circle', { cx: 84, cy: 78, r: 2.8, fill: INT }, P('int'));
      E('path', { d: sm(WM, false), stroke: MOT, 'stroke-width': 1.8, fill: 'none' }, P('mot')); E('circle', { cx: 92, cy: 99, r: 3.6, fill: MOT }, P('mot'));
      E('path', { d: 'M176 160l-4 2M176 160l-3 -4M176 160l1 5', stroke: MOT, 'stroke-width': 1.4 }, P('nmj'));
      E('path', { d: 'M0 0', fill: 'none' }, P('drg')); E('path', { d: 'M0 0', fill: 'none' }, P('gm')); E('path', { d: 'M0 0', fill: 'none' }, P('vr'));
      hits(this.parts, part, 12); },
    idle(g, C, t) { const ph = (t * .35) % 1, seq = [[WS, SEN, 0, .4], [WC, SEN, .4, .55], [WI, INT, .55, .65], [WM, MOT, .65, .95]];
      seq.forEach(([p, col, a, b]) => { if (ph >= a && ph < b) { const [x, y] = B.alongC(p)((ph - a) / (b - a)); E('circle', { cx: f1(x), cy: f1(y), r: 4, fill: col, stroke: '#fff', 'stroke-width': 1.2 }, g); } }); },
    parts: [
      { id: 'rec', bn: 'গ্রাহক (ত্বকের ব্যথা-গ্রাহক)', lb: 'গ্রাহক', en: 'Receptor', fn: 'ত্বকের মুক্ত স্নায়ুপ্রান্ত (নোসিসেপ্টর) ধারালো বা গরম উদ্দীপনায় স্নায়ু-উদ্দীপনা তৈরি করে।', a: [264, 224], l: [330, 258], an: 'end' },
      { id: 'sen', bn: 'সংবেদী (অন্তর্মুখী) নিউরন', lb: 'সংবেদী নিউরন', en: 'Sensory neuron', fn: 'গ্রাহক থেকে উদ্দীপনা সুষুম্নাকাণ্ডে নিয়ে যায়; কোষদেহ পৃষ্ঠমূলের গ্যাংলিয়নে।', a: [182, 140], l: [234, 112], an: 'start' },
      { id: 'drg', bn: 'পৃষ্ঠমূলের গ্যাংলিয়ন', lb: 'পৃষ্ঠমূলের গ্যাংলিয়ন', en: 'Dorsal root ganglion', fn: 'সংবেদী নিউরনের কোষদেহগুলো এখানে জড়ো থাকে — পৃষ্ঠমূলের ওপরের ফোলা অংশ।', a: [155, 58], l: [214, 28], an: 'start' },
      { id: 'int', bn: 'অন্তর্বর্তী (সংযোজক) নিউরন', lb: 'অন্তর্বর্তী নিউরন', en: 'Interneuron', fn: 'ধূসর পদার্থে সংবেদী ও মোটর নিউরনের মাঝে সংযোগ ঘটায় — এ কারণে দুটি সিন্যাপ্স, তাই বহুসিন্যাপ্সীয় প্রতিবর্ত।', a: [84, 78], l: [14, 176], an: 'start' },
      { id: 'gm', bn: 'ধূসর পদার্থ', lb: 'ধূসর পদার্থ', en: 'Grey matter', fn: 'নিউরনের কোষদেহ ও সিন্যাপ্সের অঞ্চল — প্রজাপতির আকৃতি; পৃষ্ঠশৃঙ্গে সংবেদী তন্তু ঢোকে, অঙ্কশৃঙ্গে মোটর নিউরনের কোষদেহ।', a: [56, 92], l: [14, 146], an: 'start' },
      { id: 'cord', bn: 'শ্বেত পদার্থ', lb: 'শ্বেত পদার্থ', en: 'White matter', fn: 'মায়েলিনযুক্ত স্নায়ুতন্তুর গুচ্ছ — ওঠানামা করা পথে উদ্দীপনা মস্তিষ্কে পৌঁছায়, তাই প্রতিবর্তের পরে ব্যথা টের পাওয়া যায়।', a: [26, 82], l: [16, 22], an: 'start' },
      { id: 'mot', bn: 'মোটর (বহির্মুখী) নিউরন', lb: 'মোটর নিউরন', en: 'Motor neuron', fn: 'অঙ্কশৃঙ্গ থেকে অঙ্কমূল হয়ে কার্যকারক পেশিতে উদ্দীপনা পাঠায়।', a: [140, 100], l: [96, 228], an: 'middle' },
      { id: 'vr', bn: 'অঙ্কমূল', lb: 'অঙ্কমূল', en: 'Ventral root', fn: 'মোটর তন্তুগুলো সুষুম্নাকাণ্ড থেকে এ পথে বের হয়।', a: [111, 99], l: [40, 254], an: 'start' },
      { id: 'eff', bn: 'কার্যকারক (বাইসেপস পেশি)', lb: 'কার্যকারক', en: 'Effector', fn: 'বাইসেপস সংকুচিত হয়ে কনুই ভাঁজ করে এবং হাত উদ্দীপনা থেকে সরিয়ে নেয়।', a: [186, 178], l: [236, 182], an: 'start' },
      { id: 'nmj', bn: 'স্নায়ু-পেশি সংযোগ', lb: 'স্নায়ু-পেশি সংযোগ', en: 'Neuromuscular junction', fn: 'মোটর নিউরনের প্রান্ত অ্যাসিটাইলকোলিন ছেড়ে পেশিকে সংকোচনের সংকেত দেয়।', a: [176, 160], l: [236, 148], an: 'start' }
    ]
  }));

/* ═════════ বাবুই পাখি (Ploceus philippinus) ও তার ঝোলানো বাসা ═════════ */
const baya = (g, x, y, s, fl = 1, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${f1(s * fl)} ${f1(s)})` }, g);
  E('path', { d: 'M8 2L20 8L19 11L6 6Z', fill: '#8a6a3a', stroke: '#4a3418', 'stroke-width': .4 }, gg);
  E('path', { d: 'M-8 -6C-2 -10 8 -8 12 0C14 6 8 10 0 10C-6 10 -10 6 -10 0C-10 -3 -9 -5 -8 -6Z', fill: '#b08850', stroke: '#5a4020', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-2 -4C4 -6 10 -2 12 4C6 6 0 6 -4 2Z', fill: '#8a6638' }, gg); for (let i = 0; i < 4; i++) E('path', { d: `M${f1(0 + i * 3)} ${f1(-3 + i)}l3 3`, stroke: '#3a2810', 'stroke-width': .6 }, gg);
  E('path', { d: 'M-8 4C-6 8 0 10 6 9C2 6 -4 4 -8 4Z', fill: '#e8d8a0' }, gg);
  E('path', { d: 'M-15 -8C-15 -14 -8 -16 -5 -12C-3 -9 -4 -5 -8 -4C-12 -4 -15 -6 -15 -8Z', fill: o.male !== false ? '#f0d020' : '#b08850', stroke: '#5a4020', 'stroke-width': .5 }, gg);
  if (o.male !== false) E('path', { d: 'M-15 -8C-14 -5 -11 -4 -8 -4C-10 -6 -12 -7 -15 -8Z', fill: '#3a2a18' }, gg);
  E('circle', { cx: -11, cy: -9.5, r: 1, fill: '#111' }, gg);
  E('path', { d: 'M-15 -10L-21 -8L-15 -6Z', fill: '#3a3028' }, gg);
  E('path', { d: 'M-2 10L-3 15M3 10L3 15', stroke: '#a89070', 'stroke-width': 1 }, gg);
  if (o.strip) E('path', { d: 'M-21 -8q-10 6 -14 22', stroke: '#c8d088', 'stroke-width': 1.6, fill: 'none' }, gg);
  return gg; };
/* বাসার বুনন: পথ বরাবর অনেক বাঁকা সুতা */
const weave = (g, pts, n, seed, col = '#a89450') => { const A = B.alongC(pts, 4); for (let i = 0; i < n; i++) { const u = (i + .5) / n, [x, y] = A(u), [x2, y2] = A(Math.min(1, u + .04)), a = Math.atan2(y2 - y, x2 - x), r = 4 + B.rnd(seed + i) * 5, w = (B.rnd(seed + i * 3) - .5) * 1.4;
  E('path', { d: `M${f1(x - Math.cos(a) * r)} ${f1(y - Math.sin(a) * r)}Q${f1(x - Math.sin(a) * r * w)} ${f1(y + Math.cos(a) * r * w)} ${f1(x + Math.cos(a) * r)} ${f1(y + Math.sin(a) * r)}`, stroke: i % 3 ? col : '#7a6a30', 'stroke-width': 1.2, fill: 'none' }, g); } };
const nestShape = (g, st, k) => { /* ডাল থেকে ঝোলানো: st = 0..4 পর্যায়, k = ০→১ */
  const top = [[196, 54], [200, 66], [204, 78]];
  if (st >= 1) { weave(g, [[200, 50], [202, 62], [204, 78]], st === 1 ? Math.floor(6 + k * 14) : 20, 3); }
  if (st >= 3) E('path', { d: sm([[204, 78], [184, 90], [168, 110], [166, 136], [178, 150], [196, 146], [206, 126], [218, 116], [222, 98], [212, 80]], true), fill: FK.alpha('#c8b870', .6), stroke: '#8a7a40', 'stroke-width': .8 }, g);
  else if (st === 2) E('path', { d: sm([[204, 78], [184, 92], [180, 114], [196, 124], [214, 118], [222, 98], [212, 80]], true), fill: 'none', stroke: FK.alpha('#8a7a40', .5), 'stroke-width': 6 }, g);
  if (st >= 2) { const ring = [[204, 78], [184, 92], [180, 114], [196, 124], [214, 118], [222, 98], [212, 80]]; weave(g, ring, st === 2 ? Math.floor(10 + k * 40) : 50, 11); }
  if (st >= 3) { const ch = [[184, 92], [168, 110], [166, 136], [178, 150], [194, 146], [198, 126]]; weave(g, ch, st === 3 ? Math.floor(10 + k * 40) : 50, 31);
    if (st >= 3 && k > .5 || st > 3) [[176, 128], [182, 138], [172, 118]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 2.6, fill: '#8a6a4a', stroke: '#5a4028', 'stroke-width': .4 }, g)); }
  if (st >= 4) { const L = 60 + k * 70; const tube = [[214, 118], [222, 140], [226, 140 + L * .5], [228, 140 + L]]; weave(g, tube, Math.floor(14 + k * 40), 61); E('path', { d: B.ellD(228, 140 + L, 6, 2.4), fill: '#4a3a18' }, g); }
};
const WN = [
  { t: 'পাতার ফালি ছেঁড়া', en: 'Collecting strips', d: 'পুরুষ বাবুই ধান, নারকেল বা তালপাতার কিনারায় ঠোঁট দিয়ে খাঁজ কেটে পেছনে উড়ে গিয়ে লম্বা সরু ফালি ছিঁড়ে আনে। বাসা বানায় শুধু পুরুষ, সাধারণত বর্ষা মৌসুমে।' },
  { t: 'ডালে গিঁট দেওয়া', en: 'Knotting', d: 'ঝুলে থাকা ডাল বা পাতার আগায় ফালি পেঁচিয়ে ঠোঁট ও পা দিয়ে গিঁট দেয় — বাসার ঝোলানো দড়ি তৈরি হয়।' },
  { t: 'বলয় (হেলমেট) পর্যায়', en: 'Ring / helmet stage', d: 'নিচে একটি গোলাকার বলয় বোনে, যার ভেতরে বসে পুরুষ বুনতে থাকে এবং পাখা ঝাপটে স্ত্রী বাবুইকে আকৃষ্ট করে। স্ত্রী এ অর্ধেক-বানানো বাসা পরীক্ষা করে পছন্দ হলেই জোড় বাঁধে।' },
  { t: 'ডিমের কক্ষ', en: 'Egg chamber', d: 'স্ত্রী রাজি হলে পুরুষ বলয়ের একপাশে গোল ডিমের কক্ষ সম্পূর্ণ করে; ভেতরে কাদার ছোট দলা লাগানো হয় (বাতাসে দুলুনি কমাতে ধারণা করা হয়)।' },
  { t: 'লম্বা প্রবেশ-নল', en: 'Entrance tube', d: 'অন্য পাশে নিচের দিকে লম্বা নলাকার প্রবেশপথ বোনা হয় — সাপ ও শিকারি পাখির পক্ষে ঢোকা কঠিন। না শিখেই প্রথমবারেই এমন জটিল বাসা বানানো সহজাত আচরণ; তবে তরুণ পুরুষের প্রথম বাসা প্রায়ই এলোমেলো হয়, অনুশীলনে দক্ষতা বাড়ে।' }
];
V.weaverNest = Object.assign({ t: 'সহজাত আচরণ: বাবুই পাখির বাসা বোনা', k: ['2d', 'anim', 'steps'], cap: 'বাবুই (Ploceus philippinus) ধাপে ধাপে ঝোলানো বাসা বোনে — ফালি ছেঁড়া, গিঁট, বলয়, ডিমের কক্ষ ও প্রবেশ-নল। এ নির্দিষ্ট ক্রম প্রজাতির সব পুরুষে একই, কাউকে শেখাতে হয় না — সহজাত আবেগের উদাহরণ।' },
  BK.steps({ W: 360, H: 300, label: 'বাবুইয়ের বাসা', dur: 3.4, stages: WN,
    draw(g, C, s, u) {
      B.cacheG(g, 'wnbg', gg => { E('rect', { x: 0, y: 0, width: 360, height: 300, fill: FK.alpha('#dfeaf2', .6) }, gg);
        E('path', { d: 'M40 20C110 30 170 40 260 44C300 46 330 52 350 60', stroke: '#6a8a3a', 'stroke-width': 3, fill: 'none' }, gg);
        for (let i = 0; i < 12; i++) { const x = 60 + i * 24; E('path', { d: `M${x} ${f1(26 + i * 2.4)}q8 18 4 ${f1(34 + B.rnd(i) * 10)}`, stroke: '#7aa048', 'stroke-width': 2.4, fill: 'none' }, gg); } });
      nestShape(g, s, u);
      const bx = s === 0 ? lerp(320, 210, u) : s === 1 ? 210 + Math.sin(u * PI * 6) * 3 : s === 2 ? 200 : s === 3 ? 176 : 232, by = s === 0 ? lerp(240, 66, u) : s === 1 ? 70 : s === 2 ? 108 : s === 3 ? 96 : 138 + u * 60;
      baya(g, bx, by, 1.7, s === 3 ? -1 : 1, { strip: s <= 1 || s === 4 });
      if (s === 2) baya(g, 286, 150, 1.5, 1, { male: false });
      if (s === 2) B.tx(g, 286, 176, 'স্ত্রী বাবুই পরীক্ষা করছে', { fs: 9.6, a: 'middle', c: C.mu });
      if (s === 0) { E('path', { d: 'M300 280C310 250 316 230 330 200', stroke: '#8ab060', 'stroke-width': 4, fill: 'none' }, g); B.tx(g, 300, 296, 'ধানপাতা', { fs: 9.6, a: 'middle', c: C.mu }); }
    }
  }));

/* ═════════ কোকিল-ছানা পোষক পাখির ডিম ফেলে দেয় ═════════ */
const chick = (g, x, y, s, a = 0) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a)}) scale(${s})` }, g);
  E('path', { d: 'M-14 4C-16 -4 -8 -10 2 -10C10 -10 14 -4 14 2C14 8 8 10 0 10C-8 10 -13 8 -14 4Z', fill: '#f2b8a8', stroke: '#a8685a', 'stroke-width': .6 }, gg);
  E('path', { d: 'M-12 -2C-8 -6 0 -8 6 -6', stroke: '#d8907e', 'stroke-width': .7, fill: 'none' }, gg);
  E('path', { d: 'M-8 -8C-12 -12 -16 -10 -18 -6M10 -6C14 -10 18 -8 20 -4', stroke: '#e2a090', 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('circle', { cx: -16, cy: 2, r: 6, fill: '#f2b8a8', stroke: '#a8685a', 'stroke-width': .6 }, gg); E('circle', { cx: -18, cy: 0, r: 1.6, fill: '#5a2a2a', opacity: .6 }, gg);
  E('path', { d: 'M-21 2L-26 4L-21 6Z', fill: '#f0a050' }, gg); return gg; };
const CK = [
  { t: 'অন্ধ ছানার জন্ম', en: 'Hatching', d: 'কমন কোকিল (Cuculus canorus) অন্য পাখির (যেমন নলখাগড়ার ফুটকি) বাসায় ডিম পাড়ে। কোকিলের ডিম আগে ফোটে; ছানা চোখ-বন্ধ, পালকহীন — কিছুই দেখেনি বা শেখেনি।' },
  { t: 'ডিম পিঠে তোলা', en: 'Loading', d: 'জন্মের কয়েক ঘণ্টার মধ্যে ছানা পিঠ দিয়ে কোনো শক্ত বস্তু (ডিম বা ছোট ছানা) ছুঁলেই অস্থির হয়ে সেটিকে পিঠের খাঁজে তুলে নেয় — স্পর্শই সংকেত-উদ্দীপনা।' },
  { t: 'কিনারা বেয়ে ঠেলা', en: 'Pushing', d: 'ছোট ডানা দুটো পাশে ঠেকিয়ে, পা শক্ত করে পেছন দিকে বাসার কিনারা বেয়ে ওঠে।' },
  { t: 'ডিম ফেলে দেওয়া', en: 'Ejection', d: 'কিনারায় পৌঁছে ঝাঁকুনি দিয়ে ডিমটি বাসার বাইরে ফেলে দেয়, তারপর আবার নিচে নেমে পরের ডিমের জন্য একই ক্রম শুরু করে — সব ডিম শেষ না হওয়া পর্যন্ত।' },
  { t: 'পোষক মা খাওয়ায়', en: 'Gape stimulus', d: 'একা থাকা কোকিল-ছানার উজ্জ্বল কমলা হাঁ-মুখ ও জোরালো ডাক পোষক পাখিকে খাওয়াতে উদ্দীপিত করে — পোষক নিজের চেয়ে কয়েক গুণ বড় ছানাকেও খাওয়ায়। (আমাদের দেশের এশীয় কোকিল কাকের বাসায় ডিম পাড়ে, তবে তার ছানা পোষকের ডিম ফেলে দেয় না।)' }
];
V.cuckooEject = Object.assign({ t: 'সহজাত আচরণ: কোকিল-ছানার ডিম ফেলে দেওয়া', k: ['2d', 'anim', 'steps'], cap: 'অন্ধ, সদ্যোজাত কোকিল-ছানা কারো কাছে না শিখেই পোষক পাখির ডিম পিঠে তুলে বাসার বাইরে ফেলে দেয় — জটিল কিন্তু সম্পূর্ণ সহজাত আচরণ, যা পরজীবী প্রজননে টিকে থাকার সুবিধা দেয়।' },
  BK.steps({ W: 360, H: 270, label: 'কোকিল-ছানা', dur: 3.2, stages: CK,
    draw(g, C, s, u) {
      B.cacheG(g, 'ckbg', gg => { E('rect', { x: 0, y: 0, width: 360, height: 270, fill: FK.alpha('#e8f0e0', .6) }, gg);
        for (let i = 0; i < 6; i++) E('path', { d: `M${40 + i * 56} 270C${44 + i * 56} 200 ${36 + i * 56} 120 ${48 + i * 56} 20`, stroke: '#b8b070', 'stroke-width': 4, fill: 'none' }, gg);
        /* বাসা (কাপ, প্রস্থচ্ছেদ) */
        E('path', { d: 'M100 150C100 200 140 222 180 222C220 222 260 200 260 150L246 150C246 190 216 206 180 206C144 206 114 190 114 150Z', fill: B.lin(gg, 'wood', 90), stroke: '#5c4022', 'stroke-width': .8 }, gg);
        for (let i = 0; i < 26; i++) { const a = PI * (i / 25); E('path', { d: `M${f1(180 - Math.cos(a) * 72)} ${f1(150 + Math.sin(a) * 64)}q6 -4 12 0`, stroke: '#8a6a3a', 'stroke-width': .8, fill: 'none' }, gg); } });
      const EGG = (x, y, a = 0) => E('path', { d: B.ellD(x, y, 8, 6, a), fill: '#d8e4c8', stroke: '#7a8a6a', 'stroke-width': .6 }, g);
      const eggs = s === 0 ? 3 : s <= 3 ? 2 : 0;
      for (let i = 0; i < eggs; i++) EGG(150 + i * 18, 196);
      let cx = 196, cy = 190, ca = 0, ex = null, ey = null;
      if (s === 1) { cx = 190; ca = -10 * u; ex = lerp(206, 196, u); ey = lerp(196, 176, u); }
      if (s === 2) { cx = lerp(190, 230, u); cy = lerp(190, 156, u); ca = lerp(-10, -50, u); ex = cx + 6; ey = cy - 14; }
      if (s === 3) { cx = 232; cy = 154; ca = -50 + Math.sin(u * PI) * 10; if (u < .4) { ex = 238; ey = 140; } else { const k = cl((u - .4) / .6); ex = lerp(250, 300, k); ey = lerp(132, 250, k * k); } }
      if (s === 4) { cx = 182; cy = 180; }
      chick(g, cx, cy, s === 4 ? 2.4 : 1.9, ca);
      if (ex != null) EGG(ex, ey, 20);
      if (s === 4) { /* পোষক পাখি খাওয়াচ্ছে; কমলা হাঁ-মুখ */ E('path', { d: 'M146 170L130 150L150 156Z', fill: '#f08a20', stroke: '#a85a10' }, g);
        const gg = E('g', { transform: `translate(110 112) scale(1.6)` }, g); E('path', { d: 'M-8 -6C-2 -10 8 -8 12 0C14 6 8 10 0 10C-6 10 -10 6 -10 0Z', fill: '#a89470', stroke: '#5a4a30', 'stroke-width': .5 }, gg); E('path', { d: 'M-14 -8C-14 -13 -8 -14 -6 -10C-4 -7 -6 -4 -9 -4C-12 -4 -14 -6 -14 -8Z', fill: '#b8a480' }, gg); E('circle', { cx: -10, cy: -9, r: .9, fill: '#111' }, gg); E('path', { d: 'M-14 -9L-22 -6L-14 -6Z', fill: '#3a3028' }, gg); E('path', { d: 'M8 2L20 6L18 9L6 6Z', fill: '#8a7a5a' }, gg);
        B.tx(g, 110, 92, 'পোষক পাখি', { fs: 9.6, a: 'middle', c: C.mu }); }
      if (s === 3 && u > .5) B.tx(g, 296, 120, 'পোষকের ডিম বাইরে', { fs: 9.6, a: 'middle', c: '#7a2a1a' });
      B.tx(g, 180, 256, s === 4 ? 'বাসায় শুধু কোকিল-ছানা — সব খাবার তার' : 'শেখা ছাড়াই, চোখ না খুলেই — সহজাত', { fs: 10.4, a: 'middle', c: C.mu });
    }
  }));
})();
