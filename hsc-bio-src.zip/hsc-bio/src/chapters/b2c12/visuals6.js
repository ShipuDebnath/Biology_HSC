/* ═══════════════════════════════════════════════════════════════════
   visuals6 — মাকড়সার জাল ও অপত্য যত্ন:
   orbWebSteps (বৃত্তাকার জাল বোনার ধাপ), spiderAnatomy (মাকড়সার দেহ — লেবেলযুক্ত),
   parentalCare (মাছ, উভচর, পাখি, স্তন্যপায়ীর সন্তান-যত্ন), offspringCare (সন্তানসংখ্যা বনাম যত্ন)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, TP = B.tp, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ মাকড়সা (ওপর থেকে, মাথা −y দিকে) ═════════ */
B.spider = (g, x, y, s = 1, rot = 0, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(rot * 180 / PI)}) scale(${s})` }, g), S = B.TS('spdr');
  /* পা: প্রতি পাশে 4টি, প্রতিটি তিন খণ্ডে বাঁকা (সামনের দুই জোড়া সামনে, পেছনের দুই জোড়া পেছনে) */
  const LG = [[-62, 14, 22], [-28, 12, 18], [22, 11, 15], [52, 13, 20]];
  let LD = '', JD = '';
  [1, -1].forEach(sd => LG.forEach(([a0, l1, l2], i) => { const a = (a0 + (o.wig ? Math.sin(o.wig + i) * 4 : 0)) * PI / 180, bx = sd * 3.4, by = -4 + i * 2.2, kx = bx + sd * Math.cos(a) * l1, ky = by + Math.sin(a) * l1 - 3, ex = kx + sd * Math.cos(a + (i < 2 ? -.5 : .5)) * l2, ey = ky + Math.sin(a + (i < 2 ? -.5 : .5)) * l2;
    LD += `M${f1(bx)} ${f1(by)}L${f1(kx)} ${f1(ky)}L${f1(ex)} ${f1(ey)}`;
    JD += dotD(kx, ky, .9); for (let k = 1; k < 3; k++) JD += dotD(lerp(kx, ex, k / 3), lerp(ky, ey, k / 3), .6); }));
  E('path', { d: LD, stroke: S.dk, 'stroke-width': 1.5, fill: 'none', 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, gg); E('path', { d: JD, fill: '#d8b47a' }, gg);
  /* দেহ একবার defs-এ এঁকে <use> দিয়ে পুনর্ব্যবহার */
  const svg = gg.ownerSVGElement; if (!svg._spb) { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } svg._spb = 'spb' + (++spN); const bb = E('g', { id: svg._spb }, d); spBody(bb, S); }
  E('use', { href: '#' + svg._spb }, gg);
  return gg; };
let spN = 0; const dotD = (x, y, r) => `M${f1(x - r)} ${f1(y)}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0`;
const spBody = (gg, S) => {
  /* উদর (ডিম্বাকার, নকশাসহ), বৃন্ত, সেফালোথোরাক্স */
  E('path', { d: B.ellD(0, 11, 8.4, 10.4), fill: B.vol(gg, 'spdr'), stroke: S.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M0 2L-4 8L0 14L4 8ZM0 14L-3 18L0 21L3 18Z', fill: '#f0e2c0', opacity: .75 }, gg);
  [-1, 1].forEach(sd => [6, 11, 16].forEach(py => E('circle', { cx: sd * 5, cy: py, r: .9, fill: '#f0e2c0' }, gg)));
  E('path', { d: 'M-1.4 0.4h2.8v2h-2.8z', fill: S.dk }, gg);
  E('path', { d: B.ellD(0, -5.6, 5, 5.8), fill: B.vol(gg, 'fur'), stroke: S.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M0 -1L0 -9M-2.6 -2.6L-1 -7M2.6 -2.6L1 -7', stroke: FK.alpha(S.dk, .4), 'stroke-width': .5 }, gg);
  /* আটটি চোখ (দুই সারি) */
  [[-1.2, -10.4], [1.2, -10.4], [-2.6, -9.6], [2.6, -9.6], [-.9, -8.6], [.9, -8.6], [-2.8, -8.2], [2.8, -8.2]].forEach(([ex, ey], i) => E('circle', { cx: ex, cy: ey, r: i < 2 ? .65 : .45, fill: '#111' }, gg));
  /* চেলিসেরি (বিষদাঁতসহ) ও পেডিপাল্প */
  E('path', { d: 'M-1.6 -11.2l-.6 -2.4l1 .6M1.6 -11.2l.6 -2.4l-1 .6', stroke: '#3a2414', 'stroke-width': 1.2, fill: 'none' }, gg);
  E('path', { d: 'M-3 -10.4l-2.6 -3.4l-.6 -2M3 -10.4l2.6 -3.4l.6 -2', stroke: S.dk, 'stroke-width': 1.1, fill: 'none', 'stroke-linecap': 'round' }, gg);
  /* স্পিনারেট (উদরের শেষ প্রান্তে) */
  E('path', { d: 'M-1.6 20.6l-.6 2M0 21.2v2.2M1.6 20.6l.6 2', stroke: S.dk, 'stroke-width': .9 }, gg);
};

/* ─── জালের জ্যামিতি ─── */
const HX = 180, HY = 146, NR = 26;
const FR = [[60, 48], [300, 40], [336, 150], [296, 248], [180, 266], [62, 246], [28, 140]];  /* কাঠামো সুতার বহুভুজ */
const hit = (a) => { const dx = Math.cos(a), dy = Math.sin(a); let best = 1e9; for (let i = 0; i < FR.length; i++) { const [x1, y1] = FR[i], [x2, y2] = FR[(i + 1) % FR.length], ex = x2 - x1, ey = y2 - y1, den = dx * ey - dy * ex; if (Math.abs(den) < 1e-9) continue; const t = ((x1 - HX) * ey - (y1 - HY) * ex) / den, u = ((x1 - HX) * dy - (y1 - HY) * dx) / den; if (t > 0 && u >= 0 && u <= 1) best = Math.min(best, t); } return best; };
const RAD = Array.from({ length: NR }, (_, i) => { const a = -PI / 2 + i * 2 * PI / NR + (B.rnd(i) - .5) * .06; return [a, hit(a)]; });
const spiral = (r0, r1, step, frac) => { const pts = [], turns = (r1 - r0) / step, n = Math.max(2, Math.floor(turns * NR * frac)); for (let k = 0; k <= n; k++) { const i = k % NR, [a, R] = RAD[i], r = Math.min(r0 + step * k / NR, R * .94); pts.push([HX + Math.cos(a) * r, HY + Math.sin(a) * r]); } return pts; };
const capSp = (frac) => { const pts = [], outer = .9, inner = 26, step = 5.2; let k = 0, done = false; const total = Math.floor(((120 - inner) / step) * NR), n = Math.floor(total * frac);
  for (k = 0; k <= n; k++) { const i = (NR * 1000 - k) % NR, [a, R] = RAD[i], r = R * outer - step * k / NR; if (r < inner) break; pts.push([HX + Math.cos(a) * r, HY + Math.sin(a) * r]); } return pts; };
const OW = [
  { t: 'সেতু সুতা', en: 'Bridge line', d: 'মাকড়সা উঁচু কোনো জায়গা থেকে স্পিনারেট দিয়ে হালকা সুতা ছাড়ে; বাতাসে ভেসে সুতাটি কোথাও আটকে গেলে সে টেনে শক্ত করে এবং তার ওপর দিয়ে হেঁটে আরও সুতা জুড়ে মজবুত সেতু বানায়।' },
  { t: 'Y-আকৃতির কাঠামো', en: 'Proto-radii', d: 'সেতুর মাঝখান থেকে একটি সুতা নিচে টেনে নিয়ে আটকায় — Y আকৃতি তৈরি হয়; Y এর কেন্দ্র হবে জালের কেন্দ্র (হাব)।' },
  { t: 'কাঠামো ও ব্যাসার্ধ সুতা', en: 'Frame & radii', d: 'বাইরের কাঠামো সুতা এবং কেন্দ্র থেকে চারদিকে চাকার স্পোকের মতো 20–30টির বেশি ব্যাসার্ধ সুতা টানে; এগুলো শুকনো, শক্ত (অ্যাম্পুলেট গ্রন্থির) রেশম।' },
  { t: 'অস্থায়ী সর্পিল', en: 'Auxiliary spiral', d: 'কেন্দ্রের কাছ থেকে বাইরের দিকে কয়েক পাকের চওড়া, আঠাহীন অস্থায়ী সর্পিল বোনে — এটি ভারা হিসেবে কাজ করে।' },
  { t: 'আঠালো ধরার সর্পিল', en: 'Capture spiral', d: 'এবার বাইরে থেকে ভেতরের দিকে ঘন, আঠালো ফোঁটাযুক্ত স্থিতিস্থাপক সর্পিল বোনে (ফ্ল্যাজেলিফর্ম ও অ্যাগ্রিগেট গ্রন্থির রেশম) এবং চলতে চলতে অস্থায়ী সর্পিল কেটে খেয়ে ফেলে।' },
  { t: 'কেন্দ্রে অপেক্ষা', en: 'Waiting at the hub', d: 'জাল শেষ হলে মাকড়সা কেন্দ্রে মাথা নিচু করে বসে থাকে (বা পাশে লুকিয়ে সংকেত-সুতায় পা রাখে)। পোকা আটকালে কম্পন টের পেয়ে ছুটে যায়। না শিখেই প্রথমবারেই নিখুঁত জাল বোনা — সহজাত আচরণ; অনেক মাকড়সা প্রতিদিন পুরোনো জাল খেয়ে নতুন জাল বোনে।' }
];
V.orbWebSteps = Object.assign({ t: 'সহজাত আচরণ: মাকড়সার জাল বোনা', k: ['2d', 'anim', 'steps'], cap: 'বাগানের বৃত্তাকার জালের মাকড়সা (অর্ব-উইভার, যেমন Araneus, Argiope, Nephila) প্রতিবার একই ক্রমে জাল বোনে: সেতু → Y কাঠামো → ব্যাসার্ধ → অস্থায়ী সর্পিল → আঠালো সর্পিল → কেন্দ্রে অপেক্ষা। এ জটিল ক্রম বংশগত, শিখতে হয় না।' },
  BK.steps({ W: 360, H: 300, label: 'জাল বোনা', dur: 3.6, stages: OW,
    draw(g, C, s, u) {
      B.cacheG(g, 'owbg', gg => { E('rect', { x: 0, y: 0, width: 360, height: 300, fill: FK.alpha('#e6efe0', .7) }, gg);
        E('path', { d: 'M0 30C60 20 120 26 180 22C240 18 300 22 360 30', stroke: '#7a5a3a', 'stroke-width': 5, fill: 'none' }, gg); E('path', { d: 'M0 286C100 280 260 282 360 290', stroke: '#6a8a3a', 'stroke-width': 6, fill: 'none' }, gg); });
      const L = (gg, pts, w = .8, col = '#9aa8b8', dash) => E('path', { d: pts.map((p, i) => (i ? 'L' : 'M') + f1(p[0]) + ' ' + f1(p[1])).join(''), stroke: col, 'stroke-width': w, fill: 'none', 'stroke-dasharray': dash || null }, gg);
      /* এক ধাপের সুতা, k = ০→১ অগ্রগতি */
      const part = (gg, st, k) => {
        if (st === 0) L(gg, [[60, 30], [lerp(60, 300, k), lerp(30, 26, k)]], 1);  /* সেতু */
        if (st === 1) { L(gg, [[60, 30], [lerp(180, HX, k), lerp(28, HY, k)]], .8); L(gg, [[300, 26], [lerp(180, HX, k), lerp(28, HY, k)]], .8); if (k > .5) L(gg, [[HX, HY], [HX, lerp(HY, 270, (k - .5) * 2)]], .8); }
        if (st === 2) { const nf = Math.floor(FR.length * k); L(gg, FR.slice(0, nf + 1).concat(k >= 1 ? [FR[0]] : []), .9, '#8898a8'); const nr = Math.floor(NR * k); RAD.slice(0, nr).forEach(([a, R]) => L(gg, [[HX, HY], [HX + Math.cos(a) * R, HY + Math.sin(a) * R]], .6)); }
        if (st === 3) L(gg, spiral(12, 70, 11, k), .6, '#a8b4c0');
        if (st === 4) { const pts = capSp(k); L(gg, pts, .55, '#7a8aa0'); if (pts.length > 2) for (let i = 0; i < pts.length; i += 2) E('circle', { cx: f1(pts[i][0]), cy: f1(pts[i][1]), r: .7, fill: '#d0dcea' }, gg); }
      };
      /* আগের ধাপগুলোর সম্পূর্ণ সুতা স্থির স্তরে (প্রতি ফ্রেমে নতুন করে আঁকতে হয় না) */
      B.cacheG(g, 'owdone' + s, gg => { for (let st = 0; st < s; st++) if (st !== 3) part(gg, st, 1); if (s >= 3) for (let r = 4; r < 14; r += 3) E('circle', { cx: HX, cy: HY, r, fill: 'none', stroke: '#a8b4c0', 'stroke-width': .5 }, gg);
        B.tx(gg, 180, 296, ['বাতাসে ভেসে সেতু', 'Y আকৃতি — কেন্দ্র তৈরি', 'কাঠামো ও ব্যাসার্ধ (শুকনো সুতা)', 'অস্থায়ী সর্পিল (আঠাহীন)', 'আঠালো সর্পিল — বাইরে থেকে ভেতরে', 'কম্পনে শিকার টের পাওয়া'][s], { fs: 10, a: 'middle', c: C.mu }); });
      if (s === 2) { const nf = Math.floor(FR.length * u), nr = Math.floor(NR * u); B.cacheG(g, 'owlive' + (nf * 1000 + nr), gg => part(gg, 2, u)); } else if (s < 5) part(g, s, u);
      if (s === 4 && u < .9) part(g, 3, 1);
      /* মাকড়সার অবস্থান */
      let sx = HX, sy = HY, sr = 0;
      if (s === 0) { sx = lerp(60, 300, u); sy = lerp(30, 26, u) + 6; sr = PI / 2; }
      else if (s === 1) { sx = lerp(180, HX, u); sy = lerp(30, HY, u); }
      else if (s === 2) { const i = Math.floor(NR * u) % NR, [a, R] = RAD[i], f = (NR * u) % 1; sx = HX + Math.cos(a) * R * Math.sin(f * PI); sy = HY + Math.sin(a) * R * Math.sin(f * PI); sr = a + PI / 2; }
      else if (s === 3) { const p = spiral(12, 70, 11, u); [sx, sy] = p[p.length - 1]; }
      else if (s === 4) { const p = capSp(u); if (p.length) [sx, sy] = p[p.length - 1]; }
      else { sr = PI; }
      B.spider(g, sx, sy, s === 5 ? 1.2 : .9, sr, { wig: u * 30 });
      if (s === 5) { const fx = 238, fy = 104; B.fly(g, fx, fy, 1.6, Math.sin(u * 50) > 0 ? 1 : 0); for (let k = 0; k < 3; k++) E('circle', { cx: fx, cy: fy, r: 8 + k * 6 + (u * 30) % 6, fill: 'none', stroke: FK.alpha('#e0a030', .5 - k * .15), 'stroke-width': 1 }, g); }
    }
  }));

/* ═════════ মাকড়সার দেহ (লেবেলযুক্ত) ═════════ */
V.spiderAnatomy = Object.assign({ t: 'মাকড়সার দেহ ও রেশম তৈরির অঙ্গ', k: ['2d', 'int', 'quiz'], cap: 'মাকড়সা (শ্রেণি Arachnida): দেহ দুই ভাগে — সেফালোথোরাক্স ও উদর, মাঝে সরু বৃন্ত; চার জোড়া হাঁটা পা, এক জোড়া চেলিসেরি (বিষদাঁত) ও এক জোড়া পেডিপাল্প। উদরের ভেতরের রেশম গ্রন্থির তরল প্রোটিন স্পিনারেট দিয়ে বেরিয়ে টানে শক্ত সুতায় পরিণত হয়।' },
  BK.diagram({ W: 360, H: 300, label: 'মাকড়সার দেহ',
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), SC = 4.3, Q = (x, y) => [180 + x * SC, 146 + y * SC];
      B.spider(P('leg'), 180, 146, SC, 0);
      const sg = P('gland'); [[-2.6, 13.4], [0, 14.6], [2.6, 13.4]].forEach(([dx, dy]) => { const [x, y] = Q(dx, dy); E('path', { d: B.ellD(x, y, 1.2 * SC, 2.8 * SC), fill: FK.alpha('#ffffff', .35), stroke: '#ffffff', 'stroke-width': 1, 'stroke-dasharray': '3 2' }, sg); });
      const [sx, sy] = Q(0, 23.4); E('path', { d: `M${f1(sx)} ${f1(sy)}C${f1(sx + 4)} ${f1(sy + 12)} ${f1(sx + 16)} ${f1(sy + 18)} ${f1(sx + 34)} ${f1(sy + 22)}`, stroke: '#c8d4e0', 'stroke-width': 1.4, fill: 'none' }, P('spin'));
      ['ceph', 'abd', 'ped', 'eye', 'chel', 'palp'].forEach(k => P(k));
      hits(this.parts, part, 12); },
    parts: [
      { id: 'ceph', bn: 'সেফালোথোরাক্স (প্রোসোমা)', lb: 'সেফালোথোরাক্স', en: 'Cephalothorax', fn: 'মাথা ও বক্ষ একত্রে যুক্ত সামনের দেহভাগ — চোখ, মুখাঙ্গ ও পা এখানে যুক্ত; ভেতরে মস্তিষ্ক ও চোষক পাকস্থলী।', a: [180, 122], l: [262, 104], an: 'start' },
      { id: 'abd', bn: 'উদর (ওপিস্থোসোমা)', lb: 'উদর', en: 'Abdomen', fn: 'নরম, খণ্ডহীন পেছনের দেহভাগ — হৃৎপিণ্ড, বুক-ফুসফুস, জননাঙ্গ ও রেশম গ্রন্থি থাকে।', a: [197, 185], l: [262, 202], an: 'start' },
      { id: 'ped', bn: 'বৃন্ত (পেডিসেল)', lb: 'বৃন্ত', en: 'Pedicel', fn: 'সেফালোথোরাক্স ও উদরের মাঝের সরু সংযোগ — উদর এদিক-ওদিক ঘুরিয়ে সুতা ফেলতে সাহায্য করে।', a: [180, 152], l: [96, 166], an: 'end' },
      { id: 'eye', bn: 'সরল চোখ (আটটি)', lb: 'আটটি সরল চোখ', en: 'Simple eyes', fn: 'অধিকাংশ মাকড়সার দুই সারিতে আটটি সরল চোখ; জাল-বোনা মাকড়সার দৃষ্টি দুর্বল, তারা কম্পনের ওপর বেশি নির্ভর করে।', a: [180, 105], l: [96, 34], an: 'end' },
      { id: 'chel', bn: 'চেলিসেরি ও বিষদাঁত', lb: 'চেলিসেরি', en: 'Chelicerae', fn: 'মুখের সামনের এক জোড়া উপাঙ্গ; আগায় বাঁকা বিষদাঁত — শিকারের দেহে বিষ ও হজমকারী রস ঢোকায়।', a: [173, 93], l: [220, 16], an: 'start' },
      { id: 'palp', bn: 'পেডিপাল্প', lb: 'পেডিপাল্প', en: 'Pedipalps', fn: 'চেলিসেরির পাশের ছোট পায়ের মতো এক জোড়া উপাঙ্গ — অনুভূতি ও শিকার ধরায় সাহায্য করে; পুরুষে শুক্রাণু স্থানান্তরের অঙ্গ হিসেবেও কাজ করে।', a: [199, 86], l: [262, 54], an: 'start' },
      { id: 'leg', bn: 'চার জোড়া হাঁটা পা', lb: 'হাঁটা পা (4 জোড়া)', en: 'Walking legs', fn: 'সেফালোথোরাক্স থেকে চার জোড়া সন্ধিযুক্ত পা — পায়ের ডগায় নখর ও লোম; জালের সুতা আঁকড়ে ধরে এবং সুতার কম্পন অনুভব করে।', a: [120, 101], l: [100, 76], an: 'end' },
      { id: 'gland', bn: 'রেশম গ্রন্থি', lb: 'রেশম গ্রন্থি', en: 'Silk glands', fn: 'উদরের ভেতরে কয়েক ধরনের গ্রন্থি — ভিন্ন ভিন্ন সুতা (কাঠামো, আঠালো সর্পিল, ডিমের থলি) তৈরি হয়। রেশম তরল প্রোটিন (স্পিড্রয়েন) হিসেবে জমা থাকে।', a: [169, 204], l: [100, 236], an: 'end' },
      { id: 'spin', bn: 'স্পিনারেট', lb: 'স্পিনারেট', en: 'Spinnerets', fn: 'উদরের শেষে তিন জোড়া (সাধারণত) আঙুলের মতো অঙ্গ — অনেক সূক্ষ্ম নল দিয়ে রেশম বের হয়; টানলেই তরল প্রোটিন শক্ত সুতায় পরিণত হয়।', a: [180, 247], l: [262, 262], an: 'start' }
    ]
  }));

/* ═════════ অপত্য যত্ন ═════════ */
const tilapia = (g, x, y, s, open) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), F = B.TS('fish');
  E('path', { d: 'M-30 0L-42 -10L-40 0L-42 10Z', fill: '#8a9670', stroke: F.dk, 'stroke-width': .5 }, gg);
  E('path', { d: 'M-12 -12C-4 -20 14 -20 22 -14L18 -10C8 -14 -4 -14 -12 -10Z', fill: '#7a8a60', stroke: F.dk, 'stroke-width': .4 }, gg);
  for (let i = 0; i < 10; i++) E('path', { d: `M${-10 + i * 3} -12l1 -6`, stroke: F.dk, 'stroke-width': .5 }, gg);
  E('path', { d: `M30 ${f1(-2 - open * 3)}C28 -10 18 -16 4 -16C-12 -16 -26 -10 -30 0C-26 10 -12 14 4 14C18 14 28 8 30 ${f1(2 + open * 3)}`, fill: B.lin(gg, 'fish', 90), stroke: F.dk, 'stroke-width': .7 }, gg);
  for (let i = 0; i < 6; i++) E('path', { d: `M${f1(-20 + i * 7)} -10v18`, stroke: FK.alpha(F.dk, .35), 'stroke-width': 2 }, gg);
  E('path', { d: 'M16 -12Q12 0 16 10', stroke: F.dk, 'stroke-width': .7, fill: 'none' }, gg);
  E('circle', { cx: 22, cy: -6, r: 2.6, fill: '#e8d070', stroke: '#3a3018', 'stroke-width': .4 }, gg); E('circle', { cx: 22, cy: -6, r: 1.2, fill: '#111' }, gg);
  /* গলা ফোলা (ডিম/পোনা মুখে) */
  E('path', { d: 'M14 6C18 12 26 10 28 4', fill: FK.alpha('#c8c4a0', .6), stroke: F.dk, 'stroke-width': .4 }, gg);
  E('path', { d: `M30 ${f1(-2 - open * 3)}L34 ${f1(-1 - open * 4)}M30 ${f1(2 + open * 3)}L33 ${f1(2 + open * 4)}`, stroke: F.dk, 'stroke-width': 1 }, gg); return gg; };
const fry = (g, x, y, a) => { E('path', { d: `M${f1(x)} ${f1(y)}l${f1(-Math.cos(a) * 5)} ${f1(-Math.sin(a) * 5)}`, stroke: '#8a9670', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, g); E('circle', { cx: f1(x), cy: f1(y), r: 1, fill: '#222' }, g); };
const doyel = B.doyel = (g, x, y, s, fl = 1) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${f1(s * fl)} ${f1(s)})` }, g);
  E('path', { d: 'M8 0L28 -10L30 -6L10 4Z', fill: '#1a1a1e' }, gg); E('path', { d: 'M24 -8L30 -6L28 -4Z', fill: '#fff' }, gg);
  E('path', { d: 'M-8 -6C-2 -10 8 -8 12 0C14 6 8 10 0 10C-6 10 -10 6 -10 0C-10 -3 -9 -5 -8 -6Z', fill: '#f4f4f0', stroke: '#6a6a6a', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-8 -6C-2 -10 8 -8 12 0C8 -2 2 -2 -4 -2C-8 -2 -9 -4 -8 -6Z', fill: '#16161a' }, gg);
  E('path', { d: 'M-2 -4C4 -6 10 -2 12 3C6 4 0 3 -4 0Z', fill: '#202024' }, gg); E('path', { d: 'M0 -2L10 1', stroke: '#fff', 'stroke-width': 2 }, gg);
  E('path', { d: 'M-15 -8C-15 -14 -8 -16 -5 -12C-3 -9 -4 -5 -8 -4C-12 -4 -15 -6 -15 -8Z', fill: '#16161a' }, gg); E('circle', { cx: -11, cy: -9.5, r: 1, fill: '#d0d0d0' }, gg);
  E('path', { d: 'M-15 -10L-21 -9L-15 -7Z', fill: '#2a2a2a' }, gg); E('path', { d: 'M-2 10L-3 15M3 10L3 15', stroke: '#5a5a5a', 'stroke-width': 1 }, gg); return gg; };
const goat = (g, x, y, s) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), F = B.TS('furD');
  [[-26, 0], [-18, 0], [18, 0], [26, 0]].forEach(([lx], i) => E('path', { d: `M${lx} -10L${lx + (i % 2 ? 1 : -1)} 18`, stroke: F.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, gg));
  E('path', { d: 'M-32 -12C-34 -26 -20 -32 0 -32C18 -32 32 -28 34 -16C36 -6 30 0 18 -2C6 -4 -8 -4 -20 -2C-28 0 -32 -4 -32 -12Z', fill: B.vol(gg, 'furD'), stroke: F.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M-12 -2C-12 6 -6 8 -2 4C0 2 0 -2 -2 -3Z', fill: '#e8b8a8', stroke: '#9a6a5a', 'stroke-width': .5 }, gg);
  E('path', { d: 'M30 -24C34 -36 40 -42 48 -40C54 -38 56 -32 54 -28C50 -24 44 -22 38 -18Z', fill: F.c, stroke: F.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M46 -40C44 -48 40 -52 36 -52', stroke: '#8a7a6a', 'stroke-width': 1.8, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('path', { d: 'M40 -38C34 -36 32 -32 34 -30', fill: F.dk }, gg); E('circle', { cx: 47, cy: -35, r: 1.1, fill: '#e8c040' }, gg);
  E('path', { d: 'M-32 -16C-38 -20 -40 -26 -36 -28', stroke: F.dk, 'stroke-width': 2, fill: 'none' }, gg); return gg; };
const kid = (g, x, y, s, k) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  [[-12], [-6], [8], [13]].forEach(([lx]) => E('path', { d: `M${lx} -4L${lx} 14`, stroke: '#8a7258', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, gg));
  E('path', { d: 'M-16 -8C-16 -16 -4 -18 8 -18C16 -18 18 -12 16 -6C12 -2 0 -2 -12 -2C-16 -2 -16 -5 -16 -8Z', fill: '#c8a478', stroke: '#7a5a38', 'stroke-width': .6 }, gg);
  E('path', { d: `M14 -12C20 ${f1(-20 + k * 2)} 26 ${f1(-26 + k * 2)} 30 ${f1(-24 + k * 2)}C32 ${f1(-20 + k * 2)} 28 ${f1(-14 + k * 2)} 22 -10Z`, fill: '#c8a478', stroke: '#7a5a38', 'stroke-width': .6 }, gg);
  E('circle', { cx: 26, cy: f1(-22 + k * 2), r: .9, fill: '#111' }, gg); return gg; };
const PC = {
  fish: ['মাছ: মুখে পোনা লালন', 'তেলাপিয়া — মুখে ডিম ও পোনা রাখা', 'মোজাম্বিক তেলাপিয়ার মা নিষিক্ত ডিম মুখে নিয়ে কয়েক দিন না খেয়ে বহন করে (মাউথব্রুডিং)। পোনা বের হওয়ার পরও বিপদ দেখলে মা মুখ খোলে আর পোনারা দ্রুত মুখের ভেতরে ঢুকে আশ্রয় নেয় — মা ও পোনা দুজনের আচরণই সহজাত।'],
  toad: ['উভচর: পায়ে ডিম বহন', 'মিডওয়াইফ ব্যাঙ — পুরুষ পায়ে ডিমের মালা বহন করে', 'ইউরোপের মিডওয়াইফ ব্যাঙে (Alytes) পুরুষ ডিমের মালা পেছনের পায়ে পেঁচিয়ে কয়েক সপ্তাহ বহন করে, শুকিয়ে না যেতে মাঝে মাঝে পানিতে ভেজায় এবং ফোটার সময় পানিতে ছেড়ে দেয়।'],
  bird: ['পাখি: খাওয়ানো', 'দোয়েল — হাঁ-মুখ ছানাকে খাওয়ানো', 'পাখি ডিমে তা দেয় এবং ছানাদের খাওয়ায়। ছানার উজ্জ্বল হলুদ-কমলা হাঁ-মুখ ও ডাক মা-বাবার খাওয়ানোর আচরণের সংকেত-উদ্দীপনা; যে ছানা বেশি হাঁ করে, সে বেশি খাবার পায়।'],
  mam: ['স্তন্যপায়ী: দুধ খাওয়ানো', 'ছাগল — বাচ্চাকে দুধ খাওয়ানো', 'স্তন্যপায়ীতে মা স্তনগ্রন্থির দুধ খাইয়ে সন্তানের পুষ্টি ও অনাক্রম্যতা (শালদুধে অ্যান্টিবডি) জোগায়, উষ্ণ রাখে ও বিপদ থেকে রক্ষা করে — সবচেয়ে দীর্ঘ ও ব্যয়বহুল অপত্য যত্ন। মানুষে এ যত্ন বছরের পর বছর চলে।']
};
V.parentalCare = Object.assign({}, B.seg({
  id: 'pcr', t: 'অপত্যের প্রতি যত্ন: বিভিন্ন প্রাণীতে', H: 260, def: 'fish', types: PC,
  cap: 'অপত্য যত্ন (Parental care): সন্তানের বেঁচে থাকার সম্ভাবনা বাড়াতে মা-বাবার যেকোনো আচরণ — বাসা বানানো, ডিম পাহারা ও তা দেওয়া, বহন করা, খাওয়ানো ও রক্ষা করা। অধিকাংশই সহজাত; যত্ন যত বেশি, প্রতিবার সন্তান তত কম।',
  art(g, C, ty) {
    if (ty === 'fish') { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: B.lin(g, 'wtr', 90) }, g); E('path', { d: 'M0 184Q180 176 360 186V200H0Z', fill: '#c8b48a' }, g); }
    else if (ty === 'toad') { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: FK.alpha('#e6ece0', .8) }, g); E('rect', { x: 0, y: 170, width: 360, height: 30, fill: B.lin(g, 'soil', 90) }, g); }
    else { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: FK.alpha('#e8f0e0', .7) }, g); E('rect', { x: 0, y: 176, width: 360, height: 24, fill: B.lin(g, 'grass', 90) }, g); }
    if (ty === 'toad') { B.toad(g, 170, 172, 1.7); for (let i = 0; i < 16; i++) { const a = i / 16 * PI * 1.6 - PI * .3, x = 110 + Math.cos(a) * 18, y = 160 + Math.sin(a) * 10; E('circle', { cx: f1(x), cy: f1(y), r: 3.6, fill: '#f0d880', stroke: '#a89040', 'stroke-width': .5 }, g); E('circle', { cx: f1(x + .6), cy: f1(y - .6), r: 1.2, fill: '#3a3020' }, g); }
      B.tx(g, 110, 136, 'ডিমের মালা', { fs: 9.6, a: 'middle', c: '#6a5a20' }); }
    if (ty === 'bird') { E('path', { d: 'M120 150C120 176 150 186 180 186C210 186 240 176 240 150Z', fill: B.lin(g, 'wood', 90), stroke: '#5c4022' }, g); for (let i = 0; i < 18; i++) E('path', { d: `M${124 + i * 6.4} 152q3 6 6 2`, stroke: '#8a6a3a', 'stroke-width': .7, fill: 'none' }, g); }
    if (ty === 'mam') goat(g, 190, 150, 1.9);
    B.tx(g, 180, 222, PC[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 244, { fish: 'মুখ = নিরাপদ আশ্রয়', toad: 'পুরুষের যত্ন — ডিম শুকায় না', bird: 'হাঁ-মুখ = খাওয়ানোর সংকেত', mam: 'দুধ, উষ্ণতা ও সুরক্ষা' }[ty], { fs: 10, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) { const ph = (t * .3) % 1;
    if (ty === 'fish') { const open = ph < .7 ? cl(ph / .15) : cl((1 - ph) / .3); tilapia(g, 190, 110, 2.4, open);
      for (let i = 0; i < 14; i++) { const r0 = 40 + B.rnd(i) * 90, a0 = B.rnd(i + 9) * 2 * PI, k = cl((ph - .1 - i * .03) / .4), mx = 190 + 34 * 2.4, my = 110, x = lerp(mx + Math.cos(a0) * r0 * .7 + 30, mx, k), y = lerp(my + Math.sin(a0) * r0 * .5, my, k); if (k < 1) fry(g, x, y, Math.atan2(my - y, mx - x)); }
      if (ph > .15 && ph < .5) B.tx(g, 300, 30, 'বিপদ! পোনারা মায়ের মুখে', { fs: 10, a: 'middle', c: '#a8201a', w: 700 }); }
    if (ty === 'bird') { for (let i = 0; i < 3; i++) { const x = 156 + i * 24, gap = Math.sin(t * 6 + i * 2) * .5 + .5; E('circle', { cx: x, cy: 146, r: 9, fill: '#b8a890', stroke: '#6a5a40', 'stroke-width': .5 }, g); E('path', { d: `M${x - 6} ${f1(136 - gap * 6)}L${x} ${f1(124 - gap * 10)}L${x + 6} ${f1(136 - gap * 6)}Z`, fill: '#f6b030', stroke: '#b07010', 'stroke-width': .6 }, g); }
      const k = Math.sin(ph * PI); doyel(g, lerp(300, 214, k), lerp(60, 92, k), 2.2, 1); if (k > .9) E('path', { d: 'M180 110l6 4', stroke: '#6a4a2a', 'stroke-width': 2 }, g); }
    if (ty === 'mam') kid(g, 178, 160, 1.8, Math.sin(t * 6) * .8);
  }
}));

/* ═════════ সন্তানসংখ্যা বনাম যত্ন (লগ স্কেল) ═════════ */
const OC = [['আটলান্টিক কড', 2e6, 'যত্ন নেই — ডিম পানিতে ছেড়ে দেয়'], ['কুনো ব্যাঙ', 1e4, 'যত্ন নেই বললেই চলে'], ['তেলাপিয়া', 500, 'মুখে ডিম ও পোনা বহন'], ['দোয়েল', 5, 'তা দেওয়া ও খাওয়ানো'], ['মানুষ', 1, 'বহু বছরের যত্ন']];
V.offspringCare = Object.assign({}, B.seg({
  id: 'ofc', t: 'সন্তানসংখ্যা বনাম অপত্য যত্ন', H: 270, def: 'log', types: { log: ['লগ স্কেল', 'প্রতিবার প্রজননে আনুমানিক ডিম বা সন্তানের সংখ্যা', 'যে প্রাণী যত বেশি যত্ন নেয়, সে তত কম সন্তান জন্ম দেয় — শক্তি সীমিত, তাই "অনেক সন্তান, কম যত্ন" বা "কম সন্তান, বেশি যত্ন" — দুটি কৌশল। কডের লক্ষ লক্ষ ডিমের অতি সামান্য অংশ বড় হয়; মানুষের সন্তান প্রায় সবাই বাঁচে।'] },
  cap: 'অনুভূমিক দণ্ড লগ স্কেলে (প্রতি দাগে 10 গুণ)। সংখ্যাগুলো আনুমানিক ও প্রজাতিভেদে অনেক বদলায় — উদ্দেশ্য শুধু প্রবণতা দেখানো।',
  art(g, C) { const X0 = 112, W = 228, lx = v => X0 + Math.log10(v) / 7 * W;
    for (let p = 0; p <= 7; p++) { const x = lx(10 ** p); E('path', { d: `M${f1(x)} 24V212`, stroke: FK.alpha(C.fg, .12) }, g); B.tx(g, x, 226, p === 0 ? '1' : '10<tspan baseline-shift="super" font-size="68%">' + p + '</tspan>', { fs: 9, a: 'middle', c: C.mu }); }
    OC.forEach(([n, v, d], i) => { const y = 30 + i * 38; B.tx(g, X0 - 6, y + 12, n, { fs: 10.4, a: 'end', w: 700, c: C.fg }); E('rect', { x: X0, y, width: f1(Math.max(3, lx(v) - X0)), height: 16, rx: 4, fill: BK.pal(i) }, g); B.tx(g, X0 + 4, y + 28, d, { fs: 9, c: C.mu }); });
    B.tx(g, 226, 244, 'প্রতিবার ডিম/সন্তানের সংখ্যা (লগ স্কেল)', { fs: 9.6, a: 'middle', c: C.mu });
    B.arrow(g, 12, 36, 12, 204, '#3a7a4a', { w: 1.6 }); const tg = E('g', { transform: 'translate(24 120) rotate(90)' }, g); B.tx(tg, 0, 0, 'যত্ন বাড়ে, সন্তান কমে', { fs: 9.6, a: 'middle', c: '#3a7a4a' }); }
}));
})();
