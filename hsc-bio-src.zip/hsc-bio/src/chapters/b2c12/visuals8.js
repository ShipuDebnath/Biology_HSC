/* ═══════════════════════════════════════════════════════════════════
   visuals8 — প্যাভলভের তত্ত্ব ও কন্ডিশনিং:
   pavlovSetup (পরীক্ষার ব্যবস্থা, লেবেলযুক্ত), conditioningSteps (চিরায়ত কন্ডিশনিংয়ের ধাপ),
   conditioningCurve (অর্জন, বিলোপ, স্বতঃস্ফূর্ত পুনরুদ্ধার), salivaryReflex (লালার প্রতিবর্তের পথ), skinnerBox
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ কুকুর (পার্শ্বদৃশ্য, বামমুখী) — দাঁড়ানো ═════════ */
B.dog = (g, x, y, s, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), F = B.TS('fur');
  const leg = (lx, back, off) => E('path', { d: `M${lx} -30C${lx + (back ? 4 : 0)} -18 ${lx + (back ? 2 : -1)} -8 ${lx + off} 0`, stroke: back ? '#8a6038' : F.c, 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, gg);
  leg(30, true, 1); leg(-18, true, -1);
  /* লেজ */
  E('path', { d: `M40 -44C52 -50 56 ${f1(-60 + (o.wag || 0) * 6)} 54 ${f1(-68 + (o.wag || 0) * 8)}`, stroke: F.c, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, gg);
  /* দেহ */
  E('path', { d: 'M-26 -44C-24 -56 -6 -58 14 -56C30 -55 42 -52 44 -42C46 -32 38 -26 24 -26C8 -26 -8 -26 -18 -28C-24 -30 -27 -36 -26 -44Z', fill: B.vol(gg, 'fur'), stroke: F.dk, 'stroke-width': .7 }, gg);
  E('path', { d: 'M-22 -32C-10 -28 10 -28 26 -28', stroke: FK.alpha('#f4e6cc', .7), 'stroke-width': 3, fill: 'none' }, gg);
  leg(34, false, 2); leg(-14, false, -2);
  /* গলা ও মাথা */
  E('path', { d: 'M-18 -50C-26 -60 -30 -70 -32 -76L-22 -82C-16 -72 -10 -60 -6 -52Z', fill: F.c, stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M-24 -86C-22 -96 -10 -98 -6 -90C-2 -84 -6 -76 -14 -74L-26 -72Z', fill: B.vol(gg, 'fur'), stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M-26 -86C-34 -86 -46 -84 -50 -80C-52 -76 -48 -72 -42 -72C-36 -72 -30 -72 -24 -74Z', fill: F.c, stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M-48 -82C-51 -82 -52 -79 -50 -78', fill: '#2a1a10', stroke: '#2a1a10', 'stroke-width': 2 }, gg);
  E('path', { d: 'M-48 -74C-42 -73 -34 -73 -28 -75', stroke: '#5a3a20', 'stroke-width': .8, fill: 'none' }, gg);
  E('circle', { cx: -24, cy: -88, r: 1.6, fill: '#1a120c' }, gg);
  /* কান (ঝোলা) */
  E('path', { d: 'M-14 -94C-8 -96 -4 -90 -6 -80C-8 -74 -12 -76 -12 -82Z', fill: '#8a6038', stroke: F.dk, 'stroke-width': .6 }, gg);
  /* ফিস্টুলা: গালের নিচে নল (প্যারোটিড নালির মুখ) */
  if (o.tube) E('circle', { cx: -30, cy: -76, r: 2.2, fill: '#e8e0d0', stroke: '#8a8070', 'stroke-width': .6 }, gg);
  return gg; };
const bell = (g, x, y, s, ring) => { const a = ring ? Math.sin(ring * 30) * 14 : 0, gg = E('g', { transform: `translate(${x} ${y}) rotate(${f1(a)}) scale(${s})` }, g);
  E('path', { d: 'M-10 6C-10 -6 -6 -12 0 -12C6 -12 10 -6 10 6L13 9H-13Z', fill: B.vol(gg, 'beak'), stroke: '#8a5a10', 'stroke-width': .7 }, gg); E('circle', { cx: 0, cy: 11, r: 2.4, fill: '#8a5a10' }, gg); E('path', { d: 'M0 -12V-16', stroke: '#6a6050', 'stroke-width': 1.4 }, gg);
  if (ring) for (let k = 1; k <= 2; k++) E('path', { d: `M${14 + k * 4} -6q4 6 0 12M${-14 - k * 4} -6q-4 6 0 12`, stroke: FK.alpha('#c08018', .7 - k * .2), 'stroke-width': 1, fill: 'none' }, g.lastChild ? gg : gg); return gg; };
const bowl = (g, x, y, s, full) => { E('path', { d: `M${x - 14 * s} ${y - 6 * s}H${x + 14 * s}L${x + 10 * s} ${y}H${x - 10 * s}Z`, fill: '#8aa0b0', stroke: '#4a6070', 'stroke-width': .7 }, g); if (full) E('path', { d: B.ellD(x, y - 7 * s, 11 * s, 3 * s), fill: '#a8703a' }, g); };
const drops = (g, x, y, t, n = 3) => { for (let i = 0; i < n; i++) { const k = (t * 1.4 + i / n) % 1; E('path', { d: `M${f1(x)} ${f1(y + k * 26)}q2 3 0 5q-2 -2 0 -5Z`, fill: '#9ac8e8', stroke: '#4a8ab0', 'stroke-width': .4, opacity: f1(1 - k * .6) }, g); } };

/* ═════════ প্যাভলভের পরীক্ষার ব্যবস্থা ═════════ */
V.pavlovSetup = Object.assign({ t: 'প্যাভলভের পরীক্ষার ব্যবস্থা', k: ['2d', 'anim', 'int', 'quiz'], cap: 'রুশ শারীরতত্ত্ববিদ ইভান প্যাভলভ (পরিপাক নিয়ে কাজের জন্য 1904 সালে নোবেল) কুকুরের লালাগ্রন্থির নালি অস্ত্রোপচারে গালের বাইরে এনে নলে লালা সংগ্রহ করতেন। শব্দনিরোধক কক্ষে কুকুর হার্নেসে বাঁধা থাকত; পর্যবেক্ষক পাশের ঘর থেকে উদ্দীপনা দিতেন ও লালার ফোঁটা গুনতেন।' },
  BK.diagram({ W: 360, H: 300, label: 'প্যাভলভের পরীক্ষা', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      E('rect', { x: 0, y: 0, width: 300, height: 300, fill: FK.alpha('#efe8da', .7) }, g);
      /* টেবিল ও হার্নেস ফ্রেম */
      E('rect', { x: 40, y: 220, width: 200, height: 10, fill: B.lin(g, 'wood', 90), stroke: '#5c4022' }, P('frame')); E('path', { d: 'M50 230V292M230 230V292', stroke: '#5c4022', 'stroke-width': 6 }, P('frame'));
      E('path', { d: 'M60 220V90H220V220', stroke: '#7a7060', 'stroke-width': 3, fill: 'none' }, P('frame')); E('path', { d: 'M120 90V156M170 90V156', stroke: '#9a8e70', 'stroke-width': 1.6 }, P('frame'));
      B.dog(P('dog'), 150, 220, 1.35, { tube: true });
      /* লালার নল → মাপার নল */
      E('path', { d: 'M110 117C100 130 90 150 92 176', stroke: '#c8d0d8', 'stroke-width': 3, fill: 'none' }, P('tube')); E('path', { d: 'M110 117C100 130 90 150 92 176', stroke: '#8a98a8', 'stroke-width': .6, fill: 'none' }, P('tube'));
      E('rect', { x: 84, y: 176, width: 16, height: 40, rx: 2, fill: FK.alpha('#e8f2fa', .9), stroke: '#7a8a9a' }, P('cyl')); for (let i = 1; i < 5; i++) E('path', { d: `M84 ${176 + i * 8}h5`, stroke: '#7a8a9a', 'stroke-width': .6 }, P('cyl')); E('rect', { x: 85, y: 200, width: 14, height: 15, fill: '#bcdcf0' }, P('cyl'));
      /* কাইমোগ্রাফ */
      E('rect', { x: 300, y: 150, width: 46, height: 64, rx: 4, fill: '#f4f4ee', stroke: '#7a7a70', 'stroke-width': 1 }, P('kymo')); E('path', { d: 'M304 196L312 192L320 194L328 180L336 172L342 170', stroke: '#2a2a2a', 'stroke-width': 1, fill: 'none' }, P('kymo')); E('path', { d: 'M100 196C160 250 260 240 300 200', stroke: FK.alpha('#7a7a70', .6), 'stroke-width': .8, 'stroke-dasharray': '3 3', fill: 'none' }, P('kymo'));
      /* ঘণ্টা ও খাবারের ব্যবস্থা */
      bell(P('bell'), 40, 60, 1.2, 0); E('path', { d: 'M40 44V0', stroke: '#6a6050' }, P('bell'));
      bowl(P('food'), 66, 214, 1.1, true); E('path', { d: 'M66 206V150L28 120', stroke: '#8a98a8', 'stroke-width': 2, fill: 'none' }, P('food'));
      /* দেয়াল ও পর্যবেক্ষণ জানালা */
      E('rect', { x: 296, y: 0, width: 8, height: 300, fill: '#a89a80' }, P('wall')); E('rect', { x: 294, y: 40, width: 12, height: 40, fill: '#bcdcf0', stroke: '#6a7a8a' }, P('wall'));
      hits(this.parts, part, 12); },
    idle(g, C, t) { const ph = (t * .25) % 1; if (ph < .5) { bell(g, 40, 60, 1.2, ph * 4); } if (ph > .2 && ph < .8) drops(g, 92, 178, t, 2); },
    parts: [
      { id: 'dog', bn: 'কুকুর (হার্নেসে বাঁধা)', lb: 'কুকুর', en: 'Dog', fn: 'ক্ষুধার্ত কুকুর হার্নেসে দাঁড় করানো, যাতে নড়াচড়া কম থাকে এবং লালা নিয়মিত মাপা যায়।', a: [180, 160], l: [210, 16], an: 'start' },
      { id: 'tube', bn: 'লালার নল (ফিস্টুলা)', lb: 'লালার নল', en: 'Salivary fistula', fn: 'অস্ত্রোপচারে প্যারোটিড লালাগ্রন্থির নালির মুখ গালের বাইরে আনা হয়; নল দিয়ে লালা বাইরে সংগ্রহ হয়।', a: [100, 140], l: [20, 140], an: 'start' },
      { id: 'cyl', bn: 'মাপার নল', lb: 'মাপার নল', en: 'Graduated tube', fn: 'লালার ফোঁটা বা আয়তন মাপা হয় — সাড়ার মাত্রা সংখ্যায় প্রকাশ।', a: [92, 196], l: [20, 178], an: 'start' },
      { id: 'kymo', bn: 'কাইমোগ্রাফ (রেকর্ডার)', lb: 'কাইমোগ্রাফ', en: 'Kymograph', fn: 'ঘূর্ণায়মান ড্রামে লালা নিঃসরণ সময়ের সাথে আঁকা হয়।', a: [322, 182], l: [352, 236], an: 'end' },
      { id: 'bell', bn: 'ঘণ্টা বা মেট্রোনোম (শর্তাধীন উদ্দীপনা)', lb: 'ঘণ্টা', en: 'Bell / metronome', fn: 'প্রথমে নিরপেক্ষ উদ্দীপনা; খাবারের সাথে বারবার জোড়া দিলে শর্তাধীন উদ্দীপনা হয়ে ওঠে। প্যাভলভ প্রায়ই মেট্রোনোম, বাঁশি বা বৈদ্যুতিক ঘণ্টা ব্যবহার করতেন।', a: [40, 66], l: [20, 100], an: 'start' },
      { id: 'food', bn: 'খাবার (শর্তহীন উদ্দীপনা)', lb: 'খাবার', en: 'Food', fn: 'মাংসের গুঁড়া মুখে দিলে স্বাভাবিকভাবেই লালা ঝরে — এটি শর্তহীন উদ্দীপনা ও শর্তহীন সাড়া।', a: [66, 208], l: [20, 262], an: 'start' },
      { id: 'frame', bn: 'হার্নেস ফ্রেম ও টেবিল', lb: 'হার্নেস ফ্রেম', en: 'Harness frame', fn: 'কুকুরকে নির্দিষ্ট অবস্থানে রাখে।', a: [220, 150], l: [260, 120], an: 'start' },
      { id: 'wall', bn: 'পর্যবেক্ষণ জানালাসহ দেয়াল', lb: 'পর্যবেক্ষণ জানালা', en: 'Observation window', fn: 'পরীক্ষক অন্য ঘর থেকে দেখেন, যাতে তার উপস্থিতি বা নড়াচড়া কুকুরের কাছে বাড়তি উদ্দীপনা না হয়।', a: [300, 60], l: [352, 30], an: 'end' }
    ]
  }));

/* ═════════ চিরায়ত কন্ডিশনিংয়ের ধাপ ═════════ */
const head = (g, x, y, s) => { const gg = E('g', { transform: `translate(${x} ${y}) scale(${s})` }, g), F = B.TS('fur');
  E('path', { d: 'M10 30C20 10 22 -10 12 -22C4 -30 -8 -30 -14 -22L-20 -10C-36 -10 -50 -6 -54 0C-56 6 -52 10 -44 10C-36 10 -28 10 -20 8C-16 18 -6 28 10 30Z', fill: B.vol(gg, 'fur'), stroke: F.dk, 'stroke-width': .8 }, gg);
  E('path', { d: 'M-52 -4C-55 -4 -56 0 -54 1', stroke: '#2a1a10', 'stroke-width': 3 }, gg); E('circle', { cx: -14, cy: -14, r: 2.2, fill: '#1a120c' }, gg);
  E('path', { d: 'M2 -26C12 -28 16 -18 14 -4C12 4 6 2 6 -6Z', fill: '#8a6038', stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: 'M-50 6C-40 8 -30 8 -22 6', stroke: '#5a3a20', 'stroke-width': .8, fill: 'none' }, gg); return gg; };
const tag = (g, x, y, t, c) => { const w = t.length * 7 + 14; E('rect', { x: x - w / 2, y: y - 11, width: w, height: 20, rx: 10, fill: FK.alpha(c, .15), stroke: c }, g); B.tx(g, x, y + 3.5, t, { fs: 10, a: 'middle', w: 700, c }); };
const CS = [
  { t: 'খাবার → লালা', en: 'UCS → UCR', d: 'খাবার মুখে পড়লেই কুকুরের লালা ঝরে — এটি জন্মগত, শেখা লাগে না। খাবার = শর্তহীন উদ্দীপনা (UCS), লালা = শর্তহীন সাড়া (UCR)।' },
  { t: 'ঘণ্টা → লালা নেই', en: 'NS → no salivation', d: 'শুধু ঘণ্টা বাজালে কুকুর কান খাড়া করে তাকায় (অভিমুখী সাড়া), কিন্তু লালা ঝরে না — ঘণ্টা এখানে নিরপেক্ষ উদ্দীপনা (NS)।' },
  { t: 'ঘণ্টা + খাবার, বারবার', en: 'Acquisition', d: 'প্রতিবার ঘণ্টা বাজানোর অল্প পরে (প্রায় আধা সেকেন্ডের মধ্যে) খাবার দেওয়া হয় — বহুবার। ঘণ্টা ও খাবারের মধ্যে সংযোগ তৈরি হয় — অর্জন পর্যায়।' },
  { t: 'শুধু ঘণ্টা → লালা', en: 'CS → CR', d: 'এখন খাবার ছাড়া শুধু ঘণ্টা বাজালেই লালা ঝরে। ঘণ্টা = শর্তাধীন উদ্দীপনা (CS), এ লালা = শর্তাধীন সাড়া (CR) — নতুন শেখা প্রতিবর্ত।' },
  { t: 'বিলোপ', en: 'Extinction', d: 'এরপর বারবার শুধু ঘণ্টা বাজালে কিন্তু খাবার না দিলে লালার পরিমাণ ধীরে ধীরে কমে প্রায় শূন্যে নামে — শর্তাধীন সাড়ার বিলোপ।' },
  { t: 'স্বতঃস্ফূর্ত পুনরুদ্ধার', en: 'Spontaneous recovery', d: 'কিছুদিন বিশ্রামের পর আবার ঘণ্টা বাজালে কিছুটা লালা ফিরে আসে — শেখা সংযোগ পুরো মুছে যায়নি, চাপা পড়েছিল।' }
];
V.conditioningSteps = Object.assign({ t: 'চিরায়ত কন্ডিশনিং: প্যাভলভের ধাপ', k: ['2d', 'anim', 'steps'], cap: 'চিরায়ত (ক্লাসিক্যাল) কন্ডিশনিং: একটি নিরপেক্ষ উদ্দীপনাকে (ঘণ্টা) একটি শর্তহীন উদ্দীপনার (খাবার) সাথে বারবার জোড়া দিলে নিরপেক্ষ উদ্দীপনাটি একাই সাড়া (লালা) জাগাতে শেখে। একে শর্তাধীন প্রতিবর্তও বলা হয়।' },
  BK.steps({ W: 360, H: 260, label: 'কন্ডিশনিং', dur: 3.2, stages: CS,
    draw(g, C, s, u) {
      const ring = (s === 1 || s === 2 || s === 3 || s === 4 || s === 5), food = s === 0 || s === 2;
      /* স্থির অংশ (কুকুর, খাবার, ধাপের লেবেল) আলাদা স্তরে */
      B.cacheG(g, 'cshead', gg => head(gg, 210, 120, 1.6));
      B.cacheG(g, 'csbowl' + (food ? 1 : 0), gg => { if (food) bowl(gg, 110, 200, 1.6, true); });
      B.cacheG(g, 'cstag' + s, gg => { const L = [['UCS', 'UCR'], ['NS', 'লালা নেই'], ['NS + UCS', 'UCR'], ['CS', 'CR'], ['CS (খাবার নেই)', 'CR কমে'], ['CS (বিশ্রামের পর)', 'CR কিছুটা ফেরে']][s];
        tag(gg, 90, 40, L[0], '#2a6ab0'); B.arrow(gg, 90 + L[0].length * 3.5 + 12, 40, 200, 40, FK.alpha(C.fg, .5), { w: 1.2 }); tag(gg, 260, 40, L[1], s === 1 ? '#8a8a8a' : '#c0392b');
        E('rect', { x: 40, y: 228, width: 280, height: 12, rx: 6, fill: FK.alpha(C.fg, .08) }, gg); B.tx(gg, 40, 222, 'লালার পরিমাণ', { fs: 9.6, c: C.mu }); });
      if (ring) bell(g, 300, 60, 1.4, u < .6 ? u * 3 : 0);
      const amt = [1, 0, 1, .85, Math.max(.1, 1 - u), .4][s], saliva = amt > .05 && (s !== 1);
      if (saliva && u > .3) drops(g, 134, 138, u * 4, Math.max(1, Math.round(amt * 4)));
      E('rect', { x: 40, y: 228, width: f1(280 * (s === 1 ? 0 : amt)), height: 12, rx: 6, fill: '#4a8ab0' }, g);
    }
  }));

/* ═════════ কন্ডিশনিংয়ের লেখচিত্র ═════════ */
const ACQ = n => 1 - Math.exp(-n / 2.6), EXT = (n) => Math.exp(-n / 2.2);
V.conditioningCurve = Object.assign({}, B.seg({
  id: 'ccv', t: 'অর্জন, বিলোপ ও স্বতঃস্ফূর্ত পুনরুদ্ধার', H: 260, def: 'all', types: { all: ['লেখচিত্র', 'প্রতি প্রচেষ্টায় শর্তাধীন সাড়া (লালা)', 'অর্জন: CS + UCS জোড়ায় সাড়া দ্রুত বেড়ে স্থির হয়। বিলোপ: শুধু CS দিলে সাড়া কমে। বিশ্রামের পর প্রথম CS এ সাড়া আংশিক ফিরে আসে (স্বতঃস্ফূর্ত পুনরুদ্ধার), আবার জোড়া দিলে আগের চেয়ে দ্রুত পুনঃশিখন হয়।'] },
  cap: 'লেখচিত্রটি গুণগত — উল্লম্ব অক্ষে লালার আপেক্ষিক পরিমাণ। অনুভূমিক অক্ষে প্রচেষ্টার ক্রম।',
  art(g, C) { const P = B.axes(g, C, [40, 26, 300, 170], { xr: [0, 34], yr: [0, 1.15], xt: [], yt: [], lx: 'প্রচেষ্টা →', ly: 'লালা (আপেক্ষিক)' });
    const pts = []; for (let n = 1; n <= 12; n++) pts.push([n, ACQ(n)]); for (let n = 1; n <= 10; n++) pts.push([12 + n, ACQ(12) * EXT(n)]); pts.push([26, .42], [27, .2], [28, .09]); for (let n = 1; n <= 5; n++) pts.push([28 + n, ACQ(12) * (1 - Math.exp(-n / 1.2))]);
    [[0, 12.5, 'অর্জন (CS + UCS)', '#2a6ab0'], [12.5, 22.5, 'বিলোপ (শুধু CS)', '#c0392b'], [25.5, 28.5, 'পুনরুদ্ধার', '#a86a10'], [28.5, 34, 'পুনঃশিখন', '#3a7a4a']].forEach(([a, b, l, c], bi) => { const [x1] = P(a, 0), [x2] = P(b, 0); E('rect', { x: x1, y: 26, width: x2 - x1, height: 170, fill: FK.alpha(c, .07) }, g); B.tx(g, (x1 + x2) / 2, bi === 2 ? 56 : 40, l, { fs: 8.8, a: 'middle', c, w: 700 }); });
    const [r1] = P(23.5, 0), [r2] = P(25.5, 0); E('path', { d: `M${r1} 196V30M${r2} 196V30`, stroke: FK.alpha(C.fg, .3), 'stroke-dasharray': '3 3' }, g); B.tx(g, (r1 + r2) / 2, 212, 'বিশ্রাম', { fs: 8.8, a: 'middle', c: C.mu });
    let d = ''; pts.forEach(([n, v], i) => { const [x, y] = P(n, v); d += (i && n !== 26 ? 'L' : 'M') + f1(x) + ' ' + f1(y); E('circle', { cx: f1(x), cy: f1(y), r: 2.6, fill: C.fg }, g); }); E('path', { d, stroke: C.fg, 'stroke-width': 1.4, fill: 'none' }, g); }
}));

/* ═════════ লালার প্রতিবর্তের পথ ═════════ */
V.salivaryReflex = Object.assign({ t: 'কুকুরের লালার প্রতিবর্ত: শর্তহীন ও শর্তাধীন পথ', k: ['2d', 'anim', 'int', 'quiz'], cap: 'শর্তহীন পথ: জিহ্বার স্বাদকোরক → সংবেদী স্নায়ু (সপ্তম ও নবম করোটিক স্নায়ু) → মেডুলার লালা-কেন্দ্র → প্যারাসিমপ্যাথেটিক স্নায়ু → লালাগ্রন্থি। শর্তাধীন পথ: কান → শ্রবণ কর্টেক্স → শেখার ফলে তৈরি নতুন সংযোগ → একই লালা-কেন্দ্র। প্যাভলভ এ নতুন সংযোগকে গুরুমস্তিষ্কের কর্টেক্সে "অস্থায়ী সংযোগ" বলেছিলেন।' },
  BK.diagram({ W: 360, H: 290, label: 'লালার প্রতিবর্ত', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), F = B.TS('fur');
      /* মাথার রূপরেখা (অর্ধস্বচ্ছ) */
      E('path', { d: 'M300 250C320 200 324 120 290 70C260 30 200 26 170 50L140 92C90 92 46 104 34 120C28 136 40 148 60 148C90 148 120 150 140 146C160 190 220 250 300 250Z', fill: FK.alpha(F.lt, .55), stroke: F.dk, 'stroke-width': 1 }, g);
      E('path', { d: 'M40 116C34 118 32 124 36 128', stroke: '#2a1a10', 'stroke-width': 5 }, g);
      /* মস্তিষ্ক */
      E('path', { d: 'M196 76C210 52 260 50 280 74C292 90 290 116 274 128C252 140 214 138 200 120C190 108 190 90 196 76Z', fill: B.vol(g, 'gm'), stroke: B.TS('gm').dk, 'stroke-width': .8 }, P('cortex'));
      E('path', { d: 'M250 126C254 140 256 152 252 164', stroke: B.TS('gm').dk, 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round' }, P('med'));
      E('circle', { cx: 252, cy: 150, r: 5, fill: '#e0a030', stroke: '#8a5410' }, P('med'));
      /* জিহ্বা ও স্বাদকোরক */
      E('path', { d: 'M48 140C80 136 120 138 150 140C140 150 100 152 56 150Z', fill: B.vol(g, 'tng'), stroke: B.TS('tng').dk, 'stroke-width': .7 }, P('taste'));
      for (let i = 0; i < 6; i++) E('circle', { cx: 70 + i * 13, cy: 141, r: 1.6, fill: '#a8424a' }, P('taste'));
      /* লালাগ্রন্থি */
      E('path', { d: B.ellD(214, 170, 18, 12, -20), fill: B.vol(g, 'pan'), stroke: '#ae8350', 'stroke-width': .7 }, P('gland')); E('path', { d: B.ellD(170, 182, 14, 9, -10), fill: B.vol(g, 'pan'), stroke: '#ae8350', 'stroke-width': .7 }, P('gland')); E('path', { d: B.ellD(132, 158, 12, 5, 0), fill: B.vol(g, 'pan'), stroke: '#ae8350', 'stroke-width': .7 }, P('gland'));
      E('path', { d: 'M200 166C170 150 140 148 110 146', stroke: '#c8a070', 'stroke-width': 1.4, fill: 'none' }, P('gland'));
      /* কান */
      E('path', { d: 'M282 70C300 60 316 70 314 96', stroke: F.dk, 'stroke-width': 1, fill: FK.alpha('#8a6038', .4) }, P('ear'));
      /* পথ */
      E('path', { d: sm([[100, 142], [150, 160], [200, 172], [236, 166], [248, 152]], false), stroke: '#2a6ab0', 'stroke-width': 1.8, fill: 'none' }, P('sens'));
      E('path', { d: sm([[256, 154], [262, 176], [240, 186], [214, 180]], false), stroke: '#c0392b', 'stroke-width': 1.8, fill: 'none' }, P('mot'));
      E('path', { d: sm([[300, 86], [282, 92], [262, 96]], false), stroke: '#2a6ab0', 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '3 2' }, P('ear'));
      E('path', { d: sm([[256, 98], [244, 112], [248, 128], [252, 144]], false), stroke: '#7a4aa8', 'stroke-width': 2, fill: 'none', 'stroke-dasharray': '4 2' }, P('new'));
      hits(this.parts, part, 12); },
    idle(g, C, t) { const ph = (t * .3) % 1, D = (pts, u, c) => { const [x, y] = B.alongC(pts)(cl(u)); E('circle', { cx: f1(x), cy: f1(y), r: 4, fill: c, stroke: '#fff', 'stroke-width': 1.2 }, g); };
      if (ph < .5) { D([[300, 86], [282, 92], [262, 96]], ph * 4, '#2a6ab0'); if (ph > .25) D([[256, 98], [244, 112], [248, 128], [252, 144]], (ph - .25) * 4, '#7a4aa8'); }
      else { D([[256, 154], [262, 176], [240, 186], [214, 180]], (ph - .5) * 2.5, '#c0392b'); if (ph > .8) drops(g, 120, 150, t, 2); } },
    parts: [
      { id: 'taste', bn: 'স্বাদকোরক (জিহ্বা)', lb: 'স্বাদকোরক', en: 'Taste buds', fn: 'খাবারের রাসায়নিক শনাক্ত করে — শর্তহীন উদ্দীপনার গ্রাহক।', a: [90, 141], l: [20, 190], an: 'start' },
      { id: 'sens', bn: 'সংবেদী স্নায়ু (VII ও IX করোটিক)', lb: 'সংবেদী স্নায়ু', en: 'Sensory nerves', fn: 'ফেসিয়াল ও গ্লসোফ্যারিঞ্জিয়াল স্নায়ু স্বাদের সংকেত মেডুলায় নেয়।', a: [170, 164], l: [100, 230], an: 'middle' },
      { id: 'med', bn: 'মেডুলার লালা-কেন্দ্র', lb: 'লালা-কেন্দ্র (মেডুলা)', en: 'Salivary nucleus', fn: 'মস্তিষ্ককাণ্ডের এ কেন্দ্র শর্তহীন প্রতিবর্ত সমন্বয় করে — জন্ম থেকেই কার্যকর।', a: [252, 150], l: [352, 150], an: 'end' },
      { id: 'mot', bn: 'প্যারাসিমপ্যাথেটিক (মোটর) স্নায়ু', lb: 'মোটর স্নায়ু', en: 'Parasympathetic nerves', fn: 'লালাগ্রন্থিকে তরল লালা নিঃসরণের নির্দেশ দেয়।', a: [248, 186], l: [300, 270], an: 'start' },
      { id: 'gland', bn: 'লালাগ্রন্থি', lb: 'লালাগ্রন্থি', en: 'Salivary glands', fn: 'প্যারোটিড, সাবম্যান্ডিবুলার ও সাবলিঙ্গুয়াল গ্রন্থি — কার্যকারক অঙ্গ; প্যাভলভ প্যারোটিডের নালি থেকে লালা মাপতেন।', a: [190, 178], l: [180, 262], an: 'middle' },
      { id: 'ear', bn: 'কান ও শ্রবণপথ', lb: 'কান', en: 'Ear', fn: 'ঘণ্টার শব্দ গ্রহণ করে শ্রবণ কর্টেক্সে পাঠায় — শর্তাধীন উদ্দীপনার গ্রাহক।', a: [300, 86], l: [340, 40], an: 'end' },
      { id: 'cortex', bn: 'গুরুমস্তিষ্কের কর্টেক্স', lb: 'কর্টেক্স', en: 'Cerebral cortex', fn: 'শ্রবণ কর্টেক্সে ঘণ্টার শব্দ বিশ্লেষিত হয়।', a: [230, 80], l: [200, 20], an: 'middle' },
      { id: 'new', bn: 'শেখার ফলে তৈরি নতুন সংযোগ', lb: 'নতুন (শর্তাধীন) সংযোগ', en: 'Learned connection', fn: 'ঘণ্টা ও খাবার বারবার একসাথে আসায় শ্রবণপথ থেকে লালা-কেন্দ্রে নতুন কার্যকর সংযোগ গড়ে ওঠে — শর্তাধীন প্রতিবর্তের ভিত্তি।', a: [246, 116], l: [100, 60], an: 'middle' }
    ]
  }));

/* ═════════ স্কিনার বাক্স: ক্রিয়ানির্ভর (অপারেন্ট) কন্ডিশনিং ═════════ */
const rat = (g, x, y, s, up) => { const gg = E('g', { transform: `translate(${x} ${y}) scale(${s})` }, g), F = B.TS('furG');
  E('path', { d: 'M18 -4C30 -2 40 4 48 2', stroke: '#d8a8a0', 'stroke-width': 1.6, fill: 'none' }, gg);
  E('path', { d: `M-16 ${-6 - up * 8}C-18 ${-16 - up * 10} -4 -18 8 -16C20 -14 22 -4 18 0C12 2 -6 2 -14 0Z`, fill: B.vol(gg, 'furG'), stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: `M-16 ${-10 - up * 10}C-22 ${-12 - up * 12} -30 ${-10 - up * 12} -32 ${-8 - up * 12}C-30 ${-4 - up * 10} -22 ${-2 - up * 8} -16 ${-4 - up * 8}Z`, fill: F.c, stroke: F.dk, 'stroke-width': .6 }, gg);
  E('circle', { cx: -14, cy: -14 - up * 11, r: 3, fill: '#e8b8b0', stroke: F.dk, 'stroke-width': .5 }, gg); E('circle', { cx: -23, cy: -10 - up * 11, r: 1, fill: '#111' }, gg);
  E('path', { d: `M-12 0L-14 4M8 0L8 4${up ? `M-20 ${-6 - up * 8}L-28 ${-14 - up * 6}` : 'M-18 -2L-20 4'}`, stroke: '#c89890', 'stroke-width': 1.4, 'stroke-linecap': 'round' }, gg); return gg; };
V.skinnerBox = Object.assign({}, B.seg({
  id: 'skb', t: 'ক্রিয়ানির্ভর কন্ডিশনিং: স্কিনার বাক্স', H: 280, def: 'pos', types: {
    pos: ['পুরস্কার (ধনাত্মক দৃঢ়ীকরণ)', 'লিভার চাপলে খাবার', 'ক্ষুধার্ত ইঁদুর বাক্সে ঘুরতে ঘুরতে হঠাৎ লিভারে চাপ দেয় এবং একটি খাবারের দানা পায়। পুরস্কার পাওয়ায় লিভার চাপার হার দ্রুত বাড়ে — আচরণটির পরিণতিই আচরণকে দৃঢ় করে।'],
    ext: ['পুরস্কার বন্ধ (বিলোপ)', 'লিভার চাপলেও খাবার আসে না', 'খাবার বন্ধ করে দিলে প্রথমে কিছুক্ষণ জোরে জোরে চাপে, তারপর লিভার চাপার হার কমে যায় — ক্রিয়ানির্ভর সাড়ার বিলোপ।']
  },
  cap: 'বি. এফ. স্কিনার (1930-এর দশক) দেখান, যে আচরণের পর পুরস্কার মেলে তার পুনরাবৃত্তির সম্ভাবনা বাড়ে — একে ক্রিয়ানির্ভর বা অপারেন্ট কন্ডিশনিং (প্রচেষ্টা ও ভুলের শিখন) বলে। চিরায়ত কন্ডিশনিংয়ে সাড়াটি প্রতিবর্ত (লালা), আর এখানে প্রাণী নিজে ইচ্ছামূলক কাজ (লিভার চাপা) করে পরিণতি পায়। ডান দিকের ক্রমযোজিত রেখা যত খাড়া, চাপার হার তত বেশি।',
  art(g, C, ty) {
    E('rect', { x: 14, y: 40, width: 200, height: 170, fill: '#eef0f2', stroke: '#6a7078', 'stroke-width': 1.4 }, g); E('rect', { x: 14, y: 196, width: 200, height: 14, fill: '#c8ccd0' }, g); for (let i = 0; i < 12; i++) E('path', { d: `M${20 + i * 16} 196V210`, stroke: '#8a9098' }, g);
    E('rect', { x: 26, y: 150, width: 12, height: 4, fill: '#5a6068' }, g); E('rect', { x: 20, y: 110, width: 24, height: 34, rx: 3, fill: '#c8ccd0', stroke: '#6a7078' }, g); B.tx(g, 32, 106, 'খাদ্য', { fs: 8.8, a: 'middle', c: C.mu });
    E('path', { d: 'M60 150H78', stroke: '#4a5058', 'stroke-width': 4, 'stroke-linecap': 'round' }, g); B.tx(g, 70, 144, 'লিভার', { fs: 8.8, a: 'middle', c: C.mu });
    E('circle', { cx: 70, cy: 70, r: 6, fill: '#f6e070', stroke: '#a89020' }, g); B.tx(g, 70, 58, 'আলো', { fs: 8.8, a: 'middle', c: C.mu });
    E('rect', { x: 228, y: 40, width: 122, height: 170, fill: '#fbfaf6', stroke: '#9a9a90' }, g); B.tx(g, 289, 32, 'ক্রমযোজিত রেকর্ড', { fs: 9.6, a: 'middle', c: C.mu });
    B.tx(g, 289, 228, 'সময় →', { fs: 9, a: 'middle', c: C.mu }); B.tx(g, 180, 252, ty === 'pos' ? 'পুরস্কারে আচরণ দৃঢ় হয় — রেখা খাড়া হয়' : 'পুরস্কার নেই — রেখা চ্যাপ্টা হয়ে আসে', { fs: 10.4, a: 'middle', w: 700, c: C.fg });
  },
  anim(g, C, ty, t) { const T0 = (t * .6) % 12, rate = ty === 'pos' ? n => Math.min(3, .4 + n * .5) : n => Math.max(0, 2.4 - n * .35);
    let presses = 0, last = 0; const P = []; for (let k = 0; k <= 60; k++) { const tt = k / 5, r = rate(tt); presses += r / 5; P.push([234 + tt * 9.5, 204 - Math.min(150, presses * 5)]); if (tt <= T0) last = k; }
    E('path', { d: P.slice(0, last + 1).map((p, i) => (i ? 'L' : 'M') + f1(p[0]) + ' ' + f1(p[1])).join(''), stroke: '#2a2a2a', 'stroke-width': 1.4, fill: 'none' }, g);
    const per = 1 / Math.max(.3, rate(T0)), ph = (T0 % per) / per, press = ph < .25;
    rat(g, press ? 94 : 120 + Math.sin(T0) * 8, 194, 1.6, press ? 1 : 0); if (press) E('path', { d: 'M60 152H78', stroke: '#c0392b', 'stroke-width': 4, 'stroke-linecap': 'round' }, g);
    if (press && ty === 'pos') E('circle', { cx: 32, cy: 160 + ph * 120, r: 2.6, fill: '#a8703a' }, g); }
}));
})();
