/* ═══════════════════════════════════════════════════════════════════
   visuals1 — আচরণের প্রকৃতি ও উদ্দীপনা:
   behaviourLoop (কুনো ব্যাঙের শিকার ধরা), sticklebackModels (টিনবার্গেনের মডেল)
   সহায়ক: B.shp (বিন্দু-তালিকা থেকে মসৃণ আকৃতি), B.toad, B.stickle
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* বিন্দু রূপান্তর: একক-কাঠামোর বিন্দু → (x, y) এ s গুণ, fl = −1 হলে আয়না, rot রেডিয়ান */
const TP = B.tp = (pts, x, y, s = 1, fl = 1, rot = 0) => { const c = Math.cos(rot), n = Math.sin(rot); return pts.map(([a, b]) => { const u = a * fl; return [x + (u * c - b * n) * s, y + (u * n + b * c) * s]; }); };
B.shp = (g, pts, x, y, s, fl, at, o = {}) => E('path', Object.assign({ d: sm(TP(pts, x, y, s, fl, o.rot || 0), o.open ? false : true, o.k != null ? o.k : .5) }, at), g);
B.pt = (p, x, y, s = 1, fl = 1, rot = 0) => TP([p], x, y, s, fl, rot)[0];

/* ═════════ কুনো ব্যাঙ (Duttaphrynus melanostictus) — পার্শ্বদৃশ্য, ডানমুখী ═════════
   একক-কাঠামো: দৈর্ঘ্য প্রায় 100, (0, 0) = পেটের নিচে মাটি; o = { tongue: 0..1, tip: [x, y] (চিত্র-স্থানাঙ্ক), eye: চোখ ঘোরানো } */
const TOAD = [[54, -27], [50, -36], [42, -43], [33, -49], [24, -50], [14, -48], [2, -50], [-12, -50], [-28, -45], [-42, -35], [-50, -22], [-47, -10], [-36, -5], [-16, -4], [6, -5], [24, -9], [38, -15], [48, -20]];
const THIGH = [[-44, -16], [-36, -30], [-18, -30], [-4, -20], [-8, -8], [-26, -4], [-42, -6]];
const SHANK = [[-6, -14], [-2, -6], [-14, -2], [-34, -2], [-44, -6], [-38, -10], [-20, -10]];
const ARM = [[22, -16], [30, -14], [34, -4], [36, 0], [28, 0], [26, -6], [18, -10]];
B.toad = (g, x, y, s = 1, o = {}) => {
  const t = B.TS('toad'), P = (q) => B.pt(q, x, y, s);
  B.shp(g, THIGH, x, y, s, 1, { fill: B.vol(g, 'toad'), stroke: t.dk, 'stroke-width': .8 });
  B.shp(g, SHANK, x, y, s, 1, { fill: t.c, stroke: t.dk, 'stroke-width': .8 });
  /* পায়ের পাতা ও আঙুল (পিছনের) */
  [[-46, 0, -62, 1], [-46, 0, -60, -3], [-46, 0, -58, 3]].forEach(([a, b, c, d]) => { const [x0, y0] = P([a, b]), [x1, y1] = P([c, d]); E('path', { d: `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}`, stroke: t.dk, 'stroke-width': 2.2 * s, 'stroke-linecap': 'round' }, g); });
  B.shp(g, TOAD, x, y, s, 1, { fill: B.vol(g, 'toad'), stroke: t.dk, 'stroke-width': .9 });
  /* পেটের হালকা অংশ */
  B.shp(g, [[38, -14], [20, -8], [-6, -6], [-30, -7], [-40, -12], [-20, -16], [10, -16], [30, -18]], x, y, s, 1, { fill: FK.alpha('#f4ead0', .7) });
  /* আঁচিল (গুটি) — নির্দিষ্ট স্থানে */
  [[-30, -38, 1.6], [-18, -44, 1.9], [-4, -44, 1.5], [-38, -26, 1.4], [-24, -28, 1.3], [-8, -34, 1.7], [6, -38, 1.4], [-14, -20, 1.1], [-30, -16, 1.1], [-40, -34, 1.2], [-26, -46, 1.3], [-12, -38, 1.2], [0, -28, 1.3], [12, -24, 1.1], [-20, -36, 1.4], [-34, -22, 1.2], [-2, -16, 1], [-44, -20, 1]].forEach(([a, b, r], i) => { const [px, py] = P([a, b]); E('circle', { cx: f1(px), cy: f1(py), r: f1(r * s), fill: i % 2 ? '#8a7442' : '#b49a62', stroke: FK.alpha(t.dk, .6), 'stroke-width': .4 }, g); });
  /* প্যারোটয়েড গ্রন্থি (চোখের পিছনে লম্বাটে ফোলা) */
  B.shp(g, [[16, -46], [6, -48], [-6, -46], [-8, -42], [4, -40], [14, -41]], x, y, s, 1, { fill: '#a08650', stroke: t.dk, 'stroke-width': .6 });
  /* চোখের ওপরের হাড়ের কালো কিনারা (এ প্রজাতির চিহ্ন) */
  const [ex, ey] = P([28, -45]);
  E('path', { d: sm(TP([[20, -50], [28, -53], [36, -50], [40, -46]], x, y, s), false), stroke: '#2a1e10', 'stroke-width': 1.6 * s, fill: 'none' }, g);
  E('circle', { cx: f1(ex), cy: f1(ey), r: f1(5.6 * s), fill: '#c8902a', stroke: '#3a2a10', 'stroke-width': .7 }, g);
  E('path', { d: B.ellD(ex + (o.eye || 0) * s, ey, 3.6 * s, 1.5 * s, 0), fill: '#120c06' }, g);
  E('circle', { cx: f1(ex - 1.8 * s), cy: f1(ey - 2 * s), r: f1(1 * s), fill: '#fff', opacity: .8 }, g);
  /* কানপর্দা (টিমপেনাম) */
  const [tx, ty] = P([14, -34]); E('circle', { cx: f1(tx), cy: f1(ty), r: f1(3.6 * s), fill: '#a48a56', stroke: '#5a4826', 'stroke-width': .6 }, g);
  /* মুখের রেখা ও নাসারন্ধ্র */
  E('path', { d: sm(TP([[54, -27], [44, -25], [30, -26], [20, -30]], x, y, s), false), stroke: '#3a2a12', 'stroke-width': .9, fill: 'none' }, g);
  const [nx, ny] = P([49, -35]); E('circle', { cx: f1(nx), cy: f1(ny), r: f1(.9 * s), fill: '#2a1e10' }, g);
  /* সামনের পা */
  B.shp(g, ARM, x, y, s, 1, { fill: t.c, stroke: t.dk, 'stroke-width': .8 });
  [[32, 0, 40, 1], [32, 0, 38, -2]].forEach(([a, b, c, d]) => { const [x0, y0] = P([a, b]), [x1, y1] = P([c, d]); E('path', { d: `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}`, stroke: t.dk, 'stroke-width': 1.8 * s, 'stroke-linecap': 'round' }, g); });
  B.toadTongue(g, x, y, s, o.tongue, o.tip);
  return { eye: [ex, ey], mouth: P([54, -27]) };
};
/* জিহ্বা: সামনের দিকে আটকানো, উল্টে বেরিয়ে আসে */
B.toadTongue = (g, x, y, s, k, tip) => { if (!(k > 0 && tip)) return; const [mx, my] = B.pt([52, -26], x, y, s), ix = lerp(mx, tip[0], k), iy = lerp(my, tip[1], k);
  E('path', { d: `M${f1(mx)} ${f1(my)}Q${f1((mx + ix) / 2)} ${f1(Math.min(my, iy) - 6 * k)} ${f1(ix)} ${f1(iy)}`, stroke: '#d4707a', 'stroke-width': 3 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  E('circle', { cx: f1(ix), cy: f1(iy), r: f1(3.2 * s), fill: '#e08890', stroke: '#9a3a44', 'stroke-width': .6 }, g); };

/* ছোট মাছি (পার্শ্বদৃশ্য) — শিকার */
B.fly = (g, x, y, s = 1, flap = 0) => {
  E('path', { d: B.ellD(x - 1 * s, y - 3 * s, 5 * s, 2 * s, -20 - flap * 25), fill: FK.alpha('#dfe8f0', .75), stroke: '#8a98a8', 'stroke-width': .4 }, g);
  E('path', { d: B.ellD(x + 1 * s, y, 4.2 * s, 2.4 * s, 0), fill: '#3a3a40' }, g);
  E('circle', { cx: f1(x + 4.6 * s), cy: f1(y - .4 * s), r: f1(1.8 * s), fill: '#8a2a20' }, g);
  [-2, 0, 2].forEach(d => E('path', { d: `M${f1(x + d * s)} ${f1(y + 2 * s)}l${f1(-1 * s)} ${f1(2.4 * s)}`, stroke: '#3a3a40', 'stroke-width': .5 }, g));
};

/* ═════════ আচরণের ধারা: উদ্দীপনা → গ্রাহক → সমন্বয় → কার্যকারক → সাড়া ═════════ */
const BL = [
  { t: 'উদ্দীপনা', en: 'Stimulus', d: 'পরিবেশের যে পরিবর্তন প্রাণীর মধ্যে সাড়া জাগায় — এখানে একটি ছোট নড়াচড়া করা পোকা। কুনো ব্যাঙ স্থির বস্তুর চেয়ে চলমান, লম্বাটে ও চলার দিকে লম্বা বস্তুকে বেশি "শিকার" হিসেবে চেনে (ইওয়ার্টের পরীক্ষা)।' },
  { t: 'গ্রাহক অঙ্গ', en: 'Receptor', d: 'চোখের রেটিনার আলোকসংবেদী কোষ ও গ্যাংলিয়ন কোষ নড়াচড়া শনাক্ত করে স্নায়ু-উদ্দীপনা তৈরি করে। ব্যাঙ মাথা ঘুরিয়ে শিকারকে সোজা সামনে আনে (অভিমুখীকরণ)।' },
  { t: 'সমন্বয় (কেন্দ্রীয় স্নায়ুতন্ত্র)', en: 'Integration', d: 'দৃষ্টিস্নায়ু হয়ে সংকেত মধ্যমস্তিষ্কের অপটিক টেকটামে যায়; সেখানে "শিকার" না "শত্রু" — সিদ্ধান্ত হয় এবং সাড়ার নির্দেশ মোটর নিউরনে পাঠানো হয়।' },
  { t: 'কার্যকারক অঙ্গ', en: 'Effector', d: 'জিহ্বা ও চোয়ালের পেশি সংকুচিত হয়। ব্যাঙের জিহ্বা মুখের সামনের দিকে আটকানো, পেছনের প্রান্ত মুক্ত — তাই উল্টে বাইরে ছুটে যায় (প্রায় 0.07 সেকেন্ডে)।' },
  { t: 'সাড়া (আচরণ)', en: 'Response', d: 'আঠালো জিহ্বায় শিকার আটকে মুখে টেনে নেয় এবং চোখ ভেতরে টেনে গিলতে সাহায্য করে। পুরো ঘটনাটি একটি আচরণ — উদ্দীপনার প্রতি জীবের সমন্বিত সাড়া।' }
];
V.behaviourLoop = Object.assign({ t: 'আচরণ: উদ্দীপনা থেকে সাড়া', k: ['2d', 'anim', 'steps'], cap: 'কুনো ব্যাঙের শিকার ধরা দিয়ে আচরণের পাঁচটি ধাপ — উদ্দীপনা, গ্রাহক, স্নায়ুতন্ত্রে সমন্বয়, কার্যকারক ও সাড়া। নিচের ধারায় চলমান ধাপটি উজ্জ্বল হয়।' },
  BK.steps({ W: 360, H: 290, label: 'আচরণের ধারা', dur: 3.4, stages: BL,
    draw(g, C, s, u) {
      B.cacheG(g, 'blbg', gg => {
        E('rect', { x: 0, y: 176, width: 360, height: 34, fill: B.lin(gg, 'soil', 90) }, gg);
        for (let i = 0; i < 16; i++) { const x = 8 + i * 23 + B.rnd(i) * 10; E('path', { d: `M${f1(x)} 177q2 -9 5 -13M${f1(x + 4)} 177q-1 -7 -4 -10`, stroke: '#7aa048', 'stroke-width': 1.1, fill: 'none' }, gg); }
      });
      const fx = 268 + Math.sin(u * PI * 2) * 6, fy = 120 + Math.cos(u * PI * 3) * 4;
      const caught = s === 4 && u > .45, tongue = s === 4 ? (u < .45 ? cl(u / .2) : cl((.9 - u) / .45)) : s === 3 ? cl((u - .7) / .3) * .3 : 0;
      const tip = caught ? null : [fx, fy];
      /* ব্যাঙের দেহ স্থির স্তরে; শুধু জিহ্বা প্রতি ফ্রেমে */
      const eyeS = s >= 1 ? 1 : 0, TL = B.cacheG(g, 'bltoad' + eyeS, gg => { gg._r = B.toad(gg, 120, 178, 1.65, { eye: eyeS }); }), r = TL._r;
      B.toadTongue(g, 120, 178, 1.65, caught ? cl((.9 - u) / .45) : tongue, caught ? [lerp(fx, 205, cl((u - .45) / .45)), lerp(fy, 134, cl((u - .45) / .45))] : tip);
      if (!(s === 4 && u > .85)) B.fly(g, caught ? lerp(fx, 205, cl((u - .45) / .45)) : fx, caught ? lerp(fy, 134, cl((u - .45) / .45)) : fy, 1.8, Math.sin(u * 60) > 0 ? 1 : 0);
      if (s === 0) for (let k = 0; k < 3; k++) E('path', { d: `M${f1(fx + 12 + k * 6)} ${f1(fy - 6)}q4 6 0 12`, stroke: FK.alpha('#c0392b', .7 - k * .2), fill: 'none', 'stroke-width': 1.2 }, g);
      if (s === 1) { const v = cl(u * 1.3); E('path', { d: `M${f1(fx)} ${f1(fy)}L${f1(lerp(fx, r.eye[0], v))} ${f1(lerp(fy, r.eye[1], v))}`, stroke: '#e0a030', 'stroke-width': 1.4, 'stroke-dasharray': '4 3' }, g); E('circle', { cx: f1(r.eye[0]), cy: f1(r.eye[1]), r: 12, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6, opacity: f1(.4 + .5 * Math.sin(u * PI)) }, g); }
      if (s === 2) { /* মস্তিষ্কের অবস্থান ও স্নায়ুপথ (অর্ধস্বচ্ছ) */ const bx = 146, by = 108; E('path', { d: B.ellD(bx, by, 11, 4.6, -8), fill: FK.alpha('#f1d9d3', .9), stroke: '#9a6d66', 'stroke-width': .8 }, g); E('circle', { cx: bx + 4, cy: by - 1, r: 3, fill: '#e0a030', opacity: f1(.5 + .5 * Math.sin(u * PI * 4)) }, g);
        B.tx(g, bx - 20, by - 26, 'অপটিক টেকটাম', { fs: 9.6, a: 'middle', c: '#7a4a3a' }); E('path', { d: `M${bx - 16} ${by - 22}L${bx - 2} ${by - 4}`, stroke: '#7a4a3a', 'stroke-width': .8 }, g); E('path', { d: `M${f1(r.eye[0] - 4)} ${f1(r.eye[1] + 2)}Q${bx + 18} ${by + 4} ${bx + 6} ${by}`, stroke: '#c9a020', 'stroke-width': 1.4, fill: 'none', 'stroke-dasharray': `${f1(40 * u)} 60` }, g); }
      if (s === 3) { const [mx, my] = r.mouth; E('circle', { cx: f1(mx - 6), cy: f1(my + 3), r: 9, fill: 'none', stroke: '#c0392b', 'stroke-width': 1.6, opacity: f1(.3 + .6 * Math.sin(u * PI * 3) ** 2) }, g); B.tx(g, mx + 6, my + 18, 'জিহ্বা ও চোয়ালের পেশি', { fs: 9.6, c: '#8a2a20' }); }
      /* নিচের ধারা */
      B.cacheG(g, 'bllab' + s, gg => { const lab = ['উদ্দীপনা', 'গ্রাহক', 'সমন্বয়', 'কার্যকারক', 'সাড়া'];
        lab.forEach((l, i) => { const x = 38 + i * 71, on = i === s; E('rect', { x: x - 32, y: 228, width: 64, height: 26, rx: 13, fill: on ? FK.alpha('#e0a030', .25) : FK.alpha(C.fg, .05), stroke: on ? '#c08018' : FK.alpha(C.fg, .25), 'stroke-width': on ? 1.6 : .8 }, gg);
          B.tx(gg, x, 245, l, { fs: 10.4, a: 'middle', w: on ? 700 : 500, c: on ? '#8a5410' : C.fg }); if (i < 4) B.arrow(gg, x + 33, 241, x + 38, 241, FK.alpha(C.fg, .5), { h: 4, w: 1.2 }); });
        B.tx(gg, 180, 274, 'আচরণ = উদ্দীপনার প্রতি জীবের সমন্বিত ও দৃশ্যমান সাড়া', { fs: 10.4, a: 'middle', c: C.mu }); });
    }
  }));

/* ═════════ তিন-কাঁটা স্টিকলব্যাক (Gasterosteus aculeatus) — ডানমুখী ═════════ */
const STK = [[34, 0], [30, -5], [22, -8], [10, -10], [-4, -9], [-18, -6], [-26, -3], [-29, -2], [-29, 2], [-26, 3], [-16, 6], [-2, 9], [12, 10], [24, 7], [31, 3]];
B.stickle = (g, x, y, s = 1, fl = 1, o = {}) => {
  const red = o.red, M = q => B.pt(q, x, y, s, fl);
  /* লেজের পাখনা */
  B.shp(g, [[-28, 0], [-38, -7], [-40, -5], [-36, 0], [-40, 5], [-38, 7]], x, y, s, fl, { fill: FK.alpha('#b8c0a8', .85), stroke: '#6a7058', 'stroke-width': .5 }, { k: .2 });
  /* পৃষ্ঠ ও পায়ু পাখনা (নরম) */
  B.shp(g, [[-6, -8], [-10, -13], [-18, -11], [-24, -5], [-18, -5]], x, y, s, fl, { fill: FK.alpha('#b8c0a8', .7), stroke: '#6a7058', 'stroke-width': .4 }, { k: .3 });
  B.shp(g, [[-6, 8], [-10, 12], [-18, 9], [-23, 4], [-16, 5]], x, y, s, fl, { fill: FK.alpha('#b8c0a8', .7), stroke: '#6a7058', 'stroke-width': .4 }, { k: .3 });
  /* দেহ */
  const body = B.shp(g, STK, x, y, s, fl, { fill: o.model === 'crude' ? '#b9b2a2' : B.lin(g, o.dull ? 'fish' : 'tit', 90), stroke: '#3a4a40', 'stroke-width': .8 });
  if (!o.dull && o.model !== 'crude') B.shp(g, [[30, -3], [20, -7], [6, -9], [-10, -7], [-22, -4], [-10, -1], [10, -1], [24, -1]], x, y, s, fl, { fill: FK.alpha('#2a5a48', .55) });
  /* লাল গলা ও পেট (প্রজনন ঋতুর পুরুষ) */
  if (red) B.shp(g, [[30, 3], [26, 0], [14, 1], [0, 2], [-12, 4], [-14, 6], [-2, 9], [12, 10], [24, 7]], x, y, s, fl, { fill: '#d8322a', opacity: .92 });
  if (o.model !== 'crude') {
    /* পার্শ্বীয় অস্থিফলক */
    for (let i = 0; i < 7; i++) { const [a, b] = M([18 - i * 5, -2]), [c, d] = M([18 - i * 5, 4]); E('path', { d: `M${f1(a)} ${f1(b)}L${f1(c)} ${f1(d)}`, stroke: FK.alpha('#e8eef0', .5), 'stroke-width': .7 }, g); }
    /* কানকো ও চোখ */
    E('path', { d: sm(TP([[22, -6], [19, -1], [22, 5]], x, y, s, fl), false), stroke: '#2a3a30', 'stroke-width': .7, fill: 'none' }, g);
    const [ex, ey] = M([27, -2]); E('circle', { cx: f1(ex), cy: f1(ey), r: f1(2.6 * s), fill: red ? '#3ab0e0' : '#c8c8b8', stroke: '#1a2a2a', 'stroke-width': .5 }, g); E('circle', { cx: f1(ex + .4 * s * fl), cy: f1(ey), r: f1(1.2 * s), fill: '#0a1014' }, g);
    /* তিনটি পৃষ্ঠকাঁটা ও শ্রোণিকাঁটা */
    [[14, -10, 10, -20], [5, -10, 2, -20], [-4, -9, -6, -14]].forEach(([a, b, c, d]) => { const [x0, y0] = M([a, b]), [x1, y1] = M([c, d]); E('path', { d: `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}`, stroke: '#3a4038', 'stroke-width': 1.3 * s, 'stroke-linecap': 'round' }, g); });
    const [p0, p1] = M([12, 9]), [p2, p3] = M([2, 16]); E('path', { d: `M${f1(p0)} ${f1(p1)}L${f1(p2)} ${f1(p3)}`, stroke: '#3a4038', 'stroke-width': 1.3 * s, 'stroke-linecap': 'round' }, g);
  } else { const [ex, ey] = M([24, -2]); E('circle', { cx: f1(ex), cy: f1(ey), r: f1(2.4 * s), fill: '#1a1a1a' }, g); }
  return body;
};
/* অপরিশীলিত মডেল (টিনবার্গেন): গোলাকার বা চুরুট আকৃতি, নিচের অর্ধেক লাল */
const crude = (g, x, y, s, kind) => {
  const pts = kind === 'disc' ? [[0, -16], [14, -10], [18, 2], [12, 14], [0, 17], [-12, 14], [-18, 2], [-14, -10]] : [[30, 0], [22, -7], [0, -9], [-24, -6], [-30, 0], [-24, 6], [0, 9], [22, 7]];
  const id = 'stc' + kind; B.shp(g, pts, x, y, s, 1, { fill: '#c9c2b2', stroke: '#6a6458', 'stroke-width': .8 });
  B.shp(g, pts.filter(p => p[1] >= -1), x, y, s, 1, { fill: '#d8322a', opacity: .92 }, { k: .4 });
  E('circle', { cx: f1(x + (kind === 'disc' ? 8 : 22) * s), cy: f1(y - 3 * s), r: f1(2 * s), fill: '#1a1a1a' }, g);
};
const STT = {
  male: ['প্রজনন-ঋতুর পুরুষ', 'আসল পুরুষ স্টিকলব্যাক', 'বসন্তে পুরুষের গলা ও পেট টকটকে লাল এবং চোখ উজ্জ্বল নীল হয়। সে নিজের এলাকা দখল করে বাসা বানায় এবং অন্য লাল-পেটওয়ালা পুরুষ ঢুকলেই আক্রমণ করে।'],
  real: ['লাল-ছাড়া নিখুঁত মডেল', 'দেখতে হুবহু মাছ, কিন্তু পেট লাল নয়', 'আকৃতি, পাখনা, কাঁটা, চোখ — সব নিখুঁত, শুধু লাল রং নেই। এলাকার মালিক পুরুষ একে প্রায় উপেক্ষা করে — আক্রমণ খুব কম।'],
  crude: ['লাল-পেট অপরিশীলিত মডেল', 'মাছের মতো দেখতেই নয়, কিন্তু নিচের অর্ধেক লাল', 'গোল চাকতি বা চুরুটের মতো কাঠের টুকরো, যার নিচের দিক লাল — পুরুষ একে প্রচণ্ডভাবে আক্রমণ করে। অর্থাৎ পুরো আকৃতি নয়, "লাল পেট" নামের একটি সংকেত-উদ্দীপনাই (sign stimulus) আক্রমণ আচরণ চালু করে।']
};
V.sticklebackModels = Object.assign({}, B.seg({
  id: 'stk', t: 'সংকেত-উদ্দীপনা: স্টিকলব্যাকের লাল পেট', H: 270, def: 'crude', types: STT,
  cap: 'নিকো টিনবার্গেনের (1951) বিখ্যাত পরীক্ষা: এলাকার মালিক পুরুষ স্টিকলব্যাকের সামনে বিভিন্ন মডেল ধরা হয়। আসলের মতো নিখুঁত কিন্তু লাল-ছাড়া মডেল প্রায় উপেক্ষিত, অথচ মাছের মতো না হলেও নিচে লাল রঙের অপরিশীলিত মডেল তীব্র আক্রমণ পায় — একটি সরল সংকেত (রিলিজার) সহজাত আচরণ শুরু করে।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 210, fill: B.lin(g, 'wtr', 90) }, g);
    E('path', { d: 'M0 190Q90 182 180 188T360 186V210H0Z', fill: B.lin(g, 'soil', 90) }, g);
    /* বাসা: জলজ উদ্ভিদের টুকরো দিয়ে তৈরি সুড়ঙ্গ */
    E('path', { d: 'M40 192Q46 176 66 174Q86 174 92 190Z', fill: '#7a8a4a', stroke: '#4a5a2a', 'stroke-width': .8 }, g);
    for (let i = 0; i < 9; i++) E('path', { d: `M${44 + i * 5} 190q${3 - B.rnd(i) * 6} -10 ${6 - B.rnd(i + 3) * 4} -15`, stroke: '#5a6a2a', 'stroke-width': .9, fill: 'none' }, g);
    E('path', { d: B.ellD(66, 186, 5, 3.4), fill: '#2a3018' }, g);
    B.tx(g, 66, 204, 'বাসা', { fs: 9.6, a: 'middle', c: '#3a4a1a' });
    [[300, 0], [326, 1], [346, 2], [16, 3]].forEach(([x, i]) => { E('path', { d: `M${x} 190C${x - 6} 150 ${x + 8} 120 ${x - 2} ${70 + i * 12}`, stroke: '#5a8a3a', 'stroke-width': 1.6, fill: 'none' }, g); });
    /* দণ্ডে ঝোলানো মডেল */
    E('path', { d: 'M236 0V92', stroke: '#8a8070', 'stroke-width': 1 }, g);
    if (ty === 'male') B.stickle(g, 236, 112, 1.7, -1, { red: true });
    else if (ty === 'real') B.stickle(g, 236, 112, 1.7, -1, { red: false, dull: true });
    else { crude(g, 224, 100, 1.3, 'disc'); crude(g, 286, 140, .9, 'cigar'); E('path', { d: 'M286 0V132', stroke: '#8a8070', 'stroke-width': 1 }, g); }
    B.tx(g, 236, 24, ty === 'male' ? 'অনুপ্রবেশকারী পুরুষ' : 'পরীক্ষার মডেল', { fs: 10.4, a: 'middle', w: 700, c: '#2a4a5a' });
    /* আপেক্ষিক আক্রমণ (গুণগত) */
    const lv = { male: .95, real: .12, crude: .85 }[ty];
    B.tx(g, 12, 232, 'মালিক পুরুষের আক্রমণ', { fs: 10, c: C.fg, w: 600 });
    E('rect', { x: 130, y: 222, width: 210, height: 12, rx: 6, fill: FK.alpha(C.fg, .08) }, g);
    E('rect', { x: 130, y: 222, width: f1(210 * lv), height: 12, rx: 6, fill: lv > .5 ? '#c0392b' : '#8aa0a8' }, g);
    B.tx(g, 12, 256, lv > .5 ? 'তীব্র — লাল পেটই মূল সংকেত' : 'খুব কম — লাল রং নেই', { fs: 10, c: lv > .5 ? '#a0281e' : C.mu });
  },
  anim(g, C, ty, t) {
    const lv = { male: .95, real: .12, crude: .85 }[ty];
    /* মালিক পুরুষ: বাসার কাছে পাহারা, লাল সংকেত দেখলে ধাওয়া করে ঠোকর দেয় */
    const ph = (t * .5) % 1, att = lv > .5, tx = ty === 'crude' ? 212 : 220;
    let x, y, a = 0;
    if (att) { const k = ph < .5 ? FK.ease(ph * 2) : FK.ease((1 - ph) * 2); x = lerp(96, tx - 34, k); y = lerp(176, 108, k) + Math.sin(t * 9) * 1.5; a = -.5 * k; }
    else { x = 100 + Math.sin(t * .8) * 14; y = 168 + Math.sin(t * 1.3) * 4; a = 0; }
    B.stickle(E('g', { transform: `rotate(${f1(a * 57)} ${f1(x)} ${f1(y)})` }, g), x, y, 1.35, 1, { red: true });
    if (att && ph > .4 && ph < .6) for (let k = 0; k < 3; k++) E('path', { d: `M${f1(tx - 22 + k * 4)} ${f1(104 - k * 6)}l${4 + k} ${-3 - k}`, stroke: '#c0392b', 'stroke-width': 1.2 }, g);
  }
}));
})();
