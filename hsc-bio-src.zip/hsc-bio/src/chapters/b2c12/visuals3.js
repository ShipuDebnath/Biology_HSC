/* ═══════════════════════════════════════════════════════════════════
   visuals3 — সহজাত আচরণ, নির্দিষ্ট ক্রিয়া বিন্যাস, ট্যাক্সিস ও কাইনেসিস:
   eggRolling (গ্রেল্যাগ রাজহাঁস), gullPeck (গাংচিল ছানা), taxisTypes, kinesisChoice (উডলাইস)
   সহায়ক: B.goose, B.gullHead, B.gullChick, B.euglena, B.maggot, B.planaria, B.minnow, B.paramecium, B.woodlouse
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, TP = B.tp;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ গ্রেল্যাগ রাজহাঁস (Anser anser), বাসায় বসা, ডানমুখী; h = মাথার অবস্থান (স্থানীয় একক) ═════════ */
B.goose = (g, x, y, s, h) => {
  const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), Gs = B.TS('goose');
  /* দেহ */
  E('path', { d: 'M-34 -10C-38 -16 -30 -26 -14 -28C4 -30 20 -26 24 -16C26 -8 20 -2 6 0H-26C-32 -2 -34 -6 -34 -10Z', fill: B.vol(gg, 'goose'), stroke: Gs.dk, 'stroke-width': .6 }, gg);
  /* ডানার পালকের সারি (ফিকে কিনারাসহ) */
  for (let r = 0; r < 4; r++) for (let i = 0; i < 7 - r; i++) { const px = -26 + i * 6 + r * 4, py = -21 + r * 4.6; E('path', { d: `M${px} ${py}q3 2.4 6 0`, stroke: FK.alpha('#f2ece0', .75), 'stroke-width': .7, fill: 'none' }, gg); E('path', { d: `M${px} ${f1(py + .8)}q3 2.4 6 0`, stroke: Gs.dk, 'stroke-width': .45, fill: 'none', opacity: .45 }, gg); }
  E('path', { d: 'M-34 -12L-42 -14L-36 -6Z', fill: '#7a7060' }, gg);
  E('path', { d: 'M-30 -4L-38 -2', stroke: '#f4f0e6', 'stroke-width': 2 }, gg);
  /* গলা: ভিত থেকে মাথা পর্যন্ত মোটা মসৃণ রেখা */
  const bx = 18, by = -20, [hx, hy] = h, mx = (bx + hx) / 2 + (hy > -20 ? 4 : -4), my = Math.min(by, hy) - (hy > -20 ? 10 : 6);
  E('path', { d: `M${bx} ${by}Q${f1(mx)} ${f1(my)} ${f1(hx)} ${f1(hy)}`, stroke: '#9a8e78', 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('path', { d: `M${bx} ${by}Q${f1(mx)} ${f1(my)} ${f1(hx)} ${f1(hy)}`, stroke: '#b4aa94', 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round', opacity: .6 }, gg);
  /* মাথা ও ঠোঁট (কমলা-গোলাপি, সাদা নখ) — গলার দিক বরাবর */
  const ang = Math.atan2(hy - my, hx - mx) * 180 / PI;
  const hd = E('g', { transform: `translate(${f1(hx)} ${f1(hy)}) rotate(${f1(ang)})` }, gg);
  E('path', { d: B.ellD(0, 0, 6.4, 4.8), fill: '#8e826c', stroke: Gs.dk, 'stroke-width': .5 }, hd);
  E('path', { d: 'M4 -2.6L14 -.6L14 1.6L4 3Z', fill: '#f0a080', stroke: '#a85a40', 'stroke-width': .5 }, hd);
  E('path', { d: 'M13 -.8L15 .4L13 1.6Z', fill: '#f6f0e4' }, hd);
  E('circle', { cx: 1.5, cy: -1.6, r: 1.1, fill: '#1a120c' }, hd);
  return gg;
};
/* বাসা: ঘাস ও পালকের ঢিবি */
const nest = (g, x, y, s) => { E('path', { d: `M${x - 52 * s} ${y}Q${x - 46 * s} ${y - 12 * s} ${x - 20 * s} ${y - 12 * s}H${x + 22 * s}Q${x + 46 * s} ${y - 12 * s} ${x + 52 * s} ${y}Z`, fill: B.lin(g, 'wood', 90), stroke: '#6a5030', 'stroke-width': .7 }, g);
  for (let i = 0; i < 22; i++) { const u = x - 48 * s + i * 4.4 * s; E('path', { d: `M${f1(u)} ${f1(y - 2)}q${f1(3 * s)} ${f1(-8 * s - B.rnd(i) * 4 * s)} ${f1(6 * s)} ${f1(-9 * s)}`, stroke: i % 3 ? '#a08050' : '#c8b080', 'stroke-width': .8, fill: 'none' }, g); } };
const egg = (g, x, y, s, big) => { E('path', { d: B.ellD(x, y, (big ? 13 : 7.4) * s, (big ? 12 : 5.6) * s, -8), fill: big ? '#e6dccb' : B.vol(g, 'egg'), stroke: '#9a8e6a', 'stroke-width': .7 }, g); if (big) E('path', { d: `M${x - 12 * s} ${y}Q${x} ${y - 6 * s} ${x + 12 * s} ${y}M${x} ${y - 12 * s}Q${x - 5 * s} ${y} ${x} ${y + 12 * s}`, stroke: '#a89a7a', 'stroke-width': .6, fill: 'none' }, g); };

const ER = [
  { t: 'ডিম বাসার বাইরে', en: 'Sign stimulus', d: 'বাসার কিনারার বাইরে একটি ডিম গড়িয়ে পড়েছে। বাসার কাছে একটি গোলাকার বস্তু — এই সংকেত-উদ্দীপনাই (sign stimulus) আচরণটি চালু করে।' },
  { t: 'গলা বাড়ানো', en: 'Neck extension', d: 'রাজহাঁস বাসায় বসে থেকেই গলা সামনে বাড়িয়ে ঠোঁটের নিচের অংশ ডিমের ওপারে রাখে।' },
  { t: 'ঠোঁটের নিচে টেনে আনা', en: 'Rolling movement', d: 'ঠোঁটের নিচ দিয়ে ডিমটি বুকের দিকে টেনে আনে; ডিম যাতে পাশে গড়িয়ে না যায় সে জন্য ঠোঁট পাশে পাশে নাড়ায় — এ পাশের নড়াচড়া উদ্দীপনা-নির্ভর (ট্যাক্সিস অংশ)।' },
  { t: 'মাঝপথে ডিম সরালেও চলে', en: 'Fixed action pattern', d: 'গবেষক মাঝপথে ডিম সরিয়ে নিলেও রাজহাঁস টানার নড়াচড়া শেষ পর্যন্ত চালিয়ে যায় — যেন অদৃশ্য ডিম টানছে। একবার শুরু হলে উদ্দীপনা ছাড়াই সম্পূর্ণ হওয়া এ আচরণই নির্দিষ্ট ক্রিয়া বিন্যাস (FAP)। পাশের নড়াচড়া তখন আর হয় না।' },
  { t: 'অতিস্বাভাবিক উদ্দীপনা', en: 'Supernormal stimulus', d: 'নিজের ডিমের চেয়ে বড় মডেল (এমনকি ভলিবলের মতো বস্তু) দিলে রাজহাঁস সেটিকেই বেশি আগ্রহে গড়িয়ে আনে — আকারে বড় সংকেত বেশি শক্তিশালী।' }
];
V.eggRolling = Object.assign({ t: 'নির্দিষ্ট ক্রিয়া বিন্যাস: রাজহাঁসের ডিম গড়ানো', k: ['2d', 'anim', 'steps'], cap: 'কনরাড লরেঞ্জ ও নিকো টিনবার্গেনের (1938) পরীক্ষা: গ্রেল্যাগ রাজহাঁস বাসার বাইরের ডিম ঠোঁটের নিচে টেনে ফেরত আনে। মাঝপথে ডিম সরালেও নড়াচড়া শেষ হয় — এটি সহজাত নির্দিষ্ট ক্রিয়া বিন্যাসের (Fixed Action Pattern) শ্রেষ্ঠ উদাহরণ।' },
  BK.steps({ W: 360, H: 270, label: 'ডিম গড়ানো', dur: 3.4, stages: ER,
    draw(g, C, s, u) {
      B.cacheG(g, 'erbg', gg => { E('rect', { x: 0, y: 190, width: 360, height: 40, fill: B.lin(gg, 'grass', 90) }, gg); for (let i = 0; i < 30; i++) E('path', { d: `M${f1(4 + i * 12)} 192q2 -7 4 -10`, stroke: '#6a9a3a', 'stroke-width': 1, fill: 'none' }, gg); });
      const X0 = 130, Y0 = 186, S = 2.2, EX = 268, EY = 180, ex = EX - X0, rest = [32, -48];
      B.cacheG(g, 'ernest', gg => { nest(gg, X0, Y0 + 4, 2); B.tx(gg, 180, 252, 'সংকেত-উদ্দীপনা → সহজাত মুক্তিদায়ী প্রক্রিয়া → নির্দিষ্ট ক্রিয়া বিন্যাস', { fs: 10, a: 'middle', c: C.mu }); });
      let h = rest, eggX = EX, show = true, big = s === 4;
      const reach = [(EX - X0) / S + 9, (EY - Y0) / S - 3], chin = [26 + 4, -6];
      if (s === 0) h = [rest[0], rest[1] + Math.sin(u * PI * 2) * 1.2];
      else if (s === 1) h = [lerp(rest[0], reach[0], u), lerp(rest[1], reach[1], u)];
      else if (s >= 2) { const k = s === 4 ? u : s === 3 ? u : u; const hx = lerp(reach[0], chin[0], k) + (s === 2 || s === 4 ? Math.sin(u * PI * 8) * 1.4 : 0); h = [hx, reach[1] + (chin[1] - reach[1]) * k];
        eggX = X0 + (hx - 9) * S; if (s === 3 && u > .35) show = false; }
      /* ডিম ও রাজহাঁস আলাদা স্থির স্তরে — অবস্থান বদলালেই কেবল নতুন করে আঁকা */
      const ex0 = s === 0 || s === 1 ? EX : eggX;
      B.cacheG(g, 'eregg' + (show ? 1 + Math.round(ex0 * 4) * 10 + (big ? 1 : 0) : 0), gg => { if (show) egg(gg, ex0, EY, 1.6, big); });
      B.cacheG(g, 'ergoose' + (Math.round(h[0] * 4 + 4000) * 100000 + Math.round(h[1] * 4 + 4000)), gg => B.goose(gg, X0, Y0 - 6, S, [Math.round(h[0] * 4) / 4, Math.round(h[1] * 4) / 4]));
      if (s === 3 && u > .35) { const k = cl((u - .35) / .3); egg(g, lerp(X0 + (lerp(reach[0], chin[0], .35) - 9) * S, 330, k), lerp(EY, 120, k), 1.6); B.tx(g, 320, 108, 'গবেষক ডিম সরালেন', { fs: 9.6, a: 'middle', c: '#7a2a1a' }); }
      const tk = s === 3 ? (u > .45 ? 3 : 0) : s === 2 || s === 4 ? s : 0;
      B.cacheG(g, 'ertx' + tk, gg => {
        if (tk === 3) B.tx(gg, 180, 30, 'ডিম নেই, তবু টানার নড়াচড়া শেষ পর্যন্ত চলছে', { fs: 10.4, a: 'middle', w: 700, c: '#a8201a' });
        if (tk === 2) B.tx(gg, 300, 156, '↔ ভারসাম্যের জন্য পাশের নড়াচড়া', { fs: 9.6, a: 'middle', c: '#2a5a6a' });
        if (tk === 4) B.tx(gg, 180, 30, 'বড় মডেল বেশি পছন্দ — অতিস্বাভাবিক উদ্দীপনা', { fs: 10.4, a: 'middle', w: 700, c: '#2a5a6a' }); });
    }
  }));

/* ═════════ হেরিং গাংচিলের মাথা (বামমুখী) ও ছানা ═════════ */
const gullHead = (g, x, y, s, o = {}) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  if (o.head !== false) { E('path', { d: 'M40 30C40 6 28 -10 10 -10C-2 -10 -8 -4 -10 2L-10 8C-4 12 6 14 14 20C20 26 24 34 26 40H44C44 36 42 32 40 30Z', fill: o.headCol || '#f6f6f2', stroke: '#a8a8a0', 'stroke-width': .6 }, gg);
    E('circle', { cx: 4, cy: 0, r: 2.6, fill: '#f0d040', stroke: '#6a5a20', 'stroke-width': .4 }, gg); E('circle', { cx: 4, cy: 0, r: 1, fill: '#111' }, gg); E('circle', { cx: 4, cy: 0, r: 3.4, fill: 'none', stroke: '#e0a040', 'stroke-width': .6 }, gg); }
  /* ঠোঁট: হলুদ, নিচের ঠোঁটের বাঁকে (গোনিস) লাল দাগ */
  if (o.rod) { E('rect', { x: -44, y: 1, width: 40, height: 3.4, rx: 1.7, fill: '#d8322a' }, gg); [-36, -26, -16].forEach(px => E('rect', { x: px, y: 1, width: 3.4, height: 3.4, fill: '#fff' }, gg)); return gg; }
  E('path', { d: 'M-10 1C-20 1 -30 2 -36 4C-38 5 -38 7 -35 7C-28 7 -18 8 -10 8Z', fill: o.billCol || '#f2d03a', stroke: '#9a8010', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-10 6L-30 7', stroke: '#9a8010', 'stroke-width': .4 }, gg);
  if (o.spot !== false) E('path', { d: B.ellD(-28, 8, 2.8, 1.8), fill: o.spotCol || '#d8322a' }, gg);
  return gg; };
const gullChick = (g, x, y, s, peck) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M-16 10C-18 0 -10 -8 0 -8C8 -8 12 -4 12 2C12 10 4 14 -6 14C-12 14 -16 12 -16 10Z', fill: B.vol(gg, 'furG'), stroke: '#5c564c', 'stroke-width': .5 }, gg);
  for (let i = 0; i < 14; i++) E('circle', { cx: f1(-14 + B.rnd(i) * 24), cy: f1(-4 + B.rnd(i + 9) * 14), r: .9, fill: '#4a4438', opacity: .7 }, gg);
  const hx = 12 + peck * 6, hy = -12 + peck * 3; E('path', { d: `M4 -4Q8 -12 ${hx} ${hy}`, stroke: '#a19a8e', 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, gg);
  E('circle', { cx: hx, cy: hy, r: 5, fill: '#b0a898', stroke: '#5c564c', 'stroke-width': .4 }, gg); E('circle', { cx: hx + 1.5, cy: hy - 1.4, r: .9, fill: '#111' }, gg);
  E('path', { d: `M${hx + 4} ${hy - 1}l6 1.4l-6 1.4Z`, fill: '#3a3430' }, gg);
  E('path', { d: 'M-4 13L-5 18M2 13L3 18', stroke: '#8a8070', 'stroke-width': 1.2 }, gg); return gg; };
const GP = {
  nat: ['স্বাভাবিক মাথার মডেল', 'হলুদ ঠোঁটে লাল দাগ — স্বাভাবিক', 'তুলনার ভিত্তি: মা-বাবার মাথার মতো মডেল, ঠোঁটের নিচের অংশে লাল দাগ। ছানা দাগটিতে ঠোকর দেয়, আর ঠোকর খেয়ে মা-বাবা খাবার উগরে দেয়।', 1],
  nos: ['দাগহীন ঠোঁট', 'লাল দাগ নেই', 'ঠোঁট পুরো হলুদ — ঠোকরের হার অনেক কমে যায়। ছানার ঠোকর মূলত দাগের রং ও বৈপরীত্যের সংকেতে নিয়ন্ত্রিত।', .3],
  bill: ['মাথা ছাড়া শুধু ঠোঁট', 'শুধু দাগসহ ঠোঁট, মাথা নেই', 'মাথা বাদ দিলেও ঠোকর প্রায় সমান — অর্থাৎ মাথার আকৃতি নয়, ঠোঁট ও লাল দাগই আসল সংকেত।', .95],
  rod: ['সাদা দাগের লাল কাঠি', 'লাল কাঠিতে তিনটি সাদা ডোরা', 'সরু, লম্বা, লাল কাঠি যাতে সাদা ডোরা আছে (বেশি বৈপরীত্য) — এটি আসল ঠোঁটের চেয়েও বেশি ঠোকর পায়: অতিস্বাভাবিক (supernormal) উদ্দীপনা।', 1.25]
};
V.gullPeck = Object.assign({}, B.seg({
  id: 'gpk', t: 'সংকেত-উদ্দীপনা: গাংচিল ছানার ঠোকর', H: 262, def: 'nat', types: GP,
  cap: 'টিনবার্গেন ও পারডেকের (1950) মডেল-পরীক্ষা: হেরিং গাংচিলের সদ্যোজাত ছানা মা-বাবার হলুদ ঠোঁটের লাল দাগে ঠোকর দেয় — এটি সহজাত খাদ্য-চাওয়া আচরণ। বিভিন্ন মডেলে ঠোকরের হার তুলনা করে দেখা যায়, লাল দাগ ও ঠোঁটের সরু-লম্বা আকৃতিই আসল সংকেত। দণ্ডগুলো আনুমানিক আপেক্ষিক হার দেখায়।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 190, fill: FK.alpha('#dfeaf2', .8) }, g);
    E('path', { d: 'M0 170Q120 162 360 168V190H0Z', fill: B.lin(g, 'soil', 90) }, g);
    const o = { nat: {}, nos: { spot: false }, bill: { head: false }, rod: { rod: true, head: false } }[ty];
    gullHead(g, 200, 54, 2.3, o);
    E('path', { d: 'M296 0V20', stroke: '#8a8070', 'stroke-width': 1 }, g); if (ty !== 'nat' && ty !== 'nos') E('path', { d: 'M150 0V60', stroke: '#8a8070', 'stroke-width': 1 }, g);
    B.tx(g, 12, 18, 'মডেল', { fs: 10, w: 700, c: '#2a4a5a' });
    /* আপেক্ষিক ঠোকরের দণ্ড */
    const keys = Object.keys(GP); keys.forEach((k, i) => { const y = 202 + i * 14, v = GP[k][3], on = k === ty;
      B.tx(g, 116, y + 8, GP[k][0], { fs: 9.6, a: 'end', c: on ? C.fg : C.mu, w: on ? 700 : 400 });
      E('rect', { x: 122, y, width: f1(180 * v / 1.3), height: 10, rx: 4, fill: on ? '#c0392b' : FK.alpha(C.fg, .2) }, g); });
    E('path', { d: `M${f1(122 + 180 / 1.3)} 198V256`, stroke: FK.alpha(C.fg, .45), 'stroke-dasharray': '2 2' }, g);
    B.tx(g, 122 + 180 / 1.3 + 3, 196, 'স্বাভাবিক = 1', { fs: 8.8, c: C.mu });
  },
  anim(g, C, ty, t) { const v = GP[ty][3], rate = 1.6 * v, ph = (t * rate) % 1, k = ph < .3 ? Math.sin(ph / .3 * PI) : 0;
    gullChick(g, 92, 150, 2.6, k);
    if (k > .8) E('circle', { cx: 130, cy: 74, r: 8, fill: 'none', stroke: '#e0a030', 'stroke-width': 1.6 }, g); }
}));

/* ═════════ ট্যাক্সিসের জীব ═════════ */
const euglena = (g, x, y, s, a) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: 'M14 0C12 -4 4 -5 -4 -4C-10 -3 -14 -1 -16 0C-14 1 -10 3 -4 4C4 5 12 4 14 0Z', fill: B.vol(gg, 'leaf'), stroke: '#3a6a22', 'stroke-width': .5 }, gg);
  for (let i = 0; i < 6; i++) E('path', { d: B.ellD(-8 + i * 3.6, (i % 2 ? 1.2 : -1.2), 1.6, .9, 20), fill: '#3a8a2a' }, gg);
  E('circle', { cx: 10, cy: -1.4, r: 1.3, fill: '#e0302a' }, gg);
  E('path', { d: `M14 0q6 ${f1(Math.sin(a * 9) * 3 + 3)} 12 0t12 0`, stroke: '#4a6a3a', 'stroke-width': .5, fill: 'none' }, gg); };
const maggot = (g, x, y, s, a) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: 'M12 0C10 -3 2 -4 -6 -4C-11 -4 -13 -2 -13 0C-13 2 -11 4 -6 4C2 4 10 3 12 0Z', fill: '#f4efe0', stroke: '#b0a88a', 'stroke-width': .6 }, gg);
  for (let i = 0; i < 8; i++) E('path', { d: `M${-9 + i * 2.6} -3.6v7.2`, stroke: '#d0c8a8', 'stroke-width': .5 }, gg);
  E('path', { d: 'M12 -.8l2 .8l-2 .8', stroke: '#2a2018', 'stroke-width': .8, fill: 'none' }, gg); };
const planaria = (g, x, y, s, a) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: 'M16 0C16 -3 14 -6 11 -5C10 -3 8 -3 7 -4C2 -4 -8 -3 -14 -1C-16 0 -16 1 -14 1C-8 3 2 4 7 4C8 3 10 3 11 5C14 6 16 3 16 0Z', fill: '#8a6a52', stroke: '#4a3424', 'stroke-width': .5 }, gg);
  [-1.6, 1.6].forEach(dy => { E('circle', { cx: 11, cy: dy, r: 1, fill: '#fff' }, gg); E('circle', { cx: 11.2, cy: dy, r: .5, fill: '#111' }, gg); });
  E('path', { d: B.ellD(-1, 0, 2, 1), fill: '#c8a890' }, gg); };
const minnow = (g, x, y, s, a, w) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: `M-12 0L-19 ${f1(-5 + w)}L-18 ${f1(w)}L-19 ${f1(5 + w)}Z`, fill: '#98a47c', stroke: '#56603e', 'stroke-width': .5 }, gg);
  E('path', { d: 'M14 0C12 -4 4 -6 -4 -5C-10 -4 -13 -2 -13 0C-13 2 -10 4 -4 5C4 6 12 4 14 0Z', fill: B.lin(gg, 'fish', 90), stroke: '#56603e', 'stroke-width': .6 }, gg);
  E('circle', { cx: 9, cy: -1.2, r: 1.4, fill: '#111' }, gg); E('path', { d: 'M5 -4Q3 0 5 4', stroke: '#56603e', 'stroke-width': .5, fill: 'none' }, gg); };
const paramecium = (g, x, y, s, a, t) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: 'M12 0C12 -4 6 -5 0 -5C-8 -5 -12 -3 -12 0C-12 3 -8 4 -2 3C2 3 3 5 6 4C10 4 12 2 12 0Z', fill: '#e8eef4', stroke: '#6a7a8a', 'stroke-width': .6 }, gg);
  for (let i = 0; i < 18; i++) { const u = i / 18 * 2 * PI; E('path', { d: `M${f1(Math.cos(u) * 12)} ${f1(Math.sin(u) * 4.6)}l${f1(Math.cos(u + Math.sin(t * 20 + i) * .5) * 1.8)} ${f1(Math.sin(u) * 1.8)}`, stroke: '#8a9aaa', 'stroke-width': .35 }, gg); }
  E('path', { d: B.ellD(-1, 0, 3.6, 2), fill: '#b8a8d0' }, gg); E('path', { d: 'M3 2Q5 0 4 -2', stroke: '#6a7a8a', 'stroke-width': .5, fill: 'none' }, gg); };

const TX = {
  ph: ['ধনাত্মক আলোকট্যাক্সিস', 'ইউগ্লিনা — আলোর দিকে', 'ইউগ্লিনার সামনের দিকে লাল চক্ষুবিন্দু (স্টিগমা) ফ্ল্যাজেলামের গোড়ার আলোকগ্রাহী ফোলা অংশকে ছায়া দেয়; সাঁতারের সময় দেহ ঘোরে, আর ছায়া পড়া-না-পড়ার তুলনা করে কোষ আলোর দিকে মুখ করে এগোয় (ধনাত্মক ফটোট্যাক্সিস)।'],
  ng: ['ঋণাত্মক আলোকট্যাক্সিস', 'মাছির শূককীট — আলো থেকে দূরে', 'মাছির ম্যাগট (শূককীট) চলতে চলতে মাথা ডানে-বাঁয়ে দোলায় এবং মাথার আলোকগ্রাহীতে আলোর তীব্রতা তুলনা করে আলো থেকে সরাসরি দূরে চলে (ঋণাত্মক ফটোট্যাক্সিস, ক্লাইনোট্যাক্সিস ধরন) — খাদ্য ও অন্ধকার আশ্রয়ের দিকে।'],
  ch: ['রাসায়নিক ট্যাক্সিস', 'প্ল্যানেরিয়া — খাদ্যের রাসায়নিকের দিকে', 'চ্যাপ্টাকৃমি প্ল্যানেরিয়া মাথার দুই পাশের কানের মতো অংশের (অরিকল) রাসায়নিক গ্রাহক দিয়ে পানিতে ছড়ানো মাংসের রাসায়নিকের ঘনত্ব তুলনা করে খাদ্যের দিকে এগোয় (ধনাত্মক কেমোট্যাক্সিস)।'],
  rh: ['স্রোতট্যাক্সিস', 'মাছ — স্রোতের বিপরীতে মুখ করে', 'নদীর মাছ স্রোতের বিপরীতে মুখ করে সাঁতরায় এবং এক জায়গায় অবস্থান ধরে রাখে (ধনাত্মক রিওট্যাক্সিস) — পার্শ্বরেখা অঙ্গ ও দৃষ্টি পানির প্রবাহ শনাক্ত করে; এতে মাছ ভেসে যায় না এবং স্রোতে আসা খাবার পায়।'],
  gr: ['ঋণাত্মক অভিকর্ষট্যাক্সিস', 'প্যারামিসিয়াম — অভিকর্ষের বিপরীতে ওপরে', 'নলের পানিতে প্যারামিসিয়াম ওপরের দিকে জড়ো হয় (ঋণাত্মক জিওট্যাক্সিস/গ্র্যাভিট্যাক্সিস) — পানির ওপরের স্তরে অক্সিজেন বেশি। কেঁচো উল্টো, মাটির ভেতরের দিকে যায়।']
};
V.taxisTypes = Object.assign({}, B.seg({
  id: 'txs', t: 'ট্যাক্সিসের প্রকারভেদ', H: 250, def: 'ph', types: TX,
  cap: 'ট্যাক্সিস (Taxis): কোনো একমুখী উদ্দীপনার উৎসের দিকে (ধনাত্মক) বা উৎস থেকে দূরে (ঋণাত্মক) পুরো দেহের নির্দিষ্ট অভিমুখী চলন। উদ্দীপনার ধরন অনুযায়ী নাম — আলোক, রাসায়নিক, স্রোত, অভিকর্ষ, তাপ ইত্যাদি ট্যাক্সিস।',
  art(g, C, ty) {
    if (ty === 'ph' || ty === 'ng') { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: B.lin(g, 'wtr', 0) }, g);
      const gr = E('linearGradient', { id: 'txl' + ty, x1: 1, x2: 0 }, E('defs', {}, g)); E('stop', { offset: 0, 'stop-color': '#fff6c0', 'stop-opacity': .95 }, gr); E('stop', { offset: 1, 'stop-color': '#fff6c0', 'stop-opacity': 0 }, gr);
      E('rect', { x: 0, y: 0, width: 360, height: 200, fill: `url(#txl${ty})` }, g);
      E('path', { d: 'M350 70L336 82V118L350 130Z', fill: '#f6e070', stroke: '#a89020' }, g); for (let i = 0; i < 5; i++) E('path', { d: `M332 ${80 + i * 10}L310 ${70 + i * 15}`, stroke: '#e8c840', 'stroke-width': 1, opacity: .7 }, g);
      B.tx(g, 300, 24, 'আলোর উৎস', { fs: 10, a: 'middle', c: '#8a6a10', w: 700 }); }
    if (ty === 'ch') { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: '#e4ecf0' }, g); for (let i = 1; i <= 6; i++) E('circle', { cx: 290, cy: 100, r: i * 26, fill: FK.alpha('#c08060', .1) }, g); E('path', { d: B.ellD(290, 100, 12, 8, 20), fill: '#b85a50', stroke: '#6a2a20' }, g); B.tx(g, 290, 124, 'মাংসের টুকরো', { fs: 9.6, a: 'middle', c: '#6a2a20' }); }
    if (ty === 'rh') { E('rect', { x: 0, y: 0, width: 360, height: 200, fill: B.lin(g, 'wtr', 90) }, g); E('path', { d: 'M0 180Q180 170 360 182V200H0Z', fill: '#c8b48a' }, g); B.tx(g, 300, 22, 'স্রোতের দিক →', { fs: 10, a: 'middle', c: '#2a5a7a', w: 700 }); }
    if (ty === 'gr') { E('rect', { x: 140, y: 10, width: 80, height: 186, rx: 8, fill: B.lin(g, 'wtr', 0), stroke: '#7a9ab0', 'stroke-width': 1.4 }, g); B.arrow(g, 290, 60, 290, 150, '#6a4a2a', { w: 2 }); B.tx(g, 300, 108, 'অভিকর্ষ', { fs: 10, c: '#6a4a2a' }); B.tx(g, 180, 6, 'বেশি O<tspan baseline-shift="sub" font-size="68%">2</tspan>', { fs: 9.6, a: 'middle', c: '#2a5a7a' }); }
    B.tx(g, 180, 222, TX[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 242, ty === 'ng' || ty === 'gr' ? 'ঋণাত্মক — উদ্দীপনা থেকে দূরে' : 'ধনাত্মক — উদ্দীপনার দিকে', { fs: 10, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    for (let i = 0; i < 6; i++) { const r = B.rnd(i * 3 + 1), r2 = B.rnd(i * 7 + 2), ph = (t * .08 + r) % 1;
      if (ty === 'ph') { const x = lerp(20, 300, ph), y = 30 + r2 * 150 + Math.sin(t * 2 + i) * 4; euglena(g, x, y, 1.15, Math.sin(t * 3 + i) * .15); }
      if (ty === 'ng') { const x = lerp(300, 20, ph), y = 30 + r2 * 150; maggot(g, x, y, 1.3, PI + Math.sin(t * 4 + i) * .35); }
      if (ty === 'ch') { const a0 = r * 2 * PI, R = lerp(150, 20, ph), x = 290 + Math.cos(a0) * R * 1.4, y = 100 + Math.sin(a0) * R * .6, a = Math.atan2(100 - y, 290 - x) + Math.sin(t * 2 + i) * .2; if (x > 0) planaria(g, x, y, 1.3, a); }
      if (ty === 'rh') { const x = 60 + i * 40 + Math.sin(t * 1.3 + i) * 3, y = 40 + r2 * 120; minnow(g, x, y, 1.3, PI, Math.sin(t * 9 + i) * 1.6); }
      if (ty === 'gr') { const y = lerp(190, 24 + i * 6, FK.ease(cl(ph * 1.5))), x = 160 + r2 * 40; paramecium(g, x, y, .9, -PI / 2 + Math.sin(t * 2 + i) * .2, t); } }
    if (ty === 'rh') for (let i = 0; i < 8; i++) { const x = ((t * 60 + i * 47) % 380) - 10, y = 30 + (i * 23) % 140; E('path', { d: `M${f1(x)} ${y}h14`, stroke: FK.alpha('#2a6a9a', .4), 'stroke-width': 1.2, 'marker-end': B.mk(g, FK.alpha('#2a6a9a', .5), 4) }, g); }
  }
}));

/* ═════════ কাইনেসিস: উডলাইসের পছন্দ-কক্ষ ═════════ */
const woodlouse = (g, x, y, s, a) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(a * 180 / PI)}) scale(${s})` }, g);
  E('path', { d: B.ellD(0, 0, 8, 4.6), fill: '#7a7468', stroke: '#3a362e', 'stroke-width': .5 }, gg);
  for (let i = 0; i < 7; i++) E('path', { d: `M${f1(-5 + i * 1.8)} -4.2Q${f1(-6 + i * 1.8)} 0 ${f1(-5 + i * 1.8)} 4.2`, stroke: '#4a463c', 'stroke-width': .4, fill: 'none' }, gg);
  E('path', { d: 'M7 -1.6l5 -3M7 1.6l5 3', stroke: '#3a362e', 'stroke-width': .5 }, gg); };
const KN = (() => { const N = 26, steps = 600, out = []; for (let i = 0; i < N; i++) { let x = 30 + B.rnd(i) * 300, y = 40 + B.rnd(i + 40) * 120, a = B.rnd(i + 80) * 2 * PI; const tr = [];
    for (let k = 0; k < steps; k++) { const dry = x > 180, sp = dry ? 2.2 : .6, turn = dry ? .5 : .25; a += (B.rnd(i * 1000 + k) - .5) * turn * 2; x += Math.cos(a) * sp; y += Math.sin(a) * sp;
      if (x < 22) { x = 22; a = PI - a; } if (x > 338) { x = 338; a = PI - a; } if (y < 36) { y = 36; a = -a; } if (y > 166) { y = 166; a = -a; } tr.push([x, y, a]); }
    out.push(tr); } return out; })();
V.kinesisChoice = Object.assign({}, B.seg({
  id: 'kns', t: 'কাইনেসিস: উডলাইসের পছন্দ-কক্ষ পরীক্ষা', H: 250, def: 'run', types: { run: ['পরীক্ষা চলছে', 'আর্দ্র বনাম শুষ্ক কক্ষ', 'পছন্দ-কক্ষের এক পাশে ভেজা স্পঞ্জ (আর্দ্র), অন্য পাশে সিলিকা জেল (শুষ্ক)। উডলাইস শুষ্ক বাতাসে দ্রুত চলে ও বেশি ঘোরে, আর্দ্র বাতাসে ধীরে চলে বা থেমে যায় — কোনো নির্দিষ্ট দিকে না গিয়েও সময়ের সাথে বেশিরভাগ আর্দ্র পাশে জড়ো হয়।'] },
  cap: 'কাইনেসিস (Kinesis): উদ্দীপনার তীব্রতা অনুযায়ী চলনের গতি (অর্থোকাইনেসিস) বা দিক বদলের হার (ক্লাইনোকাইনেসিস) বদলায়, কিন্তু চলন উদ্দীপনার উৎসের দিকে নির্দিষ্ট অভিমুখী নয় — এটাই ট্যাক্সিসের সাথে মূল পার্থক্য। উডলাইস (চুচিপোকা জাতীয় ক্রাস্টেশিয়ান) এভাবে স্যাঁতসেঁতে আশ্রয়ে থাকে, তাদের দেহ শুকিয়ে যায় না।',
  art(g, C) { E('rect', { x: 18, y: 32, width: 162, height: 138, fill: FK.alpha('#5f90b4', .22), stroke: '#5f90b4' }, g); E('rect', { x: 180, y: 32, width: 162, height: 138, fill: FK.alpha('#e8c070', .22), stroke: '#c8a050' }, g);
    B.tx(g, 99, 24, 'আর্দ্র (ভেজা স্পঞ্জ)', { fs: 10.4, a: 'middle', w: 700, c: '#2a5a7a' }); B.tx(g, 261, 24, 'শুষ্ক (সিলিকা জেল)', { fs: 10.4, a: 'middle', w: 700, c: '#8a6010' });
    E('path', { d: 'M180 32V170', stroke: FK.alpha(C.fg, .4), 'stroke-dasharray': '4 3' }, g); },
  anim(g, C, ty, t) { const k = Math.floor((t * 14) % 600); let L = 0; KN.forEach(tr => { const [x, y, a] = tr[k]; if (x < 180) L++; woodlouse(g, x, y, 1.15, a); });
    const R = KN.length - L, m = Math.floor(k / 14 / 6);
    E('rect', { x: 18, y: 190, width: f1(324 * L / KN.length), height: 14, fill: '#5f90b4' }, g); E('rect', { x: f1(18 + 324 * L / KN.length), y: 190, width: f1(324 * R / KN.length), height: 14, fill: '#e0b050' }, g);
    B.tx(g, 22, 226, `আর্দ্র পাশে: ${L}টি`, { fs: 10.4, w: 700, c: '#2a5a7a' }); B.tx(g, 338, 226, `শুষ্ক পাশে: ${R}টি`, { fs: 10.4, a: 'end', w: 700, c: '#8a6010' });
    B.tx(g, 180, 244, 'শুরুতে সমানভাবে ছড়ানো → সময়ের সাথে আর্দ্র পাশে বেশি', { fs: 9.6, a: 'middle', c: C.mu }); }
}));
})();
