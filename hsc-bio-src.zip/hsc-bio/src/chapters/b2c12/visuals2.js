/* ═══════════════════════════════════════════════════════════════════
   visuals2 — আচরণ ও বংশগতি:
   hygienicBees (রোথেনবুলারের পরিচ্ছন্ন মৌমাছি), lovebirdNest (ডিলগারের লাভবার্ড)
   সহায়ক: B.bee (শ্রমিক/রানি/পুরুষ, ওপর থেকে), B.comb (চাকের ষড়ভুজ কোষ), B.lovebird
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, TP = B.tp;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ মৌমাছি (Apis), ওপর থেকে দেখা; মাথা +x দিকে, rot রেডিয়ান ═════════
   o = { caste: 'w' | 'q' | 'd', wings: 'fold' | 'spread', pollen, flap: 0..1 } */
B.bee = (g, x, y, s = 1, rot = 0, o = {}) => {
  const c = o.caste || 'w', gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) rotate(${f1(rot * 180 / PI)}) scale(${s})` }, g);
  const Y = B.TS('beeY'), D = B.TS('beeB'), WG = B.TS('wing');
  const ab = c === 'q' ? { cx: -17, rx: 18, ry: 7.6 } : c === 'd' ? { cx: -13, rx: 13, ry: 9.4 } : { cx: -12, rx: 13, ry: 7.6 };
  const th = c === 'd' ? { rx: 8, ry: 7.6 } : { rx: 6.6, ry: 6.2 };
  /* পা (তিন জোড়া, বক্ষ থেকে) */
  const L = [[[7, 5], [10, 10], [13, 13]], [[4, 6], [2, 12], [1, 17]], [[1, 6], [-6, 13], [-13, 17]]];
  [1, -1].forEach(sd => L.forEach((p, i) => { E('path', { d: `M${p[0][0]} ${p[0][1] * sd}L${p[1][0]} ${p[1][1] * sd}L${p[2][0]} ${p[2][1] * sd}`, stroke: '#2a1e14', 'stroke-width': i === 2 ? 1.5 : 1.1, fill: 'none', 'stroke-linejoin': 'round' }, gg);
    if (i === 2 && o.pollen) E('path', { d: B.ellD(-5, 12.6 * sd, 3, 2.2, 40 * sd), fill: '#f0a020', stroke: '#a86a10', 'stroke-width': .4 }, gg); }));
  /* উদর ও খণ্ডের ডোরা */
  E('path', { d: B.ellD(ab.cx, 0, ab.rx, ab.ry), fill: B.vol(gg, c === 'd' ? 'beeB' : 'beeY'), stroke: D.dk, 'stroke-width': .5 }, gg);
  const nb = c === 'q' ? 5 : 5;
  for (let i = 0; i < nb; i++) { const bx = ab.cx + ab.rx * (.62 - i * .3), u = (bx - ab.cx) / ab.rx, h = ab.ry * Math.sqrt(Math.max(0, 1 - u * u)) * .97;
    E('path', { d: `M${f1(bx)} ${f1(-h)}Q${f1(bx - 2.4)} 0 ${f1(bx)} ${f1(h)}`, stroke: c === 'd' ? '#120a06' : D.c, 'stroke-width': c === 'q' ? 2 : 2.6, fill: 'none', opacity: c === 'q' ? .65 : .9 }, gg); }
  /* কোমর, বক্ষ (রোমশ), মাথা */
  E('path', { d: B.ellD(0, 0, 2, 2.4), fill: D.c }, gg);
  E('path', { d: B.ellD(4.5, 0, th.rx, th.ry), fill: B.vol(gg, 'fur'), stroke: D.dk, 'stroke-width': .5 }, gg);
  for (let i = 0; i < 14; i++) { const a = i / 14 * 2 * PI; E('path', { d: `M${f1(4.5 + Math.cos(a) * th.rx * .92)} ${f1(Math.sin(a) * th.ry * .92)}l${f1(Math.cos(a) * 1.4)} ${f1(Math.sin(a) * 1.4)}`, stroke: '#c8a070', 'stroke-width': .5 }, gg); }
  const hx = c === 'd' ? 14.5 : 14;
  E('path', { d: B.ellD(hx, 0, 4.6, c === 'd' ? 6.2 : 5.4), fill: D.c, stroke: D.dk, 'stroke-width': .4 }, gg);
  /* পুঞ্জাক্ষি: পুরুষে বিশাল, মাথার ওপরে প্রায় মিলিত */
  [1, -1].forEach(sd => { if (c === 'd') E('path', { d: B.ellD(hx - .5, 3 * sd, 4.6, 3.4, 18 * sd), fill: '#3a2a20', stroke: '#120a06', 'stroke-width': .4 }, gg);
    else E('path', { d: B.ellD(hx, 4 * sd, 3, 1.7, 8 * sd), fill: '#3a2a20', stroke: '#120a06', 'stroke-width': .4 }, gg);
    E('path', { d: `M${hx + 3.6} ${1.5 * sd}L${hx + 7.6} ${3.2 * sd}L${hx + 10.6} ${7 * sd}`, stroke: '#1a120c', 'stroke-width': .8, fill: 'none' }, gg); });
  /* ডানা: দুই জোড়া — ভাঁজ বা মেলা */
  const fold = o.wings !== 'spread', fl = o.flap || 0;
  [1, -1].forEach(sd => {
    const a1 = fold ? (c === 'q' ? 8 : 10) : 48 - fl * 30, a2 = fold ? 6 : 30 - fl * 22, len = c === 'd' ? 22 : c === 'q' ? 16 : 19;
    E('path', { d: B.ellD(4 - Math.cos(a1 * PI / 180) * len * .5, sd * Math.sin(a1 * PI / 180) * len * .5 + sd * 1.5, len * .52, 3.8, 180 - a1 * sd), fill: FK.alpha(WG.lt, .72), stroke: WG.dk, 'stroke-width': .45 }, gg);
    E('path', { d: B.ellD(1 - Math.cos(a2 * PI / 180) * len * .36, sd * Math.sin(a2 * PI / 180) * len * .36 + sd * 2.2, len * .36, 2.6, 180 - a2 * sd), fill: FK.alpha(WG.lt, .6), stroke: WG.dk, 'stroke-width': .35 }, gg);
    E('path', { d: `M${f1(4)} ${f1(sd * 1.5)}L${f1(4 - Math.cos(a1 * PI / 180) * len * .9)} ${f1(sd * (Math.sin(a1 * PI / 180) * len * .9 + 1.5))}`, stroke: FK.alpha(WG.dk, .5), 'stroke-width': .35 }, gg); });
  return gg;
};

/* চাকের ষড়ভুজ কোষ (মুখোমুখি দৃশ্য, খাড়া সারি) — কেন্দ্রগুলোর তালিকা ফেরত দেয় */
const hexD = (x, y, r) => { let d = ''; for (let i = 0; i < 6; i++) { const a = PI / 6 + i * PI / 3; d += (i ? 'L' : 'M') + f1(x + r * Math.cos(a)) + ' ' + f1(y + r * Math.sin(a)); } return d + 'Z'; };
B.hexD = hexD;
B.comb = (g, x0, y0, cols, rows, r, fillFn) => { const out = [], w = r * Math.sqrt(3);
  for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) { const x = x0 + i * w + (j % 2 ? w / 2 : 0), y = y0 + j * r * 1.5; out.push([x, y, i, j]);
    E('path', { d: hexD(x, y, r), fill: '#e8c860', stroke: '#9a7420', 'stroke-width': 1.1 }, g); if (fillFn) fillFn(g, x, y, i, j); }
  return out; };
/* ঢাকা দেওয়া শূককীট-কোষ (সুস্থ: উঁচু, হালকা বাদামি মোমের ঢাকনা; রোগাক্রান্ত: বসে যাওয়া, গাঢ়, ছিদ্রযুক্ত) */
const cap = (g, x, y, r, sick) => { E('path', { d: hexD(x, y, r * .86), fill: sick ? '#8a6a3a' : B.vol(g, 'wax'), stroke: sick ? '#5a3a1a' : '#b08a3a', 'stroke-width': .6 }, g);
  if (sick) { E('circle', { cx: f1(x + r * .2), cy: f1(y - r * .15), r: f1(r * .16), fill: '#3a2410' }, g); E('path', { d: `M${f1(x - r * .5)} ${f1(y + r * .2)}q${f1(r * .5)} ${f1(-r * .25)} ${f1(r)} 0`, stroke: '#4a2e14', 'stroke-width': .6, fill: 'none' }, g); }
  else E('path', { d: B.ellD(x - r * .2, y - r * .25, r * .35, r * .2, -30), fill: '#fff', opacity: .35 }, g); };
/* খোলা কোষে মৃত শূককীট/মূককীট (বাদামি, গলে যাওয়া) */
const dead = (g, x, y, r) => { E('path', { d: hexD(x, y, r * .86), fill: '#5a3a1c' }, g); E('path', { d: B.ellD(x, y + r * .1, r * .5, r * .34, 10), fill: '#7a5028', stroke: '#3a2410', 'stroke-width': .5 }, g); };
const empty = (g, x, y, r) => { E('path', { d: hexD(x, y, r * .86), fill: B.vol(g, 'wax', { r: .8 }) }, g); E('path', { d: hexD(x, y, r * .5), fill: FK.alpha('#9a7420', .25) }, g); };

const HYG = {
  hyg: ['uu rr: পরিচ্ছন্ন', 'uu rr — ঢাকনা খোলে ও মৃত শূককীট সরায়', 'দুটি প্রচ্ছন্ন জিনই সমযুগ্মী: শ্রমিক রোগে (যেমন আমেরিকান ফাউলব্রুড) মরা শূককীটের কোষের মোমের ঢাকনা খুলে ফেলে (u) এবং মৃতদেহ টেনে চাক থেকে বের করে দেয় (r)। ফলে রোগ ছড়ায় না — এ কলোনি রোগ-প্রতিরোধী।'],
  unc: ['uu R_: শুধু ঢাকনা খোলে', 'uu R_ — ঢাকনা খোলে, কিন্তু মৃতদেহ সরায় না', 'ঢাকনা-খোলার জিন সমযুগ্মী প্রচ্ছন্ন (uu), কিন্তু সরানোর জিনে প্রকট অ্যালিল (R) আছে — তাই কোষ খোলা পড়ে থাকে, মৃত শূককীট ভেতরেই।'],
  rem: ['U_ rr: শুধু সরায়', 'U_ rr — নিজে খোলে না, খোলা থাকলে সরায়', 'ঢাকনা খোলে না (U প্রকট); কিন্তু গবেষক ঢাকনা খুলে দিলে মৃতদেহ সরিয়ে ফেলে (rr) — প্রমাণ করে দুটি আচরণ দুটি আলাদা জিন দিয়ে নিয়ন্ত্রিত।'],
  non: ['U_ R_: অপরিচ্ছন্ন', 'U_ R_ — কোনোটিই করে না', 'দুটি জিনেই প্রকট অ্যালিল — শ্রমিকেরা রোগাক্রান্ত কোষ উপেক্ষা করে; জীবাণু-স্পোর চাকে থেকে যায় এবং রোগ ছড়ায়।']
};
V.hygienicBees = Object.assign({}, B.seg({
  id: 'hyb', t: 'আচরণের বংশগতি: পরিচ্ছন্ন মৌমাছি', H: 286, def: 'hyg', types: HYG,
  cap: 'ওয়াল্টার রোথেনবুলার (1964) পরিচ্ছন্ন (রোগ-প্রতিরোধী) ও অপরিচ্ছন্ন মৌমাছির লাইনের সংকরায়ণে দেখান, "ঢাকনা খোলা" ও "মৃতদেহ সরানো" — দুটি আচরণ আলাদাভাবে বংশানুসরণ করে; ব্যাকক্রসে চার রকম কলোনি পাওয়া যায়। আচরণও জিন দিয়ে নিয়ন্ত্রিত হতে পারে (পরে দেখা গেছে আরও অনেক জিন জড়িত)।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 222, fill: '#c8a050' }, g);
    const r = 15, cells = B.comb(g, 10, 22, 12, 8, r, (q, x, y, i, j) => { const k = i + j * 12; const sick = k === 41 || k === 54 || k === 66; const target = k === 54;
      if (sick) cap(q, x, y, r, true); else if (j === 7 || i === 11) empty(q, x, y, r); else cap(q, x, y, r, false); });
    g._c = cells;
    B.tx(g, 180, 240, HYG[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg });
    const G = { hyg: ['uu', 'rr'], unc: ['uu', 'R_'], rem: ['U_', 'rr'], non: ['U_', 'R_'] }[ty];
    B.tx(g, 180, 262, `ঢাকনা-খোলা জিন: <tspan font-style="italic">${G[0]}</tspan>   ·   সরানোর জিন: <tspan font-style="italic">${G[1]}</tspan>`, { fs: 10.4, a: 'middle', c: C.mu });
    B.tx(g, 180, 280, 'গাঢ় বসে যাওয়া ঢাকনা = রোগে মরা শূককীট', { fs: 9.6, a: 'middle', c: '#7a5a2a' });
  },
  anim(g, C, ty, t) {
    const r = 15, w = r * Math.sqrt(3), tx = 10 + 6 * w + w / 2, ty0 = 22 + 4 * r * 1.5, S = 1.35;  /* কোষ 54 = i 6, j 4 */
    const ph = (t * .22) % 1;
    E('path', { d: hexD(tx, ty0, r + 2), fill: 'none', stroke: '#c0392b', 'stroke-width': 1.4, 'stroke-dasharray': '3 2', opacity: .8 }, g);
    if (ty === 'non') { const a = t * .5; B.bee(g, tx + Math.cos(a) * 70, ty0 + Math.sin(a) * 40, S, a + PI / 2); return; }
    /* লক্ষ্য কোষের অবস্থা: খোলার পর মৃতদেহ দেখা যায়; পরিচ্ছন্ন হলে সরানোর পর খালি */
    const opened = ty !== 'rem' && ph >= .5, removed = ty === 'hyg' && ph >= .58;
    if (removed) empty(g, tx, ty0, r); else if (opened) dead(g, tx, ty0, r);
    if (ph < .25) { const k = FK.ease(ph / .25); B.bee(g, lerp(340, tx + 30, k), lerp(206, ty0 + 2, k), S, PI); }
    else if (ph < .55) { const k = (ph - .25) / .3, jig = Math.sin(t * 40) * 1.2;
      if (ty !== 'rem') for (let i = 0; i < 4; i++) E('circle', { cx: f1(tx + 8 + i * 5 + k * 12), cy: f1(ty0 + 10 + (i % 2) * 4 + k * 10), r: 1.3, fill: '#6a4a24', opacity: f1(k) }, g);
      B.bee(g, tx + 24 + jig, ty0 + 1, S, PI); }
    else if (ph < .88) { const k = FK.ease((ph - .55) / .33);
      if (ty === 'hyg') { E('path', { d: B.ellD(lerp(tx + 6, tx + 130, k), lerp(ty0 + 2, ty0 + 104, k), 6.5, 4.2, 10), fill: '#7a5028', stroke: '#3a2410', 'stroke-width': .5 }, g); B.bee(g, lerp(tx + 26, tx + 150, k), lerp(ty0, ty0 + 102, k), S, PI * 1.15); }
      else B.bee(g, lerp(tx + 26, 336, k), lerp(ty0, 50, k), S, -.4); }
    if (ty === 'rem' && ph > .6) B.tx(g, tx, ty0 - 24, 'ঢাকনা খোলেনি — তাই সরানোও হলো না', { fs: 9.6, a: 'middle', c: '#7a2a1a', w: 600 });
  }
}));

/* ═════════ লাভবার্ড (Agapornis), পার্শ্বদৃশ্য, বামমুখী ═════════
   sp: 'fis' (ফিশারের: কমলা-লাল মাথা, চোখে সাদা বলয়, লাল ঠোঁট) | 'ros' (গোলাপি-মুখ: পীচ রঙের মুখ, লাল কপাল, হলুদাভ ঠোঁট) | 'hyb' */
B.lovebird = (g, x, y, s = 1, sp = 'fis', o = {}) => {
  const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  const face = sp === 'fis' ? '#e8702a' : sp === 'ros' ? '#f4a090' : '#ec8a5a', fore = sp === 'fis' ? '#d8502a' : '#d8383a', bill = sp === 'fis' ? '#d8322a' : '#e8d098';
  /* লেজ ও পিঠ-কটি (নীল কটি দুই প্রজাতিতেই) */
  E('path', { d: 'M18 4L34 14L32 18L14 10Z', fill: '#3a8a4a', stroke: '#1e5a2a', 'stroke-width': .5 }, gg);
  E('path', { d: 'M8 -2C18 -2 22 4 18 10C14 12 8 10 6 6Z', fill: '#4a7ad0' }, gg);
  /* দেহ */
  E('path', { d: 'M-10 -10C-4 -16 10 -12 16 -2C20 6 14 14 4 15C-6 16 -14 10 -15 2C-16 -4 -14 -8 -10 -10Z', fill: B.vol(gg, 'grass'), stroke: '#2e6a2e', 'stroke-width': .6 }, gg);
  /* ডানা */
  E('path', { d: 'M-4 -6C6 -8 16 -2 18 6C12 10 2 10 -4 4Z', fill: '#3e8a3a', stroke: '#1e5a1e', 'stroke-width': .5 }, gg);
  for (let i = 0; i < 4; i++) E('path', { d: `M${f1(2 + i * 4)} ${f1(-2 + i)}q3 4 6 6`, stroke: '#2a6a2a', 'stroke-width': .5, fill: 'none' }, gg);
  /* মাথা ও মুখ */
  E('path', { d: 'M-12 -10C-12 -20 -2 -24 4 -18C8 -14 6 -8 0 -6C-6 -4 -12 -6 -12 -10Z', fill: sp === 'fis' ? '#6aa84a' : '#5a9a4a' }, gg);
  E('path', { d: 'M-13 -12C-14 -20 -6 -23 -1 -20C0 -16 -2 -10 -6 -6C-10 -6 -13 -8 -13 -12Z', fill: face }, gg);
  E('path', { d: 'M-12 -16C-11 -21 -5 -23 -2 -21C-5 -19 -9 -17 -12 -16Z', fill: fore }, gg);
  /* চোখ (ফিশারে পালকহীন সাদা বলয়) */
  if (sp === 'fis') E('circle', { cx: -6, cy: -15, r: 2.6, fill: '#fff', stroke: '#ccc', 'stroke-width': .3 }, gg);
  E('circle', { cx: -6, cy: -15, r: 1.3, fill: '#1a120c' }, gg);
  /* ঠোঁট (বাঁকা, তোতার মতো) */
  E('path', { d: 'M-12 -15C-17 -15 -19 -11 -17 -8C-16 -9 -15 -10 -13 -10Z', fill: bill, stroke: '#6a3a1a', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-13 -10C-16 -9 -16 -7 -14 -6L-11 -8Z', fill: bill, stroke: '#6a3a1a', 'stroke-width': .4 }, gg);
  /* পা ও আঙুল (জাইগোড্যাকটিল) */
  E('path', { d: 'M0 14L-1 20M4 14L5 20', stroke: '#8a7a6a', 'stroke-width': 1.2 }, gg);
  return gg;
};
const LB = {
  fis: ['ফিশারের লাভবার্ড', 'A. fischeri — ঠোঁটে করে বহন', 'গাছের ছাল বা পাতা থেকে ঠোঁট দিয়ে ছোট ফালি কেটে প্রতিবার একটি ফালি ঠোঁটে চেপে বাসায় নিয়ে যায়। এ আচরণ শেখানো লাগে না — সহজাত।'],
  ros: ['গোলাপি-মুখ লাভবার্ড', 'A. roseicollis — কোমরের পালকে গুঁজে বহন', 'লম্বা ফালি কেটে পিঠের নিচের (কটি) পালকের ফাঁকে গুঁজে দেয় এবং একসাথে কয়েকটি ফালি নিয়ে উড়ে যায়।'],
  hyb: ['সংকর', 'সংকর লাভবার্ড — দ্বিধাগ্রস্ত আচরণ', 'দুই প্রজাতির সংকর ফালি কেটে কোমরে গোঁজার চেষ্টা করে, কিন্তু ঠিকমতো গুঁজতে পারে না — ফালি পড়ে যায়, বারবার চেষ্টা করে। প্রায় 3 বছরে ধীরে ধীরে ঠোঁটে বহন করা শেখে, তবু বহনের আগে মাথা কোমরের দিকে ঘোরায় — মাঝামাঝি, বংশগত আচরণ যা শিখনে কিছুটা বদলায়।']
};
V.lovebirdNest = Object.assign({}, B.seg({
  id: 'lvb', t: 'আচরণের বংশগতি: লাভবার্ডের বাসার উপকরণ বহন', H: 260, def: 'hyb', types: LB,
  cap: 'উইলিয়াম ডিলগার (1962) দুই প্রজাতির লাভবার্ড ও তাদের সংকর নিয়ে দেখান, বাসার উপকরণ বহনের ধরন বংশগত: সংকরে দুই পিতামাতার আচরণের মিশ্র ও দ্বিধাগ্রস্ত রূপ দেখা যায়, যা শিখনে আংশিক বদলায়।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 200, fill: FK.alpha('#e8f0e0', .7) }, g);
    E('path', { d: 'M20 150L340 138', stroke: B.TS('wood').c, 'stroke-width': 8, 'stroke-linecap': 'round' }, g);
    E('path', { d: 'M20 150L340 138', stroke: B.TS('wood').dk, 'stroke-width': 1, opacity: .6, 'stroke-dasharray': '10 14' }, g);
    /* ছালের ফালির উৎস */
    E('rect', { x: 250, y: 60, width: 70, height: 50, rx: 3, fill: '#efe6cc', stroke: '#a89a70', 'stroke-width': .8 }, g);
    for (let i = 0; i < 6; i++) E('path', { d: `M${256 + i * 10} 62V108`, stroke: FK.alpha('#a89a70', .5), 'stroke-width': .6 }, g);
    B.tx(g, 285, 54, 'কাগজ বা ছাল', { fs: 9.6, a: 'middle', c: C.mu });
    B.tx(g, 180, 222, LB[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg, st: 'font-style:normal' });
  },
  anim(g, C, ty, t) {
    const sp = ty === 'hyb' ? 'hyb' : ty, ph = (t * .25) % 1;
    const bird = B.lovebird(g, 150, 118, 2.2, sp);
    /* ফালি */
    if (ty === 'fis') { const k = FK.ease(cl((ph - .2) / .5)); E('path', { d: `M${f1(lerp(250, 108, k))} ${f1(lerp(80, 88, k))}l${f1(-14)} 2`, stroke: '#d8c890', 'stroke-width': 3, 'stroke-linecap': 'round' }, g); }
    else if (ty === 'ros') { for (let i = 0; i < 3; i++) { const on = ph > .2 + i * .22; if (on) E('path', { d: `M${168 + i * 3} ${108 - i * 3}q10 ${-12 + i * 2} 26 ${-10 + i * 3}`, stroke: '#d8c890', 'stroke-width': 2.6, fill: 'none', 'stroke-linecap': 'round' }, g); } }
    else { const k = (ph * 3) % 1, fall = k > .6; E('path', { d: fall ? `M${f1(180 + k * 20)} ${f1(110 + (k - .6) * 100)}l10 6` : `M${f1(lerp(118, 172, k / .6))} ${f1(lerp(86, 104, k / .6))}l18 -6`, stroke: '#d8c890', 'stroke-width': 2.6, 'stroke-linecap': 'round' }, g);
      if (!fall) E('path', { d: 'M150 92q16 -4 26 10', stroke: FK.alpha('#c0392b', .7), 'stroke-width': 1.2, fill: 'none', 'stroke-dasharray': '3 2', 'marker-end': B.mk(g, '#c0392b', 5) }, g); }
    bird.setAttribute('transform', bird.getAttribute('transform') + (ty === 'hyb' ? ` rotate(${f1(Math.sin(t * 3) * 6)})` : ''));
  }
}));
})();
