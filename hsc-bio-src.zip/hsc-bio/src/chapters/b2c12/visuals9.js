/* ═══════════════════════════════════════════════════════════════════
   visuals9 — সামাজিক আচরণ ও মৌমাছির সামাজিক সংগঠন:
   peckingOrder (মুরগির ঠোকরানোর ক্রম), socialTypes, beeCastes (রানি, শ্রমিক, পুরুষ), beeDevelopment,
   workerDuties (বয়সভিত্তিক শ্রমবিভাগ), waggleDance (মৌমাছির নাচ — দিক ও দূরত্ব)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* মুরগি (পার্শ্বদৃশ্য, বামমুখী) */
const hen = (g, x, y, s, col = '#c8865a', peck = 0) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: 'M10 -16C18 -26 24 -26 26 -18C24 -12 18 -10 14 -10Z', fill: '#3a2a20', opacity: .85 }, gg);
  E('path', { d: 'M-10 -14C-6 -22 8 -22 16 -12C20 -4 14 4 2 4C-8 4 -14 -2 -14 -8Z', fill: col, stroke: FK.alpha('#000', .4), 'stroke-width': .5 }, gg);
  E('path', { d: 'M-2 -14C6 -14 12 -8 12 -2', stroke: FK.alpha('#000', .25), 'stroke-width': .8, fill: 'none' }, gg);
  const hx = -12 - peck * 4, hy = -18 + peck * 8;
  E('path', { d: `M-6 -14L${hx + 2} ${hy + 2}`, stroke: col, 'stroke-width': 5, 'stroke-linecap': 'round' }, gg);
  E('circle', { cx: hx, cy: hy, r: 4, fill: col }, gg); E('path', { d: `M${hx - 2} ${hy - 4}q1 -3 3 -1q1 -3 3 0q1 -2 2 1`, fill: '#d8322a', stroke: '#a01a14', 'stroke-width': .4 }, gg);
  E('path', { d: `M${hx - 3} ${hy + 2}q0 4 2 4q2 0 1 -4`, fill: '#d8322a' }, gg); E('circle', { cx: hx - 1, cy: hy - .6, r: .8, fill: '#111' }, gg);
  E('path', { d: `M${hx - 4} ${hy}l-3 1l3 1`, fill: '#e8b040', stroke: '#9a6a10', 'stroke-width': .4 }, gg);
  E('path', { d: 'M0 4L-1 10M5 4L6 10', stroke: '#e0a040', 'stroke-width': 1.2 }, gg); return gg; };
const HN = ['ক', 'খ', 'গ', 'ঘ', 'ঙ'], HC = ['#f0ece0', '#c8865a', '#3a2a20', '#d8b070', '#8a5a3a'];
V.peckingOrder = Object.assign({}, B.seg({
  id: 'pko', t: 'প্রাধান্য-ক্রম: মুরগির ঠোকরানোর ক্রম', H: 280, def: 'line', types: {
    line: ['সরল ক্রম', 'একরৈখিক প্রাধান্য-ক্রম', 'থোরলেইফ শেলডেরাপ-এবে (1922) মুরগির দলে দেখান, প্রতিটি মুরগি নির্দিষ্ট কয়েকজনকে ঠোকরায় এবং অন্য কয়েকজনের ঠোকর সহ্য করে। "ক" সবাইকে ঠোকরায়, "ঙ" কাউকে পারে না — একবার ক্রম ঠিক হয়ে গেলে লড়াই কমে যায়; খাবার, বসার জায়গা ও বাসার জায়গায় ওপরের সদস্যরা আগে সুযোগ পায়।'],
    new: ['নতুন সদস্য', 'নতুন মুরগি ঢুকলে', 'নতুন বা অপরিচিত মুরগি দলে এলে কয়েক দিন লড়াই বেড়ে যায়, যতক্ষণ না সে ক্রমে নিজের জায়গা পায়। খামারে বারবার দল ভাঙলে চাপ ও আঘাত বাড়ে, ডিম পাড়া কমে।']
  },
  cap: 'প্রাধান্য-ক্রম (Dominance hierarchy): দলের সদস্যদের মধ্যে শক্তি বা মর্যাদার স্থিতিশীল সামাজিক স্তর। প্রতিবার লড়াই না করে আগের ফলাফল মনে রেখে চলায় শক্তি ও আঘাতের ঝুঁকি কমে — সামাজিক আচরণের অন্যতম সুবিধা। বানর, নেকড়ে, হাতির দলেও এমন ক্রম দেখা যায়।',
  art(g, C, ty) { const n = ty === 'new' ? 5 : 5;
    E('rect', { x: 0, y: 0, width: 360, height: 220, fill: FK.alpha('#efe8da', .6) }, g);
    for (let i = 0; i < n; i++) { const x = 52 + i * 64, y = 60 + i * 30; E('rect', { x: x - 26, y: y + 14, width: 52, height: 4, rx: 2, fill: FK.alpha(C.fg, .12) }, g); hen(g, x, y + 10, 1.3, HC[i]); B.tx(g, x, y + 34, HN[i], { fs: 12, a: 'middle', w: 700, c: C.fg }); }
    B.tx(g, 10, 22, 'ওপরে: সবচেয়ে প্রভাবশালী', { fs: 9.6, c: C.mu }); B.tx(g, 350, 214, 'নিচে: সবচেয়ে দুর্বল', { fs: 9.6, a: 'end', c: C.mu });
    B.tx(g, 180, 244, ty === 'line' ? 'ক → খ → গ → ঘ → ঙ (তীর = কে কাকে ঠোকরায়)' : 'নতুন সদস্য "ঙ" — জায়গা খুঁজতে লড়াই', { fs: 10.4, a: 'middle', c: C.fg, w: 600 }); },
  anim(g, C, ty, t) { const k = Math.floor(t * .8) % 4, ph = (t * .8) % 1, a = k, b = k + 1, xa = 52 + a * 64, ya = 70 + a * 30, xb = 52 + b * 64, yb = 70 + b * 30;
    E('path', { d: `M${xa + 14} ${ya - 10}Q${(xa + xb) / 2} ${ya - 30} ${xb - 18} ${yb - 20}`, stroke: '#c0392b', 'stroke-width': 1.6, fill: 'none', 'marker-end': B.mk(g, '#c0392b', 5), opacity: f1(.4 + .6 * Math.sin(ph * PI)) }, g);
    if (ty === 'new' && ph < .5) for (let i = 0; i < 3; i++) E('path', { d: `M${xb - 10 + i * 8} ${yb - 26}l3 -6`, stroke: '#e0a030', 'stroke-width': 1.4 }, g); }
}));

/* ═════════ সামাজিক আচরণের ধরন ═════════ */
const ST = {
  coop: ['সহযোগিতা ও শ্রমবিভাগ', 'মৌমাছি, পিঁপড়া, উইপোকা', 'সামাজিক পতঙ্গে কাজ ভাগ করা — রানি ডিম পাড়ে, শ্রমিকেরা খাবার আনে, বাচ্চা লালন করে ও বাসা পাহারা দেয়। একক সদস্য একা যা পারত না, দল একসাথে তা পারে।'],
  terr: ['এলাকা রক্ষা', 'দোয়েলের এলাকা', 'প্রজনন ঋতুতে পুরুষ দোয়েল নির্দিষ্ট এলাকা গান গেয়ে ও প্রদর্শন করে দখলে রাখে; অন্য পুরুষ ঢুকলে তাড়িয়ে দেয়। এতে খাবার ও বাসার জায়গা নিশ্চিত হয় এবং সরাসরি লড়াই কমে।'],
  alarm: ['সতর্কসংকেত (পরার্থতা)', 'বিপদের ডাক', 'কাঠবিড়ালি বা পাখি শিকারি দেখলে বিশেষ ডাক দেয় — নিজের ঝুঁকি বাড়লেও দলের অন্যরা (প্রায়ই আত্মীয়) পালাতে পারে। আত্মীয়দের মধ্যে একই জিন থাকায় এ পরার্থ আচরণ টিকে থাকে (হ্যামিল্টনের আত্মীয়-নির্বাচন ধারণা)।'],
  comm: ['যোগাযোগ', 'রাসায়নিক, শব্দ, দৃশ্য ও স্পর্শ সংকেত', 'দলবদ্ধ জীবনে যোগাযোগ অপরিহার্য — মৌমাছির নাচ ও ফেরোমোন, পিঁপড়ার গন্ধের পথ, পাখির গান, বানরের মুখভঙ্গি। সংকেতের মাধ্যমে খাবারের খবর, বিপদ, প্রজনন ও দলের পরিচয় জানানো হয়।']
};
V.socialTypes = Object.assign({}, B.seg({
  id: 'sct', t: 'সামাজিক আচরণের রূপ', H: 260, def: 'coop', types: ST,
  cap: 'সামাজিক আচরণ (Social behaviour): একই প্রজাতির সদস্যদের পারস্পরিক ক্রিয়া — সহযোগিতা, শ্রমবিভাগ, প্রাধান্য-ক্রম, এলাকা রক্ষা, যোগাযোগ ও পরার্থতা। সুবিধা: শিকারি থেকে সুরক্ষা, খাদ্য খোঁজায় দক্ষতা, সন্তান লালন; অসুবিধা: খাদ্যের প্রতিযোগিতা ও রোগ ছড়ানো।',
  art(g, C, ty) { E('rect', { x: 0, y: 0, width: 360, height: 210, fill: FK.alpha('#e8f0e0', .6) }, g);
    if (ty === 'coop') { E('rect', { x: 0, y: 0, width: 360, height: 210, fill: '#c8a050' }, g); B.comb(g, 10, 20, 12, 7, 15, null); }
    if (ty === 'terr') { [[90, 100, 70], [220, 90, 66], [160, 170, 60], [300, 170, 50]].forEach(([x, y, r], i) => { E('path', { d: sm(Array.from({ length: 9 }, (_, k) => { const a = k / 9 * 2 * PI, rr = r * (.85 + B.rnd(i * 9 + k) * .3); return [x + Math.cos(a) * rr, y + Math.sin(a) * rr * .7]; }), true), fill: FK.alpha(BK.pal(i), .12), stroke: BK.pal(i), 'stroke-width': 1.2, 'stroke-dasharray': '4 3' }, g); B.doyel(g, x, y, 1.3, 1); }); }
    if (ty === 'alarm') { E('rect', { x: 0, y: 170, width: 360, height: 40, fill: B.lin(g, 'grass', 90) }, g); [60, 130, 210].forEach((x, i) => B.squirrel(g, x, 176, 1.3, i === 0 ? 0 : .3)); }
    if (ty === 'comm') { [['রাসায়নিক (ফেরোমোন)', 70, 60, '#3a7a4a'], ['শব্দ (গান, ডাক)', 280, 60, '#2a6ab0'], ['দৃশ্য (রং, ভঙ্গি, নাচ)', 70, 160, '#c0392b'], ['স্পর্শ (শুঙ্গ ছোঁয়া)', 280, 160, '#a86a10']].forEach(([l, x, y, c]) => { E('circle', { cx: x, cy: y, r: 34, fill: FK.alpha(c, .12), stroke: c }, g); B.tx(g, x, y + 50, l, { fs: 9.6, a: 'middle', w: 700, c }); }); B.bee(g, 70, 60, 1.2, 0); B.doyel(g, 280, 66, 1.6, 1); B.stickle(g, 70, 160, 1.4, 1, { red: true }); B.bee(g, 266, 160, 1, 0); B.bee(g, 294, 160, 1, PI); }
    B.tx(g, 180, 234, ST[ty][1], { fs: 11, a: 'middle', w: 700, c: C.fg }); },
  anim(g, C, ty, t) {
    if (ty === 'coop') { for (let i = 0; i < 6; i++) { const a = t * .4 + i * 1.05, x = 180 + Math.cos(a) * (60 + i * 12), y = 105 + Math.sin(a * 1.3) * 60; B.bee(g, x, y, 1.1, a + PI / 2, { pollen: i % 2 }); } }
    if (ty === 'terr') { const k = (t * .3) % 1, x = lerp(360, 250, Math.sin(k * PI)), y = 120; B.doyel(g, x, y, 1.1, -1); if (k > .3 && k < .7) for (let i = 0; i < 3; i++) E('path', { d: `M${228 + i * 6} ${70 - i * 4}q6 -4 12 0`, stroke: '#2a6ab0', 'stroke-width': 1.2, fill: 'none' }, g); }
    if (ty === 'alarm') { const k = (t * .4) % 1; for (let r = 0; r < 3; r++) E('circle', { cx: 60, cy: 130, r: f1(((k + r / 3) % 1) * 60), fill: 'none', stroke: '#c0392b', 'stroke-width': 1.2, opacity: f1(1 - (k + r / 3) % 1) }, g); B.tx(g, 60, 110, 'সতর্ক ডাক!', { fs: 9.6, a: 'middle', w: 700, c: '#a8201a' });
      const hx = lerp(380, 300, Math.sin(k * PI)); E('path', { d: `M${hx} 40l-18 6l18 6l-6 -6Z M${hx} 46l20 -8M${hx} 46l20 8`, fill: '#5a4030', stroke: '#3a2a20', 'stroke-width': 1.4 }, g); B.tx(g, hx, 30, 'বাজপাখি', { fs: 9, a: 'middle', c: C.mu }); }
  }
}));

/* ═════════ মৌমাছির তিন শ্রেণি ═════════ */
V.beeCastes = Object.assign({ t: 'মৌমাছির তিন শ্রেণি: রানি, শ্রমিক ও পুরুষ', k: ['2d', 'anim', 'int', 'quiz'], cap: 'একটি মৌচাকে (Apis mellifera) সাধারণত একটি রানি, হাজার হাজার শ্রমিক (গ্রীষ্মে 20,000–60,000 বা আরও বেশি) এবং মৌসুমে কয়েকশো পুরুষ (ড্রোন) থাকে। চিত্রে তিনটি আনুমানিক সমান অনুপাতে আঁকা — নিচের দাগ 5 মিমি।' },
  BK.diagram({ W: 360, H: 290, label: 'মৌমাছির শ্রেণি', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), S = 2.3;
      E('rect', { x: 0, y: 0, width: 360, height: 290, fill: FK.alpha('#fbf3dc', .8) }, g);
      B.bee(P('queen'), 72, 125, S * 1.18, -PI / 2, { caste: 'q' }); B.bee(P('worker'), 182, 125, S, -PI / 2, { caste: 'w', pollen: true }); B.bee(P('drone'), 292, 125, S * 1.1, -PI / 2, { caste: 'd' });
      [['রানি', 72, 'প্রায় 18–22 মিমি'], ['শ্রমিক', 182, 'প্রায় 12–15 মিমি'], ['পুরুষ (ড্রোন)', 292, 'প্রায় 15–17 মিমি']].forEach(([n, x, l]) => { B.tx(g, x, 236, n, { fs: 11.4, a: 'middle', w: 700, c: '#5a3a10' }); B.tx(g, x, 252, l, { fs: 9.6, a: 'middle', c: C.mu }); });
      E('path', { d: 'M150 272h' + f1(5 * 44 * S / 13.5), stroke: C.fg, 'stroke-width': 2 }, g); B.tx(g, 150, 284, '5 মিমি', { fs: 8.8, c: C.mu });
      ['eye', 'basket', 'abd', 'sting'].forEach(k => P(k));
      hits(this.parts, part, 12); },
    idle(g, C, t) { const k = Math.sin(t * 3) * .5 + .5; E('circle', { cx: 182, cy: 125, r: f1(52 + k * 4), fill: 'none', stroke: FK.alpha('#e0a030', .25), 'stroke-width': 2 }, g); },
    parts: [
      { id: 'queen', bn: 'রানি মৌমাছি', lb: 'রানি', en: 'Queen', fn: 'উর্বর স্ত্রী (2n), কলোনির একমাত্র ডিম পাড়ার সদস্য — দিনে প্রায় 1,500–2,000টি পর্যন্ত। লম্বা উদর, ডানা উদরের অর্ধেক পর্যন্ত। রাজকীয় জেলি খেয়ে বড় হয়; ফেরোমোন দিয়ে কলোনির ঐক্য বজায় রাখে। আয়ু কয়েক বছর।', a: [72, 113], l: [20, 40], an: 'start' },
      { id: 'worker', bn: 'শ্রমিক মৌমাছি', lb: 'শ্রমিক', en: 'Worker', fn: 'বন্ধ্যা স্ত্রী (2n) — সংখ্যায় সবচেয়ে বেশি। বয়স অনুযায়ী কোষ পরিষ্কার, লার্ভা লালন, মোম তৈরি, পাহারা ও খাদ্য সংগ্রহ করে। গ্রীষ্মে আয়ু প্রায় 5–6 সপ্তাহ।', a: [182, 115], l: [182, 24], an: 'middle' },
      { id: 'drone', bn: 'পুরুষ মৌমাছি (ড্রোন)', lb: 'পুরুষ', en: 'Drone', fn: 'অনিষিক্ত ডিম থেকে জন্ম (n, হ্যাপ্লয়েড)। বড় চোখ, মোটা দেহ, হুল নেই; খাবার সংগ্রহ করে না। একমাত্র কাজ নতুন রানির সাথে উড়ন্ত অবস্থায় মিলন — মিলনের পর মারা যায়।', a: [292, 114], l: [352, 24], an: 'end' },
      { id: 'eye', bn: 'বড় পুঞ্জাক্ষি (পুরুষে)', lb: 'বিশাল পুঞ্জাক্ষি', en: 'Large compound eyes', fn: 'পুরুষের চোখ মাথার ওপরে প্রায় মিলিত — আকাশে উড়ন্ত রানিকে খুঁজে পেতে সাহায্য করে।', a: [292, 90], l: [352, 54], an: 'end' },
      { id: 'basket', bn: 'পরাগের ঝুড়ি (শ্রমিকে)', lb: 'পরাগের ঝুড়ি', en: 'Pollen basket', fn: 'শ্রমিকের পেছনের পায়ের চওড়া, লোমে ঘেরা অংশ (করবিকুলা) — পরাগ চেপে বলের মতো বহন করে।', a: [211, 137], l: [236, 212], an: 'start' },
      { id: 'abd', bn: 'লম্বা উদর (রানিতে)', lb: 'লম্বা উদর', en: 'Long abdomen', fn: 'রানির উদর লম্বা — বিকশিত ডিম্বাশয় ও শুক্রাণুধারক (স্পার্মাথিকা) থাকে, যেখানে মিলনের শুক্রাণু বছরের পর বছর জমা থাকে।', a: [72, 171], l: [14, 204], an: 'start' },
      { id: 'sting', bn: 'হুল', lb: 'হুল', en: 'Sting', fn: 'রূপান্তরিত ডিম্বাধার। শ্রমিকের হুলে উল্টো কাঁটা — স্তন্যপায়ীর চামড়ায় আটকে যায় ও হুল ফোটালে শ্রমিক মারা যায়; রানির হুল মসৃণ (প্রতিদ্বন্দ্বী রানির বিরুদ্ধে ব্যবহার করে); পুরুষের হুল নেই।', a: [182, 182], l: [132, 214], an: 'end' }
    ]
  }));

/* ═════════ মৌমাছির বিকাশ ═════════ */
const DV = { q: ['রানি', 3, 5.5, 7.5, 'রানিকোষ — ঝোলানো, চীনাবাদামের খোসার মতো; সারা লার্ভাকালে রাজকীয় জেলি'], w: ['শ্রমিক', 3, 6, 12, 'শ্রমিককোষ — ছোট ষড়ভুজ; প্রথম 3 দিন রাজকীয় জেলি, তারপর মধু ও পরাগের মিশ্রণ'], d: ['পুরুষ', 3, 6.5, 14.5, 'পুরুষকোষ — বড় ষড়ভুজ, ঢাকনা উঁচু গম্বুজের মতো; অনিষিক্ত ডিম']};
V.beeDevelopment = Object.assign({}, B.seg({
  id: 'bdv', t: 'মৌমাছির বিকাশ: ডিম থেকে পূর্ণাঙ্গ', H: 280, def: 'q', types: Object.fromEntries(Object.entries(DV).map(([k, v]) => [k, [v[0], `${v[0]}: মোট ${v[1] + v[2] + v[3]} দিন`, `ডিম ${v[1]} দিন → লার্ভা ${v[2]} দিন → পিউপা ${v[3]} দিন। ${v[4]}।`]])),
  cap: 'রানি ও শ্রমিক দুজনেই নিষিক্ত ডিম (2n, স্ত্রী) থেকে হয় — পার্থক্য তৈরি করে খাদ্য: রানির লার্ভা পুরো সময় রাজকীয় জেলি পায়। পুরুষ হয় অনিষিক্ত ডিম (n) থেকে — হ্যাপ্লো-ডিপ্লয়েড লিঙ্গ নির্ধারণ। সময়গুলো Apis mellifera এর গড় হিসাব (তাপমাত্রায় কিছুটা বদলায়)।',
  art(g, C, ty) { const X0 = 70, W = 270, D = 26, x = d => X0 + d / D * W;
    Object.entries(DV).forEach(([k, v], i) => { const y = 34 + i * 40, on = k === ty; B.tx(g, X0 - 8, y + 13, v[0], { fs: 11, a: 'end', w: on ? 700 : 500, c: on ? C.fg : C.mu });
      let d0 = 0; [['ডিম', v[1], '#f4efe0'], ['লার্ভা', v[2], '#f6d27a'], ['পিউপা', v[3], '#c8a070']].forEach(([l, n, c]) => { E('rect', { x: f1(x(d0)), y, width: f1(x(d0 + n) - x(d0)), height: 20, fill: c, stroke: on ? '#8a5410' : FK.alpha(C.fg, .3), 'stroke-width': on ? 1.2 : .6, opacity: on ? 1 : .55 }, g); if (on) B.tx(g, (x(d0) + x(d0 + n)) / 2, y + 14, l, { fs: 9, a: 'middle', c: '#4a3010' }); d0 += n; });
      B.tx(g, x(d0) + 4, y + 14, d0 + ' দিন', { fs: 9.6, w: 700, c: on ? '#8a5410' : C.mu }); });
    [0, 5, 10, 15, 20, 25].forEach(d => { E('path', { d: `M${f1(x(d))} 156v4`, stroke: C.mu }, g); B.tx(g, x(d), 170, String(d), { fs: 9, a: 'middle', c: C.mu }); }); B.tx(g, X0 + W, 184, 'দিন', { fs: 9, a: 'end', c: C.mu });
    /* কোষের আকার */
    const cy = 238; B.tx(g, 30, cy - 34, 'কোষ:', { fs: 10, c: C.mu });
    if (ty === 'q') { E('path', { d: `M180 ${cy - 30}C196 ${cy - 30} 200 ${cy - 4} 196 ${cy + 20}C192 ${cy + 34} 168 ${cy + 34} 164 ${cy + 20}C160 ${cy - 4} 164 ${cy - 30} 180 ${cy - 30}Z`, fill: B.vol(g, 'wax'), stroke: '#9a7420', 'stroke-width': 1 }, g); for (let i = 0; i < 6; i++) E('path', { d: `M${168 + i * 4} ${cy - 20 + i * 8}q6 2 12 0`, stroke: '#b09040', 'stroke-width': .6, fill: 'none' }, g); }
    else { const r = ty === 'd' ? 19 : 15; for (let i = -1; i <= 1; i++) { E('path', { d: B.hexD(180 + i * r * 1.75, cy, r), fill: '#e8c860', stroke: '#9a7420', 'stroke-width': 1 }, g); E('path', { d: B.hexD(180 + i * r * 1.75, cy, r * .82), fill: B.vol(g, 'wax'), stroke: ty === 'd' ? '#7a5a20' : '#b08a3a', 'stroke-width': ty === 'd' ? 1.6 : .6 }, g); } }
    B.tx(g, 180, 276, DV[ty][4].split('—')[0], { fs: 9.6, a: 'middle', c: C.mu }); },
  anim(g, C, ty, t) { const v = DV[ty], tot = v[1] + v[2] + v[3], d = (t * 3) % (tot + 3), X0 = 70, W = 270, i = ['q', 'w', 'd'].indexOf(ty), x = X0 + Math.min(d, tot) / 26 * W;
    E('path', { d: `M${f1(x)} ${30 + i * 40}V${58 + i * 40}`, stroke: '#c0392b', 'stroke-width': 2 }, g); B.tx(g, x, 24 + i * 40, `দিন ${Math.min(Math.floor(d), tot)}`, { fs: 9, a: 'middle', w: 700, c: '#a8201a' }); }
}));

/* ═════════ শ্রমিকের বয়সভিত্তিক কাজ ═════════ */
const WD = [[0, 3, 'কোষ পরিষ্কার', '#a8c0d0'], [3, 10, 'লার্ভা লালন (নার্স)', '#f6d27a'], [10, 16, 'মোম তৈরি ও চাক বানানো', '#ecd37a'], [16, 21, 'মধু সংরক্ষণ ও পাহারা', '#d8a070'], [21, 40, 'খাদ্য সংগ্রহ (বাইরে)', '#8ac070']];
V.workerDuties = Object.assign({}, B.seg({
  id: 'wdt', t: 'শ্রমিক মৌমাছির বয়সভিত্তিক শ্রমবিভাগ', H: 270, def: 'tl', types: { tl: ['সময়রেখা', 'বয়স (দিন) অনুযায়ী কাজ', 'তরুণ শ্রমিক চাকের ভেতরে কাজ করে: প্রথমে কোষ পরিষ্কার, তারপর মাথার হাইপোফ্যারিঞ্জিয়াল গ্রন্থি থেকে রাজকীয় জেলি তৈরি করে লার্ভা খাওয়ায়, পরে উদরের মোমগ্রন্থি বিকশিত হলে চাক বানায়; প্রায় তিন সপ্তাহ পর দরজায় পাহারা দিয়ে বাইরে মধু, পরাগ, পানি ও প্রোপোলিস সংগ্রহ করে। প্রয়োজনে (যেমন খাদ্য সংগ্রাহক কমে গেলে) এ ক্রম আগে-পিছে হতে পারে।'] },
  cap: 'বয়সভিত্তিক শ্রমবিভাগ (age polyethism): শ্রমিকের দেহের গ্রন্থি বয়সের সাথে বদলায়, তাই কাজও বদলায়। দিনগুলো আনুমানিক — মৌসুম ও কলোনির প্রয়োজনে বদলায়।',
  art(g, C) { const X0 = 20, W = 320, x = d => X0 + d / 40 * W;
    WD.forEach(([a, b, l, c], i) => { E('rect', { x: f1(x(a)), y: 60, width: f1(x(b) - x(a)), height: 36, fill: c, stroke: FK.alpha('#000', .25) }, g); const lx = (x(a) + x(b)) / 2, up = i % 2; B.tx(g, lx, up ? 120 : 50, l, { fs: 9.6, a: 'middle', w: 700, c: C.fg }); E('path', { d: `M${f1(lx)} ${up ? 98 : 54}V${up ? 108 : 60}`, stroke: FK.alpha(C.fg, .4) }, g); });
    [0, 5, 10, 15, 20, 25, 30, 35, 40].forEach(d => { E('path', { d: `M${f1(x(d))} 96v4`, stroke: C.mu }, g); B.tx(g, x(d), 140, String(d), { fs: 9, a: 'middle', c: C.mu }); }); B.tx(g, 340, 154, 'বয়স (দিন)', { fs: 9, a: 'end', c: C.mu });
    E('path', { d: `M${f1(x(21))} 30V100`, stroke: '#3a7a4a', 'stroke-width': 1.4, 'stroke-dasharray': '3 3' }, g); B.tx(g, x(21) + 4, 26, 'চাকের বাইরে →', { fs: 9, c: '#3a7a4a', w: 700 }); B.tx(g, x(21) - 4, 26, '← চাকের ভেতরে', { fs: 9, a: 'end', c: '#8a5410', w: 700 });
    B.tx(g, 180, 250, 'গ্রন্থির পরিবর্তন: হাইপোফ্যারিঞ্জিয়াল (জেলি) → মোমগ্রন্থি → বিষগ্রন্থি', { fs: 9.6, a: 'middle', c: C.mu }); },
  anim(g, C, ty, t) { const d = (t * 4) % 40, x = 20 + d / 40 * 320, k = WD.findIndex(w => d >= w[0] && d < w[1]);
    B.bee(g, x, 196, 1.5, 0, { pollen: k === 4, wings: k === 4 ? 'spread' : 'fold', flap: Math.sin(t * 40) * .5 + .5 }); B.tx(g, 180, 230, `দিন ${Math.floor(d)}: ${WD[Math.max(0, k)][2]}`, { fs: 10.4, a: 'middle', w: 700, c: '#5a3a10' }); }
}));

/* ═════════ মৌমাছির নাচ ═════════ */
V.waggleDance = Object.assign({}, B.seg({
  id: 'wgl', t: 'মৌমাছির নাচ: খাবারের দিক ও দূরত্ব জানানো', H: 300, def: 'wag', types: {
    wag: ['লেজ-নাড়া নাচ', 'লেজ-নাড়া নাচ (দূরের খাবার)', 'খাবার প্রায় 100 মিটারের বেশি দূরে হলে শ্রমিক খাড়া চাকের ওপর আট-এর মতো পথে নাচে। মাঝের সোজা অংশে উদর জোরে নাড়ায় (ওয়াগল রান)। এ অংশ খাড়া ওপরের দিক থেকে যত ডিগ্রি ঘোরানো, খাবার সূর্যের দিক থেকে ঠিক তত ডিগ্রি ডানে বা বাঁয়ে; ওয়াগল রান যত দীর্ঘ, খাবার তত দূরে।'],
    round: ['বৃত্তাকার নাচ', 'বৃত্তাকার নাচ (কাছের খাবার)', 'খাবার চাকের কাছে (প্রায় 50–100 মিটারের মধ্যে) হলে ছোট বৃত্তে ঘুরে ঘুরে নাচে, দিক উল্লেখ করে না — "কাছেই খাবার আছে, খোঁজো"। অন্যরা নর্তকীর গায়ের ফুলের গন্ধ থেকে খাবার চিনে নেয়।']
  },
  sl: [{ k: 'ang', l: 'সূর্য থেকে খাবারের কোণ', min: -150, max: 150, step: 15, val: 45, unit: '°' }, { k: 'dist', l: 'দূরত্ব (মিটার)', min: 200, max: 3000, step: 100, val: 1000, unit: '' }],
  cap: 'কার্ল ফন ফ্রিশ (নোবেল 1973) আবিষ্কার করেন, মৌমাছি অন্ধকার চাকের খাড়া দেয়ালে নেচে অন্য শ্রমিকদের খাবারের দিক ও দূরত্ব জানায় — খাড়া ওপর দিক মানে সূর্যের দিক। প্রায় 1 সেকেন্ডের ওয়াগল রান প্রায় 1 কিলোমিটার দূরত্ব বোঝায় (প্রজাতি ও জাতভেদে আলাদা)। ডানের স্লাইডার দিয়ে খাবারের অবস্থান বদলাও।',
  art(g, C, ty, ctx) { const a = (ty === 'round' ? 0 : ctx.v.ang) * PI / 180, D = ty === 'round' ? 80 : ctx.v.dist;
    /* বাঁয়ে মাঠ (ওপর থেকে) */
    E('rect', { x: 8, y: 20, width: 168, height: 230, rx: 8, fill: B.lin(g, 'grass', 90), opacity: .8 }, g); B.tx(g, 92, 14, 'মাঠ (ওপর থেকে)', { fs: 9.6, a: 'middle', c: C.mu });
    const hx = 92, hy = 200, sun = [92, 40]; E('circle', { cx: sun[0], cy: sun[1], r: 12, fill: '#f6d040', stroke: '#c89a10' }, g); for (let i = 0; i < 8; i++) { const q = i * PI / 4; E('path', { d: `M${f1(sun[0] + Math.cos(q) * 15)} ${f1(sun[1] + Math.sin(q) * 15)}l${f1(Math.cos(q) * 5)} ${f1(Math.sin(q) * 5)}`, stroke: '#c89a10', 'stroke-width': 1.2 }, g); }
    E('path', { d: `M${hx} ${hy}L${sun[0]} ${sun[1] + 16}`, stroke: '#c89a10', 'stroke-width': 1, 'stroke-dasharray': '3 3' }, g);
    E('rect', { x: hx - 9, y: hy - 6, width: 18, height: 18, rx: 3, fill: '#d8b070', stroke: '#7a5420' }, g); B.tx(g, hx, hy + 26, 'চাক', { fs: 9.6, a: 'middle', c: '#5a3a10' });
    const R = 30 + Math.min(1, D / 3000) * 120, fx = hx + Math.sin(a) * R, fy = hy - Math.cos(a) * R; E('path', { d: `M${hx} ${hy}L${f1(fx)} ${f1(fy)}`, stroke: '#c0392b', 'stroke-width': 1.4, 'marker-end': B.mk(g, '#c0392b', 5) }, g);
    for (let i = 0; i < 5; i++) { const q = i / 5 * 2 * PI; E('circle', { cx: f1(fx + Math.cos(q) * 4), cy: f1(fy + Math.sin(q) * 4), r: 3, fill: '#e070a0' }, g); } E('circle', { cx: f1(fx), cy: f1(fy), r: 2.4, fill: '#f6d040' }, g);
    if (ty !== 'round') { E('path', { d: `M${hx} ${hy - 24}A24 24 0 0 ${a > 0 ? 1 : 0} ${f1(hx + Math.sin(a) * 24)} ${f1(hy - Math.cos(a) * 24)}`, stroke: '#2a6ab0', 'stroke-width': 1.2, fill: 'none' }, g); B.tx(g, hx + (a >= 0 ? 30 : -30), hy - 30, Math.abs(ctx.v.ang) + '°', { fs: 10, a: 'middle', w: 700, c: '#2a6ab0' }); }
    /* ডানে খাড়া চাক */
    E('rect', { x: 186, y: 20, width: 166, height: 230, rx: 8, fill: '#c8a050' }, g); B.comb(g, 192, 30, 7, 11, 12, null); B.tx(g, 269, 14, 'খাড়া চাকের দেয়াল', { fs: 9.6, a: 'middle', c: C.mu });
    B.arrow(g, 344, 120, 344, 40, '#5a3a10', { w: 1.4 }); B.tx(g, 340, 34, 'ওপর = সূর্য', { fs: 8.8, a: 'end', w: 700, c: '#3a2a10', halo: '#c8a050' });
    B.tx(g, 180, 270, ty === 'round' ? 'বৃত্তাকার নাচ — শুধু "কাছে খাবার"' : `ওয়াগল রান: খাড়া থেকে ${ctx.v.ang > 0 ? 'ডানে' : ctx.v.ang < 0 ? 'বাঁয়ে' : ''} ${Math.abs(ctx.v.ang)}°, প্রায় ${(D / 1000).toFixed(1)} সেকেন্ড`, { fs: 10.4, a: 'middle', w: 700, c: C.fg });
    B.tx(g, 180, 290, ty === 'round' ? 'দূরত্ব প্রায় 50–100 মিটারের কম' : `খাবার: সূর্যের ${ctx.v.ang > 0 ? 'ডানে' : ctx.v.ang < 0 ? 'বাঁয়ে' : 'দিকে'} ${Math.abs(ctx.v.ang)}°, প্রায় ${D} মিটার দূরে`, { fs: 9.6, a: 'middle', c: C.mu }); },
  anim(g, C, ty, t, ctx) { const cx = 269, cy = 138;
    if (ty === 'round') { const q = t * 3, sd = Math.floor(t * 3 / (2 * PI)) % 2 ? -1 : 1, x = cx + Math.cos(q * sd) * 22, y = cy + Math.sin(q * sd) * 22; B.bee(g, x, y, 1.4, q * sd + PI / 2 * sd); return; }
    const a = ctx.v.ang * PI / 180, L = 30 + Math.min(1, ctx.v.dist / 3000) * 46, per = 1.2 + ctx.v.dist / 1000, ph = (t / per) % 2, side = ph < 1 ? 1 : -1, k = ph % 1;
    const ux = Math.sin(a), uy = -Math.cos(a), sx = cx - ux * L / 2, sy = cy - uy * L / 2;
    let x, y, r;
    if (k < .55) { const u = k / .55, w = Math.sin(u * PI * 14) * 3.5; x = sx + ux * L * u + uy * w; y = sy + uy * L * u - ux * w; r = Math.atan2(uy, ux); }
    else { const u = (k - .55) / .45, q = PI * u, ex = sx + ux * L, ey = sy + uy * L, mx = (sx + ex) / 2, my = (sy + ey) / 2, px = -uy * side, py = ux * side; x = mx + ux * L / 2 * Math.cos(q) + px * L / 2 * Math.sin(q); y = my + uy * L / 2 * Math.cos(q) + py * L / 2 * Math.sin(q); r = Math.atan2(uy, ux) + PI + side * (PI / 2 - q); }
    E('path', { d: `M${f1(sx)} ${f1(sy)}L${f1(sx + ux * L)} ${f1(sy + uy * L)}`, stroke: FK.alpha('#c0392b', .7), 'stroke-width': 1.4, 'stroke-dasharray': '3 2' }, g);
    E('path', { d: `M${cx} ${cy}V${cy - 50}`, stroke: FK.alpha('#2a1a08', .4), 'stroke-width': 1, 'stroke-dasharray': '2 3' }, g);
    B.bee(g, x, y, 1.4, r);
    for (let i = 0; i < 3; i++) { const q = i * 2.1 + .5; B.bee(g, cx + Math.cos(q) * 40, cy + Math.sin(q) * 46, 1.2, Math.atan2(cy - (cy + Math.sin(q) * 46), cx - (cx + Math.cos(q) * 40))); } }
}));
})();
