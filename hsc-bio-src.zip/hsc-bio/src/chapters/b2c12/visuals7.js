/* ═══════════════════════════════════════════════════════════════════
   visuals7 — শিখন: ইমপ্রিন্টিং, অন্তর্দৃষ্টি, অভ্যাসগত (হ্যাবিচুয়েশন), অনুকরণ:
   imprinting, hessCurve, insightKohler, habituationSnail, imitationTits, songLearning
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B212, PI = Math.PI;
const f1 = B.f1, sm = B.sm, TP = B.tp;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* রাজহাঁসের ছানা (হলুদাভ-ধূসর পালক), ডানমুখী */
const gosling = (g, x, y, s, step = 0) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g);
  E('path', { d: `M-3 6L${f1(-4 + step)} 12M3 6L${f1(3 - step)} 12`, stroke: '#7a6a4a', 'stroke-width': 1.2 }, gg);
  E('path', { d: 'M-9 2C-10 -4 -4 -8 2 -7C7 -6 9 -2 8 2C7 6 2 8 -3 8C-7 8 -9 5 -9 2Z', fill: B.vol(gg, 'ttY'), stroke: '#8a7a3a', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-8 0C-4 -2 2 -2 6 0', stroke: '#a89048', 'stroke-width': .6, fill: 'none' }, gg);
  E('circle', { cx: 7, cy: -8, r: 4.2, fill: '#d8c070', stroke: '#8a7a3a', 'stroke-width': .5 }, gg); E('circle', { cx: 8.4, cy: -9, r: .8, fill: '#111' }, gg);
  E('path', { d: 'M10.6 -8.4L14.4 -7.6L10.6 -6.6Z', fill: '#5a5040' }, gg); return gg; };
/* সাধারণ মানুষ (পার্শ্বদৃশ্য, হাঁটা), ডানমুখী */
const person = (g, x, y, s, ph) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), sw = Math.sin(ph) * 12;
  const L = (a, len, w, c) => E('path', { d: `M0 -46L${f1(Math.sin(a * PI / 180) * len)} ${f1(-46 + Math.cos(a * PI / 180) * len)}`, stroke: c, 'stroke-width': w, 'stroke-linecap': 'round' }, gg);
  L(-sw, 46, 6, '#4a5a6a'); L(sw, 46, 6, '#5a6a7a');
  E('path', { d: 'M-6 -48C-7 -62 -6 -74 0 -78C6 -74 7 -62 6 -48Z', fill: '#7a8a6a', stroke: '#4a5a3a', 'stroke-width': .6 }, gg);
  E('path', { d: `M0 -74L${f1(Math.sin(sw * PI / 180) * -22)} ${f1(-74 + 24)}`, stroke: '#7a8a6a', 'stroke-width': 4.4, 'stroke-linecap': 'round' }, gg);
  E('circle', { cx: 1, cy: -86, r: 7, fill: '#e2b48e', stroke: '#9a6a4a', 'stroke-width': .6 }, gg); E('path', { d: 'M-6 -88C-6 -95 6 -96 8 -89C4 -92 -2 -92 -6 -88Z', fill: '#d8d4cc' }, gg);
  return gg; };
const IM = [
  { t: 'ইনকিউবেটরে ডিম ফোটা', en: 'Hatching', d: 'কনরাড লরেঞ্জ গ্রেল্যাগ রাজহাঁসের ডিম দুই ভাগ করেন — একভাগ মা রাজহাঁসের কাছে, আরেক ভাগ ইনকিউবেটরে। ইনকিউবেটরে ফোটা ছানারা মা রাজহাঁসকে কখনো দেখেনি।' },
  { t: 'প্রথম চলমান বস্তু', en: 'First moving object', d: 'জন্মের পর ছানারা প্রথম যে বড় চলমান ও শব্দ করা বস্তু দেখে — এখানে লরেঞ্জ নিজে — তাকেই "মা" হিসেবে চিনে নেয়।' },
  { t: 'অনুসরণ', en: 'Following response', d: 'এরপর ছানারা সারি বেঁধে লরেঞ্জের পেছনে পেছনে চলে, তার ডাকে সাড়া দেয়; মা রাজহাঁসের কাছে ছেড়ে দিলেও লরেঞ্জের দিকে ফিরে আসে।' },
  { t: 'সংকটকাল', en: 'Critical (sensitive) period', d: 'ইমপ্রিন্টিং ঘটে জন্মের পর একটি সীমিত সময়ে — রাজহাঁস-হাঁসে প্রথম প্রায় 1–2 দিন (সবচেয়ে বেশি প্রায় 13–16 ঘণ্টায়)। এ সময় পেরোলে নতুন বস্তুতে আর সহজে ইমপ্রিন্টিং হয় না।' },
  { t: 'দীর্ঘস্থায়ী প্রভাব', en: 'Lasting effect', d: 'ইমপ্রিন্টিং দ্রুত, প্রায় অপরিবর্তনীয় এবং পুরস্কার ছাড়াই ঘটে। মানুষকে ইমপ্রিন্ট করা কিছু রাজহাঁস বড় হয়ে প্রজনন ঋতুতেও মানুষকে সঙ্গী হিসেবে বেছে নেওয়ার চেষ্টা করেছে (যৌন ইমপ্রিন্টিং)।' }
];
V.imprinting = Object.assign({ t: 'ইমপ্রিন্টিং: লরেঞ্জ ও রাজহাঁসের ছানা', k: ['2d', 'anim', 'steps'], cap: 'ইমপ্রিন্টিং (Imprinting): জন্মের পর নির্দিষ্ট সংকটকালে দ্রুত ও প্রায় স্থায়ীভাবে কোনো বস্তুকে চিনে নিয়ে তার প্রতি আসক্ত হওয়ার শিখন। কনরাড লরেঞ্জ (1935) রাজহাঁসের ছানা দিয়ে এটি বিখ্যাত করেন; লরেঞ্জ, টিনবার্গেন ও ফন ফ্রিশ 1973 সালে নোবেল পুরস্কার পান।' },
  BK.steps({ W: 360, H: 270, label: 'ইমপ্রিন্টিং', dur: 3.4, stages: IM,
    draw(g, C, s, u) {
      B.cacheG(g, 'imbg', gg => { E('rect', { x: 0, y: 0, width: 360, height: 270, fill: FK.alpha('#e8f0e0', .6) }, gg); E('rect', { x: 0, y: 200, width: 360, height: 30, fill: B.lin(gg, 'grass', 90) }, gg); });
      if (s === 0) { E('rect', { x: 100, y: 120, width: 160, height: 80, rx: 6, fill: '#eef0f2', stroke: '#8a9098', 'stroke-width': 1.2 }, g); E('rect', { x: 110, y: 130, width: 140, height: 50, fill: FK.alpha('#f0c040', .15), stroke: '#c0a040' }, g); B.tx(g, 180, 116, 'ইনকিউবেটর', { fs: 10, a: 'middle', c: C.mu });
        for (let i = 0; i < 4; i++) { if (u < .3 + i * .15) E('path', { d: B.ellD(132 + i * 32, 166, 9, 7), fill: B.vol(g, 'egg'), stroke: '#9a8e6a', 'stroke-width': .6 }, g); else gosling(g, 132 + i * 32, 166, 1.4); } return; }
      const px = s === 1 ? 250 : s === 2 ? lerp(220, 330, u) : s === 3 ? 300 : 300, ph = s === 2 ? u * 30 : 0;
      if (s !== 4) person(g, px, 204, 1.4, ph);
      for (let i = 0; i < 4; i++) { const gx = s === 1 ? 90 + i * 22 + u * 30 : s === 2 ? px - 34 - i * 22 : s === 3 ? 250 - i * 22 : 140 + i * 22; gosling(g, gx, 196, 1.5, s === 2 ? Math.sin(u * 40 + i) * 1.5 : 0); }
      if (s === 1) B.cacheG(g, 'im1', g => { E('path', { d: `M150 186Q200 160 ${px - 6} 150`, stroke: '#e0a030', 'stroke-width': 1.4, 'stroke-dasharray': '4 3', fill: 'none' }, g); B.tx(g, 210, 140, 'প্রথম দেখা চলমান বস্তু', { fs: 10, a: 'middle', c: '#8a5410' }); });
      if (s === 3) { B.cacheG(g, 'imtl', g => { /* সময়রেখা: সংকটকাল (স্থির স্তর) */ const X0 = 30, W = 300; E('rect', { x: X0, y: 40, width: W, height: 14, rx: 7, fill: FK.alpha(C.fg, .08) }, g); E('rect', { x: X0 + W * 4 / 48, y: 40, width: W * 28 / 48, height: 14, rx: 7, fill: FK.alpha('#e0a030', .6) }, g); E('rect', { x: X0 + W * 13 / 48, y: 40, width: W * 3 / 48, height: 14, fill: '#c0392b' }, g);
        [0, 12, 24, 36, 48].forEach(h => B.tx(g, X0 + W * h / 48, 70, h + ' ঘণ্টা', { fs: 9, a: 'middle', c: C.mu })); B.tx(g, X0 + W * 14.5 / 48, 32, 'শীর্ষ প্রায় 13–16 ঘণ্টা', { fs: 9.6, a: 'middle', c: '#a8201a', w: 700 }); }); E('path', { d: `M${f1(30 + 300 * u)} 36V58`, stroke: C.fg, 'stroke-width': 1.4 }, g); }
      if (s === 4) B.cacheG(g, 'imad', g => { /* প্রাপ্তবয়স্ক রাজহাঁস মানুষের দিকে */ B.goose(g, 120, 200, 1.6, [30, -46]); person(g, 240, 204, 1.4, 0); B.tx(g, 180, 60, 'বড় হয়েও মানুষের প্রতি আকর্ষণ', { fs: 10.4, a: 'middle', w: 700, c: '#5a3a18' }); });
      B.cacheG(g, 'imcap' + s, g => B.tx(g, 180, 252, ['', 'প্রথম চলমান বস্তুই "মা"', 'মায়ের বদলে মানুষকে অনুসরণ', 'নির্দিষ্ট সময়ের মধ্যেই ঘটে', 'দ্রুত, প্রায় স্থায়ী শিখন'][s], { fs: 10.4, a: 'middle', c: C.mu }));
    }
  }));

/* ═════════ হেসের লেখচিত্র: ইমপ্রিন্টিং বনাম বয়স ═════════ */
const HS = h => 85 * Math.exp(-(((h - 14.5) / 8.4) ** 2)) + 4;
V.hessCurve = Object.assign({}, B.seg({
  id: 'hes', t: 'ইমপ্রিন্টিংয়ের সংকটকাল (হেসের পরীক্ষা)', H: 250, def: 'c', types: { c: ['লেখচিত্র', 'ছানার বয়স অনুযায়ী ইমপ্রিন্টিংয়ের সাফল্য', 'এখার্ড হেস (1958–1959) ম্যালার্ড হাঁসের ছানাকে ভিন্ন ভিন্ন বয়সে একটি চলমান, ডাকা মডেল হাঁস দেখিয়ে পরে পরীক্ষা করেন কারা মডেলটিকে অনুসরণ করে। সাফল্য সবচেয়ে বেশি প্রায় 13–16 ঘণ্টা বয়সে; প্রায় 30 ঘণ্টার পর প্রায় হয় না।'] },
  cap: 'বক্ররেখাটি হেসের ফলাফলের আনুমানিক আকার দেখায়: সংকটকালের বাইরে ইমপ্রিন্টিং দুর্বল। শুরুতে কম কারণ ছানা তখনো ঠিকমতো হাঁটতে পারে না; পরে কমে কারণ অচেনা বস্তুর প্রতি ভয় বাড়ে।',
  art(g, C) { const P = B.axes(g, C, [44, 24, 290, 170], { xr: [0, 36], yr: [0, 100], xt: [0, 6, 12, 18, 24, 30, 36], yt: [0, 25, 50, 75, 100], lx: 'ছানার বয়স (ঘণ্টা)', ly: 'সফল ইমপ্রিন্টিং (%)' });
    const [x1] = P(13, 0), [x2] = P(16, 0); E('rect', { x: x1, y: 24, width: x2 - x1, height: 170, fill: FK.alpha('#e0a030', .18) }, g); B.tx(g, (x1 + x2) / 2, 36, 'শীর্ষ', { fs: 9.6, a: 'middle', c: '#8a5410', w: 700 });
    B.area(g, P, HS, 0, 36, 0, { fill: FK.alpha('#3a7a4a', .12) }); B.curve(g, P, HS, 0, 36, { stroke: '#3a7a4a' }); },
  anim(g, C, ty, t) { const P = B.axes(E('g', { opacity: 0 }, g), C, [44, 24, 290, 170], { xr: [0, 36], yr: [0, 100] }); const h = (t * 3) % 36, [x, y] = P(h, HS(h));
    E('circle', { cx: f1(x), cy: f1(y), r: 5, fill: '#3a7a4a', stroke: '#fff', 'stroke-width': 1.5 }, g); B.tx(g, x < 110 ? x + 8 : x > 280 ? x - 8 : x, y - 10, `${Math.round(h)} ঘণ্টা: প্রায় ${Math.round(HS(h))}%`, { fs: 9.6, a: x < 110 ? 'start' : x > 280 ? 'end' : 'middle', w: 700, c: '#2a5a3a' }); }
}));

/* ═════════ অন্তর্দৃষ্টি: কোহলারের শিম্পাঞ্জি ═════════ */
const chimp = (g, x, y, s, pose = 'stand', ph = 0) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), F = B.TS('furD'), face = '#c8a080';
  const up = pose === 'reach' || pose === 'jump', sit = pose === 'sit';
  /* পা */
  E('path', { d: sit ? 'M-6 -10C-12 -6 -12 0 -4 0H6' : 'M-4 -18L-8 0M4 -18L6 0', stroke: F.dk, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, gg);
  /* দেহ (সামনে ঝোঁকা) */
  E('path', { d: sit ? 'M-8 -10C-10 -24 -6 -36 2 -38C10 -36 12 -24 8 -10Z' : 'M-8 -16C-10 -30 -4 -42 4 -44C12 -42 12 -28 8 -16Z', fill: B.vol(gg, 'furD'), stroke: F.dk, 'stroke-width': .6 }, gg);
  /* বাহু (লম্বা) */
  const sy = sit ? -32 : -38;
  if (up) E('path', { d: `M2 ${sy}L${f1(6 + Math.sin(ph) * 2)} ${sy - 22}L${f1(8 + Math.sin(ph) * 2)} ${sy - 34}`, stroke: F.dk, 'stroke-width': 4.4, fill: 'none', 'stroke-linecap': 'round' }, gg);
  else if (pose === 'carry') E('path', { d: `M2 ${sy}L14 ${sy + 10}L22 ${sy + 6}`, stroke: F.dk, 'stroke-width': 4.4, fill: 'none', 'stroke-linecap': 'round' }, gg);
  else E('path', { d: `M2 ${sy}L${sit ? 10 : 8} ${sy + 16}L${sit ? 12 : 10} ${sy + 28}`, stroke: F.dk, 'stroke-width': 4.4, fill: 'none', 'stroke-linecap': 'round' }, gg);
  /* মাথা ও মুখ */
  const hy = sit ? -44 : -50; E('circle', { cx: 4, cy: hy, r: 7.6, fill: F.c, stroke: F.dk, 'stroke-width': .6 }, gg);
  E('path', { d: `M5 ${hy - 2}C12 ${hy - 3} 14 ${hy + 3} 11 ${hy + 6}C8 ${hy + 8} 4 ${hy + 6} 3 ${hy + 3}Z`, fill: face, stroke: '#7a5a3a', 'stroke-width': .5 }, gg);
  E('path', { d: `M5 ${hy - 4}H12`, stroke: '#3a2414', 'stroke-width': 1.4 }, gg); E('circle', { cx: 9, cy: hy - 1.6, r: .9, fill: '#111' }, gg);
  E('circle', { cx: -2, cy: hy - 1, r: 2.4, fill: face, stroke: '#7a5a3a', 'stroke-width': .5 }, gg);
  if (pose === 'think') E('path', { d: `M12 ${hy + 4}L10 ${hy + 10}`, stroke: F.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, gg);
  return gg; };
const box = (g, x, y, w, h) => { E('rect', { x, y, width: w, height: h, fill: B.lin(g, 'wood', 90), stroke: '#5c4022', 'stroke-width': .8 }, g); E('path', { d: `M${x} ${y}L${x + w} ${y + h}M${x + w} ${y}L${x} ${y + h}`, stroke: FK.alpha('#5c4022', .35), 'stroke-width': .6 }, g); };
const IK = [
  { t: 'নাগালের বাইরে কলা', en: 'Problem', d: 'খাঁচার ছাদ থেকে কলা ঝোলানো — লাফিয়েও নাগাল পাওয়া যায় না। ঘরে কয়েকটি কাঠের বাক্স পড়ে আছে। (ভোলফগাং কোহলার, টেনেরিফ দ্বীপ, 1913–1917)' },
  { t: 'ব্যর্থ চেষ্টা', en: 'Unsuccessful attempts', d: 'শিম্পাঞ্জি (সুলতান) বারবার লাফ দিয়ে ব্যর্থ হয় — এলোমেলো চেষ্টায় সমাধান আসে না।' },
  { t: 'থেমে পর্যবেক্ষণ', en: 'Pause', d: 'হঠাৎ চেষ্টা থামিয়ে বসে চারপাশ দেখে — কলা, উচ্চতা ও বাক্সগুলোর সম্পর্ক বোঝার চেষ্টা।' },
  { t: 'হঠাৎ সমাধান', en: 'Insight', d: 'যেন হঠাৎ বুঝে ফেলে — বাক্স টেনে কলার নিচে এনে একটির ওপর আরেকটি সাজায়। আগের অভিজ্ঞতার অংশগুলো নতুনভাবে জুড়ে সমাধান — এটাই অন্তর্দৃষ্টি শিখন ("আহা!" মুহূর্ত)।' },
  { t: 'সফলতা ও পুনরাবৃত্তি', en: 'Solution retained', d: 'বাক্সে উঠে কলা পেড়ে নেয়। পরের বার একই সমস্যায় প্রায় সাথে সাথেই সমাধান করে — অন্তর্দৃষ্টি থেকে পাওয়া সমাধান মনে থাকে। কোহলারের আরেক পরীক্ষায় সুলতান দুটি ছোট লাঠি জোড়া দিয়ে লম্বা লাঠি বানিয়ে খাঁচার বাইরের কলা টেনে এনেছিল।' }
];
V.insightKohler = Object.assign({ t: 'অন্তর্দৃষ্টি শিখন: কোহলারের শিম্পাঞ্জি', k: ['2d', 'anim', 'steps'], cap: 'অন্তর্দৃষ্টি (Insight) শিখন: ভুল-চেষ্টার পুনরাবৃত্তি ছাড়াই সমস্যার উপাদানগুলোর সম্পর্ক বুঝে হঠাৎ নতুন সমাধানে পৌঁছানো। জার্মান মনোবিজ্ঞানী ভোলফগাং কোহলার শিম্পাঞ্জির ওপর এটি দেখান (The Mentality of Apes, 1925 এর ইংরেজি সংস্করণ)।' },
  BK.steps({ W: 360, H: 280, label: 'অন্তর্দৃষ্টি', dur: 3.4, stages: IK,
    draw(g, C, s, u) {
      B.cacheG(g, 'ikbg', gg => { E('rect', { x: 0, y: 0, width: 360, height: 280, fill: FK.alpha('#efe8da', .7) }, gg); E('rect', { x: 0, y: 236, width: 360, height: 20, fill: '#c8b89a' }, gg); for (let i = 0; i < 10; i++) E('path', { d: `M${10 + i * 38} 0V236`, stroke: FK.alpha('#8a8070', .35), 'stroke-width': 2 }, gg); E('path', { d: 'M200 0V60', stroke: '#6a6050', 'stroke-width': 1 }, gg); });
      /* কলা */ B.cacheG(g, 'ikban' + (!(s === 4 && u > .6) ? 1 : 0), g => { if (!(s === 4 && u > .6)) E('path', { d: 'M192 60C196 76 206 82 212 78C206 74 200 68 198 60Z M200 60C206 74 216 78 222 72C214 70 208 66 204 60Z', fill: '#f2d03a', stroke: '#9a8010', 'stroke-width': .6 }, g); });
      const stacked = s >= 3;
      const b1 = s >= 3 ? [180, 196] : [60, 206], b2 = s >= 3 ? (s === 3 ? [lerp(280, 186, cl(u * 1.5)), lerp(206, 160, cl(u * 1.5 - .4))] : [186, 160]) : [280, 206];
      if (s === 3 && u < .35) { b1[0] = lerp(60, 180, u / .35); b1[1] = 196 + (1 - u / .35) * 10; }
      if (s === 3) { box(g, b1[0], b1[1], 44, 40); box(g, b2[0], b2[1], 40, 36); } else B.cacheG(g, 'ikbox' + (stacked ? 1 : 0), g => { box(g, b1[0], b1[1], 44, 40); box(g, b2[0], b2[1], 40, 36); });
      if (s === 0) B.cacheG(g, 'ikch0', g => chimp(g, 140, 236, 2, 'stand'));
      if (s === 1) chimp(g, 200, 236 - Math.abs(Math.sin(u * PI * 3)) * 30, 2, 'jump', u * 20);
      if (s === 2) B.cacheG(g, 'ikch2', g => { chimp(g, 130, 236, 2, 'think'); B.tx(g, 166, 100, '?', { fs: 26, a: 'middle', w: 700, c: '#8a5410' }); });
      if (s === 3) { chimp(g, u < .35 ? lerp(100, 160, u / .35) : lerp(270, 160, cl((u - .35) * 2)), 236, 2, 'carry'); if (u > .8) B.tx(g, 120, 100, 'আহা!', { fs: 20, a: 'middle', w: 700, c: '#c0392b' }); }
      if (s === 4) chimp(g, 204, 160, 2, 'reach', u * 6);
      B.cacheG(g, 'ikcap' + s, g => B.tx(g, 180, 272, ['সমস্যা: কলা উঁচুতে', 'ভুল-চেষ্টায় ব্যর্থ', 'থেমে সম্পর্ক বোঝা', 'হঠাৎ নতুন সমাধান', 'সমাধান পাওয়া ও মনে রাখা'][s], { fs: 10.4, a: 'middle', c: C.mu }));
    }
  }));

/* ═════════ অভ্যাসগত শিখন (হ্যাবিচুয়েশন): শামুক ═════════ */
const snail = (g, x, y, s, ext) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${s})` }, g), Sh = B.TS('shell'), Bd = B.TS('snail');
  E('path', { d: 'M-34 0C-36 -6 -20 -8 0 -8C12 -8 22 -10 26 -14C30 -10 32 -4 30 0Z', fill: B.vol(gg, 'snail'), stroke: Bd.dk, 'stroke-width': .6 }, gg);
  /* খোলস: লগারিদমিক সর্পিল */
  E('circle', { cx: -6, cy: -22, r: 18, fill: B.vol(gg, 'shell'), stroke: Sh.dk, 'stroke-width': .8 }, gg);
  let d = ''; for (let i = 0; i <= 60; i++) { const a = i / 60 * 4 * PI, r = 17 * Math.exp(-a * .19); d += (i ? 'L' : 'M') + f1(-6 + Math.cos(a + PI) * r) + ' ' + f1(-22 + Math.sin(a + PI) * r); } E('path', { d, stroke: Sh.dk, 'stroke-width': .9, fill: 'none' }, gg);
  for (let i = 0; i < 8; i++) { const a = i / 8 * 2 * PI; E('path', { d: `M${f1(-6 + Math.cos(a) * 10)} ${f1(-22 + Math.sin(a) * 10)}L${f1(-6 + Math.cos(a) * 17)} ${f1(-22 + Math.sin(a) * 17)}`, stroke: FK.alpha(Sh.dk, .3), 'stroke-width': .5 }, gg); }
  /* শুঙ্গ (চোখসহ) — ext 0..1 */
  const L = 4 + 12 * ext, l2 = 2 + 5 * ext;
  E('path', { d: `M22 -12L${f1(22 + L * .6)} ${f1(-12 - L)}M24 -11L${f1(24 + L * .9)} ${f1(-11 - L * .8)}`, stroke: Bd.c, 'stroke-width': 1.8, 'stroke-linecap': 'round' }, gg);
  E('circle', { cx: f1(22 + L * .6), cy: f1(-12 - L), r: 1.4, fill: '#2a1e14' }, gg); E('circle', { cx: f1(24 + L * .9), cy: f1(-11 - L * .8), r: 1.4, fill: '#2a1e14' }, gg);
  E('path', { d: `M28 -6L${f1(28 + l2)} ${f1(-4 - l2 * .2)}M28 -5L${f1(28 + l2)} ${f1(-2)}`, stroke: Bd.c, 'stroke-width': 1.2, 'stroke-linecap': 'round' }, gg);
  return gg; };
const HAB = n => n === 0 ? 1 : Math.max(.08, Math.exp(-n * .32));
V.habituationSnail = Object.assign({}, B.seg({
  id: 'hab', t: 'অভ্যাসগত শিখন: শামুকের শুঙ্গ গুটানো', H: 280, def: 'snail', types: {
    snail: ['শামুক', 'বারবার একই নিরীহ স্পর্শ', 'শামুকের শুঙ্গে আলতো স্পর্শ দিলে সে শুঙ্গ গুটিয়ে নেয় (আত্মরক্ষার প্রতিবর্ত)। একই স্পর্শ বারবার দিলে ক্ষতি হয় না বুঝে সে ধীরে ধীরে কম গুটায় এবং শেষে প্রায় সাড়াই দেয় না — অভ্যাসগত শিখন বা হ্যাবিচুয়েশন।'],
    graph: ['লেখচিত্র', 'সাড়ার মাত্রা বনাম উদ্দীপনার সংখ্যা', 'সাড়া ধাপে ধাপে কমে (হ্যাবিচুয়েশন)। কিছুক্ষণ বিশ্রাম দিলে সাড়া আংশিক ফিরে আসে (স্বতঃস্ফূর্ত পুনরুদ্ধার)। হঠাৎ ভিন্ন বা জোরালো উদ্দীপনা দিলে আবার পূর্ণ সাড়া — ডিসহ্যাবিচুয়েশন, যা প্রমাণ করে সাড়া কমার কারণ ক্লান্তি নয়, শিখন।']
  },
  cap: 'অভ্যাসগত শিখন (Habituation): বারবার আসা ক্ষতিহীন উদ্দীপনায় সাড়া দেওয়া ধীরে ধীরে কমে যাওয়া — সবচেয়ে সরল শিখন। এতে প্রাণী অপ্রয়োজনীয় সাড়ায় শক্তি নষ্ট করে না। এরিক ক্যান্ডেল সামুদ্রিক শামুক Aplysia তে এর স্নায়বিক ভিত্তি দেখিয়ে 2000 সালে নোবেল পান। শহরের পাখি যানবাহনের শব্দে ভয় না পাওয়াও এর উদাহরণ।',
  art(g, C, ty) {
    if (ty === 'graph') { const P = B.axes(g, C, [44, 24, 290, 180], { xr: [0, 22], yr: [0, 1.1], xt: [1, 5, 10, 15, 20], yt: [0, .5, 1], yf: v => v === 1 ? '100%' : v ? '50%' : '0', lx: 'উদ্দীপনার ক্রম', ly: 'সাড়ার মাত্রা' });
      const pts = []; for (let n = 1; n <= 12; n++) pts.push([n, HAB(n - 1)]); pts.push([16, .55]); pts.push([17, HAB(2)]); pts.push([18, HAB(4)]); pts.push([20, 1]);
      pts.forEach(([n, v], i) => { const [x, y] = P(n, v), [, y0] = P(n, 0); E('rect', { x: x - 5, y, width: 10, height: y0 - y, fill: n === 20 ? '#c0392b' : n >= 16 ? '#e0a030' : '#2a6ab0', opacity: .85 }, g); });
      const [rx] = P(14, 0); E('path', { d: `M${rx} 26V204`, stroke: FK.alpha(C.fg, .3), 'stroke-dasharray': '3 3' }, g); B.tx(g, rx, 18, 'বিশ্রাম', { fs: 9.6, a: 'middle', c: C.mu });
      B.tx(g, 110, 236, 'নীল: হ্যাবিচুয়েশন', { fs: 9.6, c: '#2a6ab0' }); B.tx(g, 110, 252, 'কমলা: স্বতঃস্ফূর্ত পুনরুদ্ধার', { fs: 9.6, c: '#a86a10' }); B.tx(g, 110, 268, 'লাল: নতুন জোরালো উদ্দীপনা — ডিসহ্যাবিচুয়েশন', { fs: 9.6, c: '#a8201a' }); return; }
    E('rect', { x: 0, y: 0, width: 360, height: 210, fill: FK.alpha('#e8f0e0', .7) }, g); E('path', { d: 'M0 172Q180 166 360 172V210H0Z', fill: B.lin(g, 'soil', 90) }, g);
  },
  anim(g, C, ty, t) { if (ty === 'graph') return; const per = 1.6, n = Math.floor(t / per) % 12, k = (t % per) / per;
    const resp = HAB(n), ext = k < .1 ? 1 : k < .3 ? 1 - resp * cl((k - .1) / .1) : 1 - resp * (1 - cl((k - .3) / .6));
    snail(g, 170, 170, 2.6, cl(ext));
    /* স্পর্শকারী দণ্ড */ const tx = k < .15 ? lerp(320, 248, k / .15) : lerp(248, 320, cl((k - .15) / .3)); E('path', { d: `M${f1(tx)} 96L${f1(tx + 60)} 60`, stroke: '#8a8070', 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g);
    B.tx(g, 180, 230, `স্পর্শ নং ${n + 1}: সাড়া প্রায় ${Math.round(resp * 100)}%`, { fs: 11, a: 'middle', w: 700, c: '#2a5a7a' });
    E('rect', { x: 80, y: 242, width: 200, height: 10, rx: 5, fill: FK.alpha(C.fg, .08) }, g); E('rect', { x: 80, y: 242, width: f1(200 * resp), height: 10, rx: 5, fill: '#2a6ab0' }, g);
    B.tx(g, 180, 272, 'একই নিরীহ উদ্দীপনা বারবার → সাড়া কমে', { fs: 9.6, a: 'middle', c: C.mu }); }
}));

/* ═════════ অনুকরণ: নীল টিট পাখির দুধের বোতলের ঢাকনা খোলা ═════════ */
const tit = (g, x, y, s, fl = 1, peck = 0) => { const gg = E('g', { transform: `translate(${f1(x)} ${f1(y)}) scale(${f1(s * fl)} ${f1(s)}) rotate(${f1(peck * 30)})` }, g);
  E('path', { d: 'M8 0L20 6L19 9L6 4Z', fill: '#3a78b8', stroke: '#1c4070', 'stroke-width': .4 }, gg);
  E('path', { d: 'M-8 -6C-2 -10 8 -8 12 0C14 6 8 10 0 10C-6 10 -10 6 -10 0C-10 -3 -9 -5 -8 -6Z', fill: B.vol(gg, 'ttY'), stroke: '#8a7a20', 'stroke-width': .5 }, gg);
  E('path', { d: 'M-4 -6C4 -8 10 -4 12 2C6 4 0 2 -4 -2Z', fill: '#7a9a6a' }, gg); E('path', { d: 'M0 -3C6 -4 10 0 12 4C8 4 2 2 0 -3Z', fill: '#3a78b8' }, gg);
  E('path', { d: 'M-14 -10C-14 -16 -6 -17 -4 -12C-3 -8 -5 -5 -9 -5C-12 -5 -14 -7 -14 -10Z', fill: '#fff', stroke: '#6a6a6a', 'stroke-width': .4 }, gg);
  E('path', { d: 'M-14 -12C-12 -17 -6 -17 -4 -13C-8 -14 -11 -13 -14 -12Z', fill: '#3a8ad8' }, gg); E('path', { d: 'M-14 -9.6L-5 -10.4', stroke: '#1a2a4a', 'stroke-width': 1 }, gg);
  E('circle', { cx: -10, cy: -10, r: .9, fill: '#111' }, gg); E('path', { d: 'M-14 -9L-18 -8L-14 -7Z', fill: '#2a2a2a' }, gg);
  E('path', { d: 'M-2 10L-3 14M3 10L3 14', stroke: '#6a7a8a', 'stroke-width': .9 }, gg); return gg; };
const bottle = (g, x, y, s, open) => { E('path', { d: `M${x - 12 * s} ${y}V${y - 50 * s}C${x - 12 * s} ${y - 58 * s} ${x - 7 * s} ${y - 62 * s} ${x - 7 * s} ${y - 70 * s}H${x + 7 * s}C${x + 7 * s} ${y - 62 * s} ${x + 12 * s} ${y - 58 * s} ${x + 12 * s} ${y - 50 * s}V${y}Z`, fill: '#f8f8f4', stroke: '#9aa0a6', 'stroke-width': .9 }, g);
  E('rect', { x: x - 12 * s, y: y - 64 * s, width: 24 * s, height: 4 * s, fill: FK.alpha('#fff', .8) }, g); E('path', { d: `M${x - 10 * s} ${y - 20 * s}H${x + 10 * s}`, stroke: '#e0e0d8', 'stroke-width': 2 }, g);
  E('path', { d: open ? `M${x - 8 * s} ${y - 72 * s}l${6 * s} ${-4 * s}l${-2 * s} ${-3 * s}` : `M${x - 8 * s} ${y - 72 * s}H${x + 8 * s}`, stroke: '#c8a020', 'stroke-width': 3 * s, fill: 'none', 'stroke-linecap': 'round' }, g);
  if (open) E('path', { d: B.ellD(x, y - 70 * s, 6 * s, 1.6 * s), fill: '#fff8e0', stroke: '#e8d8a0', 'stroke-width': .5 }, g); };
V.imitationTits = Object.assign({}, B.seg({
  id: 'tit', t: 'অনুকরণ: নীল টিটের দুধের বোতল খোলা', H: 270, def: 'copy', types: {
    one: ['প্রথম উদ্ভাবক', 'একটি পাখি নতুন কৌশল খুঁজে পায়', 'ইংল্যান্ডে বাড়ির দরজায় রাখা দুধের বোতলের ধাতব পাতের ঢাকনা ঠোকর দিয়ে ছিঁড়ে ওপরের ঘন সর (ক্রিম) খাওয়া — 1921 সালে সাউদাম্পটনের কাছে প্রথম লক্ষ করা হয়।'],
    copy: ['দেখে শেখা', 'অন্য পাখি দেখে অনুকরণ করে', 'পাশের পাখি কৌশলটি দেখে নিজেও ঢাকনা ঠোকরায় — অনুকরণ বা সামাজিক শিখন। এভাবে আচরণটি একজনের থেকে অনেকের মধ্যে ছড়ায়।'],
    spread: ['বিস্তার', 'কয়েক দশকে দেশজুড়ে ছড়িয়ে পড়া', 'ফিশার ও হাইন্ড (1949) দেখান, 1930 ও 1940-এর দশকে আচরণটি ইংল্যান্ডজুড়ে বহু জায়গায় দ্রুত ছড়ায় — বিক্ষিপ্ত কেন্দ্র থেকে চারদিকে, যা স্বাধীন আবিষ্কারের চেয়ে অনুকরণের মাধ্যমে বিস্তারের সাথে মেলে।']
  },
  cap: 'অনুকরণ (Imitation): অন্য প্রাণীর আচরণ দেখে নিজে একই আচরণ করা শেখা। এতে ভুল-চেষ্টার সময় বাঁচে এবং নতুন আচরণ জনগোষ্ঠীতে "সংস্কৃতির" মতো ছড়ায় — যেমন জাপানের কোশিমা দ্বীপের বানর ইমো 1953 সালে মিষ্টি আলু পানিতে ধুয়ে খাওয়া শুরু করলে দলের অন্যরাও তা শেখে।',
  art(g, C, ty) {
    E('rect', { x: 0, y: 0, width: 360, height: 210, fill: FK.alpha('#efe8da', .8) }, g); E('rect', { x: 0, y: 190, width: 360, height: 20, fill: '#b8a890' }, g);
    if (ty === 'spread') { E('rect', { x: 0, y: 0, width: 360, height: 210, fill: FK.alpha('#dfeaf2', .9) }, g);
      for (let i = 0; i < 4; i++) { const cx = [90, 180, 260, 140][i], cy = [70, 120, 60, 170][i]; for (let r = 1; r <= 4; r++) E('circle', { cx, cy, r: r * 14, fill: FK.alpha('#e0a030', .15), stroke: FK.alpha('#c08018', .4), 'stroke-dasharray': '3 3' }, g); E('circle', { cx, cy, r: 4, fill: '#c0392b' }, g); }
      B.tx(g, 180, 22, 'লাল: যেখানে প্রথম দেখা গেছে — চারপাশে ছড়ায় (রেখাচিত্র)', { fs: 9.6, a: 'middle', c: C.mu }); }
    B.tx(g, 180, 232, ({ one: 'উদ্ভাবন — একটি পাখি', copy: 'দেখে শেখা — অনুকরণ', spread: 'অনুকরণে দ্রুত বিস্তার' })[ty], { fs: 11, a: 'middle', w: 700, c: C.fg });
  },
  anim(g, C, ty, t) { if (ty === 'spread') { const k = (t * .12) % 1; for (let i = 0; i < 4; i++) { const cx = [90, 180, 260, 140][i], cy = [70, 120, 60, 170][i]; E('circle', { cx, cy, r: f1(k * 60), fill: 'none', stroke: '#c0392b', 'stroke-width': 1.4, opacity: f1(1 - k) }, g); } return; }
    const ph = (t * .5) % 1, pk = Math.max(0, Math.sin(ph * PI * 6)) * (ph < .6 ? 1 : 0);
    bottle(g, 120, 190, 1.6, ph > .5); tit(g, 128, 66, 2.1, 1, pk * .8);
    if (ty === 'copy') { bottle(g, 270, 190, 1.6, ph > .85); const pk2 = ph > .55 ? Math.max(0, Math.sin(ph * PI * 8)) : 0; tit(g, 278, 66, 2.1, 1, pk2 * .8); if (ph < .55) { E('path', { d: 'M250 58Q190 30 138 54', stroke: '#2a6ab0', 'stroke-width': 1.2, 'stroke-dasharray': '4 3', fill: 'none', 'marker-end': B.mk(g, '#2a6ab0', 5) }, g); B.tx(g, 196, 34, 'দেখছে', { fs: 9.6, a: 'middle', c: '#2a6ab0' }); } } }
}));

/* ═════════ গান শেখা: চ্যাফিঞ্চের সোনোগ্রাম (রেখাচিত্র) ═════════ */
const SG = { nor: 'স্বাভাবিক', iso: 'বিচ্ছিন্ন লালন', deaf: 'বধির' };
const sono = (g, X0, Y0, W, H, ty, t) => { E('rect', { x: X0, y: Y0, width: W, height: H, fill: '#fbfaf6', stroke: '#b8b0a0' }, g);
  for (let k = 0; k <= 4; k++) { const y = Y0 + H - k * H / 4; E('path', { d: `M${X0} ${y}h-4`, stroke: '#8a8070' }, g); B.tx(g, X0 - 6, y + 3, String(k * 2), { fs: 8.6, a: 'end', c: '#8a8070' }); }
  B.tx(g, X0 - 6, Y0 - 6, 'kHz', { fs: 8.6, a: 'end', c: '#8a8070' });
  const notes = [];
  if (ty === 'nor') { for (let p = 0; p < 3; p++) for (let i = 0; i < 4; i++) notes.push([.04 + p * .22 + i * .05, .62 - p * .08 - i * .03, .028, .05]); notes.push([.72, .5, .06, .26], [.8, .4, .05, .22], [.88, .28, .06, .3]); }
  else if (ty === 'iso') { for (let i = 0; i < 10; i++) notes.push([.05 + i * .075, .55 - i * .02, .04, .07]); }
  else { for (let i = 0; i < 9; i++) notes.push([.05 + B.rnd(i) * .85, .2 + B.rnd(i + 9) * .6, .02 + B.rnd(i + 3) * .05, .04 + B.rnd(i + 6) * .25]); }
  notes.forEach(([u, v, w, h]) => E('path', { d: `M${f1(X0 + u * W)} ${f1(Y0 + H - v * H)}l${f1(w * W)} ${f1(h * H * .4)}`, stroke: '#2a2a2a', 'stroke-width': 3.2, 'stroke-linecap': 'round', opacity: .85 }, g));
  if (t != null) E('path', { d: `M${f1(X0 + (t % 1) * W)} ${Y0}V${Y0 + H}`, stroke: '#c0392b', 'stroke-width': 1.2 }, g); };
V.songLearning = Object.assign({}, B.seg({
  id: 'sng', t: 'অনুকরণ ও সংবেদনশীল পর্যায়: পাখির গান শেখা', H: 250, def: 'nor', types: {
    nor: ['স্বাভাবিক', 'বুনো পরিবেশে বড় হওয়া চ্যাফিঞ্চ', 'প্রায় 2–3 সেকেন্ডের গান: কয়েকটি ক্রমশ নিচু সুরের অংশ (ফ্রেজ), শেষে অলংকার। তরুণ পাখি প্রথম গ্রীষ্মে প্রাপ্তবয়স্কদের গান শুনে মনে রাখে, পরের বসন্তে নিজের গলার সাথে মিলিয়ে অনুশীলন করে ঠিক করে নেয়।'],
    iso: ['বিচ্ছিন্ন লালন', 'অন্যের গান না শুনে বড় হওয়া', 'উইলিয়াম থর্প (1950-এর দশক) দেখান, একা লালিত চ্যাফিঞ্চ প্রায় সঠিক দৈর্ঘ্য ও সুরের পরিসরের গান গায়, কিন্তু অংশভাগ ও শেষের অলংকার থাকে না — গানের মৌলিক কাঠামো সহজাত, বিস্তারিত অংশ অনুকরণে শেখা।'],
    deaf: ['বধির', 'নিজের গলার আওয়াজ শুনতে পারে না', 'গান শেখার আগে বধির হলে পাখি এলোমেলো, ভাঙা স্বর তৈরি করে — অনুশীলনে নিজের গান শুনে মডেলের সাথে মেলানো জরুরি (মাসাকাজু কোনিশির 1965 সালের হোয়াইট-ক্রাউন্ড চড়ুইয়ের পরীক্ষা; চ্যাফিঞ্চেও একই ফল)।']
  },
  cap: 'অনেক গায়ক পাখি জীবনের একটি সংবেদনশীল পর্যায়ে নিজ প্রজাতির গান শুনে অনুকরণ করে শেখে; এ পর্যায় পেরোলে নতুন গান শেখা কঠিন। সোনোগ্রামে সময় (বাঁ থেকে ডানে) বনাম কম্পাঙ্ক — চিত্রটি রেখাচিত্র, আসল রেকর্ডিং নয়।',
  art(g, C, ty) { sono(g, 44, 24, 300, 150, ty); B.tx(g, 194, 194, 'সময় (প্রায় 2.5 সেকেন্ড)', { fs: 9.6, a: 'middle', c: C.mu }); B.tx(g, 194, 220, ({ nor: 'অংশভাগ + শেষের অলংকার — শেখা গান', iso: 'সরল, অংশভাগহীন — সহজাত কাঠামো', deaf: 'এলোমেলো — নিজেকে শুনে মেলাতে পারে না' })[ty], { fs: 10.4, a: 'middle', w: 700, c: C.fg }); },
  anim(g, C, ty, t) { const u = (t * .4) % 1; E('path', { d: `M${f1(44 + u * 300)} 24V174`, stroke: '#c0392b', 'stroke-width': 1.4 }, g); }
}));
})();
