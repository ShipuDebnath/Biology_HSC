/* ═══════════════════════════════════════════════════════════════════
   visuals0c — অধ্যায় ৬ (রেচন) এর শারীরস্থান-জ্যামিতি (B26 এ যোগ হয়)
   বৃক্কের সম্মুখ-ছেদ (kidneySec — কর্টেক্স, পিরামিড, কলাম, ক্যালিক্স, পেলভিস, রক্তনালির শাখা),
   নেফ্রনের পথ (NEPH — নালিকার প্রতিটি অংশের মধ্যরেখা), নেফ্রন আঁকা (nephronDraw), কোষ-ঝিল্লির পরিবহন চিহ্ন।
   রঙ: কর্টেক্স লালচে-বাদামি দানাদার, মেডুলার পিরামিড গাঢ় ও রেখাযুক্ত, ক্যালিক্স-পেলভিস সাদাটে,
   সাইনাসের চর্বি হলুদাভ, ধমনি লাল, শিরা নীল, মূত্র হলুদ; নালিকার অংশ আলাদা আলাদা রঙে (পাঠ্যবইয়ের প্রথা)।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, BK = window.BK, T = BK.T, B = window.B26, PI = Math.PI;
const f1 = v => (+v).toFixed(1);
const sm = (p, c, k) => B.smooth(p, c, k);
B.f1 = f1; B.sm = sm;
const hits = (parts, part, r = 14) => parts.forEach(p => E('circle', { cx: p.a[0], cy: p.a[1], r, fill: 'transparent' }, part(p.id)));
B.hits = hits;
/* পথ বরাবর কণা */
const AC = new WeakMap();
B.alongC = (pts, per = 6) => { let f = AC.get(pts); if (!f) { f = B.along(per ? B.dense(pts, per) : pts); AC.set(pts, f); } return f; };
/* স্থির অংশ একবার এঁকে প্রতি ফ্রেমে আবার জুড়ে দেওয়া (svg বদলালে নতুন করে) */
B.cacheG = (g, key, fn) => { const svg = g.ownerSVGElement || g, slot = key.replace(/\d+$/, ''), lm = svg._lm || (svg._lm = {}), LS = svg._ls || (svg._ls = []);
  let L = lm[slot]; if (!L) { L = E('g', {}, svg); svg.insertBefore(L, g); lm[slot] = L; LS.push(L); }
  if (L._k !== key) { L.innerHTML = ''; fn(L); L._k = key; }
  if (!svg._sch) { svg._sch = 1; svg._used = new Set(); queueMicrotask(() => { svg._sch = 0; LS.forEach(x => { const v = svg._used.has(x) ? '' : 'none'; if (x.style.display !== v) x.style.display = v; }); }); }
  svg._used.add(L); return L; };
B.flow = (g, pts, t, n, sp, dir, col, r = 1.8, op = .9) => { const A = B.alongC(pts); for (let i = 0; i < n; i++) { let u = (t * sp + i / n) % 1; if (dir < 0) u = 1 - u; const [x, y] = A(u); E('circle', { cx: f1(x), cy: f1(y), r, fill: col, opacity: op }, g); } };
const memo = (svg, key, mk) => { const m = svg._b26s || (svg._b26s = {}); return m[key] || (m[key] = mk()); };
const svgOf = g => g.ownerSVGElement || g;
let gid = 0;
const defs = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };

/* ─── বৃক্কের রূপরেখা (স্থানীয় স্থানাঙ্ক ০–১০০ × ০–১৬০, হাইলাম ডান দিকে) ─── */
const KO = [[52, 2], [72, 7], [86, 21], [92, 42], [88, 60], [80, 68], [79, 82], [81, 96], [90, 112], [92, 132], [83, 150], [62, 159], [38, 156], [17, 141], [6, 117], [2, 82], [6, 47], [16, 22], [32, 7]];
B.KO = KO;
const KD = B.dense(KO, 10, true);
B.kidOut = () => sm(KO, true, .5);
/* সাইনাসের কেন্দ্র থেকে θ দিকে রূপরেখা পর্যন্ত দূরত্ব */
const KS = [62, 82];
const ray = (th, S = KS) => { const dx = Math.cos(th), dy = Math.sin(th); let best = 1e9;
  for (let i = 0; i < KD.length; i++) { const a = KD[i], b = KD[(i + 1) % KD.length], ex = b[0] - a[0], ey = b[1] - a[1], den = dx * ey - dy * ex; if (Math.abs(den) < 1e-9) continue;
    const t = ((a[0] - S[0]) * ey - (a[1] - S[1]) * ex) / den, u = ((a[0] - S[0]) * dy - (a[1] - S[1]) * dx) / den; if (t > 0 && u >= 0 && u <= 1 && t < best) best = t; }
  return best; };
B.kray = ray;
const pol = (th, r, S = KS) => [S[0] + r * Math.cos(th), S[1] + r * Math.sin(th)];
/* পিরামিডের দিক (রেডিয়ান) — হাইলাম (০°) বাদে চারপাশে */
const PYR = [62, 98, 132, 166, 196, 228, 262, 296].map(d => d * PI / 180);
B.PYR = PYR;
const CORT = 15;   /* কর্টেক্সের পুরুত্ব (স্থানীয় একক ≈ ১ সেমি) */
/* একটি পিরামিড: শীর্ষ (প্যাপিলা) r1 এ, ভিত্তি রূপরেখা থেকে CORT ভেতরে */
const pyramid = (th, hw = .2) => { const r1 = 21, pts = [];
  for (let i = 0; i <= 6; i++) { const a = th - hw + 2 * hw * i / 6; pts.push(pol(a, ray(a) - CORT)); }
  const ap = pol(th, r1), l = pol(th - .07, r1 + 3), r = pol(th + .07, r1 + 3);
  return { base: pts, apex: ap, d: `M${f1(l[0])} ${f1(l[1])}L${pts.map(p => f1(p[0]) + ' ' + f1(p[1])).join('L')}L${f1(r[0])} ${f1(r[1])}Q${f1(ap[0])} ${f1(ap[1])} ${f1(l[0])} ${f1(l[1])}Z` }; };
B.kpyr = pyramid;

/* ─── বৃক্কের সম্মুখ-ছেদ ───
   o = { x, y, s, flip (দেহের বাম বৃক্ক = হাইলাম বাঁয়ে), ves (রক্তনালি দেখাও), hl (উজ্জ্বল অংশ: 'cor'|'med'|'col'|'cal'|'pel'|'cap'), urine (০–১ মূত্রের প্রবাহ দেখাতে নয় — শুধু রং) } */
B.kidneySec = (g, C, o = {}) => {
  const s = o.s || 1, gg = E('g', { transform: `translate(${o.x || 0} ${o.y || 0}) scale(${o.flip ? -s : s} ${s})` }, g);
  const kd = sm(KO, true, .5), kc = B.TS('kid'), mc = B.TS('med'), pc = B.TS('pel'), ft = B.TS('fat');
  const sw = 1 / s;
  /* ক্যাপসুল + কর্টেক্স */
  E('path', { d: kd, fill: B.vol(gg, 'kid', { cx: .4, cy: .35, r: .9 }), stroke: kc.dk, 'stroke-width': 1.6 * sw }, gg);
  E('path', { d: kd, fill: B.pat(gg, 'dot', FK.alpha(kc.dk, .35), { s: 4.2, w: .55 }), stroke: 'none' }, gg);
  E('path', { d: sm(B.offset(KO.concat([KO[0]]), -1.6, 4), false, .5), fill: 'none', stroke: FK.alpha('#fff', .55), 'stroke-width': 1.1 * sw }, gg);  /* তন্তুময় ক্যাপসুলের আভা */
  /* সাইনাস (চর্বি) */
  const sin = [[50, 56], [66, 54], [80, 66], [82, 98], [68, 112], [50, 110], [40, 94], [40, 70]];
  E('path', { d: sm(sin, true, .55), fill: B.vol(gg, 'fat', { cx: .6, cy: .4 }), stroke: FK.alpha(ft.dk, .6), 'stroke-width': .7 * sw }, gg);
  E('path', { d: sm(sin, true, .55), fill: B.pat(gg, 'fat', FK.alpha(ft.dk, .4), { s: 4, w: .4 }), stroke: 'none' }, gg);
  /* পিরামিড (রেখাযুক্ত) */
  const P = PYR.map(th => pyramid(th)); let dP = '', dS = '';
  P.forEach((p, i) => { dP += p.d; const th = PYR[i]; for (let k = -3; k <= 3; k++) { const a = th + k * .045, b = pol(a, ray(a) - CORT - 1), c = pol(th + k * .012, 25); dS += `M${f1(b[0])} ${f1(b[1])}L${f1(c[0])} ${f1(c[1])}`; } });
  E('path', { d: dP, fill: B.lin(gg, 'med', 0), stroke: mc.dk, 'stroke-width': .8 * sw, opacity: o.hl === 'cor' ? .55 : 1 }, gg);
  E('path', { d: dS, stroke: FK.alpha(mc.dk, .55), 'stroke-width': .5 * sw, fill: 'none' }, gg);
  /* ক্ষুদ্র ক্যালিক্স (প্রতিটি প্যাপিলার চারপাশে কাপ) → বৃহৎ ক্যালিক্স → পেলভিস */
  const pelv = [[56, 72], [70, 70], [84, 76], [88, 84], [84, 92], [70, 96], [58, 94]];
  let dC = '';
  P.forEach((p, i) => { const th = PYR[i], a = pol(th - .16, 19), b = pol(th + .16, 19), c = pol(th + .1, 11), d = pol(th - .1, 11); dC += `M${f1(a[0])} ${f1(a[1])}Q${f1(p.apex[0] + Math.cos(th) * 2)} ${f1(p.apex[1] + Math.sin(th) * 2)} ${f1(b[0])} ${f1(b[1])}L${f1(c[0])} ${f1(c[1])}L${f1(d[0])} ${f1(d[1])}Z`; });
  /* বৃহৎ ক্যালিক্স: ওপরের ও নিচের */
  const majU = sm([[58, 74], [52, 62], [50, 56], [56, 54], [62, 62], [68, 72]], true, .5), majL = sm([[58, 92], [52, 104], [50, 110], [58, 112], [64, 104], [70, 94]], true, .5);
  E('path', { d: dC, fill: B.vol(gg, 'pel'), stroke: pc.dk, 'stroke-width': .7 * sw }, gg);
  E('path', { d: majU + majL, fill: B.vol(gg, 'pel'), stroke: pc.dk, 'stroke-width': .7 * sw }, gg);
  /* রক্তনালি (সাইনাসের ভেতর দিয়ে কলামে) */
  if (o.ves !== false) {
    const ar = B.TS('art'), vn = B.TS('vein'); let dA = '', dV = '', dArc = '', dArcV = '', dIl = '';
    const mids = PYR.slice(0, -1).map((th, i) => (th + PYR[i + 1]) / 2).concat([PYR[0] - .3, PYR[PYR.length - 1] + .3]);
    mids.forEach(th => { const r0 = 16, r1 = ray(th) - CORT - 1, a0 = pol(th, r0), a1 = pol(th, r1); dA += `M${f1(a0[0])} ${f1(a0[1])}L${f1(a1[0])} ${f1(a1[1])}`; const v0 = pol(th + .05, r0), v1 = pol(th + .05, r1); dV += `M${f1(v0[0])} ${f1(v0[1])}L${f1(v1[0])} ${f1(v1[1])}`; });
    PYR.forEach(th => { let d = '', dv = ''; for (let k = 0; k <= 8; k++) { const a = th - .26 + .52 * k / 8, q = pol(a, ray(a) - CORT - .5), q2 = pol(a, ray(a) - CORT + 1.2); d += (k ? 'L' : 'M') + f1(q[0]) + ' ' + f1(q[1]); dv += (k ? 'L' : 'M') + f1(q2[0]) + ' ' + f1(q2[1]); if (k % 2) { const z = pol(a, ray(a) - 3); dIl += `M${f1(q[0])} ${f1(q[1])}L${f1(z[0])} ${f1(z[1])}`; } } dArc += d; dArcV += dv; });
    /* হাইলাম থেকে সেগমেন্টাল শাখা */
    const seg = `M98 76L84 78M84 78Q72 76 ${f1(pol(PYR[3] - .2, 16)[0])} ${f1(pol(PYR[3] - .2, 16)[1])}M84 78Q72 66 ${f1(pol(PYR[5] + .2, 16)[0])} ${f1(pol(PYR[5] + .2, 16)[1])}M84 78Q74 92 ${f1(pol(PYR[1] + .1, 16)[0])} ${f1(pol(PYR[1] + .1, 16)[1])}`;
    E('path', { d: dV + dArcV, stroke: vn.c, 'stroke-width': 1.25 * sw, fill: 'none', opacity: .85 }, gg);
    E('path', { d: dA + dArc, stroke: ar.c, 'stroke-width': 1.2 * sw, fill: 'none' }, gg);
    E('path', { d: dIl, stroke: FK.alpha(ar.c, .75), 'stroke-width': .6 * sw, fill: 'none' }, gg);
    B.tube(gg, seg, 2.2 * sw, 'art', { sw: .5 * sw, hl: false });
    B.tube(gg, 'M100 90L86 88Q76 86 70 84', 3 * sw, 'vein', { sw: .5 * sw, hl: false });
  }
  /* পেলভিস ও মূত্রনালি */
  const ure = sm([[84, 88], [92, 98], [97, 112], [99, 130], [100, 160]], false, .5);
  E('path', { d: sm(pelv, true, .5), fill: B.vol(gg, 'pel', { cx: .3 }), stroke: pc.dk, 'stroke-width': .8 * sw }, gg);
  B.tube(gg, ure, 6 * sw, 'pel', { sw: .6 * sw });
  if (o.hl) { const H = { cor: kd, med: dP, cal: dC + majU + majL, pel: sm(pelv, true, .5) }; if (H[o.hl]) E('path', { d: H[o.hl], fill: FK.alpha('#ffe066', .28), stroke: '#e0a800', 'stroke-width': 1.6 * sw, 'stroke-dasharray': `${4 * sw} ${3 * sw}` }, gg); }
  /* স্থানীয় বিন্দুকে বাইরের স্থানাঙ্কে রূপান্তর */
  const X = ([x, y]) => [+(f1((o.x || 0) + (o.flip ? -x : x) * s)), +(f1((o.y || 0) + y * s))];
  return { g: gg, X, pyr: P.map(p => X(p.apex)), cort: X(pol(PYR[3], ray(PYR[3]) - 6)), med: X(pol(PYR[3], 32)), col: X(pol((PYR[3] + PYR[4]) / 2, 32)), minor: X(pol(PYR[2], 17)), major: X([54, 60]), pelvis: X([74, 84]), ureter: X([99, 132]), cap: X(KO[15]), hilum: X([86, 80]), art: X([94, 76]), vein: X([96, 89]), papilla: X(P[3].apex), sinus: X([46, 100]) };
};

/* ─── নেফ্রনের পথ (৩৬০ চওড়া কাঠামো) ───
   কর্টেক্স y ১৮–১৯২, বহিঃমেডুলা ১৯২–৩০০, অন্তঃমেডুলা ৩০০–৪২০
   G = গ্লোমেরুলাস; প্রতিটি অংশের মধ্যরেখা আলাদা — রঙ ও অ্যানিমেশনের জন্য */
const NEPH = {
  G: [118, 70], rC: 23,
  pct: [[100, 89], [86, 100], [68, 94], [54, 108], [64, 124], [86, 118], [96, 134], [80, 150], [60, 144], [48, 160], [62, 174], [70, 196]],
  tdl: [[70, 196], [72, 260], [75, 330], [77, 388]],
  loop: [[77, 388], [84, 404], [96, 404], [103, 390]],
  tal_thin: [[103, 390], [104, 340], [104, 300]],
  tal: [[104, 300], [106, 240], [112, 190], [124, 150], [144, 116], [152, 84], [148, 60], [142, 50]],
  dct: [[142, 50], [158, 36], [176, 46], [190, 30], [208, 40], [202, 62], [216, 76], [234, 66], [246, 80], [254, 98]],
  cnt: [[254, 98], [264, 106], [272, 120]],
  cd: [[272, 120], [273, 200], [274, 300], [276, 412]],
  aff: [[22, 30], [70, 26], [112, 30], [128, 46]],
  eff: [[134, 44], [146, 22], [176, 14], [214, 16]],
  zones: [18, 192, 300, 420]
};
/* ডানে লেবেলের জায়গা রাখতে x সংকোচন (১০ থেকে ×০.৮২) */
const MX = x => +(10 + (x - 10) * .82).toFixed(1);
Object.keys(NEPH).forEach(k => { const v = NEPH[k]; if (Array.isArray(v) && Array.isArray(v[0])) NEPH[k] = v.map(([x, y]) => [MX(x), y]); });
NEPH.G = [MX(118), 70]; B.MX = MX;
B.NEPH = NEPH;
const SEGC = { pct: '#e9a37c', tdl: '#f2d7a6', loop: '#f2d7a6', tal_thin: '#f2d7a6', tal: '#d99ac4', dct: '#8fbfdc', cnt: '#9fd0b4', cd: '#7fbf8f' };
B.SEGC = SEGC;
const SEGW = { pct: 9, tdl: 5, loop: 5, tal_thin: 5, tal: 7.5, dct: 7.5, cnt: 7.5, cd: 11 };
/* পুরো নেফ্রন আঁকা: o = { hl (অংশের নাম বা অ্যারে), dim (বাকি অংশ ফ্যাকাশে), bands (অঞ্চলের পটভূমি), ves (রক্তনালি), vr (ভাসা রেক্টা), cap (পেরিটিউবুলার জাল) } */
B.nephronDraw = (g, C, o = {}) => {
  const N = NEPH, Z = N.zones, kc = B.TS('kid'), mc = B.TS('med');
  if (o.bands !== false) {
    E('rect', { x: 8, y: Z[0], width: 344, height: Z[1] - Z[0], fill: FK.alpha(kc.lt, C.dark ? .14 : .34), stroke: 'none' }, g);
    E('rect', { x: 8, y: Z[1], width: 344, height: Z[2] - Z[1], fill: FK.alpha(mc.lt, C.dark ? .16 : .38) }, g);
    E('rect', { x: 8, y: Z[2], width: 344, height: Z[3] - Z[2], fill: FK.alpha(mc.c, C.dark ? .18 : .3) }, g);
    { let d = ''; for (let x = 14; x < 352; x += 9) d += `M${x} ${Z[1]}V${Z[3]}`; E('path', { d, stroke: FK.alpha(mc.dk, .1), 'stroke-width': .6 }, g); }
    E('path', { d: `M8 ${Z[1]}H352M8 ${Z[2]}H352`, stroke: FK.alpha(C.fg, .3), 'stroke-width': .8, 'stroke-dasharray': '5 4' }, g);
    [[Z[1] - 5, 'কর্টেক্স'], [Z[1] + 12, 'বহিঃমেডুলা'], [Z[2] + 12, 'অন্তঃমেডুলা']].forEach(([y, s]) => B.tx(g, o.zx || 20, y, s, { fs: 8.5, a: 'start', c: C.mu, w: 600 }));
  }
  if (o.cap) { /* পেরিটিউবুলার কৈশিক জাল */ let d = ''; for (let i = 0; i < 26; i++) { const x = MX(40 + B.rnd(i * 3.1) * 220), y = 40 + B.rnd(i * 7.7) * 140; d += `M${f1(x)} ${f1(y)}q${f1(8 + B.rnd(i) * 8)} ${f1(-6 + B.rnd(i * 2) * 12)} ${f1(16 + B.rnd(i * 5) * 10)} ${f1(-4 + B.rnd(i * 9) * 8)}`; } E('path', { d, stroke: FK.alpha('#c9352b', .28), 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g); }
  if (o.vr) { /* ভাসা রেক্টা — লুপের পাশে চুলের কাঁটার মতো */ const vp = [[150, 30], [176, 60], [120, 190], [114, 300], [118, 398], [132, 410], [144, 396], [138, 300], [140, 190], [196, 70], [214, 18]].map(([x, y]) => [MX(x), y]); B.tube(g, sm(vp.slice(0, 6), false, .5), 2.2, 'art', { sw: .4, hl: false, op: .75 }); B.tube(g, sm(vp.slice(5), false, .5), 2.4, 'vein', { sw: .4, hl: false, op: .75 }); }
  const on = k => !o.hl || (Array.isArray(o.hl) ? o.hl.includes(k) : o.hl === k);
  const seg = k => { const d = sm(N[k], false, .5), w = SEGW[k], c = SEGC[k], dm = o.dim && !on(k);
    E('path', { d, stroke: FK.alpha('#5a3a2a', dm ? .25 : .75), 'stroke-width': w + 2, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
    E('path', { d, stroke: dm ? FK.alpha(c, .35) : c, 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
    E('path', { d, stroke: FK.alpha('#fff9ee', dm ? .15 : .75), 'stroke-width': Math.max(1.2, w * .3), fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);   /* লুমেন */
    if (k === 'pct' && !dm) E('path', { d, stroke: FK.alpha('#a85a3a', .5), 'stroke-width': w * .62, fill: 'none', 'stroke-dasharray': '.6 1.4', 'stroke-linecap': 'butt' }, g);   /* ব্রাশ বর্ডার */
    if (o.hl && on(k) && o.dim) E('path', { d, stroke: '#f0b400', 'stroke-width': w + 6, fill: 'none', opacity: .35, 'stroke-linecap': 'round' }, g); };
  ['cd', 'cnt', 'tdl', 'loop', 'tal_thin', 'tal', 'pct', 'dct'].forEach(seg);
  /* রক্তনালি: অন্তর্মুখী ও বহির্মুখী ধমনিকা */
  if (o.ves !== false) {
    B.tube(g, 'M10 196V30H22', 4.4, 'art', { sw: .6 }); B.tube(g, 'M16 198V36', 4, 'vein', { sw: .6, op: .9 });
    B.tube(g, sm(N.aff, false, .5), 3.8, 'art', { sw: .6 }); B.tube(g, sm(N.eff, false, .5), 2.8, 'art', { sw: .5 });
  }
  /* বোম্যান ক্যাপসুল ও গ্লোমেরুলাস */
  B.corpuscle(g, N.G[0], N.G[1], N.rC, { dim: o.dim && !on('gl') });
  if (o.hl && on('gl') && o.dim) E('circle', { cx: N.G[0], cy: N.G[1], r: N.rC + 4, fill: 'none', stroke: '#f0b400', 'stroke-width': 5, opacity: .35 }, g);
  /* ম্যাকুলা ডেনসা (দূরবর্তী নালিকার শুরুতে ঘন কোষ) */
  E('path', { d: `M${MX(138)} 47l6 -6`, stroke: '#6a2f6a', 'stroke-width': 3, 'stroke-linecap': 'round', opacity: o.dim && !on('jga') ? .3 : 1 }, g);
  return N;
};
/* বৃক্কীয় দেহাণু: বোম্যান ক্যাপসুলের দুই স্তর + কৈশিকের গুচ্ছ (লুপ আকারে) */
B.corpuscle = (g, x, y, r, o = {}) => { const op = o.dim ? .35 : 1, ar = B.TS('art');
  E('circle', { cx: x, cy: y, r, fill: FK.alpha('#fff6e6', .9 * op), stroke: FK.alpha('#8a5a3a', op), 'stroke-width': 1.6 }, g);
  E('circle', { cx: x, cy: y, r: r - 2.4, fill: 'none', stroke: FK.alpha('#c49a7a', op), 'stroke-width': .7 }, g);
  /* কৈশিকের কুণ্ডলী */ let d = ''; const n = o.n || 9;
  for (let i = 0; i < n; i++) { const a = i / n * 2 * PI + .3, cx = x + Math.cos(a) * r * .42, cy = y + Math.sin(a) * r * .42; d += B.ellD(cx, cy, r * .26, r * .18, a * 180 / PI); }
  E('path', { d, fill: FK.alpha(ar.c, .8 * op), stroke: FK.alpha(ar.dk, op), 'stroke-width': .6 }, g);
  E('path', { d: B.ellD(x, y, r * .3, r * .24, 0), fill: FK.alpha(ar.lt, .9 * op), stroke: FK.alpha(ar.dk, op), 'stroke-width': .5 }, g);
  /* পোডোসাইটের নিউক্লিয়াস */ for (let i = 0; i < 6; i++) { const a = i / 6 * 2 * PI + .7; E('ellipse', { cx: f1(x + Math.cos(a) * r * .72), cy: f1(y + Math.sin(a) * r * .72), rx: 1.6, ry: 1.1, fill: FK.alpha('#5c4c9e', op) }, g); }
};

/* ─── কোষ ও ঝিল্লির পরিবহন চিহ্ন ───
   পাম্প (Na+/K+-ATPase): বৃত্তে ATP; চ্যানেল: দুটি দণ্ড; বাহক: ডিম্বাকার */
B.pump = (g, x, y, s = 'ATP', col = '#e0a030') => { E('circle', { cx: x, cy: y, r: 7, fill: FK.alpha(col, .85), stroke: '#7a5410', 'stroke-width': .8 }, g); B.tx(g, x, y + 2.6, s, { fs: 6.4, a: 'middle', w: 700, c: '#3a2500', halo: FK.alpha('#fff', .5), hw: 1 }); };
B.chan = (g, x, y, col = '#4a8ac8', vert = true, open = 1) => { const w = 2.6 + open * 1.5; if (vert) { E('rect', { x: x - w - 3, y: y - 8, width: 3, height: 16, rx: 1.4, fill: col, stroke: FK.alpha('#000', .3), 'stroke-width': .4 }, g); E('rect', { x: x + w, y: y - 8, width: 3, height: 16, rx: 1.4, fill: col, stroke: FK.alpha('#000', .3), 'stroke-width': .4 }, g); } else { E('rect', { x: x - 8, y: y - w - 3, width: 16, height: 3, rx: 1.4, fill: col }, g); E('rect', { x: x - 8, y: y + w, width: 16, height: 3, rx: 1.4, fill: col }, g); } };
B.carr = (g, x, y, col = '#7a6ac8', rx = 5.5, ry = 8) => E('ellipse', { cx: x, cy: y, rx, ry, fill: FK.alpha(col, .8), stroke: FK.alpha('#000', .3), 'stroke-width': .5 }, g);
/* ছোট কণা (আয়ন) লেবেলসহ */
const MT = new Map();
B.mol = (g, x, y, s, col, r = 6.5, fs = 6.6) => { const key = s + '|' + col + '|' + r + '|' + fs; let t = MT.get(key);
  if (!t) { t = document.createElementNS('http://www.w3.org/2000/svg', 'g'); E('circle', { cx: 0, cy: 0, r, fill: col, stroke: FK.alpha('#000', .35), 'stroke-width': .5 }, t); B.tx(t, 0, 2.4, s, { fs, a: 'middle', w: 700, c: '#fff', halo: FK.alpha('#000', .35), hw: 1.4 }); MT.set(key, t); }
  const n = t.cloneNode(true); n.setAttribute('transform', `translate(${f1(x)} ${f1(y)})`); g.appendChild(n); return n; };
/* তীর (সোজা) */
B.arr = (g, x0, y0, x1, y1, col, w = 1.4, o = {}) => E('path', { d: `M${f1(x0)} ${f1(y0)}L${f1(x1)} ${f1(y1)}`, stroke: col, 'stroke-width': w, 'marker-end': B.mk(g, col, o.s || 6), fill: 'none', 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1 }, g);
/* নালিকার আবরণী কোষের প্রস্থচ্ছেদ: cx, cy, R (বাইরের), r (লুমেন), n কোষ, o = { bb (ব্রাশ বর্ডার), k (রং), h (কোষের উচ্চতার অনুপাত), cil } */
B.tubX = (g, cx, cy, R, r, n, o = {}) => { const tc = o.col || '#f2b9c9', dk = o.dk || '#a86a82'; let dC = '', dN = '';
  for (let i = 0; i < n; i++) { const a0 = i / n * 2 * PI, a1 = (i + 1) / n * 2 * PI, p = (a, rr) => [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr], A = p(a0, R), Bq = p(a1, R), c = p(a1, r), d = p(a0, r);
    dC += `M${f1(A[0])} ${f1(A[1])}A${R} ${R} 0 0 1 ${f1(Bq[0])} ${f1(Bq[1])}L${f1(c[0])} ${f1(c[1])}A${r} ${r} 0 0 0 ${f1(d[0])} ${f1(d[1])}Z`;
    const am = (a0 + a1) / 2, nr = r + (R - r) * (o.nucAt != null ? o.nucAt : .45), np = p(am, nr), nw = Math.min((R - r) * .26, R * PI / n * .32); dN += B.ellD(np[0], np[1], nw, nw * .8, am * 180 / PI); }
  E('circle', { cx, cy, r: R + 1.2, fill: 'none', stroke: FK.alpha(dk, .7), 'stroke-width': 1 }, g);   /* ভিত্তিপর্দা */
  E('path', { d: dC, fill: tc, stroke: dk, 'stroke-width': .5 }, g);
  E('path', { d: dN, fill: '#5c4c9e', stroke: '#31266a', 'stroke-width': .35 }, g);
  E('circle', { cx, cy, r: r, fill: o.lum || '#fffaf0', stroke: dk, 'stroke-width': .5 }, g);
  if (o.bb) { let d = ''; const m = Math.round(r * 2.2); for (let i = 0; i < m; i++) { const a = i / m * 2 * PI; d += `M${f1(cx + Math.cos(a) * r)} ${f1(cy + Math.sin(a) * r)}L${f1(cx + Math.cos(a) * (r - 2.6))} ${f1(cy + Math.sin(a) * (r - 2.6))}`; } E('path', { d, stroke: FK.alpha(dk, .8), 'stroke-width': .6 }, g); }
};
/* প্রশস্ত নালিকা (বিবর্ধিত চিত্রে): প্রাচীরে কোষ, গোল নিউক্লিয়াস দুই পাশে, ঐচ্ছিক ব্রাশ বর্ডার
   pts = মধ্যরেখা, w = বাইরের প্রস্থ, lw = লুমেন প্রস্থ, o = { fill, edge, bb, gap (নিউক্লিয়াসের ফাঁক) } */
B.tubeWall = (g, pts, w, lw, o = {}) => { const d = sm(pts, false, .5), fill = o.fill || '#e9a37c', edge = o.edge || '#a85a3a';
  E('path', { d, stroke: edge, 'stroke-width': w + 2, fill: 'none' }, g); E('path', { d, stroke: fill, 'stroke-width': w, fill: 'none' }, g);
  /* কোষের সীমা (প্রাচীর জুড়ে আড়াআড়ি সরু রেখা) */
  E('path', { d, stroke: FK.alpha(edge, .45), 'stroke-width': w - 1, fill: 'none', 'stroke-dasharray': `.6 ${o.gap || 7}` }, g);
  E('path', { d, stroke: o.lum || '#fffbe9', 'stroke-width': lw, fill: 'none' }, g);
  if (o.bb) E('path', { d, stroke: FK.alpha(edge, .6), 'stroke-width': lw + 3, fill: 'none', 'stroke-dasharray': '.5 1.3' }, g), E('path', { d, stroke: o.lum || '#fffbe9', 'stroke-width': lw - 1, fill: 'none' }, g);
  const off = (w + lw) / 4; [off, -off].forEach(k => { const P = B.offset(pts, k, 8); E('path', { d: sm(P, false, .5), stroke: '#5c4c9e', 'stroke-width': o.nw || 3.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-dasharray': `0 ${o.gap || 7}` }, g); }); };

})();
