/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৬.১ ব্রায়োফাইটা ও Riccia
   bryoGroups  : ব্রায়োফাইটের তিন দল — লিভারওয়ার্ট, হর্নওয়ার্ট, মস (গ্রিড, অ্যানিমেটেড)
   bryoClass   : শ্রেণিবিভাগ — গাছ
   bryoTraits  : ব্রায়োফাইটার বৈশিষ্ট্য — মাইন্ড ম্যাপ
   altGen      : জনুঃক্রম তুলনা — শৈবাল থেকে আবৃতবীজী পর্যন্ত n ও 2n জনুর অনুপাত (ইন্টারঅ্যাকটিভ বলয়)
   ricciaThallus: Riccia থ্যালাসের পৃষ্ঠীয় দৃশ্য — চিহ্নিত চিত্র (বৃষ্টির পানিতে শুক্রাণু সাঁতরায়)
   ricciaTS    : Riccia থ্যালাসের প্রস্থচ্ছেদ — চিহ্নিত চিত্র (রন্ধ্র দিয়ে গ্যাস বিনিময়)
   ricciaSex   : পুংধানী ও স্ত্রীধানী — চিহ্নিত চিত্র (শুক্রাণু গ্রীবার দিকে সাঁতরায়)
   ricciaSporo : স্পোরোফাইটের পরিস্ফুটন — ধাপে ধাপে
   ricciaCycle : Riccia এর জীবনচক্র — চক্র
   জীববৈজ্ঞানিক নোট: Riccia এর স্পোরোফাইট সবচেয়ে সরল — পদ (foot) ও সিটা নেই, কেবল ক্যাপসুল;
   ক্যাপসুল প্রাচীর এক স্তরের, ইলেটার নেই (কিছু পুষ্টিকোষ থাকে); স্পোর থ্যালাস পচে মুক্ত হয়।
   শুক্রাণু দুই-ফ্ল্যাজেলাযুক্ত; স্ত্রীধানীর গ্রীবায় ছয় সারি কোষ, গ্রীবা নালিকা কোষ চারটি।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

/* ───────── অধ্যায় ৬ এর সাধারণ সহায়ক ───────── */
const B6 = window.B6 = {};
B6.grid = (o) => ({
  t: o.t, k: ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, cols = o.cols || 3, ch = o.ch || 112, L = o.items;
    let sel = 0, C, svg, cells = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; cells = [];
      const rows = Math.ceil(L.length / cols), cw = W / cols, H = rows * ch + 8;
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.t }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      L.forEach((it, i) => {
        const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + 4, R = BK.ramp(o.ramp ? o.ramp(i) : i);
        const cg = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - cw / 2 + 4, y: y + 2, width: cw - 8, height: ch - 8, rx: 10, fill: i === sel ? FK.alpha(R.c, .14) : C.s2, stroke: i === sel ? R.c : C.ln, 'stroke-width': i === sel ? 2 : 1 }, cg);
        const gg = E('g', { transform: `translate(${x} ${y + (ch - 30) / 2})` }, cg);
        const u = o.draw(gg, it[0], R, C);
        T(cg, x, y + ch - 14, it[1], { fs: 10.5, a: 'middle', w: 600, c: R.ink });
        cells.push({ gg, x, y: y + (ch - 30) / 2, u });
      });
      info(); step(0);
    };
    const info = () => { const it = L[sel]; $('info').innerHTML = `<b>${it[1]}</b> — ${it[2]}${it[3] ? `<div class="small">উদাহরণ: <i>${it[3]}</i></div>` : ''}`; };
    const step = dt => { tt += dt; cells.forEach((c, i) => { if (c.u) c.u(tt, i === sel); }); };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    root.addEventListener('click', e => { const c = e.target.closest('[data-i]'); if (c && root.contains(c) && c.closest('svg')) { sel = +c.dataset.i; base(); } });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
/* শুক্রাণু: দুই-ফ্ল্যাজেলা (ব্রায়োফাইট) বা বহু-ফ্ল্যাজেলা প্যাঁচানো (ফার্ন) */
B6.sperm = (g, x, y, R, t, ang = 0, multi = false) => {
  const c = Math.cos(ang), s = Math.sin(ang);
  if (!multi) {
    E('path', { d: `M${(x - 4 * c).toFixed(1)} ${(y - 4 * s).toFixed(1)}q${(4 * c - 3 * s).toFixed(1)} ${(4 * s + 3 * c).toFixed(1)} ${(8 * c).toFixed(1)} ${(8 * s).toFixed(1)}`, stroke: R.dk, 'stroke-width': 2.2, fill: 'none', 'stroke-linecap': 'round' }, g);
    [-1, 1].forEach(k => { let d = `M${(x + 4 * c).toFixed(1)} ${(y + 4 * s).toFixed(1)}`; for (let j = 1; j <= 4; j++) { const L = j * 3, w = 2 * Math.sin(t * 12 + j + k); const a = ang + k * .5; d += `L${(x + 4 * c + L * Math.cos(a) - w * Math.sin(a)).toFixed(1)} ${(y + 4 * s + L * Math.sin(a) + w * Math.cos(a)).toFixed(1)}`; } E('path', { d, stroke: R.dk, 'stroke-width': .8, fill: 'none' }, g); });
  } else {
    let d = ''; for (let j = 0; j <= 14; j++) { const a = j * .62, r = 1.5 + j * .28; d += (j ? 'L' : 'M') + (x + r * Math.cos(a + t * 3)).toFixed(1) + ' ' + (y + r * Math.sin(a + t * 3)).toFixed(1); }
    E('path', { d, stroke: R.dk, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g);
    for (let k = 0; k < 6; k++) { const a = ang + Math.PI + (k - 2.5) * .35; let p = `M${x.toFixed(1)} ${y.toFixed(1)}`; for (let j = 1; j <= 3; j++) { const L = 2 + j * 2.6, w = 1.2 * Math.sin(t * 12 + j + k); p += `L${(x + L * Math.cos(a) - w * Math.sin(a)).toFixed(1)} ${(y + L * Math.sin(a) + w * Math.cos(a)).toFixed(1)}`; } E('path', { d: p, stroke: R.dk, 'stroke-width': .6, fill: 'none', opacity: .8 }, g); }
  }
};
/* দ্বিবিভাজিত থ্যালাসের খণ্ড: অংশগুলো segs এ জমা হয় */
const dich = (segs, x, y, a, len, w, depth, spread = .42) => {
  const x2 = x + len * Math.cos(a), y2 = y + len * Math.sin(a);
  segs.push({ x1: x, y1: y, x2, y2, w, tip: depth === 0, a });
  if (depth > 0) { dich(segs, x2, y2, a - spread, len * .8, w * .9, depth - 1, spread); dich(segs, x2, y2, a + spread, len * .8, w * .9, depth - 1, spread); }
};
const drawThallus = (g, segs, R, C, groove = true) => {
  segs.forEach(s => E('path', { d: `M${s.x1.toFixed(1)} ${s.y1.toFixed(1)}L${s.x2.toFixed(1)} ${s.y2.toFixed(1)}`, stroke: R.dk, 'stroke-width': s.w + 3, 'stroke-linecap': 'round' }, g));
  segs.forEach(s => E('path', { d: `M${s.x1.toFixed(1)} ${s.y1.toFixed(1)}L${s.x2.toFixed(1)} ${s.y2.toFixed(1)}`, stroke: R.c, 'stroke-width': s.w, 'stroke-linecap': 'round' }, g));
  if (groove) segs.forEach(s => E('path', { d: `M${s.x1.toFixed(1)} ${s.y1.toFixed(1)}L${(s.x2 - (s.tip ? s.w * .35 * Math.cos(s.a) : 0)).toFixed(1)} ${(s.y2 - (s.tip ? s.w * .35 * Math.sin(s.a) : 0)).toFixed(1)}`, stroke: R.dk, 'stroke-width': Math.max(.8, s.w * .09), 'stroke-linecap': 'round', opacity: .8 }, g));
  segs.filter(s => s.tip).forEach(s => { const hx = s.x2 + s.w * .42 * Math.cos(s.a), hy = s.y2 + s.w * .42 * Math.sin(s.a), n = s.w * .32; E('path', { d: `M${(hx - n * Math.sin(s.a) * .9).toFixed(1)} ${(hy + n * Math.cos(s.a) * .9).toFixed(1)}L${(s.x2 + s.w * .05 * Math.cos(s.a)).toFixed(1)} ${(s.y2 + s.w * .05 * Math.sin(s.a)).toFixed(1)}L${(hx + n * Math.sin(s.a) * .9).toFixed(1)} ${(hy - n * Math.cos(s.a) * .9).toFixed(1)}Z`, fill: C.sf }, g); });
};

/* ───────── তিন দল ───────── */
V.bryoGroups = B6.grid({
  t: 'ব্রায়োফাইটের প্রধান দল ও পরিচিত উদাহরণ',
  cap: 'ব্রায়োফাইটের তিন দল — লিভারওয়ার্ট (থ্যালয়েড বা পাতাযুক্ত), হর্নওয়ার্ট (শিং-এর মতো স্পোরোফাইট) ও মস (কাণ্ড-পাতাসদৃশ গ্যামিটোফাইট)। সবুজ অংশ গ্যামিটোফাইট (n); বাদামি বা কমলা অংশ স্পোরোফাইট (2n)। ঘরে চাপ দাও, চালু করলে নড়ে।',
  cols: 3, ch: 112,
  items: [
    ['riccia', 'Riccia (লিভারওয়ার্ট)', 'চ্যাপ্টা, দ্বিবিভাজিত, গোলাপের পাপড়ির মতো ছড়ানো থ্যালাস; স্পোরোফাইট থ্যালাসের ভেতরে নিমজ্জিত — সবচেয়ে সরল।', 'Riccia glauca, R. discolor'],
    ['march', 'Marchantia (লিভারওয়ার্ট)', 'বড় থ্যালাস; পৃষ্ঠে জেমা কাপ (অঙ্গজ জনন); ছাতার মতো দণ্ডে যৌনাঙ্গ।', 'Marchantia polymorpha'],
    ['antho', 'Anthoceros (হর্নওয়ার্ট)', 'চাকতির মতো থ্যালাস থেকে শিং-এর মতো লম্বা স্পোরোফাইট; গোড়ার ভাজক কলা থেকে দীর্ঘদিন বাড়ে, আগা দুই ভাগে ফেটে স্পোর ছড়ায়।', 'Anthoceros, Notothylas'],
    ['funaria', 'Funaria (মস)', 'খাড়া কাণ্ড ও ছোট পাতাসদৃশ গ্যামিটোফাইট; পদ, লম্বা সিটা ও বাঁকানো ক্যাপসুলযুক্ত স্পোরোফাইট।', 'Funaria hygrometrica — পুরনো দেয়াল, পোড়া মাটিতে'],
    ['sphag', 'Sphagnum (পিট মস)', 'মাথায় শাখার গুচ্ছ; পাতায় মৃত হায়ালাইন কোষ নিজের ওজনের প্রায় 20 গুণ পানি ধরে রাখে; জমে পিট তৈরি হয়।', 'Sphagnum — জলাভূমিতে'],
    ['poly', 'Polytrichum (মস)', 'সবচেয়ে উন্নত মসের একটি; লম্বা শক্ত কাণ্ড, ক্যাপসুলের উপর লোমশ টুপি (ক্যালিপট্রা)।', 'Polytrichum commune']
  ],
  ramp: i => (i < 2 ? 10 : i === 2 ? 7 : 10),
  draw(g, k, R, C) {
    const Rs = BK.ramp(6);
    if (k === 'riccia') { const o = E('g', {}, g); const segs = []; [0, 1, 2, 3, 4].forEach(i => dich(segs, 0, 0, -Math.PI / 2 + i * 1.2566, 13, 9, 1, .5)); drawThallus(o, segs, R, C); return (t, on) => { o.setAttribute('transform', `rotate(${on ? (4 * Math.sin(t * .8)).toFixed(1) : 0})`); }; }
    if (k === 'march') { const segs = []; dich(segs, -26, 18, 0, 26, 12, 1, .38); drawThallus(g, segs, R, C, false); E('path', { d: 'M-8 18l-5 -8h10z', fill: R.lt, stroke: R.dk }, g); [-11, -8.5].forEach(x => E('circle', { cx: x, cy: 13, r: 1.1, fill: R.dk }, g)); const o = E('g', {}, g); return t => { o.innerHTML = ''; const sw = 2.5 * Math.sin(t * 1.3); E('path', { d: `M6 18Q${7 + sw / 2} -2 ${8 + sw} -18`, stroke: R.dk, 'stroke-width': 2, fill: 'none' }, o); for (let i = 0; i < 8; i++) { const a = Math.PI + i * Math.PI / 7; E('path', { d: `M${8 + sw} -18l${(13 * Math.cos(a)).toFixed(1)} ${(-6 + 6 * Math.sin(a) * -.4).toFixed(1)}`, stroke: R.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, o); } }; }
    if (k === 'antho') { E('ellipse', { cx: 0, cy: 22, rx: 26, ry: 7, fill: R.c, stroke: R.dk }, g); const o = E('g', {}, g); return t => { o.innerHTML = ''; [-12, 0, 11].forEach((x, i) => { const h = 34 + 6 * Math.sin(t * .6 + i * 2), sp = 1.5 + 1.5 * Math.sin(t * .6 + i * 2); E('path', { d: `M${x} 20L${x} ${20 - h + 6}`, stroke: '#5b6b2a', 'stroke-width': 3.2, 'stroke-linecap': 'round' }, o); E('path', { d: `M${x} ${20 - h + 7}l${-sp} -7M${x} ${20 - h + 7}l${sp} -7`, stroke: Rs.dk, 'stroke-width': 1.8, 'stroke-linecap': 'round' }, o); E('circle', { cx: x, cy: 20 - h + 4, r: 1.1, fill: Rs.c }, o); }); }; }
    if (k === 'funaria') { const o = E('g', {}, g); return t => { o.innerHTML = ''; E('path', { d: 'M-6 28V8', stroke: R.dk, 'stroke-width': 2 }, o); for (let i = 0; i < 5; i++) { const y = 26 - i * 4; E('path', { d: `M-6 ${y}l-6 -4M-6 ${y}l6 -4`, stroke: R.c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, o); } const sw = 3 * Math.sin(t * 1.4); E('path', { d: `M-6 8Q${-2 + sw} -14 ${8 + sw} -26`, stroke: Rs.dk, 'stroke-width': 1.6, fill: 'none' }, o); E('ellipse', { cx: 12 + sw, cy: -24, rx: 6, ry: 3.6, fill: Rs.c, stroke: Rs.dk, transform: `rotate(${30} ${12 + sw} -24)` }, o); }; }
    if (k === 'sphag') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const sw = 2 * Math.sin(t * 1.2); E('path', { d: `M0 30Q${sw / 2} 0 ${sw} -14`, stroke: R.dk, 'stroke-width': 2, fill: 'none' }, o); for (let j = 0; j < 4; j++) { const y = 20 - j * 10; [-1, 1].forEach(s2 => E('path', { d: `M${sw * (1 - y / 30) / 2} ${y}q${s2 * 8} 2 ${s2 * 14} 10`, stroke: R.c, 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, o)); } for (let i = 0; i < 9; i++) { const a = i / 9 * 6.283; E('path', { d: `M${sw} -14l${(9 * Math.cos(a)).toFixed(1)} ${(6 * Math.sin(a)).toFixed(1)}`, stroke: R.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, o); } E('circle', { cx: sw, cy: -14, r: 4, fill: R.dk }, o); }; }
    if (k === 'poly') { const o = E('g', {}, g); return t => { o.innerHTML = ''; E('path', { d: 'M-8 30V0', stroke: R.dk, 'stroke-width': 2.4 }, o); for (let i = 0; i < 7; i++) { const y = 28 - i * 4; E('path', { d: `M-8 ${y}l-9 -5M-8 ${y}l9 -5`, stroke: R.c, 'stroke-width': 1.8, 'stroke-linecap': 'round' }, o); } const sw = 2 * Math.sin(t * 1.1); E('path', { d: `M-8 0Q${-6 + sw} -16 ${-4 + sw} -26`, stroke: Rs.dk, 'stroke-width': 1.6, fill: 'none' }, o); E('rect', { x: -8 + sw, y: -36, width: 8, height: 10, rx: 2, fill: Rs.c, stroke: Rs.dk }, o); E('path', { d: `M${-9 + sw} -36q5 -6 10 0l1 6h-12z`, fill: FK.alpha('#b08850', .9), stroke: '#7a5a30' }, o); }; }
  }
});

V.bryoClass = Object.assign({ t: 'ব্রায়োফাইটার শ্রেণিবিভাগ', k: ['tree', 'int'], cap: 'প্রচলিত শ্রেণিবিন্যাসে ব্রায়োফাইটা বিভাগকে তিনটি শ্রেণিতে ভাগ করা হয় (আধুনিক পদ্ধতিতে এরা তিনটি আলাদা বিভাগ)। প্রায় 20 হাজারের বেশি প্রজাতি।' }, BK.tree({
  t: 'ব্রায়োফাইটা', d: 'অভাস্কুলার, ভ্রূণ উৎপাদনকারী স্থলজ উদ্ভিদ; গ্যামিটোফাইট প্রধান।',
  c: [
    { t: 'হেপাটিসি (লিভারওয়ার্ট)', d: 'Hepaticopsida — থ্যালাস পৃষ্ঠ-অঙ্কীয় (dorsiventral); এককোষী রাইজয়েড; স্পোরোফাইট সরল, ইলেটার থাকে (Riccia তে নেই)।', c: [{ t: 'উদাহরণ', d: 'Riccia, Marchantia (থ্যালয়েড); Porella, Frullania (পাতাযুক্ত)।' }] },
    { t: 'অ্যান্থোসেরোটি (হর্নওয়ার্ট)', d: 'Anthocerotopsida — প্রতি কোষে সাধারণত একটি বড় ক্লোরোপ্লাস্ট ও পাইরিনয়েড; শিং-এর মতো স্পোরোফাইট গোড়ার ভাজক কলায় বাড়ে; কলুমেলা থাকে।', c: [{ t: 'উদাহরণ', d: 'Anthoceros, Notothylas।' }] },
    { t: 'মাসাই (মস)', d: 'Bryopsida — কাণ্ড-পাতাসদৃশ খাড়া গ্যামিটোফাইট; বহুকোষী রাইজয়েড; প্রোটোনিমা দশা; ক্যাপসুলে পেরিস্টোম দাঁত।', c: [{ t: 'উদাহরণ', d: 'Funaria, Polytrichum, Sphagnum।' }] }
  ]
}, { colW: 120 }));

V.bryoTraits = Object.assign({ t: 'ব্রায়োফাইটার প্রধান বৈশিষ্ট্য', k: ['mind', 'int'], cap: 'দেহ, জনন, জনুঃক্রম ও আবাস — চার দিক থেকে ব্রায়োফাইটার বৈশিষ্ট্য। শাখায় চাপ দিলে বিস্তারিত।' }, BK.mind({
  t: 'ব্রায়োফাইটা', d: 'উভচর উদ্ভিদ — স্থলে জন্মায়, কিন্তু নিষেকে পানি লাগে।',
  c: [
    { t: 'দেহ', d: 'গ্যামিটোফাইট দেহ।', c: [{ t: 'থ্যালয়েড বা কাণ্ড-পাতাসদৃশ', d: 'প্রকৃত মূল, কাণ্ড ও পাতা নেই।' }, { t: 'রাইজয়েড', d: 'মূলের বদলে এককোষী বা বহুকোষী রাইজয়েড — আটকে রাখে ও পানি শোষে।' }, { t: 'ভাস্কুলার টিস্যু নেই', d: 'জাইলেম-ফ্লোয়েম নেই; তাই আকারে ছোট ও ভেজা স্থানে জন্মায়।' }] },
    { t: 'জনন', d: 'অঙ্গজ ও যৌন।', c: [{ t: 'বহুকোষী যৌনাঙ্গ', d: 'পুংধানী (অ্যান্থেরিডিয়াম) ও স্ত্রীধানী (আর্কিগোনিয়াম) — বন্ধ্যা কোষের আবরণে ঢাকা।' }, { t: 'উগ্যামি', d: 'দুই-ফ্ল্যাজেলাযুক্ত শুক্রাণু পানিতে সাঁতরে স্ত্রীধানীর ডিম্বাণুকে নিষিক্ত করে।' }, { t: 'ভ্রূণ', d: 'জাইগোট স্ত্রীধানীর ভেতরেই ভ্রূণে পরিণত হয় — এমব্রায়োফাইটা।' }, { t: 'অঙ্গজ জনন', d: 'খণ্ডায়ন, জেমা, টিউবার, অস্থানিক শাখা।' }] },
    { t: 'জনুঃক্রম', d: 'বিষমরূপী (heteromorphic)।', c: [{ t: 'গ্যামিটোফাইট প্রধান', d: 'হ্যাপ্লয়েড (n), সবুজ, স্বাধীন ও দীর্ঘস্থায়ী।' }, { t: 'স্পোরোফাইট নির্ভরশীল', d: 'ডিপ্লয়েড (2n) — পদ, সিটা ও ক্যাপসুল (Riccia তে কেবল ক্যাপসুল); গ্যামিটোফাইট থেকে পুষ্টি নেয়।' }, { t: 'সমরেণু', d: 'সব স্পোর একই রকম (homosporous)।' }] },
    { t: 'আবাস ও গুরুত্ব', d: 'ছায়াযুক্ত, স্যাঁতসেঁতে স্থান।', c: [{ t: 'আবাস', d: 'ভেজা মাটি, দেয়াল, গাছের বাকল, পাথর।' }, { t: 'অগ্রগামী উদ্ভিদ', d: 'লাইকেনের পরে পাথরে মাটি তৈরি ও ভূমিক্ষয় রোধ।' }, { t: 'পিট', d: 'Sphagnum জমে পিট — জ্বালানি, মাটি উন্নয়ন, কার্বন সঞ্চয়।' }] }
  ]
}));

/* ───────── জনুঃক্রম তুলনা ───────── */
const AG = {
  ulo: ['Ulothrix (শৈবাল)', .95, 'হ্যাপ্লন্টিক — বহুকোষী দেহ কেবল হ্যাপ্লয়েড; 2n দশা শুধু জাইগোট, সেখানেই মায়োসিস। প্রকৃত জনুঃক্রম নেই।', 'n', 'কেবল জাইগোট (2n)'],
  ric: ['Riccia (লিভারওয়ার্ট)', .8, 'গ্যামিটোফাইট (n) প্রধান, স্বাধীন ও দীর্ঘস্থায়ী; স্পোরোফাইট (2n) কেবল একটি ক্যাপসুল — থ্যালাসের ভেতরে নিমজ্জিত ও পুরোপুরি নির্ভরশীল।', 'গ্যামিটোফাইট', 'স্পোরোফাইট (নির্ভরশীল)'],
  fun: ['Funaria (মস)', .65, 'গ্যামিটোফাইট প্রধান; স্পোরোফাইটে পদ, সিটা ও ক্যাপসুল — তরুণ অবস্থায় সালোকসংশ্লেষণ করলেও পানি ও খনিজের জন্য গ্যামিটোফাইটের উপর নির্ভরশীল।', 'গ্যামিটোফাইট', 'স্পোরোফাইট (আংশিক নির্ভরশীল)'],
  pte: ['Pteris (ফার্ন)', .15, 'স্পোরোফাইট (2n) প্রধান — মূল, কাণ্ড, পাতা ও ভাস্কুলার টিস্যুযুক্ত; গ্যামিটোফাইট (প্রোথ্যালাস, n) ছোট, স্বাধীন কিন্তু স্বল্পস্থায়ী। দুই জনুই জীবনের কোনো এক সময় স্বাধীন।', 'প্রোথ্যালাস (স্বাধীন, ক্ষুদ্র)', 'স্পোরোফাইট'],
  ang: ['আবৃতবীজী উদ্ভিদ', .04, 'স্পোরোফাইট সম্পূর্ণ প্রধান; গ্যামিটোফাইট অতি ক্ষুদ্র — পরাগরেণু (2–3 কোষ) ও ভ্রূণথলি (7 কোষ, 8 নিউক্লিয়াস) — স্পোরোফাইটের উপর নির্ভরশীল; নিষেকে পানি লাগে না।', 'গ্যামিটোফাইট (অতি ক্ষুদ্র)', 'স্পোরোফাইট']
};
V.altGen = {
  t: 'জনুঃক্রম: গ্যামিটোফাইট থেকে স্পোরোফাইটের প্রাধান্য', k: ['2d', 'anim', 'int'],
  cap: 'বলয়ের সবুজ অংশ হ্যাপ্লয়েড (n) গ্যামিটোফাইট জনু, কমলা অংশ ডিপ্লয়েড (2n) স্পোরোফাইট জনু (জীবনকালের আনুমানিক অনুপাত)। নিষেকে n → 2n, মায়োসিসে 2n → n। উদ্ভিদ বদলে দেখো — বিবর্তনের ধারায় স্পোরোফাইট ক্রমে প্রধান হয়েছে।',
  html: () => `<div class="fk-row">${X.seg('ag', Object.keys(AG).map(k => [k, AG[k][0].split(' (')[0]]), 'ric')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250, cx = 180, cy = 118, r = 78;
    let ty = 'ric', C, svg, tok, frac = AG.ric[1], tgt = frac, arcN, arcD, tt = 0, lab = [];
    const arc = (a0, a1) => { const p = a => [cx + r * Math.cos(a), cy + r * Math.sin(a)]; const [x0, y0] = p(a0), [x1, y1] = p(a1); return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${a1 - a0 > Math.PI ? 1 : 0} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`; };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'জনুঃক্রম' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      arcN = E('path', { fill: 'none', stroke: BK.ramp(10).c, 'stroke-width': 20, 'stroke-linecap': 'butt' }, svg);
      arcD = E('path', { fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 20, 'stroke-linecap': 'butt' }, svg);
      lab = [T(svg, cx, cy - 6, '', { fs: 14, a: 'middle', w: 650, c: BK.ramp(10).ink }), T(svg, cx, cy + 14, '', { fs: 14, a: 'middle', w: 650, c: BK.ramp(6).ink }),
        T(svg, 0, 0, 'নিষেক', { fs: 11, a: 'middle', w: 600, c: C.fg }), T(svg, 0, 0, 'মায়োসিস', { fs: 11, a: 'middle', w: 600, c: C.fg }),
        T(svg, 20, H - 30, '', { fs: 11.5, w: 600, c: BK.ramp(10).ink }), T(svg, 20, H - 12, '', { fs: 11.5, w: 600, c: BK.ramp(6).ink })];
      tok = E('circle', { r: 7, fill: C.fg, stroke: C.sf, 'stroke-width': 2.5 }, svg);
      const a = AG[ty]; $('info').innerHTML = `<b>${a[0]}</b> — ${a[2]}`;
      lab[4].textContent = 'সবুজ (n): ' + a[3]; lab[5].textContent = 'কমলা (2n): ' + a[4];
      paint();
    };
    const paint = () => {
      const a0 = -Math.PI / 2, aM = a0 + 2 * Math.PI * frac, a1 = a0 + 2 * Math.PI - .0001;
      arcN.setAttribute('d', arc(a0, aM)); arcD.setAttribute('d', arc(aM, a1));
      lab[0].textContent = `n: ${Math.round(frac * 100)}%`; lab[1].textContent = `2n: ${Math.round((1 - frac) * 100)}%`;
      const pos = (lb, ang) => { lb.setAttribute('x', (cx + (r + 26) * Math.cos(ang)).toFixed(1)); lb.setAttribute('y', (cy + (r + 26) * Math.sin(ang) + 4).toFixed(1)); };
      pos(lab[3], a0); lab[3].setAttribute('y', cy - r - 18); pos(lab[2], aM);
      const ta = a0 + (tt % 1) * 2 * Math.PI; FK.at(tok, { cx: (cx + r * Math.cos(ta)).toFixed(1), cy: (cy + r * Math.sin(ta)).toFixed(1) });
    };
    const A = X.anim(root, dt => { tt += dt * .18; frac += (tgt - frac) * Math.min(1, dt * 4); paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'ag', v => { ty = v; tgt = AG[v][1]; frac = tgt; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── Riccia থ্যালাস (পৃষ্ঠীয় দৃশ্য) ───────── */
const RS = []; [0, 1, 2, 3, 4, 5].forEach(i => dich(RS, 180, 150, -Math.PI / 2 + Math.PI / 6 + i * Math.PI / 3, 36, 26, 1, .4));
const RT = RS.filter(s => s.tip), RP = RS.filter(s => !s.tip);
/* শল্ক: প্রতিটি আগার শাখার দুই কিনারায় ছোট বেগুনি ত্রিভুজ — [x, y, বাইরের দিকের একক ভেক্টর] */
const RSC = []; RT.forEach(s => [-1, 1].forEach(k => { const n = [-Math.sin(s.a) * k, Math.cos(s.a) * k]; [.6].forEach(f => RSC.push([s.x1 + (s.x2 - s.x1) * f + n[0] * s.w * .5, s.y1 + (s.y2 - s.y1) * f + n[1] * s.w * .5, n, s.a])); }));
V.ricciaThallus = Object.assign({
  t: 'Riccia এর থ্যালাস (পৃষ্ঠীয় দৃশ্য)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'চ্যাপ্টা, পুরু, গাঢ় সবুজ, বারবার দ্বিবিভাজিত (dichotomous) থ্যালাস মাটিতে গোলাপের মতো ছড়িয়ে থাকে। প্রতিটি শাখার মাঝ বরাবর পৃষ্ঠীয় খাঁজ, আগায় খাঁজে বৃদ্ধিবিন্দু। খাঁজের তলায় নিমজ্জিত যৌনাঙ্গ ও পরে স্পোরোফাইট কালো বিন্দুর মতো দেখা যায়। চালু করলে বৃষ্টির পানিতে শুক্রাণুর চলাচল দেখাবে।'
}, BK.diagram({
  W: 360, H: 300, label: 'Riccia থ্যালাস',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rv = BK.ramp(3), Rr = BK.ramp(6);
    const rh = P('rhizoid'); for (let i = 0; i < 36; i++) { const a = i / 36 * 6.283 + .09, r0 = 30, r1 = 66 + (i % 3) * 8; E('path', { d: `M${(180 + r0 * Math.cos(a)).toFixed(1)} ${(150 + r0 * Math.sin(a)).toFixed(1)}L${(180 + r1 * Math.cos(a + .05)).toFixed(1)} ${(150 + r1 * Math.sin(a + .05)).toFixed(1)}`, stroke: FK.alpha(Rr.dk, .55), 'stroke-width': 1 }, rh); }
    const th = P('thallus'); drawThallus(th, RS, R, C, false);
    const sc = P('scale'); RSC.forEach(([x, y, n, a]) => { const c = Math.cos(a) * 3.5, s2 = Math.sin(a) * 3.5; E('path', { d: `M${(x - c).toFixed(1)} ${(y - s2).toFixed(1)}L${(x + n[0] * 6).toFixed(1)} ${(y + n[1] * 6).toFixed(1)}L${(x + c).toFixed(1)} ${(y + s2).toFixed(1)}Z`, fill: Rv.c, stroke: Rv.dk, 'stroke-width': .6 }, sc); });
    const dc = P('dich'); RP.forEach(s => E('circle', { cx: s.x2, cy: s.y2, r: 4, fill: FK.alpha(R.lt, .7), stroke: R.dk, 'stroke-width': 1 }, dc));
    const gr = P('groove'); RS.forEach(s => E('path', { d: `M${s.x1.toFixed(1)} ${s.y1.toFixed(1)}L${(s.x2 - (s.tip ? s.w * .3 * Math.cos(s.a) : 0)).toFixed(1)} ${(s.y2 - (s.tip ? s.w * .3 * Math.sin(s.a) : 0)).toFixed(1)}`, stroke: R.dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, gr));
    const nt = P('notch'); RT.forEach(s => { const hx = s.x2 + s.w * .1 * Math.cos(s.a), hy = s.y2 + s.w * .1 * Math.sin(s.a); E('circle', { cx: hx.toFixed(1), cy: hy.toFixed(1), r: 2.6, fill: BK.ramp(4).c }, nt); });
    const sp = P('sporo'); RS.forEach(s => { for (let k = 1; k <= 3; k++) { const f = s.tip ? k * .2 : k * .25; if (!s.tip && k === 3) continue; E('circle', { cx: (s.x1 + (s.x2 - s.x1) * f).toFixed(1), cy: (s.y1 + (s.y2 - s.y1) * f).toFixed(1), r: 2.2, fill: '#3b2a1a' }, sp); } });
  },
  idle(g, C, t) {
    const R = BK.ramp(5);
    RS.forEach((s, i) => { if (!s.tip || i % 2) return; const f = ((t * .25 + i * .13) % 1); const x = s.x2 + (s.x1 - s.x2) * f, y = s.y2 + (s.y1 - s.y2) * f; B6.sperm(g, x + 3 * Math.sin(t * 3 + i), y, R, t, Math.atan2(s.y1 - s.y2, s.x1 - s.x2)); });
  },
  parts: [
    { id: 'thallus', bn: 'থ্যালাস (গ্যামিটোফাইট, n)', lb: 'থ্যালাস', en: 'Thallus', fn: 'চ্যাপ্টা, পুরু, মাংসল, পৃষ্ঠ-অঙ্কীয় (dorsiventral) হ্যাপ্লয়েড দেহ — প্রকৃত মূল, কাণ্ড, পাতা নেই; Riccia এর প্রধান ও স্বাধীন জনু।', a: [RT[1].x2 - 14, RT[1].y2 + 6], l: [300, 20] },
    { id: 'dich', bn: 'দ্বিবিভাজন বিন্দু', lb: 'দ্বিবিভাজন', en: 'Dichotomy', fn: 'শীর্ষ বৃদ্ধিবিন্দু দুই ভাগ হওয়ায় শাখা বারবার সমান দুই ভাগে বিভক্ত — দ্বিবিভাজিত (dichotomous) শাখায়ন। পুরনো অংশ মরে গেলে শাখাগুলো আলাদা হয়ে নতুন উদ্ভিদ (অঙ্গজ জনন)।', a: [RP[0].x2, RP[0].y2], l: [300, 60] },
    { id: 'groove', bn: 'পৃষ্ঠীয় মধ্য খাঁজ', lb: 'মধ্য খাঁজ', en: 'Dorsal median groove', fn: 'প্রতিটি শাখার মাঝ বরাবর লম্বা খাঁজ; এর তলায় পুংধানী ও স্ত্রীধানী নিমজ্জিত থাকে; বৃষ্টির পানি জমে শুক্রাণু চলাচলে সাহায্য করে।', a: [RP[2].x1 + (RP[2].x2 - RP[2].x1) * .6, RP[2].y1 + (RP[2].y2 - RP[2].y1) * .6], l: [300, 286] },
    { id: 'notch', bn: 'শীর্ষ খাঁজ ও বৃদ্ধিবিন্দু', lb: 'শীর্ষ খাঁজ', en: 'Apical notch', fn: 'প্রতিটি শাখার আগার খাঁজে শীর্ষকোষ (বৃদ্ধিবিন্দু) থাকে — এখান থেকে থ্যালাস দৈর্ঘ্যে বাড়ে।', a: [RT[0].x2, RT[0].y2], l: [214, 16] },
    { id: 'sporo', bn: 'নিমজ্জিত যৌনাঙ্গ ও স্পোরোফাইট', lb: 'স্পোরোফাইট', en: 'Embedded sex organs / sporophytes', fn: 'খাঁজের তলায় থ্যালাসের ভেতরে পুংধানী, স্ত্রীধানী ও পরে গোল ক্যাপসুল (স্পোরোফাইট) — বাইরে থেকে কালো বিন্দুর মতো দেখা যায়।', a: [RT[5].x1 + (RT[5].x2 - RT[5].x1) * .4, RT[5].y1 + (RT[5].y2 - RT[5].y1) * .4], l: [60, 286] },
    { id: 'scale', bn: 'শল্ক (অঙ্কীয় দিক থেকে)', lb: 'শল্ক', en: 'Ventral scales', fn: 'অঙ্কীয় তলের কিনারায় এক স্তরের বহুকোষী, প্রায়ই বেগুনি শল্ক — কচি বৃদ্ধিবিন্দু রক্ষা করে ও পানি ধরে রাখে; কিনারা দিয়ে উঁকি দেয়।', a: [RSC[18][0] + RSC[18][2][0] * 3, RSC[18][1] + RSC[18][2][1] * 3], l: [40, 56] },
    { id: 'rhizoid', bn: 'রাইজয়েড (অঙ্কীয় দিকে)', lb: 'রাইজয়েড', en: 'Rhizoids', fn: 'অঙ্কীয় তল থেকে এককোষী, শাখাহীন রাইজয়েড — মসৃণ ও গুটিযুক্ত দুই ধরন; মাটিতে আটকে রাখে এবং পানি ও খনিজ শোষণ করে।', a: [180 + 70 * Math.cos(.09 + 6.283 * 20 / 36), 150 + 70 * Math.sin(.09 + 6.283 * 20 / 36)], l: [40, 150] }
  ]
}));

/* ───────── Riccia থ্যালাসের প্রস্থচ্ছেদ ───────── */
const tX0 = 90, tX1 = 330, tC = 210, tH = 120;
const tTop = x => 112 + 22 * Math.exp(-(((x - tC) / 18) ** 2)) + 34 * ((x - tC) / tH) ** 4;
const tBot = x => 238 - 26 * ((x - tC) / tH) ** 4;
const tMid = x => tTop(x) + (tBot(x) - tTop(x)) * .5;
const tCols = []; for (let x = 96; x <= 324; x += 11) tCols.push(x);
V.ricciaTS = Object.assign({
  t: 'Riccia থ্যালাসের প্রস্থচ্ছেদ', k: ['2d', 'label', 'int', 'anim'],
  cap: 'উপরের অর্ধেক সালোকসংশ্লেষী অঞ্চল — খাড়া সারি সারি ক্লোরোপ্লাস্টযুক্ত কোষের সূত্র (আত্তীকরণ সূত্র), মাঝে বায়ুনালি; প্রতিটি সূত্রের মাথার বড় বর্ণহীন কোষ মিলে অবিচ্ছিন্ন নয় এমন উপরের ত্বক, ফাঁকগুলো বায়ুরন্ধ্র। নিচের অর্ধেক বর্ণহীন প্যারেনকাইমার সঞ্চয়ী অঞ্চল (শ্বেতসার)। অঙ্কীয় ত্বক থেকে রাইজয়েড ও শল্ক।'
}, BK.diagram({
  W: 360, H: 330, label: 'Riccia থ্যালাসের প্রস্থচ্ছেদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rv = BK.ramp(3), Rr = BK.ramp(6);
    let d = `M${tX0} ${tTop(tX0)}`; for (let x = tX0 + 4; x <= tX1; x += 4) d += `L${x} ${tTop(x).toFixed(1)}`; for (let x = tX1; x >= tX0; x -= 4) d += `L${x} ${tBot(x).toFixed(1)}`;
    E('path', { d: d + 'Z', fill: FK.alpha(R.lt, .18), stroke: R.dk, 'stroke-width': 1.4 }, g);
    const sc = P('scale'); E('path', { d: `M${tX0 + 10} ${tBot(tX0 + 10) - 2}C${tX0 - 6} ${tBot(tX0) + 4} ${tX0 - 14} ${tTop(tX0) + 10} ${tX0 - 4} ${tTop(tX0) - 10}C${tX0 + 2} ${tTop(tX0) + 6} ${tX0 + 2} ${tBot(tX0) - 10} ${tX0 + 16} ${tBot(tX0 + 16)}Z`, fill: FK.alpha(Rv.c, .85), stroke: Rv.dk }, sc);
    E('path', { d: `M${tX1 - 10} ${tBot(tX1 - 10) - 2}C${tX1 + 6} ${tBot(tX1) + 4} ${tX1 + 12} ${tTop(tX1) + 10} ${tX1 + 4} ${tTop(tX1) - 10}C${tX1 - 2} ${tTop(tX1) + 6} ${tX1 - 2} ${tBot(tX1) - 10} ${tX1 - 16} ${tBot(tX1 - 16)}Z`, fill: FK.alpha(Rv.c, .85), stroke: Rv.dk }, sc);
    const st = P('storage'); for (let x = tX0 + 6; x < tX1 - 4; x += 10) { const yb = tBot(x) - 9; let row = 0; for (let y = tMid(x) + 2; y < yb - 6; y += 8.5, row++) { const xx = x + (row % 2 ? 5 : 0); if (xx > tX1 - 8) continue; E('rect', { x: xx - 4.6, y, width: 9.2, height: 8, rx: 2, fill: C.sf, stroke: FK.alpha(C.mu, .55), 'stroke-width': .7 }, st); if ((row + x) % 3 === 0) E('circle', { cx: xx, cy: y + 4, r: 1.2, fill: FK.alpha(C.mu, .7) }, st); } }
    const le = P('lowep'); for (let x = tX0 + 8; x < tX1 - 6; x += 7) E('rect', { x: x - 3, y: tBot(x) - 8, width: 6.4, height: 6.4, rx: 1, fill: FK.alpha(Rr.lt, .5), stroke: FK.alpha(Rr.dk, .6), 'stroke-width': .6 }, le);
    const ca = P('canal'); tCols.slice(0, -1).forEach((x, i) => { const xm = x + 5.5; E('rect', { x: xm - 2, y: tTop(xm) + 6, width: 4, height: Math.max(4, tMid(xm) - tTop(xm) - 6), fill: FK.alpha(BK.ramp(5).lt, .55) }, ca); });
    const as = P('assim'); const hy = P('hyaline');
    tCols.forEach(x => { const y0 = tTop(x), y1 = tMid(x); E('ellipse', { cx: x, cy: y0 + 4, rx: 4.6, ry: 4.6, fill: C.sf, stroke: R.dk, 'stroke-width': .8 }, hy); for (let y = y0 + 12; y < y1 - 2; y += 8) E('ellipse', { cx: x, cy: y, rx: 3.4, ry: 3.6, fill: R.c, stroke: R.dk, 'stroke-width': .5 }, as); });
    const po = P('pore'); [tCols[5] + 5.5, tCols[16] + 5.5].forEach(x => E('path', { d: `M${x} ${tTop(x) - 6}v8`, stroke: BK.ramp(5).dk, 'stroke-width': 1.6 }, po));
    const gr = P('groove'); E('path', { d: `M${tC - 22} ${tTop(tC - 22) - 4}Q${tC} ${tTop(tC) + 8} ${tC + 22} ${tTop(tC + 22) - 4}`, stroke: R.dk, 'stroke-width': 2, fill: 'none', 'stroke-dasharray': '3 2' }, gr);
    const sm = P('smooth'), tb = P('tuber');
    for (let i = 0; i < 11; i++) { const x = 118 + i * 18, y0 = tBot(x), y1 = 296 - (i % 3) * 6, b = (i % 2 ? 4 : -4); const dd = `M${x} ${y0}Q${x + b} ${(y0 + y1) / 2} ${x + b * .3} ${y1}`; E('path', { d: dd, stroke: Rr.dk, 'stroke-width': 2.6, fill: 'none', 'stroke-linecap': 'round', opacity: .55 }, i % 2 ? tb : sm); if (i % 2) for (let y = y0 + 8; y < y1 - 4; y += 7) E('path', { d: `M${x + b * .5 - 2.5} ${y}h5`, stroke: Rr.dk, 'stroke-width': 1 }, tb); }
  },
  idle(g, C, t) {
    const Rb = BK.ramp(5), Rg = BK.ramp(4);
    [tCols[5] + 5.5, tCols[16] + 5.5].forEach((x, k) => { for (let j = 0; j < 3; j++) { const f = (t * .35 + j / 3 + k * .2) % 1; E('circle', { cx: x + 3 * Math.sin(t * 2 + j), cy: tTop(x) - 30 + f * 46, r: 1.8, fill: Rb.c, opacity: 1 - f * .6 }, g); const f2 = (t * .3 + j / 3 + .5 + k * .3) % 1; E('circle', { cx: x - 4 + 3 * Math.cos(t * 2 + j), cy: tTop(x) + 16 - f2 * 46, r: 1.6, fill: Rg.c, opacity: 1 - f2 }, g); } });
    T(g, 6, 292, 'নীল: CO₂ ঢোকে', { fs: 9.5, c: Rb.ink, w: 600 }); T(g, 6, 306, 'লাল: O₂ বের হয়', { fs: 9.5, c: Rg.ink, w: 600 });
  },
  parts: [
    { id: 'hyaline', bn: 'উপরের ত্বক (বর্ণহীন শীর্ষকোষ)', lb: 'উপরের ত্বক', en: 'Upper epidermis', fn: 'প্রতিটি আত্তীকরণ সূত্রের মাথার বড়, বর্ণহীন কোষগুলো মিলে একটি অবিচ্ছিন্ন নয় এমন উপরের ত্বক তৈরি করে — পানি ধরে রাখে ও আলো ভেতরে যেতে দেয়।', a: [tCols[2], tTop(tCols[2]) + 2], l: [128, 30] },
    { id: 'pore', bn: 'বায়ুরন্ধ্র (সরল)', lb: 'বায়ুরন্ধ্র', en: 'Air pore', fn: 'দুটি শীর্ষকোষের মাঝের সরল ফাঁক — বায়ুনালিতে CO₂ ঢোকে ও O₂ বের হয়। Riccia র রন্ধ্র সরল, Marchantia র মতো পিপা আকৃতির নয়।', a: [tCols[5] + 5.5, tTop(tCols[5] + 5.5) - 2], l: [168, 66] },
    { id: 'groove', bn: 'পৃষ্ঠীয় খাঁজ', lb: 'পৃষ্ঠীয় খাঁজ', en: 'Dorsal groove', fn: 'থ্যালাসের মাঝ বরাবর খাঁজ — প্রস্থচ্ছেদে উপরের তল এখানে নিচু।', a: [tC, tTop(tC) + 1], l: [228, 30] },
    { id: 'canal', bn: 'বায়ুনালি (বায়ুপ্রকোষ্ঠ)', lb: 'বায়ুনালি', en: 'Air canal', fn: 'পাশাপাশি আত্তীকরণ সূত্রের মাঝের সরু বায়ুপূর্ণ নালি — গ্যাস বিনিময় সহজ করে।', a: [tCols[18] + 5.5, tTop(tCols[18]) + 20], l: [300, 66] },
    { id: 'assim', bn: 'আত্তীকরণ সূত্র (সালোকসংশ্লেষী অঞ্চল)', lb: 'আত্তীকরণ সূত্র', en: 'Assimilatory filaments', fn: 'উপরের অর্ধেকে খাড়া, অশাখ, সারি সারি কোষের সূত্র — প্রতিটি কোষে অনেক ক্লোরোপ্লাস্ট; খাদ্য তৈরি করে।', a: [tCols[1], tMid(tCols[1]) - 8], l: [70, 112] },
    { id: 'storage', bn: 'সঞ্চয়ী অঞ্চল', lb: 'সঞ্চয়ী অঞ্চল', en: 'Storage region', fn: 'নিচের অর্ধেকে ঘন সন্নিবিষ্ট বর্ণহীন প্যারেনকাইমা কোষ — শ্বেতসার সঞ্চয় করে; ক্লোরোপ্লাস্ট নেই।', a: [tX0 + 22, tMid(tX0 + 22) + 14], l: [70, 168] },
    { id: 'lowep', bn: 'নিচের ত্বক', lb: 'নিচের ত্বক', en: 'Lower epidermis', fn: 'অঙ্কীয় তলের এক স্তরের কোষ — এখান থেকেই রাইজয়েড ও শল্ক উৎপন্ন হয়।', a: [tX0 + 40, tBot(tX0 + 40) - 4], l: [70, 214] },
    { id: 'scale', bn: 'শল্ক', en: 'Scale', fn: 'অঙ্কীয় তলের কিনারা থেকে উৎপন্ন এক কোষ পুরু বহুকোষী শল্ক (প্রায়ই বেগুনি) — কিনারা বরাবর উপরের দিকে বাঁকা।', a: [tX0 - 6, tTop(tX0) + 18], l: [70, 258] },
    { id: 'smooth', bn: 'মসৃণ রাইজয়েড', lb: 'মসৃণ রাইজয়েড', en: 'Smooth-walled rhizoid', fn: 'ভেতরের প্রাচীর মসৃণ এককোষী রাইজয়েড — জীবিত, পানি ও খনিজ শোষণ করে এবং আটকে রাখে।', a: [118 + 4 * 18 - 1, 284], l: [150, 322] },
    { id: 'tuber', bn: 'গুটিযুক্ত (টিউবারকুলেট) রাইজয়েড', lb: 'গুটিযুক্ত রাইজয়েড', en: 'Tuberculate rhizoid', fn: 'ভেতরের প্রাচীর থেকে খুঁটির মতো উঁচু অংশ (পেগ) বের হয় — পরিণত অবস্থায় মৃত; কৈশিক নালির মতো পানি পরিবহনে সাহায্য করে।', a: [118 + 7 * 18 + 2, 268], l: [270, 322] }
  ]
}));

/* ───────── পুংধানী ও স্ত্রীধানী ───────── */
const AX = 70, GX = 236;
V.ricciaSex = Object.assign({
  t: 'Riccia এর পুংধানী ও স্ত্রীধানী', k: ['2d', 'label', 'int', 'anim'],
  cap: 'দুটিই থ্যালাসের পৃষ্ঠীয় খাঁজের তলায় প্রকোষ্ঠে নিমজ্জিত। পুংধানী (অ্যান্থেরিডিয়াম) বৃন্তযুক্ত, গদা আকৃতির — বন্ধ্যা আবরণের ভেতরে অসংখ্য পুংজনন কোষ, প্রতিটি থেকে একটি দুই-ফ্ল্যাজেলাযুক্ত শুক্রাণু। স্ত্রীধানী (আর্কিগোনিয়াম) ফ্লাস্ক আকৃতির — লম্বা গ্রীবা ও স্ফীত অঙ্কদেশে ডিম্বাণু। চালু করলে পানিতে শুক্রাণু গ্রীবার দিকে সাঁতরায়।'
}, BK.diagram({
  W: 360, H: 300, label: 'পুংধানী ও স্ত্রীধানী',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Ra = BK.ramp(5), Rf = BK.ramp(8), Rr = BK.ramp(6);
    E('path', { d: 'M10 84H350V270H10Z', fill: FK.alpha(R.lt, .22), stroke: 'none' }, g);
    E('path', { d: `M10 84H${AX - 30}Q${AX - 26} 84 ${AX - 26} 90V96M${AX + 26} 96V90Q${AX + 26} 84 ${AX + 32} 84H350`, stroke: R.dk, 'stroke-width': 1.6, fill: 'none' }, g);
    for (let x = 14; x < 350; x += 13) for (let y = 98; y < 266; y += 13) { if ((x > AX - 32 && x < AX + 32 && y < 230) || (x > GX - 44 && x < GX + 44 && y < 262)) continue; E('rect', { x, y, width: 11, height: 11, rx: 2, fill: 'none', stroke: FK.alpha(C.mu, .3), 'stroke-width': .6 }, g); }
    const ch = P('chamber'); E('path', { d: `M${AX - 26} 96V224Q${AX - 26} 232 ${AX - 18} 232H${AX + 18}Q${AX + 26} 232 ${AX + 26} 224V96`, fill: FK.alpha(Ra.lt, .25), stroke: R.dk, 'stroke-width': 1.4 }, ch); E('path', { d: `M${AX - 14} 84h28`, stroke: Ra.dk, 'stroke-width': 2, 'stroke-dasharray': '2 2' }, ch);
    const stl = P('stalk'); E('rect', { x: AX - 4, y: 212, width: 8, height: 20, fill: FK.alpha(Rr.lt, .6), stroke: Rr.dk, 'stroke-width': 1.2 }, stl);
    const jk = P('jacket'); E('path', { d: `M${AX} 108C${AX + 24} 108 ${AX + 24} 212 ${AX} 212C${AX - 24} 212 ${AX - 24} 108 ${AX} 108Z`, fill: FK.alpha(Ra.lt, .7), stroke: Ra.dk, 'stroke-width': 3 }, jk);
    const an = P('andro'); for (let y = 118; y < 206; y += 7) for (let x = AX - 16; x < AX + 18; x += 7) { const dx = (x - AX) / 18, dy = (y - 160) / 50; if (dx * dx + dy * dy > .82) continue; E('rect', { x: x - 3, y: y - 3, width: 6, height: 6, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .4 }, an); }
    const nk = P('neck'); E('path', { d: `M${GX - 10} 40V200M${GX + 10} 40V200`, stroke: Rf.dk, 'stroke-width': 7 }, nk); E('path', { d: `M${GX - 10} 40V200M${GX + 10} 40V200`, stroke: FK.alpha(Rf.lt, .9), 'stroke-width': 4 }, nk); for (let y = 48; y < 200; y += 10) E('path', { d: `M${GX - 13.5} ${y}h7M${GX + 6.5} ${y}h7`, stroke: Rf.dk, 'stroke-width': .7 }, nk);
    const cv = P('cover'); [GX - 8, GX, GX + 8].forEach(x => E('ellipse', { cx: x, cy: 36, rx: 4.5, ry: 5, fill: Rf.c, stroke: Rf.dk, 'stroke-width': .8 }, cv));
    const nc = P('ncc'); for (let i = 0; i < 4; i++) E('rect', { x: GX - 5, y: 54 + i * 34, width: 10, height: 30, rx: 3, fill: FK.alpha(C.mu, .25), stroke: C.mu, 'stroke-width': .8 }, nc);
    const vt = P('venter'); E('path', { d: `M${GX - 10} 200C${GX - 38} 210 ${GX - 42} 262 ${GX} 266C${GX + 42} 262 ${GX + 38} 210 ${GX + 10} 200`, fill: FK.alpha(Rf.lt, .45), stroke: Rf.dk, 'stroke-width': 5 }, vt);
    const vc = P('vcc'); E('ellipse', { cx: GX, cy: 208, rx: 7, ry: 5, fill: FK.alpha(C.mu, .35), stroke: C.mu }, vc);
    const eg = P('egg'); E('circle', { cx: GX, cy: 238, r: 18, fill: Rf.c, stroke: Rf.dk, 'stroke-width': 1.4 }, eg); E('circle', { cx: GX, cy: 236, r: 6, fill: BK.ramp(3).c }, eg);
  },
  idle(g, C, t) {
    const R = BK.ramp(5);
    E('path', { d: 'M10 74Q90 68 180 74T350 74', stroke: FK.alpha(R.c, .4), 'stroke-width': 10, fill: 'none' }, g);
    for (let i = 0; i < 5; i++) { const f = (t * .18 + i / 5) % 1, x = AX + (GX - AX) * f, y = 72 - 22 * Math.sin(f * Math.PI); B6.sperm(g, x, y, R, t + i, 0); }
  },
  parts: [
    { id: 'chamber', bn: 'পুংধানী প্রকোষ্ঠ', lb: 'প্রকোষ্ঠ', en: 'Antheridial chamber', fn: 'পৃষ্ঠীয় খাঁজের তলায় থ্যালাসের ভেতরের গহ্বর; উপরে সরু মুখ (অস্টিওল) দিয়ে শুক্রাণু বাইরে আসে।', a: [AX - 26, 104], l: [30, 30], an: 'middle' },
    { id: 'jacket', bn: 'বন্ধ্যা আবরণ (জ্যাকেট)', lb: 'জ্যাকেট', en: 'Sterile jacket', fn: 'এক স্তরের বন্ধ্যা কোষের আবরণ — ভেতরের জনন কোষকে রক্ষা করে; পানিতে ফেটে শুক্রাণু মুক্ত করে। শৈবালের জননাঙ্গে এমন আবরণ নেই।', a: [AX + 18, 136], l: [110, 112] },
    { id: 'andro', bn: 'পুংজনন কোষ (অ্যান্ড্রোসাইট)', lb: 'অ্যান্ড্রোসাইট', en: 'Androcytes', fn: 'আবরণের ভেতরের অসংখ্য ছোট কোষ; প্রতিটি রূপান্তরিত হয়ে একটি দুই-ফ্ল্যাজেলাযুক্ত শুক্রাণু (অ্যান্থেরোজয়েড, n) তৈরি করে।', a: [AX + 4, 170], l: [110, 168] },
    { id: 'stalk', bn: 'বৃন্ত', en: 'Stalk', fn: 'ছোট বহুকোষী বৃন্ত — পুংধানীকে প্রকোষ্ঠের তলায় আটকে রাখে।', a: [AX, 224], l: [110, 226] },
    { id: 'cover', bn: 'আবরণী কোষ (ঢাকনা কোষ)', lb: 'আবরণী কোষ', en: 'Cover cells', fn: 'গ্রীবার মাথার চারটি কোষ — পরিণত হলে ছড়িয়ে গিয়ে পথ খুলে দেয়।', a: [GX + 8, 32], l: [282, 22] },
    { id: 'neck', bn: 'গ্রীবা (ছয় সারি কোষ)', lb: 'গ্রীবা', en: 'Neck', fn: 'লম্বা নলাকার অংশ — ছয়টি খাড়া সারির কোষে গঠিত; থ্যালাসের উপরে উঁচু হয়ে থাকে।', a: [GX + 12, 104], l: [282, 104] },
    { id: 'ncc', bn: 'গ্রীবা নালিকা কোষ (চারটি)', lb: 'গ্রীবা নালিকা', en: 'Neck canal cells', fn: 'গ্রীবার ভেতরে সাধারণত চারটি; পরিণত অবস্থায় গলে মিউসিলেজ তৈরি করে — এর রাসায়নিক আকর্ষণে শুক্রাণু ডিম্বাণুর দিকে যায় ও পথ পায়।', a: [GX, 150], l: [282, 150] },
    { id: 'vcc', bn: 'অঙ্কীয় নালিকা কোষ', lb: 'অঙ্কীয় নালিকা', en: 'Ventral canal cell', fn: 'ডিম্বাণুর ঠিক উপরের ছোট কোষ — গ্রীবা নালিকা কোষের সাথে গলে যায়।', a: [GX + 6, 208], l: [282, 196] },
    { id: 'egg', bn: 'ডিম্বাণু (n)', lb: 'ডিম্বাণু', en: 'Egg', fn: 'অঙ্কদেশের বড় স্ত্রী গ্যামিট — শুক্রাণুর সাথে মিলে ডিপ্লয়েড জাইগোট (2n) হয়।', a: [GX + 12, 244], l: [290, 244] },
    { id: 'venter', bn: 'অঙ্কদেশ (ভেন্টার)', lb: 'অঙ্কদেশ', en: 'Venter', fn: 'স্ত্রীধানীর স্ফীত গোড়া; নিষেকের পর এর প্রাচীর দুই স্তরের ক্যালিপট্রা হয়ে বাড়ন্ত স্পোরোফাইটকে ঘিরে রাখে।', a: [GX - 36, 240], l: [160, 288] }
  ]
}));

/* ───────── স্পোরোফাইটের পরিস্ফুটন ───────── */
V.ricciaSporo = Object.assign({
  t: 'Riccia এর স্পোরোফাইটের পরিস্ফুটন', k: ['2d', 'anim', 'int'],
  cap: 'Riccia র স্পোরোফাইট ব্রায়োফাইটের মধ্যে সবচেয়ে সরল — পদ ও সিটা নেই, কেবল একটি গোল ক্যাপসুল। জাইগোট থেকে ভ্রূণ, তারপর এক স্তরের প্রাচীর ও ভেতরে স্পোর মাতৃকোষ; মায়োসিসে চারটি করে স্পোর (টেট্রাড)। থ্যালাস পচে গেলে স্পোর মুক্ত হয়।'
}, BK.steps({
  W: 360, H: 250, label: 'Riccia স্পোরোফাইট', dur: 2.8,
  stages: [
    { t: 'নিষেক → জাইগোট', en: 'Zygote (2n)', d: 'শুক্রাণু গ্রীবা দিয়ে ঢুকে ডিম্বাণুর সাথে মিলিত হয়; অঙ্কদেশে ডিপ্লয়েড জাইগোট তৈরি হয় ও চারপাশে প্রাচীর গড়ে — স্পোরোফাইট জনুর প্রথম কোষ।' },
    { t: 'ভ্রূণ ও ক্যালিপট্রা', en: 'Embryo & calyptra', d: 'জাইগোট বারবার বিভাজিত হয়ে গোল ভ্রূণ; বাইরের স্তর (অ্যাম্ফিথেসিয়াম) থেকে ক্যাপসুল প্রাচীর, ভেতরের অংশ (এন্ডোথেসিয়াম) থেকে স্পোরজনন কলা। অঙ্কদেশের প্রাচীর দুই স্তরের ক্যালিপট্রা হয়।' },
    { t: 'স্পোর মাতৃকোষ', en: 'Spore mother cells', d: 'স্পোরজনন কলার কোষগুলো স্পোর মাতৃকোষে (2n) পরিণত হয়; কিছু কোষ বন্ধ্যা পুষ্টিকোষ হয়ে খাদ্য জোগায় ও পরে মিশে যায়। ইলেটার নেই।' },
    { t: 'মায়োসিস → টেট্রাড', en: 'Meiosis', d: 'প্রতিটি স্পোর মাতৃকোষে মায়োসিস — চারটি হ্যাপ্লয়েড স্পোরের চতুষ্টয় (টেট্রাড)। ক্যাপসুল প্রাচীর ও ক্যালিপট্রার ভেতরের স্তর ভেঙে যায়।' },
    { t: 'স্পোর মুক্তি ও অঙ্কুরোদগম', en: 'Spore release', d: 'থ্যালাসের পুরনো অংশ পচে গেলে স্পোর মাটিতে মুক্ত হয়; অনুকূল পরিবেশে স্পোর থেকে ছোট জার্ম টিউব বের হয়ে নতুন থ্যালাস (n) গড়ে।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), Rz = BK.ramp(6), Rf = BK.ramp(8), Rs = BK.ramp(9);
    const svg = g.ownerSVGElement; svg._ph = (svg._ph || 0) + .03; const ph = svg._ph;
    if (s < 4) { E('rect', { x: 20, y: 60, width: 320, height: 170, rx: 10, fill: FK.alpha(R.lt, .25), stroke: R.dk, 'stroke-width': 1.2 }, g); E('path', { d: 'M20 60H340', stroke: R.dk, 'stroke-width': 3 }, g); T(g, 30, 52, 'থ্যালাস (n)', { fs: 11, w: 600, c: R.ink }); }
    const cx = 180, cy = 150;
    if (s === 0) { E('path', { d: 'M172 60V112M188 60V112', stroke: Rf.dk, 'stroke-width': 3 }, g); E('path', { d: 'M172 112C150 118 150 186 180 188C210 186 210 118 188 112', fill: FK.alpha(Rf.lt, .4), stroke: Rf.dk, 'stroke-width': 3 }, g); const k = Math.min(1, u * 1.5); B6.sperm(g, 180, 40 + 100 * k, BK.ramp(5), ph, Math.PI / 2); E('circle', { cx, cy: 158, r: 16, fill: k >= 1 ? Rz.c : Rf.c, stroke: k >= 1 ? Rz.dk : Rf.dk, 'stroke-width': k >= 1 ? 2.5 : 1.2 }, g); T(g, cx, 220, k >= 1 ? 'জাইগোট (2n)' : 'ডিম্বাণু (n)', { fs: 11, a: 'middle', w: 650, c: k >= 1 ? Rz.ink : Rf.ink }); }
    if (s === 1) { const r = 16 + 18 * u; E('circle', { cx, cy, r: r + 10, fill: 'none', stroke: Rf.dk, 'stroke-width': 3 }, g); E('circle', { cx, cy, r: r + 5, fill: 'none', stroke: Rf.dk, 'stroke-width': 2, opacity: .7 }, g); E('circle', { cx, cy, r, fill: FK.alpha(Rz.lt, .8), stroke: Rz.dk, 'stroke-width': 2.5 }, g); const n = Math.min(16, Math.pow(2, Math.floor(1 + u * 4))); const k = Math.ceil(Math.sqrt(n)); for (let i = 0; i < n; i++) { const x = cx - r * .6 + (i % k + .5) * (r * 1.2 / k), y = cy - r * .6 + (Math.floor(i / k) + .5) * (r * 1.2 / k); E('circle', { cx: x, cy: y, r: r * .5 / k, fill: Rz.c, opacity: .8 }, g); } T(g, cx + 74, 96, 'ক্যালিপট্রা (2 স্তর, n)', { fs: 10.5, a: 'middle', w: 600, c: Rf.ink }); T(g, cx, 222, 'ভ্রূণ (2n)', { fs: 11, a: 'middle', w: 650, c: Rz.ink }); }
    if (s >= 2 && s <= 3) { const r = 40; E('circle', { cx, cy, r: r + 12, fill: 'none', stroke: Rf.dk, 'stroke-width': 3, 'stroke-dasharray': s === 3 ? `${8 - 6 * u} 4` : null }, g); E('circle', { cx, cy, r, fill: FK.alpha(Rz.lt, .5), stroke: Rz.dk, 'stroke-width': 3, 'stroke-dasharray': s === 3 ? `${10 - 7 * u} 5` : null }, g); for (let i = 0; i < 19; i++) { const a = i * 2.4, rr = 7 + 27 * Math.sqrt(i / 19), x = cx + rr * Math.cos(a), y = cy + rr * Math.sin(a); if (s === 2) { const nurse = i % 5 === 3; E('circle', { cx: x, cy: y, r: nurse ? 4 * (1 - u * .5) : 5.4, fill: nurse ? FK.alpha(C.mu, .4) : Rz.c, stroke: Rz.dk, 'stroke-width': .6 }, g); } else { if (i % 5 === 3) continue; const sp = 2.6 * u; [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a1, b1]) => E('circle', { cx: x + a1 * sp, cy: y + b1 * sp, r: 2.6, fill: Rs.c, stroke: Rs.dk, 'stroke-width': .5 }, g)); } } T(g, cx, 222, s === 2 ? 'স্পোর মাতৃকোষ (2n) + পুষ্টিকোষ' : 'মায়োসিস: 2n → চারটি n স্পোর', { fs: 11, a: 'middle', w: 650, c: s === 2 ? Rz.ink : Rs.ink }); T(g, cx + 96, 104, 'ক্যাপসুল প্রাচীর', { fs: 10.5, a: 'middle', w: 600, c: Rz.ink }); }
    if (s === 4) { const k = Math.min(1, u * 1.6); E('rect', { x: 20, y: 150, width: 320, height: 70, fill: FK.alpha('#8a6b3a', .2) }, g); E('path', { d: 'M20 150H340', stroke: '#8a6b3a', 'stroke-width': 2 }, g); T(g, 30, 238, 'মাটি', { fs: 11, w: 600, c: C.mu }); E('rect', { x: 40, y: 110, width: 280, height: 40 * (1 - k), fill: FK.alpha(R.lt, .3 * (1 - k)), stroke: FK.alpha(R.dk, 1 - k) }, g); for (let i = 0; i < 14; i++) { const x = 60 + i * 18, y = 130 + 14 * k + 4 * Math.sin(i * 1.7); E('circle', { cx: x, cy: y, r: 3, fill: Rs.c, stroke: Rs.dk, 'stroke-width': .6 }, g); if (u > .6 && i % 4 === 1) { const gl = (u - .6) / .4; E('path', { d: `M${x} ${y}q${8 * gl} ${-6 * gl} ${18 * gl} ${-4 * gl}`, stroke: R.c, 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round' }, g); } } T(g, 180, 80, u > .6 ? 'জার্ম টিউব → নতুন থ্যালাস (n)' : 'থ্যালাস পচে স্পোর মুক্ত', { fs: 11.5, a: 'middle', w: 650, c: u > .6 ? R.ink : Rs.ink }); }
  }
}));

/* ───────── জীবনচক্র ───────── */
V.ricciaCycle = Object.assign({ t: 'Riccia এর জীবনচক্র ও জনুঃক্রম', k: ['cycle', 'anim', 'int'], cap: 'হ্যাপ্লয়েড গ্যামিটোফাইট জনু (থ্যালাস থেকে গ্যামিট পর্যন্ত) ও ডিপ্লয়েড স্পোরোফাইট জনু (জাইগোট থেকে স্পোর মাতৃকোষ পর্যন্ত) পর্যায়ক্রমে আসে — বিষমরূপী জনুঃক্রম। নিষেকে পানি লাগে; মায়োসিস স্পোর তৈরির সময়।' }, BK.cycle({
  W: 360, H: 350, label: 'Riccia জীবনচক্র', center: 'Riccia', sub: 'গ্যামিটোফাইট প্রধান', rx: 116, ry: 122,
  nodes: [
    { t: 'থ্যালাস (n)', en: 'Gametophyte', d: 'সবুজ, স্বাধীন, দ্বিবিভাজিত থ্যালাস — প্রধান জনু। অঙ্গজভাবেও (খণ্ডায়ন, টিউবার) বংশবৃদ্ধি করে।' },
    { t: 'পুংধানী ও স্ত্রীধানী', en: 'Sex organs', d: 'পৃষ্ঠীয় খাঁজে নিমজ্জিত বহুকোষী যৌনাঙ্গ; প্রজাতিভেদে একই থ্যালাসে (সহবাসী) বা আলাদা থ্যালাসে (ভিন্নবাসী)।' },
    { t: 'শুক্রাণু + ডিম্বাণু', en: 'Fertilization', d: 'বৃষ্টি বা শিশিরের পানিতে দুই-ফ্ল্যাজেলাযুক্ত শুক্রাণু সাঁতরে গ্রীবা দিয়ে ঢুকে ডিম্বাণুকে নিষিক্ত করে — উগ্যামি।', io: [['পানি', 'in']] },
    { t: 'জাইগোট (2n)', en: 'Zygote', d: 'স্পোরোফাইট জনুর শুরু; অঙ্কদেশের ভেতরেই থাকে।' },
    { t: 'ক্যাপসুল (2n)', en: 'Sporophyte', d: 'ভ্রূণ থেকে গোল ক্যাপসুল — পদ ও সিটা নেই; থ্যালাস থেকে পুষ্টি নেয় (নির্ভরশীল)।' },
    { t: 'মায়োসিস → স্পোর', en: 'Meiosis', d: 'স্পোর মাতৃকোষে মায়োসিসে চারটি করে হ্যাপ্লয়েড স্পোর — গ্যামিটোফাইট জনুর প্রথম কোষ। সব স্পোর একই রকম (সমরেণু)।', io: [['স্পোর', 'out']] },
    { t: 'অঙ্কুরোদগম', en: 'Germination', d: 'থ্যালাস পচে মুক্ত স্পোর থেকে জার্ম টিউব বের হয়ে নতুন থ্যালাস গড়ে।' }
  ]
}));
})();
