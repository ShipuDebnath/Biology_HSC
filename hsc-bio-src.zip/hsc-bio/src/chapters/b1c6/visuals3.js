/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §৬.৩ ব্যবহারিক ও §৬.৪ পুনরালোচনা
   pterisPractical: Pteris এর স্পোরোফাইট পর্যবেক্ষণের ধাপ — ধাপে ধাপে
   rachisStain    : রঞ্জনের প্রভাব — রঞ্জনহীন / স্যাফ্রানিন / দ্বি-রঞ্জন; 10× ও 40× (রঞ্জক ধীরে চড়ে)
   b1c6map        : অধ্যায়ের মানচিত্র — মাইন্ড ম্যাপ
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

const fern = (g, x, y, s, R, sori) => { E('path', { d: `M${x} ${y}Q${x - 4 * s} ${y - 20 * s} ${x} ${y - 40 * s}`, stroke: R.dk, 'stroke-width': 1.6, fill: 'none' }, g); for (let i = 0; i < 6; i++) { const yy = y - 12 * s - i * 5 * s, L = (16 - i * 2) * s; [-1, 1].forEach(sd => { E('path', { d: `M${x} ${yy}Q${x + sd * L * .5} ${yy - L * .15 - 2 * s} ${x + sd * L} ${yy - L * .3}Q${x + sd * L * .5} ${yy - L * .15 + 2 * s} ${x} ${yy}Z`, fill: R.c, stroke: R.dk, 'stroke-width': .5 }, g); if (sori) E('path', { d: `M${x + sd * L * .2} ${yy + 1.2 * s}L${x + sd * L * .85} ${yy - L * .25 + 1.2 * s}`, stroke: BK.ramp(6).dk, 'stroke-width': 1 }, g); }); } };
V.pterisPractical = Object.assign({
  t: 'ব্যবহারিক: Pteris এর স্পোরোফাইট পর্যবেক্ষণের ধাপ', k: ['2d', 'anim', 'int'],
  cap: 'নমুনা সংগ্রহ থেকে চিত্রাঙ্কন পর্যন্ত — বাহ্যিক গঠন, সোরাস, রেণুস্থলী ও পত্রাক্ষের প্রস্থচ্ছেদ পর্যবেক্ষণ। প্রতিটি ধাপে কী দেখবে ও কী সতর্কতা নেবে তা নিচে লেখা।'
}, BK.steps({
  W: 360, H: 250, label: 'Pteris ব্যবহারিক', dur: 3,
  stages: [
    { t: 'নমুনা সংগ্রহ', en: 'Collect specimen', d: 'পুরনো দেয়াল বা ছায়াযুক্ত ভেজা স্থান থেকে রাইজোম ও মূলসহ পুরো উদ্ভিদ তোলো; উর্বর (কিনারায় বাদামি রেখাযুক্ত) পাতা বেছে নাও। রাইজোমের শল্ক, অস্থানিক মূল, একপক্ষল যৌগিক পাতা ও কুণ্ডলিত কচিপাতা লক্ষ করো।' },
    { t: 'সোরাস — হ্যান্ড লেন্স', en: 'Sori under lens', d: 'উর্বর পত্রক উল্টে হ্যান্ড লেন্সে দেখো — কিনারা বরাবর লম্বা অবিচ্ছিন্ন বাদামি সোরাস, পত্রকের বাঁকানো কিনারায় (অপ্রকৃত ইনডুসিয়াম) ঢাকা।' },
    { t: 'রেণুস্থলীর মাউন্ট', en: 'Sporangium mount', d: 'সুচের আগায় সোরাস থেকে কিছু রেণুস্থলী চেঁছে স্লাইডে এক ফোঁটা পানি বা গ্লিসারিনে নাও; কভারস্লিপ ঢাকো (বুদবুদ যেন না থাকে)।' },
    { t: 'পত্রাক্ষের প্রস্থচ্ছেদ', en: 'Section cutting', d: 'পত্রাক্ষের ছোট টুকরা আলু বা পিথের মাঝে রেখে ধারালো ব্লেডে আড়াআড়ি পাতলা ছেদ কাটো; ছেদগুলো পানিভর্তি ওয়াচগ্লাসে রাখো, সবচেয়ে পাতলাটি বেছে নাও। ব্লেড শরীর থেকে দূরে চালাও।' },
    { t: 'রঞ্জন ও মাউন্ট', en: 'Stain & mount', d: 'স্যাফ্রানিনে প্রায় 1–2 মিনিট রেখে পানিতে ধুয়ে বাড়তি রং সরাও (চাইলে ফাস্ট গ্রিনে কয়েক সেকেন্ড — দ্বি-রঞ্জন); স্লাইডে গ্লিসারিনে রেখে কভারস্লিপ দাও।' },
    { t: 'অণুবীক্ষণ ও চিত্রাঙ্কন', en: 'Observe & draw', d: 'প্রথমে কম বিবর্ধনে (10×) পুরো ছেদ, পরে বেশি বিবর্ধনে (40×) মেরিস্টিলি দেখো; রেণুস্থলীর অ্যানুলাস, স্টোমিয়াম ও স্পোর চিনে নাও। পেনসিলে পরিষ্কার চিত্র এঁকে চিহ্নিত করো ও শনাক্তকারী বৈশিষ্ট্য লেখো।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), Rb = BK.ramp(6), Rr = BK.ramp(4), glass = FK.alpha(BK.ramp(5).lt, .5);
    const tag = (t2, c) => T(g, 180, 238, t2, { fs: 11.5, a: 'middle', w: 650, c: c || C.fg });
    if (s === 0) { E('rect', { x: 20, y: 170, width: 320, height: 46, rx: 6, fill: FK.alpha('#8a6b3a', .15) }, g); fern(g, 140, 172, 3.4, R, false); fern(g, 210, 172, 3.4 + .2 * Math.sin(u * 6), R, true); E('path', { d: 'M90 178C140 172 220 182 260 176', stroke: '#6b4a2a', 'stroke-width': 8, 'stroke-linecap': 'round', fill: 'none' }, g); for (let x = 100; x < 256; x += 12) E('path', { d: `M${x} 182q-3 14 1 26`, stroke: '#6b5233', 'stroke-width': 1, fill: 'none' }, g); tag('উর্বর পাতা: কিনারায় বাদামি রেখা', Rb.ink); }
    if (s === 1) { E('path', { d: 'M40 120Q180 96 320 120Q180 150 40 120Z', fill: R.c, stroke: R.dk }, g); E('path', { d: 'M56 122Q180 104 304 122', stroke: R.dk, 'stroke-width': 1, fill: 'none' }, g); E('path', { d: 'M48 116Q180 92 312 116M48 126Q180 146 312 126', stroke: Rb.dk, 'stroke-width': 3, fill: 'none' }, g); const lx = 90 + 180 * u; E('circle', { cx: lx, cy: 122, r: 42, fill: glass, stroke: '#555', 'stroke-width': 4 }, g); E('path', { d: `M${lx + 30} ${152}l34 40`, stroke: '#6b4a2a', 'stroke-width': 9, 'stroke-linecap': 'round' }, g); for (let k = -3; k <= 3; k++) E('circle', { cx: lx + k * 10, cy: 108 - Math.abs(k) * .8, r: 3.4, fill: Rb.c, stroke: Rb.dk, 'stroke-width': .6 }, g); tag('প্রান্তীয়, রৈখিক, অবিচ্ছিন্ন সোরাস', Rb.ink); }
    if (s === 2) { E('rect', { x: 40, y: 110, width: 280, height: 60, rx: 4, fill: glass, stroke: '#7a8a9a' }, g); E('ellipse', { cx: 180, cy: 140, rx: 28, ry: 12, fill: FK.alpha(BK.ramp(5).c, .3) }, g); const k = Math.min(1, u * 1.5); E('path', { d: `M${250 - 60 * k} ${40 + 70 * k}l60 -50`, stroke: '#666', 'stroke-width': 2.4 }, g); for (let i = 0; i < 5; i++) E('circle', { cx: 168 + i * 6, cy: 138 + (i % 2) * 4, r: 3, fill: Rb.c, stroke: Rb.dk }, g); if (u > .6) E('rect', { x: 150, y: 124 - 30 * (1 - (u - .6) / .4), width: 60, height: 32, fill: FK.alpha('#cfe6ff', .5), stroke: '#7a8a9a' }, g); tag('পানি/গ্লিসারিনে রেণুস্থলী, কভারস্লিপ', BK.ramp(5).ink); }
    if (s === 3) { E('ellipse', { cx: 180, cy: 140, rx: 46, ry: 40, fill: '#f3e7c4', stroke: '#b59a5a', 'stroke-width': 1.5 }, g); E('circle', { cx: 180, cy: 140, r: 9, fill: '#7a5a30' }, g); const bx = 120 + 120 * u; E('path', { d: `M${bx - 40} 98L${bx + 40} 98L${bx + 40} 92L${bx - 40} 92Z`, fill: '#c9ced6', stroke: '#6a7280' }, g); for (let i = 0; i < Math.floor(u * 5); i++) E('ellipse', { cx: 280 + i * 4, cy: 190 - i * 3, rx: 9, ry: 7, fill: FK.alpha('#f3e7c4', .9), stroke: '#7a5a30', 'stroke-width': .8 }, g); tag('আলুর মাঝে পত্রাক্ষ — পাতলা আড়াআড়ি ছেদ', C.fg); }
    if (s === 4) { E('ellipse', { cx: 120, cy: 150, rx: 60, ry: 20, fill: FK.alpha(Rr.c, .25 + .5 * u), stroke: '#777' }, g); E('path', { d: `M120 ${60 + 40 * u}v-40`, stroke: '#888', 'stroke-width': 6, 'stroke-linecap': 'round' }, g); E('circle', { cx: 120, cy: 64 + 40 * u, r: 3, fill: Rr.c }, g); E('circle', { cx: 120, cy: 150, r: 9, fill: 'none', stroke: Rr.dk, 'stroke-width': 3 }, g); E('rect', { x: 210, y: 130, width: 120, height: 40, rx: 3, fill: glass, stroke: '#7a8a9a' }, g); if (u > .5) { E('circle', { cx: 270, cy: 150, r: 9, fill: 'none', stroke: Rr.dk, 'stroke-width': 3 }, g); E('rect', { x: 248, y: 132, width: 44, height: 36, fill: FK.alpha('#cfe6ff', .5), stroke: '#7a8a9a' }, g); } tag('স্যাফ্রানিন → ধোয়া → গ্লিসারিন → কভারস্লিপ', Rr.ink); }
    if (s === 5) { E('path', { d: 'M70 210h80M100 210V100l30 -40M96 100h20', stroke: '#555', 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, g); E('rect', { x: 120, y: 44, width: 16, height: 30, fill: '#777', transform: 'rotate(35 128 59)' }, g); E('path', { d: 'M80 150h60', stroke: '#555', 'stroke-width': 4 }, g); const mag = u > .5; E('circle', { cx: 260, cy: 118, r: 70, fill: '#fffbe9', stroke: '#444', 'stroke-width': 3 }, g);
      if (!mag) { E('ellipse', { cx: 260, cy: 118, rx: 40, ry: 38, fill: '#f5ecd6', stroke: '#9a1a3a', 'stroke-width': 5 }, g); E('path', { d: 'M244 104C240 126 249 140 260 140C271 140 280 126 276 104', stroke: '#5fae6a', 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d: 'M244 104C240 126 249 140 260 140C271 140 280 126 276 104', stroke: '#c21f4a', 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round' }, g); }
      else { E('path', { d: 'M206 84C200 150 230 176 260 176C290 176 320 150 314 84', stroke: '#c21f4a', 'stroke-width': 30, fill: 'none', opacity: .25 }, g); E('path', { d: 'M206 84C200 150 230 176 260 176C290 176 320 150 314 84', stroke: '#5fae6a', 'stroke-width': 22, fill: 'none' }, g); E('path', { d: 'M206 84C200 150 230 176 260 176C290 176 320 150 314 84', stroke: '#c21f4a', 'stroke-width': 8, fill: 'none' }, g); for (let k = 0; k <= 10; k++) { const t = k / 10, x = (1 - t) ** 3 * 206 + 3 * (1 - t) ** 2 * t * 200 + 3 * (1 - t) * t * t * 230 + t ** 3 * 260, y = (1 - t) ** 3 * 84 + 3 * (1 - t) ** 2 * t * 150 + 3 * (1 - t) * t * t * 176 + t ** 3 * 176; [x, 520 - x].forEach(xx => E('circle', { cx: xx.toFixed(1), cy: y.toFixed(1), r: 3, fill: '#fff', stroke: '#9a1a3a', 'stroke-width': .8 }, g)); } }
      T(g, 260, 206, mag ? '40× — মেরিস্টিলি (জাইলেম লাল, ফ্লোয়েম সবুজ)' : '10× — পুরো ছেদ', { fs: 10.5, a: 'middle', w: 600, c: C.mu }); tag('কম থেকে বেশি বিবর্ধনে দেখো, তারপর আঁকো', C.fg); }
  }
}));

/* ───────── রঞ্জনের প্রভাব ───────── */
const SX = 150, SY = 136;
const sOut = `M${SX - 22} ${SY - 92}C${SX - 62} ${SY - 92} ${SX - 100} ${SY - 54} ${SX - 100} ${SY}C${SX - 100} ${SY + 58} ${SX - 54} ${SY + 96} ${SX} ${SY + 96}C${SX + 54} ${SY + 96} ${SX + 100} ${SY + 58} ${SX + 100} ${SY}C${SX + 100} ${SY - 54} ${SX + 62} ${SY - 92} ${SX + 22} ${SY - 92}C${SX + 12} ${SY - 92} ${SX + 9} ${SY - 78} ${SX} ${SY - 78}C${SX - 9} ${SY - 78} ${SX - 12} ${SY - 92} ${SX - 22} ${SY - 92}Z`;
const sU = `M${SX - 40} ${SY - 30}C${SX - 52} ${SY + 9} ${SX - 36} ${SY + 46} ${SX} ${SY + 48}C${SX + 36} ${SY + 46} ${SX + 52} ${SY + 9} ${SX + 40} ${SY - 30}`;
const ST = {
  raw: ['রঞ্জনহীন', 'রঞ্জন ছাড়া ছেদ প্রায় বর্ণহীন — কেবল ফার্নের হাইপোডার্মিস প্রাকৃতিকভাবে বাদামি; জাইলেম আর ফ্লোয়েম আলাদা করে চেনা কঠিন।'],
  saf: ['স্যাফ্রানিন', 'স্যাফ্রানিন লিগনিনযুক্ত প্রাচীরকে গাঢ় লাল করে — জাইলেমের ট্র্যাকিড, স্ক্লেরেনকাইমা ও এন্ডোডার্মিসের ক্যাসপেরিয়ান ফিতা স্পষ্ট লাল; অন্য কোষ হালকা গোলাপি।'],
  dbl: ['দ্বি-রঞ্জন', 'স্যাফ্রানিনের পর ফাস্ট গ্রিন: লিগনিনযুক্ত অংশ লাল, আর সেলুলোজ প্রাচীরের কোষ (প্যারেনকাইমা, ফ্লোয়েম, পেরিসাইকল) সবুজ — কলাগুলো পাশাপাশি সবচেয়ে ভালো আলাদা করা যায়।']
};
V.rachisStain = {
  t: 'রঞ্জনের প্রভাব — Pteris এর পত্রাক্ষের প্রস্থচ্ছেদ', k: ['2d', 'anim', 'int'],
  cap: 'একই ছেদ তিনভাবে: রঞ্জনহীন, স্যাফ্রানিন ও স্যাফ্রানিন-ফাস্ট গ্রিন দ্বি-রঞ্জন। চালু করলে রং ধীরে চড়ে। 40× এ মেরিস্টিলির কাছাকাছি দৃশ্য। (রং প্রতীকী — প্রকৃত ছায়া রঞ্জকের মাত্রা ও সময়ভেদে ভিন্ন।)',
  html: () => `<div class="fk-row">${X.seg('stn', Object.keys(ST).map(k => [k, ST[k][0]]), 'dbl')}</div><div class="fk-row">${X.seg('mag', [['10', '10×'], ['40', '40×']], '10')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 290;
    let stn = 'dbl', mag = '10', C, svg, el = {}, k = 1; const kk = () => k;
    const mix = (a, b, t) => { const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
    const COL = () => {
      const k = Math.min(1, kk());
      const pale = '#efe8d8', red = '#c21f4a', pink = '#f2c6d2', green = '#5fae6a', brown = '#8a6a3a';
      if (stn === 'raw') return { lig: '#d9cfb8', hyp: brown, par: pale, phl: '#e8e2cf', end: '#d6ccb4' };
      if (stn === 'saf') return { lig: mix('#d9cfb8', red, k), hyp: mix(brown, '#9a1a3a', k), par: mix(pale, pink, k), phl: mix('#e8e2cf', pink, k), end: mix('#d6ccb4', red, k * .9) };
      return { lig: mix('#d9cfb8', red, k), hyp: mix(brown, '#9a1a3a', k), par: mix(pale, '#cfe8c8', k), phl: mix('#e8e2cf', green, k), end: mix('#d6ccb4', red, k * .9) };
    };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'রঞ্জনের প্রভাব' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      E('defs', {}, svg).innerHTML = `<clipPath id="stnclip"><circle cx="${SX}" cy="${SY - 6}" r="118"/></clipPath>`;
      E('circle', { cx: SX, cy: SY - 6, r: 118, fill: '#fffbea', stroke: '#444', 'stroke-width': 3 }, svg);
      const z = mag === '40' ? 2.4 : 1, g = E('g', { 'clip-path': 'url(#stnclip)' }, svg), gg = E('g', { transform: `translate(${SX} ${SY - 6}) scale(${z * .9}) translate(${-SX} ${-(mag === '40' ? SY + 40 : SY - 6)})` }, g);
      el.ep = E('path', { d: sOut, stroke: '#6b4a2a', 'stroke-width': 2.4 }, gg);
      el.hyp = E('path', { d: sOut, fill: 'none', 'stroke-width': 20, transform: `translate(${SX} ${SY}) scale(.93) translate(${-SX} ${-SY})` }, gg);
      el.par = E('path', { d: sOut, stroke: 'none', transform: `translate(${SX} ${SY}) scale(.84) translate(${-SX} ${-SY})` }, gg);
      el.cells = E('g', {}, gg); for (let i = 0; i < 120; i++) { const a = i * 2.39996, r = Math.sqrt(i / 120) * 78; E('circle', { cx: (SX + r * Math.cos(a)).toFixed(1), cy: (SY + 4 + r * .95 * Math.sin(a)).toFixed(1), r: 3.8, fill: 'none', 'stroke-width': .7 }, el.cells); }
      el.end = E('path', { d: sU, 'stroke-width': 28, fill: 'none', 'stroke-linecap': 'round' }, gg);
      el.per = E('path', { d: sU, 'stroke-width': 23, fill: 'none', 'stroke-linecap': 'round' }, gg);
      el.phl = E('path', { d: sU, 'stroke-width': 17, fill: 'none', 'stroke-linecap': 'round' }, gg);
      el.xyl = E('path', { d: sU, 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, gg);
      el.tr = E('g', {}, gg); for (let i = 0; i <= 16; i++) { const t = i / 16, x = (1 - t) ** 3 * (SX - 40) + 3 * (1 - t) ** 2 * t * (SX - 52) + 3 * (1 - t) * t * t * (SX - 36) + t ** 3 * SX, y = (1 - t) ** 3 * (SY - 30) + 3 * (1 - t) ** 2 * t * (SY + 9) + 3 * (1 - t) * t * t * (SY + 46) + t ** 3 * (SY + 48); [x, 2 * SX - x].forEach(xx => E('circle', { cx: xx.toFixed(1), cy: y.toFixed(1), r: 2.2, fill: '#fff', 'stroke-width': .8 }, el.tr)); }
      el.lg = [0, 1, 2].map(i => { const x = 16 + i * 116, y = 276; E('rect', { x, y: y - 11, width: 14, height: 14, rx: 3, stroke: C.ln }, svg); return [svg.lastChild, T(svg, x + 19, y, '', { fs: 10.5, w: 600, c: C.fg })]; });
      $('info').innerHTML = `<b>${ST[stn][0]}</b> — ${ST[stn][1]}`;
      paint();
    };
    const paint = () => {
      const c = COL();
      FK.at(el.ep, { fill: c.par }); FK.at(el.hyp, { stroke: c.hyp }); FK.at(el.par, { fill: c.par });
      el.cells.setAttribute('stroke', mix(c.par.length === 7 ? c.par : '#efe8d8', '#7a6a4a', .35));
      FK.at(el.end, { stroke: c.end }); FK.at(el.per, { stroke: c.par }); FK.at(el.phl, { stroke: c.phl }); FK.at(el.xyl, { stroke: c.lig }); el.tr.setAttribute('stroke', c.lig);
      [['লিগনিন (জাইলেম)', c.lig], ['স্ক্লেরেনকাইমা', c.hyp], ['সেলুলোজ কোষ', c.phl]].forEach(([t, col], i) => { el.lg[i][0].setAttribute('fill', col); el.lg[i][1].textContent = t; });
    };
    const A = X.anim(root, dt => { if (stn === 'raw') return; k += dt * .35; if (k > 1.8) k = 0; paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'stn', v => { stn = v; k = 1; base(); });
    X.onSeg(root, 'mag', v => { mag = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

V.b1c6map = Object.assign({ t: 'অধ্যায় ৬ এর মানচিত্র', k: ['mind', 'int'], cap: 'ব্রায়োফাইটা, টেরিডোফাইটা ও ব্যবহারিক — এক নজরে। শাখায় চাপলে বিস্তারিত ও পাঠে যাওয়ার বোতাম।' }, BK.mind({
  t: 'ব্রায়োফাইটা ও টেরিডোফাইটা', d: 'অপুষ্পক স্থলজ উদ্ভিদ — নিষেকে পানি লাগে, বীজ নেই।',
  c: [
    { t: 'ব্রায়োফাইটা', d: 'অভাস্কুলার; গ্যামিটোফাইট প্রধান।', id: 'b1c6s1a', c: [{ t: 'বৈশিষ্ট্য', d: 'রাইজয়েড; বহুকোষী আবৃত যৌনাঙ্গ; দুই-ফ্ল্যাজেলাযুক্ত শুক্রাণু; নির্ভরশীল স্পোরোফাইট।', id: 'b1c6s1b' }, { t: 'Riccia', d: 'দ্বিবিভাজিত থ্যালাস; আত্তীকরণ সূত্র ও সঞ্চয়ী অঞ্চল; স্পোরোফাইট কেবল ক্যাপসুল।', id: 'b1c6s1c' }] },
    { t: 'টেরিডোফাইটা', d: 'বীজহীন ভাস্কুলার; স্পোরোফাইট প্রধান।', id: 'b1c6s2a', c: [{ t: 'Pteris', d: 'রাইজোম, রামেন্টা, যৌগিক পাতা, প্রান্তীয় সোরাস ও অপ্রকৃত ইনডুসিয়াম।', id: 'b1c6s2b' }, { t: 'অন্তর্গঠন', d: 'রাইজোমে ডিকটিওস্টিলি; পত্রাক্ষে অশ্বখুরাকৃতি মেরিস্টিলি; কনসেন্ট্রিক অ্যাম্ফিক্রিবাল বান্ডল।', id: 'b1c6s2c' }, { t: 'জীবনচক্র', d: 'স্পোরোফাইট → স্পোর → প্রোথ্যালাস → গ্যামিট → জাইগোট; বিষমরূপী জনুঃক্রম।', id: 'b1c6s2d' }, { t: 'পার্থক্য', d: 'ব্রায়োফাইট বনাম টেরিডোফাইট।', id: 'b1c6s2e' }] },
    { t: 'ব্যবহারিক', d: 'Pteris এর স্পোরোফাইট পর্যবেক্ষণ।', id: 'b1c6s3a', c: [{ t: 'ধাপ', d: 'বাহ্যিক গঠন → সোরাস → রেণুস্থলী → পত্রাক্ষের ছেদ, রঞ্জন ও চিত্রাঙ্কন।' }] },
    { t: 'পুনরালোচনা', d: 'সারসংক্ষেপ, দক্ষতা, পার্থক্য, অনুশীলনী।', id: 'b1c6s4a' }
  ]
}));
})();
