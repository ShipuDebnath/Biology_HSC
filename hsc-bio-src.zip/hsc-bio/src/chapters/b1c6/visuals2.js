/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৬.২ টেরিডোফাইটা ও Pteris
   pteridoClass : টেরিডোফাইটার শ্রেণিবিভাগ — গাছ
   pteridoTraits: টেরিডোফাইটার বৈশিষ্ট্য ও গুরুত্ব — মাইন্ড ম্যাপ
   pterisPlant  : Pteris এর স্পোরোফাইট — চিহ্নিত চিত্র (কুণ্ডলিত কচিপাতা খোলে, স্পোর ঝরে)
   pterisSorus  : পত্রকের কিনারায় সোরাস — অপ্রকৃত ইনডুসিয়াম, রেণুস্থলী (রেণুস্থলী ফাটে)
   sporangium   : রেণুস্থলী ফেটে স্পোর ছড়ানো — অ্যানুলাসের ক্রিয়া ধাপে ধাপে
   rhizomeTS    : রাইজোমের প্রস্থচ্ছেদ — ডিকটিওস্টিলি, কনসেন্ট্রিক বান্ডল
   rachisTS     : পত্রাক্ষের প্রস্থচ্ছেদ — অশ্বখুরাকৃতি মেরিস্টিলি
   prothallus   : প্রোথ্যালাস — চিহ্নিত চিত্র (বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু সাঁতরায়)
   pterisCycle  : Pteris এর জীবনচক্র — ধাপে ধাপে
   cmpBryoPterido: ব্রায়োফাইট বনাম টেরিডোফাইট — তুলনা ও কুইজ
   জীববৈজ্ঞানিক নোট: Pteris সমরেণু (homosporous); সোরাস প্রান্তীয়, রৈখিক ও অবিচ্ছিন্ন, পত্রকের বাঁকানো
   কিনারা (অপ্রকৃত ইনডুসিয়াম) দিয়ে ঢাকা; রেণুস্থলীর অ্যানুলাস খাড়া ও অসম্পূর্ণ; শুক্রাণু বহু-ফ্ল্যাজেলাযুক্ত।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B6 = window.B6;

V.pteridoClass = Object.assign({ t: 'টেরিডোফাইটার শ্রেণিবিভাগ', k: ['tree', 'int'], cap: 'প্রচলিত শ্রেণিবিন্যাসে চারটি শ্রেণি। আধুনিক আণবিক গবেষণায় লাইকোফাইট (Lycopsida) একটি আলাদা দল, আর বাকিরা — ফার্ন, Equisetum ও Psilotum — মিলে মনিলোফাইট বা ফার্ন দল।' }, BK.tree({
  t: 'টেরিডোফাইটা', d: 'বীজহীন ভাস্কুলার উদ্ভিদ; স্পোরোফাইট প্রধান; প্রায় 12 হাজার প্রজাতি।',
  c: [
    { t: 'সাইলোপসিডা', d: 'Psilopsida — প্রকৃত মূল ও পাতা নেই; দ্বিবিভাজিত সবুজ কাণ্ড ও রাইজোম; সবচেয়ে সরল জীবিত ভাস্কুলার উদ্ভিদ।', c: [{ t: 'উদাহরণ', d: 'Psilotum, Tmesipteris; জীবাশ্ম Rhynia।' }] },
    { t: 'লাইকোপসিডা', d: 'Lycopsida — ছোট একশিরাযুক্ত পাতা (মাইক্রোফিল); রেণুপত্র শঙ্কুতে (স্ট্রোবিলাস); কেউ কেউ বিষমরেণু।', c: [{ t: 'উদাহরণ', d: 'Lycopodium (সমরেণু), Selaginella (বিষমরেণু), Isoetes।' }] },
    { t: 'স্ফেনোপসিডা', d: 'Sphenopsida — পর্ব ও পর্বমধ্যযুক্ত খাঁজকাটা কাণ্ড; পর্বে আবর্তে ছোট শল্কপাতা; কাণ্ডে সিলিকা।', c: [{ t: 'উদাহরণ', d: 'Equisetum (হর্সটেইল)।' }] },
    { t: 'টেরোপসিডা (ফার্ন)', d: 'Pteropsida বা Filicopsida — বড় বহুশিরাযুক্ত যৌগিক পাতা (মেগাফিল, ফ্রন্ড); কচিপাতা কুণ্ডলিত; সোরাসে রেণুস্থলী।', c: [{ t: 'উদাহরণ', d: 'Pteris, Dryopteris, Diplazium (ঢেঁকি শাক); জলজ বিষমরেণু Marsilea (শুষনি শাক), Azolla।' }] }
  ]
}, { colW: 120 }));

V.pteridoTraits = Object.assign({ t: 'টেরিডোফাইটার বৈশিষ্ট্য ও গুরুত্ব', k: ['mind', 'int'], cap: 'প্রথম ভাস্কুলার উদ্ভিদ — মূল, কাণ্ড ও পাতায় বিভক্ত স্পোরোফাইট; কিন্তু বীজ ও ফুল নেই, নিষেকে এখনো পানি লাগে। শাখায় চাপ দাও।' }, BK.mind({
  t: 'টেরিডোফাইটা', d: 'বীজহীন ভাস্কুলার উদ্ভিদ — "সরীসৃপ উদ্ভিদ" নয়, ফার্নবর্গীয় উদ্ভিদ।',
  c: [
    { t: 'দেহ (স্পোরোফাইট)', d: 'প্রধান জনু, ডিপ্লয়েড।', c: [{ t: 'মূল, কাণ্ড, পাতা', d: 'প্রকৃত অস্থানিক মূল; কাণ্ড প্রায়ই মাটির নিচে রাইজোম; পাতা ছোট (মাইক্রোফিল) বা বড় যৌগিক (মেগাফিল)।' }, { t: 'ভাস্কুলার টিস্যু', d: 'জাইলেমে প্রধানত ট্র্যাকিড (ভেসেল সাধারণত নেই), ফ্লোয়েমে সিভ কোষ (সঙ্গীকোষ নেই)।' }, { t: 'কুণ্ডলিত পত্রবিন্যাস', d: 'ফার্নের কচিপাতা গুটানো থাকে (circinate vernation), পরে খোলে।' }] },
    { t: 'জনন', d: 'স্পোর দিয়ে বিস্তার।', c: [{ t: 'রেণুস্থলী ও সোরাস', d: 'রেণুপত্রের নিচে বা কিনারায় রেণুস্থলীর গুচ্ছ (সোরাস); অনেকে ইনডুসিয়াম দিয়ে ঢাকা।' }, { t: 'সমরেণু ও বিষমরেণু', d: 'অধিকাংশ সমরেণু (Pteris, Lycopodium); কিছু বিষমরেণু — ক্ষুদ্ররেণু ও বৃহৎরেণু (Selaginella, Marsilea, Azolla) — বীজ অভ্যাসের পূর্বধাপ।' }, { t: 'প্রোথ্যালাস', d: 'স্পোর থেকে ছোট স্বাধীন সবুজ গ্যামিটোফাইট; পুংধানী ও স্ত্রীধানী বহন করে।' }, { t: 'বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু', d: 'পানিতে সাঁতরে স্ত্রীধানীতে যায় — নিষেকে পানি অপরিহার্য।' }] },
    { t: 'জনুঃক্রম', d: 'বিষমরূপী।', c: [{ t: 'স্পোরোফাইট প্রধান', d: 'বড়, দীর্ঘস্থায়ী, স্বাধীন (2n)।' }, { t: 'গ্যামিটোফাইট স্বাধীন কিন্তু ক্ষুদ্র', d: 'প্রোথ্যালাস (n) কয়েক মিলিমিটার, স্বল্পস্থায়ী।' }] },
    { t: 'গুরুত্ব', d: 'অতীত ও বর্তমান।', c: [{ t: 'কয়লা', d: 'কার্বনিফেরাস যুগের (প্রায় 36–30 কোটি বছর আগে) বৃক্ষসদৃশ লাইকোপসিড ও ফার্নের দেহাবশেষ থেকে কয়লা।' }, { t: 'জৈবসার', d: 'Azolla র ভেতরের সায়ানোব্যাকটেরিয়া (Anabaena azollae) নাইট্রোজেন সংবন্ধন করে — ধানক্ষেতে সবুজ সার।' }, { t: 'খাদ্য ও শোভা', d: 'ঢেঁকি শাক (Diplazium esculentum), শুষনি শাক (Marsilea); বাগানে শোভাবর্ধক ফার্ন।' }, { t: 'আর্সেনিক অপসারণ', d: 'Pteris vittata মাটি ও পানি থেকে বিপুল আর্সেনিক শোষণ করে পাতায় জমায় — ফাইটোরেমিডিয়েশন গবেষণায় ব্যবহৃত।' }] }
  ]
}));

/* ───────── Pteris উদ্ভিদ ───────── */
const qpt = (p0, p1, p2, t) => [(1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]];
const FR = [{ p0: [130, 258], p1: [96, 150], p2: [112, 34], fert: false, side: -1 }, { p0: [205, 258], p1: [222, 160], p2: [250, 46], fert: true, side: 1 }];
const frondPinnae = f => { const P = []; for (let i = 0; i < 9; i++) { const t = .3 + i * .078, [x, y] = qpt(f.p0, f.p1, f.p2, t), L = 50 - i * 3.6; [-1, 1].forEach(sd => P.push({ x, y, ex: x + sd * L, ey: y - L * .22, sd })); } const [x, y] = qpt(f.p0, f.p1, f.p2, 1); P.push({ x, y, ex: x + (f.p2[0] - f.p1[0]) * .2, ey: y - 24, sd: 0 }); return P; };
const leafPath = (x, y, ex, ey, w) => { const dx = ex - x, dy = ey - y, L = Math.hypot(dx, dy), nx = -dy / L * w, ny = dx / L * w; return `M${x.toFixed(1)} ${y.toFixed(1)}Q${(x + dx * .5 + nx).toFixed(1)} ${(y + dy * .5 + ny).toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}Q${(x + dx * .5 - nx).toFixed(1)} ${(y + dy * .5 - ny).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)}Z`; };
const FP = FR.map(frondPinnae);
V.pterisPlant = Object.assign({
  t: 'Pteris এর স্পোরোফাইট (বাহ্যিক গঠন)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'Pteris এর প্রধান উদ্ভিদদেহ ডিপ্লয়েড স্পোরোফাইট — মাটির নিচে শল্কে (রামেন্টা) ঢাকা রাইজোম, তা থেকে অস্থানিক মূল ও উপরে একপক্ষল যৌগিক পাতা (ফ্রন্ড)। উর্বর পত্রকের কিনারা বরাবর লম্বা অবিচ্ছিন্ন সোরাস। কচিপাতা কুণ্ডলিত থাকে — চালু করলে খুলতে দেখা যাবে।'
}, BK.diagram({
  W: 360, H: 340, label: 'Pteris স্পোরোফাইট',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rb = BK.ramp(6), soil = '#8a6b3a';
    E('rect', { x: 8, y: 256, width: 344, height: 78, rx: 8, fill: FK.alpha(soil, .16) }, g); E('path', { d: 'M8 256H352', stroke: soil, 'stroke-width': 1.6, opacity: .6 }, g);
    const rt = P('root'); for (let i = 0; i < 10; i++) { const x = 70 + i * 24, b = (i % 2 ? 8 : -8); E('path', { d: `M${x} 268q${b} 24 ${b * .4} ${42 + (i % 3) * 8}M${x + b * .4} 300l${b * .7} 10`, stroke: '#6b5233', 'stroke-width': 1.4, fill: 'none' }, rt); }
    const rz = P('rhizome'); E('path', { d: 'M54 262C120 256 240 268 300 260', stroke: '#6b4a2a', 'stroke-width': 13, 'stroke-linecap': 'round', fill: 'none' }, rz);
    const rm = P('ramenta'); for (let x = 60; x < 300; x += 7) { const y = 262 + 3 * Math.sin(x / 30); E('path', { d: `M${x} ${y - 5}l${-3} ${-6}M${x + 2} ${y + 5}l${-2} 6`, stroke: '#b07a40', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, rm); }
    FR.forEach((f, k) => {
      const pt = P(k ? 'petiole2' : 'petiole'); let d = ''; for (let j = 0; j <= 10; j++) { const [x, y] = qpt(f.p0, f.p1, f.p2, j * .03); d += (j ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } E('path', { d, stroke: '#6b5233', 'stroke-width': 3.4, fill: 'none' }, pt);
      const rc = P(k ? 'rachis2' : 'rachis'); d = ''; for (let j = 10; j <= 34; j++) { const [x, y] = qpt(f.p0, f.p1, f.p2, j / 34); d += (j > 10 ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } E('path', { d, stroke: R.dk, 'stroke-width': 2.4, fill: 'none' }, rc);
      const pn = P(k ? 'sorus' : 'pinna'); FP[k].forEach(p => { E('path', { d: leafPath(p.x, p.y, p.ex, p.ey, 4.2), fill: R.c, stroke: R.dk, 'stroke-width': .7 }, pn); if (f.fert) { const dx = p.ex - p.x, dy = p.ey - p.y, L = Math.hypot(dx, dy) || 1; [-1, 1].forEach(sd => E('path', { d: `M${(p.x + dx * .15 - dy / L * 2.4 * sd).toFixed(1)} ${(p.y + dy * .15 + dx / L * 2.4 * sd).toFixed(1)}Q${(p.x + dx * .5 - dy / L * 3.8 * sd).toFixed(1)} ${(p.y + dy * .5 + dx / L * 3.8 * sd).toFixed(1)} ${(p.x + dx * .9 - dy / L * 1 * sd).toFixed(1)} ${(p.y + dy * .9 + dx / L * 1 * sd).toFixed(1)}`, stroke: Rb.dk, 'stroke-width': 1.8, fill: 'none' }, pn)); } });
    });
    const cz = P('crozier'); E('path', { d: 'M286 258Q290 230 296 206', stroke: FK.alpha(R.dk, .6), 'stroke-width': 3.2, fill: 'none' }, cz); E('circle', { cx: 300, cy: 186, r: 16, fill: 'transparent' }, cz);
  },
  idle(g, C, t) {
    const R = BK.ramp(10), Rb = BK.ramp(6);
    const k = .5 + .5 * Math.sin(t * .5), turns = 2.2 * (1 - k) + .25; let d = 'M296 206', px = 296, py = 206, a = -Math.PI / 2 + .2; const seg = 26; for (let j = 0; j < seg; j++) { const L = 70 / seg * (1 - j / seg * .4); a += turns * 2 * Math.PI / seg * (j / seg) * 2; px += L * Math.cos(a); py += L * Math.sin(a); d += `L${px.toFixed(1)} ${py.toFixed(1)}`; }
    E('path', { d, stroke: R.c, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d, stroke: '#b07a40', 'stroke-width': 1, fill: 'none', 'stroke-dasharray': '1 4', opacity: .8 }, g);
    for (let i = 0; i < 8; i++) { const p = FP[1][(i * 3) % FP[1].length], f = (t * .3 + i / 8) % 1; E('circle', { cx: (p.ex + (p.x - p.ex) * .5 + 10 * Math.sin(t + i) * f).toFixed(1), cy: (p.ey + 4 + f * 70).toFixed(1), r: 1.5, fill: Rb.c, opacity: 1 - f }, g); }
  },
  parts: [
    { id: 'rachis', bn: 'পত্রাক্ষ (র‍্যাকিস)', lb: 'পত্রাক্ষ', en: 'Rachis', fn: 'যৌগিক পাতার মাঝের অক্ষ — পত্রবৃন্তের উপরের অংশ; দুই পাশে পত্রক বহন করে।', a: [qpt(FR[0].p0, FR[0].p1, FR[0].p2, .62)[0], qpt(FR[0].p0, FR[0].p1, FR[0].p2, .62)[1]], l: [26, 120], an: 'middle' },
    { id: 'pinna', bn: 'পত্রক (পিনা) — বন্ধ্যা', lb: 'পত্রক', en: 'Pinna (sterile)', fn: 'যৌগিক পাতার প্রতিটি লম্বা সরু অংশ; সবুজ, সালোকসংশ্লেষণ করে। বন্ধ্যা পত্রকে সোরাস নেই।', a: [FP[0][4].ex + 10, FP[0][4].ey + 1], l: [26, 66], an: 'middle' },
    { id: 'petiole', bn: 'পত্রবৃন্ত', en: 'Petiole', fn: 'রাইজোম থেকে উঠে আসা পাতার বোঁটা — গোড়ায় শল্ক থাকে; উপরে পত্রাক্ষে মিশে যায়।', a: [qpt(FR[0].p0, FR[0].p1, FR[0].p2, .18)[0], qpt(FR[0].p0, FR[0].p1, FR[0].p2, .18)[1]], l: [30, 220], an: 'middle' },
    { id: 'sorus', bn: 'সোরাস (উর্বর পত্রকের কিনারায়)', lb: 'প্রান্তীয় সোরাস', en: 'Marginal sorus', fn: 'রেণুপত্রের (উর্বর পত্রকের) নিচের দিকে কিনারা বরাবর লম্বা, অবিচ্ছিন্ন রেখার মতো রেণুস্থলীর গুচ্ছ — পত্রকের বাঁকানো কিনারা (অপ্রকৃত ইনডুসিয়াম) দিয়ে ঢাকা।', a: [FP[1][9].ex - 8, FP[1][9].ey + 3], l: [330, 92], an: 'middle' },
    { id: 'crozier', bn: 'কুণ্ডলিত কচিপাতা (ক্রোজিয়ার)', lb: 'কুণ্ডলিত কচিপাতা', en: 'Circinate young leaf', fn: 'কচিপাতা আগা থেকে গুটানো থাকে (circinate vernation) — নরম শীর্ষ রক্ষা পায়; বাড়তে বাড়তে নিচ থেকে উপরে খোলে। ফার্নের বৈশিষ্ট্য।', a: [298, 200], l: [318, 152], an: 'middle' },
    { id: 'ramenta', bn: 'রামেন্টা (বাদামি শল্ক)', lb: 'রামেন্টা', en: 'Ramenta', fn: 'রাইজোম ও পত্রবৃন্তের গোড়ায় বাদামি, পাতলা, এক স্তরের শল্ক ও রোম — কচি অংশকে রক্ষা করে।', a: [244, 258], l: [300, 290], an: 'middle' },
    { id: 'rhizome', bn: 'রাইজোম (ভূনিম্নস্থ কাণ্ড)', lb: 'রাইজোম', en: 'Rhizome', fn: 'মাটির নিচে আনুভূমিক, ছোট, শাখান্বিত কাণ্ড — খাদ্য সঞ্চয় করে, উপরে পাতা ও নিচে মূল দেয়; প্রস্থচ্ছেদে ডিকটিওস্টিলি।', a: [100, 262], l: [44, 292], an: 'middle' },
    { id: 'root', bn: 'অস্থানিক মূল', en: 'Adventitious roots', fn: 'রাইজোমের নিচ থেকে সরু, শাখান্বিত অস্থানিক মূল — মাটিতে আটকে রাখে, পানি ও খনিজ শোষণ করে। প্রাথমিক মূল দ্রুত নষ্ট হয়ে যায়।', a: [166, 308], l: [170, 330], an: 'middle' }
  ]
}));

/* ───────── সোরাস ───────── */
const SG = [{ a: 2.1, L: 54 }, { a: 1.75, L: 62 }, { a: 1.4, L: 66 }, { a: 1.05, L: 60 }, { a: .75, L: 46 }];
const SX = 214, SY = 116;
const spPos = sp => [SX + sp.L * Math.cos(sp.a), SY + sp.L * Math.sin(sp.a)];
V.pterisSorus = Object.assign({
  t: 'Pteris এর সোরাস (পত্রকের কিনারার প্রস্থচ্ছেদ)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'পত্রকের কিনারা নিচের দিকে বেঁকে অপ্রকৃত ইনডুসিয়াম তৈরি করে। এর নিচে কিনারা বরাবর একটি শিরা-সংযোগ (ভাস্কুলার কমিশার) থেকে নানা বয়সের বৃন্তযুক্ত রেণুস্থলী ও সরু প্যারাফাইসিস বের হয় — সোরাস অবিচ্ছিন্ন (সিনোসোরাস)। চালু করলে একটি পরিণত রেণুস্থলী ফেটে স্পোর ছড়ায়।'
}, BK.diagram({
  W: 360, H: 290, label: 'Pteris সোরাস',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rb = BK.ramp(6), Rv = BK.ramp(9);
    const lm = P('lamina'); E('path', { d: 'M14 80H232C262 80 282 100 280 132C278 164 258 186 236 190L232 180C250 174 262 156 262 132C262 108 248 102 230 102H14Z', fill: R.c, stroke: R.dk, 'stroke-width': 1.2 }, lm);
    for (let x = 22; x < 226; x += 9) E('ellipse', { cx: x, cy: 91, rx: 3.6, ry: 6, fill: FK.alpha(R.lt, .6) }, lm);
    E('path', { d: 'M14 80H232M14 102H230', stroke: FK.alpha(R.dk, .8), 'stroke-width': 1.4 }, lm);
    const ind = P('indusium'); E('path', { d: 'M262 120C262 156 250 174 232 180L236 190C258 186 278 164 280 132C280 126 279 122 278 118Z', fill: FK.alpha(R.lt, .9), stroke: R.dk, 'stroke-width': 1.6 }, ind);
    const vc = P('commissure'); E('circle', { cx: SX, cy: SY - 6, r: 9, fill: FK.alpha(Rv.lt, .8), stroke: Rv.dk, 'stroke-width': 1.4 }, vc); E('circle', { cx: SX, cy: SY - 6, r: 4, fill: BK.ramp(4).c }, vc);
    const ph = P('paraphysis'); [1.92, 1.57, 1.22, .9].forEach(a => { let d = `M${SX} ${SY}`; for (let j = 1; j <= 5; j++) { const L = j * 10; d += `L${(SX + L * Math.cos(a) + 2 * Math.sin(j)).toFixed(1)} ${(SY + L * Math.sin(a)).toFixed(1)}`; } E('path', { d, stroke: R.dk, 'stroke-width': 1, fill: 'none' }, ph); });
    const st = P('stalk'), sp = P('sporang'), an = P('annulus');
    SG.forEach((s, i) => { const [x, y] = spPos(s); E('path', { d: `M${SX} ${SY}L${(SX + (s.L - 12) * Math.cos(s.a)).toFixed(1)} ${(SY + (s.L - 12) * Math.sin(s.a)).toFixed(1)}`, stroke: Rb.dk, 'stroke-width': 2.4 }, st); const r = i === 4 ? 8 : 12; E('ellipse', { cx: x, cy: y, rx: r * .8, ry: r, fill: FK.alpha(Rb.lt, .9), stroke: Rb.dk, 'stroke-width': 1, transform: `rotate(${(s.a * 180 / Math.PI - 90).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})` }, sp); if (i !== 4) { for (let k = 0; k < 5; k++) E('circle', { cx: (x + 3 * Math.cos(k * 1.3)).toFixed(1), cy: (y + 4 * Math.sin(k * 1.3)).toFixed(1), r: 1.3, fill: Rb.dk }, sp); let d = ''; for (let k = 0; k <= 12; k++) { const aa = -1.2 + k * .22; const lx = r * .8 * Math.cos(aa), ly = r * Math.sin(aa) - 0; const rot = s.a - Math.PI / 2; d += (k ? 'L' : 'M') + (x + lx * Math.cos(rot) - ly * Math.sin(rot)).toFixed(1) + ' ' + (y + lx * Math.sin(rot) + ly * Math.cos(rot)).toFixed(1); } E('path', { d, stroke: '#7a4a1a', 'stroke-width': 3, fill: 'none', 'stroke-dasharray': '2.5 1' }, an); } });
    const sm = P('spores'); for (let i = 0; i < 16; i++) E('circle', { cx: 60 + (i % 8) * 18, cy: 222 + Math.floor(i / 8) * 18 + (i % 2) * 5, r: 3, fill: Rb.c, stroke: Rb.dk, 'stroke-width': .6 }, sm);
    T(g, 112, 270, 'মুক্ত স্পোর (n, সব একই রকম)', { fs: 10.5, a: 'middle', c: C.mu });
  },
  idle(g, C, t) {
    const Rb = BK.ramp(6), s = SG[2], [x, y] = spPos(s), f = (t * .3) % 1;
    if (f > .45) { const k = (f - .45) / .55; for (let i = 0; i < 10; i++) { const a = 1.4 + (i - 4.5) * .2; E('circle', { cx: (x + 70 * k * Math.cos(a + 1)).toFixed(1), cy: (y + 80 * k * Math.sin(a) - 30 * Math.sin(k * Math.PI)).toFixed(1), r: 2, fill: Rb.c, opacity: 1 - k * .6 }, g); } E('path', { d: `M${x - 6} ${y - 4}l-8 -10`, stroke: '#7a4a1a', 'stroke-width': 2 }, g); }
  },
  parts: [
    { id: 'lamina', bn: 'পত্রকের ফলক', lb: 'পত্রক ফলক', en: 'Lamina of pinna', fn: 'উপরের ও নিচের ত্বক এবং মাঝে ক্লোরোপ্লাস্টযুক্ত মেসোফিল — সালোকসংশ্লেষণ করে।', a: [80, 91], l: [80, 40] },
    { id: 'indusium', bn: 'অপ্রকৃত ইনডুসিয়াম', lb: 'অপ্রকৃত ইনডুসিয়াম', en: 'False indusium', fn: 'পত্রকের কিনারা নিচের দিকে বেঁকে সোরাসকে ঢেকে রাখে — এটি আলাদা গঠন নয়, পাতারই বাঁকানো কিনারা; তাই "অপ্রকৃত"। কচি রেণুস্থলীকে শুকানো ও আঘাত থেকে রক্ষা করে।', a: [276, 140], l: [292, 40], an: 'middle' },
    { id: 'commissure', bn: 'ভাস্কুলার কমিশার (রিসেপ্ট্যাকল)', lb: 'কমিশার', en: 'Vascular commissure', fn: 'কিনারার কাছে পার্শ্ব শিরাগুলোর প্রান্ত যুক্ত হয়ে তৈরি শিরা-সংযোগ — এর উপরের ফোলা অংশ (রিসেপ্ট্যাকল) থেকে রেণুস্থলী জন্মে ও খাদ্য পায়।', a: [SX, SY - 10], l: [178, 40] },
    { id: 'sporang', bn: 'রেণুস্থলী (স্পোরাঞ্জিয়াম)', lb: 'রেণুস্থলী', en: 'Sporangium', fn: 'দ্বিউত্তল মসুরের মতো থলি — ভেতরে স্পোর মাতৃকোষের মায়োসিসে সাধারণত 64টি হ্যাপ্লয়েড স্পোর। সোরাসে নানা বয়সের রেণুস্থলী থাকে (মিশ্র সোরাস)।', a: [spPos(SG[0])[0] - 8, spPos(SG[0])[1]], l: [70, 160] },
    { id: 'annulus', bn: 'অ্যানুলাস', en: 'Annulus', fn: 'রেণুস্থলীর কিনারা বরাবর পুরু প্রাচীরের কোষের খাড়া, অসম্পূর্ণ বলয় — শুকানোর সময় টান তৈরি করে রেণুস্থলী ফাটায় ও স্পোর ছুড়ে দেয়।', a: [spPos(SG[1])[0] - 8, spPos(SG[1])[1] - 4], l: [70, 196] },
    { id: 'stalk', bn: 'রেণুস্থলীর বৃন্ত', lb: 'বৃন্ত', en: 'Stalk', fn: 'লম্বা বহুকোষী বৃন্ত — রেণুস্থলীকে কমিশারের সাথে যুক্ত রাখে।', a: [SX + 20 * Math.cos(SG[3].a), SY + 20 * Math.sin(SG[3].a)], l: [312, 196] },
    { id: 'paraphysis', bn: 'প্যারাফাইসিস', en: 'Paraphyses', fn: 'রেণুস্থলীর ফাঁকে সরু বহুকোষী বন্ধ্যা রোম — কচি রেণুস্থলী রক্ষা করে।', a: [SX + 32 * Math.cos(.9), SY + 32 * Math.sin(.9)], l: [312, 240] },
    { id: 'spores', bn: 'স্পোর (n)', en: 'Spores', fn: 'Pteris সমরেণু — সব স্পোর একই আকারের; প্রতিটি অঙ্কুরিত হয়ে প্রোথ্যালাস (গ্যামিটোফাইট) তৈরি করে।', a: [168, 232], l: [220, 262] }
  ]
}));

/* ───────── রেণুস্থলী ফাটা ───────── */
const KX = 180, KY = 124, KRX = 50, KRY = 62, aH = 75 * Math.PI / 180, aS = 140 * Math.PI / 180;
const ep = a => [KX + KRX * Math.cos(a), KY + KRY * Math.sin(a)];
const PIV = ep(aH);
const rot = (p, th) => { const dx = p[0] - PIV[0], dy = p[1] - PIV[1], c = Math.cos(th), s = Math.sin(th); return [PIV[0] + dx * c - dy * s, PIV[1] + dx * s + dy * c]; };
const SPS = []; for (let i = 0; i < 26; i++) { const a = i * 2.4, r = Math.sqrt(i / 26) * .78; SPS.push([KX + KRX * r * Math.cos(a), KY - 8 + KRY * r * .9 * Math.sin(a)]); }
V.sporangium = Object.assign({
  t: 'রেণুস্থলী ফেটে স্পোর ছড়ানো — অ্যানুলাসের কৌশল', k: ['2d', 'anim', 'int'],
  cap: 'অ্যানুলাসের কোষের ভেতরের ও পাশের প্রাচীর পুরু, বাইরের প্রাচীর পাতলা। শুকানোর সময় কোষের পানি কমে, পানির সংসক্তিতে পাতলা প্রাচীর ভেতরে টেনে নেয় — স্টোমিয়ামের পাতলা কোষ ছিঁড়ে যায় ও অ্যানুলাস পেছনে বেঁকে যায়। পানির স্তম্ভ হঠাৎ ভেঙে গেলে অ্যানুলাস ঝটকায় ফিরে আসে — গুলতির মতো স্পোর ছুড়ে দেয়।'
}, BK.steps({
  W: 360, H: 260, label: 'রেণুস্থলী ফাটা', dur: 2.8,
  stages: [
    { t: 'পরিণত রেণুস্থলী', en: 'Mature sporangium', d: 'বৃন্তের মাথায় দ্বিউত্তল থলি; ভেতরে সাধারণত 64টি স্পোর (16টি স্পোর মাতৃকোষের মায়োসিসে)। কিনারায় খাড়া অসম্পূর্ণ অ্যানুলাস, এক পাশে পাতলা প্রাচীরের স্টোমিয়াম।' },
    { t: 'শুকানো ও টান', en: 'Drying & tension', d: 'বাতাস শুষ্ক হলে অ্যানুলাস কোষের পানি বাষ্প হয়; পানির অণুর সংসক্তি ও প্রাচীরে আসক্তির কারণে পাতলা বাইরের প্রাচীর ভেতরে টান খায় — অ্যানুলাসে টান জমে।' },
    { t: 'স্টোমিয়াম ছিঁড়ে যায়', en: 'Stomium ruptures', d: 'টানের চাপে সবচেয়ে দুর্বল জায়গা — স্টোমিয়ামের পাতলা কোষ — ছিঁড়ে যায়; থলি আড়াআড়িভাবে ফাটতে শুরু করে।' },
    { t: 'অ্যানুলাস পেছনে বাঁকে', en: 'Annulus curls back', d: 'অ্যানুলাস সোজা হয়ে আরও পেছনে বেঁকে যায় — থলির উপরের অংশ স্পোরসহ খোলা পেয়ালার মতো পেছনে সরে যায়।' },
    { t: 'ঝটকায় ফিরে আসা', en: 'Catapult', d: 'টান সীমায় পৌঁছালে কোষের পানি হঠাৎ বাষ্প-বুদবুদে ভেঙে যায় (ক্যাভিটেশন); অ্যানুলাস প্রায় এক ঝটকায় আগের জায়গায় ফিরে আসে এবং স্পোর কয়েক মিলিমিটার দূরে ছিটকে পড়ে — বাতাসে ভেসে ছড়ায়।' }
  ],
  draw(g, C, s, u) {
    const Rb = BK.ramp(6), Ra = '#7a4a1a', Rs = BK.ramp(9);
    let th = 0; if (s === 2) th = .5 * u; if (s === 3) th = .5 + 1.6 * u; if (s === 4) th = u < .12 ? 2.1 * (1 - u / .12) + .25 * (u / .12) : .25;
    E('path', { d: `M${PIV[0] - 14} 250L${PIV[0] - 6} ${PIV[1] + 2}M${PIV[0] + 4} 250L${PIV[0] + 2} ${PIV[1] + 2}`, stroke: Rb.dk, 'stroke-width': 2 }, g); E('rect', { x: PIV[0] - 13, y: PIV[1] + 4, width: 14, height: 250 - PIV[1] - 4, fill: FK.alpha(Rb.lt, .5) }, g);
    const low = []; for (let a = aH; a <= aS + .001; a += .1) low.push(ep(a)); low.push(ep(aS));
    E('path', { d: 'M' + low.map(p => p.map(v => v.toFixed(1)).join(' ')).join('L') + 'Z', fill: FK.alpha(Rb.lt, .85), stroke: Rb.dk, 'stroke-width': 1.2 }, g);
    const up = []; for (let a = aS; a <= aH + 2 * Math.PI + .001; a += .08) up.push(rot(ep(a), th));
    E('path', { d: 'M' + up.map(p => p.map(v => v.toFixed(1)).join(' ')).join('L') + 'Z', fill: FK.alpha(Rb.lt, .85), stroke: Rb.dk, 'stroke-width': 1.2 }, g);
    const flying = s === 4 && u >= .12;
    SPS.forEach((p, i) => { let q = rot(p, th); if (flying) { const k = (u - .12) / .88, a = -2.2 + i * .12; q = [q[0] + 160 * k * Math.cos(a), q[1] + 160 * k * Math.sin(a) + 90 * k * k]; } else if (s < 2 && (i % 3 === 0) && i < 14) { const k = s === 0 ? 0 : u; E('circle', { cx: q[0], cy: q[1], r: 3.6, fill: 'none', stroke: FK.alpha(Rs.dk, .3 * (1 - k)) }, g); } E('circle', { cx: q[0].toFixed(1), cy: q[1].toFixed(1), r: 2.6, fill: Rs.c, stroke: Rs.dk, 'stroke-width': .5, opacity: flying ? 1 - (u - .12) * .6 : 1 }, g); });
    const nA = 16, squeeze = s === 1 ? u : s >= 2 ? 1 : 0;
    for (let k = 0; k < nA; k++) { const a0 = aH + 2 * Math.PI - (k + .5) * ((aH + 2 * Math.PI - aS - .25) / nA); const p = rot(ep(a0), th), n = rot([ep(a0)[0] + Math.cos(a0) * 8, ep(a0)[1] + Math.sin(a0) * 8], th); const w = 7 - 2 * squeeze; E('rect', { x: (p[0] - w / 2).toFixed(1), y: (p[1] - 4).toFixed(1), width: w.toFixed(1), height: 8, fill: '#c98a45', stroke: Ra, 'stroke-width': 1.6, transform: `rotate(${((Math.atan2(n[1] - p[1], n[0] - p[0]) * 180 / Math.PI) + 90).toFixed(1)} ${p[0].toFixed(1)} ${p[1].toFixed(1)})` }, g); }
    const stP = ep(aS + .12); E('circle', { cx: stP[0].toFixed(1), cy: stP[1].toFixed(1), r: 5, fill: s >= 2 ? C.bad : '#f2e6c9', stroke: Ra, 'stroke-width': 1 }, g);
    if (s === 1) { for (let k = 0; k < 4; k++) { const a0 = -1.6 + k * .8, p = ep(a0); E('path', { d: `M${(p[0] + 18 * Math.cos(a0)).toFixed(1)} ${(p[1] + 18 * Math.sin(a0)).toFixed(1)}L${(p[0] + 6 * Math.cos(a0)).toFixed(1)} ${(p[1] + 6 * Math.sin(a0)).toFixed(1)}`, stroke: BK.ramp(5).c, 'stroke-width': 2, opacity: u }, g); } T(g, 300, 40, 'পানি বাষ্প', { fs: 11, a: 'middle', w: 600, c: BK.ramp(5).ink }); }
    T(g, 16, 30, s === 0 ? 'অ্যানুলাস (পুরু প্রাচীর)' : s === 1 ? 'অ্যানুলাসে টান' : s === 4 ? 'স্পোর ছিটকে পড়ে' : 'স্টোমিয়াম ফেটেছে', { fs: 11.5, w: 650, c: s === 4 ? Rs.ink : Ra });
    T(g, stP[0] - 10, stP[1] + 20, 'স্টোমিয়াম', { fs: 10.5, a: 'end', w: 600, c: C.mu });
  }
}));

/* ───────── রাইজোমের প্রস্থচ্ছেদ ───────── */
const ZX = 140, ZY = 160, ZR = 118, MR = 64, NM = 7;
const MS = []; for (let i = 0; i < NM; i++) { const a = i / NM * 2 * Math.PI; MS.push({ x: ZX + MR * Math.cos(a), y: ZY + MR * .92 * Math.sin(a), a }); }
V.rhizomeTS = Object.assign({
  t: 'Pteris এর রাইজোমের প্রস্থচ্ছেদ', k: ['2d', 'label', 'int'],
  cap: 'বাইরে থেকে ভেতরে: এপিডার্মিস, স্ক্লেরেনকাইমার হাইপোডার্মিস, প্যারেনকাইমার ভিত্তিকলা (মাঝে মাঝে স্ক্লেরেনকাইমার গুচ্ছ) এবং পত্র-ফাঁকে বিচ্ছিন্ন একটি বলয়ে কয়েকটি মেরিস্টিলি — ডিকটিওস্টিলি। প্রতিটি মেরিস্টিলি কনসেন্ট্রিক অ্যাম্ফিক্রিবাল বান্ডল: মাঝে জাইলেম, চারপাশে ফ্লোয়েম, তার বাইরে পেরিসাইকল ও এন্ডোডার্মিস। (প্রজাতি ও বয়সভেদে স্টিলির ধরন ভিন্ন হতে পারে।)'
}, BK.diagram({
  W: 360, H: 320, label: 'রাইজোমের প্রস্থচ্ছেদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rs = BK.ramp(6), Rx = BK.ramp(4), Rp = BK.ramp(7), Ren = BK.ramp(9);
    const ep = P('epidermis'); E('circle', { cx: ZX, cy: ZY, r: ZR, fill: '#e9dcc0', stroke: '#6b4a2a', 'stroke-width': 3 }, ep);
    const hp = P('hypodermis'); E('circle', { cx: ZX, cy: ZY, r: ZR - 9, fill: 'none', stroke: '#8a5a2a', 'stroke-width': 14 }, hp);
    const gt = P('ground'); E('circle', { cx: ZX, cy: ZY, r: ZR - 16, fill: FK.alpha('#f5ecd6', 1), stroke: 'none' }, gt); for (let i = 0; i < 160; i++) { const a = i * 2.39996, r = Math.sqrt(i / 160) * (ZR - 22); E('circle', { cx: (ZX + r * Math.cos(a)).toFixed(1), cy: (ZY + r * Math.sin(a)).toFixed(1), r: 4.4, fill: 'none', stroke: FK.alpha('#b9a37a', .45), 'stroke-width': .7 }, gt); }
    const sc = P('scler'); [[ZX - 18, ZY - 10, 14, 7], [ZX + 16, ZY + 14, 12, 6], [ZX + 4, ZY - 30, 8, 5]].forEach(([x, y, rx, ry]) => E('ellipse', { cx: x, cy: y, rx, ry, fill: '#8a5a2a', stroke: '#5a3a1a' }, sc));
    const gp = P('gap'); E('path', { d: `M${MS[1].x + 6} ${MS[1].y + 10}L${MS[2].x + 18} ${MS[2].y - 2}`, stroke: C.acc, 'stroke-width': 1.5, 'stroke-dasharray': '3 3' }, gp);
    const en = P('endo'), pc = P('peri'), fl = P('phloem'), xy = P('xylem');
    MS.forEach(m => { const deg = m.a * 180 / Math.PI + 90, tr = `rotate(${deg.toFixed(1)} ${m.x.toFixed(1)} ${m.y.toFixed(1)})`;
      E('ellipse', { cx: m.x, cy: m.y, rx: 23, ry: 13, fill: FK.alpha(Ren.lt, .5), stroke: Ren.dk, 'stroke-width': 2, transform: tr }, en);
      E('ellipse', { cx: m.x, cy: m.y, rx: 20, ry: 10.5, fill: '#fbf3dd', stroke: FK.alpha(Rs.dk, .6), 'stroke-width': .8, transform: tr }, pc);
      E('ellipse', { cx: m.x, cy: m.y, rx: 17, ry: 8, fill: FK.alpha(Rp.c, .7), stroke: Rp.dk, 'stroke-width': .6, transform: tr }, fl);
      const xg = E('g', { transform: tr }, xy); E('ellipse', { cx: m.x, cy: m.y, rx: 12, ry: 4, fill: FK.alpha(Rx.c, .85), stroke: Rx.dk, 'stroke-width': .6 }, xg); [-8, -3, 2, 7].forEach(dx => E('circle', { cx: m.x + dx, cy: m.y, r: 2, fill: FK.alpha('#fff', .8), stroke: Rx.dk, 'stroke-width': .5 }, xg)); });
    const mr = P('meri'); const m3 = MS[3]; E('ellipse', { cx: m3.x, cy: m3.y, rx: 28, ry: 18, fill: 'none', stroke: C.acc, 'stroke-width': 1.6, 'stroke-dasharray': '4 3', transform: `rotate(${(m3.a * 180 / Math.PI + 90).toFixed(1)} ${m3.x.toFixed(1)} ${m3.y.toFixed(1)})` }, mr);
  },
  parts: [
    { id: 'epidermis', bn: 'এপিডার্মিস', en: 'Epidermis', fn: 'সবচেয়ে বাইরের এক স্তরের কোষ; বাইরের প্রাচীর পুরু ও কিউটিকলযুক্ত, অনেক সময় বাদামি — রক্ষা করে।', a: [ZX + ZR * Math.cos(-1.1), ZY + ZR * Math.sin(-1.1)], l: [292, 26] },
    { id: 'hypodermis', bn: 'হাইপোডার্মিস (স্ক্লেরেনকাইমা)', lb: 'হাইপোডার্মিস', en: 'Hypodermis', fn: 'এপিডার্মিসের নিচে কয়েক স্তরের পুরু প্রাচীরের বাদামি স্ক্লেরেনকাইমা — যান্ত্রিক শক্তি দেয়।', a: [ZX + (ZR - 9) * Math.cos(-.6), ZY + (ZR - 9) * Math.sin(-.6)], l: [292, 58] },
    { id: 'ground', bn: 'ভিত্তিকলা (প্যারেনকাইমা)', lb: 'ভিত্তিকলা', en: 'Ground tissue', fn: 'পাতলা প্রাচীরের প্যারেনকাইমা কোষ — শ্বেতসার সঞ্চয় করে; মেরিস্টিলির ভেতরে ও বাইরে বিস্তৃত।', a: [ZX + 96 * Math.cos(-.25), ZY + 96 * Math.sin(-.25)], l: [292, 92] },
    { id: 'endo', bn: 'এন্ডোডার্মিস', en: 'Endodermis', fn: 'প্রতিটি মেরিস্টিলিকে ঘিরে এক স্তরের ব্যারেলাকার কোষ — ক্যাসপেরিয়ান ফিতা থাকে; পানি ও দ্রবণের চলাচল নিয়ন্ত্রণ করে।', a: [MS[0].x + 4, MS[0].y - 21], l: [292, 126] },
    { id: 'peri', bn: 'পেরিসাইকল', en: 'Pericycle', fn: 'এন্ডোডার্মিসের ভেতরে এক বা দুই স্তরের প্যারেনকাইমা কোষ।', a: [MS[0].x + 3, MS[0].y + 17.5], l: [292, 196] },
    { id: 'phloem', bn: 'ফ্লোয়েম', en: 'Phloem', fn: 'জাইলেমকে চারদিক থেকে ঘিরে থাকে — সিভ কোষ ও ফ্লোয়েম প্যারেনকাইমা; খাদ্য পরিবহন করে (সঙ্গীকোষ নেই)।', a: [MS[0].x + 5, MS[0].y + 12], l: [292, 228] },
    { id: 'xylem', bn: 'জাইলেম (মাঝখানে)', lb: 'জাইলেম', en: 'Xylem', fn: 'মেরিস্টিলির কেন্দ্রে ট্র্যাকিড ও জাইলেম প্যারেনকাইমা — পানি পরিবহন করে। প্রোটোজাইলেম মেটাজাইলেমের মাঝে (মেসার্ক)। জাইলেম ঘিরে ফ্লোয়েম থাকায় বান্ডলটি কনসেন্ট্রিক অ্যাম্ফিক্রিবাল (হ্যাড্রোসেন্ট্রিক)।', a: [MS[0].x + 1, MS[0].y + 6], l: [292, 262] },
    { id: 'meri', bn: 'মেরিস্টিলি (ডিকটিওস্টিলির একক)', lb: 'মেরিস্টিলি', en: 'Meristele', fn: 'পত্র-ফাঁকে বিচ্ছিন্ন স্টিলির প্রতিটি অংশ — নিজস্ব এন্ডোডার্মিস ও পেরিসাইকলসহ একটি কনসেন্ট্রিক বান্ডল। কয়েকটি মেরিস্টিলি মিলে বলয় — ডিকটিওস্টিলি।', a: [MS[3].x - 20, MS[3].y], l: [26, 292], an: 'middle' },
    { id: 'gap', bn: 'পত্র-ফাঁক', en: 'Leaf gap', fn: 'পাতায় ভাস্কুলার ট্রেস যাওয়ার জায়গায় স্টিলিতে যে ফাঁক তৈরি হয় — অনেকগুলো পত্র-ফাঁকের ফলে নলাকার স্টিলি জালের মতো বিচ্ছিন্ন হয় (ডিকটিওস্টিলি)।', a: [(MS[1].x + MS[2].x) / 2 + 12, (MS[1].y + MS[2].y) / 2 + 4], l: [150, 306], an: 'middle' },
    { id: 'scler', bn: 'স্ক্লেরেনকাইমা গুচ্ছ', lb: 'স্ক্লেরেনকাইমা গুচ্ছ', en: 'Sclerenchyma patches', fn: 'ভিত্তিকলার মাঝে পুরু প্রাচীরের বাদামি কোষের গুচ্ছ বা ফিতা — অতিরিক্ত দৃঢ়তা দেয়।', a: [ZX - 18, ZY - 10], l: [60, 20], an: 'middle' }
  ]
}));

/* ───────── পত্রাক্ষের প্রস্থচ্ছেদ ───────── */
const QX = 150, QY = 158;
const uPath = `M${QX - 46} ${QY - 34}C${QX - 58} ${QY + 10} ${QX - 40} ${QY + 52} ${QX} ${QY + 54}C${QX + 40} ${QY + 52} ${QX + 58} ${QY + 10} ${QX + 46} ${QY - 34}`;
V.rachisTS = Object.assign({
  t: 'Pteris এর পত্রাক্ষের (র‍্যাকিস) প্রস্থচ্ছেদ', k: ['2d', 'label', 'int'],
  cap: 'পত্রাক্ষ বা পত্রবৃন্তের প্রস্থচ্ছেদ: এপিডার্মিস, পুরু স্ক্লেরেনকাইমার হাইপোডার্মিস, প্যারেনকাইমার ভিত্তিকলা এবং মাঝে একটি অশ্বখুরাকৃতি (U আকৃতির) মেরিস্টিলি — উপরের দিকে খোলা। মেরিস্টিলি কনসেন্ট্রিক: জাইলেমের চারপাশে ফ্লোয়েম, পেরিসাইকল ও এন্ডোডার্মিস; বাহুর প্রান্তে আঁকড়ার মতো বাঁকা জাইলেমে প্রোটোজাইলেম।'
}, BK.diagram({
  W: 360, H: 310, label: 'পত্রাক্ষের প্রস্থচ্ছেদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rx = BK.ramp(4), Rp = BK.ramp(7), Ren = BK.ramp(9);
    const out = `M${QX - 26} ${QY - 104}C${QX - 70} ${QY - 104} ${QX - 112} ${QY - 60} ${QX - 112} ${QY}C${QX - 112} ${QY + 66} ${QX - 60} ${QY + 108} ${QX} ${QY + 108}C${QX + 60} ${QY + 108} ${QX + 112} ${QY + 66} ${QX + 112} ${QY}C${QX + 112} ${QY - 60} ${QX + 70} ${QY - 104} ${QX + 26} ${QY - 104}C${QX + 14} ${QY - 104} ${QX + 10} ${QY - 88} ${QX} ${QY - 88}C${QX - 10} ${QY - 88} ${QX - 14} ${QY - 104} ${QX - 26} ${QY - 104}Z`;
    const ep = P('epidermis'); E('path', { d: out, fill: '#e9dcc0', stroke: '#6b4a2a', 'stroke-width': 3 }, ep);
    const hp = P('hypodermis'); E('path', { d: out, fill: 'none', stroke: '#8a5a2a', 'stroke-width': 22, transform: `translate(${QX} ${QY}) scale(.93) translate(${-QX} ${-QY})` }, hp);
    const gt = P('ground'); E('path', { d: out, fill: '#f5ecd6', stroke: 'none', transform: `translate(${QX} ${QY}) scale(.84) translate(${-QX} ${-QY})` }, gt); for (let i = 0; i < 130; i++) { const a = i * 2.39996, r = Math.sqrt(i / 130) * 86; E('circle', { cx: (QX + r * Math.cos(a)).toFixed(1), cy: (QY + 6 + r * .95 * Math.sin(a)).toFixed(1), r: 4.2, fill: 'none', stroke: FK.alpha('#b9a37a', .45), 'stroke-width': .7 }, gt); }
    const en = P('endo'); E('path', { d: uPath, stroke: Ren.dk, 'stroke-width': 30, fill: 'none', 'stroke-linecap': 'round' }, en); E('path', { d: uPath, stroke: FK.alpha(Ren.lt, .9), 'stroke-width': 26, fill: 'none', 'stroke-linecap': 'round' }, en);
    const pc = P('peri'); E('path', { d: uPath, stroke: '#fbf3dd', 'stroke-width': 22, fill: 'none', 'stroke-linecap': 'round' }, pc);
    const fl = P('phloem'); E('path', { d: uPath, stroke: FK.alpha(Rp.c, .75), 'stroke-width': 17, fill: 'none', 'stroke-linecap': 'round' }, fl);
    const xy = P('xylem'); E('path', { d: uPath, stroke: FK.alpha(Rx.c, .9), 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, xy);
    const mr = P('meri'); E('path', { d: uPath, stroke: C.acc, 'stroke-width': 38, fill: 'none', 'stroke-linecap': 'round', opacity: .12 }, mr);
    const px = P('protox'); [[QX - 46, QY - 34], [QX + 46, QY - 34]].forEach(([x, y], k) => { E('path', { d: `M${x} ${y}q${k ? -8 : 8} -8 ${k ? -14 : 14} -2`, stroke: Rx.dk, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, px); E('circle', { cx: x + (k ? -14 : 14), cy: y - 2, r: 2.6, fill: '#fff', stroke: Rx.dk }, px); });
  },
  parts: [
    { id: 'epidermis', bn: 'এপিডার্মিস', en: 'Epidermis', fn: 'বাইরের এক স্তরের কিউটিকলযুক্ত কোষ।', a: [QX + 104, QY - 44], l: [300, 30] },
    { id: 'hypodermis', bn: 'হাইপোডার্মিস (স্ক্লেরেনকাইমা)', lb: 'হাইপোডার্মিস', en: 'Hypodermis', fn: 'কয়েক স্তরের পুরু, লিগনিনযুক্ত বাদামি স্ক্লেরেনকাইমা — পাতার ভার বহনে দৃঢ়তা দেয়।', a: [QX + 98, QY + 12], l: [300, 70] },
    { id: 'ground', bn: 'ভিত্তিকলা (প্যারেনকাইমা)', lb: 'ভিত্তিকলা', en: 'Ground tissue', fn: 'পাতলা প্রাচীরের প্যারেনকাইমা — খাদ্য সঞ্চয় করে।', a: [QX + 74, QY + 40], l: [300, 110] },
    { id: 'endo', bn: 'এন্ডোডার্মিস', en: 'Endodermis', fn: 'মেরিস্টিলির সবচেয়ে বাইরের এক স্তর — ক্যাসপেরিয়ান ফিতাযুক্ত।', a: [QX + 54, QY - 4], l: [300, 150] },
    { id: 'peri', bn: 'পেরিসাইকল', en: 'Pericycle', fn: 'এন্ডোডার্মিসের ভেতরের পাতলা প্রাচীরের কোষস্তর।', a: [QX + 24, QY + 59], l: [300, 190] },
    { id: 'phloem', bn: 'ফ্লোয়েম', en: 'Phloem', fn: 'জাইলেমের দুই পাশ ঘিরে সিভ কোষ ও প্যারেনকাইমা — খাদ্য পরিবহন।', a: [QX + 6, QY + 61], l: [300, 230] },
    { id: 'xylem', bn: 'মেটাজাইলেম (U আকৃতির ফিতা)', lb: 'জাইলেম', en: 'Metaxylem', fn: 'অশ্বখুরাকৃতি ফিতার মতো জাইলেম — বড় ট্র্যাকিড; পানি পরিবহন করে।', a: [QX - 20, QY + 52], l: [80, 290], an: 'middle' },
    { id: 'protox', bn: 'প্রোটোজাইলেম (বাহুর বাঁকা প্রান্তে)', lb: 'প্রোটোজাইলেম', en: 'Protoxylem', fn: 'U এর দুই বাহুর ভেতরের দিকে বাঁকা আঁকড়ার মতো প্রান্তে ছোট প্রোটোজাইলেম — প্রথমে পরিণত হয়।', a: [QX - 34, QY - 38], l: [40, 40], an: 'middle' },
    { id: 'meri', bn: 'অশ্বখুরাকৃতি মেরিস্টিলি', lb: 'মেরিস্টিলি', en: 'Horseshoe meristele', fn: 'পত্রাক্ষে একটি মাত্র বড় U বা অশ্বখুরাকৃতি কনসেন্ট্রিক মেরিস্টিলি — খোলা মুখ পত্রাক্ষের উপরের (অক্ষ-সম্মুখ) খাঁজের দিকে।', a: [QX - 50, QY], l: [26, 170], an: 'middle' }
  ]
}));

/* ───────── প্রোথ্যালাস ───────── */
const HX = 180;
const heart = `M${HX} 58C${HX - 20} 34 ${HX - 70} 30 ${HX - 98} 58C${HX - 126} 88 ${HX - 110} 150 ${HX - 70} 196C${HX - 44} 226 ${HX - 16} 246 ${HX} 256C${HX + 16} 246 ${HX + 44} 226 ${HX + 70} 196C${HX + 110} 150 ${HX + 126} 88 ${HX + 98} 58C${HX + 70} 30 ${HX + 20} 34 ${HX} 58Z`;
const ARC = [[HX - 14, 84], [HX + 12, 80], [HX - 4, 104], [HX + 20, 106], [HX - 22, 112]];
const ANT = [[HX - 40, 200], [HX + 36, 196], [HX - 10, 214], [HX + 14, 226], [HX - 56, 176], [HX + 58, 172], [HX + 2, 190]];
V.prothallus = Object.assign({
  t: 'Pteris এর প্রোথ্যালাস (গ্যামিটোফাইট, অঙ্কীয় দৃশ্য)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'স্পোর থেকে তৈরি হৃৎপিণ্ডাকার, সবুজ, এক কোষ পুরু (মাঝে কয়েক স্তরের কুশন) গ্যামিটোফাইট — মাত্র কয়েক মিলিমিটার চওড়া। অঙ্কীয় তলের পেছনের দিকে রাইজয়েড ও তাদের ফাঁকে পুংধানী; সামনের খাঁজের কাছে কুশনে স্ত্রীধানী। চালু করলে বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু পানির স্তরে সাঁতরে স্ত্রীধানীর দিকে যায়।'
}, BK.diagram({
  W: 360, H: 290, label: 'প্রোথ্যালাস',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Ra = BK.ramp(5), Rf = BK.ramp(8), Rr = BK.ramp(6);
    const rh = P('rhizoid'); for (let i = 0; i < 16; i++) { const x = HX - 50 + i * 6.6, y0 = 188 + Math.abs(i - 7.5) * -2 + 20; E('path', { d: `M${x} ${y0}q${(i % 2 ? 6 : -6)} 30 ${(i % 3) * 3 - 3} ${54 + (i % 4) * 6}`, stroke: FK.alpha(Rr.dk, .7), 'stroke-width': 1.1, fill: 'none' }, rh); }
    const th = P('thallus'); E('path', { d: heart, fill: FK.alpha(R.c, .85), stroke: R.dk, 'stroke-width': 1.6 }, th); for (let i = 0; i < 60; i++) { const a = i * 2.39996, r = Math.sqrt(i / 60) * 92; const x = HX + r * Math.cos(a), y = 140 + r * .9 * Math.sin(a); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 1.4, fill: FK.alpha(R.dk, .35) }, th); }
    const cu = P('cushion'); E('path', { d: `M${HX} 66C${HX - 24} 70 ${HX - 34} 100 ${HX - 30} 140C${HX - 26} 170 ${HX + 26} 170 ${HX + 30} 140C${HX + 34} 100 ${HX + 24} 70 ${HX} 66Z`, fill: FK.alpha(R.dk, .25), stroke: FK.alpha(R.dk, .5), 'stroke-dasharray': '3 2' }, cu);
    const nt = P('notch'); E('circle', { cx: HX, cy: 60, r: 4, fill: BK.ramp(4).c }, nt);
    const ar = P('arche'); ARC.forEach(([x, y]) => { E('path', { d: `M${x} ${y}q-6 -10 -2 -18`, stroke: Rf.dk, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, ar); E('circle', { cx: x, cy: y, r: 4.6, fill: Rf.c, stroke: Rf.dk }, ar); });
    const an = P('anther'); ANT.forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 5.4, fill: Ra.lt, stroke: Ra.dk, 'stroke-width': 1.4 }, an); E('circle', { cx: x, cy: y, r: 2.4, fill: Ra.c }, an); });
    T(g, 20, 280, 'চওড়া মাত্র কয়েক mm', { fs: 10.5, c: C.mu });
  },
  idle(g, C, t) {
    const R = BK.ramp(5);
    for (let i = 0; i < 5; i++) { const [x0, y0] = ANT[i], [x1, y1] = ARC[i], f = (t * .16 + i / 5) % 1; const x = x0 + (x1 - x0) * f + 10 * Math.sin(f * 9 + i), y = y0 + (y1 - y0) * f; B6.sperm(g, x, y, R, t + i, Math.atan2(y1 - y0, x1 - x0), true); }
  },
  parts: [
    { id: 'notch', bn: 'শীর্ষ খাঁজ ও বৃদ্ধিবিন্দু', lb: 'শীর্ষ খাঁজ', en: 'Apical notch', fn: 'হৃৎপিণ্ডের সামনের খাঁজে ভাজক কোষ — প্রোথ্যালাস এখান থেকে বাড়ে।', a: [HX, 58], l: [HX, 22] },
    { id: 'thallus', bn: 'প্রোথ্যালাস (গ্যামিটোফাইট, n)', lb: 'প্রোথ্যালাস', en: 'Prothallus', fn: 'হ্যাপ্লয়েড, সবুজ, স্বভোজী, এক কোষ পুরু চ্যাপ্টা দেহ — স্বাধীন কিন্তু ক্ষুদ্র ও স্বল্পস্থায়ী; স্পোরোফাইট প্রতিষ্ঠিত হলে মরে যায়।', a: [HX + 96, 80], l: [320, 40], an: 'middle' },
    { id: 'cushion', bn: 'কুশন (মধ্যবর্তী পুরু অংশ)', lb: 'কুশন', en: 'Cushion', fn: 'খাঁজের পেছনে মাঝ বরাবর কয়েক কোষ পুরু অংশ — এখানে স্ত্রীধানী জন্মায় এবং পরে ভ্রূণকে খাদ্য জোগায়।', a: [HX + 26, 128], l: [326, 128], an: 'middle' },
    { id: 'arche', bn: 'স্ত্রীধানী (আর্কিগোনিয়াম)', lb: 'স্ত্রীধানী', en: 'Archegonia', fn: 'কুশনে খাঁজের কাছে; অঙ্কদেশ কুশনে নিমজ্জিত, ছোট বাঁকা গ্রীবা বাইরে উঁচু হয়ে থাকে; প্রতিটিতে একটি ডিম্বাণু।', a: [ARC[0][0] - 4, ARC[0][1] - 10], l: [40, 70], an: 'middle' },
    { id: 'anther', bn: 'পুংধানী (অ্যান্থেরিডিয়াম)', lb: 'পুংধানী', en: 'Antheridia', fn: 'পেছনের দিকে রাইজয়েডের ফাঁকে ছোট গোল পুংধানী — প্রতিটিতে অল্প কয়েকটি (প্রায় 32টি) বহু-ফ্ল্যাজেলাযুক্ত প্যাঁচানো শুক্রাণু।', a: [ANT[4][0] - 5, ANT[4][1]], l: [40, 170], an: 'middle' },
    { id: 'rhizoid', bn: 'রাইজয়েড', en: 'Rhizoids', fn: 'অঙ্কীয় তলের পেছন দিক থেকে এককোষী রাইজয়েড — মাটিতে আটকে রাখে, পানি ও খনিজ শোষণ করে।', a: [HX - 30, 262], l: [60, 240], an: 'middle' }
  ]
}));

/* ───────── জীবনচক্র ───────── */
const miniFern = (g, x, y, s, R, sori) => { E('path', { d: `M${x} ${y}Q${x - 4 * s} ${y - 20 * s} ${x} ${y - 40 * s}`, stroke: R.dk, 'stroke-width': 1.6, fill: 'none' }, g); for (let i = 0; i < 6; i++) { const yy = y - 12 * s - i * 5 * s, L = (16 - i * 2) * s; [-1, 1].forEach(sd => { E('path', { d: leafPath(x, yy, x + sd * L, yy - L * .3, 2 * s), fill: R.c, stroke: R.dk, 'stroke-width': .5 }, g); if (sori) E('path', { d: `M${x + sd * L * .2} ${yy + 1.2 * s}L${x + sd * L * .85} ${yy - L * .25 + 1.2 * s}`, stroke: BK.ramp(6).dk, 'stroke-width': 1 }, g); }); } };
V.pterisCycle = Object.assign({
  t: 'Pteris এর জীবনচক্র ও জনুঃক্রম', k: ['2d', 'anim', 'int'],
  cap: 'স্পোরোফাইট (2n) প্রধান জনু; রেণুস্থলীতে মায়োসিসে স্পোর (n) → প্রোথ্যালাস (গ্যামিটোফাইট, n) → গ্যামিট → নিষেকে জাইগোট (2n) → নতুন স্পোরোফাইট। দুই জনু ভিন্নরূপী ও পর্যায়ক্রমিক — বিষমরূপী জনুঃক্রম; দুটিই জীবনের কোনো এক সময় স্বাধীন।'
}, BK.steps({
  W: 360, H: 260, label: 'Pteris জীবনচক্র', dur: 2.8,
  stages: [
    { t: 'স্পোরোফাইট (2n)', en: 'Sporophyte', d: 'মূল, রাইজোম ও যৌগিক পাতাযুক্ত প্রধান উদ্ভিদ; উর্বর পত্রকের কিনারায় সোরাস।' },
    { t: 'মায়োসিস → স্পোর', en: 'Meiosis in sporangium', d: 'রেণুস্থলীতে স্পোর মাতৃকোষ (2n) মায়োসিসে বিভাজিত হয়ে সাধারণত 64টি হ্যাপ্লয়েড স্পোর; রেণুস্থলী ফেটে স্পোর বাতাসে ছড়ায়।' },
    { t: 'প্রোথ্যালাস গঠন', en: 'Prothallus', d: 'ভেজা মাটিতে স্পোর অঙ্কুরিত হয়ে প্রথমে ছোট সূত্র, তারপর চ্যাপ্টা হৃৎপিণ্ডাকার সবুজ প্রোথ্যালাস (n) — স্বাধীন গ্যামিটোফাইট।' },
    { t: 'যৌনাঙ্গ ও নিষেক', en: 'Fertilization', d: 'পুংধানী থেকে বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু পানির স্তরে সাঁতরে রাসায়নিক আকর্ষণে (ম্যালিক অ্যাসিড) স্ত্রীধানীর গ্রীবা দিয়ে ঢুকে ডিম্বাণুকে নিষিক্ত করে → জাইগোট (2n)।' },
    { t: 'ভ্রূণ', en: 'Embryo', d: 'জাইগোট স্ত্রীধানীর ভেতরেই ভ্রূণে পরিণত হয় — পদ (প্রোথ্যালাস থেকে খাদ্য নেয়), প্রাথমিক মূল, কাণ্ডের শীর্ষ ও প্রথম পাতা।' },
    { t: 'তরুণ স্পোরোফাইট', en: 'Young sporophyte', d: 'প্রথম পাতা ও মূল বেরিয়ে তরুণ স্পোরোফাইট স্বাধীন হয়; প্রোথ্যালাস শুকিয়ে মরে যায় — চক্র পূর্ণ।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), Rb = BK.ramp(6), Rs = BK.ramp(9), Rf = BK.ramp(8), Ra = BK.ramp(5);
    const svg = g.ownerSVGElement; svg._ph = (svg._ph || 0) + .03; const ph = svg._ph;
    E('rect', { x: 10, y: 214, width: 340, height: 38, rx: 6, fill: FK.alpha('#8a6b3a', .15) }, g);
    const tag = (txt, c) => T(g, 180, 36, txt, { fs: 12, a: 'middle', w: 650, c });
    if (s === 0) { miniFern(g, 180, 214, 4.2, R, true); tag('স্পোরোফাইট (2n) — প্রধান জনু', Rb.ink); }
    if (s === 1) { E('ellipse', { cx: 180, cy: 120, rx: 44, ry: 54, fill: FK.alpha(Rb.lt, .8), stroke: Rb.dk, 'stroke-width': 1.4 }, g); E('path', { d: 'M180 174V214', stroke: Rb.dk, 'stroke-width': 3 }, g); const n = u < .5 ? 16 : 64; for (let i = 0; i < 16; i++) { const a = i * 2.39996, r = Math.sqrt((i + .5) / 16) * 34, x = 180 + r * Math.cos(a), y = 116 + r * 1.2 * Math.sin(a); if (n === 16) E('circle', { cx: x, cy: y, r: 6, fill: FK.alpha(Rb.c, .8), stroke: Rb.dk, 'stroke-width': .6 }, g); else [[-2.4, -2.4], [2.4, -2.4], [-2.4, 2.4], [2.4, 2.4]].forEach(([a1, b1]) => E('circle', { cx: x + a1, cy: y + b1, r: 2.2, fill: Rs.c, stroke: Rs.dk, 'stroke-width': .4 }, g)); } tag(n === 16 ? '16টি স্পোর মাতৃকোষ (2n)' : 'মায়োসিস → 64টি স্পোর (n)', n === 16 ? Rb.ink : Rs.ink); }
    if (s === 2) { const k = u; E('circle', { cx: 120, cy: 200, r: 4, fill: Rs.c, stroke: Rs.dk }, g); if (k > .15) { const L = Math.min(1, (k - .15) / .3); for (let i = 0; i < Math.ceil(L * 4); i++) E('rect', { x: 124 + i * 9, y: 196, width: 9, height: 7, fill: R.c, stroke: R.dk, 'stroke-width': .5 }, g); E('path', { d: 'M120 204v12', stroke: Rb.dk }, g); } if (k > .45) { const sc = (k - .45) / .55; E('path', { d: heart, fill: FK.alpha(R.c, .85), stroke: R.dk, transform: `translate(${230 - HX * .55 * sc} ${200 - 256 * .55 * sc}) scale(${(.55 * sc).toFixed(3)})` }, g); } tag('স্পোর (n) → সূত্র → প্রোথ্যালাস (n)', R.ink); }
    if (s === 3) { const sc = .62; const gg = E('g', { transform: `translate(${180 - HX * sc} ${30}) scale(${sc})` }, g); E('path', { d: heart, fill: FK.alpha(R.c, .85), stroke: R.dk, 'stroke-width': 2 }, gg); ARC.slice(0, 3).forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 6, fill: Rf.c, stroke: Rf.dk }, gg)); ANT.slice(0, 4).forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 6, fill: Ra.lt, stroke: Ra.dk, 'stroke-width': 1.6 }, gg)); E('path', { d: heart, fill: FK.alpha(BK.ramp(5).c, .15), stroke: 'none', transform: `translate(${HX} 140) scale(1.04) translate(${-HX} -140)` }, gg); for (let i = 0; i < 4; i++) { const [x0, y0] = ANT[i], [x1, y1] = ARC[i % 3], f = Math.min(1, u * 1.3 + i * .05); B6.sperm(gg, x0 + (x1 - x0) * f, y0 + (y1 - y0) * f, Ra, ph + i, Math.atan2(y1 - y0, x1 - x0), true); } tag(u > .8 ? 'নিষেক → জাইগোট (2n)' : 'শুক্রাণু সাঁতরায় (পানি লাগে)', u > .8 ? Rb.ink : Ra.ink); }
    if (s === 4) { const sc = .62; const gg = E('g', { transform: `translate(${180 - HX * sc} ${30}) scale(${sc})` }, g); E('path', { d: heart, fill: FK.alpha(R.c, .85), stroke: R.dk, 'stroke-width': 2 }, gg); const r = 8 + 10 * u; E('circle', { cx: HX, cy: 104, r, fill: FK.alpha(Rb.lt, .9), stroke: Rb.dk, 'stroke-width': 2 }, gg); if (u > .4) { T(gg, HX + 70, 70, 'ভ্রূণ (2n)', { fs: 18, a: 'middle', w: 650, c: Rb.ink }); E('path', { d: `M${HX} ${104}l${-r * .5} ${r * .6}M${HX} 104l${r * .5} ${-r * .6}`, stroke: Rb.dk, 'stroke-width': 2 }, gg); } tag('জাইগোট → ভ্রূণ (পদ, মূল, কাণ্ড, প্রথম পাতা)', Rb.ink); }
    if (s === 5) { const sc = .5; const gg = E('g', { transform: `translate(${180 - HX * sc} ${84}) scale(${sc})`, opacity: (1 - u * .6).toFixed(2) }, g); E('path', { d: heart, fill: FK.alpha('#9a8a40', .7), stroke: '#6b5a20', 'stroke-width': 2 }, gg); miniFern(g, 180, 150, 1 + 1.6 * u, R, false); E('path', { d: `M180 150q-6 ${20 + 30 * u} -2 ${40 + 30 * u}M180 150q8 ${16 + 20 * u} 14 ${30 + 26 * u}`, stroke: '#6b5233', 'stroke-width': 1.4, fill: 'none' }, g); tag('তরুণ স্পোরোফাইট স্বাধীন; প্রোথ্যালাস মরে যায়', R.ink); }
  }
}));

/* ───────── তুলনা ───────── */
V.cmpBryoPterido = Object.assign({ t: 'ব্রায়োফাইট ও টেরিডোফাইটের পার্থক্য', k: ['compare', 'int', 'game'], cap: 'সারণিতে পাশাপাশি তুলনা; "কোনটি?" মোডে বৈশিষ্ট্য দেখে দল চিনে নিজেকে যাচাই করো।' }, BK.compare({
  a: 'ব্রায়োফাইট (Riccia)', b: 'টেরিডোফাইট (Pteris)',
  rows: [
    ['প্রধান জনু', 'গ্যামিটোফাইট (n)', 'স্পোরোফাইট (2n)'],
    ['দেহ', 'থ্যালয়েড বা কাণ্ড-পাতাসদৃশ; প্রকৃত মূল-কাণ্ড-পাতা নেই', 'প্রকৃত মূল, কাণ্ড (রাইজোম) ও পাতায় বিভক্ত'],
    ['ভাস্কুলার টিস্যু', 'নেই', 'আছে — জাইলেম (ট্র্যাকিড) ও ফ্লোয়েম'],
    ['মূলের কাজ', 'রাইজয়েড দিয়ে', 'অস্থানিক মূল দিয়ে'],
    ['স্পোরোফাইট', 'গ্যামিটোফাইটের উপর নির্ভরশীল; পদ, সিটা, ক্যাপসুল (Riccia তে কেবল ক্যাপসুল)', 'স্বাধীন, বড়, দীর্ঘস্থায়ী'],
    ['গ্যামিটোফাইট', 'বড়, দীর্ঘস্থায়ী, স্বাধীন', 'ছোট (প্রোথ্যালাস), স্বল্পস্থায়ী, স্বাধীন'],
    ['স্পোর উৎপাদন', 'ক্যাপসুলের ভেতরে', 'পাতার (রেণুপত্রের) রেণুস্থলীতে, সোরাসে'],
    ['শুক্রাণু', 'দুই-ফ্ল্যাজেলাযুক্ত', 'বহু-ফ্ল্যাজেলাযুক্ত, প্যাঁচানো'],
    ['আকার ও আবাস', 'ছোট; স্যাঁতসেঁতে ছায়াযুক্ত স্থান', 'বড় হতে পারে; বিচিত্র আবাস — ভেজা মাটি, দেয়াল, পানি'],
    ['উদাহরণ', 'Riccia, Marchantia, Funaria', 'Pteris, Dryopteris, Marsilea, Selaginella']
  ]
}));
})();
