/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §২.৪
   crossingOver : ক্রসিংওভারের কৌশল — A/a, B/b জিনসহ, ৫ ধাপ
   linkageMap   : জিনের দূরত্ব বনাম রিকম্বিনেশন — ১০০ গ্যামেটের অনুকরণ
   chromoGene   : ক্রোমোসোম ও জিনের আচরণ — ভিন্ন ক্রোমোসোম বনাম সংযুক্ত
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.crossingOver = Object.assign({
  t: 'ক্রসিংওভারের কৌশল', k: ['anim', 'steps'],
  cap: 'লাল ক্রোমোসোমে জিন A ও B (মাতৃ), নীলে a ও b (পিতৃ)। মাঝের দুটি নন-সিস্টার ক্রোমাটিড একই বিন্দুতে কেটে অংশ বদল করে — ফলে চারটি ক্রোমাটিডের দুটি নতুন সমন্বয় (Ab, aB) পায়।'
}, BK.steps({
  W: 380, H: 250, label: 'ক্রসিংওভার', dur: 3,
  stages: [
    { t: 'সিন্যাপসিস', en: 'Synapsis', d: 'জাইগোটিনে সমসংস্থ ক্রোমোসোম জিন বরাবর হুবহু পাশাপাশি জোড় বাঁধে।' },
    { t: 'টেট্রাড', en: 'Tetrad', d: 'প্যাকাইটিনে প্রতিটি ক্রোমোসোমের দুই ক্রোমাটিড স্পষ্ট — চারটি ক্রোমাটিড।' },
    { t: 'ভাঙন', en: 'Breakage', d: 'দুটি <b>নন-সিস্টার</b> ক্রোমাটিড A–B ও a–b-এর মাঝে একই বিন্দুতে <b>এন্ডোনিউক্লিয়েজে</b> কাটে।' },
    { t: 'বিনিময় ও জোড়া', en: 'Exchange & rejoining', d: 'কাটা অংশ আড়াআড়ি বদল হয়ে অপর ক্রোমাটিডে যুক্ত হয়; <b>লাইগেজ</b> জোড়া লাগায়। এই স্থানে পরে <b>কায়াজমা</b> দেখা যায়।' },
    { t: 'ফল — চার ক্রোমাটিড', en: 'Recombinants', d: 'পৃথক হওয়ার পর: <b>AB</b> ও <b>ab</b> (পিতামাতৃক) এবং <b>Ab</b> ও <b>aB</b> (রিকম্বিন্যান্ট) — নতুন জিন-সমন্বয়।' }
  ],
  draw(g, C, s, u) {
    const Rr = BK.ramp(4), Rb = BK.ramp(5), e = FK.ease(Math.min(1, u * 1.3));
    const y1 = 46, y2 = 196, yc = 121, yA = 76, yB = 166, w = 7;
    /* x অবস্থান: r1 r2 b1 b2 */
    let xs;
    if (s === 0) xs = [150, 150, 230 - 60 * e, 230 - 60 * e];
    else if (s <= 3) xs = [150, 162, 178, 190];
    else xs = [60, 140, 220, 300].map((x, i) => 150 + [0, 12, 28, 40][i] + (x - 150 - [0, 12, 28, 40][i]) * e);
    if (s === 0) xs = [146, 154, xs[2] + 16 - 4, xs[2] + 16 + 4];
    const swap = s === 3 ? e > .5 : s >= 4;
    const gap = s === 2 ? 6 * e : s === 3 ? 6 * (1 - e) : 0;
    /* প্রতিটি ক্রোমাটিড: উপরের অংশ ও নিচের অংশের রং ও জিন */
    const top = [[Rr, 'A'], [Rr, 'A'], [Rb, 'a'], [Rb, 'a']];
    const bot = [[Rr, 'B'], swap ? [Rb, 'b'] : [Rr, 'B'], swap ? [Rr, 'B'] : [Rb, 'b'], [Rb, 'b']];
    for (let i = 0; i < 4; i++) {
      const x = xs[i], cut = (i === 1 || i === 2) ? gap : 0;
      /* বিনিময়ের সময় নিচের অংশ পাশের দিকে সরে যায় */
      let bx = x;
      if (s === 3 && (i === 1 || i === 2)) { const other = xs[i === 1 ? 2 : 1]; bx = e < .5 ? x + (other - x) * e * 2 * .5 : other + (x - other) * (1 - (e - .5) * 2) * .5; bx = e < .5 ? x + (other - x) * e : x + (other - x) * (1 - e); }
      if (s === 3 && e > .5 && (i === 1 || i === 2)) bx = x;
      E('path', { d: `M${x} ${y1}V${yc - cut}`, stroke: top[i][0].c, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
      E('path', { d: `M${bx} ${yc + cut}V${y2}`, stroke: bot[i][0].c, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
      if (s !== 0 || i % 2 === 0) {
        T(g, x + (i < 2 ? -9 : 9), yA + 4, top[i][1], { fs: 12.5, a: i < 2 ? 'end' : 'start', w: 700, c: top[i][0].ink });
        T(g, bx + (i < 2 ? -9 : 9), yB + 4, bot[i][1], { fs: 12.5, a: i < 2 ? 'end' : 'start', w: 700, c: bot[i][0].ink });
      }
      E('circle', { cx: x, cy: yA, r: 2.6, fill: '#fff' }, g); E('circle', { cx: bx, cy: yB, r: 2.6, fill: '#fff' }, g);
    }
    if (s <= 3) [(xs[0] + xs[1]) / 2, (xs[2] + xs[3]) / 2].forEach(x => E('circle', { cx: x, cy: 60, r: 4.5, fill: C.fg }, g));
    if (s === 2) { const cx = (xs[1] + xs[2]) / 2; T(g, cx + 30, yc + 5, '✂ কাটা', { fs: 12, a: 'start', w: 650, c: C.fg }); E('path', { d: `M${xs[1] - 8} ${yc}H${xs[2] + 8}`, stroke: C.fg, 'stroke-width': 1.4, 'stroke-dasharray': '3 2' }, g); }
    if (s === 3 && e > .5) { const cx = (xs[1] + xs[2]) / 2; E('circle', { cx, cy: yc, r: 13, fill: 'none', stroke: BK.ramp(6).dk, 'stroke-width': 2 }, g); T(g, cx + 34, yc + 5, 'কায়াজমা', { fs: 12, a: 'start', w: 650, c: BK.ramp(6).ink }); }
    if (s === 4 && e > .6) {
      const lab = [['পিতামাতৃক', C.mu], ['রিকম্বিন্যান্ট', BK.ramp(6).ink], ['রিকম্বিন্যান্ট', BK.ramp(6).ink], ['পিতামাতৃক', C.mu]];
      xs.forEach((x, i) => T(g, x, 222, lab[i][0], { fs: 10.5, a: 'middle', w: 600, c: lab[i][1] }));
    }
  }
}));
})();

/* ───────── জিনের দূরত্ব ও রিকম্বিনেশন ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
V.linkageMap = Object.assign({
  t: 'জিনের দূরত্ব ও রিকম্বিনেশন', k: ['2d', 'anim', 'int'],
  cap: 'স্লাইডারে জিন A ও B-এর দূরত্ব (cM) বদলাও। নিচের ১০০টি বিন্দু ১০০টি গ্যামেট: ধূসর = পিতামাতৃক (AB বা ab), কমলা = রিকম্বিন্যান্ট (Ab বা aB)। দূরত্ব বাড়লে রিকম্বিন্যান্ট বাড়ে — কিন্তু ৫০%-এর বেশি কখনো নয়।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    ${FK.sl('d', 'দূরত্ব (cM)', 1, 150, 1, 15, '')}
    <div class="bk-info" data-k="calc" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 250;
    let d = 15, svg, chrG, dots = [], order = [], reveal = 1;
    for (let i = 0; i < 100; i++) order.push(i);
    const shuffle = () => { for (let i = 99; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; } };
    shuffle();
    /* হ্যালডেনের ম্যাপিং ফাংশন: r = ৫০(১ − e^(−২d/১০০)) */
    const rf = () => Math.round(50 * (1 - Math.exp(-2 * d / 100)));
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'রিকম্বিনেশন অনুকরণ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      chrG = E('g', {}, svg);
      dots = [];
      for (let i = 0; i < 100; i++) { const r = Math.floor(i / 20), c = i % 20; dots.push(E('circle', { cx: 32 + c * 15, cy: 136 + r * 22, r: 5.5, fill: FK.alpha(C.mu, .35) }, svg)); }
      T(svg, 24, 120, '১০০টি গ্যামেট', { fs: 11.5, w: 600, c: C.mu });
      paint();
    };
    const paint = () => {
      const C = FK.P(), Rr = BK.ramp(4), Rb = BK.ramp(5); chrG.innerHTML = '';
      const L = 300, x0 = 30, bx = x0 + 20 + Math.min(1, d / 150) * (L - 40);
      E('rect', { x: x0, y: 30, width: L, height: 14, rx: 7, fill: FK.alpha(Rr.c, .8) }, chrG);
      E('rect', { x: x0, y: 52, width: L, height: 14, rx: 7, fill: FK.alpha(Rb.c, .8) }, chrG);
      [[x0 + 20, 'A', 'a'], [bx, 'B', 'b']].forEach(([x, u1, l1]) => { E('path', { d: `M${x} 28V68`, stroke: '#fff', 'stroke-width': 3 }, chrG); T(chrG, x, 22, u1, { fs: 13, a: 'middle', w: 700, c: Rr.ink }); T(chrG, x, 82, l1, { fs: 13, a: 'middle', w: 700, c: Rb.ink }); });
      E('path', { d: `M${x0 + 20} 92H${bx}`, stroke: C.fg, 'stroke-width': 1.2 }, chrG);
      T(chrG, Math.max(x0 + 40, (x0 + 20 + bx) / 2), 106, `${d} cM`, { fs: 11, a: 'middle', w: 650, c: C.fg });
      const r = rf(), set = new Set(order.slice(0, r)), shown = Math.floor(reveal * 100), Ro = BK.ramp(2);
      dots.forEach((c, i) => { const vis = i < shown; c.setAttribute('fill', !vis ? FK.alpha(C.mu, .12) : set.has(i) ? Ro.c : FK.alpha(C.mu, .45)); });
      $('calc').innerHTML = `রিকম্বিন্যান্ট ≈ <b>${r}</b>টি (${r}%) · পিতামাতৃক ≈ <b>${100 - r}</b>টি`
        + `<div class="small">${d <= 10 ? 'কাছের জিন: রিকম্বিনেশন % ≈ দূরত্ব (cM)।' : d < 100 ? 'দূরত্ব বাড়লে দ্বৈত ক্রসিংওভার কিছু বিনিময় উল্টে দেয় — তাই % দূরত্বের চেয়ে একটু কম।' : 'অনেক দূরের জিন প্রায় ৫০% — যেন ভিন্ন ক্রোমোসোমে, স্বাধীন বিন্যাস।'}</div>`;
    };
    FK.bindSl(root, 'd', v => { d = Math.round(v); shuffle(); reveal = 0; if (svg) paint(); }, '', 0);
    build();
    const A = X.anim(root, dt => { if (reveal < 1) { reveal = Math.min(1, reveal + dt * 1.4); paint(); } }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── ক্রোমোসোম ও জিনের আচরণ ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const MODES = [['u', 'ভিন্ন ক্রোমোসোমে'], ['l', 'একই ক্রোমোসোমে']];
V.chromoGene = Object.assign({
  t: 'ক্রোমোসোম ও জিন — একই আচরণ', k: ['2d', 'anim', 'int'],
  cap: 'AaBb উদ্ভিদের মেটাফেজ-১। জিন দুটি <b>ভিন্ন ক্রোমোসোমে</b> থাকলে দুই রকম সাজানো সমান সম্ভাব্য → চার রকম গ্যামেট ১ : ১ : ১ : ১ (মেন্ডেলের স্বাধীন বিন্যাস)। <b>একই ক্রোমোসোমে</b> থাকলে কেবল দুই রকম (সংযুক্তি)।',
  html: () => `<div class="fk-row">${X.seg('md', MODES, 'u')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="bk-info" data-k="note" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 240;
    let mode = 'u', t = 0, svg, hl;
    const chr = (g, x, y, len, col, labs, C) => {
      [-3.2, 3.2].forEach(o => E('path', { d: `M${x + o} ${y - len / 2}V${y + len / 2}`, stroke: col.c, 'stroke-width': 5.5, 'stroke-linecap': 'round' }, g));
      E('circle', { cx: x, cy: y, r: 3.2, fill: C.fg }, g);
      labs.forEach(([dy, l]) => T(g, x + 12, y + dy + 4, l, { fs: 12.5, a: 'start', w: 700, c: col.ink }));
    };
    const build = () => {
      const C = FK.P(), Rr = BK.ramp(4), Rb = BK.ramp(5); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'ক্রোমোসোম ও জিনের বিন্যাস' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      hl = E('rect', { x: 8, y: 8, width: 168, height: 150, rx: 10, fill: FK.alpha(BK.ramp(6).c, .14), stroke: BK.ramp(6).dk, 'stroke-width': 1.5 }, svg);
      const panels = mode === 'u' ? [[92, 'সাজানো ১', [['A', 'B'], ['a', 'b']], ['AB', 'ab']], [268, 'সাজানো ২', [['A', 'b'], ['a', 'B']], ['Ab', 'aB']]] : [[92, 'সাজানো (একমাত্র)', [['A', 'B'], ['a', 'b']], ['AB', 'ab']]];
      panels.forEach(([cx, title, sides, gams]) => {
        T(svg, cx, 26, title, { fs: 12, a: 'middle', w: 650, c: C.fg });
        E('path', { d: `M${cx} 36V150`, stroke: FK.alpha(C.mu, .4), 'stroke-dasharray': '4 4' }, svg);
        if (mode === 'u') {
          /* জোড়া ১ (A/a) উপরে, জোড়া ২ (B/b) নিচে; বাম = মেরু ১ */
          const leftA = sides[0][0] === 'A', leftB = sides[0][1] === 'B';
          chr(svg, cx - 22, 66, 40, leftA ? Rr : Rb, [[0, leftA ? 'A' : 'a']], C); chr(svg, cx + 14, 66, 40, leftA ? Rb : Rr, [[0, leftA ? 'a' : 'A']], C);
          chr(svg, cx - 22, 122, 34, leftB ? Rr : Rb, [[0, leftB ? 'B' : 'b']], C); chr(svg, cx + 14, 122, 34, leftB ? Rb : Rr, [[0, leftB ? 'b' : 'B']], C);
        } else {
          chr(svg, cx - 22, 94, 92, Rr, [[-24, 'A'], [24, 'B']], C); chr(svg, cx + 14, 94, 92, Rb, [[-24, 'a'], [24, 'b']], C);
        }
        gams.forEach((gm, i) => { const gx = cx + (i ? 36 : -36); E('circle', { cx: gx, cy: 192, r: 20, fill: FK.alpha(BK.ramp(10).lt, .7), stroke: BK.ramp(10).dk, 'stroke-width': 1.6 }, svg); T(svg, gx, 197, gm, { fs: 13, a: 'middle', w: 700, c: BK.ramp(10).ink }); });
      });
      if (mode === 'l') { T(svg, 268, 90, 'A ও B একই', { fs: 12.5, a: 'middle', w: 600, c: C.mu }); T(svg, 268, 108, 'ক্রোমোসোমে বাঁধা —', { fs: 12.5, a: 'middle', w: 600, c: C.mu }); T(svg, 268, 126, 'আলাদা হতে পারে না', { fs: 12.5, a: 'middle', w: 600, c: C.mu }); }
      $('note').innerHTML = mode === 'u'
        ? 'গ্যামেট: <b>AB : Ab : aB : ab = ১ : ১ : ১ : ১</b>। অ্যানাফেজ-১ এ প্রতিটি জোড়া পৃথক = <b>পৃথকীকরণ সূত্র</b>; মেটাফেজ-১ এ জোড়াগুলোর স্বাধীন সাজানো = <b>স্বাধীন বিন্যাস সূত্র</b>।'
        : 'গ্যামেট প্রায় কেবল <b>AB ও ab (১ : ১)</b> — জিন দুটি <b>সংযুক্ত</b>। কেবল ক্রসিংওভার হলে অল্প কিছু Ab ও aB আসে।';
    };
    X.onSeg(root, 'md', v => { mode = v; t = 0; build(); });
    build();
    const A = X.anim(root, dt => { t += dt; if (!hl) return; if (mode === 'u') { const k = Math.floor(t / 1.6) % 2; hl.setAttribute('x', k ? 184 : 8); hl.setAttribute('opacity', .55 + .45 * Math.abs(Math.sin(t * 2))); } else { hl.setAttribute('x', 8); hl.setAttribute('opacity', .55 + .45 * Math.abs(Math.sin(t * 2))); } }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();
