/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §২.১
   amitosis    : অ্যামাইটোসিস — চার ধাপ
   checkpoints : কোষচক্রের চেকপয়েন্ট ও সাইক্লিন — স্বাভাবিক / DNA ক্ষতি / p53 অকেজো
   dnaAmount   : কোষচক্রে DNA-র পরিমাণ (C) ও ক্রোমাটিড — সময় টেনে দেখো
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.amitosis = Object.assign({
  t: 'অ্যামাইটোসিস — প্রত্যক্ষ বিভাজন', k: ['2d', 'anim'],
  cap: 'কোনো স্পিন্ডল নেই, ক্রোমোসোম দেখা যায় না, নিউক্লিয়ার পর্দা ভাঙে না — নিউক্লিয়াস লম্বা হয়ে মাঝে খাঁজ পড়ে (ডাম্বেল), তারপর সাইটোপ্লাজমও দুই ভাগ। ক্রোমাটিন কণাগুলো (বিন্দু) এলোমেলোভাবে দুই দিকে যায় — তাই বণ্টন অসম হতে পারে।'
}, BK.steps({
  W: 380, H: 230, label: 'অ্যামাইটোসিস', dur: 3,
  stages: [
    { t: 'স্বাভাবিক কোষ', en: 'Interphase cell', d: 'গোল নিউক্লিয়াস, ভেতরে ক্রোমাটিন ও নিউক্লিওলাস।' },
    { t: 'নিউক্লিয়াস লম্বা', en: 'Elongation', d: 'নিউক্লিয়াস ও কোষ দুটিই লম্বাটে হয়; নিউক্লিওলাসও লম্বা হয়ে দুই ভাগ হতে থাকে।' },
    { t: 'খাঁজ — ডাম্বেল', en: 'Constriction', d: 'নিউক্লিয়াসের মাঝখানে খাঁজ পড়ে — <b>ডাম্বেল</b> আকৃতি। নিউক্লিয়ার পর্দা অক্ষত থাকে।' },
    { t: 'দুই নিউক্লিয়াস', en: 'Nuclear division', d: 'খাঁজ গভীর হয়ে দুটি অপত্য নিউক্লিয়াস; কোষঝিল্লিতেও খাঁজ পড়তে থাকে।' },
    { t: 'দুই অপত্য কোষ', en: 'Cytoplasmic division', d: 'সাইটোপ্লাজম দুই ভাগ — দুটি অপত্য কোষ। ক্রোমাটিন কণার সংখ্যা দুই কোষে সমান না-ও হতে পারে।' }
  ],
  draw(g, C, s, u) {
    const Rc = BK.org('cyto'), Rm = BK.org('mem'), Rn = BK.org('nucleus'), Rch = BK.ramp(4), Rno = BK.ramp(3);
    const e = FK.ease(Math.min(1, u * 1.3));
    /* অগ্রগতি p: 0 → 4 */
    const p = s + (s === 0 ? 0 : e) - (s === 0 ? 0 : 1) + (s === 0 ? 0 : 0);
    const P = s === 0 ? 0 : (s - 1) + e;          /* 0..4 */
    const cy = 112, cx = 190;
    const sep = Math.max(0, P - 2) / 2;            /* কোষ বিভাজন 0..1 (ধাপ ৩-৪) */
    const nsep = Math.min(1, Math.max(0, P - 1) / 2); /* নিউক্লিয়াস বিভাজন 0..1 */
    const elong = Math.min(1, P);                  /* লম্বা হওয়া */
    /* কোষ */
    const cw = 90 + 40 * elong + 30 * sep, ch = 70 - 6 * elong, pinch = sep;
    const cell = `M${cx - cw} ${cy}C${cx - cw} ${cy - ch * 1.3} ${cx - 20} ${cy - ch * (1 - pinch * .95)} ${cx} ${cy - ch * (1 - pinch * .98)}C${cx + 20} ${cy - ch * (1 - pinch * .95)} ${cx + cw} ${cy - ch * 1.3} ${cx + cw} ${cy}C${cx + cw} ${cy + ch * 1.3} ${cx + 20} ${cy + ch * (1 - pinch * .95)} ${cx} ${cy + ch * (1 - pinch * .98)}C${cx - 20} ${cy + ch * (1 - pinch * .95)} ${cx - cw} ${cy + ch * 1.3} ${cx - cw} ${cy}Z`;
    E('path', { d: cell, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 3 }, g);
    /* নিউক্লিয়াস */
    const nw = 34 + 30 * elong + 30 * nsep, nh = 30 - 4 * elong, np = nsep;
    if (np < .98) {
      const nd = `M${cx - nw} ${cy}C${cx - nw} ${cy - nh * 1.3} ${cx - 12} ${cy - nh * (1 - np)} ${cx} ${cy - nh * (1 - np)}C${cx + 12} ${cy - nh * (1 - np)} ${cx + nw} ${cy - nh * 1.3} ${cx + nw} ${cy}C${cx + nw} ${cy + nh * 1.3} ${cx + 12} ${cy + nh * (1 - np)} ${cx} ${cy + nh * (1 - np)}C${cx - 12} ${cy + nh * (1 - np)} ${cx - nw} ${cy + nh * 1.3} ${cx - nw} ${cy}Z`;
      E('path', { d: nd, fill: FK.alpha(Rn.lt || Rn.c, .7), stroke: Rn.dk || Rn.c, 'stroke-width': 2.4 }, g);
    } else {
      [-1, 1].forEach(k => E('ellipse', { cx: cx + k * (nw - 26), cy, rx: 26, ry: 24, fill: FK.alpha(Rn.lt || Rn.c, .7), stroke: Rn.dk || Rn.c, 'stroke-width': 2.4 }, g));
    }
    /* ক্রোমাটিন কণা — ইচ্ছাকৃত অসম: বাঁয়ে ৭, ডানে ৫ */
    const pts = [[-.7, -.3], [-.5, .4], [-.3, -.5], [-.2, .1], [-.6, .05], [-.35, .55], [-.15, -.2], [.25, -.4], [.45, .3], [.6, -.1], [.3, .5], [.7, .25]];
    pts.forEach(([a, b]) => E('circle', { cx: cx + a * (nw - 8), cy: cy + b * nh * .8, r: 3, fill: Rch.c }, g));
    /* নিউক্লিওলাস */
    if (nsep < .5) E('ellipse', { cx, cy, rx: 7 + 10 * elong, ry: 7, fill: Rno.c, opacity: .8 }, g);
    else [-1, 1].forEach(k => E('circle', { cx: cx + k * (nw - 26), cy: cy - 2, r: 6, fill: Rno.c, opacity: .8 }, g));
    if (s === 2) T(g, cx, 32, 'ডাম্বেল আকৃতি', { fs: 13, a: 'middle', w: 600, c: Rn.ink || C.fg });
    if (s === 4) { T(g, cx - 80, 206, 'কণা ৭টি', { fs: 12.5, a: 'middle', w: 600, c: Rch.ink }); T(g, cx + 80, 206, 'কণা ৫টি', { fs: 12.5, a: 'middle', w: 600, c: Rch.ink }); }
    T(g, 16, 22, 'স্পিন্ডল নেই', { fs: 12, w: 600, c: C.mu });
  }
}));
})();

/* ───────── ২. চেকপয়েন্ট ও সাইক্লিন ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* দশার সীমা (০–১ চক্র): G1 0–.46, S .46–.79, G2 .79–.96, M .96–1 */
const PH = [['G1', 0, .46, 10], ['S', .46, .79, 5], ['G2', .79, .96, 3], ['M', .96, 1, 4]];
const CK = [{ at: .40, n: 'G1', d: 'আকার, পুষ্টি ও DNA ঠিক আছে?' }, { at: .93, n: 'G2', d: 'সব DNA কপি হয়েছে, ক্ষতি নেই?' }, { at: .985, n: 'M', d: 'সব ক্রোমোসোম স্পিন্ডলে যুক্ত?' }];
const MODES = [['ok', 'স্বাভাবিক'], ['dmg', 'DNA ক্ষতি'], ['p53', 'ক্ষতি + p53 অকেজো']];
const NOTE = {
  ok: 'সব চেকপয়েন্টে "সবুজ সংকেত" — চক্র ঘুরছে। নিচে দেখো সাইক্লিনের পরিমাণ: <b>সাইক্লিন E</b> G1→S-এ, <b>সাইক্লিন B</b> (MPF) G2→M-এ চূড়ায় ওঠে, তারপর ভেঙে যায়।',
  dmg: 'DNA-তে ক্ষতি! <b>p53</b> সক্রিয় হয়ে G1 চেকপয়েন্টে চক্র <b>থামিয়ে</b> দিয়েছে — মেরামত চলছে। মেরামত না হলে কোষটি অ্যাপোপটোসিসে মারা যাবে। এটাই সুস্থ কোষের প্রতিরক্ষা।',
  p53: 'ক্ষতি আছে, কিন্তু p53 অকেজো — চেকপয়েন্ট কাজ করছে না, তাই ক্ষতিগ্রস্ত DNA নিয়েই চক্র ঘুরছে আর <b>মিউটেশন</b> জমছে (লাল বিন্দু)। এভাবেই ক্যানসার কোষ তৈরি হয়।'
};
V.checkpoints = Object.assign({
  t: 'কোষচক্রের চেকপয়েন্ট ও সাইক্লিন', k: ['2d', 'anim', 'int'],
  cap: 'বিন্দুটি কোষচক্রে ঘুরছে; তিনটি চেকপয়েন্টে (রঙিন দাগ) যাচাই হয়। পরিস্থিতি বদলে দেখো — DNA ক্ষতিতে p53 চক্র থামায়; p53 অকেজো হলে থামে না।',
  html: () => `<div class="fk-row">${X.seg('md', MODES, 'ok')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="bk-info" data-k="note" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 330, CX = 112, CY = 112, R = 78;
    let mode = 'ok', ph = 0, muts = 0, svg, dot, cur, mutG, stopG;
    const ang = f => (f * 360 - 90) * FK.D, pt = (f, r) => [CX + r * Math.cos(ang(f)), CY + r * Math.sin(ang(f))];
    /* সাইক্লিন বক্ররেখা */
    const cycE = f => Math.exp(-Math.pow((f - .44) / .07, 2));
    const cycB = f => f < .5 ? 0 : f < .97 ? Math.pow((f - .5) / .47, 2) : Math.max(0, 1 - (f - .97) / .02);
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'কোষচক্রের চেকপয়েন্ট' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      PH.forEach(([n, a, b, r]) => {
        const Rr = BK.ramp(r), [x1, y1] = pt(a, R), [x2, y2] = pt(b, R), big = b - a > .5 ? 1 : 0;
        E('path', { d: `M${x1} ${y1}A${R} ${R} 0 ${big} 1 ${x2} ${y2}`, fill: 'none', stroke: Rr.c, 'stroke-width': 22 }, svg);
        const [tx, ty] = pt((a + b) / 2, R); if (n !== 'M') T(svg, tx, ty + 4.5, n, { fs: 12.5, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
        else { const [mx, my] = pt(.98, R + 24); T(svg, mx, my + 4, 'M', { fs: 12.5, a: 'middle', w: 700, c: Rr.ink }); }
      });
      CK.forEach((k, i) => {
        const [x1, y1] = pt(k.at, R - 16), [x2, y2] = pt(k.at, R + 16);
        E('path', { d: `M${x1} ${y1}L${x2} ${y2}`, stroke: BK.ramp(4).dk, 'stroke-width': 3.5, 'stroke-linecap': 'round' }, svg);
      });
      /* চেকপয়েন্ট তালিকা */
      CK.forEach((k, i) => { T(svg, 214, 36 + i * 44, `<tspan font-weight="700">${k.n}</tspan> চেকপয়েন্ট`, { fs: 12.5, w: 600, c: BK.ramp(4).ink }); T(svg, 214, 52 + i * 44, k.d, { fs: 10.5, w: 520, c: C.mu }); });
      T(svg, CX, CY - 4, 'কোষচক্র', { fs: 12, a: 'middle', w: 600, c: C.mu });
      stopG = E('g', {}, svg); mutG = E('g', {}, svg);
      dot = E('circle', { r: 9, fill: C.fg, stroke: '#fff', 'stroke-width': 2 }, svg);
      /* সাইক্লিন লেখচিত্র */
      const GX = 28, GY = 300, GW = 310, GH = 80;
      E('path', { d: `M${GX} ${GY}H${GX + GW}`, stroke: C.mu, 'stroke-width': 1.4 }, svg);
      PH.forEach(([n, a, b, r]) => { E('rect', { x: GX + a * GW, y: GY + 2, width: (b - a) * GW, height: 6, fill: BK.ramp(r).c }, svg); });
      T(svg, GX, GY - GH - 8, 'সাইক্লিনের পরিমাণ', { fs: 11, w: 600, c: C.mu });
      [[cycE, BK.ramp(2), 'সাইক্লিন E', .44], [cycB, BK.ramp(5), 'সাইক্লিন B', .86]].forEach(([fn, Rr, lab, lx]) => {
        const d = []; for (let i = 0; i <= 100; i++) { const f = i / 100; d.push(`${i ? 'L' : 'M'}${GX + f * GW} ${GY - fn(f) * GH}`); }
        E('path', { d: d.join(''), fill: 'none', stroke: Rr.c, 'stroke-width': 2.6 }, svg);
        T(svg, GX + lx * GW, GY - fn(lx) * GH - 6, lab, { fs: 11, a: 'middle', w: 650, c: Rr.ink });
      });
      cur = E('path', { stroke: C.fg, 'stroke-width': 1.4, 'stroke-dasharray': '3 3' }, svg);
      paintMode();
    };
    const paintMode = () => {
      const C = FK.P(); stopG.innerHTML = ''; mutG.innerHTML = '';
      if (mode === 'dmg') { const [x, y] = pt(CK[0].at, R - 36); E('circle', { cx: x, cy: y, r: 15, fill: BK.ramp(4).c }, stopG); T(stopG, x, y + 4, 'থামো', { fs: 9, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' }); }
      $('note').innerHTML = NOTE[mode];
    };
    const tick = dt => {
      const stopAt = CK[0].at - .012;
      if (mode === 'dmg' && ph < stopAt && ph + dt * .12 >= stopAt) ph = stopAt;
      else if (!(mode === 'dmg' && Math.abs(ph - stopAt) < 1e-6)) {
        const prev = ph; ph = (ph + dt * .12) % 1;
        if (mode === 'p53' && prev > ph) { muts = Math.min(14, muts + 2); const Rr = BK.ramp(4); for (let i = 0; i < 2; i++) { const a = Math.random() * 6.28, r = 14 + Math.random() * 34; E('circle', { cx: CX + r * Math.cos(a), cy: CY + 14 + r * Math.sin(a) * .6, r: 3, fill: Rr.c }, mutG); } }
      }
      const [x, y] = pt(ph, R); dot.setAttribute('cx', x); dot.setAttribute('cy', y);
      cur.setAttribute('d', `M${28 + ph * 310} 300V212`);
    };
    X.onSeg(root, 'md', v => { mode = v; muts = 0; if (mode !== 'dmg' && ph > CK[0].at - .02 && ph < CK[0].at) ph += .02; paintMode(); });
    build(); tick(0);
    const A = X.anim(root, tick, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── ৩. DNA-র পরিমাণ ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
/* t: 0–100 → দশা; DNA (C একক) */
const dna = t => t < 46 ? 2 : t < 79 ? 2 + 2 * (t - 46) / 33 : t < 98 ? 4 : 2;
const phase = t => t < 46 ? ['G1', 'কোষ বাড়ছে; প্রতিটি ক্রোমোসোমে একটি ক্রোমাটিড'] : t < 79 ? ['S', 'DNA রেপ্লিকেশন চলছে — DNA বাড়ছে, ক্রোমোসোম সংখ্যা একই'] : t < 96 ? ['G2', 'প্রতিটি ক্রোমোসোমে দুটি সিস্টার ক্রোমাটিড'] : t < 98 ? ['M', 'মাইটোসিস — ক্রোমাটিড আলাদা হচ্ছে'] : ['M শেষ', 'প্রতিটি অপত্য কোষে আবার 2C'];
V.dnaAmount = Object.assign({
  t: 'কোষচক্রে DNA-র পরিমাণ', k: ['2d', 'anim', 'int'],
  cap: 'উদাহরণ কোষ 2n = 4। স্লাইডার টেনে সময় বদলাও — লেখচিত্রে DNA-র পরিমাণ (C) আর ডানে একটি ক্রোমোসোমের অবস্থা দেখো। লক্ষ করো: DNA দ্বিগুণ হয় S দশায়, কিন্তু ক্রোমোসোম সংখ্যা সবসময় 4।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    ${FK.sl('t', 'চক্রের সময় (%)', 0, 100, 1, 30, '')}
    <div class="bk-info" data-k="calc" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 220, GX = 34, GY = 180, GW = 210, GH = 120;
    let svg, cur, chrG, t = 30, ph = 0;
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'DNA-র পরিমাণের লেখচিত্র' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      [['G1', 0, 46, 10], ['S', 46, 79, 5], ['G2', 79, 96, 3], ['M', 96, 100, 4]].forEach(([n, a, b, r]) => {
        E('rect', { x: GX + a / 100 * GW, y: GY - GH - 6, width: (b - a) / 100 * GW, height: GH + 6, fill: FK.alpha(BK.ramp(r).c, .12) }, svg);
        T(svg, GX + (a + b) / 200 * GW, GY + 16, n, { fs: 11.5, a: 'middle', w: 650, c: BK.ramp(r).ink });
      });
      E('path', { d: `M${GX} ${GY - GH - 6}V${GY}H${GX + GW}`, stroke: C.mu, 'stroke-width': 1.6, fill: 'none' }, svg);
      [2, 4].forEach(c => { const y = GY - c / 4 * GH; E('path', { d: `M${GX - 4} ${y}H${GX + GW}`, stroke: FK.alpha(C.mu, .3), 'stroke-dasharray': '3 3' }, svg); T(svg, GX - 8, y + 4, c + 'C', { fs: 11, a: 'end', w: 650, c: C.mu }); });
      const d = []; for (let i = 0; i <= 100; i++) d.push(`${i ? 'L' : 'M'}${GX + i / 100 * GW} ${GY - dna(i) / 4 * GH}`);
      E('path', { d: d.join(''), fill: 'none', stroke: BK.ramp(5).c, 'stroke-width': 3 }, svg);
      T(svg, GX, 16, 'DNA (C)', { fs: 11, w: 600, c: C.mu });
      cur = E('g', {}, svg); chrG = E('g', {}, svg);
      E('rect', { x: 262, y: 30, width: 86, height: 150, rx: 10, fill: FK.alpha(C.mu, .06), stroke: FK.alpha(C.mu, .25) }, svg);
      paint();
    };
    const paint = () => {
      const C = FK.P(); cur.innerHTML = ''; chrG.innerHTML = '';
      const x = GX + t / 100 * GW, y = GY - dna(t) / 4 * GH, Rr = BK.ramp(4);
      E('path', { d: `M${x} ${GY}V${y}`, stroke: C.fg, 'stroke-width': 1.2, 'stroke-dasharray': '3 3' }, cur);
      E('circle', { cx: x, cy: y, r: 6 + Math.sin(ph) * 1.5, fill: BK.ramp(5).c, stroke: '#fff', 'stroke-width': 2 }, cur);
      /* ক্রোমোসোম চিত্র */
      const cx = 305, cy = 104, sTwo = t < 46 ? 0 : t < 79 ? (t - 46) / 33 : 1, after = t >= 98;
      if (!after) {
        const off = 7 * sTwo, cond = t >= 96 ? .6 : 1, L = 56 * cond;
        E('path', { d: `M${cx - off} ${cy - L}V${cy + L}`, stroke: Rr.c, 'stroke-width': t >= 96 ? 9 : 5, 'stroke-linecap': 'round' }, chrG);
        if (sTwo > 0) E('path', { d: `M${cx + off} ${cy - L * sTwo}V${cy + L * sTwo}`, stroke: Rr.c, 'stroke-width': t >= 96 ? 9 : 5, 'stroke-linecap': 'round', opacity: .5 + .5 * sTwo }, chrG);
        E('circle', { cx, cy, r: 5, fill: C.fg }, chrG);
        T(chrG, cx, 172, sTwo >= 1 ? '২ ক্রোমাটিড' : sTwo > 0 ? 'কপি হচ্ছে' : '১ ক্রোমাটিড', { fs: 11, a: 'middle', w: 600, c: Rr.ink });
      } else {
        [-18, 18].forEach(dx => { E('path', { d: `M${cx + dx} ${cy - 40}V${cy + 40}`, stroke: Rr.c, 'stroke-width': 5, 'stroke-linecap': 'round' }, chrG); E('circle', { cx: cx + dx, cy, r: 4, fill: C.fg }, chrG); });
        T(chrG, cx, 172, 'দুই কোষে ১টি করে', { fs: 10.5, a: 'middle', w: 600, c: Rr.ink });
      }
      T(chrG, cx, 46, 'একটি ক্রোমোসোম', { fs: 10, a: 'middle', w: 560, c: C.mu });
    };
    const calc = v => {
      t = v; paint();
      const [p, d] = phase(t), c = dna(t), chromatids = t < 46 ? 4 : t < 79 ? '4 → 8' : t < 98 ? 8 : 4;
      $('calc').innerHTML = `<b>${p}</b> — ${d}`
        + `<div class="small">DNA = <b>${c.toFixed(1)}C</b> · ক্রোমোসোম = <b>4</b> · ক্রোমাটিড = <b>${chromatids}</b></div>`;
    };
    FK.bindSl(root, 't', calc, '', 0);
    build(); calc(30);
    const A = X.anim(root, dt => { ph += dt * 4; const c = cur && cur.lastChild; if (c) c.setAttribute('r', 6 + Math.sin(ph) * 1.5); }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();
