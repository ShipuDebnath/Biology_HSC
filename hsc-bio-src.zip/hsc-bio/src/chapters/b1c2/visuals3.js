/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §২.৩ মায়োসিস
   meiosis    : মায়োসিস-১ ও ২ — ৮ ধাপ (2n = 4, লাল = মাতৃ, নীল = পিতৃ, ক্রসিংওভারসহ)
   prophase1  : প্রোফেজ-১ এর পাঁচ উপদশা — একটি সমসংস্থ জোড়ার কাছ থেকে দেখা
   assortment : স্বাধীন বিন্যাস — n বদলাও, গ্যামেট ও জাইগোট-সমন্বয় গোনো
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const lerp = (a, b, u) => a + (b - a) * u;
/* একটি ক্রোমাটিড: [ডগার রং, দেহের রং]; ori 'v' খাড়া (ডগা উপরে), 'h' আড়াআড়ি (ডগা বাঁয়ে) */
const chromatid = (g, x, y, len, ori, col, w) => {
  const tip = len * .34;
  if (ori === 'v') {
    E('path', { d: `M${x} ${y - len / 2}V${y - len / 2 + tip}`, stroke: col[0], 'stroke-width': w, 'stroke-linecap': 'round' }, g);
    E('path', { d: `M${x} ${y - len / 2 + tip}V${y + len / 2}`, stroke: col[1], 'stroke-width': w, 'stroke-linecap': 'round' }, g);
  } else {
    E('path', { d: `M${x - len / 2} ${y}H${x - len / 2 + tip}`, stroke: col[0], 'stroke-width': w, 'stroke-linecap': 'round' }, g);
    E('path', { d: `M${x - len / 2 + tip} ${y}H${x + len / 2}`, stroke: col[1], 'stroke-width': w, 'stroke-linecap': 'round' }, g);
  }
};
/* ক্রোমোসোম = ১ বা ২ ক্রোমাটিড */
const chromo = (g, x, y, len, ori, cts, C, w = 5.5) => {
  const off = cts.length === 2 ? w * .62 : 0;
  cts.forEach((col, i) => { const d = (i ? 1 : -1) * off; ori === 'v' ? chromatid(g, x + d, y, len, ori, col, w) : chromatid(g, x, y + d, len, ori, col, w); });
  E('circle', { cx: x, cy: y, r: w * .55, fill: C.fg }, g);
};
V.meiosis = Object.assign({
  t: 'মায়োসিস: ধাপে ধাপে', k: ['anim', 'steps', 'int'],
  cap: 'উদাহরণ কোষে 2n = 4 — একটি লম্বা ও একটি খাটো সমসংস্থ জোড়া (লাল = মাতৃ, নীল = পিতৃ)। লম্বা জোড়ায় ক্রসিংওভার হয়ে ডগার রং বদলায়। শেষে চারটি কোষ, প্রতিটি n = 2 — এবং চারটিই আলাদা।'
}, BK.steps({
  W: 380, H: 250, label: 'মায়োসিস', dur: 3,
  stages: [
    { t: 'ইন্টারফেজ', en: 'Interphase', d: 'S দশায় DNA রেপ্লিকেশন হয়েছে — প্রতিটি ক্রোমোসোমে দুটি সিস্টার ক্রোমাটিড। ক্রোমাটিন এখনো সরু।' },
    { t: 'প্রোফেজ-১', en: 'Prophase I', d: 'সমসংস্থ ক্রোমোসোম জোড় বাঁধে (<b>সিন্যাপসিস</b>) — বাইভ্যালেন্ট। লম্বা জোড়ায় নন-সিস্টার ক্রোমাটিডের মধ্যে <b>ক্রসিংওভার</b>: ডগার অংশ বিনিময়।' },
    { t: 'মেটাফেজ-১', en: 'Metaphase I', d: 'বাইভ্যালেন্টগুলো বিষুবতলে <b>দুই সারিতে</b>; প্রতিটি জোড়ার দুই সদস্য বিপরীত মেরুমুখী। খাটো জোড়াটি উল্টো দিকে মুখ করেছে — <b>স্বাধীন বিন্যাস</b>।' },
    { t: 'অ্যানাফেজ-১', en: 'Anaphase I', d: '<b>সমসংস্থ ক্রোমোসোম</b> আলাদা হয়ে বিপরীত মেরুতে; সেন্ট্রোমিয়ার অক্ষত — প্রতিটি দুই ক্রোমাটিডসহ। এখানেই 2n → n।' },
    { t: 'টেলোফেজ-১', en: 'Telophase I', d: 'দুটি হ্যাপ্লয়েড কোষ (n = 2), প্রতিটি ক্রোমোসোমে এখনো দুটি ক্রোমাটিড। এরপর ইন্টারকাইনেসিস — <b>DNA রেপ্লিকেশন হয় না</b>।' },
    { t: 'মেটাফেজ-২', en: 'Metaphase II', d: 'প্রতিটি কোষে নতুন স্পিন্ডল (আগেরটির সমকোণে); ক্রোমোসোম বিষুবতলে <b>এক সারিতে</b> — মাইটোসিসের মতো।' },
    { t: 'অ্যানাফেজ-২', en: 'Anaphase II', d: '<b>সেন্ট্রোমিয়ার বিভক্ত</b> হয়; সিস্টার ক্রোমাটিড আলাদা হয়ে বিপরীত মেরুতে যায়।' },
    { t: 'টেলোফেজ-২', en: 'Telophase II', d: 'চারটি হ্যাপ্লয়েড কোষ (n = 2), প্রতিটি ক্রোমোসোমে একটি ক্রোমাটিড। ক্রসিংওভার ও স্বাধীন বিন্যাসের ফলে <b>চারটিই জিনগতভাবে আলাদা</b>।' }
  ],
  draw(g, C, s, u) {
    const Rr = BK.ramp(4).c, Rb = BK.ramp(5).c, Rc = BK.org('cyto'), Rm = BK.org('mem'), Rn = BK.org('nucleus');
    const e = FK.ease(Math.min(1, u * 1.3));
    const X = s === 1 ? e : s > 1 ? 1 : 0;           /* ক্রসিংওভার অগ্রগতি */
    const sw = X > .5;
    /* লম্বা জোড়ার চার ক্রোমাটিড (ক্রসিংওভারের পর b ও c-এর ডগা বদলায়) */
    const a = [Rr, Rr], b = [sw ? Rb : Rr, Rr], c = [sw ? Rr : Rb, Rb], d = [Rb, Rb];
    const sr = [[Rr, Rr], [Rr, Rr]], sb = [[Rb, Rb], [Rb, Rb]];
    const L = 64, S = 38;
    const cell = (cx, cy, rx, ry, pin) => {
      if (!pin) { E('ellipse', { cx, cy, rx, ry, fill: FK.alpha(Rc.lt || Rc.c, .45), stroke: Rm.c || Rm.dk, 'stroke-width': 2.6 }, g); return; }
      const p = pin * .96, dd = `M${cx - rx} ${cy}C${cx - rx} ${cy - ry * 1.3} ${cx - 18} ${cy - ry * (1 - p)} ${cx} ${cy - ry * (1 - p)}C${cx + 18} ${cy - ry * (1 - p)} ${cx + rx} ${cy - ry * 1.3} ${cx + rx} ${cy}C${cx + rx} ${cy + ry * 1.3} ${cx + 18} ${cy + ry * (1 - p)} ${cx} ${cy + ry * (1 - p)}C${cx - 18} ${cy + ry * (1 - p)} ${cx - rx} ${cy + ry * 1.3} ${cx - rx} ${cy}Z`;
      E('path', { d: dd, fill: FK.alpha(Rc.lt || Rc.c, .45), stroke: Rm.c || Rm.dk, 'stroke-width': 2.6 }, g);
    };
    const spindle = (x1, y1, x2, y2, pts) => pts.forEach(([px, py]) => { E('path', { d: `M${x1} ${y1}L${px} ${py}`, stroke: FK.alpha(C.mu, .45), 'stroke-width': 1 }, g); E('path', { d: `M${x2} ${y2}L${px} ${py}`, stroke: FK.alpha(C.mu, .45), 'stroke-width': 1 }, g); });
    if (s <= 3) {
      cell(190, 122, 168, 100, 0);
      if (s <= 1) E('circle', { cx: 190, cy: 122, r: 80, fill: s === 0 ? FK.alpha(Rn.lt || Rn.c, .35) : FK.alpha(Rn.lt || Rn.c, .35 * (1 - e)), stroke: Rn.dk || Rn.c, 'stroke-width': 2, 'stroke-dasharray': s === 1 ? '6 4' : 'none', opacity: s === 1 ? 1 - e * .7 : 1 }, g);
    }
    if (s === 0) {
      const wob = (x, y, col, len) => E('path', { d: `M${x} ${y - len / 2}q8 ${len / 4} 0 ${len / 2}t0 ${len / 2}`, stroke: col, 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round' }, g);
      wob(150, 105, Rr, L); wob(232, 130, Rb, L); wob(176, 150, Rr, S); wob(210, 92, Rb, S);
    } else if (s === 1) {
      const gap = lerp(40, 13, Math.min(1, e * 2));
      chromo(g, 150 - gap / 2, 120, L, 'v', [a, b], C); chromo(g, 150 + gap / 2, 120, L, 'v', [c, d], C);
      chromo(g, 232 - gap / 2, 124, S, 'v', sr, C); chromo(g, 232 + gap / 2, 124, S, 'v', sb, C);
      if (e > .3 && e < .75) E('path', { d: `M${150 - 4} ${120 - L / 2 + 6}L${150 + 4} ${120 - L / 2 + 20}M${150 + 4} ${120 - L / 2 + 6}L${150 - 4} ${120 - L / 2 + 20}`, stroke: C.fg, 'stroke-width': 2 }, g);
      T(g, 150, 46, 'ক্রসিংওভার', { fs: 12, a: 'middle', w: 650, c: C.fg });
    } else if (s === 2 || s === 3) {
      const dx = s === 3 ? 100 * e : 0;
      spindle(34, 122, 346, 122, [[178 - dx, 92], [202 + dx, 92], [178 - dx, 152], [202 + dx, 152]]);
      E('path', { d: 'M190 30V214', stroke: FK.alpha(C.mu, .35), 'stroke-dasharray': '5 4' }, g);
      /* লম্বা জোড়া: লাল বাঁয়ে; খাটো জোড়া: নীল বাঁয়ে (স্বাধীন বিন্যাস) */
      chromo(g, 178 - dx, 92, L, 'v', [a, b], C); chromo(g, 202 + dx, 92, L, 'v', [c, d], C);
      chromo(g, 178 - dx, 152, S, 'v', sb, C); chromo(g, 202 + dx, 152, S, 'v', sr, C);
      if (s === 2) T(g, 190, 236, 'বিষুবতল — দুই সারি', { fs: 12, a: 'middle', w: 600, c: C.mu });
    } else if (s === 4) {
      cell(190, 122, 168, 100, e);
      chromo(g, 80, 105, L, 'v', [a, b], C); chromo(g, 104, 132, S, 'v', sb, C);
      chromo(g, 276, 105, L, 'v', [c, d], C); chromo(g, 300, 132, S, 'v', sr, C);
      T(g, 92, 236, 'n = 2', { fs: 12.5, a: 'middle', w: 650, c: C.fg }); T(g, 288, 236, 'n = 2', { fs: 12.5, a: 'middle', w: 650, c: C.fg });
    } else if (s === 5 || s === 6) {
      const dy = s === 6 ? 46 * e : 0;
      [[96, [a, b], sb], [284, [c, d], sr]].forEach(([cx, lp, spr]) => {
        cell(cx, 122, 86, 104, 0);
        spindle(cx, 24, cx, 220, [[cx - 30, 122 - dy], [cx + 30, 122 - dy], [cx - 30, 122 + dy], [cx + 30, 122 + dy]].slice(0, 4));
        if (s === 5) { chromo(g, cx - 28, 122, 50, 'h', lp, C); chromo(g, cx + 32, 122, 30, 'h', spr, C); }
        else { chromo(g, cx - 28, 122 - dy, 50, 'h', [lp[0]], C); chromo(g, cx - 28, 122 + dy, 50, 'h', [lp[1]], C); chromo(g, cx + 32, 122 - dy, 30, 'h', [spr[0]], C); chromo(g, cx + 32, 122 + dy, 30, 'h', [spr[1]], C); }
      });
    } else {
      const cells = [[96, 66, a, sb[0]], [96, 178, b, sb[1]], [284, 66, c, sr[0]], [284, 178, d, sr[1]]];
      cells.forEach(([cx, cy, lc, sc], i) => {
        E('ellipse', { cx, cy, rx: 74, ry: 48, fill: FK.alpha(Rc.lt || Rc.c, .45), stroke: Rm.c || Rm.dk, 'stroke-width': 2.4 }, g);
        chromo(g, cx - 18, cy, 50, 'h', [lc], C); chromo(g, cx + 34, cy, 30, 'h', [sc], C);
        T(g, cx - 60, cy - 30, 'ABCD'[i], { fs: 12, w: 700, c: C.mu });
      });
    }
  }
}));
})();

/* ───────── প্রোফেজ-১ ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
const lerp = (a, b, u) => a + (b - a) * u;
V.prophase1 = Object.assign({
  t: 'প্রোফেজ-১ — পাঁচ উপদশা', k: ['anim', 'steps'],
  cap: 'একটি সমসংস্থ জোড়া (লাল = মাতৃ, নীল = পিতৃ) কাছ থেকে দেখো: সরু সুতা থেকে জোড় বাঁধা, ক্রসিংওভার, কায়াজমা এবং শেষে কায়াজমার প্রান্তে সরে যাওয়া।'
}, BK.steps({
  W: 380, H: 240, label: 'প্রোফেজ-১', dur: 3.2,
  stages: [
    { t: 'লেপ্টোটিন', en: 'Leptotene', d: 'ক্রোমোসোম লম্বা, <b>সরু সুতার</b> মতো; গায়ে পুঁতির মতো <b>ক্রোমোমিয়ার</b>। সমসংস্থ দুটি এখনো দূরে।' },
    { t: 'জাইগোটিন', en: 'Zygotene', d: 'সমসংস্থ ক্রোমোসোম জিপারের মতো পাশাপাশি জোড় বাঁধে — <b>সিন্যাপসিস</b>; মাঝে <b>সিন্যাপটোনিমাল কমপ্লেক্স</b>। জোড়াটি = <b>বাইভ্যালেন্ট</b>।' },
    { t: 'প্যাকাইটিন', en: 'Pachytene', d: 'ক্রোমোসোম খাটো ও মোটা; চার ক্রোমাটিড স্পষ্ট (<b>টেট্রাড</b>)। নন-সিস্টার ক্রোমাটিডের মধ্যে <b>ক্রসিংওভার</b> — অংশ বিনিময়।' },
    { t: 'ডিপ্লোটিন', en: 'Diplotene', d: 'সিন্যাপটোনিমাল কমপ্লেক্স ভাঙে, সমসংস্থ ক্রোমোসোম সরে যেতে চায় — কিন্তু ক্রসিংওভারের স্থানে <b>X আকৃতির কায়াজমা</b> দিয়ে আটকে থাকে।' },
    { t: 'ডায়াকাইনেসিস', en: 'Diakinesis', d: 'ক্রোমোসোম সর্বাধিক ঘন; কায়াজমা প্রান্তের দিকে সরে যায় — <b>প্রান্তীয়করণ</b>। নিউক্লিওলাস ও নিউক্লিয়ার পর্দা মিলিয়ে যায়।' }
  ],
  draw(g, C, s, u) {
    const Rr = BK.ramp(4), Rb = BK.ramp(5), Rn = BK.org('nucleus'), Rno = BK.ramp(3);
    const e = FK.ease(Math.min(1, u * 1.3)), cx = 190, cy = 118;
    const fade = s === 4 ? 1 - e : 1;
    E('circle', { cx, cy, r: 100, fill: FK.alpha(Rn.lt || Rn.c, .28 * fade), stroke: Rn.dk || Rn.c, 'stroke-width': 2.4, 'stroke-dasharray': s === 4 ? '6 5' : 'none', opacity: .3 + .7 * fade }, g);
    E('circle', { cx: cx + 58, cy: cy - 52, r: 14 * fade + .1, fill: Rno.c, opacity: .75 * fade }, g);
    const len = s === 0 ? 150 : s === 1 ? 140 : s === 2 ? 118 : s === 3 ? 108 : 96;
    const w = s <= 1 ? 2.6 : 5;
    const y1 = cy - len / 2, y2 = cy + len / 2;
    if (s === 0) {
      [[cx - 46, Rr], [cx + 46, Rb]].forEach(([x, R]) => {
        E('path', { d: `M${x} ${y1}q10 ${len / 6} 0 ${len / 3}t0 ${len / 3}t0 ${len / 3}`, stroke: R.c, 'stroke-width': w, fill: 'none' }, g);
        for (let i = 1; i < 8; i++) E('circle', { cx: x + Math.sin(i * 1.6) * 4, cy: y1 + i * len / 8, r: 3.4, fill: R.dk }, g);
      });
      return;
    }
    if (s === 1) {
      const zip = e; /* উপর থেকে জিপ বন্ধ */
      const gap = (y) => (y - y1) / len < zip ? 6 : 36;
      [[-1, Rr], [1, Rb]].forEach(([k, R]) => {
        const pts = []; for (let i = 0; i <= 20; i++) { const y = y1 + i * len / 20; pts.push(`${i ? 'L' : 'M'}${cx + k * gap(y)} ${y}`); }
        E('path', { d: pts.join(''), stroke: R.c, 'stroke-width': 3.4, fill: 'none', 'stroke-linejoin': 'round' }, g);
      });
      const zy = y1 + zip * len; if (zip > .05) E('rect', { x: cx - 2, y: y1, width: 4, height: zy - y1, fill: FK.alpha(C.mu, .5) }, g);
      T(g, cx + 54, cy + 74, 'সিন্যাপটোনিমাল', { fs: 11, a: 'start', w: 600, c: C.mu }); T(g, cx + 54, cy + 88, 'কমপ্লেক্স', { fs: 11, a: 'start', w: 600, c: C.mu });
      return;
    }
    /* s ≥ 2: চার ক্রোমাটিড; ক্রসের অবস্থান chi (০ = উপর, ১ = নিচ) */
    const sep = s === 2 ? 0 : s === 3 ? 22 * e : 22;
    const chi = s === 4 ? lerp(.35, .03, e) : .35;
    const swap = s >= 3 || (s === 2 && e > .55);
    const xs = [cx - 15 - sep, cx - 5 - sep * .2, cx + 5 + sep * .2, cx + 15 + sep]; /* r1 r2 b1 b2 */
    const cyc = y1 + chi * len;
    const draw = (x, top, bot, bend) => {
      /* কায়াজমার কাছে ভেতরের দুই ক্রোমাটিড মাঝখানে মিলে যায় */
      const midX = bend ? cx : x;
      E('path', { d: `M${x} ${y1}L${bend ? lerp(x, midX, .0) : x} ${cyc - 8}L${midX} ${cyc}`, stroke: top, 'stroke-width': w, 'stroke-linecap': 'round', fill: 'none' }, g);
      E('path', { d: `M${midX} ${cyc}L${x} ${cyc + 8}L${x} ${y2}`, stroke: bot, 'stroke-width': w, 'stroke-linecap': 'round', fill: 'none' }, g);
    };
    const inner = s >= 3;
    draw(xs[0], Rr.c, Rr.c, false);
    draw(xs[1], swap ? Rb.c : Rr.c, Rr.c, inner);
    draw(xs[2], swap ? Rr.c : Rb.c, Rb.c, inner);
    draw(xs[3], Rb.c, Rb.c, false);
    [[(xs[0] + xs[1]) / 2], [(xs[2] + xs[3]) / 2]].forEach(([x]) => E('circle', { cx: x, cy: cy + len * .12, r: 4.5, fill: C.fg }, g));
    if (s === 2 && e > .2 && e < .7) E('path', { d: `M${cx - 8} ${cyc - 8}L${cx + 8} ${cyc + 8}M${cx + 8} ${cyc - 8}L${cx - 8} ${cyc + 8}`, stroke: C.fg, 'stroke-width': 2 }, g);
    if (s >= 3) { E('circle', { cx, cy: cyc, r: 11, fill: 'none', stroke: BK.ramp(6).dk, 'stroke-width': 2.2 }, g); T(g, cx + 22, cyc + 4, 'কায়াজমা', { fs: 12, a: 'start', w: 650, c: BK.ramp(6).ink }); }
    if (s === 2) T(g, cx - 100, cy + 96, 'টেট্রাড = ৪ ক্রোমাটিড', { fs: 11.5, a: 'start', w: 600, c: C.mu });
  }
}));
})();

/* ───────── স্বাধীন বিন্যাস ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
V.assortment = Object.assign({
  t: 'স্বাধীন বিন্যাস — কত রকম গ্যামেট?', k: ['2d', 'anim', 'int'],
  cap: 'মেটাফেজ-১ এ প্রতিটি সমসংস্থ জোড়া স্বাধীনভাবে মুখ ফেরায় — লাল (মাতৃ) বাঁয়ে বা ডানে। "আবার সাজাও" চাপলে জোড়াগুলো এলোমেলোভাবে ঘুরবে। স্লাইডারে n (জোড়ার সংখ্যা) বদলে দেখো গ্যামেটের সমন্বয় কত দ্রুত বাড়ে।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div>
    ${FK.sl('n', 'হ্যাপ্লয়েড সংখ্যা n', 1, 23, 1, 3, '')}
    <div class="fk-row">${FK.btn('sh', 'আবার সাজাও', 'reset')}</div>
    <div class="bk-info" data-k="calc" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 230, MAX = 5;
    let n = 3, ori = [0, 1, 0, 1, 0], flip = [0, 0, 0, 0, 0], svg, pairsG, leftG;
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'স্বাধীন বিন্যাস' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      E('path', { d: `M180 14V${H - 34}`, stroke: FK.alpha(C.mu, .4), 'stroke-dasharray': '5 4' }, svg);
      T(svg, 24, 22, 'মেরু ১', { fs: 11.5, w: 650, c: C.mu }); T(svg, W - 24, 22, 'মেরু ২', { fs: 11.5, a: 'end', w: 650, c: C.mu });
      pairsG = E('g', {}, svg); leftG = E('g', {}, svg);
      paint();
    };
    const paint = () => {
      const C = FK.P(), Rr = BK.ramp(4).c, Rb = BK.ramp(5).c; pairsG.innerHTML = ''; leftG.innerHTML = '';
      const k = Math.min(n, MAX), gap = (H - 60) / k;
      for (let i = 0; i < k; i++) {
        const y = 36 + gap * (i + .5), len = Math.min(gap * .8, 34) * (1 - i * .08), f = flip[i];
        /* ঘোরার অ্যানিমেশন: f ১ → ০ ; স্কেল x = cos */
        const sx = Math.cos(f * Math.PI), left = (ori[i] ^ (f > .5 ? 1 : 0)) ? Rb : Rr, right = left === Rr ? Rb : Rr;
        const gg = E('g', { transform: `translate(180 ${y}) scale(${sx.toFixed(3)} 1)` }, pairsG);
        [[-14, left], [14, right]].forEach(([dx, col]) => { [-3, 3].forEach(o => E('path', { d: `M${dx + o} ${-len / 2}V${len / 2}`, stroke: col, 'stroke-width': 5, 'stroke-linecap': 'round' }, gg)); E('circle', { cx: dx, cy: 0, r: 3, fill: C.fg }, gg); });
        E('path', { d: `M-70 0H-20M20 0H70`, stroke: FK.alpha(C.mu, .35), 'stroke-width': 1 }, gg);
        /* মেরু ১ কোন রং পাচ্ছে */
        E('circle', { cx: 30, cy: y, r: 6, fill: left }, leftG);
      }
      if (n > MAX) T(svg, 180, H - 16, `… আরও ${n - MAX} জোড়া (দেখানো হয়নি)`, { fs: 11, a: 'middle', w: 560, c: C.mu });
      const g1 = Math.pow(2, n), z = BigInt(g1) * BigInt(g1);
      $('calc').innerHTML = `n = <b>${n}</b> জোড়া → এক জনের গ্যামেট-সমন্বয় = 2<sup>${n}</sup> = <b>${g1.toLocaleString('en')}</b>`
        + `<div class="small">দৈব নিষেকে জাইগোট-সমন্বয় = 2<sup>${n}</sup> × 2<sup>${n}</sup> = <b>${z.toLocaleString('en')}</b> (ক্রসিংওভার ছাড়াই)</div>`
        + (n === 23 ? `<div class="small">এটাই মানুষ: প্রায় ৮৪ লক্ষ রকম গ্যামেট, প্রায় ৭০ লক্ষ কোটি রকম সন্তান।</div>` : '');
    };
    FK.bindSl(root, 'n', v => { n = Math.round(v); if (svg) paint(); }, '', 0);
    let anim = 0;
    FK.on(root, 'sh', () => { for (let i = 0; i < MAX; i++) { if (Math.random() < .5) { ori[i] ^= 1; flip[i] = 1; } } anim = 1; });
    build();
    const A = X.anim(root, dt => { if (!anim) return; let any = 0; for (let i = 0; i < MAX; i++) if (flip[i] > 0) { flip[i] = Math.max(0, flip[i] - dt * 2.2); any = 1; } paint(); if (!any) anim = 0; }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();
