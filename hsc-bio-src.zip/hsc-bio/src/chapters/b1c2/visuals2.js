/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §২.২
   cytokinesis : প্রাণিকোষে খাঁজ বনাম উদ্ভিদকোষে কোষপ্লেট — পাশাপাশি
   tumorGrowth : স্বাভাবিক কলা / বিনাইন / ম্যালিগন্যান্ট (মেটাস্টেসিস)
   apoptosis   : নেক্রোসিস বনাম অ্যাপোপটোসিস — পাশাপাশি
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.cytokinesis = Object.assign({
  t: 'সাইটোকাইনেসিস — প্রাণী বনাম উদ্ভিদ', k: ['2d', 'anim'],
  cap: 'বাঁয়ে <b>প্রাণিকোষ</b>: অ্যাকটিন-মায়োসিন বলয় সংকুচিত হয়ে বাইরে থেকে ভেতরে <b>খাঁজ</b> ফেলে। ডানে <b>উদ্ভিদকোষ</b>: শক্ত প্রাচীরে খাঁজ পড়ে না — গলগি ভেসিকল জুড়ে মাঝখান থেকে বাইরের দিকে <b>কোষপ্লেট</b> বাড়ে।'
}, BK.steps({
  W: 380, H: 230, label: 'সাইটোকাইনেসিস', dur: 3,
  stages: [
    { t: 'টেলোফেজ শেষ', en: 'Late telophase', d: 'দুই মেরুতে দুটি নতুন নিউক্লিয়াস তৈরি হয়েছে; এবার সাইটোপ্লাজম ভাগের পালা।' },
    { t: 'শুরু', en: 'Initiation', d: 'প্রাণিকোষে বিষুবীয় অঞ্চলে কোষঝিল্লির নিচে <b>অ্যাকটিন-মায়োসিন বলয়</b>; উদ্ভিদকোষে মাঝখানে <b>ফ্র্যাগমোপ্লাস্টে</b> গলগি ভেসিকল জমা শুরু।' },
    { t: 'অগ্রগতি', en: 'Progression', d: 'খাঁজ <b>বাইরে থেকে ভেতরে</b> (কেন্দ্রমুখী) গভীর হয়; কোষপ্লেট <b>ভেতর থেকে বাইরে</b> (কেন্দ্রবিমুখী) বাড়ে।' },
    { t: 'দুই কোষ', en: 'Two daughter cells', d: 'প্রাণিকোষে ঝিল্লি মিলিত হয়ে দুই কোষ আলাদা। উদ্ভিদে কোষপ্লেট প্রাচীরে মিলে <b>মধ্যপর্দা</b> হয়; দুই পাশে নতুন প্রাথমিক প্রাচীর জমে।' }
  ],
  draw(g, C, s, u) {
    const Rm = BK.org('mem'), Rc = BK.org('cyto'), Rn = BK.org('nucleus'), Rw = BK.org('wall'), Ra = BK.ramp(4), Rg = BK.ramp(6);
    const e = FK.ease(Math.min(1, u * 1.3));
    const P = s === 0 ? 0 : s === 1 ? .25 * e : s === 2 ? .25 + .6 * e : .85 + .15 * e;
    const nuc = (x, y) => E('ellipse', { cx: x, cy: y, rx: 16, ry: 14, fill: FK.alpha(Rn.lt || Rn.c, .8), stroke: Rn.dk || Rn.c, 'stroke-width': 2 }, g);
    /* প্রাণিকোষ */
    const ax = 96, ay = 120, aw = 76, ah = 62, pin = P * .97;
    const d = `M${ax - aw} ${ay}C${ax - aw} ${ay - ah * 1.3} ${ax - 16} ${ay - ah * (1 - pin)} ${ax} ${ay - ah * (1 - pin)}C${ax + 16} ${ay - ah * (1 - pin)} ${ax + aw} ${ay - ah * 1.3} ${ax + aw} ${ay}C${ax + aw} ${ay + ah * 1.3} ${ax + 16} ${ay + ah * (1 - pin)} ${ax} ${ay + ah * (1 - pin)}C${ax - 16} ${ay + ah * (1 - pin)} ${ax - aw} ${ay + ah * 1.3} ${ax - aw} ${ay}Z`;
    E('path', { d, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 3 }, g);
    nuc(ax - 42, ay); nuc(ax + 42, ay);
    if (s >= 1 && s < 3) { const yy = ah * (1 - pin) - 2; [[ax, ay - yy], [ax, ay + yy]].forEach(([x, y]) => { E('ellipse', { cx: x, cy: y, rx: 5, ry: 3, fill: Ra.c }, g); }); }
    if (s === 2) { E('path', { d: `M${ax} ${ay - ah - 22}v14M${ax - 5} ${ay - ah - 13}l5 5l5 -5`, stroke: Ra.dk, 'stroke-width': 2, fill: 'none' }, g); E('path', { d: `M${ax} ${ay + ah + 22}v-14M${ax - 5} ${ay + ah + 13}l5 -5l5 5`, stroke: Ra.dk, 'stroke-width': 2, fill: 'none' }, g); }
    T(g, ax, 214, 'প্রাণিকোষ — খাঁজ', { fs: 13, a: 'middle', w: 600, c: Ra.ink });
    /* উদ্ভিদকোষ */
    const px = 288, py = 120, pw = 74, ph = 66;
    E('rect', { x: px - pw - 5, y: py - ph - 5, width: 2 * pw + 10, height: 2 * ph + 10, rx: 6, fill: FK.alpha(Rw.lt || Rw.c, .55), stroke: Rw.dk || Rw.c, 'stroke-width': 2 }, g);
    E('rect', { x: px - pw, y: py - ph, width: 2 * pw, height: 2 * ph, rx: 4, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 2 }, g);
    nuc(px - 42, py); nuc(px + 42, py);
    if (s >= 1) {
      const half = ph * P;
      if (half > 1) E('rect', { x: px - 3, y: py - half, width: 6, height: 2 * half, rx: 3, fill: Rg.c, stroke: Rg.dk, 'stroke-width': 1 }, g);
      if (s < 3) for (let i = -3; i <= 3; i++) { const y = py + i * 14 * (half / ph + .3); if (Math.abs(y - py) > half) E('circle', { cx: px + (i % 2 ? 4 : -4), cy: y, r: 3.2, fill: FK.alpha(Rg.c, .7), stroke: Rg.dk, 'stroke-width': .8 }, g); }
      if (s === 2) { E('path', { d: `M${px + 14} ${py - 8}v-18M${px + 9} ${py - 21}l5 -5l5 5M${px + 14} ${py + 8}v18M${px + 9} ${py + 21}l5 5l5 -5`, stroke: Rg.dk, 'stroke-width': 2, fill: 'none' }, g); }
    }
    T(g, px, 214, 'উদ্ভিদকোষ — কোষপ্লেট', { fs: 13, a: 'middle', w: 600, c: Rg.ink });
  }
}));
})();

/* ───────── টিউমার বৃদ্ধি ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const MODES = [['n', 'স্বাভাবিক'], ['b', 'বিনাইন'], ['m', 'ম্যালিগন্যান্ট']];
const NOTE = {
  n: 'একটি কোষ মরে গেলে (ফাঁকা জায়গা) পাশের কোষ মাইটোসিসে ঠিক একটি কোষ বানিয়ে ফাঁক পূরণ করে — তারপর <b>স্পর্শ নিবারণে</b> থেমে যায়। কলার স্তর একটিই থাকে।',
  b: 'নিয়ন্ত্রণ হারানো কোষ বারবার বিভাজিত হয়ে পিণ্ড গড়ছে, কিন্তু চারপাশে একটি <b>আবরণ (ক্যাপসুল)</b> — নিচের ভিত্তিপর্দা পেরোয় না, অন্যত্র ছড়ায় না। <b>বিনাইন টিউমার</b>।',
  m: 'আবরণহীন পিণ্ড; কোষ <b>ভিত্তিপর্দা ভেদ করে</b> রক্তনালিতে ঢুকছে এবং স্রোতে ভেসে দূরে নতুন টিউমার গড়ছে — <b>মেটাস্টেসিস</b>। এটাই ক্যানসার।'
};
V.tumorGrowth = Object.assign({
  t: 'অনিয়ন্ত্রিত মাইটোসিস — টিউমার ও ক্যানসার', k: ['2d', 'anim', 'int'],
  cap: 'একটি আবরণী কলার প্রস্থচ্ছেদ: উপরে কোষের স্তর, নিচে ভিত্তিপর্দা ও রক্তনালি। তিন অবস্থা বদলে দেখো কোষ বিভাজন কীভাবে নিয়ন্ত্রিত থেকে অনিয়ন্ত্রিত হয়।',
  html: () => `<div class="fk-row">${X.seg('md', MODES, 'n')}</div>
    <div class="fk-stage bk-stage" data-k="st"></div>
    <div class="bk-info" data-k="note" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const W = 360, H = 240, BY = 150, N0 = 12, CW = 28;
    let mode = 'n', t = 0, svg, layer, extra = [], cap, vesselCells = [];
    /* পিণ্ডের কোষের অবস্থান — সর্পিলভাবে বাইরে */
    const lump = []; for (let i = 0; i < 26; i++) { const r = 10 + Math.sqrt(i) * 11, a = i * 2.4; lump.push([180 + r * Math.cos(a) * 1.25, 98 - Math.abs(r * Math.sin(a)) * .9 + (i % 3) * 2]); }
    const build = () => {
      const C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'টিউমারের বৃদ্ধি' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rv = BK.ramp(4), Rb = BK.ramp(9);
      /* রক্তনালি */
      E('path', { d: `M0 ${BY + 44}H${W}`, stroke: FK.alpha(Rv.c, .3), 'stroke-width': 30 }, svg);
      T(svg, 12, BY + 72, 'রক্তনালি', { fs: 11.5, w: 600, c: Rv.ink });
      /* ভিত্তিপর্দা */
      E('path', { d: `M0 ${BY}H${W}`, stroke: Rb.dk, 'stroke-width': 3, 'stroke-dasharray': '7 3' }, svg);
      T(svg, W - 10, BY + 15, 'ভিত্তিপর্দা', { fs: 11, a: 'end', w: 600, c: C.mu });
      cap = E('ellipse', { cx: 180, cy: 92, rx: 0, ry: 0, fill: 'none', stroke: BK.ramp(10).dk, 'stroke-width': 2.4, 'stroke-dasharray': '5 3' }, svg);
      layer = E('g', {}, svg);
      for (let i = 0; i < N0; i++) E('rect', { x: 12 + i * CW, y: BY - 34, width: CW - 3, height: 32, rx: 6, fill: FK.alpha(BK.ramp(5).lt, .85), stroke: BK.ramp(5).dk, 'stroke-width': 1.2, 'data-i': i }, layer);
      extra = lump.map(([x, y]) => E('circle', { cx: x, cy: y, r: 9, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk, 'stroke-width': 1.2, opacity: 0 }, svg));
      vesselCells = [0, 1, 2].map(() => E('circle', { r: 7, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk, opacity: 0 }, svg));
      paint();
    };
    const paint = () => {
      const k = Math.min(1, t / 6), cells = layer.children;
      /* স্বাভাবিক: ৬ নম্বর কোষ মরে আবার পূরণ */
      for (let i = 0; i < N0; i++) {
        const c = cells[i];
        if (mode === 'n' && i === 6) { const ph = (t % 5) / 5; c.setAttribute('opacity', ph < .25 ? 1 - ph * 4 : ph < .45 ? 0 : Math.min(1, (ph - .45) * 3)); c.setAttribute('height', ph > .45 ? 32 * Math.min(1, (ph - .45) * 3) : 32); c.setAttribute('y', BY - 2 - (ph > .45 ? 32 * Math.min(1, (ph - .45) * 3) : 32)); }
        else { c.setAttribute('opacity', 1); c.setAttribute('height', 32); c.setAttribute('y', BY - 34); }
        c.setAttribute('fill', mode !== 'n' && (i === 5 || i === 6) ? FK.alpha(BK.ramp(2).c, .9) : FK.alpha(BK.ramp(5).lt, .85));
      }
      const n = mode === 'n' ? 0 : Math.floor(k * lump.length);
      extra.forEach((c, i) => { c.setAttribute('opacity', i < n ? 1 : 0); c.setAttribute('r', mode === 'm' ? 8 + (i % 3) * 1.5 : 9); });
      if (mode === 'b' && n > 2) { const rx = 22 + 48 * k, ry = 14 + 34 * k; cap.setAttribute('rx', rx); cap.setAttribute('ry', ry); cap.setAttribute('cy', BY - 34 - ry * .55); } else { cap.setAttribute('rx', 0); cap.setAttribute('ry', 0); }
      vesselCells.forEach((c, i) => {
        if (mode !== 'm' || k < .35) { c.setAttribute('opacity', 0); return; }
        const tt = ((t * .35 + i * .33) % 1);
        const x = tt < .2 ? 186 : 186 + (tt - .2) / .8 * 170, y = tt < .2 ? BY - 10 + tt / .2 * 50 : BY + 40 + Math.sin(tt * 20) * 4;
        c.setAttribute('cx', x); c.setAttribute('cy', y); c.setAttribute('opacity', 1);
      });
    };
    X.onSeg(root, 'md', v => { mode = v; t = 0; $('note').innerHTML = NOTE[v]; paint(); });
    build(); $('note').innerHTML = NOTE.n;
    const A = X.anim(root, dt => { t += dt; if (mode !== 'n' && t > 12) t = 0; paint(); }, { paused: false });
    const onT = () => build();
    document.addEventListener('bk-lang', onT);
    return () => { A.stop(); document.removeEventListener('bk-lang', onT); };
  }
});
})();

/* ───────── নেক্রোসিস বনাম অ্যাপোপটোসিস ───────── */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T;
V.apoptosis = Object.assign({
  t: 'নেক্রোসিস বনাম অ্যাপোপটোসিস', k: ['2d', 'anim'],
  cap: 'বাঁয়ে <b>নেক্রোসিস</b>: কোষ ফুলে ফেটে যায়, উপাদান ছড়িয়ে পড়ে — প্রদাহ। ডানে <b>অ্যাপোপটোসিস</b>: কোষ গুটিয়ে যায়, ঝিল্লিবেষ্টিত টুকরো (অ্যাপোপটোটিক বডি) হয় এবং ফ্যাগোসাইট নিঃশব্দে খেয়ে ফেলে।'
}, BK.steps({
  W: 380, H: 240, label: 'কোষমৃত্যুর দুই ধরন', dur: 3,
  stages: [
    { t: 'সুস্থ কোষ', en: 'Healthy cell', d: 'দুই পাশে একই রকম সুস্থ কোষ।' },
    { t: 'প্রথম পরিবর্তন', en: 'Early', d: 'নেক্রোসিসে পানি ঢুকে কোষ ও অঙ্গাণু <b>ফুলে</b> যায়। অ্যাপোপটোসিসে কোষ <b>সংকুচিত</b> হয়, ক্রোমাটিন ঘনীভূত হয়।' },
    { t: 'ভাঙন', en: 'Breakdown', d: 'নেক্রোসিসে ঝিল্লি <b>ফেটে</b> যায়। অ্যাপোপটোসিসে ঝিল্লিতে ফোসকা (ব্লেবিং), নিউক্লিয়াস টুকরো হয় — <b>ক্যাসপেজ</b> সক্রিয়।' },
    { t: 'পরিণতি', en: 'Outcome', d: 'নেক্রোসিসে উপাদান ছড়িয়ে <b>প্রদাহ</b>। অ্যাপোপটোসিসে <b>অ্যাপোপটোটিক বডি</b> ফ্যাগোসাইট গ্রাস করে — কোনো প্রদাহ নেই।' }
  ],
  draw(g, C, s, u) {
    const Rc = BK.org('cyto'), Rm = BK.org('mem'), Rn = BK.org('nucleus'), Rr = BK.ramp(4), Rp = BK.ramp(10), Rk = BK.ramp(3);
    const e = FK.ease(Math.min(1, u * 1.3));
    /* নেক্রোসিস — বাঁয়ে */
    const nx = 96, ny = 112;
    const sw = s === 0 ? 1 : s === 1 ? 1 + .35 * e : 1.35;
    if (s < 2 || (s === 2 && e < .4)) {
      E('circle', { cx: nx, cy: ny, r: 46 * sw, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 3 }, g);
      E('circle', { cx: nx, cy: ny, r: 16 * sw, fill: FK.alpha(Rn.lt || Rn.c, .8), stroke: Rn.dk || Rn.c, 'stroke-width': 2 }, g);
      [[-26, -14], [22, 18], [18, -22]].forEach(([dx, dy]) => E('ellipse', { cx: nx + dx * sw, cy: ny + dy * sw, rx: 8 * sw, ry: 5 * sw, fill: FK.alpha(BK.org('mito').c, .7) }, g));
    } else {
      const k = s === 2 ? (e - .4) / .6 : 1;
      for (let i = 0; i < 9; i++) { const a = i * .7 - 1.2, r = 50 + 22 * k; E('path', { d: `M${nx + Math.cos(a) * r} ${ny + Math.sin(a) * r}a14 14 0 0 1 14 6`, stroke: Rm.c || Rm.dk, 'stroke-width': 3, fill: 'none' }, g); }
      for (let i = 0; i < 18; i++) { const a = i * 1.7, r = 20 + (i % 5) * 12 * (1 + k); E('circle', { cx: nx + Math.cos(a) * r, cy: ny + Math.sin(a) * r, r: 2.6, fill: i % 3 ? Rr.c : BK.org('mito').c }, g); }
      if (s === 3) { E('circle', { cx: nx, cy: ny, r: 74, fill: FK.alpha(Rr.c, .12 + .08 * Math.sin(u * 12)), stroke: 'none' }, g); T(g, nx, 28, 'প্রদাহ!', { fs: 14, a: 'middle', w: 650, c: Rr.ink }); }
    }
    T(g, nx, 226, 'নেক্রোসিস', { fs: 13.5, a: 'middle', w: 650, c: Rr.ink });
    /* অ্যাপোপটোসিস — ডানে */
    const ax = 284, ay = 112;
    const sh = s === 0 ? 1 : s === 1 ? 1 - .3 * e : .7;
    if (s < 2) {
      E('circle', { cx: ax, cy: ay, r: 46 * sh, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 3 }, g);
      E('circle', { cx: ax, cy: ay, r: 16 * sh, fill: s === 1 ? FK.alpha(Rk.c, .3 + .5 * e) : FK.alpha(Rn.lt || Rn.c, .8), stroke: Rn.dk || Rn.c, 'stroke-width': 2 }, g);
    } else if (s === 2) {
      const R0 = 32;
      E('circle', { cx: ax, cy: ay, r: R0, fill: FK.alpha(Rc.lt || Rc.c, .5), stroke: Rm.c || Rm.dk, 'stroke-width': 3 }, g);
      for (let i = 0; i < 6; i++) { const a = i * 1.05; E('circle', { cx: ax + Math.cos(a) * (R0 + 4 * e), cy: ay + Math.sin(a) * (R0 + 4 * e), r: 4 + 6 * e, fill: FK.alpha(Rc.lt || Rc.c, .6), stroke: Rm.c || Rm.dk, 'stroke-width': 2 }, g); }
      for (let i = 0; i < 4; i++) E('circle', { cx: ax + (i - 1.5) * 8 * e, cy: ay + (i % 2 ? 5 : -5) * e, r: 5, fill: Rk.c }, g);
    } else {
      const bodies = [[-30, -16], [8, -30], [32, 6], [-10, 26], [-36, 18]];
      bodies.forEach(([dx, dy], i) => {
        const gone = e > .3 + i * .12;
        if (!gone) { E('circle', { cx: ax + dx, cy: ay + dy, r: 11, fill: FK.alpha(Rc.lt || Rc.c, .6), stroke: Rm.c || Rm.dk, 'stroke-width': 2 }, g); E('circle', { cx: ax + dx, cy: ay + dy, r: 4, fill: Rk.c }, g); }
      });
      const fx = ax + 70 - 60 * e, fy = ay + 10;
      E('path', { d: `M${fx + 30} ${fy - 26}Q${fx - 10} ${fy - 30} ${fx - 16} ${fy}Q${fx - 10} ${fy + 30} ${fx + 30} ${fy + 26}Q${fx + 44} ${fy} ${fx + 30} ${fy - 26}Z`, fill: FK.alpha(Rp.lt, .7), stroke: Rp.dk, 'stroke-width': 2 }, g);
      T(g, fx + 16, fy + 4, 'ফ্যাগো-', { fs: 10, a: 'middle', w: 600, c: Rp.ink }); T(g, fx + 16, fy + 16, 'সাইট', { fs: 10, a: 'middle', w: 600, c: Rp.ink });
      T(g, ax, 28, 'প্রদাহ নেই', { fs: 14, a: 'middle', w: 650, c: Rp.ink });
    }
    T(g, ax, 226, 'অ্যাপোপটোসিস', { fs: 13.5, a: 'middle', w: 650, c: Rp.ink });
    E('path', { d: 'M190 30V212', stroke: FK.alpha(C.mu, .3), 'stroke-dasharray': '4 4' }, g);
  }
}));
})();
