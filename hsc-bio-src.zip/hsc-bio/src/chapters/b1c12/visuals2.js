/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §১২.২ জীবের অভিযোজন: জলজ, মরুজ, লোনামাটির উদ্ভিদ ও প্রাণী, মেসোফাইট
   waterGrad, hydroTypes, hydroAnat, xeroTypes, xeroLeaf, camelAdapt, fishAdapt, mangroveRoots, saltWays, fishOsmo,
   cmpHydroXero, cmpXeroMeso, cmpXeroHalo, cmpMarineFresh
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B12, XB = window.B12X;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot, chip = B.chip, lab = B.lab;
const arrow = XB.arrow, okm = XB.okm, nope = XB.nope, cmp = XB.cmp, org = XB.org;
const R5 = () => BK.ramp(5), R10 = () => BK.ramp(10), R11 = () => BK.ramp(11);
const water = (g, y, h, o = {}) => { E('rect', { x: 0, y, width: 360, height: h, fill: FK.alpha(BK.ramp(5).c, o.a || .22) }, g); E('path', { d: `M0 ${y}q15 -4 30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0`, stroke: BK.ramp(5).dk, 'stroke-width': 1.2, fill: 'none' }, g); };
const mud = (g, y) => { E('rect', { x: 0, y, width: 360, height: 270 - y, fill: FK.alpha(BK.ramp(11).c, .45) }, g); E('path', { d: `M0 ${y}H360`, stroke: BK.ramp(11).dk, 'stroke-width': 1.2 }, g); };
const leafE = (g, x, y, rx, ry, a, R, op = 1) => E('ellipse', { cx: x, cy: y, rx, ry, transform: `rotate(${a} ${x} ${y})`, fill: R.c, stroke: R.dk, 'stroke-width': .9, opacity: op }, g);

/* ═════════ ১. পানির প্রাপ্যতা অনুযায়ী উদ্ভিদ ═════════ */
V.waterGrad = Object.assign({}, B.seg({
  id: 'wgr', t: 'পানির প্রাপ্যতা ও উদ্ভিদের অভিযোজন', H: 256,
  cap: 'অভিযোজন — যে বৈশিষ্ট্যের (গঠনগত, শারীরবৃত্তীয় বা আচরণগত) কারণে কোনো জীব তার পরিবেশে টিকে থাকতে ও বংশবৃদ্ধি করতে পারে; বহু প্রজন্মে প্রাকৃতিক নির্বাচনের মাধ্যমে গড়ে ওঠে। পানির প্রাপ্যতা অনুযায়ী উদ্ভিদ তিন প্রধান দলে — জলজ (হাইড্রোফাইট), সমবায়ী বা মেসোফাইট ও মরুজ (জেরোফাইট); লবণাক্ত মাটির উদ্ভিদ হ্যালোফাইট। স্লাইডার সরিয়ে দেখো পানির পরিমাণ কমলে উদ্ভিদের গঠন কীভাবে বদলায়।',
  sl: [{ k: 'w', l: 'মাটিতে পানি', min: 0, max: 100, step: 5, val: 50, unit: '%' }],
  types: { g: ['পরিবর্তন', 'পানি অনুযায়ী গঠন', 'বাঁয়ে কম পানি (মরুজ), মাঝে পরিমিত (মেসোফাইট), ডানে বেশি পানি (জলজ)।'] }, def: 'g',
  art(g, C, ty, ctx) {
    const w = +ctx.v.w / 100, type = w < .3 ? 2 : w > .75 ? 0 : 1;
    const NM = [['জলজ উদ্ভিদ (হাইড্রোফাইট)', 5], ['মেসোফাইট', 10], ['মরুজ উদ্ভিদ (জেরোফাইট)', 6]][type];
    mud(g, 170);
    if (w > .75) water(g, 150 - (w - .75) * 160, 20 + (w - .75) * 160, { a: .25 });
    /* মূল */
    const rl = 20 + (1 - w) * 70;
    for (let i = -2; i <= 2; i++) E('path', { d: `M90 170q${i * 8} ${rl * .5} ${i * 16} ${rl}`, stroke: BK.ramp(11).dk, 'stroke-width': w > .75 ? 1 : 1.8, fill: 'none' }, g);
    /* কাণ্ড ও পাতা */
    const sh = 70 + w * 30, Rg = BK.ramp(type === 2 ? 7 : 10);
    E('path', { d: `M90 170V${170 - sh}`, stroke: Rg.dk, 'stroke-width': type === 2 ? 7 : 3, 'stroke-linecap': 'round' }, g);
    const ls = 6 + w * 20;
    for (let i = 0; i < 4; i++) { const y = 170 - sh * (.35 + i * .18); leafE(g, 90 - ls * .9, y, ls, ls * .42, -18, Rg); leafE(g, 90 + ls * .9, y - 6, ls, ls * .42, 18, Rg); }
    if (type === 2) for (let i = 0; i < 8; i++) E('path', { d: `M${90 + (i % 2 ? 4 : -4)} ${170 - sh * (.2 + i * .1)}l${i % 2 ? 8 : -8} -3`, stroke: BK.ramp(11).dk, 'stroke-width': 1 }, g);
    /* বৈশিষ্ট্য-তালিকা */
    const rows = [['মূল', w > .75 ? 'দুর্বল বা অনুপস্থিত' : w < .3 ? 'গভীর ও বিস্তৃত' : 'সুগঠিত, মাঝারি'], ['পাতা', w > .75 ? 'বড়, পাতলা, কোমল' : w < .3 ? 'ছোট, পুরু বা কাঁটায় রূপান্তরিত' : 'মাঝারি, চ্যাপ্টা'], ['কিউটিকল', w > .75 ? 'নেই বা খুব পাতলা' : w < .3 ? 'খুব পুরু, মোমযুক্ত' : 'মাঝারি'], ['পত্ররন্ধ্র', w > .75 ? 'ওপরের তলে বা নেই' : w < .3 ? 'কম, গর্তে নিমজ্জিত' : 'নিচের তলে বেশি'], ['বায়ুকুঠুরি', w > .75 ? 'প্রচুর (অ্যারেনকাইমা)' : w < .3 ? 'নেই' : 'সামান্য'], ['জাইলেম', w > .75 ? 'কম গঠিত' : w < .3 ? 'সুগঠিত' : 'সুগঠিত']];
    const R = BK.ramp(NM[1]);
    E('rect', { x: 176, y: 14, width: 174, height: 26, rx: 8, fill: FK.alpha(R.c, .25), stroke: R.dk }, g);
    T(g, 263, 32, NM[0], { fs: 10.6, a: 'middle', w: 700, c: R.ink });
    rows.forEach(([a, b], i) => { const y = 64 + i * 26; T(g, 184, y, a, { fs: 9.6, w: 700, c: C.mu }); T(g, 244, y, b, { fs: 9.6, c: C.fg }); E('path', { d: `M180 ${y + 8}H350`, stroke: C.ln, 'stroke-width': .5 }, g); });
    /* পানি-মিটার */
    E('rect', { x: 14, y: 14, width: 10, height: 150, rx: 5, fill: FK.alpha(C.mu, .1), stroke: C.ln }, g);
    E('rect', { x: 14, y: 14 + 150 * (1 - w), width: 10, height: 150 * w, rx: 5, fill: BK.ramp(5).c }, g);
    T(g, 19, 236, 'পানি', { fs: 8.6, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const w = +ctx.v.w / 100, k = (t * .8) % 1; if (w < .3) { E('path', { d: `M${84 + k * 4} ${110 - k * 60}q4 -6 0 -12`, stroke: BK.ramp(4).c, 'stroke-width': 1.4, fill: 'none', opacity: 1 - k }, g); } else E('circle', { cx: 90 + (k - .5) * 30, cy: 110 - k * 60, r: 2, fill: BK.ramp(5).c, opacity: 1 - k }, g); }
}));

/* ═════════ ২. জলজ উদ্ভিদের প্রকার ═════════ */
const HYD = {
  ff: ['ভাসমান', 'মুক্তভাসমান উদ্ভিদ', 'পানির ওপর ভেসে থাকে, মূল মাটিতে পৌঁছায় না — কচুরিপানা (Eichhornia crassipes), টোপাপানা (Pistia stratiotes), ক্ষুদিপানা (Lemna), উলফিয়া (Wolffia — পৃথিবীর ক্ষুদ্রতম সপুষ্পক উদ্ভিদ)। কচুরিপানার স্ফীত স্পঞ্জের মতো পত্রবৃন্তে বায়ু থাকে; মূলের আগায় মূলত্রের বদলে মূলপকেট।'],
  rf: ['মূলযুক্ত ভাসমান', 'নিমজ্জিত-মূল ভাসমান-পাতা উদ্ভিদ', 'মূল কাদায় আটকানো, পাতা লম্বা বৃন্তে পানির ওপর ভাসে — শাপলা (Nymphaea), পদ্ম (Nelumbo nucifera), মাখনা। পাতার ওপরের তলে পুরু মোমের আবরণ ও পত্ররন্ধ্র; নিচের তলে রন্ধ্র নেই।'],
  sm: ['নিমজ্জিত', 'নিমজ্জিত উদ্ভিদ', 'সম্পূর্ণ পানির নিচে থাকে — পাতাঝাঁঝি (Hydrilla), পাতাশেওলা (Vallisneria), ঝাঁঝি (Ceratophyllum), ইউট্রিকুলারিয়া (Utricularia — পতঙ্গভুক)। পাতা সরু, ফিতা বা সূতার মতো খণ্ডিত; কিউটিকল ও পত্ররন্ধ্র নেই — সারা দেহ দিয়ে পানি, খনিজ ও গ্যাস শোষণ।'],
  am: ['উভচর', 'উভচর বা জলাভূমির উদ্ভিদ', 'দেহের কিছু অংশ পানিতে, কিছু অংশ বাতাসে — কলমি (Ipomoea aquatica), হেলেঞ্চা, ধান, Sagittaria, Limnophila। অনেকের পানির নিচের ও ওপরের পাতা দুই রকম — ভিন্নপত্রতা (হেটেরোফিলি)।']
};
V.hydroTypes = Object.assign({}, B.seg({
  id: 'hyt', t: 'জলজ উদ্ভিদের প্রকারভেদ', H: 250, def: 'ff',
  cap: 'জলজ উদ্ভিদ বা হাইড্রোফাইট — যে উদ্ভিদ পানিতে বা অত্যন্ত ভেজা মাটিতে জন্মায় এবং যার দেহের সম্পূর্ণ বা অধিকাংশ পানিতে ডুবে বা ভেসে থাকে। পানির সাথে সম্পর্ক অনুযায়ী এদের চার দলে ভাগ করা হয়।',
  types: { ff: HYD.ff, rf: HYD.rf, sm: HYD.sm, am: HYD.am },
  art(g, C, ty) {
    const Rg = BK.ramp(10);
    water(g, 70, 150); mud(g, 220);
    if (ty === 'ff') {
      [[90, 1.1], [200, .9], [290, 1]].forEach(([x, s]) => { E('ellipse', { cx: x, cy: 66, rx: 9 * s, ry: 7 * s, fill: FK.alpha(Rg.c, .7), stroke: Rg.dk }, g); for (let i = 0; i < 4; i++) { const a = -PI / 2 + (i - 1.5) * .5; E('path', { d: `M${x} 66q${Math.cos(a) * 10 * s} -10 ${Math.cos(a) * 18 * s} ${-26 * s}`, stroke: Rg.dk, 'stroke-width': 2.2, fill: 'none' }, g); leafE(g, x + Math.cos(a) * 18 * s, 66 - 30 * s, 9 * s, 7 * s, 0, Rg); } for (let i = 0; i < 7; i++) E('path', { d: `M${x - 6 + i * 2} 72q${(i - 3) * 2} 30 ${(i - 3) * 3} 60`, stroke: BK.ramp(11).dk, 'stroke-width': .9, fill: 'none' }, g); });
      lab(g, 104, 70, 150, 40, 'স্ফীত পত্রবৃন্ত (বায়ুপূর্ণ)', C, { fs: 9.6 }); lab(g, 92, 128, 150, 150, 'গুচ্ছমূল, মূলপকেট', C, { fs: 9.6 });
      for (let i = 0; i < 12; i++) E('circle', { cx: 30 + i * 26, cy: 69, r: 2.4, fill: Rg.c }, g);
      T(g, 300, 104, 'ক্ষুদিপানা / উলফিয়া', { fs: 9, a: 'middle', c: C.mu });
    } else if (ty === 'rf') {
      [[100, 1], [240, 1.15]].forEach(([x, s], j) => { E('path', { d: `M${x} 222q${j ? -20 : 20} -70 ${j ? 10 : -6} -150`, stroke: Rg.dk, 'stroke-width': 1.6, fill: 'none' }, g); E('ellipse', { cx: x + (j ? 10 : -6), cy: 70, rx: 30 * s, ry: 6 * s, fill: Rg.c, stroke: Rg.dk }, g); if (j) { E('path', { d: `M${x + 30} 222q10 -80 0 -170`, stroke: Rg.dk, 'stroke-width': 1.4, fill: 'none' }, g); for (let p = 0; p < 6; p++) leafE(g, x + 30 + Math.cos(p) * 6, 44, 6, 11, (p - 2.5) * 22, BK.ramp(8)); } });
      lab(g, 150, 220, 190, 236, 'মূল ও গ্রন্থিকাণ্ড কাদায়', C, { fs: 9.6 }); lab(g, 112, 140, 150, 150, 'লম্বা নমনীয় পত্রবৃন্ত', C, { fs: 9.6 }); lab(g, 70, 66, 50, 40, 'ভাসমান পাতা — ওপরে মোম ও রন্ধ্র', C, { fs: 9.6, a: 'start' });
    } else if (ty === 'sm') {
      for (let i = 0; i < 3; i++) { const x = 70 + i * 100; E('path', { d: `M${x} 222q-10 -60 4 -130`, stroke: Rg.dk, 'stroke-width': 1.6, fill: 'none' }, g); for (let k = 0; k < 9; k++) { const y = 210 - k * 14; [-1, 1].forEach(sd => E('path', { d: `M${x + sd} ${y}q${sd * 10} -4 ${sd * 16} -12`, stroke: Rg.dk, 'stroke-width': 1.2, fill: 'none' }, g)); } }
      for (let i = 0; i < 4; i++) E('path', { d: `M${260 + i * 12} 222q${8 - i * 4} -70 ${-4 + i * 6} -140`, stroke: BK.ramp(10).c, 'stroke-width': 4, fill: 'none', opacity: .8 }, g);
      lab(g, 86, 150, 130, 120, 'সরু খণ্ডিত পাতা — কিউটিকল ও রন্ধ্র নেই', C, { fs: 9.6, a: 'start' }); lab(g, 266, 120, 300, 100, 'ফিতা-পাতা', C, { fs: 9.6 });
    } else {
      mud(g, 150); water(g, 150, 70);
      E('path', { d: 'M120 222V40', stroke: Rg.dk, 'stroke-width': 2, fill: 'none' }, g);
      for (let k = 0; k < 4; k++) { const y = 210 - k * 14; [-1, 1].forEach(sd => E('path', { d: `M${120 + sd} ${y}q${sd * 12} -4 ${sd * 20} -12`, stroke: Rg.dk, 'stroke-width': 1.1, fill: 'none' }, g)); }
      for (let k = 0; k < 4; k++) { const y = 130 - k * 24; leafE(g, 104, y, 14, 5, -25, Rg); leafE(g, 136, y - 8, 14, 5, 25, Rg); }
      lab(g, 140, 196, 190, 200, 'নিমজ্জিত পাতা — খণ্ডিত', C, { fs: 9.6 }); lab(g, 150, 104, 190, 90, 'বায়বীয় পাতা — অখণ্ড, চওড়া', C, { fs: 9.6 });
      T(g, 250, 130, 'ভিন্নপত্রতা', { fs: 12, a: 'middle', w: 700, c: BK.ramp(10).ink }); T(g, 250, 146, '(একই গাছে দুই রকম পাতা)', { fs: 9, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t) { if (!t) return; for (let i = 0; i < 4; i++) { const k = (t * .3 + i * .25) % 1; E('circle', { cx: 40 + i * 90 + Math.sin(t + i) * 6, cy: 216 - k * 140, r: 2 + k * 1.5, fill: 'none', stroke: BK.ramp(5).dk, 'stroke-width': .9, opacity: 1 - k }, g); } }
}));

/* ═════════ ৩. জলজ উদ্ভিদের কাণ্ডের প্রস্থচ্ছেদ ═════════ */
const HAN = [['এপিডার্মিস', 'পাতলা, কিউটিকল নেই — সরাসরি পানি ও গ্যাস শোষণ; অনেক সময় ক্লোরোপ্লাস্টযুক্ত', 180, 22, 10], ['বায়ুকুঠুরি (অ্যারেনকাইমা)', 'বড় বড় বায়ুপূর্ণ ফাঁকা স্থান — দেহকে হালকা করে ভাসায় এবং O<sub>2</sub> ও CO<sub>2</sub> জমিয়ে রাখে', 124, 104, 5], ['কর্টেক্স', 'পাতলা প্রাচীরের প্যারেনকাইমা; যান্ত্রিক টিস্যু (স্ক্লেরেনকাইমা) প্রায় নেই, তাই দেহ নমনীয় — স্রোতে ভেঙে যায় না', 236, 70, 6], ['সংবহন গুচ্ছ', 'কেন্দ্রে অল্প; জাইলেম খুব কম গঠিত, কারণ পানি পরিবহনের প্রয়োজন সামান্য', 180, 128, 2], ['জাইলেম গহ্বর', 'অনেক সময় জাইলেম ভেঙে ফাঁকা নালি (প্রোটোজাইলেম ক্যানেল) তৈরি হয়', 196, 140, 4]];
V.hydroAnat = Object.assign({}, B.seg({
  id: 'han', t: 'জলজ উদ্ভিদের অন্তর্গঠন (কাণ্ডের প্রস্থচ্ছেদ)', H: 250, def: 'ts', sel: null,
  cap: 'জলজ উদ্ভিদের অন্তর্গঠনের মূল বৈশিষ্ট্য — কিউটিকলবিহীন পাতলা এপিডার্মিস, প্রচুর বায়ুকুঠুরি, যান্ত্রিক টিস্যুর অভাব ও দুর্বল জাইলেম। উদাহরণ — হাইড্রিলা বা পদ্মের কাণ্ড। যেকোনো অংশে চাপ দাও।',
  types: { ts: ['প্রস্থচ্ছেদ', 'কাণ্ডের প্রস্থচ্ছেদ', 'অংশে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    const cx = 180, cy = 128, R = 100, Rg = BK.ramp(10);
    E('circle', { cx, cy, r: R + 3, fill: FK.alpha(Rg.c, .35), stroke: Rg.dk, 'stroke-width': 1.5 }, g);
    E('circle', { cx, cy, r: R - 6, fill: FK.alpha(BK.ramp(6).c, .12), stroke: 'none' }, g);
    for (let i = 0; i < 12; i++) { const a = i / 12 * PI * 2, rr = 62; B.blob(g, cx + rr * Math.cos(a), cy + rr * Math.sin(a), 15, { n: 8, seed: i + 3, j: .25, fill: FK.alpha(BK.ramp(5).c, .25), stroke: BK.ramp(5).dk, sw: 1 }); }
    for (let i = 0; i < 40; i++) { const a = i / 40 * PI * 2, rr = 88 + (i % 2) * 5; E('circle', { cx: cx + rr * Math.cos(a), cy: cy + rr * Math.sin(a), r: 4, fill: 'none', stroke: FK.alpha(BK.ramp(6).dk, .5), 'stroke-width': .7 }, g); }
    E('circle', { cx, cy, r: 26, fill: FK.alpha(BK.ramp(2).c, .22), stroke: BK.ramp(2).dk, 'stroke-width': 1.2 }, g);
    E('circle', { cx: cx + 16, cy: cy + 12, r: 6, fill: C.sf, stroke: BK.ramp(4).dk, 'stroke-width': 1.2 }, g);
    for (let i = 0; i < 5; i++) E('circle', { cx: cx - 10 + (i % 3) * 8, cy: cy - 8 + Math.floor(i / 3) * 8, r: 2.6, fill: BK.ramp(2).dk }, g);
    HAN.forEach(([s, , x, y, ri], i) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r: 12, fill: 'none', stroke: BK.ramp(ri).dk, 'stroke-width': 2.4 }, g); });
    T(g, 20, 240, 'এপিডার্মিস · বায়ুকুঠুরি · কর্টেক্স · সংবহন গুচ্ছ', { fs: 8.8, c: C.mu });
    ctx.H = HAN.map((h, i) => [h[2], h[3], i]);
  },
  anim(g, C, ty, t) { if (!t) return; for (let i = 0; i < 6; i++) { const a = i / 6 * PI * 2 + t * .3, k = (t * .5 + i / 6) % 1; E('circle', { cx: 180 + 62 * Math.cos(a), cy: 128 + 62 * Math.sin(a), r: 2 + k * 3, fill: 'none', stroke: BK.ramp(5).dk, 'stroke-width': .8, opacity: 1 - k }, g); } },
  tap(x, y, ty, ctx) {
    const d = Math.hypot(x - 180, y - 128); let i = d > 94 ? 0 : d > 78 ? 2 : d > 30 ? 1 : (Math.hypot(x - 196, y - 140) < 8 ? 4 : 3);
    ctx.sel = i; const h = HAN[i]; return `<b>${h[0]}</b> — ${h[1]}`;
  }
}));

/* ═════════ ৪. মরুজ উদ্ভিদের প্রকার ═════════ */
V.xeroTypes = Object.assign({}, B.seg({
  id: 'xet', t: 'মরুজ উদ্ভিদ (জেরোফাইট)', H: 250, def: 'suc',
  cap: 'মরুজ উদ্ভিদ বা জেরোফাইট — যে উদ্ভিদ শুষ্ক, পানির অভাবযুক্ত পরিবেশে (মরুভূমি, পাথুরে বা বালুময় মাটি) জন্মায় ও টিকে থাকে। কৌশল তিন রকম — খরা এড়ানো (ক্ষণজীবী), খরা সহ্য করা ও পানি জমিয়ে রাখা (রসালো) এবং পানি হারানো কমানো (অরসালো)।',
  types: {
    eph: ['ক্ষণজীবী', 'ক্ষণজীবী (খরা এড়ায়)', 'অল্প বৃষ্টির পর দ্রুত অঙ্কুরিত হয়ে কয়েক সপ্তাহে ফুল-বীজ দিয়ে জীবনচক্র শেষ করে; শুকনো সময় বীজ হিসেবে কাটায় — যেমন মরুভূমির কিছু বর্ষজীবী ঘাস ও বীরুৎ। প্রকৃত অর্থে এরা খরা সহ্য করে না, এড়িয়ে চলে।'],
    suc: ['রসালো', 'রসালো (পানি জমায়)', 'কাণ্ড বা পাতার রসালো প্যারেনকাইমায় মিউসিলেজের সাথে পানি জমায় — ফণিমনসা (Opuntia; চ্যাপ্টা সবুজ কাণ্ড পর্ণকাণ্ড বা ফাইলোক্লেড, পাতা কাঁটায় রূপান্তরিত), ঘৃতকুমারী (Aloe; রসালো পাতা), সিজ (Euphorbia)। রাতে পত্ররন্ধ্র খোলে — CAM বিপাক।'],
    non: ['অরসালো', 'অরসালো (পানি হারানো কমায়)', 'পানি জমায় না, কিন্তু প্রস্বেদন কমানোর নানা গঠন থাকে — আকন্দ (Calotropis; পুরু মোমযুক্ত পাতা), করবী (Nerium; গর্তে নিমজ্জিত রন্ধ্র), ঝাউ (Casuarina; শল্কপত্র), বাবলা জাতীয় কিছু Acacia (পাতার বদলে চ্যাপ্টা পত্রবৃন্ত — ফাইলোড)। মূল খুব গভীরে যায়।']
  },
  art(g, C, ty) {
    const Rs = BK.ramp(11), Rg = BK.ramp(10), Ry = BK.ramp(7);
    E('rect', { x: 0, y: 196, width: 360, height: 60, fill: FK.alpha(BK.ramp(6).c, .25) }, g); for (let i = 0; i < 30; i++) E('circle', { cx: rnd(i) * 360, cy: 204 + rnd(i + 9) * 44, r: 1.2, fill: Rs.dk, opacity: .6 }, g);
    E('circle', { cx: 330, cy: 30, r: 16, fill: BK.ramp(2).c, opacity: .75 }, g);
    if (ty === 'suc') {
      const pad = (x, y, rx, ry, a) => { E('ellipse', { cx: x, cy: y, rx, ry, transform: `rotate(${a} ${x} ${y})`, fill: Rg.c, stroke: Rg.dk, 'stroke-width': 1.1 }, g); for (let i = 0; i < 6; i++) { const px = x + (rnd(i + x) - .5) * rx * 1.2, py = y + (rnd(i + y) - .5) * ry * 1.2; E('path', { d: `M${px} ${py}l-4 -4M${px} ${py}l4 -4`, stroke: '#f5f0e0', 'stroke-width': 1 }, g); } };
      pad(90, 168, 20, 30, 0); pad(66, 122, 16, 24, -30); pad(114, 116, 16, 24, 28); pad(96, 76, 13, 19, 6);
      E('ellipse', { cx: 96, cy: 58, rx: 6, ry: 4, fill: BK.ramp(7).c }, g);
      lab(g, 110, 116, 150, 100, 'পর্ণকাণ্ড (রসালো চ্যাপ্টা কাণ্ড)', C, { fs: 9.6 }); lab(g, 78, 150, 150, 150, 'কাঁটা = রূপান্তরিত পাতা', C, { fs: 9.6 });
      for (let i = 0; i < 6; i++) { const a = PI * .15 + i * .15; E('path', { d: `M250 196q${Math.cos(a) * 8} ${-30} ${Math.cos(a) * 30 - 10} ${-60 - i * 4}`, stroke: Rg.dk, 'stroke-width': 9 - i, fill: 'none', 'stroke-linecap': 'round', opacity: .85 }, g); }
      T(g, 250, 120, 'ঘৃতকুমারী — রসালো পাতা', { fs: 9.6, a: 'middle', c: C.mu });
      T(g, 180, 240, 'রাতে রন্ধ্র খোলে, দিনে বন্ধ — CAM', { fs: 9.6, a: 'middle', w: 650, c: BK.ramp(3).ink });
    } else if (ty === 'non') {
      E('path', { d: 'M100 196V70', stroke: Rs.dk, 'stroke-width': 4 }, g);
      for (let i = 0; i < 4; i++) { const y = 170 - i * 28; leafE(g, 82, y, 18, 8, -15, BK.ramp(10)); leafE(g, 118, y - 10, 18, 8, 15, BK.ramp(10)); }
      E('path', { d: 'M100 196V250M100 210l-24 36M100 214l20 34', stroke: Rs.dk, 'stroke-width': 1.6, fill: 'none' }, g);
      lab(g, 118, 132, 156, 116, 'পুরু, চকচকে মোমযুক্ত পাতা', C, { fs: 9.6 }); lab(g, 100, 236, 140, 236, 'গভীর মূল', C, { fs: 9.6 });
      E('path', { d: 'M260 196V60', stroke: Rs.dk, 'stroke-width': 2 }, g);
      for (let i = 0; i < 10; i++) E('path', { d: `M260 ${190 - i * 13}q${i % 2 ? 22 : -22} 4 ${i % 2 ? 30 : -30} 18`, stroke: BK.ramp(10).dk, 'stroke-width': 1.2, fill: 'none' }, g);
      T(g, 260, 50, 'ঝাউ — শল্কপত্র, সবুজ শাখা', { fs: 9.6, a: 'middle', c: C.mu });
    } else {
      [[60, 0], [150, 1], [250, 2]].forEach(([x, st]) => {
        T(g, x, 40, ['বৃষ্টি', 'দ্রুত বৃদ্ধি ও ফুল', 'বীজ — খরা কাটায়'][st], { fs: 9.8, a: 'middle', w: 650, c: C.fg });
        if (st === 0) for (let i = 0; i < 8; i++) E('path', { d: `M${x - 24 + i * 7} ${60 + (i % 3) * 8}l-3 8`, stroke: BK.ramp(5).dk, 'stroke-width': 1.4 }, g);
        if (st >= 1) { E('path', { d: `M${x} 196V${st === 1 ? 140 : 160}`, stroke: BK.ramp(10).dk, 'stroke-width': 1.8 }, g); leafE(g, x - 8, 170, 9, 4, -20, BK.ramp(10)); leafE(g, x + 8, 166, 9, 4, 20, BK.ramp(10)); if (st === 1) E('circle', { cx: x, cy: 136, r: 7, fill: BK.ramp(8).c }, g); }
        if (st === 2) for (let i = 0; i < 6; i++) E('ellipse', { cx: x - 20 + i * 8, cy: 202, rx: 3, ry: 2, fill: Rs.dk }, g);
        if (st < 2) arrow(g, x + 26, 110, x + 64, 110, C.mu, { w: 1.2 });
      });
      T(g, 180, 240, 'পুরো জীবনচক্র কয়েক সপ্তাহে', { fs: 9.6, a: 'middle', w: 650, c: BK.ramp(6).ink });
    }
  },
  anim(g, C, ty, t) { if (!t) return; const k = (t * .6) % 1; for (let i = 0; i < 3; i++) E('path', { d: `M${300 + i * 12} ${60 + k * 40}q4 -6 0 -12`, stroke: BK.ramp(2).c, 'stroke-width': 1.3, fill: 'none', opacity: 1 - k }, g); }
}));

/* ═════════ ৫. করবীর পাতার প্রস্থচ্ছেদ ═════════ */
const XL = [['পুরু কিউটিকল', 'মোমের মতো কিউটিন স্তর — কিউটিকলীয় প্রস্বেদন প্রায় বন্ধ করে', 30, 22, 7], ['বহুস্তরী এপিডার্মিস', '২–৩ স্তরের এপিডার্মিস — পানি হারানো কমায় ও তাপ থেকে রক্ষা করে', 70, 38, 6], ['প্যালিসেড প্যারেনকাইমা', 'ঘন সন্নিবিষ্ট, দুই তলেই থাকতে পারে', 120, 64, 10], ['নিমজ্জিত পত্ররন্ধ্র', 'নিচের তলে গর্তের (ক্রিপ্ট) ভেতরে রন্ধ্র; গর্তের মুখে রোম — ভেতরে আর্দ্র বাতাস আটকে রেখে প্রস্বেদন কমায়', 220, 178, 3], ['ত্বকীয় রোম', 'গর্তের রোম বায়ুপ্রবাহ কমায় ও আলো প্রতিফলিত করে', 236, 156, 9], ['স্ক্লেরেনকাইমা ও জাইলেম', 'সুগঠিত যান্ত্রিক টিস্যু — পাতা শুকিয়েও নুয়ে পড়ে না; জাইলেম সুগঠিত', 180, 112, 2]];
V.xeroLeaf = Object.assign({}, B.seg({
  id: 'xel', t: 'মরুজ উদ্ভিদের পাতার অন্তর্গঠন (করবী)', H: 250, def: 'ts', sel: null,
  cap: 'করবী (Nerium oleander) এর পাতার প্রস্থচ্ছেদ মরুজ অভিযোজনের আদর্শ উদাহরণ — পুরু কিউটিকল, বহুস্তরী এপিডার্মিস, রোমযুক্ত গর্তে নিমজ্জিত পত্ররন্ধ্র ও সুগঠিত যান্ত্রিক টিস্যু। প্রতিটি বৈশিষ্ট্যের লক্ষ্য একটাই — প্রস্বেদনে পানি হারানো কমানো। অংশে চাপ দাও।',
  types: { ts: ['প্রস্থচ্ছেদ', 'পাতার প্রস্থচ্ছেদ', 'অংশে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    const R7 = BK.ramp(7), R6 = BK.ramp(6), R10 = BK.ramp(10);
    E('path', { d: 'M16 30H344V40H16Z', fill: FK.alpha(R7.c, .7), stroke: R7.dk }, g);
    for (let r = 0; r < 3; r++) for (let i = 0; i < 22; i++) E('rect', { x: 16 + i * 15, y: 40 + r * 9, width: 15, height: 9, fill: FK.alpha(R6.c, .2), stroke: FK.alpha(R6.dk, .6), 'stroke-width': .6 }, g);
    for (let i = 0; i < 33; i++) E('rect', { x: 17 + i * 10, y: 68, width: 8, height: 30, rx: 3, fill: FK.alpha(R10.c, .55), stroke: R10.dk, 'stroke-width': .5 }, g);
    for (let i = 0; i < 26; i++) E('circle', { cx: 26 + (i % 13) * 25 + (i > 12 ? 12 : 0), cy: 112 + (i > 12 ? 18 : 0), r: 9, fill: FK.alpha(R10.c, .2), stroke: FK.alpha(R10.dk, .5), 'stroke-width': .6 }, g);
    E('circle', { cx: 180, cy: 112, r: 16, fill: FK.alpha(BK.ramp(2).c, .3), stroke: BK.ramp(2).dk, 'stroke-width': 1.2 }, g);
    for (let i = 0; i < 5; i++) E('circle', { cx: 172 + (i % 3) * 8, cy: 106 + Math.floor(i / 3) * 10, r: 3, fill: BK.ramp(2).dk }, g);
    /* নিচের এপিডার্মিস ও ক্রিপ্ট */
    E('path', { d: 'M16 150H196Q200 150 200 156V188Q220 200 240 188V156Q240 150 244 150H344V160H250V196Q220 214 190 196V160H16Z', fill: FK.alpha(R6.c, .2), stroke: R6.dk, 'stroke-width': .9 }, g);
    E('path', { d: 'M16 160H190V196Q220 214 250 196V160H344V170H16Z', fill: FK.alpha(R7.c, .7), stroke: R7.dk, 'stroke-width': .8 }, g);
    for (let i = 0; i < 9; i++) E('path', { d: `M${200 + i * 5} ${172 + Math.abs(i - 4)}l${i < 4 ? 4 : -4} ${-12}`, stroke: BK.ramp(9).dk, 'stroke-width': 1 }, g);
    E('ellipse', { cx: 220, cy: 194, rx: 6, ry: 3, fill: BK.ramp(3).c, stroke: BK.ramp(3).dk }, g);
    XL.forEach(([s, , x, y, ri], i) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r: 12, fill: 'none', stroke: BK.ramp(ri).dk, 'stroke-width': 2.4 }, g); });
    T(g, 180, 232, 'ওপরে → নিচে: কিউটিকল, এপিডার্মিস, প্যালিসেড, স্পঞ্জি, ক্রিপ্ট', { fs: 8.8, a: 'middle', c: C.mu });
    ctx.H = XL.map((h, i) => [h[2], h[3], i]);
  },
  anim(g, C, ty, t) { if (!t) return; const k = (t * .6) % 1; E('circle', { cx: 220, cy: 192 + k * 30, r: 2.2, fill: BK.ramp(5).c, opacity: (1 - k) * .4 }, g); },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 60); if (!h) return null; ctx.sel = h[2]; const d = XL[h[2]]; return `<b>${d[0]}</b> — ${d[1]}`; }
}));
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B12, XB = window.B12X;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot, chip = B.chip, lab = B.lab;
const arrow = XB.arrow, okm = XB.okm, nope = XB.nope, cmp = XB.cmp, org = XB.org;
const pin = (g, x, y, on, R) => { E('circle', { cx: x, cy: y, r: on ? 7 : 5, fill: on ? R.c : C0().sf, stroke: R.dk, 'stroke-width': 1.6 }, g); };
const C0 = () => FK.P();

/* ═════════ ৬. মরুজ প্রাণী — উট ═════════ */
const CAM = [
  ['কুঁজ', 'চর্বি জমা থাকে, পানি নয়। খাদ্যাভাবে চর্বি জারিত হয়ে শক্তি ও বিপাকীয় পানি দেয়; চর্বি পুরো দেহে না ছড়িয়ে এক জায়গায় থাকায় দেহের তাপ বের হওয়াও সহজ হয়।', 152, 74],
  ['চোখ ও নাক', 'দুই সারি লম্বা পাপড়ি ও স্বচ্ছ তৃতীয় চোখের পাতা বালু থেকে চোখ রক্ষা করে; নাসারন্ধ্র ইচ্ছামতো বন্ধ করা যায়, আর নাকের ভেতরে শ্বাসের জলীয় বাষ্প ফিরিয়ে নেওয়া হয়।', 290, 60],
  ['পা ও পায়ের তলা', 'লম্বা পা দেহকে গরম বালু থেকে দূরে রাখে; চওড়া নরম গদির মতো পায়ের তলা বালুতে ডুবে যেতে দেয় না।', 196, 210],
  ['দেহের তাপমাত্রা', 'দিনে দেহের তাপ প্রায় 34 থেকে 41 °C পর্যন্ত ওঠানামা করতে দেয় — ফলে ঘাম কম হয়, পানি বাঁচে; রাতে জমা তাপ ছেড়ে দেয়।', 120, 110],
  ['রক্ত ও পানি সহনশীলতা', 'দেহের ওজনের প্রায় এক-চতুর্থাংশ পানি হারিয়েও বাঁচতে পারে; ডিম্বাকার লোহিত কণিকা হঠাৎ প্রচুর পানি পানের পরও ফেটে যায় না — এক দফায় 100 লিটারের বেশি পানি খেতে পারে।', 176, 112],
  ['বৃক্ক ও মল', 'অত্যন্ত ঘন মূত্র ও শুকনো মল ত্যাগ করে — বর্জ্যের সাথে পানি প্রায় যায় না।', 80, 136]
];
V.camelAdapt = Object.assign({}, B.seg({
  id: 'cam', t: 'মরুজ প্রাণীর অভিযোজন', H: 250, def: 'cam', sel: null,
  cap: 'মরুভূমির প্রাণীর প্রধান সমস্যা — পানির অভাব, দিনে প্রচণ্ড গরম ও রাতে ঠান্ডা, বালুঝড়। অভিযোজনের তিন কৌশল: পানি সংরক্ষণ (ঘন মূত্র, শুকনো মল, বিপাকীয় পানি), তাপ এড়ানো (নিশাচর জীবন, গর্তে বাস, বড় কান) এবং দেহের গঠনগত পরিবর্তন।',
  types: {
    cam: ['উট', 'উট — "মরুভূমির জাহাজ"', 'অংশে চাপ দিয়ে অভিযোজন দেখো।'],
    oth: ['অন্যান্য', 'অন্যান্য মরুজ প্রাণী', 'ক্যাঙারু ইঁদুর কখনো পানি পান করে না — শুকনো বীজের বিপাক থেকে পাওয়া পানিতেই চলে, আর দিনে ঠান্ডা গর্তে থাকে। ফেনেক শিয়ালের বড় কান দিয়ে দেহের তাপ বের হয়। সরীসৃপের আঁশযুক্ত শুষ্ক ত্বক পানি হারানো রোধ করে এবং এরা নাইট্রোজেন বর্জ্য প্রায় শুকনো ইউরিক অ্যাসিড হিসেবে ত্যাগ করে।']
  },
  art(g, C, ty, ctx) {
    E('rect', { x: 0, y: 214, width: 360, height: 40, fill: FK.alpha(BK.ramp(6).c, .3) }, g);
    if (ty === 'oth') {
      const items = [['ক্যাঙারু ইঁদুর', 'বিপাকীয় পানি, গর্তে বাস', 70, 6], ['ফেনেক শিয়াল', 'বড় কান — তাপ ছাড়ে', 180, 2], ['সরীসৃপ', 'আঁশ, ইউরিক অ্যাসিড', 290, 10]];
      items.forEach(([s, d, x, ri]) => { const R = BK.ramp(ri); E('circle', { cx: x, cy: 110, r: 46, fill: FK.alpha(R.c, .12), stroke: R.dk }, g); T(g, x, 176, s, { fs: 11, a: 'middle', w: 700, c: R.ink }); T(g, x, 194, d, { fs: 9, a: 'middle', c: C.mu }); });
      org(g, 'rabbit', 64, 130, 1.3);
      E('ellipse', { cx: 180, cy: 124, rx: 18, ry: 11, fill: '#e3b77a', stroke: '#8a5d24' }, g); E('path', { d: 'M168 116l-10 -34l18 22M192 116l10 -34l-18 22', fill: '#e3b77a', stroke: '#8a5d24', 'stroke-width': 1 }, g);
      E('path', { d: 'M266 128q12 -16 24 0t24 0', stroke: BK.ramp(10).dk, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g);
      return;
    }
    const Rc = { c: '#d8a865', dk: '#7d5524' };
    /* পা */
    [[84, 150], [108, 152], [196, 152], [222, 150]].forEach(([x, y]) => { E('path', { d: `M${x} ${y}V212`, stroke: Rc.dk, 'stroke-width': 9, 'stroke-linecap': 'round' }, g); E('path', { d: `M${x} ${y}V210`, stroke: Rc.c, 'stroke-width': 6, 'stroke-linecap': 'round' }, g); E('ellipse', { cx: x, cy: 214, rx: 10, ry: 4, fill: Rc.dk }, g); });
    /* দেহ, কুঁজ, গলা, মাথা */
    E('ellipse', { cx: 152, cy: 128, rx: 92, ry: 32, fill: Rc.c, stroke: Rc.dk, 'stroke-width': 1.6 }, g);
    E('path', { d: 'M104 106Q120 54 152 52Q186 54 200 106Z', fill: Rc.c, stroke: Rc.dk, 'stroke-width': 1.6 }, g);
    E('path', { d: 'M226 112Q250 104 256 84L262 64L278 64L270 92Q262 124 236 140Z', fill: Rc.c, stroke: Rc.dk, 'stroke-width': 1.6, 'stroke-linejoin': 'round' }, g);
    E('path', { d: 'M258 70Q262 52 280 54Q296 56 300 66Q300 76 288 76L270 74Z', fill: Rc.c, stroke: Rc.dk, 'stroke-width': 1.6 }, g);
    E('circle', { cx: 280, cy: 62, r: 2.4, fill: Rc.dk }, g); E('path', { d: 'M296 68l4 2', stroke: Rc.dk, 'stroke-width': 1.4 }, g);
    E('path', { d: 'M62 122Q48 132 52 152', stroke: Rc.dk, 'stroke-width': 2.4, fill: 'none' }, g);
    CAM.forEach(([s, , x, y], i) => { const on = ctx.sel === i; pin(g, x, y, on, BK.ramp(on ? 4 : 3)); });
    ctx.H = CAM.map((c, i) => [c[2], c[3], i]);
  },
  anim(g, C, ty, t) { if (!t) return; const k = (t * .5) % 1; for (let i = 0; i < 3; i++) E('path', { d: `M${40 + i * 120 + k * 30} ${236}q6 -4 12 0`, stroke: BK.ramp(6).dk, 'stroke-width': 1.2, fill: 'none', opacity: 1 - k }, g); },
  tap(x, y, ty, ctx) { if (ty !== 'cam') return null; const h = hot(ctx.H || [], x, y, 34); if (!h) return null; ctx.sel = h[2]; const d = CAM[h[2]]; return `<b>${d[0]}</b> — ${d[1]}`; }
}));

/* ═════════ ৭. জলজ প্রাণী — মাছ ═════════ */
const FISH = [
  ['মাকু আকৃতির দেহ', 'দুই প্রান্ত সরু, মাঝখান মোটা — পানির বাধা কমিয়ে সহজে সাঁতার কাটতে দেয়।', 120, 70],
  ['ফুলকা', 'পানিতে দ্রবীভূত অক্সিজেন গ্রহণ করে; বহু সূক্ষ্ম ফুলকা-সূত্রে বিশাল তল, প্রতিস্রোত প্রবাহে দক্ষ গ্যাস বিনিময়।', 250, 96],
  ['পাখনা', 'বক্ষ ও শ্রোণি পাখনা দিক ও ভারসাম্য রাখে; পুচ্ছ পাখনা সামনে এগোতে ধাক্কা দেয়।', 40, 100],
  ['বায়ুথলি', 'গ্যাসের পরিমাণ বদলে পানিতে ভাসা-ডোবা নিয়ন্ত্রণ করে — কম শক্তিতে নির্দিষ্ট গভীরতায় থাকা যায়।', 160, 110],
  ['পার্শ্বরেখা', 'দেহের দুই পাশে সংবেদী অঙ্গ — পানির কম্পন ও স্রোত টের পায়; ঘোলা পানিতে চলাচলে সাহায্য করে।', 180, 92],
  ['আঁশ ও পিচ্ছিল শ্লেষ্মা', 'আঁশ দেহ রক্ষা করে; শ্লেষ্মা ঘর্ষণ কমায় ও জীবাণু থেকে রক্ষা করে।', 96, 112]
];
V.fishAdapt = Object.assign({}, B.seg({
  id: 'fsh', t: 'জলজ প্রাণীর অভিযোজন', H: 250, def: 'fish', sel: null,
  cap: 'পানিতে অক্সিজেন বাতাসের তুলনায় অনেক কম, পানির ঘনত্ব ও বাধা বেশি, আর তাপমাত্রা তুলনামূলক স্থির। জলজ প্রাণীর অভিযোজন তাই সাঁতার, শ্বসন, ভাসমানতা ও লবণ-পানির ভারসাম্য ঘিরে। মাছের অংশে চাপ দাও।',
  types: {
    fish: ['মাছ', 'মাছের অভিযোজন', 'অংশে চাপ দাও।'],
    mam: ['জলজ স্তন্যপায়ী', 'শুশুক, তিমি ও ব্যাঙ', 'শুশুক ও তিমি — মাকু আকৃতির দেহ, পাখনার মতো রূপান্তরিত অগ্রপদ, ত্বকের নিচে পুরু চর্বিস্তর (ব্লাবার) দেহের তাপ ধরে রাখে, মাথার ওপরে শ্বাসছিদ্র; ফুসফুসে শ্বাস নেয়, তাই নিয়মিত পানির ওপরে আসতে হয়। ব্যাঙ — পায়ের আঙুলের মাঝে লিপ্তপদ, পানিতে আর্দ্র ত্বক দিয়ে শ্বাস নেয়।']
  },
  art(g, C, ty, ctx) {
    E('rect', { x: 0, y: 0, width: 360, height: 254, fill: FK.alpha(BK.ramp(5).c, .14) }, g);
    if (ty === 'mam') {
      E('path', { d: 'M30 120Q90 70 200 88Q260 96 300 116L330 104L320 124L334 144L300 132Q240 156 150 150Q70 146 30 120Z', fill: '#9aa8b5', stroke: '#4a5866', 'stroke-width': 1.4 }, g);
      E('path', { d: 'M150 150L140 178L168 152Z', fill: '#9aa8b5', stroke: '#4a5866' }, g); E('path', { d: 'M170 90L186 60L196 92Z', fill: '#9aa8b5', stroke: '#4a5866' }, g);
      E('path', { d: 'M30 120Q20 116 14 118', stroke: '#4a5866', 'stroke-width': 2 }, g); E('circle', { cx: 56, cy: 112, r: 2.4, fill: '#222' }, g);
      lab(g, 110, 86, 110, 40, 'শ্বাসছিদ্র (ওপরে)', C, { fs: 9.6, a: 'middle' }); lab(g, 150, 160, 120, 210, 'পাখনা (রূপান্তরিত অগ্রপদ)', C, { fs: 9.6 }); lab(g, 230, 140, 260, 200, 'ব্লাবার — পুরু চর্বিস্তর', C, { fs: 9.6 });
      T(g, 180, 236, 'শুশুক (গাঙ্গেয় ডলফিন) — প্রায় অন্ধ, শব্দের প্রতিধ্বনিতে পথ চেনে', { fs: 9, a: 'middle', c: C.mu });
      return;
    }
    const R2 = BK.ramp(2);
    E('path', { d: 'M40 100Q100 52 200 66Q262 74 296 100Q262 130 200 136Q100 146 40 100Z', fill: FK.alpha(R2.c, .55), stroke: R2.dk, 'stroke-width': 1.5 }, g);
    E('path', { d: 'M42 100L10 72L18 100L10 128Z', fill: FK.alpha(R2.c, .55), stroke: R2.dk, 'stroke-width': 1.2 }, g);
    E('path', { d: 'M150 66L170 40L196 66M160 134L172 158L186 134', fill: FK.alpha(R2.c, .4), stroke: R2.dk, 'stroke-width': 1 }, g);
    E('path', { d: 'M250 96Q240 108 252 118', stroke: R2.dk, 'stroke-width': 2, fill: 'none' }, g);
    E('path', { d: 'M60 92Q170 86 286 94', stroke: BK.ramp(3).dk, 'stroke-width': 1.2, 'stroke-dasharray': '2 2', fill: 'none' }, g);
    E('ellipse', { cx: 160, cy: 110, rx: 34, ry: 9, fill: FK.alpha('#fff', .6), stroke: BK.ramp(5).dk, 'stroke-width': .9 }, g);
    E('circle', { cx: 272, cy: 90, r: 4, fill: '#222' }, g);
    for (let i = 0; i < 18; i++) E('path', { d: `M${70 + (i % 9) * 18} ${100 + Math.floor(i / 9) * 14}q6 -6 12 0`, stroke: FK.alpha(R2.dk, .5), 'stroke-width': .7, fill: 'none' }, g);
    FISH.forEach(([s, , x, y], i) => { const on = ctx.sel === i; pin(g, x, y, on, BK.ramp(on ? 4 : 3)); });
    T(g, 180, 200, 'পুচ্ছ পাখনা ধাক্কা দেয় · পার্শ্বরেখা কম্পন টের পায়', { fs: 9.4, a: 'middle', c: C.mu });
    ctx.H = FISH.map((f, i) => [f[2], f[3], i]);
  },
  anim(g, C, ty, t) { if (!t) return; for (let i = 0; i < 3; i++) { const k = (t * .5 + i / 3) % 1; E('circle', { cx: 300 + k * 20, cy: 90 - k * 70, r: 2 + k * 3, fill: 'none', stroke: BK.ramp(5).dk, 'stroke-width': .9, opacity: 1 - k }, g); } },
  tap(x, y, ty, ctx) { if (ty !== 'fish') return null; const h = hot(ctx.H || [], x, y, 30); if (!h) return null; ctx.sel = h[2]; const d = FISH[h[2]]; return `<b>${d[0]}</b> — ${d[1]}`; }
}));

/* ═════════ ৮. ম্যানগ্রোভের মূল ও জরায়ুজ অঙ্কুরোদগম ═════════ */
V.mangroveRoots = Object.assign({}, B.seg({
  id: 'mgr', t: 'লোনামাটির উদ্ভিদ — শ্বাসমূল, ঠেসমূল ও জরায়ুজ অঙ্কুরোদগম', H: 256, def: 'pn',
  cap: 'হ্যালোফাইট বা লোনামাটির উদ্ভিদ — যে উদ্ভিদ উচ্চ লবণাক্ত মাটি বা পানিতে জন্মায়; সুন্দরবনের ম্যানগ্রোভ উদ্ভিদ প্রধান উদাহরণ। জোয়ারে ডুবে থাকা কাদামাটি অক্সিজেনহীন, নরম ও লবণাক্ত — এ তিন সমস্যার সমাধান হিসেবে শ্বাসমূল, ঠেসমূল ও জরায়ুজ অঙ্কুরোদগম গড়ে উঠেছে। চালাও চাপলে জোয়ার-ভাটা দেখবে।',
  types: {
    pn: ['শ্বাসমূল', 'শ্বাসমূল (নিউমাটোফোর)', 'অক্সিজেনহীন কাদা থেকে মূলের শাখা খাড়া হয়ে মাটির ওপরে ওঠে; এদের গায়ের অসংখ্য ছিদ্র (নিউমাথোড বা লেন্টিসেল) দিয়ে ভাটার সময় বাতাস ঢোকে — বাইন (Avicennia), কেওড়া (Sonneratia), সুন্দরী (Heritiera fomes)।'],
    stl: ['ঠেসমূল', 'ঠেসমূল (স্টিল্ট রুট)', 'কাণ্ডের নিচের অংশ থেকে বাঁকা মূল নেমে নরম কাদায় খুঁটির মতো গাছকে দাঁড় করিয়ে রাখে ও জোয়ারের ধাক্কা সামলায় — গর্জন বা ঝানা (Rhizophora)।'],
    vv: ['জরায়ুজ অঙ্কুরোদগম', 'জরায়ুজ অঙ্কুরোদগম (ভিভিপ্যারি)', 'বীজ গাছে থাকা অবস্থাতেই ফলের ভেতরে অঙ্কুরিত হয়; লম্বা ভারী ভ্রূণমূল (হাইপোকোটাইল) নিয়ে চারা নিচে পড়ে কাদায় গেঁথে যায়, নইলে লবণাক্ত পানিতে বীজ অঙ্কুরিত হতে পারত না বা জোয়ারে ভেসে যেত — গরান (Ceriops), কাঁকড়া (Bruguiera), Rhizophora।']
  },
  art(g, C, ty, ctx) {
    E('rect', { x: 0, y: 176, width: 360, height: 80, fill: FK.alpha(BK.ramp(11).c, .55) }, g); E('path', { d: 'M0 176H360', stroke: BK.ramp(11).dk, 'stroke-width': 1.4 }, g);
    const Rw = { c: '#8a6a4a', dk: '#4f3a26' }, Rg = BK.ramp(10);
    const crown = (x, y, rx) => { E('ellipse', { cx: x, cy: y, rx, ry: rx * .45, fill: FK.alpha(Rg.c, .85), stroke: Rg.dk }, g); E('ellipse', { cx: x - rx * .5, cy: y + 6, rx: rx * .5, ry: rx * .3, fill: FK.alpha(Rg.c, .85), stroke: Rg.dk }, g); };
    if (ty === 'pn') {
      E('path', { d: 'M120 176V60', stroke: Rw.dk, 'stroke-width': 9 }, g); crown(120, 54, 60);
      E('path', { d: 'M120 190H20M120 196H300', stroke: Rw.dk, 'stroke-width': 3 }, g);
      for (let i = 0; i < 14; i++) { const x = 24 + i * 20 + (i > 4 ? 10 : 0); if (Math.abs(x - 120) < 12) continue; E('path', { d: `M${x} 193V${150 - (i % 3) * 6}`, stroke: Rw.dk, 'stroke-width': 3.4, 'stroke-linecap': 'round' }, g); for (let k = 0; k < 3; k++) E('circle', { cx: x, cy: 158 - k * 6 - (i % 3) * 6, r: .9, fill: '#f2e7d4' }, g); }
      lab(g, 184, 150, 240, 120, 'খাড়া শ্বাসমূল — ছিদ্র দিয়ে বাতাস ঢোকে', C, { fs: 9.6 });
    } else if (ty === 'stl') {
      E('path', { d: 'M180 140V50', stroke: Rw.dk, 'stroke-width': 9 }, g); crown(180, 46, 66);
      for (let i = -3; i <= 3; i++) { if (!i) continue; E('path', { d: `M180 ${120 + Math.abs(i) * 4}Q${180 + i * 22} ${110 + Math.abs(i) * 2} ${180 + i * 34} 186`, stroke: Rw.dk, 'stroke-width': 3.4, fill: 'none' }, g); }
      E('path', { d: 'M180 140V160', stroke: Rw.dk, 'stroke-width': 5 }, g);
      lab(g, 240, 160, 280, 120, 'বাঁকা ঠেসমূল — খুঁটির মতো', C, { fs: 9.6 });
    } else {
      E('path', { d: 'M90 176V60', stroke: Rw.dk, 'stroke-width': 8 }, g); crown(90, 54, 56);
      E('path', { d: 'M150 70H226', stroke: Rw.dk, 'stroke-width': 3 }, g); leafE2(g, 186, 64);
      const st = [[166, 76, 18], [192, 76, 36], [218, 76, 58]];
      st.forEach(([x, y, L], i) => { E('ellipse', { cx: x, cy: y + 4, rx: 6, ry: 8, fill: BK.ramp(6).c, stroke: BK.ramp(6).dk }, g); E('path', { d: `M${x} ${y + 12}V${y + 12 + L}`, stroke: Rg.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, g); });
      T(g, 192, 160, 'গাছেই অঙ্কুরিত — ভ্রূণমূল লম্বা হচ্ছে', { fs: 9.4, a: 'middle', c: C.mu });
      E('path', { d: 'M290 176V140', stroke: Rg.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, g); E('path', { d: 'M290 176V196', stroke: Rg.dk, 'stroke-width': 4, opacity: .5 }, g);
      leafE2(g, 290, 136); T(g, 300, 212, 'কাদায় গাঁথা চারা', { fs: 9.4, a: 'middle', c: C.mu });
    }
    T(g, 344, 22, 'লবণাক্ত কাদা — অক্সিজেন কম', { fs: 9, a: 'end', c: C.mu });
  },
  anim(g, C, ty, t) {
    const tide = t ? (1 - Math.cos(t * .5)) / 2 : 0, y = 176 - tide * 46;
    E('rect', { x: 0, y, width: 360, height: 176 - y + 2, fill: FK.alpha(BK.ramp(5).c, .32) }, g);
    if (tide > .02) E('path', { d: `M0 ${y}q15 -3 30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0t30 0`, stroke: BK.ramp(5).dk, 'stroke-width': 1, fill: 'none' }, g);
    T(g, 16, 22, t ? (tide > .5 ? 'জোয়ার' : 'ভাটা') : '', { fs: 10, w: 700, c: BK.ramp(5).ink });
    if (ty === 'vv' && t) { const k = (t * .35) % 1; const yy = 130 + k * 56; E('path', { d: `M218 ${yy}V${yy + 46}`, stroke: BK.ramp(10).dk, 'stroke-width': 4, 'stroke-linecap': 'round', opacity: k < .95 ? 1 : 0 }, g); }
  }
}));
function leafE2(g, x, y) { const R = BK.ramp(10); E('ellipse', { cx: x - 9, cy: y, rx: 10, ry: 4, fill: R.c, stroke: R.dk, transform: `rotate(-20 ${x - 9} ${y})` }, g); E('ellipse', { cx: x + 9, cy: y, rx: 10, ry: 4, fill: R.c, stroke: R.dk, transform: `rotate(20 ${x + 9} ${y})` }, g); }

/* ═════════ ৯. লবণ সামলানোর কৌশল ═════════ */
V.saltWays = Object.assign({}, B.seg({
  id: 'slt', t: 'লবণাক্ত পরিবেশে উদ্ভিদের শারীরবৃত্তীয় অভিযোজন', H: 250, def: 'phd',
  cap: 'লবণাক্ত মাটিতে পানি প্রচুর থাকলেও মাটির দ্রবণের ঘনত্ব বেশি বলে উদ্ভিদ সহজে পানি শোষণ করতে পারে না — একে শারীরবৃত্তীয় শুষ্কতা বলে। তাই হ্যালোফাইটের অনেক বৈশিষ্ট্য মরুজ উদ্ভিদের মতো। লবণ সামলাতে এরা তিন কৌশল নেয় — বাদ দেওয়া, বের করে দেওয়া ও জমিয়ে পাতলা করা।',
  types: {
    phd: ['শারীরবৃত্তীয় শুষ্কতা', 'কেন পানি থাকতেও "শুষ্কতা"', 'কোষরসের অভিস্রবণ চাপ মাটির দ্রবণের চেয়ে বেশি না হলে পানি কোষে ঢোকে না। হ্যালোফাইট কোষরসে লবণ ও জৈব দ্রব (প্রোলিন, গ্লাইসিন বেটেইন) জমিয়ে অভিস্রবণ চাপ অনেক বাড়িয়ে নেয়।'],
    exc: ['বাদ দেওয়া', 'মূলে লবণ ছেঁকে ফেলা', 'মূলের এন্ডোডার্মিসের ঝিল্লি অতিসূক্ষ্ম ছাঁকনির মতো লবণের বড় অংশ ভেতরে ঢুকতে দেয় না — গর্জন বা ঝানা (Rhizophora), কাঁকড়া (Bruguiera)।'],
    gld: ['বের করা', 'পাতার লবণগ্রন্থি', 'পাতার লবণগ্রন্থি দিয়ে অতিরিক্ত লবণ বের করে দেয় — পাতার ওপর সাদা লবণের দানা দেখা যায়; বাইন (Avicennia), খলসি (Aegiceras)।'],
    suc: ['জমিয়ে পাতলা করা', 'রসালো পাতায় লবণ পাতলা করা', 'রসালো পাতা বা কাণ্ডে প্রচুর পানি জমিয়ে লবণের ঘনত্ব কমিয়ে রাখে; অনেক সময় লবণ জমা পুরোনো পাতা ঝরিয়ে ফেলে — Suaeda, Salicornia, গেওয়া (Excoecaria)।']
  },
  art(g, C, ty) {
    const R9 = BK.ramp(9), R5 = BK.ramp(5), Rg = BK.ramp(10);
    const salt = (x, y, n, sp) => { for (let i = 0; i < n; i++) E('rect', { x: x + (rnd(i * 3 + x) - .5) * sp, y: y + (rnd(i * 7 + y) - .5) * sp * .6, width: 3, height: 3, fill: R9.dk, opacity: .8 }, g); };
    if (ty === 'phd') {
      [[90, 'সাধারণ উদ্ভিদ', 3, 4], [270, 'হ্যালোফাইট', 14, 10]].forEach(([x, s, nIn, ri], j) => {
        E('rect', { x: x - 70, y: 150, width: 140, height: 70, rx: 6, fill: FK.alpha(R5.c, .2), stroke: R5.dk }, g); salt(x, 186, 12, 120);
        E('circle', { cx: x, cy: 100, r: 34, fill: FK.alpha(Rg.c, .2), stroke: Rg.dk, 'stroke-width': 1.4 }, g); salt(x, 100, nIn, 44);
        T(g, x, 52, s, { fs: 11, a: 'middle', w: 700, c: BK.ramp(ri).ink });
        if (j) arrow(g, x, 150, x, 138, BK.ramp(10).dk, { w: 2.2 }); else { arrow(g, x, 136, x, 150, BK.ramp(4).dk, { w: 2.2 }); }
        T(g, x, 238, j ? 'কোষরস বেশি ঘন → পানি ঢোকে' : 'মাটি বেশি ঘন → পানি বেরিয়ে যায়', { fs: 9.2, a: 'middle', w: 650, c: BK.ramp(j ? 10 : 4).ink });
      });
      T(g, 180, 104, 'কোষ', { fs: 9, a: 'middle', c: C.mu });
      return;
    }
    E('rect', { x: 0, y: 176, width: 360, height: 80, fill: FK.alpha(BK.ramp(11).c, .45) }, g); salt(180, 214, 40, 340);
    E('path', { d: 'M180 176V70', stroke: '#5b4630', 'stroke-width': 6 }, g);
    for (let i = 0; i < 3; i++) { const y = 140 - i * 30; E('ellipse', { cx: 150, cy: y, rx: 26, ry: ty === 'suc' ? 13 : 8, fill: Rg.c, stroke: Rg.dk, transform: `rotate(-15 150 ${y})` }, g); E('ellipse', { cx: 210, cy: y - 8, rx: 26, ry: ty === 'suc' ? 13 : 8, fill: Rg.c, stroke: Rg.dk, transform: `rotate(15 210 ${y - 8})` }, g); }
    E('path', { d: 'M180 176V226M180 192l-40 34M180 196l36 32', stroke: '#5b4630', 'stroke-width': 2, fill: 'none' }, g);
    if (ty === 'exc') { E('path', { d: 'M120 230Q180 210 240 232', stroke: BK.ramp(3).dk, 'stroke-width': 2.4, 'stroke-dasharray': '4 3', fill: 'none' }, g); T(g, 270, 246, 'মূলে ছাঁকনি — লবণ আটকে যায়', { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(3).ink }); }
    if (ty === 'gld') { [[140, 132], [214, 124], [150, 102], [208, 94]].forEach(([x, y]) => salt(x, y - 6, 4, 14)); T(g, 290, 100, 'পাতায় সাদা লবণদানা', { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(9).ink }); }
    if (ty === 'suc') { T(g, 290, 100, 'রসালো পাতা — লবণ পাতলা', { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(10).ink }); E('ellipse', { cx: 150, cy: 80, rx: 22, ry: 10, fill: BK.ramp(7).c, stroke: BK.ramp(7).dk, transform: 'rotate(-15 150 80)', opacity: .8 }, g); T(g, 104, 66, 'পুরোনো পাতা ঝরে', { fs: 8.6, a: 'middle', c: C.mu }); }
  },
  anim(g, C, ty, t) {
    if (!t) return; const k = (t * .6) % 1;
    if (ty === 'gld') E('rect', { x: 212, y: 116 - k * 20, width: 3, height: 3, fill: BK.ramp(9).dk, opacity: 1 - k }, g);
    else if (ty === 'exc') { E('circle', { cx: 160 + k * 20, cy: 238 - k * 14, r: 2.2, fill: BK.ramp(5).dk }, g); E('rect', { x: 196, y: 238 - k * 8, width: 3, height: 3, fill: BK.ramp(9).dk, opacity: k < .6 ? 1 : 0 }, g); }
    else if (ty === 'phd') { E('circle', { cx: 270, cy: 150 - k * 14, r: 2.4, fill: BK.ramp(5).dk, opacity: 1 - k }, g); E('circle', { cx: 90, cy: 136 + k * 14, r: 2.4, fill: BK.ramp(5).dk, opacity: 1 - k }, g); }
    else E('circle', { cx: 180, cy: 170 - k * 60, r: 2.2, fill: BK.ramp(5).dk, opacity: 1 - k }, g);
  }
}));

/* ═════════ ১০. মাছের অভিস্রবণ নিয়ন্ত্রণ ═════════ */
V.fishOsmo = Object.assign({}, B.seg({
  id: 'osm', t: 'লবণাক্ত ও মিঠাপানিতে প্রাণীর অভিযোজন', H: 250, def: 'sea',
  cap: 'প্রাণীর দেহতরল ও চারপাশের পানির লবণের ঘনত্ব আলাদা হলে অভিস্রবণে পানি ঢোকে বা বেরিয়ে যায়। তাই সামুদ্রিক ও মিঠাপানির মাছ ঠিক বিপরীত কৌশলে দেহের লবণ-পানির ভারসাম্য রাখে (অভিস্রবণ নিয়ন্ত্রণ)। হাঙর রক্তে ইউরিয়া জমিয়ে প্রায় সমুদ্রের সমান ঘনত্বে থাকে।',
  types: {
    sea: ['সামুদ্রিক মাছ', 'লবণাক্ত পানির অস্থিময় মাছ', 'দেহতরল সমুদ্রের চেয়ে কম ঘন → অভিস্রবণে পানি বেরিয়ে যায়। তাই প্রচুর সমুদ্রের পানি পান করে, ফুলকার বিশেষ কোষ দিয়ে অতিরিক্ত লবণ বের করে দেয় এবং অল্প পরিমাণ ঘন মূত্র ত্যাগ করে।'],
    fresh: ['মিঠাপানির মাছ', 'মিঠাপানির মাছ', 'দেহতরল চারপাশের পানির চেয়ে বেশি ঘন → অভিস্রবণে পানি ঢোকে। তাই প্রায় পানি পান করে না, প্রচুর পাতলা মূত্র ত্যাগ করে এবং ফুলকা দিয়ে পানি থেকে লবণ শোষণ করে।'],
    oth: ['উপকূলের প্রাণী', 'লবণাক্ত উপকূলের অন্যান্য প্রাণী', 'মাডস্কিপার (Periophthalmus) — জোয়ার-ভাটার কাদায় পাখনায় ভর দিয়ে হাঁটে, ফুলকা-প্রকোষ্ঠে পানি ধরে রেখে বাতাসেও শ্বাস নেয়। লোনাপানির কুমিরের জিহ্বায় ও সামুদ্রিক পাখির নাকের কাছে লবণগ্রন্থি অতিরিক্ত লবণ বের করে। সুন্দরবনের কাঁকড়া গর্তে থেকে লবণ ও তাপের ওঠানামা এড়ায়।']
  },
  art(g, C, ty) {
    const sea = ty === 'sea', R5 = BK.ramp(5), R9 = BK.ramp(9), R2 = BK.ramp(2);
    if (ty === 'oth') {
      E('rect', { x: 0, y: 150, width: 360, height: 104, fill: FK.alpha(BK.ramp(11).c, .45) }, g); E('rect', { x: 220, y: 150, width: 140, height: 104, fill: FK.alpha(R5.c, .3) }, g);
      E('path', { d: 'M60 150Q70 128 100 130Q120 132 130 142L150 138L140 150Z', fill: '#8e8a6c', stroke: '#4e4a33', 'stroke-width': 1.2 }, g); E('circle', { cx: 102, cy: 128, r: 4, fill: '#222', stroke: '#fff', 'stroke-width': 1 }, g); E('path', { d: 'M84 150l-6 8M96 150l2 8', stroke: '#4e4a33', 'stroke-width': 2 }, g);
      T(g, 100, 112, 'মাডস্কিপার', { fs: 10.4, a: 'middle', w: 700, c: C.fg });
      E('ellipse', { cx: 280, cy: 138, rx: 20, ry: 11, fill: BK.ramp(4).c, stroke: BK.ramp(4).dk }, g); E('path', { d: 'M262 132l-16 -12M298 132l18 -16M266 146l-12 8M294 146l12 8', stroke: BK.ramp(4).dk, 'stroke-width': 2 }, g); E('ellipse', { cx: 318, cy: 112, rx: 8, ry: 5, fill: BK.ramp(4).c, stroke: BK.ramp(4).dk }, g);
      T(g, 280, 100, 'লাল কাঁকড়া', { fs: 10.4, a: 'middle', w: 700, c: C.fg });
      for (let i = 0; i < 4; i++) E('ellipse', { cx: 30 + i * 50, cy: 200 + (i % 2) * 14, rx: 6, ry: 9, fill: FK.alpha('#000', .25) }, g);
      T(g, 180, 238, 'গর্ত, বাতাসে শ্বাস, লবণগ্রন্থি', { fs: 9.6, a: 'middle', c: C.mu });
      return;
    }
    E('rect', { x: 0, y: 0, width: 360, height: 254, fill: FK.alpha(sea ? R9.c : R5.c, sea ? .16 : .14) }, g);
    for (let i = 0; i < (sea ? 40 : 6); i++) E('rect', { x: rnd(i * 3) * 350, y: rnd(i * 5 + 1) * 240, width: 3, height: 3, fill: R9.dk, opacity: .55 }, g);
    E('path', { d: 'M90 126Q140 80 220 92Q262 98 284 126Q262 154 220 160Q140 170 90 126Z', fill: FK.alpha(R2.c, .6), stroke: R2.dk, 'stroke-width': 1.5 }, g);
    E('path', { d: 'M92 126L62 102L70 126L62 150Z', fill: FK.alpha(R2.c, .6), stroke: R2.dk }, g); E('circle', { cx: 262, cy: 118, r: 3.5, fill: '#222' }, g);
    const W = BK.ramp(5).dk, S = BK.ramp(9).dk, Rd = BK.ramp(4).dk, Rg = BK.ramp(10).dk;
    if (sea) {
      arrow(g, 190, 116, 190, 60, W, { w: 2 }); T(g, 190, 52, 'অভিস্রবণে পানি বের হয়', { fs: 9.4, a: 'middle', c: C.fg });
      arrow(g, 320, 126, 288, 126, W, { w: 2.4 }); T(g, 324, 112, 'সমুদ্রের পানি পান', { fs: 9.4, a: 'end', c: C.fg });
      arrow(g, 240, 140, 262, 196, S, { w: 2.2 }); T(g, 262, 210, 'ফুলকা দিয়ে লবণ বের', { fs: 9.4, a: 'middle', c: C.fg });
      arrow(g, 120, 150, 110, 196, Rd, { w: 1.4 }); T(g, 110, 210, 'অল্প, ঘন মূত্র', { fs: 9.4, a: 'middle', c: C.fg });
      T(g, 180, 238, 'দেহ সমুদ্রের চেয়ে কম ঘন (হাইপোটনিক)', { fs: 9.8, a: 'middle', w: 650, c: R9.ink });
    } else {
      arrow(g, 190, 60, 190, 108, W, { w: 2 }); T(g, 190, 52, 'অভিস্রবণে পানি ঢোকে', { fs: 9.4, a: 'middle', c: C.fg });
      nope(g, 306, 126, 6, Rd); T(g, 324, 112, 'পানি পান করে না', { fs: 9.4, a: 'end', c: C.fg });
      arrow(g, 262, 196, 240, 144, Rg, { w: 2.2 }); T(g, 262, 210, 'ফুলকা দিয়ে লবণ শোষণ', { fs: 9.4, a: 'middle', c: C.fg });
      arrow(g, 120, 150, 110, 196, W, { w: 3 }); T(g, 110, 210, 'প্রচুর, পাতলা মূত্র', { fs: 9.4, a: 'middle', c: C.fg });
      T(g, 180, 238, 'দেহ পানির চেয়ে বেশি ঘন (হাইপারটনিক)', { fs: 9.8, a: 'middle', w: 650, c: R5.ink });
    }
  },
  anim(g, C, ty, t) { if (!t || ty === 'oth') return; const k = (t * .7) % 1, y = ty === 'sea' ? 110 - k * 50 : 60 + k * 48; E('circle', { cx: 196, cy: y, r: 2.6, fill: BK.ramp(5).c, stroke: BK.ramp(5).dk, 'stroke-width': .6 }, g); }
}));

/* ═════════ তুলনা ═════════ */
V.cmpHydroXero = cmp('জলজ উদ্ভিদ বনাম মরুজ উদ্ভিদ', 'পানির প্রাচুর্য ও অভাব — দুই বিপরীত পরিবেশে দুই বিপরীত অভিযোজন।', 'জলজ (হাইড্রোফাইট)', 'মরুজ (জেরোফাইট)', [
  ['মূল', 'দুর্বল, ছোট বা অনুপস্থিত; মূলত্রের বদলে মূলপকেট', 'গভীর, বিস্তৃত ও সুগঠিত'],
  ['কাণ্ড', 'নরম, নমনীয়, স্পঞ্জের মতো', 'শক্ত; অনেক সময় রসালো বা পর্ণকাণ্ডে রূপান্তরিত'],
  ['পাতা', 'বড়, পাতলা বা সরু খণ্ডিত; ভিন্নপত্রতা দেখা যায়', 'ছোট, পুরু, শল্ক বা কাঁটায় রূপান্তরিত'],
  ['কিউটিকল', 'নেই বা খুব পাতলা', 'খুব পুরু ও মোমযুক্ত'],
  ['পত্ররন্ধ্র', 'নিমজ্জিত পাতায় নেই; ভাসমান পাতার ওপরের তলে', 'কম, নিচের তলে গর্তে নিমজ্জিত'],
  ['বায়ুকুঠুরি', 'প্রচুর (অ্যারেনকাইমা)', 'নেই'],
  ['যান্ত্রিক টিস্যু ও জাইলেম', 'খুব কম', 'সুগঠিত'],
  ['উদাহরণ', 'কচুরিপানা, শাপলা, হাইড্রিলা, পদ্ম', 'ফণিমনসা, ঘৃতকুমারী, করবী, আকন্দ']
]);
V.cmpXeroMeso = cmp('মরুজ উদ্ভিদ বনাম মেসোফাইট', 'পরিমিত পানির পরিবেশ মেসোফাইটকে "মাঝামাঝি" গঠন দিয়েছে।', 'মরুজ (জেরোফাইট)', 'মেসোফাইট', [
  ['আবাস', 'শুষ্ক, পানির অভাবযুক্ত মাটি', 'পরিমিত পানি ও বাতাসযুক্ত উর্বর মাটি'],
  ['মূল', 'অত্যন্ত গভীর ও বিস্তৃত', 'সুগঠিত, মাঝারি গভীর; মূলত্র প্রচুর'],
  ['পাতা', 'ছোট, পুরু, কাঁটা বা শল্কে রূপান্তরিত', 'চওড়া, চ্যাপ্টা, সবুজ; সাধারণত পৃষ্ঠ-অঙ্কীয় (ডরসিভেন্ট্রাল)'],
  ['কিউটিকল', 'খুব পুরু', 'মাঝারি'],
  ['পত্ররন্ধ্র', 'কম ও নিমজ্জিত', 'নিচের তলে বেশি, স্বাভাবিক অবস্থানে'],
  ['প্রস্বেদন', 'খুব কম', 'স্বাভাবিক; দিনে রন্ধ্র খোলা'],
  ['উদাহরণ', 'ফণিমনসা, করবী', 'আম, জাম, কাঁঠাল, সরিষা, শিম']
]);
V.cmpXeroHalo = cmp('মরুজ উদ্ভিদ বনাম লোনামাটির উদ্ভিদ', 'দুটিই পানি সংকটে — একটির কারণ পানির অভাব, অন্যটির কারণ লবণ।', 'মরুজ (জেরোফাইট)', 'লোনামাটির (হ্যালোফাইট)', [
  ['পানি সংকটের ধরন', 'ভৌত শুষ্কতা — মাটিতে পানিই কম', 'শারীরবৃত্তীয় শুষ্কতা — পানি আছে কিন্তু লবণের কারণে শোষণ কঠিন'],
  ['মাটি', 'শুষ্ক, বালুময় বা পাথুরে; বায়ুযুক্ত', 'ভেজা, কাদাময়, লবণাক্ত ও অক্সিজেনহীন'],
  ['বিশেষ মূল', 'গভীর মূল', 'শ্বাসমূল ও ঠেসমূল'],
  ['বংশবিস্তার', 'সাধারণ বীজ; ক্ষণজীবীরা বীজে খরা কাটায়', 'জরায়ুজ অঙ্কুরোদগম'],
  ['লবণ ব্যবস্থাপনা', 'প্রয়োজন হয় না', 'লবণগ্রন্থি, মূলে ছাঁকনি, রসালোতা'],
  ['মিল', 'পুরু কিউটিকল, নিমজ্জিত রন্ধ্র, রসালোতা', 'পুরু কিউটিকল, নিমজ্জিত রন্ধ্র, রসালোতা'],
  ['উদাহরণ', 'ফণিমনসা, করবী, আকন্দ', 'সুন্দরী, গরান, গেওয়া, কেওড়া, বাইন']
]);
V.cmpMarineFresh = cmp('সামুদ্রিক মাছ বনাম মিঠাপানির মাছ', 'অভিস্রবণ নিয়ন্ত্রণের দুই বিপরীত কৌশল।', 'সামুদ্রিক অস্থিময় মাছ', 'মিঠাপানির মাছ', [
  ['দেহতরল বনাম পরিবেশ', 'পরিবেশের চেয়ে কম ঘন', 'পরিবেশের চেয়ে বেশি ঘন'],
  ['অভিস্রবণে পানি', 'দেহ থেকে বেরিয়ে যায়', 'দেহে ঢোকে'],
  ['পানি পান', 'প্রচুর সমুদ্রের পানি পান করে', 'প্রায় পান করে না'],
  ['লবণ', 'ফুলকা দিয়ে বের করে দেয়', 'ফুলকা দিয়ে শোষণ করে'],
  ['মূত্র', 'অল্প ও ঘন', 'প্রচুর ও পাতলা'],
  ['উদাহরণ', 'ইলিশ সমুদ্রে থাকাকালীন, রূপচাঁদা, লাক্ষা', 'রুই, কাতলা, শিং, মাগুর']
]);
})();
