/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §১২.৪ বাংলাদেশের বিলুপ্তপ্রায় উদ্ভিদ ও প্রাণী
   redListBD, endPlants, talipamLife, endAnimals, vultureCrisis, cmpGharialMugger
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B12, XB = window.B12X;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot, chip = B.chip, lab = B.lab;
const arrow = XB.arrow, okm = XB.okm, nope = XB.nope, cmp = XB.cmp, org = XB.org;
const CAT = { EX: 9, EW: 3, RE: 3, CR: 4, EN: 2, VU: 6, NT: 7, LC: 10, DD: 9 };
const catR = c => BK.ramp(CAT[c] != null ? CAT[c] : 9);

/* ═════════ ১. বাংলাদেশের লাল তালিকা — সংখ্যায় ═════════ */
const RL = {
  an: ['প্রাণী (2015)', 'IUCN বাংলাদেশ ও বন বিভাগের "Red List of Bangladesh" (2015) — স্তন্যপায়ী, পাখি, সরীসৃপ, উভচর, মিঠাপানির মাছ, ক্রাস্টেশিয়ান ও প্রজাপতি মূল্যায়ন করা হয়। হুমকিগ্রস্ত প্রজাতি 390টি; 31টি প্রজাতি বাংলাদেশ থেকে আঞ্চলিকভাবে বিলুপ্ত — এর মধ্যে 11টি স্তন্যপায়ী (একশৃঙ্গ গণ্ডার, নেকড়ে, নীলগাই প্রভৃতি), 19টি পাখি (গোলাপিশির হাঁস, বেঙ্গল ফ্লোরিকান…) ও 1টি সরীসৃপ (মিঠাপানির কুমির)।', [['RE', 'আঞ্চলিকভাবে বিলুপ্ত', 31], ['CR', 'মহাবিপন্ন', 56], ['EN', 'বিপন্ন', 181], ['VU', 'সংকটাপন্ন', 153]]],
  pl: ['উদ্ভিদ (2024)', 'বাংলাদেশের প্রথম উদ্ভিদ লাল তালিকা (নভেম্বর 2024) — 1,000টি উদ্ভিদ প্রজাতি মূল্যায়ন; হুমকিগ্রস্ত 395টি। বন্য অবস্থায় বিলুপ্ত 1টি (তালিপাম) ও আঞ্চলিকভাবে বিলুপ্ত 7টি। পাঁচটি মহাবিপন্ন উদ্ভিদ — দুই প্রজাতির অর্কিড (Bulbophyllum), খুদে খেজুর (Phoenix acaulis), চালমুগরা (Hydnocarpus kurzii) ও বাঁশপাতা (Podocarpus neriifolius)।', [['RE', 'আঞ্চলিকভাবে বিলুপ্ত', 7], ['EW', 'বন্য অবস্থায় বিলুপ্ত', 1], ['CR', 'মহাবিপন্ন', 5], ['EN', 'বিপন্ন', 127], ['VU', 'সংকটাপন্ন', 263]]]
};
V.redListBD = Object.assign({}, B.seg({
  id: 'rlb', t: 'বাংলাদেশের লাল তালিকা', H: 250, def: 'an', sel: null,
  cap: 'লাল তালিকা (Red List) — কোন প্রজাতি বিলুপ্তির কতটা ঝুঁকিতে আছে তার বৈজ্ঞানিক মূল্যায়ন ও তালিকা; IUCN এর নির্ধারিত মানদণ্ডে তৈরি হয়। মহাবিপন্ন, বিপন্ন ও সংকটাপন্ন — এ তিন বিভাগ মিলে "হুমকিগ্রস্ত" (threatened)। বাংলাদেশে প্রথম লাল তালিকা প্রকাশিত হয় 2000 সালে; প্রাণীর হালনাগাদ তালিকা 2015 সালে এবং উদ্ভিদের প্রথম লাল তালিকা 2024 সালে।',
  types: { an: [RL.an[0], 'প্রাণী — Red List of Bangladesh 2015', RL.an[1]], pl: [RL.pl[0], 'উদ্ভিদ — Plant Red List of Bangladesh 2024', RL.pl[1]] },
  art(g, C, ty, ctx) {
    const D = RL[ty][2], mx = Math.max(...D.map(d => d[2])), gap = ty === 'an' ? 46 : 38;
    D.forEach(([c, s, v], i) => {
      const y = 26 + i * gap, R = catR(c), on = ctx.sel === i, w = Math.max(4, v / mx * 190);
      E('rect', { x: 12, y, width: 34, height: 26, rx: 6, fill: R.c, stroke: R.dk }, g); T(g, 29, y + 17, c, { fs: 10.4, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
      T(g, 54, y + 17, s, { fs: 10, w: on ? 700 : 560, c: C.fg });
      E('rect', { x: 150, y: y + 3, width: w, height: 20, rx: 5, fill: FK.alpha(R.c, on ? .75 : .45), stroke: R.dk }, g);
      T(g, 156 + w, y + 18, String(v), { fs: 11, w: 700, c: R.ink });
    });
    const thr = D.filter(d => ['CR', 'EN', 'VU'].indexOf(d[0]) >= 0).reduce((a, d) => a + d[2], 0);
    E('rect', { x: 12, y: 214, width: 336, height: 28, rx: 8, fill: FK.alpha(BK.ramp(4).c, .1), stroke: BK.ramp(4).dk }, g);
    T(g, 180, 233, `হুমকিগ্রস্ত (CR + EN + VU) = ${thr}টি প্রজাতি`, { fs: 10.6, a: 'middle', w: 700, c: BK.ramp(4).ink });
    ctx.H = D.map((_, i) => [200, 26 + i * gap + 13, i]);
  },
  anim(g, C, ty, t) { if (!t) return; const D = RL[ty][2], i = Math.floor(t * .6) % D.length, gap = ty === 'an' ? 46 : 38, k = (t * .6) % 1; E('rect', { x: 10, y: 24 + i * gap, width: 340, height: 30, rx: 7, fill: 'none', stroke: catR(D[i][0]).c, 'stroke-width': 1.6, opacity: 1 - k }, g); },
  tap(x, y, ty, ctx) {
    const h = hot(ctx.H || [], x, y, 150); if (!h) return null; ctx.sel = h[2]; const [c, s, v] = RL[ty][2][h[2]];
    const M = { RE: 'দেশে প্রাকৃতিক অবস্থায় আর একটিও নেই, তবে পৃথিবীর অন্য কোথাও টিকে আছে।', EW: 'প্রকৃতিতে আর নেই; কেবল চাষ বা সংরক্ষণে টিকে আছে।', CR: 'অতি নিকট ভবিষ্যতে প্রকৃতি থেকে বিলুপ্তির চরম ঝুঁকিতে।', EN: 'নিকট ভবিষ্যতে বিলুপ্তির খুব উঁচু ঝুঁকিতে।', VU: 'মাঝারি মেয়াদে বিলুপ্তির উঁচু ঝুঁকিতে।' };
    return `<b>${s} (${c}): ${v}টি</b><div class="small">${M[c]}</div>`;
  }
}));

/* ═════════ ২. বিলুপ্তপ্রায় উদ্ভিদ ═════════ */
const PL = [
  ['তালিপাম', 'Corypha taliera', 'Arecaceae (তাল পরিবার)', 'EW', 'বিশাল পাখার মতো পাতার এক কাণ্ডের পাম, দেখতে তালগাছের মতো। জীবনে একবারই — বহু দশক পর — বিশাল পুষ্পমঞ্জরি তৈরি করে, ফুল-ফল দিয়ে মারা যায় (মনোকার্পিক)। বন্য অবস্থায় বিলুপ্ত; বাংলাদেশে শেষ পরিচিত গাছটি ছিল ঢাকা বিশ্ববিদ্যালয় চত্বরে, যা 2008 সালে ফুল দিয়ে পরে মারা যায়। তার বীজ থেকে চারা করে দেশের নানা স্থানে লাগানো হয়েছে।', 2],
  ['মালাক্কা ঝাঁঝি', 'Aldrovanda vesiculosa', 'Droseraceae', 'RE*', 'মূলহীন, পানিতে নিমজ্জিত ভাসমান পতঙ্গভুক উদ্ভিদ; সরু কাণ্ডের চারপাশে চাকার পাখির মতো আবর্তে সাজানো পাতা ফাঁদের মতো বন্ধ হয়ে ক্ষুদ্র জলজ প্রাণী ধরে (ইংরেজিতে waterwheel plant)। রাজশাহী ও চলনবিল এলাকায় পাওয়া গিয়েছিল; বহু বছর সংগৃহীত হয়নি, দেশ থেকে বিলুপ্ত বলে ধারণা করা হয়।', 5],
  ['ক্ষুদে বড়লা', 'Knema bengalensis', 'Myristicaceae (জায়ফল পরিবার)', 'VU*', 'বাংলাদেশের এন্ডেমিক মাঝারি আকারের বৃক্ষ, বাকলে লালচে রস। 1957 সালে কক্সবাজারে প্রথম পাওয়া যায়, পরে 1999 সালে সেখানে আরেকটি গাছের খোঁজ মেলে। আবাসস্থল ধ্বংসই সংকটের প্রধান কারণ।', 10],
  ['কোরুদ', 'Licuala peltata', 'Arecaceae (তাল পরিবার)', 'VU*', 'প্রায় 2–3 মিটার উঁচু ঝোপালো চিরসবুজ পাম; গোলাকার পাখার মতো পাতা। সিলেট, চট্টগ্রাম ও পার্বত্য চট্টগ্রামের ছায়াঘেরা আর্দ্র মিশ্র বনে জন্মায়। পাতা দিয়ে ছাতা, ঝুড়ি ও ঘরের চালা তৈরি হয় — অতিরিক্ত আহরণ ও বন উজাড়ে বিরল।', 6],
  ['রোটালা', 'Rotala simpliciuscula', 'Lythraceae', 'VU*', 'ক্ষুদ্র পাতার সরু উভচর বর্ষজীবী বীরুৎ; ধানক্ষেতের ভেজা আইলে জন্মায়। বাংলাদেশের এন্ডেমিক — উনিশ শতকে চট্টগ্রাম অঞ্চলে প্রথম নথিভুক্ত, তারপর আর খুব কম দেখা গেছে। আবাস নষ্ট হয়ে বিলুপ্তির ঝুঁকিতে।', 3]
];
V.endPlants = Object.assign({}, B.seg({
  id: 'epl', t: 'বাংলাদেশের কয়েকটি বিলুপ্তপ্রায় উদ্ভিদ', H: 256, def: 'all', sel: 0,
  cap: 'বাংলাদেশের বিলুপ্তপ্রায় উদ্ভিদের পাঁচটি উদাহরণ। অবস্থার চিহ্ন: EW — বন্য অবস্থায় বিলুপ্ত (IUCN); তারকাচিহ্নিত মানগুলো বাংলাদেশের লাল তথ্য বই (Red Data Book, 2001) ও পরবর্তী জাতীয় মূল্যায়ন থেকে — নতুন তালিকায় কিছু প্রজাতির অবস্থান বদলাতে পারে। বইয়ে "মন্ত্রিকা ঝাঁঝি" নামে উল্লেখিত উদ্ভিদটি সাধারণত মালাক্কা বা মল্লিকা ঝাঁঝি নামে পরিচিত। কার্ডে চাপ দাও।',
  types: { all: ['উদ্ভিদ', 'পাঁচটি বিলুপ্তপ্রায় উদ্ভিদ', 'কার্ডে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    PL.forEach(([s, sci, fam, st, , ri], i) => {
      const y = 10 + i * 40, R = BK.ramp(ri), on = ctx.sel === i, Rc = catR(st.replace('*', ''));
      E('rect', { x: 10, y, width: 136, height: 34, rx: 8, fill: FK.alpha(R.c, on ? .3 : .1), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g);
      T(g, 20, y + 15, s, { fs: 10.6, w: 700, c: on ? R.ink : C.fg }); T(g, 20, y + 28, sci, { fs: 8, c: C.mu, st: 'font-style:italic' });
      E('rect', { x: 112, y: y + 9, width: 28, height: 16, rx: 5, fill: Rc.c }, g); T(g, 126, y + 21, st, { fs: 8.4, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' });
    });
    /* নির্বাচিত উদ্ভিদের ছবি */
    const i = ctx.sel != null ? ctx.sel : 0, R = BK.ramp(PL[i][5]), Rg = BK.ramp(10), Rw = { c: '#8a6a4a', dk: '#4f3a26' };
    E('rect', { x: 156, y: 10, width: 194, height: 194, rx: 12, fill: FK.alpha(R.c, .08), stroke: R.dk }, g);
    const cx = 253;
    if (i === 0) { E('path', { d: `M${cx} 196V64`, stroke: Rw.dk, 'stroke-width': 7 }, g); for (let k = 0; k < 9; k++) { const a = -PI / 2 + (k - 4) * .38; E('path', { d: `M${cx} 64L${cx + Math.cos(a) * 54} ${64 + Math.sin(a) * 40}`, stroke: Rg.dk, 'stroke-width': 1.4 }, g); E('path', { d: `M${cx + Math.cos(a) * 30} ${64 + Math.sin(a) * 22}l${Math.cos(a - .3) * 26} ${Math.sin(a - .3) * 20}l${Math.cos(a + .3) * -2} 0z`, fill: Rg.c, stroke: Rg.dk, 'stroke-width': .6 }, g); } E('path', { d: `M${cx} 40V14M${cx - 14} 22l14 8l14 -8`, stroke: BK.ramp(7).dk, 'stroke-width': 2, fill: 'none' }, g); T(g, cx + 26, 18, 'বিশাল পুষ্পমঞ্জরি', { fs: 8, c: C.mu }); }
    else if (i === 1) { E('rect', { x: 160, y: 14, width: 186, height: 186, rx: 10, fill: FK.alpha(BK.ramp(5).c, .18) }, g); E('path', { d: `M180 108H330`, stroke: Rg.dk, 'stroke-width': 1.6 }, g); for (let k = 0; k < 7; k++) { const x = 190 + k * 20; for (let p = 0; p < 8; p++) { const a = p / 8 * PI * 2; E('path', { d: `M${x} 108l${Math.cos(a) * 9} ${Math.sin(a) * 9}`, stroke: Rg.dk, 'stroke-width': 1 }, g); E('ellipse', { cx: x + Math.cos(a) * 11, cy: 108 + Math.sin(a) * 11, rx: 2.6, ry: 1.8, fill: Rg.c, stroke: Rg.dk, 'stroke-width': .4, transform: `rotate(${a * 57.3} ${x + Math.cos(a) * 11} ${108 + Math.sin(a) * 11})` }, g); } } T(g, cx, 150, 'চাকার পাখির মতো আবর্তে ফাঁদ-পাতা', { fs: 8.8, a: 'middle', c: C.mu }); }
    else if (i === 2) { E('path', { d: `M${cx} 196V90`, stroke: '#7a4a3a', 'stroke-width': 8 }, g); E('path', { d: `M${cx - 2} 150l-6 8M${cx + 2} 130l5 6`, stroke: BK.ramp(4).c, 'stroke-width': 2 }, g); B.blob(g, cx, 70, 52, { n: 9, seed: 3, j: .2, fill: FK.alpha(Rg.c, .8), stroke: Rg.dk }); T(g, cx, 186, 'লালচে রসযুক্ত বাকল', { fs: 8.8, a: 'middle', c: C.mu }); }
    else if (i === 3) { for (let s = 0; s < 4; s++) { const x = cx - 36 + s * 24; E('path', { d: `M${x} 196V${110 - s * 6}`, stroke: Rw.dk, 'stroke-width': 2 }, g); E('circle', { cx: x, cy: 104 - s * 6, r: 22, fill: FK.alpha(Rg.c, .7), stroke: Rg.dk }, g); for (let k = 0; k < 10; k++) { const a = k / 10 * PI * 2; E('path', { d: `M${x} ${104 - s * 6}l${Math.cos(a) * 22} ${Math.sin(a) * 22}`, stroke: Rg.dk, 'stroke-width': .5 }, g); } } T(g, cx, 186, 'গোল পাখার মতো পাতার ঝোপালো পাম', { fs: 8.8, a: 'middle', c: C.mu }); }
    else { E('rect', { x: 160, y: 150, width: 186, height: 50, fill: FK.alpha(BK.ramp(11).c, .4) }, g); for (let s = 0; s < 6; s++) { const x = 190 + s * 26; E('path', { d: `M${x} 152q4 -40 -2 -80`, stroke: BK.ramp(4).dk, 'stroke-width': 1.2, fill: 'none' }, g); for (let k = 0; k < 8; k++) E('ellipse', { cx: x + 2 + (k % 2 ? 4 : -4), cy: 144 - k * 9, rx: 3.2, ry: 1.6, fill: Rg.c }, g); } T(g, cx, 48, 'ধানক্ষেতের ভেজা আইলের ক্ষুদ্র বীরুৎ', { fs: 8.8, a: 'middle', c: C.mu }); }
    T(g, cx, 222, PL[i][0], { fs: 12, a: 'middle', w: 700, c: R.ink }); T(g, cx, 238, PL[i][2], { fs: 8.6, a: 'middle', c: C.mu });
    ctx.H = PL.map((_, k) => [78, 27 + k * 40, k]);
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const k = (t * .6) % 1; E('rect', { x: 156, y: 10, width: 194, height: 194, rx: 12, fill: 'none', stroke: BK.ramp(PL[ctx.sel || 0][5]).c, 'stroke-width': 1 + k * 2, opacity: 1 - k }, g); },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 80); if (!h) return null; ctx.sel = h[2]; const p = PL[h[2]]; return `<b>${p[0]}</b> (<i>${p[1]}</i>) — ${p[2]}।<div class="small">${p[4]}</div>`; }
}));

/* ═════════ ৩. তালিপামের জীবনচক্র ═════════ */
const TP = [[0, 'বীজ থেকে চারা', 'পাখার মতো পাতা বাড়তে থাকে; কাণ্ড ধীরে ধীরে লম্বা হয়।'], [.55, 'দীর্ঘ অঙ্গজ বৃদ্ধি', 'কয়েক দশক ধরে কেবল পাতা ও কাণ্ড বাড়ে — একবারও ফুল হয় না।'], [.82, 'একবারই ফুল', 'কাণ্ডের মাথায় বিশাল পুষ্পমঞ্জরি — লক্ষাধিক ক্ষুদ্র ফুল; সঞ্চিত সব খাদ্য এতে খরচ হয়।'], [.92, 'ফল ও বীজ', 'অসংখ্য গোল ফল পাকে।'], [1, 'গাছের মৃত্যু', 'ফল দেওয়ার পর গাছটি শুকিয়ে মারা যায় — মনোকার্পিক (একবার ফলদায়ী) উদ্ভিদ।']];
V.talipamLife = Object.assign({}, B.seg({
  id: 'tpl', t: 'তালিপাম — জীবনে একবার ফুল', H: 250, def: 'l',
  cap: 'তালিপাম (Corypha taliera) একটি মনোকার্পিক উদ্ভিদ — জীবনে একবারই ফুল ও ফল দেয়, তারপর মারা যায়। বন্য অবস্থায় বিলুপ্ত (IUCN)। ঢাকা বিশ্ববিদ্যালয়ের গাছটি 2001 সালে শনাক্ত হয় ও 2008 সালে ফুল দেয়; সেই বীজ থেকে কয়েকশ চারা তৈরি করে দেশের বিভিন্ন স্থানে লাগানো হয়েছে — এক্স-সিটু সংরক্ষণের একটি সফল উদাহরণ। জীবনকাল স্লাইডারে সরাও।',
  sl: [{ k: 'u', l: 'জীবনকাল', min: 0, max: 100, step: 2, val: 60, unit: '%' }],
  types: { l: ['জীবনচক্র', 'মনোকার্পিক জীবনচক্র', 'বেশিরভাগ বহুবর্ষজীবী গাছ প্রতি বছর ফুল দেয় (পলিকার্পিক); তালিপাম, কিছু বাঁশ ও আগাভে ব্যতিক্রম।'] },
  art(g, C, ty, ctx) {
    const u = (+ctx.v.u) / 100, st = TP.reduce((a, s, i) => (u >= s[0] ? i : a), 0), cx = 110, Rg = BK.ramp(10), Rw = { dk: '#4f3a26' };
    E('rect', { x: 0, y: 200, width: 220, height: 10, fill: FK.alpha(BK.ramp(11).c, .5) }, g);
    const h = 20 + Math.min(u, .82) / .82 * 140, dead = st === 4, top = 200 - h;
    E('path', { d: `M${cx} 200V${top}`, stroke: dead ? '#8a7a66' : Rw.dk, 'stroke-width': 3 + Math.min(u, .82) * 8 }, g);
    const nl = dead ? 3 : 9, ls = 16 + Math.min(u, .82) * 34;
    for (let k = 0; k < nl; k++) { const a = -PI / 2 + (k - (nl - 1) / 2) * .36; E('path', { d: `M${cx} ${top}L${cx + Math.cos(a) * ls} ${top + Math.sin(a) * ls * .8 + (dead ? 20 : 0)}`, stroke: dead ? '#a89a80' : Rg.dk, 'stroke-width': 1.6 }, g); E('circle', { cx: cx + Math.cos(a) * ls, cy: top + Math.sin(a) * ls * .8 + (dead ? 20 : 0), r: 5, fill: dead ? '#c9b99a' : Rg.c }, g); }
    if (st === 2 || st === 3) { E('path', { d: `M${cx} ${top}V${top - 40}`, stroke: BK.ramp(7).dk, 'stroke-width': 2 }, g); for (let k = 0; k < 24; k++) { const yy = top - 4 - k * 1.6, dx = (k % 2 ? 1 : -1) * (6 + (24 - k) * .5); E('path', { d: `M${cx} ${yy}l${dx} -4`, stroke: BK.ramp(7).dk, 'stroke-width': .8 }, g); E('circle', { cx: cx + dx, cy: yy - 4, r: st === 3 ? 2.4 : 1.6, fill: st === 3 ? BK.ramp(11).c : BK.ramp(7).c }, g); } }
    TP.forEach(([p, s], i) => { const y = 26 + i * 36, on = i === st, R = BK.ramp([10, 10, 7, 11, 9][i]); E('rect', { x: 226, y, width: 126, height: 30, rx: 8, fill: FK.alpha(R.c, on ? .35 : .08), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); T(g, 236, y + 19, bn(i + 1) + '. ' + s, { fs: 9.6, w: on ? 700 : 500, c: on ? R.ink : C.fg }); });
    T(g, 110, 230, TP[st][2], { fs: 8.8, a: 'middle', c: C.fg });
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const u = +ctx.v.u / 100; if (u < .82 || u >= 1) return; const k = (t * .7) % 1; for (let i = 0; i < 3; i++) E('circle', { cx: 110 + (i - 1) * 16 + Math.sin(t * 3 + i) * 3, cy: 40 + k * 30, r: 1.6, fill: BK.ramp(7).c, opacity: 1 - k }, g); }
}));

/* ═════════ ৪. বিলুপ্তপ্রায় প্রাণী ═════════ */
const AN = [
  ['রাজশকুন', 'Sarcogyps calvus', 'CR', 'CR', 'লাল মাথা ও গলার বড় শকুন; মৃত প্রাণীর দেহ খেয়ে পরিবেশ পরিষ্কার রাখে। গবাদিপশুর চিকিৎসায় ব্যবহৃত ডাইক্লোফেনাক ওষুধযুক্ত মৃতদেহ খেয়ে বৃক্ক বিকল হয়ে মারা যায় — দক্ষিণ এশিয়ায় শকুনের সংখ্যা ব্যাপকভাবে কমেছে।', 'hawk', 4],
  ['ঘড়িয়াল', 'Gavialis gangeticus', 'CR', 'CR', 'লম্বা, খুব সরু চোয়াল ও ধারালো দাঁতের মাছখেকো কুমির; পুরুষের নাকের ডগায় মাটির ঘড়ার মতো ফোলা অংশ ("ঘড়া") থেকে নাম। পদ্মা-যমুনার অববাহিকায় দেখা যায়; বালুচর নষ্ট হওয়া, জালে আটকে মৃত্যু ও নদীর প্রবাহ কমায় সংকটে।', 'snake', 10],
  ['মিঠাপানির কুমির', 'Crocodylus palustris', 'VU', 'RE', 'চওড়া চোয়ালের মাগার কুমির — নদী, বিল ও পুকুরে বাস করত। বাংলাদেশে বন্য অবস্থায় বিলুপ্ত (আঞ্চলিকভাবে বিলুপ্ত, 2015); বাগেরহাটের খানজাহান আলীর মাজারের দিঘিতে রাখা কয়েকটি কুমির এ প্রজাতির। আবাস ধ্বংস ও শিকার প্রধান কারণ।', 'snake', 11],
  ['নীলগাই', 'Boselaphus tragocamelus', 'LC', 'RE', 'এশিয়ার বৃহত্তম অ্যান্টিলোপ (হরিণ-সদৃশ গো-পরিবারের প্রাণী); পুরুষ নীলচে-ধূসর। একসময় উত্তর-পশ্চিম বাংলাদেশে ছিল, এখন দেশে বিলুপ্ত — মাঝেমধ্যে সীমান্ত পেরিয়ে ভারত থেকে আসে। বিশ্বজুড়ে অবশ্য এটি হুমকিগ্রস্ত নয়।', 'deer', 5],
  ['শুশুক', 'Platanista gangetica', 'EN', 'EN', 'গাঙ্গেয় নদী-ডলফিন; প্রায় অন্ধ, শব্দের প্রতিধ্বনিতে (ইকোলোকেশন) খাদ্য খোঁজে ও পথ চেনে। শ্বাস নিতে কিছুক্ষণ পরপর পানির ওপরে ওঠে। জালে আটকে মৃত্যু, নদীর দূষণ ও বাঁধে আবাস টুকরো হওয়ায় বিপন্ন।', 'bigfish', 9]
];
V.endAnimals = Object.assign({}, B.seg({
  id: 'ean', t: 'বাংলাদেশের কয়েকটি বিলুপ্তপ্রায় প্রাণী', H: 252, def: 'all', sel: 0,
  cap: 'বাংলাদেশের বিলুপ্তপ্রায় প্রাণীর পাঁচটি উদাহরণ। প্রতিটির দুটি অবস্থা দেখানো হয়েছে — "বিশ্ব" মানে IUCN এর বৈশ্বিক লাল তালিকা, "দেশ" মানে Red List of Bangladesh (2015)। একই প্রজাতি বিশ্বে নিরাপদ হলেও কোনো দেশে বিলুপ্ত হতে পারে — যেমন নীলগাই। কার্ডে চাপ দাও।',
  types: { all: ['প্রাণী', 'পাঁচটি বিলুপ্তপ্রায় প্রাণী', 'কার্ডে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    AN.forEach(([s, sci, gl, bd, , kind, ri], i) => {
      const y = 10 + i * 46, R = BK.ramp(ri), on = ctx.sel === i;
      E('rect', { x: 10, y, width: 340, height: 40, rx: 9, fill: FK.alpha(R.c, on ? .26 : .08), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g);
      org(g, kind, 36, y + 30, kind === 'deer' ? .8 : .95);
      T(g, 66, y + 18, s, { fs: 11, w: 700, c: on ? R.ink : C.fg }); T(g, 66, y + 32, sci, { fs: 8.4, c: C.mu, st: 'font-style:italic' });
      [['বিশ্ব', gl, 236], ['দেশ', bd, 296]].forEach(([lb, c, x]) => { const Rc = catR(c); T(g, x - 4, y + 24, lb, { fs: 8.4, a: 'end', c: C.mu }); E('rect', { x, y: y + 11, width: 40, height: 18, rx: 5, fill: Rc.c }, g); T(g, x + 20, y + 24, c, { fs: 9.6, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' }); });
    });
    ctx.H = AN.map((_, i) => [180, 30 + i * 46, i]);
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const i = ctx.sel != null ? ctx.sel : 0, k = (t * .6) % 1; E('rect', { x: 10, y: 10 + i * 46, width: 340, height: 40, rx: 9, fill: 'none', stroke: BK.ramp(AN[i][6]).c, 'stroke-width': 1 + k * 2, opacity: 1 - k }, g); },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 180); if (!h) return null; ctx.sel = h[2]; const a = AN[h[2]]; return `<b>${a[0]}</b> (<i>${a[1]}</i>) — বিশ্ব: ${a[2]}, বাংলাদেশ: ${a[3]}।<div class="small">${a[4]}</div>`; }
}));

/* ═════════ ৫. শকুন সংকট — একটি কারণ-শৃঙ্খল ═════════ */
V.vultureCrisis = Object.assign({ t: 'শকুন কেন হারিয়ে যাচ্ছে', k: ['anim', 'steps'], cap: 'নব্বইয়ের দশক থেকে দক্ষিণ এশিয়ায় জিপস জাতের শকুনের সংখ্যা 95 শতাংশের বেশি কমে গেছে। প্রধান কারণ খুঁজে পাওয়া যায় 2004 সালে — গবাদিপশুর ব্যথানাশক ডাইক্লোফেনাক। বিলুপ্তির কারণ যে কখনো কখনো অপ্রত্যাশিত পথে খাদ্যশৃঙ্খল ধরে আসে, এটি তার প্রামাণিক উদাহরণ।' }, BK.steps({
  W: 360, H: 220, label: 'কারণ ও প্রতিকার', dur: 3,
  stages: [
    { t: 'অসুস্থ গরুকে ওষুধ', en: 'Diclofenac', d: 'গবাদিপশুর ব্যথা ও জ্বরে সস্তা ওষুধ ডাইক্লোফেনাক ব্যবহার করা হতো।' },
    { t: 'মৃতদেহে ওষুধের অবশেষ', en: 'Residue', d: 'ওষুধ দেওয়ার কয়েক দিনের মধ্যে গরু মারা গেলে তার দেহে, বিশেষত বৃক্ক ও যকৃতে, ওষুধের অবশেষ থেকে যায়।' },
    { t: 'শকুনের বৃক্ক বিকল', en: 'Kidney failure', d: 'এমন মৃতদেহ খেলে শকুনের বৃক্ক বিকল হয় — দেহে ইউরিক অ্যাসিড জমে (ভিসেরাল গাউট) কয়েক দিনের মধ্যে মৃত্যু। শকুনের প্রজনন ধীর বলে সংখ্যা দ্রুত ফেরে না।' },
    { t: 'বাস্তুতন্ত্রে প্রভাব', en: 'Ecosystem', d: 'শকুন না থাকায় মৃতদেহ পচে থাকে, বেওয়ারিশ কুকুর ও ইঁদুর বাড়ে এবং জলাতঙ্ক ও অ্যানথ্রাক্সের মতো রোগ ছড়ানোর ঝুঁকি বাড়ে।' },
    { t: 'প্রতিকার', en: 'Action', d: 'বাংলাদেশে 2010 সালে পশু চিকিৎসায় ডাইক্লোফেনাক নিষিদ্ধ হয় এবং 2014 সালে দুটি শকুন-নিরাপদ এলাকা ঘোষণা করা হয়; বিকল্প নিরাপদ ওষুধ মেলোক্সিক্যাম ব্যবহারে উৎসাহ দেওয়া হচ্ছে, শকুনের জন্য নিরাপদ খাদ্যস্থলও তৈরি করা হয়েছে।' }
  ],
  draw(g, C, s, u) {
    const xs = [40, 110, 180, 250, 320], R = [9, 2, 4, 6, 10];
    xs.forEach((x, i) => { const on = i === s, done = i < s, Rr = BK.ramp(R[i]); E('circle', { cx: x, cy: 96, r: on ? 26 : 20, fill: FK.alpha(Rr.c, on ? .4 : done ? .25 : .1), stroke: on ? Rr.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g); if (i < 4) arrow(g, x + 22, 96, xs[i + 1] - 22, 96, done || on ? C.fg : C.ln, { w: 1.4, h: 4 }); });
    org(g, 'cow', 40, 108, .8); E('rect', { x: 104, y: 86, width: 12, height: 20, rx: 3, fill: '#fff', stroke: BK.ramp(2).dk }, g); E('path', { d: 'M104 94h12', stroke: BK.ramp(2).dk }, g);
    org(g, 'hawk', 180, 110, .8); if (s >= 2) nope(g, 196, 80, 5, BK.ramp(4).dk);
    org(g, 'rabbit', 250, 110, .7); okm(g, 312, 98, 7, BK.ramp(10).dk);
    const names = ['ওষুধ', 'অবশেষ', 'শকুন মারা যায়', 'রোগ ছড়ায়', 'নিষেধাজ্ঞা'];
    xs.forEach((x, i) => T(g, x, 140, names[i], { fs: 9, a: 'middle', w: i === s ? 700 : 500, c: i === s ? C.fg : C.mu }));
    if (s === 2) { const k = u; E('circle', { cx: 180, cy: 96, r: 26 + k * 10, fill: 'none', stroke: BK.ramp(4).c, opacity: 1 - k }, g); }
  }
}));

V.cmpGharialMugger = cmp('ঘড়িয়াল বনাম মিঠাপানির কুমির', 'দুটিই বাংলাদেশের মিঠাপানির কুমির জাতীয় সরীসৃপ — দুটিই সংকটে।', 'ঘড়িয়াল', 'মিঠাপানির কুমির (মাগার)', [
  ['বৈজ্ঞানিক নাম', 'Gavialis gangeticus', 'Crocodylus palustris'],
  ['চোয়াল', 'খুব লম্বা ও সরু', 'চওড়া ও খাটো'],
  ['খাদ্য', 'প্রায় শুধু মাছ', 'মাছ, পাখি, স্তন্যপায়ী — সব ধরনের প্রাণী'],
  ['বিশেষ চিহ্ন', 'পুরুষের নাকের ডগায় ঘড়ার মতো ফোলা অংশ', 'নেই'],
  ['আবাস', 'বড় নদীর গভীর স্রোত ও বালুচর', 'বিল, পুকুর, ধীর প্রবাহের নদী'],
  ['বাংলাদেশে অবস্থা', 'মহাবিপন্ন (CR)', 'বন্য অবস্থায় বিলুপ্ত (RE, 2015)'],
  ['বিশ্বে অবস্থা', 'মহাবিপন্ন (CR)', 'সংকটাপন্ন (VU)']
]);
})();
