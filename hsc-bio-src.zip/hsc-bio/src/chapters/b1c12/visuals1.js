/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §১২.১ প্রজাতি, পপুলেশন, জীব সম্প্রদায়, বাস্তুতন্ত্র, পিরামিড, শক্তি প্রবাহ ও জৈব বিবর্ধন
   speciesConcept, plantCount, popTraits, popGrowth, markRecap, commLayers, pondEco, foodWeb,
   ecoPyramid, energyFlow, bioMag, cmpPyrNumEnergy, cmpChainWeb, cmpGrazDet
   এখানে B12X (arrow, okm, nope, cmp, org) রপ্তানি হয় — visuals2–5 এগুলো ব্যবহার করে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B12;
const PI = Math.PI, cl = B.cl || ((v, a = 0, b = 1) => Math.max(a, Math.min(b, v))), rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot, chip = B.chip, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const arrow = (g, x0, y0, x1, y1, c, o = {}) => { const a = Math.atan2(y1 - y0, x1 - x0), h = o.h || 6; E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: c, 'stroke-width': o.w || 1.6, 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1, fill: 'none' }, g); E('path', { d: `M${x1} ${y1}l${-h * Math.cos(a - .45)} ${-h * Math.sin(a - .45)}l${h * Math.cos(a - .45) - h * Math.cos(a + .45)} ${h * Math.sin(a - .45) - h * Math.sin(a + .45)}z`, fill: c, opacity: o.op != null ? o.op : 1 }, g); };
const okm = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y}l${r * .7} ${r * .7}l${r * 1.3} ${-r * 1.4}`, stroke: c, 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
const nope = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y - r}L${x + r} ${y + r}M${x + r} ${y - r}L${x - r} ${y + r}`, stroke: c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g);
/* সরল জীব-প্রতীক: kind = grass, tree, shrub, insect, frog, snake, hawk, rabbit, deer, tiger, fish, bigfish, plank, zoo, fungus, bird, cow */
const org = (g, kind, x, y, s = 1, o = {}) => {
  const op = o.op != null ? o.op : 1, R10 = BK.ramp(10), R6 = BK.ramp(6), R2 = BK.ramp(2), R4 = BK.ramp(4), R11 = BK.ramp(11), R5 = BK.ramp(5);
  const P = (d, f, st, w = 1) => E('path', { d, fill: f, stroke: st, 'stroke-width': w, opacity: op, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, g);
  const Cc = (cx, cy, r, f, st) => E('circle', { cx, cy, r, fill: f, stroke: st || 'none', 'stroke-width': .8, opacity: op }, g);
  switch (kind) {
    case 'grass': for (let i = -2; i <= 2; i++) P(`M${x + i * 3 * s} ${y}q${i * 2 * s} ${-9 * s} ${i * 4 * s} ${-16 * s}`, 'none', R10.dk, 1.8 * s); break;
    case 'shrub': Cc(x, y - 8 * s, 9 * s, R10.c, R10.dk); Cc(x - 7 * s, y - 4 * s, 6 * s, R10.c, R10.dk); Cc(x + 7 * s, y - 4 * s, 6 * s, R10.c, R10.dk); break;
    case 'tree': P(`M${x - 2.5 * s} ${y}V${y - 16 * s}H${x + 2.5 * s}V${y}Z`, R11.c, R11.dk); Cc(x, y - 24 * s, 12 * s, R10.c, R10.dk); Cc(x - 9 * s, y - 18 * s, 7 * s, R10.c, R10.dk); Cc(x + 9 * s, y - 18 * s, 7 * s, R10.c, R10.dk); break;
    case 'insect': E('ellipse', { cx: x, cy: y - 4 * s, rx: 8 * s, ry: 3.5 * s, fill: R6.c, stroke: R6.dk, 'stroke-width': .8, opacity: op }, g); Cc(x + 8.5 * s, y - 5 * s, 2.6 * s, R6.dk); P(`M${x - 2 * s} ${y - 2 * s}l${-4 * s} ${5 * s}M${x + 2 * s} ${y - 2 * s}l${2 * s} ${5 * s}M${x + 9 * s} ${y - 7 * s}l${4 * s} ${-5 * s}`, 'none', R6.dk, 1); break;
    case 'zoo': Cc(x, y - 3 * s, 4 * s, R6.c, R6.dk); P(`M${x - 3 * s} ${y}l${-3 * s} ${4 * s}M${x + 3 * s} ${y}l${3 * s} ${4 * s}`, 'none', R6.dk, .9); break;
    case 'plank': for (let i = 0; i < 5; i++) Cc(x + (rnd(i * 3 + 1) - .5) * 14 * s, y - 4 * s + (rnd(i * 7 + 2) - .5) * 8 * s, 2.2 * s, R10.c, R10.dk); break;
    case 'rabbit': E('ellipse', { cx: x, cy: y - 6 * s, rx: 9 * s, ry: 6 * s, fill: '#cdbba4', stroke: '#7a6650', 'stroke-width': .8, opacity: op }, g); Cc(x + 9 * s, y - 10 * s, 4.5 * s, '#cdbba4', '#7a6650'); P(`M${x + 8 * s} ${y - 14 * s}l${-1 * s} ${-9 * s}M${x + 11 * s} ${y - 14 * s}l${1 * s} ${-9 * s}`, 'none', '#7a6650', 2.2 * s); break;
    case 'deer': E('ellipse', { cx: x, cy: y - 12 * s, rx: 12 * s, ry: 6 * s, fill: '#c9925a', stroke: '#7a4f25', 'stroke-width': .8, opacity: op }, g); P(`M${x - 8 * s} ${y - 8 * s}V${y}M${x + 8 * s} ${y - 8 * s}V${y}M${x + 10 * s} ${y - 15 * s}l${5 * s} ${-9 * s}`, 'none', '#7a4f25', 2 * s); Cc(x + 16 * s, y - 25 * s, 3.6 * s, '#c9925a', '#7a4f25'); P(`M${x + 15 * s} ${y - 28 * s}l${-3 * s} ${-6 * s}M${x + 17 * s} ${y - 28 * s}l${3 * s} ${-6 * s}`, 'none', '#7a4f25', 1.2); break;
    case 'frog': E('ellipse', { cx: x, cy: y - 5 * s, rx: 8 * s, ry: 5 * s, fill: R10.c, stroke: R10.dk, 'stroke-width': .8, opacity: op }, g); Cc(x - 4 * s, y - 10 * s, 2.4 * s, '#fff', R10.dk); Cc(x + 4 * s, y - 10 * s, 2.4 * s, '#fff', R10.dk); P(`M${x - 8 * s} ${y - 2 * s}l${-5 * s} ${3 * s}M${x + 8 * s} ${y - 2 * s}l${5 * s} ${3 * s}`, 'none', R10.dk, 1.6 * s); break;
    case 'snake': P(`M${x - 14 * s} ${y - 3 * s}q${5 * s} ${-8 * s} ${10 * s} 0t${10 * s} 0t${10 * s} ${-2 * s}`, 'none', R2.dk, 3.4 * s); Cc(x + 16 * s, y - 5 * s, 3 * s, R2.c, R2.dk); break;
    case 'hawk': case 'bird': { const R = kind === 'hawk' ? R4 : R2; P(`M${x - 16 * s} ${y - 10 * s}q${8 * s} ${-8 * s} ${16 * s} 0q${8 * s} ${-8 * s} ${16 * s} 0`, 'none', R.dk, 2.4 * s); E('ellipse', { cx: x, cy: y - 9 * s, rx: 4 * s, ry: 3 * s, fill: R.c, stroke: R.dk, 'stroke-width': .8, opacity: op }, g); break; }
    case 'tiger': E('ellipse', { cx: x, cy: y - 10 * s, rx: 14 * s, ry: 6.5 * s, fill: '#e0912f', stroke: '#7a4310', 'stroke-width': .8, opacity: op }, g); for (let i = -2; i <= 2; i++) P(`M${x + i * 5 * s} ${y - 16 * s}v${5 * s}`, 'none', '#3b2410', 1.4); Cc(x + 15 * s, y - 13 * s, 5 * s, '#e0912f', '#7a4310'); P(`M${x - 9 * s} ${y - 5 * s}V${y}M${x + 9 * s} ${y - 5 * s}V${y}M${x - 14 * s} ${y - 11 * s}q${-6 * s} ${-2 * s} ${-8 * s} ${-8 * s}`, 'none', '#7a4310', 2 * s); break;
    case 'fish': case 'bigfish': { const k = kind === 'bigfish' ? 1.5 : 1, R = kind === 'bigfish' ? R4 : R2; E('ellipse', { cx: x, cy: y - 5 * s * k, rx: 9 * s * k, ry: 4.2 * s * k, fill: R.c, stroke: R.dk, 'stroke-width': .8, opacity: op }, g); P(`M${x - 8 * s * k} ${y - 5 * s * k}l${-6 * s * k} ${-4 * s * k}v${8 * s * k}z`, R.c, R.dk); Cc(x + 5 * s * k, y - 6 * s * k, 1.2 * s * k, R.dk); break; }
    case 'fungus': P(`M${x - 9 * s} ${y - 8 * s}q${9 * s} ${-12 * s} ${18 * s} 0z`, R11.c, R11.dk); P(`M${x - 2 * s} ${y - 8 * s}V${y}H${x + 2 * s}V${y - 8 * s}`, '#efe2cc', R11.dk); break;
    case 'cow': E('ellipse', { cx: x, cy: y - 11 * s, rx: 13 * s, ry: 6.5 * s, fill: '#f4efe6', stroke: '#6b5b47', 'stroke-width': .8, opacity: op }, g); P(`M${x - 8 * s} ${y - 6 * s}V${y}M${x + 8 * s} ${y - 6 * s}V${y}`, 'none', '#6b5b47', 2 * s); Cc(x + 14 * s, y - 14 * s, 4.5 * s, '#f4efe6', '#6b5b47'); break;
  }
};
window.B12X = { arrow, okm, nope, cmp, org };

/* ═════════ ১. প্রজাতি ═════════ */
V.speciesConcept = Object.assign({}, B.seg({
  id: 'spc', t: 'প্রজাতি — জৈবিক প্রজাতি ধারণা', H: 250, def: 'bio',
  cap: 'প্রজাতি — আকৃতি ও গঠনে প্রায় একই রকম এবং যারা নিজেদের মধ্যে প্রাকৃতিকভাবে মিলিত হয়ে জননক্ষম (উর্বর) সন্তান জন্ম দিতে পারে, কিন্তু অন্য দলের সাথে জননগতভাবে বিচ্ছিন্ন — এমন জীবগোষ্ঠী। এটি আর্নস্ট মেয়ারের (1942) জৈবিক প্রজাতি ধারণা। প্রজাতিই শ্রেণিবিন্যাসের মৌলিক একক।',
  types: {
    bio: ['জননক্ষম সন্তান', 'একই প্রজাতির মিলন', 'একই প্রজাতির দুটি জীবের মিলনে যে সন্তান হয় সেটিও জননক্ষম — তাই তারা একই জিনপুলের অংশ।'],
    iso: ['জনন-বিচ্ছিন্নতা', 'ভিন্ন প্রজাতির মিলন — খচ্চর', 'ঘোড়া (2n = 64) ও গাধা (2n = 62) মিলে খচ্চর (2n = 63) জন্মায়, কিন্তু খচ্চর বন্ধ্যা — ক্রোমোসোম জোড় মেলে না বলে মিয়োসিস ঠিকমতো হয় না। তাই ঘোড়া ও গাধা আলাদা প্রজাতি।'],
    name: ['দ্বিপদ নাম', 'প্রজাতির বৈজ্ঞানিক নাম', 'ক্যারোলাস লিনিয়াসের দ্বিপদ নামকরণে প্রথম পদ গণ (বড় হাতের অক্ষরে শুরু), দ্বিতীয় পদ প্রজাতিক বিশেষণ (ছোট হাতের অক্ষরে) — যেমন Homo sapiens, Oryza sativa, Panthera tigris।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'name') {
      const rows = [['Oryza', 'sativa', 'ধান'], ['Homo', 'sapiens', 'মানুষ'], ['Panthera', 'tigris', 'বাঘ'], ['Corypha', 'taliera', 'তালিপাম']];
      T(g, 108, 30, 'গণ', { fs: 11, a: 'middle', w: 700, c: BK.ramp(3).ink }); T(g, 214, 30, 'প্রজাতিক বিশেষণ', { fs: 11, a: 'middle', w: 700, c: BK.ramp(5).ink }); T(g, 310, 30, 'বাংলা নাম', { fs: 11, a: 'middle', c: C.mu });
      rows.forEach(([a, b, c], i) => { const y = 64 + i * 44; E('rect', { x: 56, y: y - 18, width: 104, height: 30, rx: 8, fill: FK.alpha(BK.ramp(3).c, .14), stroke: BK.ramp(3).dk }, g); E('rect', { x: 166, y: y - 18, width: 96, height: 30, rx: 8, fill: FK.alpha(BK.ramp(5).c, .14), stroke: BK.ramp(5).dk }, g); T(g, 108, y + 2, a, { fs: 12, a: 'middle', w: 650, c: C.fg, st: 'font-style:italic' }); T(g, 214, y + 2, b, { fs: 12, a: 'middle', c: C.fg, st: 'font-style:italic' }); T(g, 310, y + 2, c, { fs: 11, a: 'middle', c: C.mu }); });
      T(g, 180, 238, 'গণ বড় হাতের অক্ষরে, বিশেষণ ছোট হাতের অক্ষরে; ছাপায় বাঁকা, হাতে লিখলে আলাদা দাগ', { fs: 8.8, a: 'middle', c: C.mu });
      return;
    }
    const iso = ty === 'iso';
    const A = iso ? ['ঘোড়া', '2n = 64', 2] : ['পুরুষ', 'একই প্রজাতি', 6], Bq = iso ? ['গাধা', '2n = 62', 5] : ['স্ত্রী', 'একই প্রজাতি', 6];
    [[70, A], [290, Bq]].forEach(([x, d]) => { const R = BK.ramp(d[2]); E('circle', { cx: x, cy: 70, r: 30, fill: FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': 1.5 }, g); T(g, x, 68, d[0], { fs: 12.5, a: 'middle', w: 700, c: R.ink }); T(g, x, 84, d[1], { fs: 9.4, a: 'middle', c: C.mu }); });
    T(g, 180, 74, '+', { fs: 22, a: 'middle', w: 700, c: C.mu });
    arrow(g, 98, 96, 160, 140, C.mu); arrow(g, 262, 96, 200, 140, C.mu);
    const Rk = BK.ramp(iso ? 4 : 10);
    E('circle', { cx: 180, cy: 164, r: 26, fill: FK.alpha(Rk.c, .2), stroke: Rk.dk, 'stroke-width': 1.5 }, g);
    T(g, 180, 162, iso ? 'খচ্চর' : 'সন্তান', { fs: 12, a: 'middle', w: 700, c: Rk.ink }); T(g, 180, 177, iso ? '2n = 63' : 'জননক্ষম', { fs: 9.2, a: 'middle', c: C.mu });
    E('rect', { x: 30, y: 204, width: 300, height: 34, rx: 9, fill: FK.alpha(Rk.c, .1), stroke: Rk.dk }, g);
    T(g, 180, 225, iso ? 'খচ্চর বন্ধ্যা → ঘোড়া ও গাধা আলাদা প্রজাতি' : 'সন্তান আবার সন্তান দিতে পারে → একই প্রজাতি', { fs: 10.4, a: 'middle', w: 650, c: Rk.ink });
    if (iso) nope(g, 220, 150, 6, BK.ramp(4).dk); else okm(g, 214, 150, 6, BK.ramp(10).dk);
  },
  anim(g, C, ty, t) { if (!t || ty === 'name') return; const k = (t * .6) % 1; E('circle', { cx: 180, cy: 164, r: 26 + k * 12, fill: 'none', stroke: BK.ramp(ty === 'iso' ? 4 : 10).c, 'stroke-width': 1.6, opacity: 1 - k }, g); }
}));

/* ═════════ ২. উদ্ভিদ প্রজাতির সংখ্যা ═════════ */
const WORLD = [['জানা উদ্ভিদ প্রজাতি (মোট)', 390900, 9], ['সপুষ্পক (আবৃতবীজী)', 369400, 10], ['অন্যান্য সংবহন উদ্ভিদ', 21500, 3]];
const BDP = [['আবৃতবীজী (নথিভুক্ত)', 3611, 10], ['শৈবাল (মিঠাপানির)', 300, 5], ['ছত্রাক', 275, 11], ['টেরিডোফাইট', 250, 3], ['ব্রায়োফাইট', 250, 6], ['নগ্নবীজী', 7, 2]];
V.plantCount = Object.assign({}, B.seg({
  id: 'plc', t: 'উদ্ভিদ প্রজাতির সংখ্যা', H: 250, def: 'w', sel: null,
  cap: 'পৃথিবী — কিউ রয়্যাল বোটানিক গার্ডেনসের "State of the World’s Plants" (2016) অনুযায়ী বিজ্ঞানের জানা উদ্ভিদ প্রজাতি প্রায় 3,90,900 (শৈবাল ও মস জাতীয় উদ্ভিদ বাদে), এর মধ্যে সপুষ্পক প্রায় 3,69,400; প্রতি বছর আরও প্রায় দুই হাজার নতুন প্রজাতি বর্ণিত হয়। বাংলাদেশ — Encyclopedia of Flora and Fauna of Bangladesh (2008–2009) অনুযায়ী 3,611টি আবৃতবীজী প্রজাতি নথিভুক্ত; সব দলের উদ্ভিদ মিলে 6,000 এর বেশি প্রজাতি। বিভিন্ন গণনায় সংখ্যাগুলো কিছুটা আলাদা হয়। দণ্ডে চাপ দাও।',
  types: { w: ['পৃথিবী', 'পৃথিবীর জানা উদ্ভিদ প্রজাতি', 'সপুষ্পক উদ্ভিদই উদ্ভিদজগতের প্রায় 94 শতাংশ।'], bd: ['বাংলাদেশ', 'বাংলাদেশের উদ্ভিদ প্রজাতি', 'নগ্নবীজী মাত্র ৭টি — দেশে স্বাভাবিকভাবে জন্মানো নগ্নবীজী খুবই কম।'] },
  art(g, C, ty, ctx) {
    const D = ty === 'w' ? WORLD : BDP, mx = D[0][1], x0 = 142, w = 196, top = 30, gap = ty === 'w' ? 60 : 34;
    D.forEach(([s, v, ri], i) => {
      const y = top + i * gap, R = BK.ramp(ri), on = ctx.sel === i, bw = Math.max(3, (ty === 'w' ? v / mx : Math.sqrt(v / mx)) * w);
      T(g, x0 - 8, y + 14, s, { fs: 9.8, a: 'end', w: on ? 700 : 560, c: C.fg });
      E('rect', { x: x0, y, width: bw, height: 20, rx: 5, fill: FK.alpha(R.c, on ? .75 : .45), stroke: R.dk, 'stroke-width': on ? 1.8 : 1 }, g);
      T(g, x0 + Math.min(bw, w - 40) + 6, y + 14, v.toLocaleString('en-IN'), { fs: 10, w: 700, c: R.ink });
    });
    if (ty === 'bd') T(g, 180, 238, 'দণ্ডের দৈর্ঘ্য বর্গমূল-মাপে — ছোট সংখ্যাও যেন চোখে পড়ে', { fs: 8.6, a: 'middle', c: C.mu });
    else { T(g, 180, 222, 'সপুষ্পক ≈ 94% · প্রতি বছর ≈ 2,000 নতুন প্রজাতি', { fs: 10, a: 'middle', w: 650, c: BK.ramp(10).ink }); T(g, 180, 238, 'শৈবাল, মস ও লিভারওয়ার্ট এ গণনার বাইরে', { fs: 8.6, a: 'middle', c: C.mu }); }
    ctx.H = D.map((_, i) => [240, top + i * gap + 10, i]);
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const D = ty === 'w' ? WORLD : BDP, i = Math.floor(t * .5) % D.length, gap = ty === 'w' ? 60 : 34; E('rect', { x: 140, y: 28 + i * gap, width: 200, height: 24, rx: 6, fill: 'none', stroke: BK.ramp(D[i][2]).c, 'stroke-width': 1.4, opacity: .7 }, g); },
  tap(x, y, ty, ctx) {
    const h = hot(ctx.H || [], x, y, 140); if (!h) return null; ctx.sel = h[2];
    const N = ty === 'w' ? ['বিজ্ঞানের কাছে পরিচিত ও নামকরণ করা সংবহন উদ্ভিদের আনুমানিক সংখ্যা (Kew, 2016)।', 'ফুল ও ফল ধারণকারী উদ্ভিদ — উদ্ভিদজগতের সবচেয়ে বড় দল।', 'ফার্ন, লাইকোফাইট ও নগ্নবীজী মিলে।'] : ['Encyclopedia of Flora and Fauna of Bangladesh এ নথিভুক্ত প্রজাতি; অন্য অনুমানে প্রায় 5,000।', 'মিঠাপানির শৈবাল; লোনা ও সামুদ্রিক শৈবাল এর বাইরে আরও অনেক।', 'বর্ণিত প্রজাতি — প্রকৃত সংখ্যা আরও বেশি হতে পারে।', 'এর মধ্যে প্রায় 230টি ফার্ন।', 'মস ও লিভারওয়ার্ট মিলে প্রায় 250।', 'দেশে স্বাভাবিকভাবে জন্মানো নগ্নবীজী — যেমন Podocarpus neriifolius (বাঁশপাতা), Gnetum, Cycas pectinata।'];
    const D = ty === 'w' ? WORLD : BDP; return `<b>${D[h[2]][0]}: ${D[h[2]][1].toLocaleString('en-IN')}</b><div class="small">${N[h[2]]}</div>`;
  }
}));

/* ═════════ ৩. পপুলেশনের বৈশিষ্ট্য ═════════ */
const AGE = { grow: [1, .86, .7, .54, .38, .24, .12], stab: [.62, .61, .6, .58, .54, .44, .26], dec: [.36, .44, .52, .58, .56, .46, .3] };
V.popTraits = Object.assign({}, B.seg({
  id: 'pop', t: 'পপুলেশনের বৈশিষ্ট্য', H: 254, def: 'den',
  cap: 'পপুলেশন — নির্দিষ্ট সময়ে নির্দিষ্ট এলাকায় বসবাসকারী একই প্রজাতির সব জীবের সমষ্টি। এর কিছু বৈশিষ্ট্য একক জীবের নয়, কেবল পুরো দলের — ঘনত্ব, জন্মহার, মৃত্যুহার, বয়স-কাঠামো, লিঙ্গ অনুপাত, বিন্যাস ও বৃদ্ধির ধরন।',
  types: {
    den: ['ঘনত্ব', 'জনঘনত্ব', 'একক ক্ষেত্রফল বা আয়তনে জীবের সংখ্যা। ঘনত্ব = জীবের সংখ্যা ÷ ক্ষেত্রফল। জন্ম ও অভিবাসন ঘনত্ব বাড়ায়; মৃত্যু ও দেশত্যাগ কমায়।'],
    age: ['বয়স-কাঠামো', 'বয়স-পিরামিড', 'প্রাক-প্রজনন, প্রজনন ও প্রজনন-উত্তর — তিন বয়সদলের অনুপাত দেখে বোঝা যায় পপুলেশন বাড়ছে, স্থির আছে না কমছে।'],
    disp: ['বিন্যাস', 'স্থানিক বিন্যাস', 'সমবণ্টিত (প্রতিযোগিতায় সমান দূরত্ব), এলোমেলো (পরিবেশ সর্বত্র সমান) ও গুচ্ছবদ্ধ (সবচেয়ে সাধারণ — সম্পদ বা সামাজিক আচরণের কারণে দলবদ্ধ)।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'age') {
      const ks = [['grow', 'বর্ধনশীল', 10], ['stab', 'স্থিতিশীল', 6], ['dec', 'হ্রাসমান', 4]];
      ks.forEach(([k, s, ri], j) => {
        const cx = 62 + j * 118, R = BK.ramp(ri);
        AGE[k].forEach((v, i) => { const y = 196 - i * 22, w = v * 48, Rz = BK.ramp(i < 2 ? 5 : i < 5 ? ri : 9); E('rect', { x: cx - w, y: y - 9, width: w * 2, height: 18, rx: 3, fill: FK.alpha(Rz.c, .55), stroke: Rz.dk, 'stroke-width': .8 }, g); });
        T(g, cx, 228, s, { fs: 11, a: 'middle', w: 700, c: R.ink });
      });
      T(g, 180, 22, 'নিচে কম বয়সী, ওপরে বেশি বয়সী', { fs: 9.6, a: 'middle', c: C.mu });
      T(g, 180, 246, 'নিচের দণ্ড আকাশি — প্রাক-প্রজনন; মাঝে প্রজনন; ওপরে ধূসর — প্রজনন-উত্তর', { fs: 8.4, a: 'middle', c: C.mu });
      return;
    }
    if (ty === 'disp') {
      const R = BK.ramp(10), boxes = [['সমবণ্টিত', 0], ['এলোমেলো', 1], ['গুচ্ছবদ্ধ', 2]];
      boxes.forEach(([s, j]) => {
        const x0 = 12 + j * 116; E('rect', { x: x0, y: 34, width: 104, height: 160, rx: 10, fill: FK.alpha(BK.ramp(11).c, .12), stroke: C.ln }, g);
        T(g, x0 + 52, 216, s, { fs: 11, a: 'middle', w: 700, c: C.fg });
        for (let i = 0; i < 16; i++) {
          let x, y;
          if (j === 0) { x = x0 + 16 + (i % 4) * 24; y = 54 + Math.floor(i / 4) * 38; }
          else if (j === 1) { x = x0 + 10 + rnd(i * 5 + 3) * 84; y = 44 + rnd(i * 11 + 7) * 140; }
          else { const c = [[30, 70], [74, 150], [60, 110]][i % 3]; x = x0 + c[0] + (rnd(i * 13) - .5) * 26; y = c[1] + (rnd(i * 17 + 1) - .5) * 26; }
          org(g, 'shrub', x, y + 8, .55);
        }
      });
      return;
    }
    /* ঘনত্ব — তিনটি সমান এলাকা (2 হেক্টর করে) */
    [[6, 0], [12, 1], [24, 2]].forEach(([n, j]) => {
      const x0 = 12 + j * 116, on = ctx.sel === j, R = BK.ramp([10, 6, 4][j]);
      E('rect', { x: x0, y: 30, width: 104, height: 140, rx: 10, fill: FK.alpha(BK.ramp(10).c, .06), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1 }, g);
      for (let i = 0; i < n; i++) org(g, 'rabbit', x0 + 12 + rnd(i * 7 + j * 31 + 1) * 74, 54 + rnd(i * 13 + j * 17 + 2) * 108, .42);
      T(g, x0 + 52, 188, `${n}টি ÷ 2 হেক্টর`, { fs: 10, a: 'middle', c: C.fg });
      T(g, x0 + 52, 206, `= ${n / 2}টি / হেক্টর`, { fs: 11.5, a: 'middle', w: 700, c: R.ink });
    });
    ctx.H = [0, 1, 2].map(j => [64 + j * 116, 100, j]);
    T(g, 180, 234, 'ঘনত্ব = জীবের সংখ্যা ÷ ক্ষেত্রফল — এলাকায় চাপ দাও', { fs: 9.4, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'age') { const j = Math.floor(t * .4) % 3; E('rect', { x: 62 + j * 118 - 54, y: 50, width: 108, height: 160, rx: 8, fill: 'none', stroke: BK.ramp([10, 6, 4][j]).c, 'stroke-width': 1.6, opacity: .7 }, g); return; }
    if (ty === 'disp') { const j = Math.floor(t * .4) % 3; E('rect', { x: 12 + j * 116, y: 34, width: 104, height: 160, rx: 10, fill: 'none', stroke: BK.ramp(10).c, 'stroke-width': 2, opacity: .8 }, g); return; }
    const j = Math.floor(t * .4) % 3; E('rect', { x: 12 + j * 116, y: 30, width: 104, height: 140, rx: 10, fill: 'none', stroke: BK.ramp([10, 6, 4][j]).c, 'stroke-width': 2, opacity: .8 }, g);
  },
  tap(x, y, ty, ctx) {
    if (ty !== 'den') return null; const h = hot(ctx.H || [], x, y, 70); if (!h) return null; ctx.sel = h[2];
    return ['<b>ঘনত্ব ৩টি / হেক্টর</b> — খাদ্য ও জায়গা প্রচুর; প্রতিযোগিতা কম, বৃদ্ধির সুযোগ বেশি।', '<b>ঘনত্ব ৬টি / হেক্টর</b> — মাঝারি; সম্পদের ভাগাভাগি শুরু।', '<b>ঘনত্ব ১২টি / হেক্টর</b> — ঘন; খাদ্য-প্রতিযোগিতা, রোগ বিস্তার ও দেশত্যাগ বাড়ে, ফলে বৃদ্ধির হার কমে।'][h[2]];
  }
}));

/* ═════════ ৪. পপুলেশন বৃদ্ধি — J ও S বক্ররেখা ═════════ */
V.popGrowth = Object.assign({}, B.seg({
  id: 'pgr', t: 'পপুলেশন বৃদ্ধির ধরন', H: 250, def: 'both', sel: null,
  cap: 'সীমাহীন সম্পদে পপুলেশন সূচকীয় হারে বাড়ে — J আকৃতির বক্ররেখা (dN/dt = rN)। বাস্তবে খাদ্য, জায়গা ও রোগের সীমার কারণে বৃদ্ধি ধীরে ধীরে কমে বহনক্ষমতার (K) কাছে স্থির হয় — S আকৃতির বা লজিস্টিক বক্ররেখা (dN/dt = rN(1 − N/K))। r = অন্তর্নিহিত বৃদ্ধির হার। স্লাইডারে r ও K বদলাও, লেখচিত্রে চাপ দিয়ে মান পড়ো।',
  sl: [{ k: 'r', l: 'হার r', min: .2, max: 1, step: .05, val: .5, d: 2 }, { k: 'K', l: 'K', min: 200, max: 900, step: 50, val: 600 }],
  types: { both: ['J ও S', 'J ও S বক্ররেখা একসাথে', 'শুরুতে দুটি প্রায় একই; সম্পদের সীমা কাজ শুরু করলে S বক্ররেখা বেঁকে K এর দিকে স্থির হয়, J বক্ররেখা বাড়তেই থাকে।'] },
  art(g, C, ty, ctx) {
    const r = +ctx.v.r, K = +ctx.v.K, N0 = 10, tm = 20;
    const P = B.axes(g, C, [48, 26, 286, 170], { xr: [0, tm], yr: [0, 1000], lx: 'সময় (বছর)', ly: 'জীবের সংখ্যা N', xt: [0, 5, 10, 15, 20], yt: [250, 500, 750, 1000] });
    const J = t => Math.min(1000, N0 * Math.exp(r * t)), S = t => K / (1 + (K / N0 - 1) * Math.exp(-r * t));
    const [, yk] = P(0, K), [xa] = P(0, 0), [xb] = P(tm, 0);
    E('path', { d: `M${xa} ${yk}H${xb}`, stroke: BK.ramp(9).dk, 'stroke-dasharray': '5 4', 'stroke-width': 1.2 }, g);
    T(g, xb - 2, yk - 5, 'K = ' + K, { fs: 9.6, a: 'end', w: 650, c: BK.ramp(9).ink });
    B.curve(g, P, J, 0, Math.min(tm, Math.log(1000 / N0) / r), { stroke: BK.ramp(4).c, 'stroke-width': 2.6 });
    B.curve(g, P, S, 0, tm, { stroke: BK.ramp(10).c, 'stroke-width': 2.8 });
    const tj = Math.min(tm, Math.log(1000 / N0) / r) * .96, [jx, jy] = P(tj, J(tj)); T(g, jx - 6, jy + 4, 'J', { fs: 13, a: 'end', w: 700, c: BK.ramp(4).ink });
    const [sx, sy] = P(tm - 1, S(tm - 1)); T(g, sx, sy + 16, 'S', { fs: 13, a: 'middle', w: 700, c: BK.ramp(10).ink });
    const ti = Math.log(K / N0 - 1) / r; if (ti > 0 && ti < tm) { const [ix, iy] = P(ti, K / 2); E('circle', { cx: ix, cy: iy, r: 3.5, fill: BK.ramp(10).dk }, g); T(g, ix + 6, iy + 14, 'K/2 — দ্রুততম বৃদ্ধি', { fs: 8.6, c: BK.ramp(10).ink }); }
    if (ctx.sel != null) { const tv = ctx.sel, [px, py] = P(tv, S(tv)); E('path', { d: `M${px} ${P(0, 0)[1]}V${py}`, stroke: C.mu, 'stroke-dasharray': '3 3' }, g); E('circle', { cx: px, cy: py, r: 4.5, fill: BK.ramp(10).c, stroke: C.sf, 'stroke-width': 1.6 }, g); }
    ctx.P = P; ctx.J = J; ctx.S = S;
    T(g, 180, 244, `দ্বিগুণ হওয়ার সময় ≈ 0.693 ÷ r = ${FK.n(.693 / r, 1)} বছর`, { fs: 9.6, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) { if (!t || !ctx.P) return; const u = (t * .12) % 1, tv = u * 20, [px, py] = ctx.P(tv, ctx.S(tv)); E('circle', { cx: px, cy: py, r: 5, fill: BK.ramp(10).dk }, g); const jv = ctx.J(tv); if (jv < 1000) { const [qx, qy] = ctx.P(tv, jv); E('circle', { cx: qx, cy: qy, r: 4, fill: BK.ramp(4).dk }, g); } },
  tap(x, y, ty, ctx) {
    if (x < 48 || x > 334) return null; const tv = cl((x - 48) / 286 * 20, 0, 20); ctx.sel = tv;
    const s = ctx.S(tv), j = ctx.J(tv);
    return `<b>t = ${FK.n(tv, 1)} বছর</b> — S বক্ররেখায় N ≈ <b>${Math.round(s)}</b>${j < 1000 ? `, J বক্ররেখায় N ≈ <b>${Math.round(j)}</b>` : ', J বক্ররেখা লেখচিত্রের বাইরে চলে গেছে'}।<div class="small">S বক্ররেখায় বৃদ্ধির হার = rN(1 − N/K) = ${FK.n(ctx.v.r * s * (1 - s / ctx.v.K), 1)} টি / বছর।</div>`;
  }
}));

/* ═════════ ৫. চিহ্নিত-পুনঃধৃত পদ্ধতি ═════════ */
V.markRecap = Object.assign({}, B.seg({
  id: 'mrc', t: 'পপুলেশনের আকার নির্ণয় — চিহ্নিত-পুনঃধৃত পদ্ধতি', H: 246, def: 'lp',
  cap: 'চলাফেরা করে এমন প্রাণীর সংখ্যা সরাসরি গোনা যায় না। লিংকন-পিটারসেন পদ্ধতিতে প্রথমবার M টি প্রাণী ধরে চিহ্ন দিয়ে ছেড়ে দেওয়া হয়; কিছুদিন পর আবার C টি ধরা হয়, যার মধ্যে R টি চিহ্নিত। ধরা হয়, দ্বিতীয় নমুনায় চিহ্নিতদের অনুপাত পুরো পপুলেশনের অনুপাতের সমান: R/C = M/N, তাই N = M × C ÷ R।',
  sl: [{ k: 'M', l: 'চিহ্নিত M', min: 10, max: 60, step: 5, val: 40 }, { k: 'C', l: 'পরে ধরা C', min: 10, max: 60, step: 5, val: 50 }, { k: 'R', l: 'পুনঃধৃত R', min: 1, max: 20, step: 1, val: 8 }],
  types: { lp: ['হিসাব', 'N = M × C ÷ R', 'শর্ত: চিহ্ন হারাবে না, চিহ্নিতরা মিশে যাবে, এ সময়ে জন্ম-মৃত্যু-আগমন-প্রস্থান নগণ্য।'] },
  art(g, C, ty, ctx) {
    const M = +ctx.v.M, Cc = +ctx.v.C, R = Math.min(+ctx.v.R, Cc), N = Math.round(M * Cc / R);
    const R6 = BK.ramp(6), R3 = BK.ramp(3);
    E('rect', { x: 14, y: 22, width: 160, height: 170, rx: 10, fill: FK.alpha(BK.ramp(5).c, .1), stroke: C.ln }, g);
    T(g, 94, 40, 'দ্বিতীয় নমুনা (C = ' + Cc + ')', { fs: 9.6, a: 'middle', w: 650, c: C.fg });
    for (let i = 0; i < Cc; i++) { const x = 28 + (i % 10) * 14.5, y = 56 + Math.floor(i / 10) * 24, mk = i < R; E('ellipse', { cx: x, cy: y, rx: 5.5, ry: 3.5, fill: mk ? R3.c : R6.c, stroke: mk ? R3.dk : R6.dk, 'stroke-width': .8 }, g); if (mk) E('circle', { cx: x, cy: y, r: 1.6, fill: '#fff' }, g); }
    T(g, 94, 186, 'বেগুনি = চিহ্নিত (R = ' + R + ')', { fs: 9, a: 'middle', c: R3.ink });
    E('rect', { x: 186, y: 22, width: 160, height: 170, rx: 10, fill: FK.alpha(R3.c, .08), stroke: R3.dk }, g);
    T(g, 266, 50, 'N = M × C ÷ R', { fs: 12, a: 'middle', w: 700, c: R3.ink });
    T(g, 266, 80, `= ${M} × ${Cc} ÷ ${R}`, { fs: 11.5, a: 'middle', c: C.fg });
    T(g, 266, 116, '≈ ' + N, { fs: 22, a: 'middle', w: 700, c: R3.ink });
    T(g, 266, 140, 'টি প্রাণী (আনুমানিক)', { fs: 9.6, a: 'middle', c: C.mu });
    T(g, 266, 168, `অনুপাত R/C = ${FK.n(R / Cc, 2)}`, { fs: 9.6, a: 'middle', c: C.mu });
    T(g, 266, 182, `M/N = ${FK.n(M / N, 2)}`, { fs: 9.6, a: 'middle', c: C.mu });
    T(g, 180, 214, R < 4 ? 'R খুব কম — অনুমান অনিশ্চিত; বড় নমুনা নাও' : 'R/C ও M/N সমান ধরেই হিসাব', { fs: 9.6, a: 'middle', w: 600, c: R < 4 ? BK.ramp(4).ink : C.mu });
    T(g, 180, 232, 'উদাহরণ: পুকুরের মাছ, বনের পাখি, মাঠের ইঁদুর', { fs: 8.8, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const R = Math.min(+ctx.v.R, +ctx.v.C), i = Math.floor(t * 3) % Math.max(1, R); E('circle', { cx: 28 + (i % 10) * 14.5, cy: 56 + Math.floor(i / 10) * 24, r: 7.5, fill: 'none', stroke: BK.ramp(3).c, 'stroke-width': 1.4 }, g); }
}));
})();
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B12, XB = window.B12X;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, node = B.node, bn = B.bn, hot = B.hot, chip = B.chip, lab = B.lab;
const arrow = XB.arrow, okm = XB.okm, nope = XB.nope, cmp = XB.cmp, org = XB.org;
const TR = [10, 6, 2, 4];   /* পুষ্টিস্তরের রং: উৎপাদক, প্রাথমিক, গৌণ, প্রগৌণ */

/* ═════════ ৬. জীব সম্প্রদায় — স্তরবিন্যাস ও ইকোটোন ═════════ */
const LAYERS = [['উদীয়মান স্তর', 'সবচেয়ে উঁচু গাছের মাথা — গর্জন, চাপালিশ', 30, 10], ['চাঁদোয়া স্তর', 'গাছের মাথা মিলে ছাদ তৈরি; বেশিরভাগ আলো এখানে শোষিত', 62, 10], ['নিম্ন চাঁদোয়া', 'ছায়াসহিষ্ণু ছোট গাছ', 102, 10], ['গুল্ম স্তর', 'ঝোপঝাড় — আসাম লতা, বেত', 142, 6], ['বীরুৎ স্তর', 'ঘাস, ফার্ন, ছোট বীরুৎ', 172, 6], ['ভূমি স্তর', 'পাতার আবরণ, ছত্রাক, বিয়োজক', 196, 11]];
V.commLayers = Object.assign({}, B.seg({
  id: 'cml', t: 'জীব সম্প্রদায়', H: 250, def: 'str', sel: null,
  cap: 'জীব সম্প্রদায় — নির্দিষ্ট এলাকায় একসাথে বসবাসকারী ও পরস্পরের ওপর নির্ভরশীল বিভিন্ন প্রজাতির পপুলেশনের সমষ্টি। এর বৈশিষ্ট্য: প্রজাতি-বৈচিত্র্য, প্রভাবশালী (ডমিন্যান্ট) প্রজাতি, স্তরবিন্যাস, খাদ্য-সম্পর্ক এবং সময়ের সাথে ধারাবাহিক পরিবর্তন বা সাকসেশন। দুটি সম্প্রদায়ের মিলনস্থল ইকোটোন।',
  types: {
    str: ['স্তরবিন্যাস', 'বনের উল্লম্ব স্তরবিন্যাস', 'আলোর পরিমাণ অনুযায়ী উদ্ভিদ বিভিন্ন উচ্চতায় স্তরে সাজানো থাকে; প্রতিটি স্তরে আলাদা প্রাণী বাস করে। স্তরে চাপ দাও।'],
    eco: ['ইকোটোন', 'ইকোটোন ও প্রান্ত-প্রভাব', 'দুটি সম্প্রদায়ের মাঝের রূপান্তর অঞ্চলে দুই পাশের প্রজাতি তো থাকেই, সাথে কিছু নিজস্ব প্রজাতিও থাকে — ফলে প্রজাতির সংখ্যা ও ঘনত্ব বেশি হয়। একে প্রান্ত-প্রভাব (edge effect) বলে। উদাহরণ — বন ও তৃণভূমির মাঝে, স্থল ও জলাশয়ের মাঝে, সুন্দরবনে নদী ও সমুদ্রের মিলনস্থলে।']
  },
  art(g, C, ty, ctx) {
    if (ty === 'eco') {
      E('rect', { x: 10, y: 30, width: 340, height: 170, rx: 10, fill: FK.alpha(BK.ramp(10).c, .04), stroke: C.ln }, g);
      E('rect', { x: 140, y: 30, width: 80, height: 170, fill: FK.alpha(BK.ramp(7).c, .22) }, g);
      for (let i = 0; i < 7; i++) org(g, 'tree', 24 + (i % 3) * 38 + (i > 2 ? 18 : 0), 110 + Math.floor(i / 3) * 44, .8);
      for (let i = 0; i < 12; i++) org(g, 'grass', 236 + (i % 4) * 30, 92 + Math.floor(i / 4) * 44, 1);
      for (let i = 0; i < 4; i++) { org(g, i % 2 ? 'shrub' : 'tree', 156 + (i % 2) * 34, 100 + Math.floor(i / 2) * 52, .6); org(g, 'grass', 162 + (i % 2) * 34, 124 + Math.floor(i / 2) * 52, .8); }
      T(g, 72, 22, 'বন', { fs: 11, a: 'middle', w: 700, c: BK.ramp(10).ink }); T(g, 180, 22, 'ইকোটোন', { fs: 11, a: 'middle', w: 700, c: BK.ramp(7).ink }); T(g, 290, 22, 'তৃণভূমি', { fs: 11, a: 'middle', w: 700, c: BK.ramp(6).ink });
      const bars = [['বনের প্রজাতি', 12, 10], ['ইকোটোন', 19, 7], ['তৃণভূমির প্রজাতি', 9, 6]];
      bars.forEach(([s, v, ri], i) => { const x = 40 + i * 112, R = BK.ramp(ri); E('rect', { x, y: 230 - v * 1.2, width: 56, height: v * 1.2, rx: 3, fill: FK.alpha(R.c, .6), stroke: R.dk }, g); T(g, x + 28, 226 - v * 1.2, String(v), { fs: 9.6, a: 'middle', w: 700, c: R.ink }); T(g, x + 62, 230, s, { fs: 8.4, c: C.mu }); });
      return;
    }
    E('rect', { x: 10, y: 14, width: 150, height: 214, rx: 10, fill: FK.alpha(BK.ramp(5).c, .05), stroke: C.ln }, g);
    /* উল্লম্ব বন */
    E('path', { d: 'M10 214H160V228H10Z', fill: FK.alpha(BK.ramp(11).c, .5) }, g);
    const Rt = BK.ramp(10), Rw = BK.ramp(11);
    const tree = (x, top, rw, rh, shade) => { E('path', { d: `M${x - 2.5} 214V${top + rh * .7}H${x + 2.5}V214Z`, fill: Rw.c, stroke: Rw.dk, 'stroke-width': .6 }, g); E('ellipse', { cx: x, cy: top + rh * .45, rx: rw, ry: rh * .5, fill: FK.alpha(Rt.c, shade), stroke: Rt.dk, 'stroke-width': .8 }, g); };
    tree(44, 22, 22, 26, .95);            /* উদীয়মান */
    tree(96, 50, 30, 26, .8); tree(140, 52, 18, 24, .8);   /* চাঁদোয়া */
    tree(70, 92, 16, 20, .6); tree(124, 94, 14, 18, .6);   /* নিম্ন চাঁদোয়া */
    for (let i = 0; i < 5; i++) org(g, 'shrub', 24 + i * 30, 152, .75);   /* গুল্ম */
    for (let i = 0; i < 10; i++) org(g, 'grass', 16 + i * 14, 184, .8);   /* বীরুৎ */
    for (let i = 0; i < 3; i++) org(g, 'fungus', 40 + i * 44, 212, .55);
    LAYERS.forEach(([s, d, y, ri], i) => {
      const R = BK.ramp(ri), on = ctx.sel === i;
      E('path', { d: `M160 ${y}H184`, stroke: on ? R.dk : C.ln, 'stroke-width': on ? 2 : 1, 'stroke-dasharray': '3 2' }, g);
      E('rect', { x: 186, y: y - 12, width: 164, height: 24, rx: 7, fill: FK.alpha(R.c, on ? .28 : .1), stroke: on ? R.dk : C.ln, 'stroke-width': on ? 1.8 : 1 }, g);
      T(g, 196, y + 4, s, { fs: 10.4, w: on ? 700 : 600, c: on ? R.ink : C.fg });
    });
    ctx.H = LAYERS.map((L, i) => [268, L[2], i]);
    T(g, 268, 230, 'ওপরে আলো বেশি, নিচে কম', { fs: 9, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'eco') { const k = (t * .4) % 1; E('rect', { x: 140, y: 30, width: 80, height: 170, fill: 'none', stroke: BK.ramp(7).dk, 'stroke-width': 1.5 + k * 1.5, opacity: 1 - k * .6 }, g); return; }
    const u = (t * .25) % 1, y = 20 + u * 194; E('path', { d: `M14 ${y}H156`, stroke: BK.ramp(7).c, 'stroke-width': 3, opacity: .55 * (1 - u) }, g);
  },
  tap(x, y, ty, ctx) { if (ty !== 'str') return null; const h = hot(ctx.H || [], x, y, 90); if (!h) return null; ctx.sel = h[2]; const L = LAYERS[h[2]]; return `<b>${L[0]}</b> — ${L[1]}`; }
}));

/* ═════════ ৭. পুকুরের বাস্তুতন্ত্র ═════════ */
const POND = [
  ['অজৈব উপাদান', 'পানি, আলো, তাপমাত্রা, দ্রবীভূত O<sub>2</sub> ও CO<sub>2</sub>, খনিজ লবণ (নাইট্রেট, ফসফেট) ও তলদেশের মাটি', 180, 28, 5],
  ['উৎপাদক', 'সবুজ উদ্ভিদ ও উদ্ভিদপ্লাংকটন — ক্লোরেলা, স্পাইরোগাইরা, হাইড্রিলা, শাপলা, পাতাঝাঁঝি; সালোকসংশ্লেষণে খাদ্য তৈরি করে', 66, 118, 10],
  ['প্রাথমিক খাদক', 'প্রাণিপ্লাংকটন, শামুক, কিছু পোকার লার্ভা ও উদ্ভিদভোজী ছোট মাছ — উৎপাদককে খায়', 150, 148, 6],
  ['গৌণ খাদক', 'ছোট মাংসাশী মাছ, ব্যাঙ, জলজ পোকা — প্রাথমিক খাদককে খায়', 246, 128, 2],
  ['প্রগৌণ খাদক', 'বোয়াল, শোল জাতীয় বড় মাছ, মাছরাঙা, বক, সাপ — গৌণ খাদককে খায়', 300, 70, 4],
  ['বিয়োজক', 'তলদেশের ব্যাকটেরিয়া ও ছত্রাক — মৃতদেহ পচিয়ে খনিজ লবণ পানিতে ফিরিয়ে দেয়', 180, 214, 11]
];
V.pondEco = Object.assign({}, B.seg({
  id: 'pnd', t: 'পুকুরের বাস্তুতন্ত্র', H: 250, def: 'all', sel: null,
  cap: 'বাস্তুতন্ত্র (ইকোসিস্টেম) — কোনো নির্দিষ্ট এলাকার জীব সম্প্রদায় ও তার অজৈব পরিবেশ মিলে যে স্বনির্ভর কার্যকরী একক গড়ে ওঠে, যেখানে শক্তি প্রবাহিত হয় ও পুষ্টি চক্রাকারে ঘোরে। শব্দটি এ জি ট্যান্সলির (1935)। পুকুর একটি আদর্শ উদাহরণ — যেকোনো উপাদানে চাপ দাও।',
  types: { all: ['উপাদান', 'পুকুরের উপাদানসমূহ', 'দুটি প্রধান অংশ — অজৈব (জড়) ও জৈব (উৎপাদক, খাদক, বিয়োজক)।'] },
  art(g, C, ty, ctx) {
    const R5 = BK.ramp(5), R11 = BK.ramp(11);
    E('path', { d: 'M8 66Q40 60 60 64H300Q330 60 352 66L340 200Q300 226 180 226Q60 226 20 200Z', fill: FK.alpha(R5.c, .2), stroke: R5.dk, 'stroke-width': 1.2 }, g);
    E('path', { d: 'M20 200Q60 226 180 226Q300 226 340 200L336 214Q300 238 180 238Q60 238 24 214Z', fill: FK.alpha(R11.c, .45) }, g);
    E('circle', { cx: 330, cy: 24, r: 12, fill: BK.ramp(7).c, opacity: .8 }, g);
    for (let i = 0; i < 4; i++) E('path', { d: `M${318 - i * 18} ${32 + i * 2}l${-10} ${22}`, stroke: BK.ramp(7).c, 'stroke-width': 1.4, opacity: .6 }, g);
    /* উদ্ভিদ */
    for (let i = 0; i < 4; i++) E('path', { d: `M${40 + i * 14} 214q${-6} -30 0 -60q6 -20 0 -40`, stroke: BK.ramp(10).dk, 'stroke-width': 1.6, fill: 'none' }, g);
    E('ellipse', { cx: 104, cy: 66, rx: 16, ry: 4, fill: BK.ramp(10).c }, g); E('path', { d: 'M104 66V214', stroke: BK.ramp(10).dk, 'stroke-width': 1 }, g);
    org(g, 'plank', 150, 100, 1.2); org(g, 'zoo', 140, 152, 1.2); org(g, 'zoo', 160, 146, 1); org(g, 'fish', 246, 134, 1.4); org(g, 'frog', 210, 68, 1); org(g, 'bigfish', 286, 182, 1.4); org(g, 'bird', 300, 42, 1);
    org(g, 'fungus', 120, 222, .7); for (let i = 0; i < 6; i++) E('circle', { cx: 160 + i * 10, cy: 220, r: 1.5, fill: R11.dk }, g);
    POND.forEach(([s, , x, y, ri], i) => { const R = BK.ramp(ri), on = ctx.sel === i; chip(g, x, y, s, R, { w: s.length * 7.2 + 14, h: 18, fs: 9.6, fill: FK.alpha(R.c, on ? .45 : .2) }); });
    ctx.H = POND.map((p, i) => [p[2], p[3], i]);
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    const k = (t * .35) % 1, path = [[66, 118], [150, 148], [246, 128], [300, 70], [180, 214], [66, 118]], seg = Math.floor(k * 5), u = k * 5 - seg;
    const [a, b] = [path[seg], path[seg + 1]], x = a[0] + (b[0] - a[0]) * u, y = a[1] + (b[1] - a[1]) * u;
    E('circle', { cx: x, cy: y, r: 4.5, fill: BK.ramp(seg === 3 ? 11 : 7).c, stroke: C.sf, 'stroke-width': 1 }, g);
  },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 44); if (!h) return null; ctx.sel = h[2]; const p = POND[h[2]]; return `<b>${p[0]}</b> — ${p[1]}`; }
}));

/* ═════════ ৮. খাদ্যজাল ═════════ */
const FW = { grass: ['ঘাস', 'grass', 60, 210, 0], grh: ['ফড়িং', 'insect', 40, 150, 1], rab: ['খরগোশ', 'rabbit', 140, 160, 1], der: ['হরিণ', 'deer', 270, 170, 1], frg: ['ব্যাঙ', 'frog', 50, 96, 2], brd: ['পাখি', 'bird', 130, 92, 2], snk: ['সাপ', 'snake', 90, 44, 3], hwk: ['বাজপাখি', 'hawk', 200, 34, 3], tgr: ['বাঘ', 'tiger', 290, 92, 3] };
const FE = [['grass', 'grh'], ['grass', 'rab'], ['grass', 'der'], ['grh', 'frg'], ['grh', 'brd'], ['frg', 'snk'], ['rab', 'snk'], ['rab', 'hwk'], ['brd', 'hwk'], ['snk', 'hwk'], ['der', 'tgr']];
V.foodWeb = Object.assign({}, B.seg({
  id: 'fwb', t: 'খাদ্যশৃঙ্খল ও খাদ্যজাল', H: 252, def: 'web', sel: null,
  cap: 'খাদ্যশৃঙ্খল — উৎপাদক থেকে শুরু করে একের পর এক খাদ্য-খাদক সম্পর্কের মাধ্যমে শক্তি স্থানান্তরের একমুখী ধারা। প্রকৃতিতে একটি প্রাণী একাধিক প্রাণীকে খায় ও একাধিক প্রাণীর খাদ্য হয় — ফলে শৃঙ্খলগুলো জড়িয়ে খাদ্যজাল তৈরি হয়। তিরের দিক = শক্তির দিক (খাদ্য থেকে খাদকের দিকে)। যেকোনো জীবে চাপ দাও।',
  types: {
    web: ['খাদ্যজাল', 'তৃণভূমির খাদ্যজাল', 'জীবে চাপ দিলে সে কী খায় ও কে তাকে খায় তা আলোকিত হবে।'],
    chain: ['একটি শৃঙ্খল', 'একটি খাদ্যশৃঙ্খল', 'ঘাস → ফড়িং → ব্যাঙ → সাপ → বাজপাখি — পাঁচটি পুষ্টিস্তর। শৃঙ্খলে সাধারণত ৪–৫টির বেশি ধাপ থাকে না, কারণ প্রতি ধাপে শক্তি প্রায় 90% কমে যায়।']
  },
  art(g, C, ty, ctx) {
    const chainOnly = ty === 'chain', CH = ['grass', 'grh', 'frg', 'snk', 'hwk'];
    const sel = ctx.sel, rel = new Set(); if (sel) FE.forEach(([a, b]) => { if (a === sel || b === sel) { rel.add(a + b); } });
    FE.forEach(([a, b]) => {
      const A = FW[a], Bn = FW[b], inC = chainOnly && CH.indexOf(a) >= 0 && CH.indexOf(b) === CH.indexOf(a) + 1, hi = rel.has(a + b) || inC;
      if (chainOnly && !inC) { arrow(g, A[2], A[3] - 14, Bn[2], Bn[3] + 10, C.ln, { w: 1, op: .35, h: 4 }); return; }
      arrow(g, A[2], A[3] - 14, Bn[2], Bn[3] + 10, hi ? BK.ramp(TR[Bn[4]]).dk : C.mu, { w: hi ? 2.2 : 1.2, op: sel && !hi ? .25 : .9, h: 5 });
    });
    Object.keys(FW).forEach(k => {
      const [s, kind, x, y, lv] = FW[k], R = BK.ramp(TR[lv]), on = sel === k, dim = (sel && !on && ![...rel].some(e => e.indexOf(k) >= 0)) || (chainOnly && CH.indexOf(k) < 0);
      E('circle', { cx: x, cy: y - 6, r: 20, fill: FK.alpha(R.c, on ? .35 : .14), stroke: on ? R.dk : FK.alpha(R.dk, .6), 'stroke-width': on ? 2 : 1, opacity: dim ? .35 : 1 }, g);
      org(g, kind, x, y + 2, kind === 'tiger' || kind === 'deer' ? .7 : .85, { op: dim ? .3 : 1 });
      T(g, x, y + 26, s, { fs: 9.6, a: 'middle', w: 650, c: dim ? C.mu : R.ink });
    });
    [['উৎপাদক', 10], ['প্রাথমিক', 6], ['গৌণ', 2], ['প্রগৌণ / শীর্ষ', 4]].forEach(([s, ri], i) => chip(g, 330, 140 + i * 24, s, BK.ramp(ri), { w: 52, h: 16, fs: 8 }));
    ctx.H = Object.keys(FW).map(k => [FW[k][2], FW[k][3] - 6, k]);
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return;
    const ed = ty === 'chain' ? [['grass', 'grh'], ['grh', 'frg'], ['frg', 'snk'], ['snk', 'hwk']] : FE, i = Math.floor(t * 1.2) % ed.length, u = (t * 1.2) % 1, [a, b] = ed[i];
    const A = FW[a], Bn = FW[b], x = A[2] + (Bn[2] - A[2]) * u, y = A[3] - 14 + (Bn[3] + 10 - A[3] + 14) * u;
    E('circle', { cx: x, cy: y, r: 4, fill: BK.ramp(7).c, stroke: BK.ramp(7).dk, 'stroke-width': .8 }, g);
  },
  tap(x, y, ty, ctx) {
    const h = hot(ctx.H || [], x, y, 26); if (!h) return null; ctx.sel = ctx.sel === h[2] ? null : h[2]; if (!ctx.sel) return ctx.def();
    const k = h[2], eats = FE.filter(e => e[1] === k).map(e => FW[e[0]][0]), eaten = FE.filter(e => e[0] === k).map(e => FW[e[1]][0]);
    const lv = ['উৎপাদক', 'প্রাথমিক খাদক (তৃণভোজী)', 'গৌণ খাদক', 'প্রগৌণ বা শীর্ষ খাদক'][FW[k][4]];
    return `<b>${FW[k][0]}</b> — ${lv}।<div class="small">খায়: ${eats.length ? eats.join(', ') : 'সূর্যালোক থেকে নিজেই খাদ্য তৈরি করে'} · খাদ্য হয়: ${eaten.length ? eaten.join(', ') : 'কারও নয় (শীর্ষ খাদক); মৃত্যুর পর বিয়োজকের'}</div>`;
  }
}));

/* ═════════ ৯. বাস্তুতান্ত্রিক পিরামিড ═════════ */
const PYR = {
  ng: ['সংখ্যার পিরামিড — তৃণভূমি', 'সোজা', [[1500000, 'ঘাস'], [200000, 'তৃণভোজী পোকা'], [90000, 'মাকড়সা, পাখি'], [1, 'বাজপাখি']], 'উৎপাদক সংখ্যায় সবচেয়ে বেশি, শীর্ষ খাদক সবচেয়ে কম — পিরামিড সোজা। (এক একর ঘাসজমি, ওডাম — প্রতি 0.1 একরে)'],
  nt: ['সংখ্যার পিরামিড — একটি বড় গাছ', 'উল্টো (আংশিক)', [[1, 'একটি বটগাছ'], [5000, 'পাতাখেকো পোকা'], [300, 'পাখি'], [20000, 'পাখির উকুন (পরজীবী)']], 'একটি বড় গাছে হাজার হাজার পোকা নির্ভর করে — তাই নিচের স্তর ছোট; পরজীবী শৃঙ্খলে ওপরের স্তর আবার বড় হয়ে পিরামিড উল্টো হয়ে যায়। (সংখ্যাগুলো উদাহরণমূলক)'],
  bl: ['জীবভরের পিরামিড — সোজা', 'সোজা', [[809, 'উৎপাদক'], [37, 'প্রাথমিক খাদক'], [11, 'গৌণ খাদক'], [1.5, 'প্রগৌণ খাদক']], 'অধিকাংশ স্থলজ বাস্তুতন্ত্র ও অনেক জলাশয়ে উৎপাদকের মোট শুষ্ক ভর সবচেয়ে বেশি — পিরামিড সোজা। (সিলভার স্প্রিংস, ফ্লোরিডা — g/m<sup>2</sup>, ওডাম 1957)'],
  bo: ['জীবভরের পিরামিড — সমুদ্র', 'উল্টো', [[4, 'উদ্ভিদপ্লাংকটন'], [21, 'প্রাণিপ্লাংকটন ও তলদেশের প্রাণী']], 'উদ্ভিদপ্লাংকটন খুব দ্রুত জন্মায় ও খাদ্য হয়, তাই কোনো মুহূর্তে এদের মোট ভর (স্থায়ী শস্য) খাদকের চেয়ে কম — পিরামিড উল্টো। (ইংলিশ চ্যানেলের উপাত্ত, g/m<sup>2</sup>)'],
  en: ['শক্তির পিরামিড', 'সর্বদা সোজা', [[20810, 'উৎপাদক'], [3368, 'তৃণভোজী'], [383, 'মাংসাশী'], [21, 'শীর্ষ মাংসাশী']], 'প্রতি ধাপে শক্তির বড় অংশ শ্বসনে তাপ হয়ে হারায়, তাই শক্তির পিরামিড কখনো উল্টো হয় না। (সিলভার স্প্রিংস, ফ্লোরিডা — kcal/m<sup>2</sup>/বছর, ওডাম 1957)']
};
V.ecoPyramid = Object.assign({}, B.seg({
  id: 'pyr', t: 'বাস্তুতান্ত্রিক পিরামিড', H: 252, def: 'ng', sel: null,
  cap: 'বাস্তুতান্ত্রিক পিরামিড — খাদ্যশৃঙ্খলের পুষ্টিস্তরগুলোতে জীবের সংখ্যা, জীবভর বা শক্তির পরিমাণ নিচ থেকে ওপরে সাজালে যে চিত্র পাওয়া যায়। চার্লস এলটন (1927) প্রথম এ ধারণা দেন, তাই একে এলটনীয় পিরামিডও বলে। তিন প্রকার: সংখ্যার, জীবভরের ও শক্তির পিরামিড।',
  types: { ng: ['সংখ্যা (সোজা)', ...PYR.ng.slice(0, 1), PYR.ng[3]], nt: ['সংখ্যা (উল্টো)', PYR.nt[0], PYR.nt[3]], bl: ['জীবভর (সোজা)', PYR.bl[0], PYR.bl[3]], bo: ['জীবভর (উল্টো)', PYR.bo[0], PYR.bo[3]], en: ['শক্তি', PYR.en[0], PYR.en[3]] },
  art(g, C, ty, ctx) {
    const P = PYR[ty], L = P[2], mx = Math.max(...L.map(l => l[0]));
    const H = 38, base = 210, cx = 170;
    L.forEach(([v, s], i) => {
      const w = ty === 'nt' || ty === 'bo' ? 40 + 240 * (v / mx) : 40 + 240 * Math.pow(v / mx, .32), y = base - (i + 1) * H, R = BK.ramp(TR[Math.min(i, 3)]), on = ctx.sel === i;
      E('rect', { x: cx - w / 2, y, width: w, height: H - 4, rx: 4, fill: FK.alpha(R.c, on ? .7 : .45), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      T(g, cx, y + 16, s, { fs: 10, a: 'middle', w: 700, c: R.ink });
      T(g, cx, y + 29, v.toLocaleString('en-IN'), { fs: 9, a: 'middle', c: C.fg });
    });
    T(g, 344, 30, P[1], { fs: 11, a: 'end', w: 700, c: P[1].indexOf('উল্টো') >= 0 ? BK.ramp(4).ink : BK.ramp(10).ink });
    T(g, 180, 234, ty === 'nt' || ty === 'bo' ? 'প্রস্থ সংখ্যার সমানুপাতিক' : 'প্রস্থ লগারিদম-জাতীয় মাপে — নইলে ওপরের স্তর দেখাই যেত না', { fs: 8.6, a: 'middle', c: C.mu });
    ctx.H = L.map((_, i) => [cx, base - (i + 1) * H + 17, i]);
  },
  anim(g, C, ty, t) { if (!t) return; const n = PYR[ty][2].length, i = Math.floor(t * .8) % n; E('path', { d: `M30 ${210 - (i + 1) * 38 + 17}h14`, stroke: BK.ramp(7).dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, g); arrow(g, 30, 210 - (i + 1) * 38 + 17, 50, 210 - (i + 1) * 38 + 17, BK.ramp(7).dk, { w: 2 }); },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 140); if (!h) return null; ctx.sel = h[2]; const L = PYR[ty][2], [v, s] = L[h[2]]; const nx = L[h[2] + 1]; return `<b>${s}: ${v.toLocaleString('en-IN')}</b>${nx ? `<div class="small">পরের স্তর / এই স্তর = ${FK.n(nx[0] / v * 100, 1)}%</div>` : ''}`; }
}));

/* ═════════ ১০. শক্তি প্রবাহ — 10% সূত্র ═════════ */
V.energyFlow = Object.assign({}, B.seg({
  id: 'enf', t: 'শক্তি প্রবাহ ও 10% সূত্র', H: 254, def: 'f',
  cap: 'বাস্তুতন্ত্রে শক্তি সূর্য থেকে উৎপাদকে, তারপর ধাপে ধাপে খাদকে যায় — এ প্রবাহ একমুখী, কখনো ফিরে আসে না। লিন্ডেম্যানের (1942) 10% সূত্র অনুযায়ী এক পুষ্টিস্তর থেকে পরের স্তরে গড়ে মাত্র প্রায় 10% শক্তি জমা হয়; বাকি শ্বসনে তাপ হিসেবে, অপাচ্য অংশ ও মৃতদেহ হয়ে বিয়োজকের কাছে চলে যায়। স্থানান্তরের হার ও উৎপাদকের শক্তি বদলে দেখো।',
  sl: [{ k: 'E0', l: 'উৎপাদক kJ', min: 1000, max: 20000, step: 1000, val: 10000 }, { k: 'p', l: 'হার %', min: 5, max: 20, step: 1, val: 10 }],
  types: { f: ['প্রবাহ', 'পুষ্টিস্তরে শক্তি', 'বাস্তবে স্থানান্তর হার প্রায় 5 থেকে 20% এর মধ্যে থাকে; 10% একটি গড় নিয়ম।'] },
  art(g, C, ty, ctx) {
    const E0 = +ctx.v.E0, p = +ctx.v.p / 100, names = ['উৎপাদক', 'প্রাথমিক খাদক', 'গৌণ খাদক', 'প্রগৌণ খাদক'];
    E('circle', { cx: 30, cy: 34, r: 14, fill: BK.ramp(7).c, opacity: .85 }, g); T(g, 30, 64, 'সূর্য', { fs: 9.6, a: 'middle', c: C.mu });
    names.forEach((s, i) => {
      const e = E0 * Math.pow(p, i), x = 74 + i * 72, R = BK.ramp(TR[i]), bh = Math.max(3, 120 * Math.pow(e / E0, .35));
      E('rect', { x: x - 26, y: 160 - bh, width: 52, height: bh, rx: 4, fill: FK.alpha(R.c, .55), stroke: R.dk }, g);
      T(g, x, 154 - bh, FK.n(e, e < 10 ? 1 : 0), { fs: 10, a: 'middle', w: 700, c: R.ink });
      T(g, x, 176, s, { fs: 9, a: 'middle', w: 650, c: R.ink });
      if (i < 3) { arrow(g, x + 28, 120, x + 44, 120, C.fg, { w: 1.6, h: 5 }); T(g, x + 36, 112, Math.round(p * 100) + '%', { fs: 8.4, a: 'middle', c: C.fg }); }
      arrow(g, x, 182, x, 204, BK.ramp(4).c, { w: 1.4, h: 4, dash: '3 2' });
      if (i === 0) arrow(g, 40, 44, 52, 80, BK.ramp(7).dk, { w: 1.6 });
    });
    T(g, 180, 222, 'নিচের তির — শ্বসনে তাপ ও বিয়োজকে যাওয়া শক্তি (প্রায় 90%)', { fs: 9.2, a: 'middle', c: BK.ramp(4).ink });
    const top = E0 * Math.pow(p, 3);
    T(g, 180, 242, `উৎপাদকের ${E0.toLocaleString('en-IN')} kJ এর মাত্র ${FK.n(top / E0 * 100, 2)}% প্রগৌণ খাদকে পৌঁছায়`, { fs: 9.8, a: 'middle', w: 650, c: C.fg });
  },
  anim(g, C, ty, t) { if (!t) return; const u = (t * .45) % 1, x = 52 + u * 232; E('circle', { cx: x, cy: 120, r: 6 * (1 - u * .8) + 1.5, fill: BK.ramp(7).c, stroke: BK.ramp(7).dk, 'stroke-width': .8 }, g); }
}));

/* ═════════ ১১. জৈব বিবর্ধন ═════════ */
const MAG = [['পানি', .000003, 5, 'grass'], ['প্রাণিপ্লাংকটন', .04, 6, 'zoo'], ['ছোট মাছ', .5, 2, 'fish'], ['বড় মাছ', 2, 4, 'bigfish'], ['মাছখেকো পাখি', 25, 4, 'bird']];
V.bioMag = Object.assign({}, B.seg({
  id: 'bmg', t: 'জৈব বিবর্ধন (বায়োলজিক্যাল ম্যাগনিফিকেশন)', H: 254, def: 'ddt', sel: null,
  cap: 'জৈব বিবর্ধন — খাদ্যশৃঙ্খলের প্রতি ধাপে কোনো অপচনশীল বিষাক্ত পদার্থের ঘনত্ব ক্রমশ বেড়ে যাওয়া। যেসব পদার্থ চর্বিতে দ্রবণীয়, বিপাকে ভাঙে না ও মলমূত্রে বের হয় না (DDT, পারদ, PCB) সেগুলো দেহে জমতে থাকে, আর প্রতিটি খাদক বহু খাদ্য খায় বলে ওপরের স্তরে ঘনত্ব বহুগুণ হয়। উপাত্ত — যুক্তরাষ্ট্রের লং আইল্যান্ড মোহনা (উডওয়েল ও সহকর্মী, 1967), ppm এককে।',
  types: { ddt: ['DDT', 'DDT এর ঘনত্ব বৃদ্ধি', 'পানির তুলনায় মাছখেকো পাখিতে DDT এর ঘনত্ব প্রায় 80 লক্ষ গুণ। এর ফলে ঈগল, অসপ্রে ও পেরেগ্রিন বাজের ডিমের খোসা পাতলা হয়ে ভেঙে যেত, প্রজনন কমে যায়।'] },
  art(g, C, ty, ctx) {
    const lg = v => (Math.log10(v) + 6) / (Math.log10(25) + 6);
    MAG.forEach(([s, v, ri, kind], i) => {
      const x = 40 + i * 70, R = BK.ramp(ri), h = 14 + lg(v) * 120, on = ctx.sel === i;
      E('rect', { x: x - 22, y: 176 - h, width: 44, height: h, rx: 5, fill: FK.alpha(R.c, on ? .7 : .45), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      for (let d = 0; d < Math.min(30, Math.round(lg(v) * 30)); d++) E('circle', { cx: x - 16 + (d % 5) * 8, cy: 172 - Math.floor(d / 5) * 8, r: 2, fill: BK.ramp(3).dk, opacity: .8 }, g);
      T(g, x, 168 - h, v < .001 ? '0.000003' : String(v), { fs: 9.6, a: 'middle', w: 700, c: R.ink });
      if (i) org(g, kind, x, 206, .9); else E('path', { d: `M${x - 18} 200q9 -6 18 0t18 0`, stroke: BK.ramp(5).dk, 'stroke-width': 1.6, fill: 'none' }, g);
      T(g, x, 226, s, { fs: 9, a: 'middle', w: 650, c: C.fg });
      if (i < 4) arrow(g, x + 24, 120, x + 46, 120, C.mu, { w: 1.2, h: 4 });
    });
    T(g, 180, 20, 'বেগুনি বিন্দু = DDT · দণ্ড লগারিদম-মাপে', { fs: 9.2, a: 'middle', c: C.mu });
    T(g, 180, 246, 'বিবর্ধন গুণক = 25 ÷ 0.000003 ≈ 8.3 × 10<tspan baseline-shift="super" font-size="7">6</tspan>', { fs: 10, a: 'middle', w: 650, c: BK.ramp(4).ink });
    ctx.H = MAG.map((_, i) => [40 + i * 70, 140, i]);
  },
  anim(g, C, ty, t) { if (!t) return; const i = Math.floor(t * .9) % 4, u = (t * .9) % 1, x = 64 + i * 70 + u * 22; E('circle', { cx: x, cy: 120, r: 3 + i, fill: BK.ramp(3).c, opacity: .85 }, g); },
  tap(x, y, ty, ctx) { const h = hot(ctx.H || [], x, y, 36); if (!h) return null; ctx.sel = h[2]; const [s, v] = MAG[h[2]], pv = h[2] ? MAG[h[2] - 1][1] : null; return `<b>${s}: ${v < .001 ? '0.000003' : v} ppm</b>${pv ? `<div class="small">আগের ধাপের তুলনায় প্রায় ${FK.n(v / pv, 0)} গুণ</div>` : '<div class="small">প্রায় অদৃশ্য পরিমাণ — তবু শৃঙ্খলের শুরু এখান থেকেই।</div>'}`; }
}));

/* ═════════ তুলনা ═════════ */
V.cmpPyrNumEnergy = cmp('সংখ্যার পিরামিড বনাম শক্তির পিরামিড', 'দুটিই পুষ্টিস্তর সাজিয়ে আঁকা, কিন্তু একটি উল্টো হতে পারে, অন্যটি পারে না।', 'সংখ্যার পিরামিড', 'শক্তির পিরামিড', [
  ['মাপা হয়', 'প্রতি স্তরে জীবের সংখ্যা', 'প্রতি স্তরে শক্তির পরিমাণ (kJ/m<sup>2</sup>/বছর)'],
  ['আকৃতি', 'সোজা, উল্টো বা মাকুর মতো হতে পারে', 'সর্বদা সোজা'],
  ['উল্টো হওয়ার উদাহরণ', 'একটি বড় গাছে বহু পোকা; পরজীবী শৃঙ্খল', 'কখনো উল্টো হয় না'],
  ['জীবের আকার', 'বিবেচনা করা হয় না — একটি গাছ ও একটি ঘাস সমান', 'আকার নয়, শক্তির প্রকৃত পরিমাণ গোনা হয়'],
  ['সময়', 'একটি নির্দিষ্ট মুহূর্তের চিত্র', 'নির্দিষ্ট সময়ে (সাধারণত এক বছরে) প্রবাহিত শক্তি'],
  ['নির্ভরযোগ্যতা', 'সবচেয়ে কম তথ্যবহুল', 'বাস্তুতন্ত্রের কার্যকারিতার সবচেয়ে সঠিক চিত্র']
]);
V.cmpChainWeb = cmp('খাদ্যশৃঙ্খল বনাম খাদ্যজাল', 'একটি সরল রেখা, অন্যটি জড়ানো জাল।', 'খাদ্যশৃঙ্খল', 'খাদ্যজাল', [
  ['গঠন', 'একটিমাত্র সরল ধারা', 'বহু শৃঙ্খল পরস্পর জড়িয়ে তৈরি জাল'],
  ['খাদ্যের বিকল্প', 'প্রতিটি খাদকের একটিমাত্র খাদ্য দেখানো হয়', 'একটি খাদকের একাধিক খাদ্য থাকে'],
  ['স্থিতিশীলতা', 'একটি জীব হারালে পুরো শৃঙ্খল ভেঙে পড়ে', 'বিকল্প পথ থাকায় বাস্তুতন্ত্র বেশি স্থিতিশীল'],
  ['বাস্তবতা', 'প্রকৃতির সরলীকৃত রূপ', 'প্রকৃতির বাস্তব চিত্রের কাছাকাছি'],
  ['উদাহরণ', 'ঘাস → ফড়িং → ব্যাঙ → সাপ → বাজপাখি', 'তৃণভূমিতে ঘাস-ফড়িং-খরগোশ-ব্যাঙ-সাপ-বাজপাখির পারস্পরিক সম্পর্ক']
]);
V.cmpGrazDet = cmp('চারণ খাদ্যশৃঙ্খল বনাম মৃতজীবী খাদ্যশৃঙ্খল', 'শৃঙ্খল শুরু হয় জীবিত উৎপাদক থেকে, নাকি মৃত জৈব পদার্থ থেকে।', 'চারণ (গ্রেজিং) শৃঙ্খল', 'মৃতজীবী (ডেট্রিটাস) শৃঙ্খল', [
  ['শুরু', 'জীবিত সবুজ উদ্ভিদ', 'মৃত জৈব পদার্থ (ঝরা পাতা, মৃতদেহ, মল)'],
  ['প্রথম খাদক', 'তৃণভোজী প্রাণী', 'ডেট্রিটাসভোজী — কেঁচো, উইপোকা, কাঁকড়া, ব্যাকটেরিয়া, ছত্রাক'],
  ['শক্তির উৎস', 'সরাসরি সূর্যালোক থেকে তৈরি খাদ্য', 'আগে তৈরি হওয়া জৈব পদার্থে সঞ্চিত শক্তি'],
  ['প্রাধান্য', 'জলাশয় ও তৃণভূমিতে বেশি', 'বন ও ম্যানগ্রোভে বেশি — সুন্দরবনে ঝরা পাতাই প্রধান খাদ্য-উৎস'],
  ['উদাহরণ', 'ঘাস → হরিণ → বাঘ', 'ঝরা পাতা → কাঁকড়া → ছোট মাছ → বড় মাছ']
]);
})();
