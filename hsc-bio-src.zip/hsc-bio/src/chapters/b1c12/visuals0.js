/* ═══════════════════════════════════════════════════════════════════
   visuals0 — অধ্যায় ১২ (জীবের পরিবেশ, বিস্তার ও সংরক্ষণ) এর সহায়ক B12
   (অধ্যায় ১১ এর B11 থেকে অনুলিপি — প্রতিটি অধ্যায় নিজস্ব সহায়ক রাখে, যাতে আলাদা করে লোড হলেও চলে)
   seg, gseg, ch / chH, axes, curve, area, along, poly, ion, dot, blob, lab, chip, mem, node, hot, dna, flask, dish
   + GEO: বাংলাদেশের সরলীকৃত সীমারেখা (world-atlas 50m, Natural Earth) ও বিশ্বের স্থলভাগ (110m)
     bdXY(lon, lat) → বাংলাদেশ মানচিত্রে বিন্দু (প্রস্থ 300); wXY(lon, lat) → বিশ্ব মানচিত্রে বিন্দু (340 × 150)
   রঙের নিয়ম (পুরো অধ্যায়ে এক): উৎপাদক / উদ্ভিদ = ১০ সবুজ, প্রাথমিক খাদক = ৬ অ্যাম্বার, গৌণ খাদক = ২ কমলা,
   প্রগৌণ / শীর্ষ খাদক = ৪ লাল, বিয়োজক = ১১ বাদামি, পানি = ৫ আকাশি, লবণ = ৯ ধূসর, শক্তি = ৭ হলুদ-সবুজ,
   হুমকির মাত্রা: CR ৪, EN ২, VU ৬, NT ৭, LC ১০
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B12 = window.B12 = {};
const PI = Math.PI;
const bn = B12.bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const rnd = B12.rnd = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
B12.cl = cl;

/* রাসায়নিক সংকেত */
const tok = s => { const out = [], re = /_\{([^}]*)\}|_(\d+)|\^\{([^}]*)\}|\^(\d*[+\-−])/g; let i = 0, m; while ((m = re.exec(s))) { if (m.index > i) out.push([s.slice(i, m.index), 0]); if (m[1] != null || m[2] != null) out.push([m[1] != null ? m[1] : m[2], 1]); else out.push([(m[3] != null ? m[3] : m[4]).replace('-', '−'), 2]); i = re.lastIndex; } if (i < s.length) out.push([s.slice(i), 0]); return out; };
B12.ch = s => { let off = 0; return tok(s).map(([t, l]) => { const o = l === 1 ? 3.5 : l === 2 ? -5 : 0, dy = o - off; off = o; return `<tspan dy="${dy}"${l ? ' font-size="72%"' : ''}>${t}</tspan>`; }).join(''); };
B12.chH = s => tok(s).map(([t, l]) => l === 1 ? `<sub>${t}</sub>` : l === 2 ? `<sup>${t}</sup>` : t).join('');
const ch = B12.ch, chH = B12.chH;

/* ধরন বদলানো চিত্র
   o: { id, t, k?, cap, W?, H? (সংখ্যা বা ty→সংখ্যা), types:{key:[বোতাম, শিরোনাম, বর্ণনা, নোট?]}, def,
        sl?:[{k,l,min,max,step,val,unit,d}], art(g,C,ty,ctx), anim?(g,C,ty,t,ctx), tap?(x,y,ty,ctx)→html, more?(ty,ctx)→html } */
B12.seg = o => ({
  t: o.t, k: o.k || ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `${Object.keys(o.types).length > 1 ? `<div class="fk-row">${X.seg(o.id, Object.keys(o.types).map(k => [k, o.types[k][0]]), o.def)}</div>` : ''}<div class="fk-stage bk-stage" data-k="st"></div>${(o.sl || []).map(s => `<div class="fk-row">${FK.sl(s.k, s.l, s.min, s.max, s.step, s.val, s.unit || '')}</div>`).join('')}<div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = o.W || 360;
    let ty = o.def, C, svg, ga, gd, tt = 0;
    const ctx = { root, v: {}, sel: o.sel != null ? o.sel : null };
    (o.sl || []).forEach(s => { ctx.v[s.k] = s.val; });
    const defInfo = () => { const a = o.types[ty]; return `<b>${a[1] || a[0]}</b> — ${a[2]}${a[3] ? `<div class="small">${a[3]}</div>` : ''}${o.more ? o.more(ty, ctx) || '' : ''}`; };
    const info = h => { $('info').innerHTML = h; };
    const frame = () => { gd.innerHTML = ''; if (o.anim) o.anim(gd, C, ty, tt, ctx); };
    const redraw = () => { ga.innerHTML = ''; o.art(ga, C, ty, ctx); frame(); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const h = typeof o.H === 'function' ? o.H(ty) : (o.H || 260);
      svg = E('svg', { viewBox: `0 0 ${W} ${h}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.types[ty][1] || o.types[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: h, rx: 12, fill: C.sf }, svg);
      ga = E('g', {}, svg); gd = E('g', { style: 'pointer-events:none' }, svg); ctx.svg = svg; ctx.C = C;
      redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo());
    };
    ctx.info = info; ctx.redraw = redraw; ctx.def = defInfo;
    root.addEventListener('click', e => {
      if (!o.tap || !svg || !svg.contains(e.target)) return;
      const m = svg.getScreenCTM(); if (!m) return; const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const q = p.matrixTransform(m.inverse());
      const h = o.tap(q.x, q.y, ty, ctx); if (h) info(h); redraw();
    });
    (o.sl || []).forEach(s => FK.bindSl(root, s.k, v => { ctx.v[s.k] = v; redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo()); }, s.unit || '', s.d != null ? s.d : 0));
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, o.id, v => { ty = v; tt = 0; ctx.sel = o.sel != null ? o.sel : null; ctx.selInfo = null; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* অক্ষ: b = [x, y, w, h]; o = { xr, yr, lx, ly, xt, yt, xf } → P(u, v) */
B12.axes = (g, C, b, o) => {
  const [x, y, w, h] = b, xr = o.xr, yr = o.yr, P = (u, v) => [x + (u - xr[0]) / (xr[1] - xr[0]) * w, y + h - (v - yr[0]) / (yr[1] - yr[0]) * h];
  (o.yt || []).forEach(t => { const [, py] = P(xr[0], t); E('path', { d: `M${x} ${py}H${x + w}`, stroke: C.ln, 'stroke-width': .6, opacity: .45 }, g); T(g, x - 5, py + 3.5, o.yf ? o.yf(t) : String(t), { fs: 9.5, a: 'end', c: C.mu }); });
  (o.xt || []).forEach(t => { const [px] = P(t, yr[0]); E('path', { d: `M${px} ${y + h}v4`, stroke: C.mu, 'stroke-width': 1 }, g); T(g, px, y + h + 14, o.xf ? o.xf(t) : String(t), { fs: 9.5, a: 'middle', c: C.mu }); });
  E('path', { d: `M${x} ${y - 6}V${y + h}H${x + w + 6}`, stroke: C.fg, 'stroke-width': 1.3, fill: 'none' }, g);
  E('path', { d: `M${x} ${y - 10}l-3.5 7h7z`, fill: C.fg }, g); E('path', { d: `M${x + w + 10} ${y + h}l-7 -3.5v7z`, fill: C.fg }, g);
  if (o.lx) T(g, x + w + 8, y + h + 28, o.lx, { fs: 10.5, a: 'end', c: C.mu });
  if (o.ly) T(g, x + 6, y - 4, o.ly, { fs: 10.5, c: C.mu });
  return P;
};
B12.curve = (g, P, f, a, b, at, n = 64) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } return E('path', Object.assign({ d, fill: 'none', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, at), g); };
B12.area = (g, P, f, a, b, y0, at, n = 48) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } const [xb] = P(b, y0), [xa, ya] = P(a, y0); d += `L${xb} ${ya}L${xa} ${ya}Z`; return E('path', Object.assign({ d, stroke: 'none' }, at), g); };
/* রেখা বরাবর u (০→১) অবস্থানের বিন্দু */
B12.along = (pts, u) => {
  let L = 0; const sg = [];
  for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); sg.push(l); L += l; }
  let d = (((u % 1) + 1) % 1) * L;
  for (let i = 0; i < sg.length; i++) { if (d <= sg[i]) { const k = sg[i] ? d / sg[i] : 0; return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k]; } d -= sg[i]; }
  return pts[pts.length - 1];
};
B12.poly = (g, pts, at) => E('path', Object.assign({ d: pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(''), fill: 'none' }, at), g);
/* আয়ন বা অণুর বল */
B12.ion = (g, x, y, s, R, r = 10, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.lt, stroke: R.dk, 'stroke-width': 1.1, opacity: o.op != null ? o.op : 1 }, g); T(g, x, y + 3.2, ch(s), { fs: o.fs || 8.5, a: 'middle', w: 650, c: R.ink }); };
B12.dot = (g, x, y, r, c, op = 1) => E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r, fill: c, opacity: op }, g);
B12.blob = (g, x, y, r, o = {}) => {
  const n = o.n || 7, sd = o.seed || 1; let d = '';
  for (let i = 0; i <= n; i++) { const a = i / n * PI * 2 + (o.rot || 0), rr = r * (1 + (rnd(sd * 31 + (i % n)) - .5) * (o.j != null ? o.j : .16)); d += (i ? 'L' : 'M') + (x + rr * Math.cos(a)).toFixed(1) + ' ' + (y + rr * Math.sin(a)).toFixed(1); }
  return E('path', { d: d + 'Z', fill: o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || 1, 'stroke-linejoin': 'round' }, g);
};
/* লেবেল রেখা ও লেখা */
B12.lab = (g, ax, ay, lx, ly, s, C, o = {}) => {
  E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': .9, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2, fill: C.fg }, g);
  const an = o.a || (lx < ax ? 'end' : 'start'); T(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 4, s, { fs: o.fs || 11, a: an, w: 560, c: o.c || C.fg });
};
/* চিপ (গোল কোণের লেবেল) */
B12.chip = (g, x, y, s, R, o = {}) => { const w = o.w || 60, h = o.h || 18; E('rect', { x: x - (o.a === 'start' ? 0 : w / 2), y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.c, 'stroke-width': 1 }, g); T(g, x + (o.a === 'start' ? w / 2 : 0), y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
/* ঝিল্লি (দ্বিস্তরী লিপিড) — অনুভূমিক */
B12.mem = (g, C, x0, x1, y, o = {}) => {
  const R = o.R || BK.ramp(2), sp = o.sp || 9, gaps = o.gaps || [];
  E('rect', { x: x0, y: y - 8, width: x1 - x0, height: 16, fill: FK.alpha(R.c, .14) }, g);
  let d = '';
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; d += `M${x.toFixed(1)} ${y - 5}v3.2M${x.toFixed(1)} ${y + 1.8}v3.2`; }
  E('path', { d, stroke: R.dk, 'stroke-width': 1, opacity: .55 }, g);
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; E('circle', { cx: x, cy: y - 7, r: 3, fill: R.c }, g); E('circle', { cx: x, cy: y + 7, r: 3, fill: R.c }, g); }
};

/* লেখচিত্র-ধরন: o.types[k] = { b, t, d, f, xr, xt, lx, ly, read?(x) → নোট, mk?:[[x, লেখা]] } */
B12.gseg = o => {
  const ty = {}; Object.keys(o.types).forEach(k => { const G = o.types[k]; ty[k] = [G.b, G.t, G.d]; });
  const box = [46, 34, 284, 160];
  return B12.seg({
    id: o.id, t: o.t, cap: o.cap, k: ['graph', 'anim', 'int'], H: 236, def: o.def, types: ty,
    art(g, C, k, ctx) {
      const G = o.types[k], R = BK.ramp(G.c != null ? G.c : 0);
      const P = B12.axes(g, C, box, { xr: G.xr, yr: [0, 1.08], lx: G.lx, ly: G.ly || 'আপেক্ষিক হার', xt: G.xt, yt: [.5, 1], yf: v => v === 1 ? 'সর্বোচ্চ' : '' });
      ctx.P = P; ctx.G = G;
      B12.area(g, P, G.f, G.xr[0], G.xr[1], 0, { fill: FK.alpha(R.c, .13) });
      B12.curve(g, P, G.f, G.xr[0], G.xr[1], { stroke: R.c, 'stroke-width': 3 });
      (G.mk || []).forEach(([xv, s, up, an]) => { const [px, py] = P(xv, G.f(xv)); E('circle', { cx: px, cy: py, r: 3.2, fill: R.dk }, g); T(g, px + (an ? 7 : 0), py + (up ? -9 : 17), s, { fs: 9.8, a: an || 'middle', w: 560, c: R.ink }); });
      if (ctx.sel != null) { const [px, py] = P(ctx.sel, G.f(ctx.sel)), [, pb] = P(ctx.sel, 0), [pa] = P(G.xr[0], 0); E('path', { d: `M${px} ${pb}V${py}H${pa}`, stroke: C.mu, 'stroke-dasharray': '3 3', fill: 'none' }, g); E('circle', { cx: px, cy: py, r: 5, fill: R.c, stroke: C.sf, 'stroke-width': 2 }, g); }
    },
    anim(g, C, k, t, ctx) {
      const G = ctx.G, P = ctx.P; if (!G || !t) return; const R = BK.ramp(G.c != null ? G.c : 0), u = (1 - Math.cos(t * .7)) / 2, xv = G.xr[0] + u * (G.xr[1] - G.xr[0]), [px, py] = P(xv, G.f(xv));
      E('circle', { cx: px, cy: py, r: 9, fill: FK.alpha(R.c, .25) }, g); E('circle', { cx: px, cy: py, r: 4.5, fill: R.dk }, g);
    },
    tap(x, y, k, ctx) {
      const G = ctx.G; if (!G || x < box[0] - 4 || x > box[0] + box[2] + 4 || y > box[1] + box[3] + 6) return null;
      const xv = cl(G.xr[0] + (x - box[0]) / box[2] * (G.xr[1] - G.xr[0]), G.xr[0], G.xr[1]); ctx.sel = xv;
      const v = Math.round(G.f(xv) * 100);
      return `<b>${G.lx}: ${FK.n(xv, G.dp != null ? G.dp : 0)}${G.u || ''}</b> → আপেক্ষিক হার ≈ <b>${v}%</b> (সর্বোচ্চের তুলনায়)${G.read ? `<div class="small">${G.read(xv)}</div>` : ''}<div class="small muted">এটি প্রবণতা বোঝানোর লেখচিত্র — মান উদ্ভিদভেদে বদলায়।</div>`;
    }
  });
};
B12.node = (g, x, y, s, R, w = 64, h = 22, o = {}) => { E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: o.rx != null ? o.rx : 7, fill: o.fill || FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': o.sw || 1.1 }, g); T(g, x, y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };

/* ═══ অধ্যায় ১১ এর নতুন সহায়ক ═══ */
/* বৃত্তচাপ: কোণ ডিগ্রিতে, ০° = ওপরে, ঘড়ির কাঁটার দিকে */
const pol = B12.pol = (cx, cy, r, a) => { const t = (a - 90) * PI / 180; return [cx + r * Math.cos(t), cy + r * Math.sin(t)]; };
B12.arc = (cx, cy, r, a0, a1) => { const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1), big = ((a1 - a0) % 360 + 360) % 360 > 180 ? 1 : 0; return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${big} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`; };
/* নিকটতম বিন্দু: H = [[x, y, ...], ...] → সবচেয়ে কাছের উপাদান (r এর মধ্যে) */
B12.hot = (H, x, y, r = 30) => { let b = null, bd = r; H.forEach(h => { const d = Math.hypot(h[0] - x, h[1] - y); if (d < bd) { bd = d; b = h; } }); return b; };
const COMP = { A: 'T', T: 'A', G: 'C', C: 'G' };
B12.comp = s => s.split('').map(c => COMP[c] || c).join('');
/* দ্বিসূত্রক DNA: ওপরের সূত্র seq (5'→3'), নিচে পরিপূরক। o = { w (প্রতি ক্ষারক), gap, cut:[উপরের কাটা, নিচের কাটা], sep (কাটার পর দুই অংশের দূরত্ব), top/bot: false হলে সেই সূত্র আঁকবে না, op, lab (5'/3' দেখাবে), from, to } */
B12.dna = (g, C, x, y, seq, o = {}) => {
  const w = o.w || 15, gap = o.gap || 24, n = seq.length, cs = B12.comp(seq), cut = o.cut, sep = o.sep || 0, a = o.from || 0, b = o.to != null ? o.to : n;
  const xs = (i, strand) => x + i * w + (cut && sep ? (i >= cut[strand] ? sep / 2 : -sep / 2) : 0);
  const Rb = BK.ramp(9);
  [0, 1].forEach(s => {
    if ((s === 0 && o.top === false) || (s === 1 && o.bot === false)) return;
    const yy = s ? y + gap : y, str = s ? cs : seq;
    const segs = cut ? [[a, cut[s]], [cut[s], b]] : [[a, b]];
    segs.forEach(([i0, i1]) => { if (i1 <= i0) return; E('path', { d: `M${xs(i0, s) + 1} ${yy + (s ? 9 : -9)}H${xs(i1 - 1, s) + w - 1}`, stroke: Rb.dk, 'stroke-width': 2.2, 'stroke-linecap': 'round', opacity: o.op != null ? o.op : 1 }, g); });
    for (let i = a; i < b; i++) {
      const R = BK.base(str[i]), px = xs(i, s);
      E('rect', { x: px + 1, y: yy - (s ? 0 : 8) - (s ? 0 : 0), width: w - 2, height: 8, rx: 1.5, fill: R.c, opacity: o.op != null ? o.op : 1 }, g);
      if (w >= 12) T(g, px + w / 2, yy + (s ? 21 : -14), str[i], { fs: o.fs || 9, a: 'middle', w: 700, c: R.ink });
    }
  });
  if (o.lab) { T(g, x - 6 - (cut && sep ? sep / 2 : 0), y - 1, "5'", { fs: 8.5, a: 'end', c: C.mu }); T(g, x + n * w + 6 + (cut && sep ? sep / 2 : 0), y - 1, "3'", { fs: 8.5, c: C.mu }); T(g, x - 6 - (cut && sep ? sep / 2 : 0), y + gap + 8, "3'", { fs: 8.5, a: 'end', c: C.mu }); T(g, x + n * w + 6 + (cut && sep ? sep / 2 : 0), y + gap + 8, "5'", { fs: 8.5, c: C.mu }); }
};
/* প্লাসমিড: o = { genes:[[a0, a1, ramp, লেখা]], sites:[[a, লেখা]], ins:[a0, a1] (ঢোকানো জিন — অ্যাম্বার), sw, lab, fs } */
B12.plasmid = (g, C, cx, cy, r, o = {}) => {
  const Rp = BK.ramp(3);
  E('circle', { cx, cy, r: r + 2.5, fill: 'none', stroke: Rp.dk, 'stroke-width': 1.2 }, g); E('circle', { cx, cy, r: r - 2.5, fill: 'none', stroke: Rp.dk, 'stroke-width': 1.2 }, g);
  E('circle', { cx, cy, r, fill: 'none', stroke: FK.alpha(Rp.c, .35), 'stroke-width': 4 }, g);
  (o.genes || []).forEach(([a0, a1, ri, s]) => { const R = BK.ramp(ri); E('path', { d: B12.arc(cx, cy, r, a0, a1), stroke: R.c, 'stroke-width': o.sw || 9, fill: 'none', 'stroke-linecap': 'butt' }, g); if (s) { const m = (a0 + a1) / 2, [lx, ly] = pol(cx, cy, r - (o.sw || 9) - 9, m); T(g, lx, ly + 3.5, s, { fs: o.fs || 9, a: 'middle', w: 650, c: R.ink }); } });
  if (o.ins) { const R = BK.ramp(6); E('path', { d: B12.arc(cx, cy, r, o.ins[0], o.ins[1]), stroke: R.c, 'stroke-width': (o.sw || 9) + 2, fill: 'none' }, g); }
  (o.sites || []).forEach(([a, s]) => { const [x0, y0] = pol(cx, cy, r + 4, a), [x1, y1] = pol(cx, cy, r + 13, a), [lx, ly] = pol(cx, cy, r + 22, a); E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: BK.ramp(4).dk, 'stroke-width': 1.5 }, g); T(g, lx, ly + 3.5, s, { fs: o.fs || 9, a: lx < cx - 4 ? 'end' : lx > cx + 4 ? 'start' : 'middle', w: 600, c: BK.ramp(4).ink }); });
};
/* ব্যাকটেরিয়া কোষ (ক্যাপসুল আকৃতি): o = { chromo, plas (সংখ্যা), pr (প্লাসমিডের রং ৩/৬ মিশ্র), op, fill } */
B12.bac = (g, C, x, y, w, h, o = {}) => {
  const R = BK.ramp(0); E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.dk, 'stroke-width': 1.3, opacity: o.op != null ? o.op : 1 }, g);
  if (o.chromo !== false) { let d = `M${x - w * .28} ${y}`; for (let i = 1; i <= 8; i++) d += `Q${x - w * .28 + (i - .5) * w * .07} ${y + (i % 2 ? -h * .22 : h * .22)} ${x - w * .28 + i * w * .07} ${y}`; E('path', { d, stroke: BK.ramp(9).dk, 'stroke-width': 1.3, fill: 'none', opacity: o.op != null ? o.op : 1 }, g); }
  for (let i = 0; i < (o.plas || 0); i++) { const px = x + w * .3 + (i % 2) * 7 - 3, py = y - h * .22 + Math.floor(i / 2) * 9; E('circle', { cx: px, cy: py, r: 3.2, fill: 'none', stroke: (o.pr === 6 ? BK.ramp(6) : BK.ramp(3)).dk, 'stroke-width': 1.6, opacity: o.op != null ? o.op : 1 }, g); }
};
/* কনিক্যাল ফ্লাস্ক — মাধ্যমসহ */
B12.flask = (g, C, x, y, s = 1, o = {}) => { E('path', { d: `M${x - 10 * s} ${y - 60 * s}V${y - 34 * s}L${x - 34 * s} ${y}H${x + 34 * s}L${x + 10 * s} ${y - 34 * s}V${y - 60 * s}Z`, fill: FK.alpha(BK.ramp(5).c, .08), stroke: C.fg, 'stroke-width': 1.3 }, g); E('path', { d: `M${x - 26 * s} ${y - 12 * s}H${x + 26 * s}L${x + 34 * s} ${y}H${x - 34 * s}Z`, fill: FK.alpha(BK.ramp(o.med != null ? o.med : 6).c, .45) }, g); E('rect', { x: x - 12 * s, y: y - 66 * s, width: 24 * s, height: 8 * s, rx: 2, fill: '#e5e5e5', stroke: C.mu }, g); };
/* পেট্রিডিশ (ওপর থেকে) — o.col: [[dx, dy, r, রং]] কলোনি */
B12.dish = (g, C, x, y, r, o = {}) => { E('circle', { cx: x, cy: y, r: r + 3, fill: 'none', stroke: C.mu, 'stroke-width': 1.2 }, g); E('circle', { cx: x, cy: y, r, fill: FK.alpha(BK.ramp(o.med != null ? o.med : 6).c, .22), stroke: C.mu, 'stroke-width': .8 }, g); (o.col || []).forEach(([dx, dy, cr, c]) => E('circle', { cx: x + dx, cy: y + dy, r: cr, fill: c, stroke: FK.alpha('#000', .25), 'stroke-width': .6 }, g)); if (o.lab) T(g, x, y + r + 16, o.lab, { fs: o.fs || 9.5, a: 'middle', w: 600, c: o.lc || C.fg }); };

/* ═══ মানচিত্রের তথ্য — world-atlas@2.0.2 (Natural Earth), সরলীকৃত ═══ */
B12.GEO = { bd: 'M68.9 308.1L68.7 295.9L63.9 280.1L60.6 272.1L61.0 269.4L59.4 257.9L56.3 244.7L61.2 235.0L59.2 233.3L48.4 230.4L47.1 227.9L49.3 218.2L40.3 207.2L38.5 202.3L46.8 180.4L48.6 168.1L48.4 162.2L43.2 158.8L34.2 157.4L27.9 154.5L24.1 150.2L21.0 148.5L17.1 149.7L12.2 148.1L4.5 138.6L5.9 132.9L12.4 119.4L14.9 119.0L20.5 121.5L22.8 121.6L26.4 116.3L31.5 101.1L49.8 102.4L54.3 101.9L58.8 100.6L61.2 98.8L62.6 96.3L62.1 94.2L56.5 91.3L54.5 89.3L52.9 83.2L51.1 80.9L40.3 80.5L34.5 77.8L31.3 75.3L25.9 67.0L18.9 60.9L12.4 59.4L9.7 57.4L8.4 54.3L12.6 41.0L30.6 22.2L31.1 19.9L30.4 17.6L25.0 14.5L26.1 9.0L29.3 8.6L35.6 12.2L41.9 18.0L45.7 23.2L45.7 27.3L50.7 28.1L54.9 29.9L59.2 29.3L61.9 30.4L63.7 30.0L64.4 27.7L60.8 21.7L62.6 19.2L66.9 19.4L69.8 21.6L72.0 26.2L72.5 33.3L77.2 39.7L83.7 44.3L88.7 46.4L94.8 47.9L99.9 46.4L102.6 42.0L101.5 37.9L102.2 34.3L104.2 32.4L107.6 32.5L110.1 35.4L117.0 50.7L115.7 57.6L117.3 76.3L115.5 88.6L115.7 91.2L117.7 94.1L128.3 96.5L143.8 101.3L155.5 103.2L208.8 101.8L220.5 104.2L256.3 102.4L266.0 106.3L276.6 112.7L282.4 117.5L283.5 120.1L282.9 122.5L280.8 123.7L277.2 123.8L268.9 120.7L267.3 121.6L267.3 129.0L260.4 147.5L259.5 153.2L257.2 155.5L250.0 156.7L245.5 167.5L243.5 168.9L239.0 166.5L236.1 166.8L232.5 167.8L228.9 170.3L226.4 173.4L223.5 174.5L213.6 174.4L211.5 179.3L205.0 185.8L200.7 203.3L201.0 208.6L206.6 222.4L210.4 240.4L211.8 242.3L213.6 242.5L213.8 234.1L215.6 233.1L217.8 234.0L222.6 245.2L225.3 248.0L229.3 248.8L234.0 247.1L237.6 243.9L239.0 240.3L237.9 228.2L239.9 223.3L248.0 215.9L249.3 213.7L248.7 201.5L251.8 201.2L255.9 202.1L261.0 199.2L262.6 199.2L264.9 202.2L268.5 201.7L274.1 225.8L274.5 242.7L275.7 252.1L277.7 254.3L283.8 268.5L289.6 318.3L290.3 349.9L292.5 360.7L290.5 363.1L288.7 363.6L286.9 359.8L273.9 351.7L270.5 352.6L266.2 357.2L264.4 361.6L265.1 367.6L266.4 373.7L269.6 377.1L269.8 380.9L273.4 395.2L272.3 395.2L265.3 382.3L256.5 369.5L253.8 346.6L253.6 335.4L247.8 322.1L242.1 299.0L244.6 290.9L240.3 294.4L234.0 280.6L223.7 267.0L220.8 261.0L220.5 255.2L216.3 261.0L210.2 265.1L204.1 271.4L200.1 273.3L187.2 274.4L179.8 266.1L169.2 245.7L167.7 241.1L169.0 229.1L166.5 217.9L165.9 207.9L164.1 208.8L163.2 211.5L163.6 215.7L162.9 219.3L144.9 217.0L152.6 222.9L160.7 224.3L165.0 229.6L165.4 238.4L157.3 243.8L158.0 248.3L162.7 253.8L156.9 255.4L155.5 259.0L155.3 264.0L159.3 271.9L158.7 274.9L165.4 285.2L166.5 290.1L165.0 297.1L150.3 311.1L146.1 321.1L142.5 325.7L138.0 326.6L136.4 324.5L132.6 321.9L132.6 317.0L133.7 313.2L141.1 303.8L132.3 307.7L125.4 312.7L122.9 306.6L121.5 300.8L121.5 293.7L127.2 283.1L120.6 288.4L118.8 295.0L119.7 302.8L116.4 315.4L113.0 319.7L107.4 322.5L104.9 326.8L101.1 329.9L99.9 315.4L95.9 295.9L95.0 300.1L97.0 312.2L97.0 320.1L93.9 326.3L87.8 332.9L83.1 333.9L80.4 332.9L76.1 328.8L71.6 322.8L70.7 313.3ZM200.1 302.6L193.3 307.3L195.6 279.5L200.5 289.9L201.9 295.4ZM225.5 288.7L222.6 290.7L219.9 289.1L216.3 282.6L218.1 274.3L219.2 273.0L220.8 275.7ZM176.7 308.3L165.9 310.6L160.2 310.0L170.6 292.4L170.4 284.5L168.8 278.1L163.4 273.0L163.2 269.3L160.7 264.3L159.6 258.4L165.4 256.5L170.1 259.9L171.7 266.6L174.2 271.6L182.3 281.9L182.3 288.2L180.0 303.6ZM245.3 325.5L243.0 331.0L241.9 327.0L242.8 322.0L243.7 319.2L244.4 319.2L245.7 322.1ZM250.0 347.2L246.2 347.6L244.4 345.6L245.3 342.8L244.2 333.7L248.9 332.9L250.0 335.5L250.7 340.4ZM168.3 249.9L169.2 252.8L165.9 251.1L163.2 249.1L161.6 246.4L164.3 245.1Z', bdH: 411.3, world: 'M307 130L310 130L309 132L308 133L307 131ZM333 130L335 131L333 133L332 134L330 136L327 135ZM335 125L337 127L339 127L336 131L335 129L334 129L335 127L333 124ZM217 102L218 104L217 104L214 114L213 114L212 114L211 110L212 109L212 105L215 103L216 100ZM306 102L307 103L308 108L311 109L315 115L314 121L311 127L308 128L307 127L306 128L303 127L302 125L300 125L301 124L299 124L300 122L298 124L297 122L294 121L280 124L279 123L279 121L278 118L277 115L278 115L277 113L278 110L278 111L280 109L284 108L289 103L290 102L292 103L293 101L295 100L295 99L298 101L299 100L298 103L302 106L304 103L304 99ZM273 95L275 95L279 97L274 96L270 95L270 94ZM297 89L298 91L301 90L307 92L309 94L309 96L310 97L312 99L310 98L307 96L305 98L301 96L300 97L301 96L300 94L296 92L296 92L295 91L296 90L293 89L295 88ZM288 86L287 88L284 88L284 89L286 89L285 90L286 93L285 93L286 93L285 93L284 91L284 94L283 93L282 91L283 87L284 87ZM270 94L267 92L260 83L262 83L268 88L268 89L270 91ZM281 86L282 87L281 87L280 92L278 92L274 91L273 88L274 86L275 86L281 81L283 82L281 85ZM289 79L288 82L287 80L286 80L285 81L286 80L288 79L288 78ZM247 82L245 81L246 78L247 80ZM285 69L285 69L286 70L285 73L287 74L287 75L286 74L284 74L283 72L283 71ZM101 67L105 68L105 69L103 69L103 70L100 69L102 69L101 68ZM95 64L100 67L97 67L97 67L96 66L92 64L90 65L92 64ZM303 50L302 52L298 53L298 52L294 53L295 54L293 56L292 53L295 51L298 51L299 49L300 50L302 48L303 45L304 45L304 47ZM306 42L307 42L307 43L305 44L304 44L303 45L302 45L302 44L304 43L304 41ZM117 35L116 36L120 38L120 40L119 40L119 39L118 39L114 39L116 35L117 35ZM306 35L307 37L305 37L305 38L306 40L305 40L304 40L304 37L304 32ZM164 34L161 34L161 33L161 32L162 31L165 31ZM167 27L166 28L168 28L167 30L172 33L171 35L165 36L167 35L165 34L166 34L166 33L167 32L165 31L165 30L165 31L164 29L165 27ZM90 20L94 22L94 22L92 22L89 23L88 22ZM156 19L157 21L152 22L149 22L149 21L147 21L149 21L147 20L148 19L151 20ZM340 17L340 21L340 20L340 21L338 21L339 23L334 24L331 26L330 25L324 26L323 28L324 28L323 31L321 32L318 35L317 31L317 29L325 25L325 23L321 25L320 24L318 24L316 26L316 27L304 27L298 31L300 32L302 32L304 34L301 40L297 43L295 43L290 47L292 50L292 52L289 52L289 50L290 50L288 49L288 47L284 48L285 46L285 46L281 47L281 48L282 49L286 49L283 52L285 55L285 59L282 63L279 64L275 66L274 67L272 65L270 67L273 74L273 76L269 79L269 78L265 74L264 78L267 82L268 87L266 85L265 81L263 80L263 76L262 70L260 72L259 71L259 69L256 64L252 66L252 67L246 71L245 77L243 80L239 71L239 66L237 66L233 62L224 61L223 60L222 61L219 59L217 57L215 57L218 62L219 61L219 63L221 63L223 61L224 63L226 65L224 68L222 70L216 73L211 75L210 71L203 59L203 57L202 59L201 57L204 64L205 65L205 69L211 75L210 76L212 77L218 75L218 77L215 84L208 91L207 93L207 97L208 99L208 105L203 108L203 113L201 115L201 117L198 120L194 123L189 124L187 123L187 121L184 116L183 111L181 107L182 103L183 100L183 97L181 93L178 89L179 85L178 83L177 83L176 84L174 81L162 83L158 80L154 75L153 73L155 69L154 65L156 61L161 57L161 54L164 51L168 52L171 50L179 49L180 50L180 53L188 57L190 54L197 56L203 55L204 50L196 50L195 47L198 45L202 44L206 46L209 45L209 44L205 41L207 39L203 40L204 41L202 42L201 41L201 40L199 40L196 44L197 45L195 46L194 46L192 46L193 47L191 46L193 48L192 49L192 50L190 50L188 46L188 45L182 41L182 41L182 42L187 46L186 46L186 48L185 49L185 47L178 42L176 43L173 43L173 45L171 46L170 48L168 50L165 51L164 50L162 50L161 43L169 42L169 40L166 38L168 38L168 36L171 36L174 33L178 33L178 29L180 28L180 30L179 31L180 32L189 32L190 31L190 29L193 29L193 28L192 27L198 26L192 26L190 25L190 23L194 21L193 20L187 23L186 24L188 26L186 27L185 30L182 31L180 26L178 28L175 27L175 24L188 16L197 14L200 15L198 15L199 16L208 18L209 19L208 19L201 19L203 20L203 21L205 22L205 21L207 21L208 21L208 20L210 19L212 20L212 19L211 17L214 17L214 18L213 19L214 19L221 17L221 17L221 17L226 17L227 17L228 17L227 16L235 17L235 17L233 16L233 14L236 12L239 13L238 14L239 17L240 17L237 19L238 19L241 18L241 17L240 16L240 15L239 14L241 13L241 13L241 13L241 14L242 14L242 14L243 13L247 14L246 12L252 11L251 11L252 10L265 9L269 8L271 9L278 9L273 11L286 12L286 12L290 12L294 15L295 14L302 14L301 13L303 13L311 13L314 15L320 15L322 16L329 16L330 17L331 17L331 15ZM84 16L84 17L86 16L88 18L89 16L92 16L93 16L93 17L93 18L91 19L89 19L88 21L82 24L81 27L82 27L83 29L92 31L92 33L95 35L96 34L95 31L98 29L96 27L97 26L96 23L100 23L104 25L105 27L106 28L109 26L112 29L112 30L116 31L117 34L113 36L107 36L103 39L109 37L109 38L109 38L109 40L112 40L113 39L114 40L108 43L108 42L109 41L107 41L103 43L104 45L100 46L102 46L100 46L99 48L99 47L99 48L98 49L98 47L97 48L98 51L93 55L94 62L93 61L91 57L86 57L86 58L85 58L81 57L79 59L78 65L79 68L81 69L83 69L84 68L85 66L88 66L86 71L91 72L91 76L93 79L95 78L97 79L99 76L102 75L102 79L103 77L104 75L106 77L112 77L111 78L116 82L119 82L122 84L123 86L122 88L124 88L124 89L125 89L128 90L128 91L132 91L136 93L137 96L133 101L131 111L125 114L124 118L119 124L117 124L115 123L116 126L114 128L111 128L111 130L108 130L109 131L110 131L108 135L106 135L106 136L108 137L105 140L106 142L103 143L103 144L99 141L99 138L100 136L99 136L100 134L101 134L101 132L100 133L101 126L103 121L104 108L103 106L98 103L95 95L93 94L93 93L95 91L94 90L94 89L97 84L96 79L95 79L94 80L89 78L87 74L84 74L81 71L79 72L72 69L70 67L70 64L62 55L62 55L62 57L67 64L66 64L64 62L64 61L61 59L62 58L59 54L56 52L53 46L53 41L52 38L54 38L54 39L54 37L50 35L49 34L43 28L31 25L27 27L28 25L20 30L14 32L21 28L22 27L17 27L17 26L15 26L13 24L15 23L18 22L17 21L18 21L14 21L11 20L15 19L17 20L13 17L22 14L41 17L49 15L51 16L55 16L61 17L62 17L61 18L67 18L68 18L67 17L68 17L70 17L74 18L77 18L78 17L79 17L79 18L81 16L79 15L80 14L82 14L84 15L83 16ZM62 12L66 12L68 14L68 12L70 13L71 14L75 16L73 16L73 17L69 16L63 17L60 16L59 16L64 15L59 15L60 14L57 14L59 13ZM88 12L89 13L92 12L94 13L96 13L100 14L102 14L106 15L107 16L105 17L112 19L110 21L106 19L109 22L109 23L105 22L108 24L99 21L96 21L96 20L100 20L101 18L95 15L86 15L85 15L86 14L85 14L85 13L87 12L89 12ZM75 12L78 12L77 12L79 13L79 14L77 14L73 13L75 13L74 12ZM82 13L80 13L80 12L85 12ZM56 14L54 15L51 14L53 12L52 11L55 11L61 12ZM307 10L306 11L301 11L299 10L301 9ZM77 9L78 9L77 10L75 10L73 10L73 9ZM68 9L70 9L70 10L63 11L64 10L59 10L61 9L67 10L66 9ZM224 15L221 15L219 13L223 10L225 10L235 9L225 11L222 13ZM81 8L86 10L93 10L95 10L83 11L81 9L78 9ZM60 8L59 9L55 9L54 9L56 8ZM269 7L264 7L266 6L266 6L267 6L270 7ZM187 5L190 6L188 7L186 8L183 8L184 8L180 6ZM194 5L196 5L194 6L189 5L186 5ZM264 6L260 6L256 5L261 4L265 5ZM88 6L89 6L84 7L79 5L79 5L81 4L83 4ZM105 2L112 3L106 4L108 4L103 5L97 6L99 7L95 8L96 9L85 9L87 8L87 7L90 8L87 7L90 6L88 5L93 5L87 5L84 3L95 2ZM144 2L150 2L140 3L158 4L151 5L153 5L151 6L153 8L150 9L151 9L151 10L150 10L152 11L148 12L149 13L147 13L149 15L146 14L146 15L145 15L149 15L132 20L130 23L129 26L128 26L124 25L121 22L119 18L122 16L118 16L119 15L121 15L117 14L118 13L116 11L112 9L105 9L103 8L107 8L101 7L108 6L106 5L113 3L122 3L128 3L126 2L129 2Z' };
B12.bdXY = (lon, lat) => [(lon - 87.95) * 62.5, (26.7 - lat) * 62.5 * 1.07];
B12.wXY = (lon, lat) => [(lon + 180) / 360 * 340, (85 - lat) / 145 * 150];
})();
