/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §১.২ কর্ডাটা, §১.৩ ব্যবহারিক ও §সার
   chordateTraits, protochordates, chordataTree, fishTypes, heartChambers, vertClasses, frogMeta,
   amnioteEgg, birdFlight, mammalGroups, specimenKey, labSpecimens, b2c1map,
   cmpNonChordChord, cmpUroCephalo, cmpChondOste, cmpAmphRept
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B21, X = window.B21X;
const PI = Math.PI, rnd = B.rnd, hot = B.hot, lab = B.lab, arrow = X.arrow, cmp = X.cmp, layer = X.layer, ani = X.ani, okm = X.okm, nope = X.nope;
const pick = (ctx, H, x, y, r) => { const h = hot(H, x, y, r || 24); if (!h) return ''; ctx.sel = h[2]; return h[3]; };
const ring = (g, x, y, r, i, ctx) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2 }, g); };

/* ═════════ ১. কর্ডাটার চারটি মৌলিক বৈশিষ্ট্য ═════════ */
const CHT = [[180, 122, 0, '<b>নটোকর্ড</b> — পৃষ্ঠীয়, দণ্ডাকার, নমনীয় কঙ্কাল-দণ্ড; জীবনের অন্তত কোনো দশায় থাকে। মেরুদণ্ডীতে ভ্রূণের পর কশেরুকায় প্রতিস্থাপিত হয়।'], [180, 96, 1, '<b>পৃষ্ঠীয় ফাঁপা স্নায়ুরজ্জু</b> — নটোকর্ডের ওপরে নলাকার; সম্মুখে মস্তিষ্ক, পেছনে সুষুম্নাকাণ্ড (ননকর্ডাটায় স্নায়ুরজ্জু নিরেট ও অঙ্কীয়)।'], [96, 140, 2, '<b>গলবিলীয় ফুলকাছিদ্র</b> — গলবিলের দুই পাশে ছিদ্র; জলজে খাদ্য ছাঁকা ও শ্বসন; স্থলজ মেরুদণ্ডীর কেবল ভ্রূণে দেখা যায়।'], [316, 128, 3, '<b>পায়ু-পরবর্তী লেজ</b> — পায়ুর পরেও দেহ লেজ হিসেবে বিস্তৃত; মানুষে ভ্রূণে থাকে, পরে কক্সিক্স।'], [112, 172, 4, '<b>এন্ডোস্টাইল</b> — গলবিলের মেঝের খাঁজ; শ্লেষ্মা দিয়ে খাদ্যকণা ধরে; মেরুদণ্ডীতে থাইরয়েড গ্রন্থি এর সমতুল্য।']];
V.chordateTraits = Object.assign({}, B.seg({
  id: 'cht', t: 'কর্ডাটার মৌলিক বৈশিষ্ট্য', H: 230, def: 'all', sel: null,
  cap: 'কর্ডাটা পর্বের সব প্রাণীর জীবনের অন্তত কোনো দশায় চারটি বৈশিষ্ট্য থাকে — নটোকর্ড, পৃষ্ঠীয় ফাঁপা স্নায়ুরজ্জু, গলবিলীয় ফুলকাছিদ্র ও পায়ু-পরবর্তী লেজ; সাথে এন্ডোস্টাইল বা থাইরয়েড। বৈশিষ্ট্যে চাপ দাও; চালাও চাপলে পানি মুখ দিয়ে ঢুকে ফুলকাছিদ্র দিয়ে বেরোবে।',
  types: { all: ['সাধারণ কর্ডেট', 'কল্পিত সাধারণ কর্ডেটের পার্শ্বচিত্র', 'নটোকর্ড (বেগুনি), স্নায়ুরজ্জু (কমলা), ফুলকাছিদ্র, লেজ ও এন্ডোস্টাইল।'] },
  art(g, C, ty, ctx) {
    E('path', { d: 'M40 130Q50 86 120 84H260Q300 90 340 128Q300 150 260 160H120Q50 170 40 130Z', fill: FK.alpha(BK.ramp(5).c, .16), stroke: BK.ramp(5).dk, 'stroke-width': 1.4 }, g);
    E('path', { d: 'M60 122H300', stroke: layer('no').c, 'stroke-width': 9, 'stroke-linecap': 'round', opacity: .75 }, g);
    E('path', { d: 'M62 102Q60 96 74 96H300', stroke: layer('nc').c, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d: 'M66 100H300', stroke: C.sf, 'stroke-width': 2 }, g);
    E('path', { d: 'M48 136H260', stroke: layer('en').c, 'stroke-width': 8, 'stroke-linecap': 'round', opacity: .6 }, g);
    for (let i = 0; i < 6; i++) E('path', { d: `M${82 + i * 9} 132v16`, stroke: BK.ramp(9).dk, 'stroke-width': 3 }, g);
    E('path', { d: 'M96 160h34', stroke: BK.ramp(0).dk, 'stroke-width': 3 }, g);
    E('circle', { cx: 262, cy: 140, r: 4, fill: C.sf, stroke: C.fg }, g); T(g, 262, 176, 'পায়ু', { fs: 9, a: 'middle', c: C.mu }); E('path', { d: 'M262 144V166', stroke: C.mu, 'stroke-width': .8 }, g);
    E('path', { d: 'M280 112L300 96M280 148L300 162', stroke: BK.ramp(5).dk, 'stroke-width': 1.2 }, g);
    T(g, 40, 160, 'মুখ', { fs: 9, c: C.mu });
    lab(g, 120, 122, 92, 30, 'নটোকর্ড', C, { fs: 9.6, a: 'middle' }); lab(g, 200, 98, 200, 30, 'পৃষ্ঠীয় ফাঁপা স্নায়ুরজ্জু', C, { fs: 9.6, a: 'middle' }); lab(g, 320, 128, 318, 62, 'পায়ু-পরবর্তী লেজ', C, { fs: 9.6, a: 'middle' });
    lab(g, 100, 148, 70, 184, 'ফুলকাছিদ্র', C, { fs: 9.6, a: 'middle' }); lab(g, 120, 160, 150, 184, 'এন্ডোস্টাইল', C, { fs: 9.6, a: 'middle' }); lab(g, 220, 136, 220, 184, 'পৌষ্টিকনালি', C, { fs: 9.6, a: 'middle' });
    [['নটোকর্ড', 3], ['স্নায়ুরজ্জু', 2], ['ফুলকাছিদ্র', 9], ['লেজ', 5], ['এন্ডোস্টাইল', 0]].forEach(([n, ri], i) => { const x = 14 + i * 70; E('rect', { x, y: 196, width: 64, height: 22, rx: 8, fill: FK.alpha(BK.ramp(ri).c, ctx.sel === i ? .5 : .15), stroke: BK.ramp(ri).dk }, g); T(g, x + 32, 211, n, { fs: 9.4, a: 'middle', w: 700, c: BK.ramp(ri).ink }); });
    CHT.forEach(([x, y, i]) => ring(g, x, y, 12, i, ctx));
  },
  anim(g, C, ty, t) {
    if (!t) return;
    for (let i = 0; i < 6; i++) { const k = (t * .4 + i / 6) % 1, x = 40 + k * 90, y = k < .6 ? 132 : 132 + (k - .6) / .4 * 30; E('circle', { cx: x, cy: y, r: 2.2, fill: BK.ramp(5).dk, opacity: .8 }, g); }
    const k = (t * .5) % 1; E('circle', { cx: 74 + k * 226, cy: 100, r: 3.4, fill: BK.ramp(2).dk }, g);
  },
  tap(x, y, ty, ctx) { if (y > 192) { const i = Math.floor((x - 14) / 70); if (i >= 0 && i < 5) { ctx.sel = i; return CHT[i][3]; } } return pick(ctx, CHT, x, y, 22); }
}));

/* ═════════ ২. প্রোটোকর্ডাটা ═════════ */
V.protochordates = Object.assign({}, B.seg({
  id: 'prc', t: 'প্রোটোকর্ডাটা — ইউরোকর্ডাটা ও সেফালোকর্ডাটা', H: 236, def: 'uro',
  cap: 'মেরুদণ্ডহীন কর্ডেটদের প্রোটোকর্ডাটা (আদি কর্ডেট) বলা হয় — সবাই সামুদ্রিক। ইউরোকর্ডাটায় (গ্রিক oura = লেজ) নটোকর্ড কেবল লার্ভার লেজে থাকে; সেফালোকর্ডাটায় (kephale = মাথা) নটোকর্ড মাথার ডগা থেকে লেজ পর্যন্ত সারাজীবন থাকে। চালাও চাপলে হার্ডম্যানিয়ার রূপান্তর দেখবে।',
  types: {
    uro: ['ইউরোকর্ডাটা', 'হার্ডম্যানিয়া (Herdmania) — অধোগামী রূপান্তর', 'মুক্ত সাঁতারু ব্যাঙাচির মতো লার্ভায় নটোকর্ড, স্নায়ুরজ্জু ও লেজ থাকে; লার্ভা মাথা দিয়ে কোনো বস্তুতে আটকে যায়, লেজ, নটোকর্ড ও স্নায়ুরজ্জু শোষিত হয়, ফুলকাথলি বড় হয় — পরিণত প্রাণী স্থির, থলির মতো, টিউনিকে ঢাকা। উন্নত লার্ভা থেকে সরল পরিণত প্রাণী — তাই অধোগামী (রেট্রোগ্রেসিভ) রূপান্তর।'],
    cep: ['সেফালোকর্ডাটা', 'ব্র্যাঙ্কিওস্টোমা (Branchiostoma; অ্যাম্ফিঅক্সাস)', 'মাছের মতো সরু স্বচ্ছ দেহ; নটোকর্ড মাথা থেকে লেজ পর্যন্ত সারাজীবন; V আকৃতির পেশিখণ্ড (মায়োটোম); মুখে সিরিযুক্ত মুখ-আবরণ; বহু ফুলকাছিদ্র, অ্যাট্রিয়াম ও অ্যাট্রিওপোর; প্রকৃত মস্তিষ্ক ও হৃৎপিণ্ড নেই। সমুদ্রতীরের বালুতে গর্ত করে থাকে।']
  },
  art(g, C, ty) {
    if (ty === 'cep') {
      E('path', { d: 'M30 120Q60 100 180 102Q300 104 336 120Q300 136 180 138Q60 140 30 120Z', fill: FK.alpha(BK.ramp(0).c, .2), stroke: BK.ramp(0).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M32 120H332', stroke: layer('no').c, 'stroke-width': 4 }, g); E('path', { d: 'M48 112H324', stroke: layer('nc').c, 'stroke-width': 3 }, g);
      for (let i = 0; i < 26; i++) E('path', { d: `M${70 + i * 10} 104l5 8l-5 8`, fill: 'none', stroke: FK.alpha(BK.ramp(4).dk, .45), 'stroke-width': .8 }, g);
      for (let i = 0; i < 14; i++) E('path', { d: `M${62 + i * 6} 124l3 10`, stroke: BK.ramp(9).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M30 120l-8 -6M30 120l-8 6M32 116l-6 -8M32 124l-6 8', stroke: C.fg, 'stroke-width': 1 }, g);
      lab(g, 180, 120, 180, 170, 'নটোকর্ড — মাথা থেকে লেজ', C, { fs: 9.6, a: 'middle' }); lab(g, 120, 112, 120, 70, 'পৃষ্ঠীয় স্নায়ুরজ্জু', C, { fs: 9.6, a: 'middle' }); lab(g, 90, 130, 60, 180, 'ফুলকাছিদ্র', C, { fs: 9.6 }); lab(g, 240, 106, 270, 70, 'মায়োটোম (V)', C, { fs: 9.6 }); lab(g, 24, 116, 30, 70, 'মুখ ও সিরি', C, { fs: 9.6 });
    } else { T(g, 80, 222, 'লার্ভা (মুক্ত সাঁতারু)', { fs: 9.6, a: 'middle', c: C.mu }); T(g, 270, 222, 'পরিণত (স্থির)', { fs: 9.6, a: 'middle', c: C.mu }); }
  },
  anim(g, C, ty, t) {
    if (ty !== 'uro') { if (t) { const k = (t * .6) % 1; E('circle', { cx: 32 + k * 300, cy: 112, r: 3, fill: BK.ramp(2).dk }, g); } return; }
    const k = ((t || 0) * .2) % 1, u = Math.min(1, k / .75), R = BK.ramp(3), x0 = 80 + u * 190;
    E('path', { d: 'M20 200H340', stroke: BK.ramp(11).dk, 'stroke-width': 3 }, g);
    const tail = 96 * (1 - u), bw = 28 + u * 30, bh = 22 + u * 38, by = (1 - u) * 112 + u * (198 - bh);
    E('ellipse', { cx: x0, cy: by, rx: bw, ry: bh, fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4 }, g);
    if (tail > 2) { E('path', { d: `M${x0 + bw - 4} ${by}q${tail / 2} ${-8 * Math.sin(t * 6)} ${tail} 0`, fill: 'none', stroke: R.dk, 'stroke-width': 6 * (1 - u) + 1, 'stroke-linecap': 'round' }, g); E('path', { d: `M${x0} ${by}H${x0 + bw + tail - 4}`, stroke: layer('no').c, 'stroke-width': 2.4 * (1 - u) }, g); }
    if (u < .5) { E('circle', { cx: x0 - bw * .4, cy: by - 6, r: 2.6, fill: C.fg }, g); for (let i = 0; i < 3; i++) E('path', { d: `M${x0 - bw - 2} ${by - 8 + i * 8}h-8`, stroke: R.dk, 'stroke-width': 2, opacity: 1 - 2 * u }, g); if (u < .15) lab(g, x0 + bw + 30, by, x0 + bw + 40, by - 40, 'নটোকর্ড ও স্নায়ুরজ্জু', C, { fs: 9.4 }); }
    if (u > .3) { E('path', { d: `M${x0 - 10} ${by - bh + 2}l-4 -14M${x0 + 14} ${by - bh + 4}l8 -12`, stroke: R.dk, 'stroke-width': 5, 'stroke-linecap': 'round', opacity: u }, g); for (let i = 0; i < 6; i++) E('path', { d: `M${x0 - 20 + i * 8} ${by - 14}v24`, stroke: BK.ramp(9).dk, 'stroke-width': 1.4, opacity: u }, g); if (u >= 1) { lab(g, x0 + 22, by - bh - 4, x0 + 60, by - bh - 14, 'সাইফন', C, { fs: 9.4 }); lab(g, x0 + 10, by, x0 + 70, by + 10, 'বড় ফুলকাথলি', C, { fs: 9.4 }); lab(g, x0 - bw + 6, by - bh * .5, x0 - bw - 50, by - bh * .5 - 10, 'টিউনিক', C, { fs: 9.4 }); } }
    E('path', { d: `M${x0 - bw * .6} ${by + bh * .8}L${x0 - bw * .8} 199`, stroke: R.dk, 'stroke-width': 3, opacity: u }, g);
    T(g, 180, 30, u < .2 ? 'লার্ভায় নটোকর্ড ও লেজ' : u < 1 ? 'আটকে গিয়ে লেজ শোষিত হচ্ছে…' : 'পরিণত: নটোকর্ড নেই, স্থির থলি', { fs: 10.5, a: 'middle', w: 700, c: C.fg });
  }
}));

/* ═════════ ৩. কর্ডাটার শ্রেণিবিন্যাস ═════════ */
V.chordataTree = Object.assign({
  t: 'কর্ডাটা পর্বের শ্রেণিবিন্যাস', k: ['tree', 'int'],
  cap: 'কর্ডাটা তিন উপপর্বে — ইউরোকর্ডাটা, সেফালোকর্ডাটা ও ভার্টিব্রাটা (মেরুদণ্ডী)। মেরুদণ্ডীরা চোয়ালহীন (অ্যাগনাথা) ও চোয়ালযুক্ত (ন্যাথোস্টোমাটা) — দুই দলে। বিভিন্ন পাঠ্যবইয়ে শ্রেণির নাম ও সংখ্যায় কিছু পার্থক্য আছে (যেমন Osteichthyes কে Actinopterygii ও Sarcopterygii তে ভাগ করা)। শাখায় চাপ দাও।'
}, BK.tree({
  t: 'কর্ডাটা', en: 'Chordata', d: 'নটোকর্ড, পৃষ্ঠীয় ফাঁপা স্নায়ুরজ্জু, গলবিলীয় ফুলকাছিদ্র, পায়ু-পরবর্তী লেজ।',
  c: [
    { t: 'ইউরোকর্ডাটা', en: 'Urochordata', d: 'নটোকর্ড কেবল লার্ভার লেজে; টিউনিকে ঢাকা — Herdmania, Ascidia।' },
    { t: 'সেফালোকর্ডাটা', en: 'Cephalochordata', d: 'নটোকর্ড মাথা থেকে লেজ পর্যন্ত সারাজীবন — Branchiostoma।' },
    { t: 'ভার্টিব্রাটা', en: 'Vertebrata', d: 'নটোকর্ডের বদলে মেরুদণ্ড (কশেরুকা), করোটিতে আবৃত মস্তিষ্ক।', c: [
      { t: 'অ্যাগনাথা (চোয়ালহীন)', en: 'Agnatha', d: 'চোয়াল ও জোড় পাখনা নেই।', c: [{ t: 'Petromyzontida — লামপ্রে (Petromyzon)' }, { t: 'Myxini — হ্যাগফিশ' }] },
      { t: 'ন্যাথোস্টোমাটা (চোয়ালযুক্ত)', en: 'Gnathostomata', d: 'চোয়াল ও জোড় উপাঙ্গ আছে।', c: [{ t: 'Chondrichthyes — হাঙর, শাপলাপাতা মাছ' }, { t: 'Actinopterygii — রুই, ইলিশ, কই' }, { t: 'Sarcopterygii — ফুসফুস-মাছ, সিলাকান্থ' }, { t: 'Amphibia — ব্যাঙ, স্যালামান্ডার' }, { t: 'Reptilia — সাপ, টিকটিকি, কচ্ছপ, কুমির' }, { t: 'Aves — পাখি' }, { t: 'Mammalia — স্তন্যপায়ী' }] }
    ] }
  ]
}, { collapse: false }));

/* ═════════ ৪. তরুণাস্থিময় ও অস্থিময় মাছ ═════════ */
const FSH = {
  chond: [[54, 128, 0, '<b>অঙ্কীয় মুখ</b> — তুণ্ডের নিচে, আড়াআড়ি।'], [116, 112, 1, '<b>5–7 জোড়া খোলা ফুলকাছিদ্র</b> — কানকো (অপারকুলাম) নেই।'], [310, 96, 2, '<b>হেটেরোসার্কাল লেজ</b> — ওপরের খণ্ড বড়, মেরুদণ্ড ওপরের খণ্ডে ঢোকে।'], [200, 118, 3, '<b>প্ল্যাকয়েড আঁশ</b> — দাঁতের মতো ক্ষুদ্র আঁশ; ত্বক খসখসে।'], [180, 70, 4, '<b>তরুণাস্থির কঙ্কাল; বায়ুথলি নেই</b> — ডুবে না যেতে সাঁতরাতে হয়, যকৃতের তেল ভাসতে সাহায্য করে।']],
  oste: [[54, 120, 0, '<b>প্রান্তীয় মুখ</b> — তুণ্ডের সামনে।'], [110, 120, 1, '<b>কানকো (অপারকুলাম)</b> — চার জোড়া ফুলকা ঢেকে রাখে।'], [310, 120, 2, '<b>হোমোসার্কাল লেজ</b> — ওপর-নিচ দুই খণ্ড সমান।'], [200, 130, 3, '<b>সাইক্লয়েড বা টিনয়েড আঁশ</b> — পাতলা, পরস্পরের ওপর সাজানো।'], [190, 104, 4, '<b>বায়ুথলি ও অস্থিময় কঙ্কাল</b> — বায়ুথলি দিয়ে পানিতে ভাসমানতা নিয়ন্ত্রণ।']]
};
V.fishTypes = Object.assign({}, B.seg({
  id: 'fsh', t: 'তরুণাস্থিময় ও অস্থিময় মাছ', H: 220, def: 'chond', sel: null,
  cap: 'মাছ মেরুদণ্ডীদের মধ্যে সবচেয়ে বৈচিত্র্যময় দল। কঙ্কাল তরুণাস্থির হলে Chondrichthyes (হাঙর — Scoliodon), অস্থির হলে Actinopterygii (রুই — Labeo rohita, ইলিশ — Tenualosa ilisha)। অংশে চাপ দাও।',
  types: {
    chond: ['তরুণাস্থিময়', 'হাঙর (Scoliodon) — Chondrichthyes', 'অধিকাংশ সামুদ্রিক; অন্তঃনিষেক — পুরুষের শ্রোণি পাখনায় ক্ল্যাস্পার।'],
    oste: ['অস্থিময়', 'রুই (Labeo rohita) — Actinopterygii', 'মিঠা ও লোনা দুই পানিতেই; অধিকাংশে বহিঃনিষেক।']
  },
  art(g, C, ty, ctx) {
    const ch = ty === 'chond', R = BK.ramp(ch ? 9 : 5);
    if (ch) {
      E('path', { d: 'M40 116Q60 88 140 86L170 52L196 86Q260 90 296 104L320 64L326 104L318 116L330 146L296 120Q240 140 140 140Q70 140 40 116Z', fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4, 'stroke-linejoin': 'round' }, g);
      E('path', { d: 'M50 128Q60 132 74 128', fill: 'none', stroke: C.fg, 'stroke-width': 2 }, g);
      for (let i = 0; i < 5; i++) E('path', { d: `M${104 + i * 7} 104q3 10 0 20`, fill: 'none', stroke: C.fg, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M130 138l-14 26l30 -24M240 132l6 16l12 -14', fill: FK.alpha(R.c, .3), stroke: R.dk }, g);
      for (let i = 0; i < 40; i++) E('path', { d: `M${150 + rnd(i) * 120} ${100 + rnd(i + 3) * 30}l3 -2l1 3z`, fill: R.dk, opacity: .4 }, g);
    } else {
      E('path', { d: 'M40 120Q70 82 160 80Q250 84 288 116L330 84Q320 120 330 156L288 124Q250 156 160 160Q70 158 40 120Z', fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4, 'stroke-linejoin': 'round' }, g);
      E('path', { d: 'M104 96Q124 120 104 146', fill: 'none', stroke: R.dk, 'stroke-width': 2 }, g); E('circle', { cx: 72, cy: 110, r: 5, fill: C.fg }, g);
      E('ellipse', { cx: 190, cy: 104, rx: 40, ry: 9, fill: FK.alpha(BK.ramp(6).c, .4), stroke: BK.ramp(6).dk, 'stroke-dasharray': '3 2' }, g);
      for (let r = 0; r < 4; r++) for (let i = 0; i < 9; i++) E('path', { d: `M${140 + i * 14 + (r % 2) * 7} ${118 + r * 9}a6 5 0 0 1 8 0`, fill: 'none', stroke: FK.alpha(R.dk, .5), 'stroke-width': .8 }, g);
      E('path', { d: 'M170 82l20 -26l20 26', fill: FK.alpha(R.c, .3), stroke: R.dk }, g);
    }
    (FSH[ty] || []).forEach(([x, y, i]) => ring(g, x, y, 13, i, ctx));
    T(g, 180, 200, ch ? 'তরুণাস্থি · প্ল্যাকয়েড আঁশ · খোলা ফুলকাছিদ্র · বায়ুথলি নেই' : 'অস্থি · সাইক্লয়েড আঁশ · কানকো · বায়ুথলি', { fs: 9.6, a: 'middle', w: 650, c: C.fg });
  },
  anim(g, C, ty, t) { if (!t) return; const w = Math.sin(t * 4) * 8, ch = ty === 'chond'; E('path', { d: ch ? `M296 104L${320 + w} 64L326 104L318 116L${330 + w} 146L296 120` : `M288 116L${330 + w} 84Q320 120 ${330 + w} 156L288 124`, fill: FK.alpha(BK.ramp(ch ? 9 : 5).c, .45), stroke: BK.ramp(ch ? 9 : 5).dk }, g); },
  tap(x, y, ty, ctx) { return pick(ctx, FSH[ty], x, y, 26); }
}));

/* ═════════ ৫. হৃৎপিণ্ডের প্রকোষ্ঠ ═════════ */
const HRT = {
  fish: ['মাছ', '2 প্রকোষ্ঠ — 1 অলিন্দ, 1 নিলয়', 'একক সংবহন: হৃৎপিণ্ড → ফুলকা → দেহ → হৃৎপিণ্ড; হৃৎপিণ্ডে কেবল অক্সিজেনবিহীন রক্ত (ভেনাস হার্ট)।'],
  amp: ['উভচর', '3 প্রকোষ্ঠ — 2 অলিন্দ, 1 নিলয়', 'দ্বি-সংবহনের সূচনা; নিলয়ে অক্সিজেনযুক্ত ও অক্সিজেনবিহীন রক্ত আংশিক মিশে যায়; ত্বকেও শ্বসন হয় বলে চলে যায়।'],
  rep: ['সরীসৃপ', '3 প্রকোষ্ঠ — নিলয়ে অসম্পূর্ণ প্রাচীর', 'নিলয়ের অসম্পূর্ণ প্রাচীর রক্ত মেশা কমায়। কুমিরে প্রাচীর সম্পূর্ণ — 4 প্রকোষ্ঠ।'],
  mam: ['পাখি ও স্তন্যপায়ী', '4 প্রকোষ্ঠ — 2 অলিন্দ, 2 নিলয়', 'পূর্ণ দ্বি-সংবহন: ডান দিকে অক্সিজেনবিহীন রক্ত ফুসফুসে, বাঁ দিকে অক্সিজেনযুক্ত রক্ত দেহে — রক্ত মেশে না; উষ্ণরক্তের উচ্চ বিপাকের জন্য অপরিহার্য।']
};
V.heartChambers = Object.assign({}, B.seg({
  id: 'hrt', t: 'মেরুদণ্ডীদের হৃৎপিণ্ডের প্রকোষ্ঠ', H: 232, def: 'fish',
  cap: 'মেরুদণ্ডীদের বিবর্তনে হৃৎপিণ্ডের প্রকোষ্ঠ 2 থেকে 4 এ পৌঁছেছে এবং অক্সিজেনযুক্ত (লাল) ও অক্সিজেনবিহীন (নীল) রক্তের পৃথকীকরণ ক্রমে সম্পূর্ণ হয়েছে। চালাও চাপলে রক্তের প্রবাহ দেখবে।',
  types: { fish: ['মাছ', HRT.fish[1], HRT.fish[2]], amp: ['উভচর', HRT.amp[1], HRT.amp[2]], rep: ['সরীসৃপ', HRT.rep[1], HRT.rep[2]], mam: ['পাখি-স্তন্যপায়ী', HRT.mam[1], HRT.mam[2]] },
  art(g, C, ty) {
    const Rr = BK.ramp(4), Rb = BK.ramp(1), cx = 130;
    const box = (x, y, w, h, R, s, a = .35) => { E('rect', { x, y, width: w, height: h, rx: 12, fill: FK.alpha(R.c, a), stroke: R.dk, 'stroke-width': 1.4 }, g); T(g, x + w / 2, y + h / 2 + 4, s, { fs: 10, a: 'middle', w: 700, c: R.ink }); };
    if (ty === 'fish') { box(cx - 40, 50, 80, 50, Rb, 'অলিন্দ'); box(cx - 40, 110, 80, 60, Rb, 'নিলয়'); }
    else if (ty === 'amp') { box(cx - 76, 50, 72, 50, Rb, 'ডান অলিন্দ'); box(cx + 4, 50, 72, 50, Rr, 'বাম অলিন্দ'); E('rect', { x: cx - 76, y: 110, width: 152, height: 66, rx: 14, fill: BK.lg(g.ownerSVGElement, FK.alpha(Rb.c, .4), FK.alpha(Rr.c, .4), { a: 0 }), stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g); T(g, cx, 147, 'একটি নিলয় — রক্ত মেশে', { fs: 10, a: 'middle', w: 700, c: BK.ramp(3).ink }); }
    else { box(cx - 76, 50, 72, 50, Rb, 'ডান অলিন্দ'); box(cx + 4, 50, 72, 50, Rr, 'বাম অলিন্দ'); box(cx - 76, 110, 72, 66, Rb, 'ডান নিলয়'); box(cx + 4, 110, 72, 66, Rr, 'বাম নিলয়'); E('path', { d: `M${cx} 110V${ty === 'rep' ? 150 : 176}`, stroke: C.fg, 'stroke-width': 4 }, g); if (ty === 'rep') T(g, cx, 192, 'প্রাচীর অসম্পূর্ণ', { fs: 9.4, a: 'middle', c: BK.ramp(3).ink }); }
    const ink = C.mu, blu = Rb.dk, red = Rr.dk;
    if (ty === 'fish') { arrow(g, cx - 90, 40, cx - 42, 66, blu, { w: 2.2 }); T(g, cx - 92, 32, 'দেহ থেকে', { fs: 9, a: 'middle', c: ink }); arrow(g, cx + 40, 150, cx + 92, 190, blu, { w: 2.2 }); T(g, cx + 94, 206, 'ফুলকায় → দেহে', { fs: 9, a: 'middle', c: ink }); }
    else { arrow(g, cx - 100, 30, cx - 70, 52, blu, { w: 2.2 }); T(g, cx - 96, 22, 'দেহ থেকে', { fs: 9, a: 'middle', c: ink }); arrow(g, cx + 100, 30, cx + 70, 52, red, { w: 2.2 }); T(g, cx + 96, 22, ty === 'amp' ? 'ফুসফুস-ত্বক থেকে' : 'ফুসফুস থেকে', { fs: 9, a: 'middle', c: ink });
      if (ty === 'amp') { arrow(g, cx, 176, cx, 206, BK.ramp(3).dk, { w: 2.2 }); T(g, cx + 6, 220, 'ফুসফুস ও দেহে (মিশ্র)', { fs: 9, a: 'middle', c: ink }); }
      else { arrow(g, cx - 40, 176, cx - 70, 206, blu, { w: 2.2 }); T(g, cx - 76, 220, 'ফুসফুসে', { fs: 9, a: 'middle', c: ink }); arrow(g, cx + 40, 176, cx + 70, 206, red, { w: 2.2 }); T(g, cx + 76, 220, 'দেহে', { fs: 9, a: 'middle', c: ink }); } }
    T(g, 300, 76, HRT[ty][0], { fs: 13, a: 'middle', w: 800, c: C.fg }); T(g, 300, 98, { fish: '2', amp: '3', rep: '3 (কুমিরে 4)', mam: '4' }[ty] + ' প্রকোষ্ঠ', { fs: 11, a: 'middle', w: 700, c: BK.ramp(3).ink });
    T(g, 300, 122, ty === 'fish' ? 'একক সংবহন' : 'দ্বি-সংবহন', { fs: 10, a: 'middle', c: C.mu });
    E('rect', { x: 256, y: 150, width: 12, height: 12, rx: 3, fill: Rr.c }, g); T(g, 274, 160, 'অক্সিজেনযুক্ত', { fs: 9, c: C.fg }); E('rect', { x: 256, y: 170, width: 12, height: 12, rx: 3, fill: Rb.c }, g); T(g, 274, 180, 'অক্সিজেনবিহীন', { fs: 9, c: C.fg });
  },
  anim(g, C, ty, t) {
    if (!t) return; const cx = 130;
    const dot = (x, y, R) => E('circle', { cx: x, cy: y, r: 3.4, fill: R.dk }, g);
    for (let i = 0; i < 4; i++) { const k = (t * .5 + i / 4) % 1;
      if (ty === 'fish') dot(cx, 50 + k * 120, BK.ramp(1));
      else if (ty === 'amp') { dot(cx - 40, 50 + k * 120, BK.ramp(1)); dot(cx + 40 - 24 * Math.max(0, (k - .5) / .5), 50 + k * 120, BK.ramp(4)); }
      else { dot(cx - 40, 50 + k * 120, BK.ramp(1)); dot(cx + 40, 50 + k * 120, BK.ramp(4)); } }
  }
}));

/* ═════════ ৬. মেরুদণ্ডী শ্রেণির কার্ড ═════════ */
const VC = [
  ['lamprey', 'অ্যাগনাথা', 9, 'চোয়ালহীন; গোল চোষক-মুখে শিঙের দাঁত; 7 জোড়া ফুলকাছিদ্র; জোড় পাখনা ও আঁশ নেই — লামপ্রে (Petromyzon)।'],
  ['shark', 'তরুণাস্থিময় মাছ', 9, 'তরুণাস্থির কঙ্কাল, প্ল্যাকয়েড আঁশ, অঙ্কীয় মুখ, খোলা ফুলকাছিদ্র, বায়ুথলি নেই — হাঙর (Scoliodon)।'],
  ['fish', 'অস্থিময় মাছ', 5, 'অস্থির কঙ্কাল, কানকো, সাইক্লয়েড-টিনয়েড আঁশ, বায়ুথলি — রুই, ইলিশ, কই।'],
  ['frog', 'উভচর', 10, 'আর্দ্র গ্রন্থিময় আঁশহীন ত্বক; ত্বক-শ্বসন; 3 প্রকোষ্ঠী হৃৎপিণ্ড; ব্যাঙাচি থেকে রূপান্তর; খোলসহীন ডিম পানিতে — কোলা ব্যাঙ (Hoplobatrachus tigerinus), কুনো ব্যাঙ।'],
  ['lizard', 'সরীসৃপ', 11, 'শুষ্ক, শৃঙ্গময় আঁশ; কেবল ফুসফুসে শ্বসন; খোলসযুক্ত অ্যামনিওটিক ডিম; শীতল রক্ত — গোখরা (Naja naja), টিকটিকি, কচ্ছপ, কুমির।'],
  ['bird', 'পাখি', 2, 'পালক, ডানা, দাঁতহীন চঞ্চু, ফাঁপা হাড়, বায়ুথলি, 4 প্রকোষ্ঠী হৃৎপিণ্ড, উষ্ণরক্ত, ডিম পাড়ে — কবুতর (Columba livia), কাক।'],
  ['mammal', 'স্তন্যপায়ী', 4, 'লোম, স্তনগ্রন্থি, বহিঃকর্ণ (পিনা), মধ্যচ্ছদা, 4 প্রকোষ্ঠী হৃৎপিণ্ড, পরিণত লোহিত কণিকা নিউক্লিয়াসবিহীন, উষ্ণরক্ত — মানুষ, গরু, বাদুড়, তিমি।'],
  ['turtle', 'অ্যামনিওট', 3, 'সরীসৃপ, পাখি ও স্তন্যপায়ী — এ তিন দলের ভ্রূণ অ্যামনিয়ন ঝিল্লিতে ঘেরা; তাই এরা অ্যামনিওট, স্থলে ডিম পাড়া বা গর্ভধারণ সম্ভব।']
];
V.vertClasses = Object.assign({}, B.seg({
  id: 'vcl', t: 'মেরুদণ্ডীদের প্রধান দল', H: 236, def: 'all', sel: null,
  cap: 'মেরুদণ্ডীদের প্রধান শ্রেণিগুলো এক নজরে। কার্ডে চাপ দিলে শনাক্তকারী বৈশিষ্ট্য ও উদাহরণ দেখবে; শেষ কার্ডে অ্যামনিওট ধারণা।',
  types: { all: ['শ্রেণি', 'মেরুদণ্ডীদের প্রধান দল', 'কার্ডে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    VC.forEach(([k, n, ri], i) => { const col = i % 4, row = Math.floor(i / 4), x = 10 + col * 86, y = 12 + row * 110, R = BK.ramp(ri), on = ctx.sel === i;
      E('rect', { x, y, width: 80, height: 100, rx: 12, fill: FK.alpha(R.c, on ? .35 : .12), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      ani(g, k, x + 40, y + 44, 1.35, { R }); T(g, x + 40, y + 88, n, { fs: 9.2, a: 'middle', w: 700, c: R.ink }); });
  },
  anim(g, C, ty, t) { if (!t) return; const i = Math.floor(t * .5) % 8, x = 10 + (i % 4) * 86, y = 12 + Math.floor(i / 4) * 110; E('rect', { x: x - 2, y: y - 2, width: 84, height: 104, rx: 13, fill: 'none', stroke: BK.ramp(VC[i][2]).dk, 'stroke-width': 2, opacity: .6 }, g); },
  tap(x, y, ty, ctx) { const col = Math.floor((x - 10) / 86), row = Math.floor((y - 12) / 110), i = row * 4 + col; if (col < 0 || col > 3 || row < 0 || row > 1) return ''; ctx.sel = i; return `<b>${VC[i][1]}</b> — ${VC[i][3]}`; }
}));

/* ═════════ ৭. ব্যাঙের রূপান্তর ═════════ */
V.frogMeta = Object.assign({ t: 'ব্যাঙের রূপান্তর (মেটামরফোসিস)', k: ['anim', 'steps'], cap: 'উভচরের জীবন দুই পরিবেশে — লার্ভা (ব্যাঙাচি) জলজ, মাছের মতো ফুলকায় শ্বাস নেয়; পরিণত ব্যাঙ ফুসফুস ও ত্বকে শ্বাস নেয়, স্থলেও থাকে। ব্যাঙাচি থেকে ব্যাঙে এ রূপান্তর থাইরক্সিন হরমোন নিয়ন্ত্রণ করে।' }, BK.steps({
  W: 360, H: 200, label: 'ব্যাঙের রূপান্তর', dur: 2.6,
  stages: [
    { t: 'ডিম', en: 'Spawn', d: 'জেলির মতো আবরণে ঢাকা ডিমের গুচ্ছ পানিতে; নিষেক বাহ্যিক।' },
    { t: 'বহিঃফুলকাযুক্ত ব্যাঙাচি', en: 'External gills', d: 'ডিম ফুটে ব্যাঙাচি বেরোয়; মাথার দুই পাশে শাখান্বিত বাইরের ফুলকা।' },
    { t: 'অন্তঃফুলকা', en: 'Internal gills', d: 'ফুলকা চামড়ার ভাঁজে (অপারকুলাম) ঢেকে যায়; শৈবাল খায় — তৃণভোজী।' },
    { t: 'পশ্চাৎপদ', en: 'Hind limbs', d: 'প্রথমে পেছনের পা গজায়।' },
    { t: 'অগ্রপদ ও ফুসফুস', en: 'Fore limbs', d: 'সামনের পা বেরোয়; ফুসফুস তৈরি হয়, ফুলকা লোপ পায়; পানির ওপরে এসে বাতাস নেয়।' },
    { t: 'লেজ শোষণ — ব্যাঙ', en: 'Froglet', d: 'লেজ শোষিত হয়ে ছোট ব্যাঙ; খাদ্যাভ্যাস বদলে পতঙ্গভুক — মাংসাশী।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), cx = 150, cy = 100, f = FK.alpha(R.c, .4), g0 = g;
    E('path', { d: 'M0 170H360', stroke: BK.ramp(5).c, 'stroke-width': 2, opacity: .5 }, g);
    T(g0, 300, 40, ['', 'বহিঃফুলকা', 'অন্তঃফুলকা', 'পেছনের পা', 'সামনের পা, ফুসফুস', ''][s], { fs: 10.5, a: 'middle', w: 700, c: C.fg });
    g = E('g', { transform: 'translate(150 100) scale(1.6) translate(-150 -100)' }, g);
    if (s === 0) { for (let i = 0; i < 9; i++) { const x = cx - 30 + (i % 3) * 30, y = cy - 20 + Math.floor(i / 3) * 24; E('circle', { cx: x, cy: y, r: 11, fill: FK.alpha(BK.ramp(5).c, .2), stroke: BK.ramp(5).dk }, g); E('circle', { cx: x, cy: y, r: 4 + u, fill: C.fg }, g); } return; }
    if (s === 5) { ani(g, 'frog', cx, cy, 2.6 - 0 * u, { R }); if (u < 1) E('path', { d: `M${cx - 18} ${cy + 16}q-20 10 ${-30 * (1 - u)} 0`, fill: 'none', stroke: R.dk, 'stroke-width': 6 * (1 - u) }, g); return; }
    E('ellipse', { cx, cy, rx: 22, ry: 16, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g);
    E('path', { d: `M${cx + 20} ${cy}q30 ${-10 * Math.sin(u * 6)} 60 0q-30 8 -60 6z`, fill: f, stroke: R.dk }, g);
    E('circle', { cx: cx - 10, cy: cy - 6, r: 2.6, fill: C.fg }, g);
    if (s === 1) [-1, 1].forEach(k => { for (let i = 0; i < 3; i++) E('path', { d: `M${cx - 4} ${cy + k * 12}l${-6 + i * 4} ${k * (10 + i * 2)}`, stroke: BK.ramp(4).dk, 'stroke-width': 1.4 }, g); });
    if (s >= 3) E('path', { d: `M${cx + 14} ${cy + 12}l${8 + 6 * (s === 3 ? u : 1)} ${10 + 8 * (s === 3 ? u : 1)}l8 2`, fill: 'none', stroke: R.dk, 'stroke-width': 2.4 }, g);
    if (s >= 4) E('path', { d: `M${cx - 12} ${cy + 12}l${-6 * u - 2} ${10 * u + 2}`, fill: 'none', stroke: R.dk, 'stroke-width': 2.2 }, g);
  }
}));

/* ═════════ ৮. অ্যামনিওটিক ডিম ═════════ */
const EGG = [[170, 18, 0, '<b>খোলস</b> — পাখিতে চুনময় (CaCO<sub>3</sub>), অনেক সরীসৃপে চামড়ার মতো নমনীয়; ছিদ্রযুক্ত — গ্যাস আদান-প্রদান হয়, কিন্তু পানি কম হারায়।'], [148, 96, 1, '<b>অ্যামনিয়ন</b> — ভ্রূণ ঘিরে তরলপূর্ণ থলি; আঘাত ও শুকিয়ে যাওয়া থেকে রক্ষা করে — ভ্রূণের "নিজস্ব পুকুর"।'], [214, 80, 2, '<b>অ্যালানটয়েস</b> — নাইট্রোজেন বর্জ্য (ইউরিক অ্যাসিড) জমা রাখে; কোরিয়নের সাথে মিলে গ্যাস বিনিময়ে অংশ নেয়।'], [166, 152, 3, '<b>কুসুমথলি</b> — কুসুম বা খাদ্যভান্ডার ঘিরে রাখে; রক্তনালি দিয়ে ভ্রূণে পুষ্টি পাঠায়।'], [82, 140, 4, '<b>কোরিয়ন</b> — সব ঝিল্লিকে ঘিরে থাকা বাইরের ঝিল্লি; খোলসের নিচে গ্যাস বিনিময়।'], [100, 60, 5, '<b>অ্যালবুমিন (সাদা অংশ)</b> — পানি ও প্রোটিনের ভান্ডার।']];
V.amnioteEgg = Object.assign({}, B.seg({
  id: 'egg', t: 'অ্যামনিওটিক ডিম — স্থলে প্রজননের চাবি', H: 220, def: 'egg', sel: null,
  cap: 'সরীসৃপ, পাখি ও ডিম পাড়া স্তন্যপায়ীর ডিমে ভ্রূণ চারটি বহির্ভ্রূণীয় ঝিল্লিতে (অ্যামনিয়ন, কোরিয়ন, অ্যালানটয়েস, কুসুমথলি) সুরক্ষিত। এ ডিম শুকনো স্থলে পাড়া যায় — উভচরের মতো প্রজননের জন্য পানিতে ফিরতে হয় না। অংশে চাপ দাও; চালাও চাপলে খোলসের ছিদ্র দিয়ে গ্যাস বিনিময় দেখবে।',
  types: { egg: ['ডিম', 'অ্যামনিওটিক ডিমের গঠন', 'অ্যামনিয়ন থাকে বলে সরীসৃপ, পাখি ও স্তন্যপায়ী — অ্যামনিওট; মাছ ও উভচর — অ্যানামনিওট।'] },
  art(g, C, ty, ctx) {
    const cx = 170, cy = 110;
    E('ellipse', { cx, cy, rx: 112, ry: 92, fill: FK.alpha(BK.ramp(6).c, .14), stroke: BK.ramp(6).dk, 'stroke-width': 5 }, g);
    E('ellipse', { cx, cy, rx: 100, ry: 80, fill: FK.alpha('#ffffff', .5), stroke: BK.ramp(0).dk, 'stroke-dasharray': '5 3', 'stroke-width': 1.4 }, g);
    E('circle', { cx: 166, cy: 150, r: 30, fill: FK.alpha(BK.ramp(2).c, .55), stroke: BK.ramp(2).dk, 'stroke-width': 1.4 }, g);
    E('ellipse', { cx: 214, cy: 80, rx: 28, ry: 20, fill: FK.alpha(BK.ramp(10).c, .35), stroke: BK.ramp(10).dk, 'stroke-width': 1.4 }, g);
    E('ellipse', { cx: 148, cy: 96, rx: 38, ry: 28, fill: FK.alpha(BK.ramp(5).c, .3), stroke: BK.ramp(5).dk, 'stroke-width': 1.4 }, g);
    E('path', { d: 'M132 102q4 -22 24 -16q12 8 2 20q-6 6 -14 2q-4 -2 -6 4', fill: FK.alpha(BK.ramp(4).c, .5), stroke: BK.ramp(4).dk, 'stroke-width': 1.2 }, g);
    E('path', { d: 'M152 108Q160 118 160 122M162 92Q186 84 190 82', stroke: BK.ramp(4).dk, 'stroke-width': 1.4, fill: 'none' }, g);
    lab(g, 268, 60, 300, 26, 'খোলস', C, { fs: 9.8 }); lab(g, 236, 78, 300, 64, 'অ্যালানটয়েস', C, { fs: 9.8 }); lab(g, 262, 130, 296, 150, 'কোরিয়ন', C, { fs: 9.8 });
    lab(g, 120, 92, 52, 22, 'অ্যামনিয়ন', C, { fs: 9.8 }); lab(g, 92, 66, 40, 60, 'অ্যালবুমিন', C, { fs: 9.8 }); lab(g, 150, 160, 70, 208, 'কুসুমথলি', C, { fs: 9.8 }); lab(g, 146, 96, 96, 190, 'ভ্রূণ', C, { fs: 9.8, a: 'end' });
    EGG.forEach(([x, y, i]) => ring(g, x, y, 14, i, ctx));
  },
  anim(g, C, ty, t) {
    if (!t) return; const k = .5 + .5 * Math.sin(t * 5);
    E('circle', { cx: 150, cy: 92, r: 2.6 + k * 1.4, fill: BK.ramp(4).dk, opacity: .7 }, g);
    for (let i = 0; i < 8; i++) { const a = i / 8 * 2 * PI + .3, u = (t * .5 + i * .37) % 1, inw = i % 2 === 0, r = inw ? 1.12 - u * .2 : .92 + u * .2;
      E('circle', { cx: 170 + 112 * r * Math.cos(a), cy: 110 + 92 * r * Math.sin(a), r: 2.2, fill: inw ? BK.ramp(4).c : BK.ramp(1).c, opacity: 1 - Math.abs(u - .5) }, g); }
    T(g, 300, 186, 'O<sub>2</sub> ভেতরে', { fs: 9, c: BK.ramp(4).ink }); T(g, 300, 200, 'CO<sub>2</sub> বাইরে', { fs: 9, c: BK.ramp(1).ink });
  },
  tap(x, y, ty, ctx) { return pick(ctx, EGG, x, y, 30); }
}));

/* ═════════ ৯. পাখির উড্ডয়ন অভিযোজন ═════════ */
const BRD = [[150, 52, 0, '<b>পালক ও ডানা</b> — অগ্রপদ ডানায় রূপান্তরিত; হালকা, বায়ুরোধী পালকের তল বাতাসে ভর দেয় ও দেহের তাপ ধরে রাখে।'], [188, 118, 1, '<b>ফাঁপা (নিউম্যাটিক) হাড়</b> — ভেতরে বাতাস, বায়ুথলির সাথে যুক্ত; কঙ্কাল হালকা কিন্তু মজবুত।'], [176, 156, 2, '<b>কিলযুক্ত উরঃফলক (স্টারনাম)</b> — নৌকার তলির মতো কিল; শক্তিশালী উড্ডয়ন পেশি (পেক্টোরালিস) আটকে থাকে।'], [226, 128, 3, '<b>বায়ুথলি</b> — ফুসফুসের সাথে যুক্ত; ফুসফুসে একমুখী বায়ুপ্রবাহ ঘটিয়ে উচ্চ বিপাকের জন্য বেশি অক্সিজেন দেয়।'], [316, 104, 4, '<b>দাঁতহীন চঞ্চু</b> — মাথা হালকা; খাদ্য পেষার কাজ করে গিজার্ড।'], [62, 120, 5, '<b>লেজের পালক</b> — দিক পরিবর্তন ও ব্রেক; সাথে মূত্রথলি নেই এবং স্ত্রীতে সাধারণত কেবল বাম ডিম্বাশয় — ওজন কমায়।']];
V.birdFlight = Object.assign({}, B.seg({
  id: 'brd', t: 'পাখির উড্ডয়ন অভিযোজন', H: 220, def: 'b', sel: null,
  cap: 'পাখির (Aves) দেহের প্রায় প্রতিটি বৈশিষ্ট্য ওড়ার জন্য অভিযোজিত — দেহ হালকা করা, শক্তিশালী পেশি ও প্রচুর অক্সিজেন সরবরাহ। সাথে উষ্ণরক্ত ও 4 প্রকোষ্ঠী হৃৎপিণ্ড উচ্চ বিপাক সামলায়। অংশে চাপ দাও; চালাও চাপলে ডানা ঝাপটাবে।',
  types: { b: ['কবুতর', 'কবুতর (Columba livia)', 'মাকু আকৃতির (স্ট্রিমলাইন্ড) দেহ বাতাসের বাধা কমায়।'] },
  art(g, C, ty, ctx) {
    const R = BK.ramp(2);
    E('path', { d: 'M86 118L34 104L40 120L32 136L86 128Z', fill: FK.alpha(R.c, .35), stroke: R.dk, 'stroke-linejoin': 'round' }, g);
    for (let i = 0; i < 4; i++) E('path', { d: `M84 ${120 + i * 2 - 2}L${40 + i * 2} ${108 + i * 8}`, stroke: R.dk, 'stroke-width': .7 }, g);
    E('path', { d: 'M84 124Q120 96 200 96Q250 94 276 92Q300 84 306 96L322 104L304 110Q290 124 256 136Q190 160 120 146Q92 140 84 124Z', fill: FK.alpha(R.c, .25), stroke: R.dk, 'stroke-width': 1.4, 'stroke-linejoin': 'round' }, g);
    E('path', { d: 'M304 100L326 104L304 108Z', fill: BK.ramp(6).c, stroke: BK.ramp(6).dk }, g); E('circle', { cx: 294, cy: 98, r: 3.4, fill: C.fg }, g);
    E('path', { d: 'M160 146Q176 168 200 146', fill: FK.alpha(BK.ramp(9).c, .4), stroke: BK.ramp(9).dk, 'stroke-width': 2 }, g);
    E('ellipse', { cx: 226, cy: 124, rx: 16, ry: 9, fill: FK.alpha(BK.ramp(5).c, .4), stroke: BK.ramp(5).dk, 'stroke-dasharray': '3 2' }, g);
    E('path', { d: 'M168 118h40', stroke: BK.ramp(11).dk, 'stroke-width': 6, 'stroke-linecap': 'round' }, g); for (let i = 0; i < 5; i++) E('circle', { cx: 172 + i * 8, cy: 118, r: 1.6, fill: C.sf }, g);
    E('path', { d: 'M188 150l-6 32l-8 6M188 182l6 6M208 146l4 36l-6 6M212 182l8 4', stroke: BK.ramp(6).dk, 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, g);
    BRD.forEach(([x, y, i]) => ring(g, x, y, 13, i, ctx));
  },
  _wing(g, w) {
    const R = BK.ramp(2), tipX = 112 - w * .3, tipY = 20 + w;
    E('path', { d: `M150 104Q156 ${60 + w * .4} ${tipX} ${tipY}Q170 ${40 + w * .6} 214 ${70 + w * .4}Q216 92 200 102Z`, fill: FK.alpha(R.c, .45), stroke: R.dk, 'stroke-width': 1.3, 'stroke-linejoin': 'round' }, g);
    for (let i = 0; i < 6; i++) { const u = i / 6; E('path', { d: `M${160 + u * 40} ${96 - u * 4}L${tipX + 14 + u * 70} ${tipY + 8 + u * 36 + w * .2}`, stroke: R.dk, 'stroke-width': .7, opacity: .7 }, g); }
  },
  anim(g, C, ty, t) { this._wing(g, t ? Math.sin(t * 5) * 34 : 0); },
  tap(x, y, ty, ctx) { return pick(ctx, BRD, x, y, 26); }
}));

/* ═════════ ১০. স্তন্যপায়ীর তিন দল ═════════ */
V.mammalGroups = Object.assign({}, B.seg({
  id: 'mam', t: 'স্তন্যপায়ীর তিন দল', H: 210, def: 'pro',
  cap: 'জন্মদানের ধরন অনুযায়ী স্তন্যপায়ী তিন দলে — প্রোটোথেরিয়া (ডিম পাড়ে), মেটাথেরিয়া (অপরিণত বাচ্চা থলিতে বড় হয়) ও ইউথেরিয়া (প্রকৃত অমরা — গর্ভে পূর্ণ বিকাশ)। তিন দলেই স্তনগ্রন্থি ও লোম আছে।',
  types: {
    pro: ['প্রোটোথেরিয়া', 'প্রোটোথেরিয়া — ডিম পাড়া স্তন্যপায়ী', 'হংসচঞ্চু (Ornithorhynchus) ও কাঁটাযুক্ত পিঁপড়াভুক (Tachyglossus); ক্লোয়েকা আছে; স্তনবৃন্ত নেই — দুধ ত্বকের লোমের ফাঁক দিয়ে চুইয়ে বেরোয়; কেবল অস্ট্রেলিয়া-নিউগিনিতে।'],
    met: ['মেটাথেরিয়া', 'মেটাথেরিয়া — থলিযুক্ত (মারসুপিয়াল)', 'ক্যাঙারু (Macropus), কোয়ালা, অপোসাম; খুব অপরিণত বাচ্চা জন্মে মায়ের পেটের থলিতে (মারসুপিয়াম) স্তনবৃন্ত মুখে নিয়ে বড় হয়; অমরা অল্প বিকশিত।'],
    eu: ['ইউথেরিয়া', 'ইউথেরিয়া — অমরাযুক্ত', 'মানুষ, বাঘ, গরু, বাদুড়, তিমি; ভ্রূণ জরায়ুতে প্রকৃত অমরার মাধ্যমে পুষ্টি পায় এবং বেশ পরিণত অবস্থায় জন্মায়; স্তন্যপায়ীর অধিকাংশ প্রজাতি।']
  },
  art(g, C, ty) {
    const R = BK.ramp(4), f = FK.alpha(R.c, .3), st = R.dk;
    if (ty === 'pro') {
      E('path', { d: 'M40 130Q30 114 50 108L80 106Q90 92 130 94Q180 96 196 112Q204 126 186 136Q150 146 96 140L52 142Q34 142 40 130Z', fill: FK.alpha(BK.ramp(6).c, .35), stroke: BK.ramp(6).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M196 112Q220 104 236 110Q240 118 232 122Q214 126 196 124Z', fill: FK.alpha(C.fg, .55), stroke: C.fg }, g);
      E('circle', { cx: 186, cy: 108, r: 2.6, fill: C.fg }, g);
      E('path', { d: 'M150 138l6 14l-8 4l16 0M90 138l-4 14l-8 4l16 0', fill: 'none', stroke: BK.ramp(6).dk, 'stroke-width': 2 }, g);
      lab(g, 226, 114, 250, 80, 'হাঁসের মতো চঞ্চু', C, { fs: 9.6 }); lab(g, 46, 126, 30, 80, 'চ্যাপ্টা লেজ', C, { fs: 9.6, a: 'start' }); lab(g, 158, 154, 140, 190, 'লিপ্তপদ', C, { fs: 9.6 });
      [0, 1].forEach(i => E('ellipse', { cx: 272 + i * 30, cy: 150, rx: 12, ry: 15, fill: FK.alpha(BK.ramp(6).c, .25), stroke: BK.ramp(6).dk, 'stroke-width': 1.4 }, g)); T(g, 287, 186, 'নরম খোলসের ডিম', { fs: 9.6, a: 'middle', c: C.fg });
    } else if (ty === 'met') {
      E('path', { d: 'M120 180Q96 150 110 110Q118 80 140 70Q150 50 168 48L180 40L176 56Q186 64 178 72Q166 78 158 84Q170 110 170 140Q178 168 200 180Z', fill: f, stroke: st, 'stroke-width': 1.4, 'stroke-linejoin': 'round' }, g);
      E('path', { d: 'M116 172Q80 176 40 196', fill: 'none', stroke: st, 'stroke-width': 7, 'stroke-linecap': 'round' }, g);
      E('path', { d: 'M146 92q8 10 4 20M150 96q10 6 12 14', fill: 'none', stroke: st, 'stroke-width': 2 }, g);
      E('circle', { cx: 168, cy: 58, r: 2.4, fill: C.fg }, g);
      E('path', { d: 'M128 124Q140 160 166 142Q168 128 160 122', fill: FK.alpha(BK.ramp(2).c, .45), stroke: BK.ramp(2).dk, 'stroke-width': 1.6 }, g);
      E('circle', { cx: 148, cy: 132, r: 7, fill: FK.alpha(R.c, .7), stroke: R.dk }, g); E('circle', { cx: 152, cy: 129, r: 1.4, fill: C.fg }, g);
      lab(g, 160, 140, 250, 120, 'থলি (মারসুপিয়াম)', C, { fs: 10 }); lab(g, 148, 132, 250, 150, 'অপরিণত বাচ্চা — স্তনবৃন্তে', C, { fs: 9.6 }); T(g, 250, 60, 'ক্যাঙারু', { fs: 12, w: 700, c: R.ink });
    } else {
      ani(g, 'mammal', 100, 120, 3.4, { R });
      E('ellipse', { cx: 92, cy: 124, rx: 22, ry: 18, fill: FK.alpha(BK.ramp(3).c, .3), stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M82 126q4 -12 14 -6q6 8 -2 12q-8 2 -12 -6', fill: FK.alpha(R.c, .7), stroke: R.dk }, g);
      E('path', { d: 'M96 128Q104 132 108 120', fill: 'none', stroke: BK.ramp(11).dk, 'stroke-width': 1.6 }, g);
      E('path', { d: 'M104 110q10 2 8 12q-2 6 -6 6', fill: FK.alpha(BK.ramp(4).dk, .5), stroke: BK.ramp(4).dk, 'stroke-width': 2.4 }, g);
      lab(g, 108, 114, 220, 96, 'প্রকৃত অমরা', C, { fs: 10 }); lab(g, 102, 126, 220, 124, 'নাভিরজ্জু', C, { fs: 9.6 }); lab(g, 88, 124, 220, 152, 'জরায়ুতে ভ্রূণ', C, { fs: 9.6 }); T(g, 220, 60, 'যেমন গরু, মানুষ', { fs: 11, w: 700, c: R.ink });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return; const k = .5 + .5 * Math.sin(t * 3);
    if (ty === 'eu') { for (let i = 0; i < 3; i++) { const u = (t * .6 + i / 3) % 1; E('circle', { cx: 108 - u * 12, cy: 118 + u * 8, r: 1.8, fill: BK.ramp(4).dk, opacity: 1 - u }, g); } }
    else if (ty === 'met') E('circle', { cx: 148, cy: 132 - 3 * k, r: 9, fill: 'none', stroke: BK.ramp(4).dk, opacity: .6 }, g);
    else E('ellipse', { cx: 272, cy: 150, rx: 12 + 2 * k, ry: 15 + 2 * k, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 1.6 }, g);
  }
}));

/* ═════════ ১১. দ্বিভাজী চাবি — নমুনা শনাক্তকরণ ═════════ */
const KEY = {
  q0: ['পরিণত দশায় মেরুদণ্ড (কশেরুকা) আছে?', 'c1', 'q1'],
  q1: ['জীবনের কোনো দশায় নটোকর্ড আছে?', 'p1', 'n1'],
  p1: ['নটোকর্ড মাথা থেকে লেজ পর্যন্ত সারাজীবন থাকে?', 'L:সেফালোকর্ডাটা:Branchiostoma — নটোকর্ড সারাজীবন, মাথা পর্যন্ত।', 'L:ইউরোকর্ডাটা:Herdmania — নটোকর্ড কেবল লার্ভার লেজে।'],
  n1: ['দেহে অসংখ্য ছিদ্র ও কাঁটা (স্পিকিউল)?', 'L:পরিফেরা:Scypha, Spongilla — নালিতন্ত্র ও কলার কোষ।', 'n2'],
  n2: ['কর্ষিকায় নিডোসাইট, দেহ অরীয়?', 'L:নিডারিয়া:Hydra, Obelia — দ্বিস্তরী, সিলেন্টেরন।', 'n3'],
  n3: ['পঞ্চ-অরীয় দেহ, নালিপদ ও কাঁটাযুক্ত ত্বক?', 'L:একাইনোডারমাটা:তারামাছ — পানি সংবহনতন্ত্র।', 'n4'],
  n4: ['সন্ধিযুক্ত পা ও কাইটিনের বহিঃকঙ্কাল?', 'L:আর্থ্রোপোডা:তেলাপোকা, চিংড়ি — উন্মুক্ত সংবহন।', 'n5'],
  n5: ['দেহ বহু আংটির মতো খণ্ডে বিভক্ত?', 'L:অ্যানেলিডা:কেঁচো, জোঁক — প্রকৃত খণ্ডায়ন।', 'n6'],
  n6: ['নরম অখণ্ড দেহ, ম্যান্টল ও (সাধারণত) খোলক?', 'L:মলাস্কা:শামুক, ঝিনুক — পেশিবহুল পদ।', 'n7'],
  n7: ['দেহ পৃষ্ঠ-অঙ্কীয়ভাবে চ্যাপ্টা?', 'L:প্লাটিহেলমিনথেস:যকৃৎ কৃমি, ফিতাকৃমি — অ্যাসিলোমেট।', 'L:নেমাটোডা:অ্যাসকারিস — নলাকার, সিউডোসিলোমেট।'],
  c1: ['চোয়াল আছে?', 'c2', 'L:অ্যাগনাথা:লামপ্রে — চোষক-মুখ, চোয়ালহীন।'],
  c2: ['পাখনা ও ফুলকা দিয়ে পানিতে জীবন?', 'c3', 'c4'],
  c3: ['কঙ্কাল তরুণাস্থির, ফুলকাছিদ্র খোলা (কানকো নেই)?', 'L:তরুণাস্থিময় মাছ:হাঙর — প্ল্যাকয়েড আঁশ।', 'L:অস্থিময় মাছ:রুই — কানকো ও বায়ুথলি।'],
  c4: ['দেহে পালক?', 'L:পাখি:কবুতর — ডানা, চঞ্চু।', 'c5'],
  c5: ['দেহে লোম ও স্তনগ্রন্থি?', 'L:স্তন্যপায়ী:মানুষ, গরু — বহিঃকর্ণ।', 'c6'],
  c6: ['ত্বক শুষ্ক ও আঁশযুক্ত?', 'L:সরীসৃপ:গোখরা, টিকটিকি — খোলসযুক্ত ডিম।', 'L:উভচর:ব্যাঙ — আর্দ্র আঁশহীন ত্বক।']
};
V.specimenKey = Object.assign({}, B.seg({
  id: 'key', t: 'দ্বিভাজী চাবি — পর্ব ও শ্রেণি শনাক্ত করো', H: 236, def: 'k',
  cap: 'দ্বিভাজী চাবি (dichotomous key) — প্রতিটি ধাপে দুটি বিপরীত বৈশিষ্ট্যের একটি বেছে নিয়ে ধাপে ধাপে নমুনার নাম বা দল বের করার পদ্ধতি। ব্যবহারিক খাতায় নমুনা শনাক্তে এ যুক্তিই ব্যবহার হয়। একটি নমুনা মনে রেখে "হ্যাঁ" বা "না" চাপো।',
  types: { k: ['চাবি', 'দ্বিভাজী চাবি', 'প্রশ্নের উত্তর দিয়ে এগোও; "আবার শুরু" চেপে নতুন নমুনা।'] },
  art(g, C, ty, ctx) {
    const cur = ctx.node || 'q0', path = ctx.path || [];
    T(g, 14, 22, 'পথ: ' + (path.length ? path.map(p => p[1]).join(' → ') : 'শুরু'), { fs: 9, c: C.mu });
    if (cur.startsWith('L:')) { const [, n, d] = cur.split(':'); E('rect', { x: 30, y: 50, width: 300, height: 100, rx: 16, fill: FK.alpha(BK.ramp(10).c, .2), stroke: BK.ramp(10).dk, 'stroke-width': 1.6 }, g); okm(g, 60, 84, 9, BK.ramp(10).dk); T(g, 190, 90, n, { fs: 17, a: 'middle', w: 800, c: BK.ramp(10).ink }); T(g, 180, 124, d, { fs: 10, a: 'middle', c: C.fg }); }
    else { const q = KEY[cur]; E('rect', { x: 20, y: 44, width: 320, height: 76, rx: 16, fill: FK.alpha(BK.ramp(3).c, .14), stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g); T(g, 180, 78, q[0].length > 30 ? q[0].slice(0, q[0].lastIndexOf(' ', 30)) : q[0], { fs: 12, a: 'middle', w: 700, c: C.fg }); if (q[0].length > 30) T(g, 180, 98, q[0].slice(q[0].lastIndexOf(' ', 30) + 1), { fs: 12, a: 'middle', w: 700, c: C.fg });
      E('rect', { x: 40, y: 140, width: 130, height: 40, rx: 20, fill: FK.alpha(BK.ramp(10).c, .3), stroke: BK.ramp(10).dk, 'stroke-width': 1.4 }, g); T(g, 105, 165, 'হ্যাঁ', { fs: 14, a: 'middle', w: 800, c: BK.ramp(10).ink });
      E('rect', { x: 190, y: 140, width: 130, height: 40, rx: 20, fill: FK.alpha(BK.ramp(4).c, .25), stroke: BK.ramp(4).dk, 'stroke-width': 1.4 }, g); T(g, 255, 165, 'না', { fs: 14, a: 'middle', w: 800, c: BK.ramp(4).ink }); }
    E('rect', { x: 120, y: 196, width: 120, height: 30, rx: 15, fill: FK.alpha(C.mu, .12), stroke: C.ln }, g); T(g, 180, 216, 'আবার শুরু', { fs: 11, a: 'middle', w: 700, c: C.fg });
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const cur = ctx.node || 'q0'; if (cur.startsWith('L:')) { const k = (t * .8) % 1; E('rect', { x: 30 - k * 6, y: 50 - k * 6, width: 300 + k * 12, height: 100 + k * 12, rx: 18, fill: 'none', stroke: BK.ramp(10).c, 'stroke-width': 2, opacity: 1 - k }, g); } else { const k = .5 + .5 * Math.sin(t * 3); E('rect', { x: 18, y: 42, width: 324, height: 80, rx: 17, fill: 'none', stroke: BK.ramp(3).c, 'stroke-width': 1 + k, opacity: .6 }, g); } },
  tap(x, y, ty, ctx) {
    const cur = ctx.node || 'q0';
    if (y > 192 && x > 116 && x < 244) { ctx.node = 'q0'; ctx.path = []; return 'নতুন নমুনা ভাবো — প্রথম প্রশ্ন থেকে শুরু।'; }
    if (cur.startsWith('L:') || y < 136 || y > 184) return '';
    const yes = x < 180, q = KEY[cur], nx = yes ? q[1] : q[2];
    ctx.path = (ctx.path || []).concat([[cur, yes ? 'হ্যাঁ' : 'না']]); ctx.node = nx;
    if (nx.startsWith('L:')) { const [, n, d] = nx.split(':'); return `<b>শনাক্ত: ${n}</b> — ${d}`; }
    return `পরের প্রশ্ন: ${KEY[nx][0]}`;
  }
}));

/* ═════════ ১২. ব্যবহারিক — নমুনার শনাক্তকারী বৈশিষ্ট্য ═════════ */
const LAB = {
  non: [['sponge', 'স্পঞ্জ (Scypha)', 6, 'পরিফেরা: দেহে অসংখ্য অস্টিয়া, শীর্ষে অস্কুলাম; দেহপ্রাচীরে চুনময় কাঁটা; ফুলদানির মতো আকৃতি।'], ['hydra', 'হাইড্রা', 5, 'নিডারিয়া: নলাকার দেহ, মুখ ঘিরে 6–10 কর্ষিকা, পাদচাকতি; পাশে মুকুল থাকতে পারে।'], ['fluke', 'যকৃৎ কৃমি', 4, 'প্লাটিহেলমিনথেস: পাতার মতো চ্যাপ্টা দেহ; মৌখিক ও অঙ্কীয় চোষক; অখণ্ড।'], ['tapeworm', 'ফিতাকৃমি', 7, 'প্লাটিহেলমিনথেস: ফিতার মতো লম্বা দেহ; স্কোলেক্সে চোষক ও আঁকড়া; বহু প্রোগ্লটিড।'], ['roundworm', 'অ্যাসকারিস', 11, 'নেমাটোডা: নলাকার, দুই প্রান্ত সরু, খণ্ডহীন; স্ত্রী বড় ও সোজা, পুরুষের লেজ বাঁকানো।'], ['snail', 'আপেল শামুক', 6, 'মলাস্কা (গ্যাস্ট্রোপোডা): পেঁচানো একক খোলক, অপারকুলাম; কর্ষিকা ও পদ।'], ['mussel', 'ঝিনুক', 11, 'মলাস্কা (বাইভালভিয়া): দুই পাল্লার খোলক কবজায় যুক্ত; বৃদ্ধিরেখা; মাথা নেই।'], ['earthworm', 'কেঁচো', 4, 'অ্যানেলিডা: বহু আংটির মতো খণ্ড; 14–16 খণ্ডে ক্লাইটেলাম; সিটি।'], ['leech', 'জোঁক', 11, 'অ্যানেলিডা: চ্যাপ্টা খণ্ডিত দেহ; দুই প্রান্তে চোষক; সিটি নেই।'], ['cockroach', 'তেলাপোকা', 6, 'আর্থ্রোপোডা (ইনসেক্টা): মাথা-বক্ষ-উদর; 3 জোড়া সন্ধিযুক্ত পা; 1 জোড়া অ্যান্টেনা; 2 জোড়া ডানা।'], ['prawn', 'চিংড়ি', 4, 'আর্থ্রোপোডা (ক্রাস্টেসিয়া): শিরোবক্ষ ও উদর; 2 জোড়া অ্যান্টেনা; 5 জোড়া হাঁটার পা।'], ['starfish', 'তারামাছ', 2, 'একাইনোডারমাটা: পাঁচ বাহুর তারকা আকৃতি; কাঁটাযুক্ত ত্বক; অঙ্কীয় তলে নালিপদ।']],
  cho: [['tunicate', 'হার্ডম্যানিয়া', 3, 'ইউরোকর্ডাটা: থলির মতো স্থির দেহ, টিউনিকে ঢাকা; দুটি সাইফন।'], ['lancelet', 'ব্র্যাঙ্কিওস্টোমা', 0, 'সেফালোকর্ডাটা: মাছের মতো স্বচ্ছ দেহ; V আকৃতির মায়োটোম; জোড় পাখনা নেই।'], ['shark', 'হাঙর', 9, 'তরুণাস্থিময় মাছ: অঙ্কীয় মুখ; 5 জোড়া খোলা ফুলকাছিদ্র; হেটেরোসার্কাল লেজ।'], ['fish', 'রুই', 5, 'অস্থিময় মাছ: প্রান্তীয় মুখ; কানকো; সাইক্লয়েড আঁশ; হোমোসার্কাল লেজ।'], ['frog', 'কুনো ব্যাঙ', 10, 'উভচর: আর্দ্র খসখসে গ্রন্থিময় ত্বক, আঁশ নেই; পেছনের পা বড়; ঘাড় নেই।'], ['snake', 'গোখরা (Naja naja)', 11, 'সরীসৃপ: পা নেই; শুষ্ক আঁশে ঢাকা দেহ; ফণায় চশমার মতো দাগ; বিষদাঁত।'], ['bird', 'কবুতর', 2, 'পাখি: পালকে ঢাকা দেহ; অগ্রপদ ডানা; দাঁতহীন চঞ্চু; পায়ে আঁশ।'], ['mammal', 'ইঁদুর', 4, 'স্তন্যপায়ী: লোমে ঢাকা দেহ; বহিঃকর্ণ; গোঁফ (ভাইব্রিসা); স্তনবৃন্ত; চিরবর্ধনশীল কৃন্তক দাঁত।']]
};
V.labSpecimens = Object.assign({}, B.seg({
  id: 'lab', t: 'ব্যবহারিক — সংরক্ষিত নমুনা শনাক্তকরণ', H: 262, def: 'non', sel: null,
  cap: 'ব্যবহারিক পরীক্ষায় সংরক্ষিত নমুনা দেখে তার পর্ব বা শ্রেণি এবং অন্তত তিনটি শনাক্তকারী বৈশিষ্ট্য লিখতে হয়। কার্ডে চাপ দিলে বৈশিষ্ট্যগুলো দেখবে — খাতায় লেখার আগে নিজে মনে করার চেষ্টা করো।',
  types: { non: ['ননকর্ডাটা', 'ননকর্ডাটা নমুনা', 'বারোটি নমুনা — কার্ডে চাপ দাও।'], cho: ['কর্ডাটা', 'কর্ডাটা নমুনা', 'আটটি নমুনা — কার্ডে চাপ দাও।'] },
  art(g, C, ty, ctx) {
    const L = LAB[ty], cols = 4, cw = 86, ch = ty === 'non' ? 82 : 120;
    L.forEach(([k, n, ri], i) => { const x = 10 + (i % cols) * cw, y = 6 + Math.floor(i / cols) * (ch + 4), R = BK.ramp(ri), on = ctx.sel === i;
      E('rect', { x, y, width: cw - 6, height: ch, rx: 12, fill: FK.alpha(R.c, on ? .35 : .1), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      ani(g, k, x + (cw - 6) / 2, y + ch / 2 - 8, ty === 'non' ? 1.15 : 1.5, { R }); T(g, x + (cw - 6) / 2, y + ch - 8, n, { fs: 8.8, a: 'middle', w: 700, c: R.ink }); });
  },
  anim(g, C, ty, t, ctx) { if (!t || ctx.sel == null) return; const i = ctx.sel, cw = 86, ch = ty === 'non' ? 82 : 120, x = 10 + (i % 4) * cw, y = 6 + Math.floor(i / 4) * (ch + 4), k = .5 + .5 * Math.sin(t * 4); E('rect', { x: x - 2, y: y - 2, width: cw - 2, height: ch + 4, rx: 13, fill: 'none', stroke: BK.ramp(LAB[ty][i][2]).c, 'stroke-width': 1 + 2 * k }, g); },
  tap(x, y, ty, ctx) { const cw = 86, ch = ty === 'non' ? 82 : 120, c = Math.floor((x - 10) / cw), r = Math.floor((y - 6) / (ch + 4)), i = r * 4 + c; if (c < 0 || c > 3 || i < 0 || i >= LAB[ty].length) return ''; ctx.sel = i; return `<b>${LAB[ty][i][1]}</b> — ${LAB[ty][i][3]}`; }
}));

/* ═════════ ১৩. অধ্যায়ের মানচিত্র ═════════ */
V.b2c1map = Object.assign({ t: 'অধ্যায় ১ (২য় পত্র) এর মানচিত্র', k: ['mind', 'int'], cap: 'প্রাণীর বিভিন্নতা ও শ্রেণিবিন্যাস এক নজরে — শ্রেণিকরণের ভিত্তি ও নীতি, ননকর্ডাটার আটটি পর্ব, কর্ডাটা ও ব্যবহারিক। যেকোনো শাখায় চাপ দিলে পাঠে যাবে।' }, BK.mind({
  t: 'প্রাণিবৈচিত্র্য', d: 'প্রায় 15 লক্ষ জানা প্রজাতি — শ্রেণিকরণে সাজানো।',
  c: [
    { t: 'শ্রেণিকরণের ভিত্তি', d: 'দেহগঠনের বৈশিষ্ট্য।', c: [{ t: 'প্রতিসাম্য', id: 'b2c1s1c' }, { t: 'ভ্রূণস্তর', id: 'b2c1s1d' }, { t: 'সিলোম', id: 'b2c1s1e' }, { t: 'খণ্ডায়ন', id: 'b2c1s1f' }] },
    { t: 'নীতি ও নামকরণ', d: 'স্তরক্রম ও ICZN।', c: [{ t: 'শ্রেণিকরণের নীতি', id: 'b2c1s1h' }, { t: 'বংশবৃক্ষ', id: 'b2c1s1i' }] },
    { t: 'ননকর্ডাটা', d: 'আটটি প্রধান পর্ব।', c: [{ t: 'পরিফেরা', id: 'b2c1s2a' }, { t: 'নিডারিয়া', id: 'b2c1s2b' }, { t: 'প্লাটিহেলমিনথেস', id: 'b2c1s2c' }, { t: 'নেমাটোডা', id: 'b2c1s2d' }, { t: 'মলাস্কা', id: 'b2c1s2e' }, { t: 'অ্যানেলিডা', id: 'b2c1s2f' }, { t: 'আর্থ্রোপোডা', id: 'b2c1s2g' }, { t: 'একাইনোডারমাটা', id: 'b2c1s2h' }] },
    { t: 'কর্ডাটা', d: 'নটোকর্ডধারী।', c: [{ t: 'মৌলিক বৈশিষ্ট্য', id: 'b2c1s2i' }, { t: 'প্রোটোকর্ডাটা', id: 'b2c1s2j' }, { t: 'মাছ', id: 'b2c1s2k' }, { t: 'উভচর ও সরীসৃপ', id: 'b2c1s2l' }, { t: 'পাখি ও স্তন্যপায়ী', id: 'b2c1s2m' }] },
    { t: 'ব্যবহারিক', d: 'নমুনা শনাক্তকরণ।', c: [{ t: 'ননকর্ডাটা নমুনা', id: 'b2c1s3a' }, { t: 'কর্ডাটা নমুনা', id: 'b2c1s3b' }, { t: 'দ্বিভাজী চাবি', id: 'b2c1s3c' }] }
  ]
}, { colW: 112 }));

/* ═════════ ১৪. তুলনা ═════════ */
V.cmpNonChordChord = cmp('ননকর্ডাটা বনাম কর্ডাটা', 'নটোকর্ডের উপস্থিতি ও দেহের মৌলিক নকশা।', 'ননকর্ডাটা', 'কর্ডাটা', [
  ['নটোকর্ড', 'নেই', 'জীবনের অন্তত কোনো দশায় আছে'],
  ['স্নায়ুরজ্জু', 'অঙ্কীয়, নিরেট, প্রায়ই জোড়া', 'পৃষ্ঠীয়, ফাঁপা, একক'],
  ['গলবিলীয় ফুলকাছিদ্র', 'নেই', 'আছে (অন্তত ভ্রূণে)'],
  ['হৃৎপিণ্ড (থাকলে)', 'পৃষ্ঠীয়', 'অঙ্কীয়'],
  ['পায়ু-পরবর্তী লেজ', 'নেই', 'আছে (অন্তত ভ্রূণে)'],
  ['কঙ্কাল', 'বহিঃকঙ্কাল বা নেই', 'অন্তঃকঙ্কাল (মেরুদণ্ডীতে)'],
  ['উদাহরণ', 'কেঁচো, তেলাপোকা, শামুক', 'মাছ, ব্যাঙ, মানুষ']
]);
V.cmpUroCephalo = cmp('ইউরোকর্ডাটা বনাম সেফালোকর্ডাটা', 'দুই প্রোটোকর্ডেট উপপর্ব।', 'ইউরোকর্ডাটা (Herdmania)', 'সেফালোকর্ডাটা (Branchiostoma)', [
  ['নটোকর্ড', 'কেবল লার্ভার লেজে', 'মাথা থেকে লেজ পর্যন্ত, সারাজীবন'],
  ['পরিণত দেহ', 'থলির মতো, স্থির, টিউনিকে ঢাকা', 'মাছের মতো সরু, গর্তে থাকে কিন্তু সাঁতরাতে পারে'],
  ['স্নায়ুরজ্জু', 'পরিণত অবস্থায় গ্যাংলিয়নে পরিণত', 'সারাজীবন পৃষ্ঠীয় নলাকার'],
  ['রূপান্তর', 'অধোগামী (রেট্রোগ্রেসিভ)', 'সরল, অধোগামী নয়'],
  ['খণ্ডায়ন', 'নেই', 'V আকৃতির মায়োটোমে পেশি খণ্ডিত'],
  ['লিঙ্গ', 'উভলিঙ্গ', 'একলিঙ্গ']
]);
V.cmpChondOste = cmp('তরুণাস্থিময় বনাম অস্থিময় মাছ', 'Chondrichthyes ও Actinopterygii।', 'তরুণাস্থিময় মাছ (হাঙর)', 'অস্থিময় মাছ (রুই)', [
  ['কঙ্কাল', 'তরুণাস্থির', 'অস্থির'],
  ['আঁশ', 'প্ল্যাকয়েড', 'সাইক্লয়েড বা টিনয়েড'],
  ['মুখ', 'অঙ্কীয়', 'প্রান্তীয়'],
  ['ফুলকা', '5–7 জোড়া খোলা ফুলকাছিদ্র, কানকো নেই', '4 জোড়া ফুলকা কানকোয় ঢাকা'],
  ['লেজ', 'হেটেরোসার্কাল', 'হোমোসার্কাল'],
  ['বায়ুথলি', 'নেই', 'আছে'],
  ['নিষেক', 'অন্তঃনিষেক (ক্ল্যাস্পার)', 'সাধারণত বহিঃনিষেক'],
  ['আবাস', 'অধিকাংশ সামুদ্রিক', 'মিঠা ও লোনা পানি']
]);
V.cmpAmphRept = cmp('উভচর বনাম সরীসৃপ', 'স্থলজীবনের পথে দুই ধাপ।', 'উভচর (ব্যাঙ)', 'সরীসৃপ (সাপ, টিকটিকি)', [
  ['ত্বক', 'আর্দ্র, গ্রন্থিময়, আঁশহীন', 'শুষ্ক, শৃঙ্গময় আঁশ বা স্কিউটে ঢাকা'],
  ['শ্বসন', 'ফুলকা (লার্ভা), ফুসফুস ও ত্বক', 'কেবল ফুসফুস'],
  ['হৃৎপিণ্ড', '3 প্রকোষ্ঠ', '3 প্রকোষ্ঠ, নিলয়ে অসম্পূর্ণ প্রাচীর (কুমিরে 4)'],
  ['ডিম', 'খোলসহীন, পানিতে পাড়ে', 'খোলসযুক্ত অ্যামনিওটিক, স্থলে পাড়ে'],
  ['নিষেক', 'সাধারণত বাহ্যিক', 'অন্তঃনিষেক'],
  ['রূপান্তর', 'আছে (ব্যাঙাচি থেকে)', 'নেই — সরাসরি বিকাশ'],
  ['অক্সিপিটাল কন্ডাইল', '2টি', '1টি']
]);
})();
