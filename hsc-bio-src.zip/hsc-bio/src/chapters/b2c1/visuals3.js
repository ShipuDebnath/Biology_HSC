/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §১.২ ননকর্ডাটা (২): মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা, একাইনোডারমাটা
   molluscPlan, annelidBody, arthropodClasses, arthroMolt, echinoWVS, nonChordTree,
   cmpAnnelidArthro, cmpInsectSpider, cmpGastroBivalve
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B21, X = window.B21X;
const PI = Math.PI, rnd = B.rnd, hot = B.hot, lab = B.lab, arrow = X.arrow, cmp = X.cmp, layer = X.layer, ani = X.ani;
const pick = (ctx, H, x, y, r) => { const h = hot(H, x, y, r || 24); if (!h) return ''; ctx.sel = h[2]; return h[3]; };
const ring = (g, x, y, r, i, ctx) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2 }, g); };

/* ═════════ ১. মলাস্কার দেহের মৌলিক নকশা ═════════ */
const MOL = {
  plan: [[170, 56, 0, '<b>খোলক</b> — ম্যান্টল থেকে নিঃসৃত ক্যালসিয়াম কার্বনেটের আবরণ; রক্ষা করে।'], [170, 84, 1, '<b>ম্যান্টল (প্যালিয়াম)</b> — আন্তরযন্ত্রীয় পিণ্ড ঢেকে রাখা চামড়ার ভাঁজ; খোলক তৈরি করে।'], [180, 112, 2, '<b>আন্তরযন্ত্রীয় পিণ্ড</b> — পরিপাক, সংবহন, রেচন ও জনন অঙ্গ।'], [176, 172, 3, '<b>পেশিবহুল পদ</b> — চলন, গর্ত খোঁড়া বা শিকার ধরা।'], [76, 150, 4, '<b>র‍্যাডুলা</b> — মুখগহ্বরের কাইটিনের দাঁতযুক্ত ফিতা; খাদ্য ঘষে কাটে (দ্বিপুটে নেই)।'], [268, 130, 5, '<b>ম্যান্টল গহ্বর ও টিনিডিয়া (ফুলকা)</b> — শ্বসন।']],
};
V.molluscPlan = Object.assign({}, B.seg({
  id: 'mol', t: 'মলাস্কা — নরম দেহের প্রাণী', H: 236, def: 'plan', sel: null,
  cap: 'মলাস্কা (ল্যাটিন mollis = নরম) — অখণ্ডিত নরম দেহ; দেহ তিন ভাগে: মাথা-পদ, আন্তরযন্ত্রীয় পিণ্ড ও ম্যান্টল; অধিকাংশের ক্যালসিয়াম কার্বনেটের খোলক; মুখে র‍্যাডুলা; শ্বসন টিনিডিয়ায়; রক্তে তামাযুক্ত হিমোসায়ানিন; সংবহন উন্মুক্ত (সেফালোপোডায় বদ্ধ)। দ্বিতীয় বৃহত্তম পর্ব। অংশে চাপ দাও।',
  types: {
    plan: ['মৌলিক নকশা', 'মলাস্কার সাধারণ দেহনকশা', 'কল্পিত আদি মলাস্কের নকশা — সব শ্রেণিতে এর রূপান্তর দেখা যায়।'],
    pila: ['আপেল শামুক', 'আপেল শামুক (Pila globosa) — গ্যাস্ট্রোপোডা', 'পেঁচানো একক খোলক; টরশন (আন্তরযন্ত্রীয় পিণ্ড 180° ঘোরা); উভচর জীবন — পানিতে ফুলকা, বাতাসে ফুসফুস-থলি; খোলকের মুখ ঢাকনা (অপারকুলাম) দিয়ে বন্ধ করে খরায় গ্রীষ্মসুপ্তিতে কাটায়।'],
    lam: ['ঝিনুক', 'মিঠাপানির ঝিনুক (Lamellidens marginalis) — বাইভালভিয়া', 'দুই পাল্লার খোলক, কবজায় যুক্ত; মাথা ও র‍্যাডুলা নেই; ফুলকা দিয়ে পানি ছেঁকে খায় (ফিল্টার ফিডার); কুঠার আকৃতির পদ। বাংলাদেশে এ ঝিনুকে মিঠাপানির মুক্তা চাষ হয়।'],
    oct: ['অক্টোপাস', 'অক্টোপাস — সেফালোপোডা', 'পদ রূপান্তরিত হয়ে মাথা ঘিরে আটটি চোষকযুক্ত বাহু; খোলক নেই; উন্নত মস্তিষ্ক ও চোখ; বদ্ধ সংবহন; কালির থলি; সাইফন দিয়ে পানি ছুড়ে জেট চলন। (কাটলফিশ Sepia ও স্কুইডে 10টি বাহু।)']
  },
  art(g, C, ty, ctx) {
    const Rs = BK.ramp(6), Rf = BK.ramp(2), Rm = BK.ramp(3);
    if (ty === 'plan') {
      E('path', { d: 'M70 168Q80 146 120 144H260Q300 146 306 168Q300 190 260 192H120Q80 190 70 168Z', fill: FK.alpha(Rf.c, .35), stroke: Rf.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M100 146Q110 90 180 86Q250 90 280 146Z', fill: FK.alpha(BK.ramp(7).c, .35), stroke: BK.ramp(7).dk }, g);
      E('path', { d: 'M92 150Q100 76 180 70Q262 76 290 150', fill: 'none', stroke: Rm.dk, 'stroke-width': 4, opacity: .55 }, g);
      E('path', { d: 'M96 142Q104 50 180 44Q258 50 286 142Q240 120 180 118Q120 120 96 142Z', fill: FK.alpha(Rs.c, .35), stroke: Rs.dk, 'stroke-width': 1.6 }, g);
      for (let i = 0; i < 5; i++) E('path', { d: `M${120 + i * 28} ${66 + Math.abs(2 - i) * 6}q6 30 4 50`, stroke: FK.alpha(Rs.dk, .4), fill: 'none' }, g);
      E('path', { d: 'M268 126q10 6 4 16q10 -2 12 8', fill: 'none', stroke: BK.ramp(0).dk, 'stroke-width': 3 }, g);
      E('path', { d: 'M66 150h18', stroke: C.fg, 'stroke-width': 2 }, g); for (let i = 0; i < 4; i++) E('path', { d: `M${68 + i * 4} 148l1 4`, stroke: C.fg, 'stroke-width': 1 }, g);
      E('circle', { cx: 200, cy: 106, r: 8, fill: FK.alpha(BK.ramp(4).c, .5), stroke: BK.ramp(4).dk }, g); T(g, 216, 104, 'হৃৎপিণ্ড', { fs: 8.4, c: C.mu });
    } else {
      ani(g, ty === 'pila' ? 'snail' : ty === 'lam' ? 'mussel' : 'octopus', 150, 120, 4.2, { R: ty === 'pila' ? Rs : ty === 'lam' ? BK.ramp(11) : BK.ramp(4) });
      const L = { pila: ['পেঁচানো খোলক', 'কর্ষিকা ও চোখ', 'পদ', 'অপারকুলাম'], lam: ['দুই পাল্লার খোলক', 'কবজা', 'বৃদ্ধিরেখা', 'পদ (ভেতরে)'], oct: ['মাথা ও চোখ', 'আটটি বাহু', 'চোষক', 'সাইফন'] }[ty];
      L.forEach((s, i) => { E('rect', { x: 270, y: 54 + i * 34, width: 82, height: 24, rx: 8, fill: FK.alpha(BK.ramp(i + 1).c, .15), stroke: BK.ramp(i + 1).dk }, g); T(g, 311, 70 + i * 34, s, { fs: 9.4, a: 'middle', w: 650, c: BK.ramp(i + 1).ink }); });
    }
    if (ty === 'plan') MOL.plan.forEach(([x, y, i]) => ring(g, x, y, 13, i, ctx));
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'plan') { const k = (t * .8) % 1; for (let i = 0; i < 5; i++) E('path', { d: `M${50 + k * 28 + i * 4} 152l2 4`, stroke: BK.ramp(4).dk, 'stroke-width': 1.4 }, g); E('path', { d: `M84 150h${-10 - 8 * Math.sin(t * 4)}`, stroke: BK.ramp(4).dk, 'stroke-width': 2.4 }, g); }
    else if (ty === 'oct') { const w = Math.sin(t * 2) * 6; for (let i = -3; i <= 3; i++) E('path', { d: `M${150 + i * 10} 120q${i * 12 + w} 34 ${i * 20 + w * 1.4} 66`, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2, opacity: .7 }, g); }
    else if (ty === 'lam') { const k = (t * .4) % 1; for (let i = 0; i < 6; i++) { const u = (k + i / 6) % 1; E('circle', { cx: 90 + u * 120, cy: 120 + Math.sin(u * 6) * 6, r: 2, fill: BK.ramp(5).dk, opacity: .7 }, g); } }
    else { const w = Math.sin(t * 2) * 4; E('path', { d: `M86 152l${-8 + w} -24M98 152l${w} -26`, stroke: BK.ramp(6).dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); }
  },
  tap(x, y, ty, ctx) { return ty === 'plan' ? pick(ctx, MOL.plan, x, y, 26) : ''; }
}));

/* ═════════ ২. অ্যানেলিডা — কেঁচো ═════════ */
const ANN = [[180, 30, 0, '<b>কিউটিকল ও এপিডার্মিস</b> — পাতলা, আর্দ্র; ত্বক দিয়ে শ্বসন (শ্বসন অঙ্গ নেই)।'], [180, 46, 1, '<b>বৃত্তাকার ও অনুদৈর্ঘ্য পেশি</b> — পর্যায়ক্রমে সংকোচনে চলন।'], [124, 120, 2, '<b>প্রকৃত সিলোম</b> — তরলপূর্ণ, প্রতিটি খণ্ডে সেপ্টামে বিভক্ত; জলস্থিতিক কঙ্কাল।'], [180, 120, 3, '<b>অন্ত্র ও টিফলোসোল</b> — পৃষ্ঠীয় ভাঁজ শোষণতল বাড়ায়।'], [180, 66, 4, '<b>পৃষ্ঠীয় রক্তনালি</b> — বদ্ধ সংবহন; রক্তরসে হিমোগ্লোবিন দ্রবীভূত।'], [180, 196, 5, '<b>অঙ্কীয় স্নায়ুরজ্জু</b> — প্রতিটি খণ্ডে গ্যাংলিয়া।'], [262, 112, 6, '<b>নেফ্রিডিয়া</b> — রেচন অঙ্গ, প্রতি খণ্ডে।'], [276, 150, 7, '<b>সিটি</b> — কাইটিনের ছোট বাঁকা কাঁটা; মাটি আঁকড়ে চলতে সাহায্য করে।']];
V.annelidBody = Object.assign({}, B.seg({
  id: 'ann', t: 'অ্যানেলিডা — অঙ্গুরীমাল প্রাণী', H: 236, def: 'ext', sel: null,
  cap: 'অ্যানেলিডা (ল্যাটিন annulus = আংটি) — দেহ বহু আংটির মতো খণ্ডে বিভক্ত (প্রকৃত খণ্ডায়ন); প্রকৃত সিলোম (সাইজোসিলোম); সিটি বা প্যারাপোডিয়া দিয়ে চলন; বদ্ধ সংবহনতন্ত্র; রেচন নেফ্রিডিয়ায়; অঙ্কীয় স্নায়ুরজ্জু।',
  types: {
    ext: ['কেঁচোর বাইরের দিক', 'কেঁচো (Metaphire posthuma) — বাহ্যিক গঠন', 'প্রায় 100–120টি খণ্ড; 14–16তম খণ্ডে ক্লাইটেলাম (ডিম রাখার কোকুন তৈরি করে); প্রথম, শেষ ও ক্লাইটেলাম ছাড়া প্রতিটি খণ্ডের মাঝে বলয়াকারে সিটি। উভলিঙ্গ কিন্তু পর-নিষেক। পুরোনো বইয়ে নাম Pheretima posthuma।'],
    ts: ['প্রস্থচ্ছেদ', 'কেঁচোর দেহের প্রস্থচ্ছেদ', 'বাইরে থেকে ভেতরে — কিউটিকল, এপিডার্মিস, বৃত্তাকার পেশি, অনুদৈর্ঘ্য পেশি, সিলোম, অন্ত্র (টিফলোসোলসহ)। অংশে চাপ দাও।'],
    lee: ['জোঁক', 'জোঁক (Hirudinaria manillensis)', '33টি খণ্ড, বাইরে খণ্ডগুলো আরও ছোট বলয়ে বিভক্ত দেখায়; দুই প্রান্তে চোষক; সিটি নেই; লালায় হিরুডিন — রক্ত জমাট বাঁধতে দেয় না। রক্তচোষা বহিঃপরজীবী।'],
    ner: ['নেরিস', 'নেরিস (Nereis) — সামুদ্রিক', 'প্রতিটি খণ্ডে একজোড়া পার্শ্বীয় প্যারাপোডিয়া (বহু সিটিযুক্ত) — সাঁতার ও শ্বসন; মাথায় কর্ষিকা ও চোখ; একলিঙ্গ।']
  },
  art(g, C, ty, ctx) {
    const R = BK.ramp(4);
    if (ty === 'ext') {
      for (let i = 0; i < 24; i++) { const x = 20 + i * 13.5, w = i === 0 ? 10 : 13, h = 30 - Math.abs(i - 6) * .2 - (i > 20 ? (i - 20) * 3 : 0), cl = i >= 3 && i <= 5; E('rect', { x, y: 110 - h / 2, width: w, height: h, rx: 5, fill: FK.alpha(cl ? BK.ramp(2).c : R.c, cl ? .55 : .25), stroke: cl ? BK.ramp(2).dk : R.dk, 'stroke-width': .8 }, g); if (!cl && i > 0 && i < 23) { E('path', { d: `M${x + 6} ${110 - h / 2}v-3M${x + 6} ${110 + h / 2}v3`, stroke: C.fg, 'stroke-width': 1.1 }, g); } }
      T(g, 20, 82, 'প্রোস্টোমিয়াম ও মুখ', { fs: 9, c: C.mu }); T(g, 76, 150, 'ক্লাইটেলাম (14–16)', { fs: 9.4, a: 'middle', w: 700, c: BK.ramp(2).ink }); T(g, 300, 150, 'পায়ু', { fs: 9, a: 'middle', c: C.mu }); T(g, 200, 80, 'সিটি — প্রতি খণ্ডে', { fs: 9, a: 'middle', c: C.mu });
      T(g, 180, 196, 'ছবিতে খণ্ড সংক্ষিপ্ত করে দেখানো; প্রকৃত কেঁচোয় 100–120টি', { fs: 9, a: 'middle', c: C.mu });
    } else if (ty === 'ts') {
      const cx = 180, cy = 120, Rm = layer('me');
      E('circle', { cx, cy, r: 92, fill: FK.alpha(layer('ec').c, .4), stroke: layer('ec').dk }, g);
      E('circle', { cx, cy, r: 84, fill: FK.alpha(Rm.c, .25), stroke: Rm.dk }, g); E('circle', { cx, cy, r: 74, fill: FK.alpha(Rm.c, .45), stroke: Rm.dk }, g);
      E('circle', { cx, cy, r: 62, fill: FK.alpha(layer('co').c, .25), stroke: Rm.dk }, g);
      E('path', { d: `M${cx - 30} ${cy}A30 30 0 1 0 ${cx + 30} ${cy}A30 30 0 1 0 ${cx - 30} ${cy}M${cx - 10} ${cy - 30}Q${cx} ${cy + 4} ${cx + 10} ${cy - 30}`, fill: FK.alpha(layer('en').c, .5), stroke: layer('en').dk, 'fill-rule': 'evenodd' }, g);
      E('circle', { cx, cy: cy - 54, r: 6, fill: FK.alpha(BK.ramp(4).c, .7), stroke: BK.ramp(4).dk }, g); E('circle', { cx, cy: cy + 46, r: 4, fill: FK.alpha(BK.ramp(4).c, .7), stroke: BK.ramp(4).dk }, g);
      E('ellipse', { cx, cy: cy + 76, rx: 10, ry: 5, fill: FK.alpha(BK.ramp(2).c, .7), stroke: BK.ramp(2).dk }, g);
      E('path', { d: `M${cx + 36} ${cy - 8}q24 -10 20 14q-4 16 22 22`, fill: 'none', stroke: BK.ramp(5).dk, 'stroke-width': 2 }, g);
      E('path', { d: `M${cx + 84} ${cy + 30}l12 4M${cx - 84} ${cy + 30}l-12 4`, stroke: C.fg, 'stroke-width': 2 }, g);
      ANN.forEach(([x, y, i]) => ring(g, x, y, 11, i, ctx));
    } else if (ty === 'lee') {
      E('path', { d: 'M40 120C60 86 280 86 310 116Q314 120 310 124C280 154 60 154 40 120Z', fill: FK.alpha(BK.ramp(11).c, .4), stroke: BK.ramp(11).dk, 'stroke-width': 1.4 }, g);
      for (let i = 0; i < 33; i++) E('path', { d: `M${56 + i * 7.6} ${100 + Math.abs(i - 16) * .5}v${40 - Math.abs(i - 16)}`, stroke: FK.alpha(BK.ramp(11).dk, .4), 'stroke-width': .7 }, g);
      E('circle', { cx: 48, cy: 120, r: 9, fill: 'none', stroke: C.fg, 'stroke-width': 1.6 }, g); E('circle', { cx: 302, cy: 120, r: 14, fill: 'none', stroke: C.fg, 'stroke-width': 1.6 }, g);
      T(g, 48, 154, 'সম্মুখ চোষক', { fs: 9, a: 'middle', c: C.mu }); T(g, 302, 158, 'পশ্চাৎ চোষক', { fs: 9, a: 'middle', c: C.mu }); T(g, 180, 190, 'লালায় হিরুডিন — রক্ত জমাট বাঁধে না', { fs: 9.6, a: 'middle', w: 650, c: C.fg });
    } else {
      E('path', { d: 'M40 120Q180 108 320 120Q180 132 40 120Z', fill: FK.alpha(BK.ramp(0).c, .4), stroke: BK.ramp(0).dk }, g);
      for (let i = 0; i < 20; i++) { const x = 60 + i * 13; [-1, 1].forEach(k => { E('path', { d: `M${x} ${120 + k * 6}l-4 ${k * 14}l8 0z`, fill: FK.alpha(BK.ramp(0).c, .5), stroke: BK.ramp(0).dk, 'stroke-width': .7 }, g); for (let j = 0; j < 3; j++) E('path', { d: `M${x} ${120 + k * 20}l${j * 3 - 3} ${k * 8}`, stroke: C.fg, 'stroke-width': .5 }, g); }); }
      E('path', { d: 'M40 120l-12 -8M40 120l-12 8M40 116l-8 -12M40 124l-8 12', stroke: BK.ramp(0).dk, 'stroke-width': 1.2 }, g); T(g, 180, 180, 'প্রতি খণ্ডে একজোড়া প্যারাপোডিয়া', { fs: 9.6, a: 'middle', w: 650, c: C.fg });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'ext') { const p = (t * 4) % 26; for (let i = 0; i < 24; i++) { const d = Math.abs(i - p); if (d < 1.6) E('rect', { x: 20 + i * 13.5 - 1, y: 90, width: 15, height: 40, rx: 6, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2 * (1.6 - d) }, g); } }
    else if (ty === 'ts') { const k = .5 + .5 * Math.sin(t * 3); E('circle', { cx: 180, cy: 66, r: 6 + 2 * k, fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 1.6 }, g); }
    else if (ty === 'ner') { for (let i = 0; i < 20; i++) { const ph = Math.sin(t * 5 - i * .6) * 5; E('path', { d: `M${60 + i * 13} 106l${ph} -10M${60 + i * 13} 134l${ph} 10`, stroke: BK.ramp(0).dk, 'stroke-width': 1.6 }, g); } }
    else { const k = Math.sin(t * 1.6) * 6; E('path', { d: `M40 120C60 ${86 - k} 280 ${86 - k} 310 116`, fill: 'none', stroke: BK.ramp(11).dk, 'stroke-width': 1.6 }, g); }
  },
  tap(x, y, ty, ctx) { return ty === 'ts' ? pick(ctx, ANN, x, y, 18) : ''; }
}));

/* ═════════ ৩. আর্থ্রোপোডার প্রধান শ্রেণি ═════════ */
V.arthropodClasses = Object.assign({}, B.seg({
  id: 'art', t: 'আর্থ্রোপোডা — সন্ধিপদী প্রাণীর শ্রেণি', H: 240, def: 'ins',
  cap: 'আর্থ্রোপোডা (গ্রিক arthron = সন্ধি, podos = পা) — খণ্ডিত দেহ, সন্ধিযুক্ত উপাঙ্গ, কাইটিনের বহিঃকঙ্কাল (তাই বৃদ্ধির জন্য খোলস মোচন); দেহগহ্বর হিমোসিল, সংবহন উন্মুক্ত; যৌগিক চোখ। প্রাণিজগতের বৃহত্তম পর্ব। শ্রেণি বদলে উপাঙ্গের সংখ্যা মিলিয়ে দেখো।',
  types: {
    ins: ['পতঙ্গ', 'ইনসেক্টা — তেলাপোকা, মৌমাছি, মশা', 'দেহ তিন ভাগ (মাথা, বক্ষ, উদর); 3 জোড়া পা; 1 জোড়া অ্যান্টেনা; সাধারণত 2 জোড়া ডানা; শ্বসন ট্রাকিয়ায়; রেচন ম্যালপিজিয়ান নালিকায়।'],
    cru: ['ক্রাস্টেসিয়া', 'ক্রাস্টেসিয়া — চিংড়ি, কাঁকড়া', 'দেহ শিরোবক্ষ ও উদরে বিভক্ত; 2 জোড়া অ্যান্টেনা; বহু জোড়া পা; ফুলকায় শ্বসন; অধিকাংশ জলজ — গলদা (Macrobrachium rosenbergii), বাগদা (Penaeus monodon)।'],
    ara: ['অ্যারাকনিডা', 'অ্যারাকনিডা — মাকড়সা, বিছা', 'দেহ শিরোবক্ষ ও উদরে বিভক্ত; 4 জোড়া পা; অ্যান্টেনা নেই; মুখে কিলিসেরি; শ্বসন বুক লাংস বা ট্রাকিয়ায়।'],
    myr: ['মিরিয়াপোডা', 'মিরিয়াপোডা — শতপদী ও সহস্রপদী', 'লম্বা বহু খণ্ডের দেহ, মাথায় 1 জোড়া অ্যান্টেনা; শতপদীর (Scolopendra) প্রতি খণ্ডে 1 জোড়া পা ও বিষ-নখর, সহস্রপদীর (Julus) প্রতি খণ্ডে 2 জোড়া পা।']
  },
  art(g, C, ty) {
    const R = BK.ramp({ ins: 6, cru: 4, ara: 9, myr: 11 }[ty]), f = FK.alpha(R.c, .35);
    const leg = (x, y, dx, dy) => E('path', { d: `M${x} ${y}l${dx * .55} ${dy * .3}l${dx * .45} ${dy * .7}`, fill: 'none', stroke: R.dk, 'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
    if (ty === 'ins') {
      E('ellipse', { cx: 140, cy: 64, rx: 16, ry: 14, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: 140, cy: 100, rx: 20, ry: 20, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: 140, cy: 160, rx: 22, ry: 40, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M132 52Q110 20 92 16M148 52Q170 20 188 16', fill: 'none', stroke: R.dk, 'stroke-width': 1.4 }, g);
      [90, 100, 112].forEach((y, i) => { leg(124, y, -44, 20 + i * 10); leg(156, y, 44, 20 + i * 10); });
      E('path', { d: 'M156 94Q210 70 236 104Q206 118 158 110Z', fill: FK.alpha(BK.ramp(5).c, .18), stroke: BK.ramp(5).dk }, g);
      T(g, 290, 60, 'মাথা', { fs: 10, a: 'middle', c: C.fg }); T(g, 290, 100, 'বক্ষ — 3 জোড়া পা', { fs: 10, a: 'middle', c: C.fg }); T(g, 290, 160, 'উদর', { fs: 10, a: 'middle', c: C.fg }); T(g, 290, 30, '1 জোড়া অ্যান্টেনা', { fs: 10, a: 'middle', c: C.fg });
    } else if (ty === 'cru') {
      E('path', { d: 'M60 110Q70 80 150 84H170Q180 110 170 136H150Q70 140 60 110Z', fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g);
      for (let i = 0; i < 6; i++) E('path', { d: `M${174 + i * 18} ${96 + i * 3}h18v${30 - i * 4}h-18z`, fill: f, stroke: R.dk }, g);
      E('path', { d: 'M282 112l26 -12v30z', fill: f, stroke: R.dk }, g);
      E('path', { d: 'M62 104Q20 70 30 30M62 108Q16 96 10 60M64 116Q30 120 14 136M64 118Q36 132 30 160', fill: 'none', stroke: R.dk, 'stroke-width': 1.2 }, g);
      for (let i = 0; i < 5; i++) leg(90 + i * 14, 134, -4 + i, 40);
      E('path', { d: 'M90 136q-10 30 -30 34l-8 -6M90 136q-6 30 -20 40', fill: 'none', stroke: R.dk, 'stroke-width': 2.6 }, g);
      T(g, 110, 76, 'শিরোবক্ষ', { fs: 10, a: 'middle', c: C.fg }); T(g, 230, 82, 'উদর', { fs: 10, a: 'middle', c: C.fg }); T(g, 70, 24, '2 জোড়া অ্যান্টেনা', { fs: 10, a: 'start', c: C.fg }); T(g, 180, 210, '5 জোড়া হাঁটার পা (দশপদী)', { fs: 10, a: 'middle', c: C.fg });
    } else if (ty === 'ara') {
      E('ellipse', { cx: 150, cy: 120, rx: 26, ry: 24, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx: 210, cy: 124, rx: 36, ry: 32, fill: f, stroke: R.dk, 'stroke-width': 1.4 }, g);
      [-56, -26, 8, 40].forEach((dx, i) => { leg(138 + i * 7, 104, dx, -52); leg(138 + i * 7, 136, dx, 52); });
      E('path', { d: 'M126 112l-12 -2M126 128l-12 2', stroke: R.dk, 'stroke-width': 3 }, g);
      T(g, 150, 70, 'শিরোবক্ষ', { fs: 10, a: 'middle', c: C.fg }); T(g, 240, 80, 'উদর', { fs: 10, a: 'middle', c: C.fg }); T(g, 300, 150, '4 জোড়া পা', { fs: 10, a: 'middle', c: C.fg }); T(g, 300, 168, 'অ্যান্টেনা নেই', { fs: 10, a: 'middle', c: BK.ramp(4).ink });
    } else {
      for (let i = 0; i < 16; i++) { const x = 40 + i * 18; E('rect', { x, y: 108, width: 16, height: 22, rx: 5, fill: f, stroke: R.dk }, g); leg(x + 8, 108, -6, -26); leg(x + 8, 130, -6, 26); }
      E('path', { d: 'M38 112Q20 90 14 70M38 126Q20 146 14 166', fill: 'none', stroke: R.dk, 'stroke-width': 1.3 }, g);
      T(g, 190, 200, 'শতপদী — প্রতি খণ্ডে 1 জোড়া পা', { fs: 10, a: 'middle', c: C.fg }); T(g, 190, 218, 'সহস্রপদী — প্রতি খণ্ডে 2 জোড়া', { fs: 9.6, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return; const R = BK.ramp({ ins: 6, cru: 4, ara: 9, myr: 11 }[ty]), ph = Math.sin(t * 6);
    if (ty === 'ins') [90, 100, 112].forEach((y, i) => { const s = (i % 2 ? 1 : -1) * ph * 6; E('path', { d: `M124 ${y}l${-24 + s} ${8}`, stroke: R.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, g); E('path', { d: `M156 ${y}l${24 - s} ${8}`, stroke: R.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, g); });
    else if (ty === 'myr') for (let i = 0; i < 16; i++) { const s = Math.sin(t * 6 - i * .7) * 5; E('path', { d: `M${48 + i * 18} 108l${s} -14M${48 + i * 18} 130l${s} 14`, stroke: R.c, 'stroke-width': 2.6, 'stroke-linecap': 'round' }, g); }
    else if (ty === 'cru') E('path', { d: `M282 112l26 ${-12 + ph * 4}v30z`, fill: FK.alpha(R.c, .4), stroke: R.dk }, g);
    else E('circle', { cx: 210, cy: 124, r: 36 + ph * 2, fill: 'none', stroke: R.c, 'stroke-width': 1.2 }, g);
  }
}));

/* ═════════ ৪. খোলস মোচন ═════════ */
V.arthroMolt = Object.assign({ t: 'আর্থ্রোপোডার খোলস মোচন (একডাইসিস)', k: ['anim', 'steps'], cap: 'কাইটিনের শক্ত বহিঃকঙ্কাল বাড়তে পারে না, তাই আর্থ্রোপোডা বড় হতে হলে পুরোনো খোলস ফেলে নতুন খোলস তৈরি করে — খোলস মোচন বা একডাইসিস। এটি একডাইসোন হরমোন নিয়ন্ত্রণ করে; জুভেনাইল হরমোন লার্ভা দশা ধরে রাখে। নতুন খোলস শক্ত হওয়ার আগের সময়ে প্রাণী অরক্ষিত থাকে।' }, BK.steps({
  W: 360, H: 220, label: 'খোলস মোচন', dur: 3,
  stages: [
    { t: 'পুরোনো খোলস', en: 'Intermoult', d: 'শক্ত কিউটিকল; প্রাণী বড় হতে পারছে না।' },
    { t: 'খোলস আলগা হওয়া', en: 'Apolysis', d: 'একডাইসোনের প্রভাবে এপিডার্মিস পুরোনো কিউটিকল থেকে আলাদা হয়; মাঝে মোচন-তরল জমে, যা পুরোনো খোলসের ভেতরের স্তর গলায়।' },
    { t: 'নতুন কিউটিকল', en: 'New cuticle', d: 'এপিডার্মিস নিচে নরম, ভাঁজ করা নতুন কিউটিকল তৈরি করে।' },
    { t: 'খোলস ফাটা ও বেরোনো', en: 'Ecdysis', d: 'পিঠের মাঝরেখা বরাবর পুরোনো খোলস ফেটে যায়; প্রাণী বেরিয়ে আসে — ফেলে যাওয়া খোলসকে এক্সুভিয়া বলে।' },
    { t: 'স্ফীতি ও শক্ত হওয়া', en: 'Sclerotization', d: 'বাতাস বা পানি টেনে দেহ বড় করে, তারপর নতুন কিউটিকল শক্ত ও গাঢ় হয় (স্ক্লেরোটাইজেশন)।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(6), Rn = BK.ramp(10), cx = 150, cy = 112;
    const shell = (rx, ry, op, split) => { if (split) { E('path', { d: `M${cx - rx} ${cy}A${rx} ${ry} 0 0 1 ${cx - 6} ${cy - ry}`, fill: 'none', stroke: R.dk, 'stroke-width': 6, opacity: op }, g); E('path', { d: `M${cx + rx} ${cy}A${rx} ${ry} 0 0 0 ${cx + 6} ${cy - ry}`, fill: 'none', stroke: R.dk, 'stroke-width': 6, opacity: op }, g); E('path', { d: `M${cx - rx} ${cy}A${rx} ${ry} 0 0 0 ${cx + rx} ${cy}`, fill: 'none', stroke: R.dk, 'stroke-width': 6, opacity: op }, g); } else E('ellipse', { cx, cy, rx, ry, fill: 'none', stroke: R.dk, 'stroke-width': 6, opacity: op }, g); };
    const body = (rx, ry, col, a) => E('ellipse', { cx, cy: cy - (s >= 3 ? u * 0 : 0), rx, ry, fill: FK.alpha(col, a), stroke: 'none' }, g);
    if (s === 0) { body(56, 40, R.c, .3); shell(58, 42, 1); }
    else if (s === 1) { body(50 - 2 * u, 34 - 2 * u, R.c, .3); shell(58, 42, 1); E('ellipse', { cx, cy, rx: 54, ry: 38, fill: 'none', stroke: BK.ramp(5).c, 'stroke-width': 3 * u, opacity: .6 }, g); }
    else if (s === 2) { body(48, 32, R.c, .3); shell(58, 42, 1); E('ellipse', { cx, cy, rx: 50, ry: 34, fill: 'none', stroke: Rn.dk, 'stroke-width': 2, 'stroke-dasharray': '4 3', opacity: u }, g); }
    else if (s === 3) { shell(58, 42, 1 - .4 * u, true); E('ellipse', { cx, cy: cy - 50 * u, rx: 48, ry: 32, fill: FK.alpha(Rn.c, .35), stroke: Rn.dk, 'stroke-dasharray': '4 3' }, g); }
    else { shell(58, 42, .25, true); E('ellipse', { cx: cx + 120 * 0 + 0, cy: cy - 50, rx: 48 + 18 * u, ry: 32 + 12 * u, fill: FK.alpha(Rn.c, .3 + .3 * u), stroke: Rn.dk, 'stroke-width': 1 + 4 * u }, g); }
    T(g, 300, 60, ['বড় হতে পারে না', 'এপিডার্মিস আলাদা', 'নতুন কিউটিকল', 'বেরিয়ে আসে', 'বড় ও শক্ত'][s], { fs: 10.5, a: 'middle', w: 700, c: C.fg });
    T(g, 300, 80, s >= 3 ? 'এক্সুভিয়া পড়ে থাকে' : 'একডাইসোন হরমোন', { fs: 9.4, a: 'middle', c: C.mu });
  }
}));

/* ═════════ ৫. একাইনোডার্মের পানি সংবহনতন্ত্র ═════════ */
const WVS = [[180, 112, 0, '<b>মাদ্রেপোরাইট</b> — পিঠের ছাঁকনির মতো ছিদ্রযুক্ত প্লেট; সমুদ্রের পানি ঢোকে।'], [196, 124, 1, '<b>পাথুরে নালি</b> — চুনময় প্রাচীরের নালি।'], [218, 140, 2, '<b>বলয় নালি</b> — মুখ ঘিরে বৃত্তাকার নালি।'], [180, 58, 3, '<b>অরীয় নালি</b> — প্রতিটি বাহুতে একটি।'], [212, 70, 4, '<b>অ্যাম্পুলা ও নালিপদ</b> — অ্যাম্পুলা সংকুচিত হলে পানি নালিপদে যায়, নালিপদ লম্বা হয়ে চোষকের মতো আটকে টানে — চলন, আঁকড়ানো, খাদ্য ধরা ও শ্বসন।']];
V.echinoWVS = Object.assign({}, B.seg({
  id: 'ech', t: 'একাইনোডারমাটা — পানি সংবহনতন্ত্র', H: 240, def: 'wvs', sel: null,
  cap: 'একাইনোডারমাটা (গ্রিক echinos = কাঁটা, derma = ত্বক) — সবাই সামুদ্রিক; ত্বকে চুনময় অসিকল ও কাঁটা; পরিণত দেহ পঞ্চ-অরীয় কিন্তু লার্ভা দ্বিপার্শ্বীয়; ডিউটেরোস্টোম ও এন্টেরোসিলোমেট। এদের অনন্য বৈশিষ্ট্য পানি সংবহনতন্ত্র (জল-সংবহন বা অ্যাম্বুল্যাক্রাল তন্ত্র)। অংশে চাপ দাও।',
  types: {
    wvs: ['পানি সংবহনতন্ত্র', 'তারামাছের পানি সংবহনতন্ত্র', 'মাদ্রেপোরাইট → পাথুরে নালি → বলয় নালি → 5টি অরীয় নালি → পার্শ্বীয় নালি → অ্যাম্পুলা ও নালিপদ।'],
    cls: ['শ্রেণি', 'একাইনোডার্মের প্রধান শ্রেণি', 'তারামাছ (Asteroidea), সমুদ্র শজারু (Echinoidea), ভঙ্গুর তারা (Ophiuroidea), সমুদ্র শসা (Holothuroidea) ও সমুদ্র লিলি (Crinoidea)।'],
    lar: ['লার্ভা', 'দ্বিপার্শ্বীয় লার্ভা — বাইপিনারিয়া', 'তারামাছের লার্ভা দ্বিপার্শ্বীয় ও সিলিয়াযুক্ত, স্বাধীনভাবে সাঁতরায়; রূপান্তরে পঞ্চ-অরীয় পরিণত প্রাণী হয় — ইঙ্গিত দেয় এদের পূর্বপুরুষ দ্বিপার্শ্বীয় ছিল।']
  },
  art(g, C, ty, ctx) {
    const R = BK.ramp(2), Rw = BK.ramp(5), cx = 180, cy = 130;
    if (ty === 'wvs') {
      let d = ''; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i / 10 * PI * 2, r = i % 2 ? 36 : 104; d += (i ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(1) + ' ' + (cy + r * Math.sin(a)).toFixed(1); }
      E('path', { d: d + 'Z', fill: FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': 1.4, 'stroke-linejoin': 'round' }, g);
      E('circle', { cx, cy, r: 20, fill: 'none', stroke: Rw.dk, 'stroke-width': 4 }, g);
      for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * PI * 2, x1 = cx + 92 * Math.cos(a), y1 = cy + 92 * Math.sin(a); E('path', { d: `M${cx + 20 * Math.cos(a)} ${cy + 20 * Math.sin(a)}L${x1} ${y1}`, stroke: Rw.dk, 'stroke-width': 3 }, g);
        for (let k = 1; k <= 5; k++) { const r = 26 + k * 13, px = cx + r * Math.cos(a), py = cy + r * Math.sin(a), nx = -Math.sin(a), ny = Math.cos(a); [-1, 1].forEach(sg => { E('circle', { cx: px + sg * 8 * nx, cy: py + sg * 8 * ny, r: 3.4, fill: FK.alpha(Rw.c, .5), stroke: Rw.dk, 'stroke-width': .8 }, g); }); } }
      E('path', { d: `M${cx} ${cy - 18}Q${cx + 12} ${cy - 14} ${cx + 18} ${cy + 2}`, fill: 'none', stroke: BK.ramp(11).dk, 'stroke-width': 3 }, g);
      E('circle', { cx: cx + 14, cy: cy - 22, r: 7, fill: FK.alpha(BK.ramp(11).c, .6), stroke: BK.ramp(11).dk }, g);
      WVS.forEach(([x, y, i]) => ring(g, x, y, 11, i, ctx));
    } else if (ty === 'cls') {
      [['starfish', 'তারামাছ'], ['urchin', 'সমুদ্র শজারু'], ['starfish', 'ভঙ্গুর তারা'], ['roundworm', 'সমুদ্র শসা'], ['hydra', 'সমুদ্র লিলি']].forEach(([k, n], i) => { const x = 40 + i * 70, y = 110; ani(g, k, x, y, 1.5, { R: BK.ramp([2, 3, 6, 11, 0][i]) }); T(g, x, y + 46, n, { fs: 9.6, a: 'middle', w: 700, c: BK.ramp([2, 3, 6, 11, 0][i]).ink }); });
      T(g, 180, 200, 'সবাই সামুদ্রিক — মিঠাপানিতে কোনো একাইনোডার্ম নেই', { fs: 9.6, a: 'middle', c: C.fg });
    } else {
      E('path', { d: 'M110 60Q180 30 250 60Q270 120 250 180Q180 210 110 180Q90 120 110 60Z', fill: FK.alpha(BK.ramp(0).c, .2), stroke: BK.ramp(0).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M180 40V200', stroke: BK.ramp(10).dk, 'stroke-dasharray': '5 4', 'stroke-width': 1.6 }, g);
      E('path', { d: 'M150 90Q180 70 210 90Q216 130 180 150Q144 130 150 90Z', fill: FK.alpha(layer('en').c, .4), stroke: layer('en').dk }, g);
      T(g, 300, 120, 'একটিমাত্র তলে', { fs: 10, a: 'middle', c: C.fg }); T(g, 300, 136, 'সমান ভাগ', { fs: 10, a: 'middle', c: C.fg });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'wvs') { const k = (t * .35) % 1, cx = 180, cy = 130; for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * PI * 2, r = 20 + k * 72; E('circle', { cx: cx + r * Math.cos(a), cy: cy + r * Math.sin(a), r: 3, fill: BK.ramp(5).dk }, g); } const e = .5 + .5 * Math.sin(t * 4); for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * PI * 2, px = cx + 65 * Math.cos(a), py = cy + 65 * Math.sin(a); E('circle', { cx: px, cy: py, r: 2 + 3 * e, fill: 'none', stroke: BK.ramp(5).c, 'stroke-width': 1.6 }, g); } }
    else if (ty === 'lar') { for (let i = 0; i < 12; i++) { const a = i / 12 * PI * 2, w = Math.sin(t * 8 + i) * 3; E('path', { d: `M${180 + 76 * Math.cos(a)} ${120 + 76 * Math.sin(a)}l${(6 + w) * Math.cos(a)} ${(6 + w) * Math.sin(a)}`, stroke: BK.ramp(0).dk, 'stroke-width': 1.2 }, g); } }
    else { const i = Math.floor(t * .6) % 5; E('circle', { cx: 40 + i * 70, cy: 110, r: 30, fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 1.6 }, g); }
  },
  tap(x, y, ty, ctx) { return ty === 'wvs' ? pick(ctx, WVS, x, y, 20) : ''; }
}));

/* ═════════ ৬. ননকর্ডাটা পর্বের গাছ ═════════ */
V.nonChordTree = Object.assign({
  t: 'ননকর্ডাটা — আটটি প্রধান পর্ব', k: ['tree', 'int'],
  cap: 'নটোকর্ড নেই এমন প্রাণীদের একত্রে ননকর্ডাটা (অমেরুদণ্ডী) বলা হয় — এটি আনুষ্ঠানিক শ্রেণিবিন্যাসের একক নয়, সুবিধার জন্য ব্যবহৃত দল। পর্বে চাপ দিলে মূল বৈশিষ্ট্য ও উদাহরণ খুলবে।'
}, BK.tree({
  t: 'ননকর্ডাটা', en: 'Non-chordates', d: 'নটোকর্ড, পৃষ্ঠীয় ফাঁপা স্নায়ুরজ্জু ও গলবিলীয় ফুলকাছিদ্র নেই; স্নায়ুরজ্জু (থাকলে) অঙ্কীয়।',
  c: [
    { t: 'পরিফেরা', en: 'Porifera', d: 'ছিদ্রযুক্ত দেহ, নালিতন্ত্র, কলার কোষ, কাঁটা (স্পিকিউল); কোষীয় মাত্রা।', c: [{ t: 'Scypha' }, { t: 'Spongilla' }, { t: 'Euspongia' }] },
    { t: 'নিডারিয়া', en: 'Cnidaria', d: 'নিডোসাইট, দ্বিস্তরী, অরীয়, সিলেন্টেরন; পলিপ ও মেডুসা।', c: [{ t: 'Hydra' }, { t: 'Obelia' }, { t: 'Aurelia (জেলিফিশ)' }] },
    { t: 'প্লাটিহেলমিনথেস', en: 'Platyhelminthes', d: 'চ্যাপ্টা, ত্রিস্তরী, অ্যাসিলোমেট, শিখা কোষ।', c: [{ t: 'Dugesia (প্লানেরিয়া)' }, { t: 'Fasciola hepatica' }, { t: 'Taenia solium' }] },
    { t: 'নেমাটোডা', en: 'Nematoda', d: 'নলাকার, খণ্ডহীন, সিউডোসিলোমেট, সম্পূর্ণ পৌষ্টিকনালি।', c: [{ t: 'Ascaris lumbricoides' }, { t: 'Enterobius vermicularis' }, { t: 'Wuchereria bancrofti' }] },
    { t: 'মলাস্কা', en: 'Mollusca', d: 'নরম অখণ্ড দেহ, ম্যান্টল, খোলক, পেশিবহুল পদ, র‍্যাডুলা।', c: [{ t: 'Pila globosa' }, { t: 'Lamellidens marginalis' }, { t: 'Octopus' }] },
    { t: 'অ্যানেলিডা', en: 'Annelida', d: 'প্রকৃত খণ্ডায়ন, সিটি বা প্যারাপোডিয়া, বদ্ধ সংবহন, নেফ্রিডিয়া।', c: [{ t: 'Metaphire posthuma (কেঁচো)' }, { t: 'Hirudinaria (জোঁক)' }, { t: 'Nereis' }] },
    { t: 'আর্থ্রোপোডা', en: 'Arthropoda', d: 'সন্ধিযুক্ত উপাঙ্গ, কাইটিনের বহিঃকঙ্কাল, হিমোসিল, উন্মুক্ত সংবহন।', c: [{ t: 'Periplaneta americana' }, { t: 'Macrobrachium rosenbergii' }, { t: 'মাকড়সা, শতপদী' }] },
    { t: 'একাইনোডারমাটা', en: 'Echinodermata', d: 'সামুদ্রিক, পঞ্চ-অরীয়, পানি সংবহনতন্ত্র, নালিপদ, কাঁটাযুক্ত ত্বক।', c: [{ t: 'Asterias (তারামাছ)' }, { t: 'Echinus (সমুদ্র শজারু)' }, { t: 'Holothuria (সমুদ্র শসা)' }] }
  ]
}, { collapse: true }));

/* ═════════ ৭. তুলনা ═════════ */
V.cmpAnnelidArthro = cmp('অ্যানেলিডা বনাম আর্থ্রোপোডা', 'দুই খণ্ডিত প্রোটোস্টোম পর্ব।', 'অ্যানেলিডা', 'আর্থ্রোপোডা', [
  ['উপাঙ্গ', 'সন্ধিহীন — সিটি বা প্যারাপোডিয়া', 'সন্ধিযুক্ত পা ও অন্যান্য উপাঙ্গ'],
  ['আবরণ', 'পাতলা, আর্দ্র কিউটিকল', 'কাইটিনের শক্ত বহিঃকঙ্কাল; খোলস মোচন'],
  ['দেহগহ্বর', 'প্রকৃত সিলোম, খণ্ডে খণ্ডে বিভক্ত', 'হিমোসিল (প্রকৃত সিলোম ক্ষুদ্র)'],
  ['সংবহনতন্ত্র', 'বদ্ধ', 'উন্মুক্ত'],
  ['শ্বসন', 'ত্বক বা প্যারাপোডিয়া', 'ট্রাকিয়া, ফুলকা বা বুক লাংস'],
  ['রেচন', 'নেফ্রিডিয়া', 'ম্যালপিজিয়ান নালিকা বা সবুজ গ্রন্থি'],
  ['উদাহরণ', 'কেঁচো, জোঁক, নেরিস', 'তেলাপোকা, চিংড়ি, মাকড়সা']
]);
V.cmpInsectSpider = cmp('পতঙ্গ বনাম মাকড়সা', 'ইনসেক্টা ও অ্যারাকনিডা।', 'পতঙ্গ (ইনসেক্টা)', 'মাকড়সা (অ্যারাকনিডা)', [
  ['দেহের ভাগ', 'তিনটি — মাথা, বক্ষ, উদর', 'দুটি — শিরোবক্ষ ও উদর'],
  ['পা', '3 জোড়া', '4 জোড়া'],
  ['অ্যান্টেনা', '1 জোড়া', 'নেই'],
  ['ডানা', 'সাধারণত 2 জোড়া', 'নেই'],
  ['চোখ', 'যৌগিক চোখ ও সরল চোখ', 'কেবল সরল চোখ'],
  ['শ্বসন', 'ট্রাকিয়া', 'বুক লাংস ও ট্রাকিয়া']
]);
V.cmpGastroBivalve = cmp('শামুক বনাম ঝিনুক', 'গ্যাস্ট্রোপোডা ও বাইভালভিয়া।', 'আপেল শামুক (Pila)', 'ঝিনুক (Lamellidens)', [
  ['খোলক', 'একটি, পেঁচানো', 'দুটি পাল্লা, কবজায় যুক্ত'],
  ['মাথা', 'সুস্পষ্ট, কর্ষিকা ও চোখসহ', 'নেই'],
  ['র‍্যাডুলা', 'আছে', 'নেই'],
  ['খাদ্যগ্রহণ', 'উদ্ভিদ ঘষে খায়', 'পানি ছেঁকে খাদ্যকণা খায়'],
  ['পদ', 'চ্যাপ্টা, হামাগুড়ি দেয়', 'কুঠার আকৃতি, কাদায় গর্ত করে'],
  ['প্রতিসাম্য', 'টরশনের কারণে অপ্রতিসম', 'দ্বিপার্শ্বীয়']
]);
})();
