/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §১.১ প্রাণিবৈচিত্র্য, শ্রেণিকরণের ভিত্তি ও নীতি
   animalDiv, animalDivBars, orgLevels, bodySymmetry, germLayers, coelomTypes, coelomOrigin,
   metamerism, protoDeutero, zooHierarchy, zooNaming, phylaTree, cmpRadialBilat, cmpDiploTriplo,
   cmpPseudoEu, cmpProtoDeutero
   এখানে B21X (arrow, okm, nope, cmp, layer) রপ্তানি হয় — visuals2–4 এগুলো ব্যবহার করে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B21;
const PI = Math.PI, cl = B.cl, rnd = B.rnd, bn = B.bn, hot = B.hot, lab = B.lab;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
const arrow = (g, x0, y0, x1, y1, c, o = {}) => { const a = Math.atan2(y1 - y0, x1 - x0), h = o.h || 6; E('path', { d: `M${x0} ${y0}L${x1} ${y1}`, stroke: c, 'stroke-width': o.w || 1.6, 'stroke-dasharray': o.dash || null, opacity: o.op != null ? o.op : 1, fill: 'none' }, g); E('path', { d: `M${x1} ${y1}l${-h * Math.cos(a - .45)} ${-h * Math.sin(a - .45)}l${h * Math.cos(a - .45) - h * Math.cos(a + .45)} ${h * Math.sin(a - .45) - h * Math.sin(a + .45)}z`, fill: c, opacity: o.op != null ? o.op : 1 }, g); };
const okm = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y}l${r * .7} ${r * .7}l${r * 1.3} ${-r * 1.4}`, stroke: c, 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, g);
const nope = (g, x, y, r, c) => E('path', { d: `M${x - r} ${y - r}L${x + r} ${y + r}M${x + r} ${y - r}L${x - r} ${y + r}`, stroke: c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g);
/* ভ্রূণস্তরের রং: ectoderm 5, mesoderm 4, endoderm 7, coelom 10 */
const LR = { ec: 5, me: 4, en: 7, co: 10, no: 3, nc: 2 };
const layer = k => BK.ramp(LR[k]);
window.B21X = { arrow, okm, nope, cmp, layer };
const info = (ctx, H, x, y, r) => { const h = hot(H, x, y, r || 26); if (!h) return null; ctx.sel = h[2]; return h[3]; };

/* ═════════ ১. প্রাণিবৈচিত্র্য — পর্বভিত্তিক প্রজাতির সংখ্যা ═════════ */
V.animalDiv = Object.assign({
  t: 'জানা জীবিত প্রাণী প্রজাতি — পর্বভিত্তিক ভাগ', k: ['graph', 'int'],
  cap: 'বর্ণিত (নামকরণ হওয়া) জীবিত প্রাণী প্রজাতি প্রায় 15.3 লক্ষ (Zhang, 2013; জীবাশ্ম বাদে)। এর প্রায় 82% আর্থ্রোপোডা — আর তার বড় অংশ পতঙ্গ। প্রকৃত সংখ্যা এর কয়েক গুণ হতে পারে, কারণ বহু প্রজাতি এখনো অনাবিষ্কৃত। অংশে চাপ দাও।'
}, BK.donut({
  title: 'জীবিত প্রাণী প্রায় 15,25,728 প্রজাতি', center: '15.3 লক্ষ',
  items: [
    ['আর্থ্রোপোডা', 1257040, null, 'প্রায় 12.6 লক্ষ — পতঙ্গ, চিংড়ি, কাঁকড়া, মাকড়সা, বিছা; বর্ণিত পতঙ্গই প্রায় 10 লক্ষ। সবচেয়ে বড় পর্ব।'],
    ['মলাস্কা', 84977, null, 'প্রায় 85 হাজার — শামুক, ঝিনুক, অক্টোপাস; দ্বিতীয় বৃহত্তম পর্ব।'],
    ['কর্ডাটা (মেরুদণ্ডী)', 65458, null, 'মেরুদণ্ডী প্রায় 65 হাজার — মাছ সবচেয়ে বেশি (প্রায় 32 হাজার), তারপর পাখি, সরীসৃপ, উভচর ও স্তন্যপায়ী।'],
    ['প্লাটিহেলমিনথেস', 29487, null, 'প্রায় 29 হাজার — চ্যাপ্টা কৃমি; বড় অংশ পরজীবী (যকৃৎ কৃমি, ফিতাকৃমি)।'],
    ['নেমাটোডা', 25033, null, 'প্রায় 25 হাজার বর্ণিত; প্রকৃত সংখ্যা এর বহু গুণ বলে অনুমান — মাটির এক মুঠোয় হাজার হাজার নেমাটোড।'],
    ['অ্যানেলিডা', 17388, null, 'প্রায় 17 হাজার — কেঁচো, জোঁক, নেরিস।'],
    ['অন্যান্য', 46345, null, 'নিডারিয়া (প্রায় 10 হাজার), পরিফেরা (প্রায় 8.7 হাজার), একাইনোডারমাটা (প্রায় 7.5 হাজার) ও অন্যান্য ছোট পর্ব।']
  ]
}));
V.animalDivBars = Object.assign({
  t: 'আর্থ্রোপোডা বাদে অন্য পর্বগুলো', k: ['graph', 'int'],
  cap: 'আর্থ্রোপোডাকে বাদ দিলে বাকি পর্বগুলোর তুলনা পরিষ্কার দেখা যায় (হাজার প্রজাতি, জীবিত, Zhang 2013)। স্তম্ভে চাপ দাও।'
}, BK.bars({
  title: 'জীবিত প্রজাতি (হাজার)', unit: ' হাজার', d: 1, labW: 118,
  items: [
    ['মলাস্কা', 85.0, null, 'শামুক, ঝিনুক, স্কুইড, অক্টোপাস।'],
    ['মেরুদণ্ডী', 65.5, null, 'মাছ প্রায় 32, পাখি প্রায় 10, সরীসৃপ প্রায় 9.4, উভচর প্রায় 7.7, স্তন্যপায়ী প্রায় 5.8 হাজার (Zhang 2011)।'],
    ['প্লাটিহেলমিনথেস', 29.5, null, 'চ্যাপ্টা কৃমি।'],
    ['নেমাটোডা', 25.0, null, 'গোলকৃমি।'],
    ['অ্যানেলিডা', 17.4, null, 'অঙ্গুরীমাল।'],
    ['নিডারিয়া', 10.2, null, 'হাইড্রা, জেলিফিশ, প্রবাল।'],
    ['পরিফেরা', 8.7, null, 'স্পঞ্জ।'],
    ['একাইনোডারমাটা', 7.6, null, 'তারামাছ, সমুদ্র শজারু — সবাই সামুদ্রিক।']
  ]
}));

/* ═════════ ২. দেহের সংগঠনের মাত্রা ═════════ */
const ORG = {
  cell: [[128, 100, 0, 'কলার কোষ (কোয়ানোসাইট) — ফ্ল্যাজেলা নেড়ে পানির স্রোত তৈরি করে ও খাদ্যকণা ধরে।'], [64, 76, 1, 'পিনাকোসাইট — বাইরের চ্যাপ্টা আবরণী কোষ।'], [96, 150, 2, 'অ্যামিবোসাইট — মেসোহিলে ঘুরে বেড়ায়, খাদ্য বহন করে ও যেকোনো কোষে রূপ নিতে পারে।'], [180, 34, 3, 'অস্কুলাম — পানি বেরোনোর বড় ছিদ্র।'], [40, 120, 4, 'অস্টিয়া — পানি ঢোকার ক্ষুদ্র ছিদ্র।']],
  tis: [[120, 110, 0, 'এপিডার্মিস — বাইরের কোষস্তর (এক্টোডার্ম থেকে)।'], [150, 120, 1, 'মেসোগ্লিয়া — দুই স্তরের মাঝের জেলির মতো কোষবিহীন স্তর।'], [176, 120, 2, 'গ্যাস্ট্রোডার্মিস — ভেতরের কোষস্তর, পরিপাকে অংশ নেয় (এন্ডোডার্ম থেকে)।'], [180, 150, 3, 'সিলেন্টেরন — একমাত্র গহ্বর, মুখ দিয়ে খাদ্য ঢোকে ও বর্জ্য বেরোয়।'], [180, 40, 4, 'কর্ষিকা — নিডোসাইটযুক্ত, শিকার ধরে।']],
  org: [[180, 120, 0, 'শাখান্বিত অন্ত্র — পরিপাকতন্ত্র (পায়ু নেই)।'], [140, 130, 1, 'স্নায়ুরজ্জু ও সংযোগ — মই আকৃতির স্নায়ুতন্ত্র।'], [232, 150, 2, 'শিখা কোষ (প্রোটোনেফ্রিডিয়া) — রেচনতন্ত্র।'], [180, 168, 3, 'গলবিল — খাদ্যগ্রহণ অঙ্গ।'], [180, 52, 4, 'মস্তিষ্কসদৃশ গ্যাংলিয়া ও চক্ষুবিন্দু।']]
};
V.orgLevels = Object.assign({}, B.seg({
  id: 'olv', t: 'দেহের সংগঠনের মাত্রা', H: 236, def: 'cell', sel: null,
  cap: 'প্রাণিদেহ কতটা জটিলভাবে সংগঠিত, তা শ্রেণিকরণের প্রথম ভিত্তি। কোষীয় মাত্রায় কোষগুলো আলাদা কাজ করে কিন্তু টিস্যু গঠন করে না (পরিফেরা); টিস্যু মাত্রায় একই রকম কোষ মিলে টিস্যু (নিডারিয়া); অঙ্গতন্ত্র মাত্রায় টিস্যু মিলে অঙ্গ ও অঙ্গতন্ত্র (প্লাটিহেলমিনথেস থেকে কর্ডাটা)। অংশে চাপ দাও।',
  types: {
    cell: ['কোষীয়', 'কোষীয় মাত্রা — পরিফেরা', 'কোষগুলো শিথিলভাবে যুক্ত, প্রকৃত টিস্যু নেই; আলাদা করে দিলেও কোষগুলো আবার একত্র হতে পারে।'],
    tis: ['টিস্যু', 'টিস্যু মাত্রা — নিডারিয়া', 'দুটি প্রকৃত টিস্যুস্তর (এপিডার্মিস ও গ্যাস্ট্রোডার্মিস) ও তাদের মাঝে মেসোগ্লিয়া; অঙ্গ নেই।'],
    org: ['অঙ্গতন্ত্র', 'অঙ্গতন্ত্র মাত্রা — প্লাটিহেলমিনথেস', 'টিস্যু মিলে অঙ্গ, অঙ্গ মিলে তন্ত্র — পরিপাক, স্নায়ু, রেচন ও জননতন্ত্র আলাদা।']
  },
  art(g, C, ty, ctx) {
    const Re = layer('ec'), Rn = layer('en'), Rm = layer('me');
    if (ty === 'cell') {
      E('path', { d: 'M150 220C110 200 50 170 46 110C44 70 80 40 150 36H210C280 40 316 70 314 110C310 170 250 200 210 220Z', fill: FK.alpha(BK.ramp(6).c, .14), stroke: BK.ramp(6).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M160 210C130 196 86 166 84 112C84 84 110 60 160 56H200C250 60 276 84 276 112C274 166 230 196 200 210Z', fill: FK.alpha(BK.ramp(5).c, .12), stroke: FK.alpha(BK.ramp(6).dk, .5), 'stroke-dasharray': '3 3' }, g);
      const col = [[100, 100], [96, 130], [104, 160], [126, 186], [118, 80], [140, 66], [234, 186], [256, 160], [264, 130], [260, 100], [242, 80], [220, 66]];
      col.forEach(([x, y]) => { E('ellipse', { cx: x, cy: y, rx: 6, ry: 5, fill: FK.alpha(Rn.c, .45), stroke: Rn.dk, 'stroke-width': .8 }, g); E('path', { d: `M${x - 4} ${y - 4}l-2 -6M${x + 4} ${y - 4}l2 -6`, stroke: Rn.dk, 'stroke-width': .8 }, g); });
      [[56, 90], [52, 130], [62, 170], [304, 90], [308, 130], [298, 170], [100, 48], [260, 48]].forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: 9, ry: 3.5, fill: FK.alpha(Re.c, .45), stroke: Re.dk, 'stroke-width': .8 }, g));
      [[96, 150], [270, 70], [80, 110], [286, 140]].forEach(([x, y], i) => B.blob(g, x - 10, y, 5, { n: 7, seed: i + 2, j: .5, fill: FK.alpha(BK.ramp(2).c, .5), stroke: BK.ramp(2).dk, sw: .8 }));
      [[40, 120], [320, 120], [70, 190], [290, 190]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 4, fill: C.sf, stroke: C.fg, 'stroke-width': 1 }, g));
      E('ellipse', { cx: 180, cy: 36, rx: 30, ry: 6, fill: C.sf, stroke: C.fg, 'stroke-width': 1.2 }, g);
      T(g, 180, 132, 'স্পঞ্জোসিল', { fs: 10, a: 'middle', c: C.mu });
    } else if (ty === 'tis') {
      const tent = (x0, s) => E('path', { d: `M${x0} 70Q${x0 + s * 20} 40 ${x0 + s * 34} 22`, fill: 'none', stroke: Re.dk, 'stroke-width': 5, 'stroke-linecap': 'round', opacity: .55 }, g);
      tent(160, -1); tent(200, 1); tent(170, -.4); tent(190, .4);
      E('path', { d: 'M150 70Q120 140 140 210H220Q240 140 210 70Z', fill: FK.alpha(Re.c, .32), stroke: Re.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M158 78Q132 140 150 204H210Q228 140 202 78Z', fill: FK.alpha(BK.ramp(9).c, .25), stroke: 'none' }, g);
      E('path', { d: 'M164 84Q142 140 158 198H202Q218 140 196 84Z', fill: FK.alpha(Rn.c, .4), stroke: Rn.dk, 'stroke-width': 1 }, g);
      E('path', { d: 'M172 92Q156 140 168 190H192Q204 140 188 92Z', fill: C.sf, stroke: 'none' }, g);
      E('path', { d: 'M174 70h12', stroke: C.fg, 'stroke-width': 2 }, g); T(g, 180, 64, 'মুখ', { fs: 9, a: 'middle', c: C.mu });
      T(g, 300, 120, 'দুটি কোষস্তর', { fs: 10, a: 'middle', w: 700, c: C.fg }); T(g, 300, 136, 'দ্বিস্তরী (ডিপ্লোব্লাস্টিক)', { fs: 9, a: 'middle', c: C.mu });
    } else {
      E('path', { d: 'M180 40C212 40 236 70 238 110C240 160 214 214 180 218C146 214 120 160 122 110C124 70 148 40 180 40Z', fill: FK.alpha(BK.ramp(11).c, .2), stroke: BK.ramp(11).dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M180 76V200M180 96L156 84M180 96L204 84M180 116L150 106M180 116L210 106M180 136L148 130M180 136L212 130M180 156L150 156M180 156L210 156M180 176L156 180M180 176L204 180', stroke: Rn.dk, 'stroke-width': 3, fill: 'none', opacity: .7, 'stroke-linecap': 'round' }, g);
      E('path', { d: 'M164 60C150 100 146 160 160 206M196 60C210 100 214 160 200 206M162 100H198M158 140H202M160 180H200', stroke: BK.ramp(2).dk, 'stroke-width': 1.3, fill: 'none' }, g);
      E('ellipse', { cx: 180, cy: 168, rx: 6, ry: 14, fill: FK.alpha(Rm.c, .5), stroke: Rm.dk }, g);
      for (let i = 0; i < 4; i++) { E('path', { d: `M${226 + (i % 2) * 4} ${90 + i * 30}v14`, stroke: layer('ec').dk, 'stroke-width': 1.4 }, g); E('path', { d: `M${134 - (i % 2) * 4} ${90 + i * 30}v14`, stroke: layer('ec').dk, 'stroke-width': 1.4 }, g); }
      E('circle', { cx: 170, cy: 52, r: 3, fill: C.fg }, g); E('circle', { cx: 190, cy: 52, r: 3, fill: C.fg }, g);
      T(g, 300, 110, 'অঙ্গ ও তন্ত্র', { fs: 10, a: 'middle', w: 700, c: C.fg }); T(g, 300, 126, 'ত্রিস্তরী', { fs: 9, a: 'middle', c: C.mu });
    }
    (ORG[ty] || []).forEach(([x, y, i]) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r: 12, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2 }, g); });
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'cell') { for (let i = 0; i < 10; i++) { const k = (t * .25 + i / 10) % 1, sx = i % 2 ? 40 : 320, x = sx + (180 - sx) * k * (k < .6 ? 1 : 1), y = 120 - (120 - 40) * Math.max(0, (k - .55) / .45); E('circle', { cx: k < .6 ? sx + (180 - sx) * (k / .6) : 180, cy: k < .6 ? 120 + (i % 3 - 1) * 20 * (1 - k / .6) : 120 - 84 * ((k - .6) / .4), r: 2.2, fill: BK.ramp(5).dk, opacity: .8 }, g); } }
    else if (ty === 'tis') { const w = Math.sin(t * 2.4) * 6; [[160, -1], [200, 1]].forEach(([x0, s]) => E('path', { d: `M${x0} 70Q${x0 + s * 20 + w} 40 ${x0 + s * 34 + w * 1.5} 22`, fill: 'none', stroke: layer('ec').dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, g)); }
    else { for (let i = 0; i < 4; i++) { const k = .5 + .5 * Math.sin(t * 9 + i); E('path', { d: `M${226 + (i % 2) * 4} ${90 + i * 30}v${6 + k * 8}`, stroke: BK.ramp(2).c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); } }
  },
  tap(x, y, ty, ctx) { const H = ORG[ty].map(([a, b, i, s]) => [a, b, i, s]); return info(ctx, H, x, y, 34) || ''; }
}));

/* ═════════ ৩. প্রতিসাম্য ═════════ */
V.bodySymmetry = Object.assign({}, B.seg({
  id: 'sym', t: 'প্রতিসাম্য (Symmetry)', H: 236, def: 'rad',
  cap: 'প্রতিসাম্য — দেহের কেন্দ্রীয় অক্ষ বরাবর কোনো তল দিয়ে কাটলে দেহ যদি দুটি সমান ও সদৃশ অংশে ভাগ হয়। কতগুলো তলে এমন ভাগ সম্ভব, তা দেখে প্রতিসাম্যের ধরন ঠিক হয়। অ্যানিমেশনে ঘুরন্ত রেখাটি কাটার তল — সবুজ হলে ভাগ সমান।',
  types: {
    asym: ['অপ্রতিসম', 'অপ্রতিসাম্য', 'কোনো তলেই সমান দুই ভাগ হয় না — অধিকাংশ স্পঞ্জ, শামুকের পেঁচানো দেহ।'],
    rad: ['অরীয়', 'অরীয় প্রতিসাম্য', 'কেন্দ্রীয় অক্ষ দিয়ে যাওয়া যেকোনো উল্লম্ব তলে সমান দুই ভাগ — হাইড্রা, জেলিফিশ। স্থির বা ভাসমান জীবনে চারদিক থেকে খাদ্য ধরতে সুবিধা।'],
    bir: ['দ্বি-অরীয়', 'দ্বি-অরীয় প্রতিসাম্য', 'মাত্র দুটি তলে সমান ভাগ — সি-অ্যানিমোন (দুই প্রান্তে খাঁজ, সাইফোনোগ্লিফ), টিনোফোরা।'],
    pent: ['পঞ্চ-অরীয়', 'পঞ্চ-অরীয় প্রতিসাম্য', 'পাঁচটি তলে সমান ভাগ — পরিণত একাইনোডার্ম (তারামাছ)। এদের লার্ভা কিন্তু দ্বিপার্শ্বীয়!'],
    bil: ['দ্বিপার্শ্বীয়', 'দ্বিপার্শ্বীয় প্রতিসাম্য', 'কেবল একটি তলে (মধ্য-সাজিটাল) সমান ডান ও বাম ভাগ — প্লাটিহেলমিনথেস থেকে কর্ডাটা। সামনে মাথা (সেফালাইজেশন), নির্দিষ্ট দিকে চলাচল।']
  },
  art(g, C, ty) {
    const cx = 150, cy = 122, R5 = BK.ramp(5), R3 = BK.ramp(3), R2 = BK.ramp(2), R10 = BK.ramp(10);
    if (ty === 'asym') { B.blob(g, cx, cy, 70, { n: 11, seed: 7, j: .55, fill: FK.alpha(BK.ramp(6).c, .3), stroke: BK.ramp(6).dk, sw: 1.4 }); for (let i = 0; i < 9; i++) E('circle', { cx: cx - 40 + rnd(i) * 80, cy: cy - 40 + rnd(i + 5) * 80, r: 3, fill: C.sf, stroke: BK.ramp(6).dk }, g); }
    else if (ty === 'rad') { E('circle', { cx, cy, r: 46, fill: FK.alpha(R5.c, .25), stroke: R5.dk, 'stroke-width': 1.4 }, g); for (let i = 0; i < 8; i++) { const a = i / 8 * PI * 2; E('path', { d: `M${cx + 46 * Math.cos(a)} ${cy + 46 * Math.sin(a)}L${cx + 88 * Math.cos(a)} ${cy + 88 * Math.sin(a)}`, stroke: R5.dk, 'stroke-width': 6, 'stroke-linecap': 'round', opacity: .5 }, g); } E('circle', { cx, cy, r: 9, fill: C.sf, stroke: C.fg }, g); T(g, cx, cy + 22, 'মুখ', { fs: 9, a: 'middle', c: C.mu }); }
    else if (ty === 'bir') { E('ellipse', { cx, cy, rx: 82, ry: 56, fill: FK.alpha(BK.ramp(0).c, .25), stroke: BK.ramp(0).dk, 'stroke-width': 1.4 }, g); E('ellipse', { cx, cy, rx: 30, ry: 12, fill: C.sf, stroke: C.fg }, g); E('path', { d: `M${cx - 30} ${cy}l-8 -5v10zM${cx + 30} ${cy}l8 -5v10z`, fill: BK.ramp(4).dk }, g); for (let i = 0; i < 16; i++) { const a = i / 16 * PI * 2; E('circle', { cx: cx + 70 * Math.cos(a), cy: cy + 46 * Math.sin(a), r: 4, fill: FK.alpha(BK.ramp(0).dk, .4) }, g); } }
    else if (ty === 'pent') { let d = ''; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i / 10 * PI * 2, r = i % 2 ? 30 : 86; d += (i ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(1) + ' ' + (cy + r * Math.sin(a)).toFixed(1); } E('path', { d: d + 'Z', fill: FK.alpha(R2.c, .35), stroke: R2.dk, 'stroke-width': 1.5, 'stroke-linejoin': 'round' }, g); for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * PI * 2; for (let k = 1; k < 5; k++) E('circle', { cx: cx + (16 + k * 14) * Math.cos(a), cy: cy + (16 + k * 14) * Math.sin(a), r: 2.2, fill: R2.dk }, g); } E('circle', { cx, cy, r: 6, fill: C.sf, stroke: C.fg }, g); }
    else { E('ellipse', { cx, cy: cy + 10, rx: 22, ry: 70, fill: FK.alpha(R10.c, .3), stroke: R10.dk, 'stroke-width': 1.4 }, g); E('circle', { cx, cy: cy - 72, r: 16, fill: FK.alpha(R10.c, .4), stroke: R10.dk, 'stroke-width': 1.4 }, g); [-1, 1].forEach(s => { E('circle', { cx: cx + s * 7, cy: cy - 76, r: 3, fill: C.fg }, g); E('path', { d: `M${cx + s * 18} ${cy - 20}L${cx + s * 66} ${cy - 46}M${cx + s * 20} ${cy + 10}L${cx + s * 70} ${cy + 10}M${cx + s * 18} ${cy + 40}L${cx + s * 62} ${cy + 74}`, stroke: R10.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, g); });
      T(g, cx, 20, 'সম্মুখ (মাথা)', { fs: 9, a: 'middle', c: C.mu }); T(g, cx, 230, 'পশ্চাৎ', { fs: 9, a: 'middle', c: C.mu }); T(g, cx - 82, cy + 4, 'বাম', { fs: 9, a: 'middle', c: C.mu }); T(g, cx + 82, cy + 4, 'ডান', { fs: 9, a: 'middle', c: C.mu }); }
    const n = { asym: '0', rad: '∞', bir: '2', pent: '5', bil: '1' }[ty];
    E('rect', { x: 262, y: 84, width: 84, height: 70, rx: 12, fill: FK.alpha(R3.c, .12), stroke: R3.dk }, g); T(g, 304, 112, 'সমান ভাগের তল', { fs: 9.4, a: 'middle', c: C.mu }); T(g, 304, 140, n === '∞' ? 'অসংখ্য' : n + 'টি', { fs: 16, a: 'middle', w: 800, c: R3.ink });
  },
  anim(g, C, ty, t) {
    const cx = 150, cy = 122, P = { asym: 0, rad: 0, bir: PI / 2, pent: PI / 5, bil: PI }[ty], ang = ty === 'bil' ? PI / 2 + Math.sin(t * .8) * .9 : t * .6;
    let good = ty === 'rad'; if (P) { const m = (((ang - PI / 2) % P) + P) % P; good = Math.min(m, P - m) < .05; }
    const R = good ? BK.ramp(10) : BK.ramp(4);
    E('path', { d: `M${cx - 100 * Math.cos(ang)} ${cy - 100 * Math.sin(ang)}L${cx + 100 * Math.cos(ang)} ${cy + 100 * Math.sin(ang)}`, stroke: R.dk, 'stroke-width': good ? 2.6 : 1.6, 'stroke-dasharray': good ? null : '5 4', opacity: .9 }, g);
  }
}));

/* ═════════ ৪. ভ্রূণস্তর — জাইগোট থেকে গ্যাস্ট্রুলা ═════════ */
V.germLayers = Object.assign({ t: 'ভ্রূণস্তর — দ্বিস্তরী ও ত্রিস্তরী', k: ['anim', 'steps'], cap: 'ভ্রূণের প্রাথমিক দশায় যে কোষস্তরগুলো তৈরি হয় এবং পরে যাদের থেকে সব টিস্যু ও অঙ্গ গড়ে ওঠে, তাদের ভ্রূণস্তর (germ layer) বলে। গ্যাস্ট্রুলেশনে এক্টোডার্ম (বাইরে) ও এন্ডোডার্ম (ভেতরে) তৈরি হয় — এ দুই নিয়ে দ্বিস্তরী প্রাণী (নিডারিয়া); মাঝে মেসোডার্ম যুক্ত হলে ত্রিস্তরী (প্লাটিহেলমিনথেস থেকে কর্ডাটা)।' }, BK.steps({
  W: 360, H: 230, label: 'ভ্রূণস্তর গঠন', dur: 3,
  stages: [
    { t: 'জাইগোট', en: 'Zygote', d: 'নিষিক্ত ডিম্বাণু — একটি কোষ।' },
    { t: 'ক্লিভেজ ও ব্লাস্টুলা', en: 'Blastula', d: 'বারবার বিভাজনে কোষের ফাঁপা গোলক; ভেতরের গহ্বর ব্লাস্টোসিল।' },
    { t: 'গ্যাস্ট্রুলা — দ্বিস্তরী', en: 'Diploblastic', d: 'এক পাশ ভেতরে ঢুকে (ইনভ্যাজিনেশন) দুই স্তর: বাইরে এক্টোডার্ম, ভেতরে এন্ডোডার্ম; নতুন গহ্বর আর্কেন্টেরন, মুখ ব্লাস্টোপোর। নিডারিয়া এ পর্যায়ে থেমে যায় — মাঝে কেবল মেসোগ্লিয়া।' },
    { t: 'মেসোডার্ম — ত্রিস্তরী', en: 'Triploblastic', d: 'এক্টোডার্ম ও এন্ডোডার্মের মাঝে তৃতীয় স্তর মেসোডার্ম — প্লাটিহেলমিনথেস থেকে কর্ডাটা পর্যন্ত সব প্রাণী ত্রিস্তরী।' },
    { t: 'কোন স্তর থেকে কী', en: 'Derivatives', d: 'এক্টোডার্ম → ত্বকের এপিডার্মিস, স্নায়ুতন্ত্র; মেসোডার্ম → পেশি, কঙ্কাল, রক্ত ও সংবহনতন্ত্র, বৃক্ক, জননাঙ্গ; এন্ডোডার্ম → পৌষ্টিকনালির আবরণ, যকৃৎ, অগ্ন্যাশয়, ফুসফুসের আবরণ।' }
  ],
  draw(g, C, s, u) {
    const cx = 130, cy = 116, Re = layer('ec'), Rn = layer('en'), Rm = layer('me');
    if (s === 0) { E('circle', { cx, cy, r: 46 + u * 4, fill: FK.alpha(BK.ramp(7).c, .25), stroke: BK.ramp(7).dk, 'stroke-width': 1.6 }, g); E('circle', { cx: cx + 6, cy: cy - 4, r: 10, fill: FK.alpha(BK.ramp(3).c, .5), stroke: BK.ramp(3).dk }, g); }
    else if (s === 1) { const n = 18; E('circle', { cx, cy, r: 50, fill: FK.alpha(BK.ramp(9).c, .12), stroke: 'none' }, g); for (let i = 0; i < n; i++) { const a = i / n * PI * 2, r = 42 + 8 * u * 0; E('circle', { cx: cx + 44 * Math.cos(a), cy: cy + 44 * Math.sin(a), r: 7.5, fill: FK.alpha(Re.c, .4), stroke: Re.dk, 'stroke-width': .9 }, g); } T(g, cx, cy + 4, 'ব্লাস্টোসিল', { fs: 9, a: 'middle', c: C.mu }); }
    else {
      const k = s === 2 ? u : 1;
      E('path', { d: `M${cx - 52} ${cy}A52 52 0 1 1 ${cx + 52} ${cy}L${cx + 16} ${cy + 52}H${cx - 16}Z`, fill: 'none' }, g);
      const outer = `M${cx - 14} ${cy + 52}A54 54 0 1 1 ${cx + 14} ${cy + 52}`;
      E('path', { d: outer, fill: 'none', stroke: Re.c, 'stroke-width': 12, opacity: .7 }, g);
      const depth = 24 + 60 * k;
      E('path', { d: `M${cx - 14} ${cy + 52}Q${cx - 30} ${cy + 52 - depth} ${cx} ${cy + 52 - depth}Q${cx + 30} ${cy + 52 - depth} ${cx + 14} ${cy + 52}`, fill: 'none', stroke: Rn.c, 'stroke-width': 11, opacity: .75 }, g);
      if (s >= 3) { const km = s === 3 ? u : 1; E('path', { d: `M${cx - 40} ${cy + 26}Q${cx - 48} ${cy - 20} ${cx - 24} ${cy - 34}M${cx + 40} ${cy + 26}Q${cx + 48} ${cy - 20} ${cx + 24} ${cy - 34}`, fill: 'none', stroke: Rm.c, 'stroke-width': 10 * km, opacity: .8, 'stroke-linecap': 'round' }, g); }
      T(g, cx, cy + 22, 'আর্কেন্টেরন', { fs: 8.6, a: 'middle', c: C.mu }); T(g, cx, cy + 66, 'ব্লাস্টোপোর', { fs: 8.6, a: 'middle', c: C.mu });
    }
    const L = [['এক্টোডার্ম', Re, s >= 1], ['মেসোডার্ম', Rm, s >= 3], ['এন্ডোডার্ম', Rn, s >= 2]];
    if (s < 4) L.forEach(([n, R, on], i) => { E('rect', { x: 236, y: 60 + i * 34, width: 108, height: 24, rx: 8, fill: on ? FK.alpha(R.c, .3) : FK.alpha(C.mu, .06), stroke: on ? R.dk : C.ln }, g); T(g, 290, 76 + i * 34, n, { fs: 10.5, a: 'middle', w: 700, c: on ? R.ink : C.mu }); });
    else { const rows = [['এক্টোডার্ম', Re, 'ত্বক, স্নায়ুতন্ত্র'], ['মেসোডার্ম', Rm, 'পেশি, অস্থি, রক্ত, বৃক্ক'], ['এন্ডোডার্ম', Rn, 'অন্ত্রের আবরণ, যকৃৎ']]; rows.forEach(([n, R, d], i) => { const y = 40 + i * 54; E('rect', { x: 204, y, width: 148, height: 44, rx: 10, fill: FK.alpha(R.c, .2), stroke: R.dk }, g); T(g, 278, y + 18, n, { fs: 10.5, a: 'middle', w: 700, c: R.ink }); T(g, 278, y + 34, d, { fs: 9, a: 'middle', c: C.fg }); arrow(g, 188, 116, 202, y + 22, R.dk, { w: 1.2, h: 5 }); }); }
  }
}));

/* ═════════ ৫. সিলোমের ধরন ═════════ */
const COE = {
  acoel: [[0, 'এক্টোডার্ম (দেহপ্রাচীরের বাইরের স্তর)'], [1, 'মেসোডার্ম — এখানে কোষে ভরা প্যারেনকাইমা; কোনো গহ্বর নেই'], [3, 'এন্ডোডার্ম — অন্ত্রের আবরণ'], [4, 'অন্ত্রের গহ্বর']],
  pseudo: [[0, 'এক্টোডার্ম'], [1, 'মেসোডার্ম — কেবল দেহপ্রাচীরের দিকে'], [2, 'ছদ্মসিলোম — মেসোডার্ম ও এন্ডোডার্মের মাঝে; পুরোপুরি মেসোডার্মে আবৃত নয় (ব্লাস্টোসিলের অবশেষ)'], [3, 'এন্ডোডার্ম — অন্ত্রের চারপাশে মেসোডার্ম নেই'], [4, 'অন্ত্রের গহ্বর']],
  eu: [[0, 'এক্টোডার্ম'], [1, 'প্যারাইটাল মেসোডার্ম — দেহপ্রাচীরের দিকে (সোমাটিক)'], [2, 'প্রকৃত সিলোম — চারদিকে মেসোডার্মে (পেরিটোনিয়ামে) আবৃত তরলপূর্ণ গহ্বর'], [5, 'ভিসেরাল মেসোডার্ম — অন্ত্রের দিকে (স্প্ল্যাংকনিক)'], [3, 'এন্ডোডার্ম'], [4, 'অন্ত্রের গহ্বর']]
};
V.coelomTypes = Object.assign({}, B.seg({
  id: 'coe', t: 'দেহগহ্বর বা সিলোমের ধরন (প্রস্থচ্ছেদ)', H: 236, def: 'eu', sel: null,
  cap: 'সিলোম — দেহপ্রাচীর ও পৌষ্টিকনালির মাঝে মেসোডার্মে আবৃত তরলপূর্ণ গহ্বর। গহ্বর আছে কি না এবং তা মেসোডার্মে কতটা আবৃত, তার ভিত্তিতে প্রাণী তিন রকম — অ্যাসিলোমেট, সিউডোসিলোমেট ও ইউসিলোমেট। স্তরে চাপ দাও।',
  types: {
    acoel: ['অ্যাসিলোমেট', 'অ্যাসিলোমেট (সিলোমবিহীন)', 'দেহপ্রাচীর ও অন্ত্রের মাঝের জায়গা মেসোডার্মজাত প্যারেনকাইমায় ভরা — প্লাটিহেলমিনথেস (প্লানেরিয়া, যকৃৎ কৃমি, ফিতাকৃমি)।'],
    pseudo: ['সিউডোসিলোমেট', 'সিউডোসিলোমেট (ছদ্মসিলোম)', 'গহ্বর আছে, কিন্তু মেসোডার্ম কেবল দেহপ্রাচীরের দিকে, অন্ত্রের দিকে নেই — নেমাটোডা (গোলকৃমি)।'],
    eu: ['ইউসিলোমেট', 'ইউসিলোমেট (প্রকৃত সিলোম)', 'গহ্বর চারদিকে মেসোডার্মে আবৃত; অঙ্গগুলো মেসেন্টারিতে ঝোলানো — মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা, একাইনোডারমাটা, কর্ডাটা।']
  },
  art(g, C, ty, ctx) {
    const cx = 130, cy = 120, Re = layer('ec'), Rm = layer('me'), Rn = layer('en'), Rc = layer('co'), s = ctx.sel;
    const ring = (r0, r1, R, a, i) => { E('path', { d: `M${cx - r1} ${cy}A${r1} ${r1} 0 1 0 ${cx + r1} ${cy}A${r1} ${r1} 0 1 0 ${cx - r1} ${cy}ZM${cx - r0} ${cy}A${r0} ${r0} 0 1 1 ${cx + r0} ${cy}A${r0} ${r0} 0 1 1 ${cx - r0} ${cy}Z`, fill: FK.alpha(R.c, a), 'fill-rule': 'evenodd', stroke: s === i ? BK.ramp(4).dk : R.dk, 'stroke-width': s === i ? 2.6 : 1 }, g); };
    ring(90, 100, Re, .55, 0);
    if (ty === 'acoel') { ring(40, 90, Rm, .32, 1); for (let i = 0; i < 40; i++) { const a = rnd(i) * PI * 2, r = 46 + rnd(i + 40) * 40; E('circle', { cx: cx + r * Math.cos(a), cy: cy + r * Math.sin(a), r: 2.4, fill: FK.alpha(Rm.dk, .5) }, g); } }
    else if (ty === 'pseudo') { ring(80, 90, Rm, .55, 1); ring(40, 80, BK.ramp(9), .06, 2); }
    else { ring(80, 90, Rm, .55, 1); ring(50, 80, Rc, .25, 2); ring(40, 50, Rm, .55, 5); E('path', { d: `M${cx} ${cy - 50}V${cy - 80}`, stroke: Rm.dk, 'stroke-width': 4 }, g); T(g, cx + 20, cy - 62, 'মেসেন্টারি', { fs: 8.4, c: C.mu }); }
    ring(28, 40, Rn, .6, 3);
    E('circle', { cx, cy, r: 28, fill: s === 4 ? FK.alpha(BK.ramp(4).c, .15) : C.sf, stroke: 'none' }, g); T(g, cx, cy + 4, 'অন্ত্র', { fs: 9.4, a: 'middle', c: C.mu });
    const L = [['এক্টোডার্ম', Re], ['মেসোডার্ম', Rm], ['এন্ডোডার্ম', Rn], [ty === 'eu' ? 'প্রকৃত সিলোম' : ty === 'pseudo' ? 'ছদ্মসিলোম' : 'গহ্বর নেই', ty === 'acoel' ? BK.ramp(9) : Rc]];
    L.forEach(([n, R], i) => { E('rect', { x: 250, y: 60 + i * 30, width: 14, height: 14, rx: 3, fill: FK.alpha(R.c, .6), stroke: R.dk }, g); T(g, 270, 72 + i * 30, n, { fs: 10, c: C.fg }); });
    const ex = { acoel: 'প্লানেরিয়া', pseudo: 'অ্যাসকারিস', eu: 'কেঁচো, মানুষ' }[ty]; T(g, 300, 200, 'উদাহরণ: ' + ex, { fs: 9.6, a: 'middle', w: 700, c: C.fg });
  },
  anim(g, C, ty, t) { if (!t || ty === 'acoel') return; const cx = 130, cy = 120, R = ty === 'eu' ? layer('co') : BK.ramp(9); for (let i = 0; i < 14; i++) { const a = i / 14 * PI * 2 + t * .4 * (i % 2 ? 1 : -1), r = ty === 'eu' ? 65 : 60 + 10 * Math.sin(t + i); E('circle', { cx: cx + r * Math.cos(a), cy: cy + r * Math.sin(a), r: 2, fill: R.dk, opacity: .55 }, g); } },
  tap(x, y, ty, ctx) {
    const d = Math.hypot(x - 130, y - 120); if (d > 104) return '';
    const map = ty === 'acoel' ? (d > 90 ? 0 : d > 40 ? 1 : d > 28 ? 3 : 4) : ty === 'pseudo' ? (d > 90 ? 0 : d > 80 ? 1 : d > 40 ? 2 : d > 28 ? 3 : 4) : (d > 90 ? 0 : d > 80 ? 1 : d > 50 ? 2 : d > 40 ? 5 : d > 28 ? 3 : 4);
    ctx.sel = map; const r = COE[ty].find(z => z[0] === map); return r ? `<b>${r[1].split(' — ')[0]}</b>${r[1].includes(' — ') ? ' — ' + r[1].split(' — ').slice(1).join(' — ') : ''}` : '';
  }
}));

/* ═════════ ৬. সিলোমের উৎপত্তি ═════════ */
V.coelomOrigin = Object.assign({}, B.seg({
  id: 'cor', t: 'প্রকৃত সিলোম কীভাবে তৈরি হয়', H: 230, def: 'schizo',
  cap: 'প্রকৃত সিলোম দুই উপায়ে তৈরি হয়। সাইজোসিলোম — ব্লাস্টোপোরের কাছের মেসোডার্ম কোষপিণ্ড চিরে (ফেটে) গহ্বর তৈরি হয় (প্রোটোস্টোম: মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা)। এন্টেরোসিলোম — আর্কেন্টেরনের প্রাচীর থলির মতো বাইরে বেরিয়ে আলাদা হয়ে গহ্বর হয় (ডিউটেরোস্টোম: একাইনোডারমাটা, কর্ডাটা)। চালাও চাপলে প্রক্রিয়া দেখবে।',
  types: { schizo: ['সাইজোসিলোম', 'সাইজোসিলোম — মেসোডার্ম চিরে', 'মেসোডার্মের কঠিন কোষপিণ্ডের ভেতরে ফাটল ধরে, তা বড় হয়ে সিলোম হয় — মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা।'], entero: ['এন্টেরোসিলোম', 'এন্টেরোসিলোম — অন্ত্রের থলি থেকে', 'আর্কেন্টেরনের প্রাচীর থেকে থলি বেরিয়ে মূল অন্ত্র থেকে বিচ্ছিন্ন হয়; থলির গহ্বরই সিলোম — একাইনোডারমাটা, কর্ডাটা।'] },
  art(g, C, ty) {
    E('path', { d: 'M40 40H200V200H40Z', fill: 'none' }, g);
    T(g, 290, 60, ty === 'schizo' ? 'প্রোটোস্টোম' : 'ডিউটেরোস্টোম', { fs: 12, a: 'middle', w: 700, c: BK.ramp(ty === 'schizo' ? 2 : 5).ink });
    T(g, 290, 80, ty === 'schizo' ? 'মলাস্কা · অ্যানেলিডা · আর্থ্রোপোডা' : 'একাইনোডারমাটা · কর্ডাটা', { fs: 9, a: 'middle', c: C.mu });
    [['এক্টোডার্ম', 'ec'], ['মেসোডার্ম', 'me'], ['এন্ডোডার্ম', 'en'], ['সিলোম', 'co']].forEach(([n, k], i) => { const R = layer(k); E('rect', { x: 246, y: 110 + i * 24, width: 12, height: 12, rx: 3, fill: FK.alpha(R.c, .6), stroke: R.dk }, g); T(g, 264, 120 + i * 24, n, { fs: 9.6, c: C.fg }); });
  },
  anim(g, C, ty, t) {
    const k = ((t || 0) * .22) % 1, ph = k < .8 ? k / .8 : 1, cx = 120, cy = 120, Re = layer('ec'), Rm = layer('me'), Rn = layer('en'), Rc = layer('co');
    E('circle', { cx, cy, r: 86, fill: FK.alpha(BK.ramp(9).c, .08), stroke: Re.c, 'stroke-width': 12, opacity: .8 }, g);
    E('path', { d: `M${cx - 12} ${cy + 86}V${cy - 30}Q${cx} ${cy - 44} ${cx + 12} ${cy - 30}V${cy + 86}`, fill: FK.alpha(Rn.c, .25), stroke: Rn.c, 'stroke-width': 9 }, g);
    if (ty === 'schizo') { [-1, 1].forEach(s => { const x = cx + s * 44; E('ellipse', { cx: x, cy: cy + 10, rx: 22, ry: 40, fill: FK.alpha(Rm.c, .6), stroke: Rm.dk }, g); E('ellipse', { cx: x, cy: cy + 10, rx: 15 * ph, ry: 32 * ph, fill: FK.alpha(Rc.c, .55), stroke: ph > .05 ? Rc.dk : 'none' }, g); }); }
    else { [-1, 1].forEach(s => { const off = 14 + 30 * ph, x = cx + s * off; E('path', { d: `M${cx + s * 12} ${cy - 10}Q${cx + s * (14 + 10 * ph)} ${cy - 8} ${x} ${cy}`, stroke: Rm.c, 'stroke-width': 7, fill: 'none', opacity: ph < .7 ? 1 : 1 - (ph - .7) / .3 }, g); E('circle', { cx: x, cy, r: 6 + 18 * ph, fill: FK.alpha(Rc.c, .55), stroke: Rm.dk, 'stroke-width': 4 }, g); }); }
    T(g, cx, 222, ph < 1 ? 'গঠিত হচ্ছে…' : 'সিলোম তৈরি', { fs: 9.6, a: 'middle', c: C.mu });
  }
}));

/* ═════════ ৭. খণ্ডায়ন ═════════ */
V.metamerism = Object.assign({}, B.seg({
  id: 'met', t: 'খণ্ডায়ন বা মেটামেরিজম', H: 210, def: 'true',
  cap: 'খণ্ডায়ন — দেহ দৈর্ঘ্য বরাবর ধারাবাহিক একই রকম খণ্ডে (মেটামিয়ার বা সোমাইট) ভাগ হওয়া, যেখানে প্রতিটি খণ্ডে বাইরের গঠনের সাথে ভেতরের অঙ্গও (পেশি, স্নায়ু গ্যাংলিয়া, রেচন অঙ্গ) পুনরাবৃত্ত হয়। অ্যানেলিডা, আর্থ্রোপোডা ও কর্ডাটায় প্রকৃত খণ্ডায়ন; ফিতাকৃমির খণ্ড ছদ্মখণ্ডায়ন।',
  types: {
    true: ['প্রকৃত', 'প্রকৃত খণ্ডায়ন — কেঁচো', 'বাইরের বলয়ের সাথে ভেতরে সেপ্টাম দিয়ে আলাদা প্রতিটি খণ্ডে একজোড়া নেফ্রিডিয়া, স্নায়ু গ্যাংলিয়া ও পেশি — পুরোনো খণ্ড সামনে, নতুন খণ্ড পেছনে যুক্ত হয়।'],
    pseudo: ['ছদ্ম', 'ছদ্মখণ্ডায়ন — ফিতাকৃমি', 'প্রোগ্লটিডগুলো ঘাড়ের অংশ থেকে মুকুলের মতো তৈরি হয়; প্রতিটি স্বাধীন জনন একক, সবচেয়ে পুরোনো (গ্র্যাভিড) প্রোগ্লটিড পেছনের প্রান্তে ও খসে পড়ে — প্রকৃত খণ্ডের মতো সমন্বিত নয়।'],
    none: ['খণ্ডহীন', 'খণ্ডায়ন নেই — গোলকৃমি', 'অ্যাসকারিসের নলাকার দেহে কোনো খণ্ড নেই; বাইরে কেবল সূক্ষ্ম ভাঁজ (কিউটিকল)।']
  },
  art(g, C, ty) {
    if (ty === 'true') { const R = BK.ramp(4); for (let i = 0; i < 16; i++) { const x = 30 + i * 19; E('rect', { x, y: 70, width: 18, height: 44, rx: 7, fill: FK.alpha(R.c, i >= 13 && i <= 14 ? .5 : .25), stroke: R.dk, 'stroke-width': .9 }, g); E('circle', { cx: x + 9, cy: 108, r: 2.2, fill: BK.ramp(2).dk }, g); E('path', { d: `M${x + 4} 80q4 6 0 12M${x + 14} 80q-4 6 0 12`, stroke: BK.ramp(5).dk, 'stroke-width': .9, fill: 'none' }, g); }
      E('path', { d: 'M39 108H334', stroke: BK.ramp(2).dk, 'stroke-width': 1 }, g); T(g, 300, 62, 'ক্লাইটেলাম', { fs: 9, a: 'middle', c: C.mu }); T(g, 40, 140, 'প্রতিটি খণ্ডে: স্নায়ু গ্যাংলিয়া (কমলা) · নেফ্রিডিয়া জোড়া (নীল) · সেপ্টাম', { fs: 9, c: C.mu }); T(g, 34, 58, 'মুখ', { fs: 9, c: C.mu }); }
    else if (ty === 'pseudo') { const R = BK.ramp(7); E('circle', { cx: 30, cy: 92, r: 10, fill: FK.alpha(R.c, .5), stroke: R.dk }, g); for (let i = 0; i < 6; i++) { const a = i / 6 * PI * 2; E('path', { d: `M${30 + 10 * Math.cos(a)} ${92 + 10 * Math.sin(a)}l${3 * Math.cos(a)} ${3 * Math.sin(a)}`, stroke: C.fg, 'stroke-width': 1.4 }, g); } E('path', { d: 'M40 92H56', stroke: R.dk, 'stroke-width': 4 }, g);
      let px = 56; for (let i = 0; i < 14; i++) { const w = 8 + i * 1.3, h = 8 + i * 2.6, x = px; px += w + 1.5; E('rect', { x, y: 92 - h / 2, width: w + 7, height: h, rx: 2, fill: FK.alpha(R.c, .2 + i / 30), stroke: R.dk, 'stroke-width': .8 }, g); if (i > 9) for (let k = 0; k < 5; k++) E('circle', { cx: x + 2 + rnd(i * 5 + k) * (w - 4), cy: 92 - h / 2 + 3 + rnd(i + k * 7) * (h - 6), r: 1.4, fill: BK.ramp(2).dk }, g); }
      T(g, 30, 124, 'স্কোলেক্স', { fs: 9, a: 'middle', c: C.mu }); T(g, 120, 140, 'অপরিণত', { fs: 9, a: 'middle', c: C.mu }); T(g, 196, 140, 'পরিণত', { fs: 9, a: 'middle', c: C.mu }); T(g, 266, 140, 'গ্র্যাভিড (ডিমে ভরা)', { fs: 9, a: 'middle', c: C.mu }); arrow(g, 70, 164, 320, 164, C.mu, { w: 1.2 }); T(g, 195, 182, 'নতুন প্রোগ্লটিড ঘাড়ে তৈরি → পুরোনোগুলো পেছনে সরে', { fs: 9, a: 'middle', c: C.fg }); }
    else { const R = BK.ramp(11); E('path', { d: 'M24 96Q40 80 120 82T300 86Q330 88 338 98Q330 108 300 110T120 112Q40 114 24 96Z', fill: FK.alpha(R.c, .35), stroke: R.dk, 'stroke-width': 1.3 }, g); for (let i = 0; i < 30; i++) E('path', { d: `M${44 + i * 9} 86v22`, stroke: FK.alpha(R.dk, .18), 'stroke-width': .7 }, g); T(g, 40, 136, 'অ্যাসকারিস — নলাকার, দুই প্রান্ত সরু, খণ্ডহীন', { fs: 9.6, c: C.mu }); }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'true') { const p = (t * 3) % 19; for (let i = 0; i < 16; i++) { const d = Math.abs(i - p); if (d < 1.5) E('rect', { x: 30 + i * 19 - 1, y: 66, width: 20, height: 52, rx: 8, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2 * (1.5 - d) }, g); } }
    else if (ty === 'pseudo') { const k = (t * .4) % 1; E('rect', { x: 56, y: 88, width: 6 * k + 1, height: 8, rx: 2, fill: BK.ramp(7).c, opacity: .9 }, g); const fx = 300 + k * 12; E('rect', { x: fx, y: 74 + k * 24, width: 24, height: 40, rx: 2, fill: FK.alpha(BK.ramp(7).c, .5 * (1 - k)), stroke: BK.ramp(7).dk, opacity: 1 - k }, g); }
    else { const w = Math.sin(t * 2.2) * 6; E('path', { d: `M24 96Q40 ${80 + w} 120 ${82 - w}T300 ${86 + w}`, fill: 'none', stroke: BK.ramp(11).dk, 'stroke-width': 1.4, opacity: .5 }, g); }
  }
}));

/* ═════════ ৮. প্রোটোস্টোম ও ডিউটেরোস্টোম ═════════ */
V.protoDeutero = Object.assign({}, B.seg({
  id: 'pds', t: 'প্রোটোস্টোম ও ডিউটেরোস্টোম', H: 236, def: 'proto',
  cap: 'ভ্রূণের ব্লাস্টোপোর (গ্যাস্ট্রুলার প্রথম ছিদ্র) পরে মুখ হয় নাকি পায়ু — এ ভিত্তিতে ত্রিস্তরী প্রাণী দুই দলে। প্রোটোস্টোমে ("আগে মুখ") ব্লাস্টোপোর থেকে মুখ, পায়ু পরে তৈরি; ডিউটেরোস্টোমে ("পরে মুখ") ব্লাস্টোপোর থেকে পায়ু, মুখ পরে বিপরীত প্রান্তে। সাথে ক্লিভেজ ও সিলোম গঠনের ধরনও আলাদা।',
  types: {
    proto: ['প্রোটোস্টোম', 'প্রোটোস্টোম', 'ব্লাস্টোপোর → মুখ; সর্পিল ও নির্ধারিত ক্লিভেজ; সাইজোসিলোম — মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা (প্লাটিহেলমিনথেস ও নেমাটোডাও প্রোটোস্টোম দলে ধরা হয়)।'],
    deut: ['ডিউটেরোস্টোম', 'ডিউটেরোস্টোম', 'ব্লাস্টোপোর → পায়ু; অরীয় ও অনির্ধারিত ক্লিভেজ (প্রাথমিক কোষ আলাদা করলেও পূর্ণ ভ্রূণ হতে পারে — অভিন্ন যমজের ভিত্তি); এন্টেরোসিলোম — একাইনোডারমাটা, কর্ডাটা।']
  },
  art(g, C, ty) {
    const pr = ty === 'proto', Re = layer('ec'), Rn = layer('en');
    E('ellipse', { cx: 110, cy: 118, rx: 70, ry: 90, fill: FK.alpha(Re.c, .15), stroke: Re.dk, 'stroke-width': 1.6 }, g);
    E('circle', { cx: 110, cy: 208, r: 7, fill: C.sf, stroke: C.fg, 'stroke-width': 1.4 }, g);
    T(g, 110, 232, 'ব্লাস্টোপোর → ' + (pr ? 'মুখ' : 'পায়ু'), { fs: 10, a: 'middle', w: 700, c: BK.ramp(pr ? 2 : 5).ink });
    T(g, 110, 22, (pr ? 'পায়ু' : 'মুখ') + ' (পরে তৈরি)', { fs: 9.6, a: 'middle', c: C.mu });
    T(g, 276, 40, 'ক্লিভেজ', { fs: 10, a: 'middle', w: 700, c: C.fg });
    const cx = 276, cy = 92;
    if (pr) { [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(([i, j]) => E('circle', { cx: cx - 14 + i * 28, cy: cy + 10 - j * 0 + j * 22, r: 13, fill: FK.alpha(BK.ramp(2).c, .3), stroke: BK.ramp(2).dk }, g)); [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(([i, j]) => E('circle', { cx: cx - 3 + i * 28, cy: cy - 6 + j * 22, r: 8, fill: FK.alpha(BK.ramp(2).c, .55), stroke: BK.ramp(2).dk }, g)); T(g, cx, cy + 56, 'সর্পিল (কোণে ঘোরানো)', { fs: 9, a: 'middle', c: C.mu }); }
    else { [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(([i, j]) => E('circle', { cx: cx - 14 + i * 28, cy: cy - 4 + j * 26, r: 13, fill: FK.alpha(BK.ramp(5).c, .3), stroke: BK.ramp(5).dk }, g)); [[0, 0], [1, 0]].forEach(([i]) => E('circle', { cx: cx - 14 + i * 28, cy: cy - 30, r: 12, fill: FK.alpha(BK.ramp(5).c, .5), stroke: BK.ramp(5).dk }, g)); T(g, cx, cy + 56, 'অরীয় (ঠিক ওপরে-নিচে)', { fs: 9, a: 'middle', c: C.mu }); }
    T(g, 276, 178, 'সিলোম: ' + (pr ? 'সাইজোসিলোম' : 'এন্টেরোসিলোম'), { fs: 9.6, a: 'middle', w: 700, c: C.fg }); T(g, 276, 196, pr ? 'অ্যানেলিডা, মলাস্কা, আর্থ্রোপোডা' : 'একাইনোডারমাটা, কর্ডাটা', { fs: 9, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) { const k = (((t || 0) * .25) % 1), y1 = 208 - 170 * Math.min(1, k / .8); E('path', { d: `M110 208V${y1}`, stroke: layer('en').c, 'stroke-width': 12, 'stroke-linecap': 'round', opacity: .8 }, g); if (k > .8) E('circle', { cx: 110, cy: 30, r: 7, fill: C.sf, stroke: C.fg, 'stroke-width': 1.4 }, g); }
}));

/* ═════════ ৯. শ্রেণিবিন্যাসের স্তরক্রম ═════════ */
const HIER = {
  man: ['মানুষ', ['Animalia', 'Chordata', 'Mammalia', 'Primates', 'Hominidae', 'Homo', 'Homo sapiens']],
  tig: ['বাঘ', ['Animalia', 'Chordata', 'Mammalia', 'Carnivora', 'Felidae', 'Panthera', 'Panthera tigris']],
  roh: ['রুই', ['Animalia', 'Chordata', 'Actinopterygii', 'Cypriniformes', 'Cyprinidae', 'Labeo', 'Labeo rohita']],
  roa: ['তেলাপোকা', ['Animalia', 'Arthropoda', 'Insecta', 'Blattodea', 'Blattidae', 'Periplaneta', 'Periplaneta americana']]
};
const RANK = [['জগৎ', 'Kingdom', 'সবচেয়ে বড় একক — সব প্রাণী একটি জগতে।'], ['পর্ব', 'Phylum', 'দেহগঠনের মৌলিক নকশায় মিল থাকা শ্রেণিগুলোর সমষ্টি।'], ['শ্রেণি', 'Class', 'কাছাকাছি বর্গগুলোর সমষ্টি।'], ['বর্গ', 'Order', 'কাছাকাছি গোত্রগুলোর সমষ্টি।'], ['গোত্র', 'Family', 'কাছাকাছি গণগুলোর সমষ্টি; প্রাণীতে নামের শেষে -idae।'], ['গণ', 'Genus', 'নিকট সম্পর্কিত প্রজাতিগুলোর সমষ্টি; নাম বড় হাতের অক্ষরে শুরু।'], ['প্রজাতি', 'Species', 'মৌলিক একক — নিজেদের মধ্যে প্রজননে জননক্ষম সন্তান দেয়।']];
V.zooHierarchy = Object.assign({}, B.seg({
  id: 'zhr', t: 'শ্রেণিবিন্যাসের স্তরক্রম (ট্যাক্সোনমিক হায়ারার্কি)', H: 262, def: 'man', sel: null,
  cap: 'লিনিয়াসের স্তরক্রমে সাতটি প্রধান স্তর — জগৎ, পর্ব, শ্রেণি, বর্গ, গোত্র, গণ, প্রজাতি। ওপরে গেলে সদস্য বেশি কিন্তু মিল কম; নিচে নামলে সদস্য কম, মিল বেশি। স্তরে চাপ দাও।',
  types: { man: ['মানুষ', 'মানুষের শ্রেণিবিন্যাস', 'Homo sapiens Linnaeus, 1758।'], tig: ['বাঘ', 'বাঘের শ্রেণিবিন্যাস', 'Panthera tigris (Linnaeus, 1758) — বন্ধনী মানে লিনিয়াস একে অন্য গণে (Felis) রেখেছিলেন।'], roh: ['রুই', 'রুই মাছের শ্রেণিবিন্যাস', 'Labeo rohita (Hamilton, 1822) — গঙ্গা অববাহিকার কার্প।'], roa: ['তেলাপোকা', 'তেলাপোকার শ্রেণিবিন্যাস', 'Periplaneta americana (Linnaeus, 1758); পুরোনো বইয়ে বর্গ Dictyoptera বা Orthoptera লেখা থাকে।'] },
  art(g, C, ty, ctx) {
    const rows = HIER[ty][1];
    rows.forEach((nm, i) => { const w = 340 - i * 34, x = (360 - w) / 2, y = 10 + i * 35, R = BK.ramp(i), on = ctx.sel === i;
      E('rect', { x, y, width: w, height: 29, rx: 14.5, fill: on ? FK.alpha(R.c, .55) : FK.alpha(R.c, .16), stroke: R.dk, 'stroke-width': on ? 2 : 1 }, g);
      T(g, x + 14, y + 19, RANK[i][0], { fs: 10.5, w: 700, c: R.ink }); T(g, x + w - 14, y + 19, nm, { fs: 11, a: 'end', w: 650, c: C.fg, st: i >= 5 ? 'font-style:italic' : '' }); });
  },
  anim(g, C, ty, t) { if (!t) return; const i = Math.floor(t * .8) % 7, w = 340 - i * 34, x = (360 - w) / 2, y = 10 + i * 35; E('rect', { x: x - 2, y: y - 2, width: w + 4, height: 33, rx: 16.5, fill: 'none', stroke: BK.ramp(i).dk, 'stroke-width': 2.2, opacity: .7 }, g); },
  tap(x, y, ty, ctx) { const i = Math.floor((y - 10) / 35); if (i < 0 || i > 6) return ''; ctx.sel = i; return `<b>${RANK[i][0]}</b> (${RANK[i][1]}) — ${RANK[i][2]} ${HIER[ty][0]}: <i>${HIER[ty][1][i]}</i>।`; }
}));

/* ═════════ ১০. নামকরণের নিয়ম ═════════ */
const NAMES = {
  bi: [[['Homo', 3, 'গণ — বড় হাতের অক্ষরে শুরু'], ['sapiens', 5, 'প্রজাতিক বিশেষণ — সব ছোট হাতের'], ['Linnaeus, 1758', 9, 'নামদাতা ও প্রকাশের সাল (ঐচ্ছিক, কিন্তু বৈজ্ঞানিক লেখায় প্রচলিত)']], 'দ্বিপদ নামকরণ', 'দুই পদের ল্যাটিন বা ল্যাটিনকৃত নাম; ছাপায় বাঁকা (ইটালিক), হাতে লিখলে দুই পদের নিচে আলাদা দাগ।'],
  tri: [[['Panthera', 3, 'গণ'], ['tigris', 5, 'প্রজাতিক বিশেষণ'], ['tigris', 2, 'উপপ্রজাতিক বিশেষণ — বাংলার বাঘ (বেঙ্গল টাইগার)']], 'ত্রিপদ নামকরণ', 'উপপ্রজাতি বোঝাতে তৃতীয় পদ যোগ হয় — প্রাণীবিদ্যায় উপপ্রজাতি স্বীকৃত একমাত্র প্রজাতি-নিম্ন স্তর।'],
  tau: [[['Naja', 3, 'গণ'], ['naja', 5, 'প্রজাতিক বিশেষণ — গণের নামের পুনরাবৃত্তি']], 'টটোনিম', 'প্রাণীর নামে গণ ও প্রজাতি একই হতে পারে (Naja naja — গোখরা, Rattus rattus — কালো ইঁদুর); উদ্ভিদের নামকরণে (ICN) এটি নিষিদ্ধ।'],
  par: [[['Panthera', 3, 'বর্তমান গণ'], ['tigris', 5, 'প্রজাতিক বিশেষণ'], ['(Linnaeus, 1758)', 9, 'বন্ধনী — মূল নামদাতা প্রজাতিটিকে অন্য গণে (Felis tigris) বর্ণনা করেছিলেন']], 'বন্ধনীর নিয়ম', 'গণ বদলালে মূল নামদাতা ও সাল বন্ধনীতে থাকে — নামের ইতিহাস বোঝা যায়।'],
  fam: [[['Felidae', 4, 'গোত্র — প্রাণীতে শেষে -idae'], ['Pantherinae', 2, 'উপগোত্র — শেষে -inae'], ['Feloidea', 3, 'অধিগোত্র — শেষে -oidea']], 'স্তরের নামের প্রত্যয়', 'গোত্রের নাম গঠিত হয় নমুনা গণের নামের মূল + -idae (Panthera থেকে নয়, Felis থেকে Felidae)।']
};
V.zooNaming = Object.assign({}, B.seg({
  id: 'znm', t: 'প্রাণীর নামকরণের নিয়ম (ICZN)', H: 210, def: 'bi', sel: null,
  cap: 'প্রাণীর বৈজ্ঞানিক নাম ঠিক হয় আন্তর্জাতিক প্রাণী নামকরণ বিধি (ICZN) অনুযায়ী। লিনিয়াসের Systema Naturae এর দশম সংস্করণ (1758) প্রাণীর নামকরণের সূচনা ধরা হয়; একই প্রাণীর একাধিক নাম থাকলে অগ্রাধিকার নীতিতে সবচেয়ে পুরোনো বৈধ নামটি গৃহীত হয়। নামের অংশে চাপ দাও।',
  types: { bi: ['দ্বিপদ', NAMES.bi[1], NAMES.bi[2]], tri: ['ত্রিপদ', NAMES.tri[1], NAMES.tri[2]], tau: ['টটোনিম', NAMES.tau[1], NAMES.tau[2]], par: ['বন্ধনী', NAMES.par[1], NAMES.par[2]], fam: ['প্রত্যয়', NAMES.fam[1], NAMES.fam[2]] },
  art(g, C, ty, ctx) {
    const parts = NAMES[ty][0], n = parts.length, gap = 10, ws = parts.map(p => Math.max(70, p[0].length * 9.2 + 18)), tot = ws.reduce((a, b) => a + b, 0) + gap * (n - 1); let x = (360 - tot) / 2;
    parts.forEach(([s, ri], i) => { const R = BK.ramp(ri), w = ws[i], on = ctx.sel === i; E('rect', { x, y: 60, width: w, height: 44, rx: 12, fill: on ? FK.alpha(R.c, .4) : FK.alpha(R.c, .14), stroke: R.dk, 'stroke-width': on ? 2.2 : 1.1 }, g); T(g, x + w / 2, 88, s, { fs: 15, a: 'middle', w: 650, c: C.fg, st: ty === 'fam' || s.startsWith('(') || /\d/.test(s) ? '' : 'font-style:italic' }); ctx['x' + i] = [x, w]; x += w + gap; });
    T(g, 180, 140, NAMES[ty][1], { fs: 12, a: 'middle', w: 700, c: C.fg }); T(g, 180, 162, 'অংশে চাপ দিলে ব্যাখ্যা', { fs: 9.4, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const i = Math.floor(t * .7) % NAMES[ty][0].length, p = ctx['x' + i]; if (!p) return; const k = (t * .7) % 1; E('path', { d: `M${p[0] + 8} 110H${p[0] + 8 + (p[1] - 16) * k}`, stroke: BK.ramp(NAMES[ty][0][i][1]).dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); },
  tap(x, y, ty, ctx) { if (y < 50 || y > 114) return ''; for (let i = 0; i < NAMES[ty][0].length; i++) { const p = ctx['x' + i]; if (p && x >= p[0] && x <= p[0] + p[1]) { ctx.sel = i; const q = NAMES[ty][0][i]; return `<b>${q[0]}</b> — ${q[2]}`; } } return ''; }
}));

/* ═════════ ১১. পর্বগুলোর সম্পর্ক — দেহগঠনভিত্তিক বংশবৃক্ষ ═════════ */
const PL = [['পরিফেরা', 26, 'প্রকৃত টিস্যু নেই; কোষীয় মাত্রা; অধিকাংশ অপ্রতিসম।'], ['নিডারিয়া', 64, 'অরীয়, দ্বিস্তরী, টিস্যু মাত্রা, সিলেন্টেরন।'], ['প্লাটিহেলমিনথেস', 104, 'দ্বিপার্শ্বীয়, ত্রিস্তরী, অ্যাসিলোমেট।'], ['নেমাটোডা', 144, 'সিউডোসিলোমেট, খণ্ডহীন।'], ['মলাস্কা', 184, 'প্রোটোস্টোম, সাইজোসিলোম, খণ্ডহীন নরম দেহ।'], ['অ্যানেলিডা', 222, 'প্রোটোস্টোম, প্রকৃত খণ্ডায়ন।'], ['আর্থ্রোপোডা', 262, 'প্রোটোস্টোম, খণ্ডিত দেহ, সন্ধিযুক্ত উপাঙ্গ।'], ['একাইনোডারমাটা', 302, 'ডিউটেরোস্টোম, পরিণত পঞ্চ-অরীয়।'], ['কর্ডাটা', 340, 'ডিউটেরোস্টোম, নটোকর্ড।']];
/* [x, y, নাম, ব্যাখ্যা, সন্তান: 'L' + পত্রের সূচক বা 'N' + নোডের সূচক] */
const PN = [[40, 234, 'প্রাণী', 'বহুকোষী, পরভোজী, কোষপ্রাচীরহীন।', ['L0', 'N1']], [76, 210, 'প্রকৃত টিস্যু', 'ইউমেটাজোয়া — প্রকৃত টিস্যু আছে।', ['L1', 'N2']], [114, 186, 'দ্বিপার্শ্বীয়, ত্রিস্তরী', 'বাইলেটেরিয়া — মেসোডার্ম ও দ্বিপার্শ্বীয় প্রতিসাম্য।', ['L2', 'N3']], [154, 162, 'দেহগহ্বর', 'সিউডোসিলোম বা প্রকৃত সিলোম আছে।', ['L3', 'N4']], [240, 138, 'প্রকৃত সিলোম', 'মেসোডার্মে আবৃত গহ্বর।', ['N5', 'N6']], [222, 104, 'প্রোটোস্টোম', 'ব্লাস্টোপোর → মুখ।', ['L4', 'L5', 'L6']], [320, 104, 'ডিউটেরোস্টোম', 'ব্লাস্টোপোর → পায়ু।', ['L7', 'L8']]];
const ptXY = id => id[0] === 'L' ? [PL[+id.slice(1)][1], 52] : [PN[+id.slice(1)][0], PN[+id.slice(1)][1]];
V.phylaTree = Object.assign({}, B.seg({
  id: 'ptr', t: 'প্রধান পর্বগুলোর সম্পর্ক (দেহগঠনভিত্তিক)', H: 252, def: 'tr', sel: null,
  cap: 'দেহগঠনের ভিত্তিগুলো (টিস্যু, প্রতিসাম্য, ভ্রূণস্তর, সিলোম, ব্লাস্টোপোরের পরিণতি) একের পর এক প্রয়োগ করলে পর্বগুলো একটি শাখান্বিত গাছে সাজে। আধুনিক আণবিক গবেষণায় প্লাটিহেলমিনথেস ও নেমাটোডাকেও প্রোটোস্টোম দলে রাখা হয় — তাই এটি পাঠ্যবইয়ের দেহগঠনভিত্তিক সরল রূপ। বিন্দু বা পর্বে চাপ দাও।',
  types: { tr: ['বংশবৃক্ষ', 'দেহগঠনের ধাপে ধাপে বিভাজন', 'প্রতিটি শাখাবিন্দুতে একটি নতুন বৈশিষ্ট্য যোগ হয়েছে।'] },
  art(g, C, ty, ctx) {
    PN.forEach(([x, y, , , ch]) => ch.forEach(c => { const [x1, y1] = ptXY(c); E('path', { d: `M${x} ${y}L${x1} ${y1}`, stroke: C.mu, 'stroke-width': 1.6, fill: 'none' }, g); }));
    PL.forEach(([n, x], i) => { const R = BK.ramp(i); E('circle', { cx: x, cy: 52, r: ctx.sel === 'L' + i ? 8 : 6, fill: R.c, stroke: R.dk }, g); T(g, x, i % 2 ? 40 : 24, n, { fs: 8.4, a: 'middle', w: 700, c: R.ink }); });
    PN.forEach(([x, y, n], i) => { E('circle', { cx: x, cy: y, r: ctx.sel === 'N' + i ? 7 : 4.5, fill: C.sf, stroke: BK.ramp(3).dk, 'stroke-width': 1.6 }, g); T(g, x + 7, y + 13, n, { fs: 8.4, c: BK.ramp(3).ink }); });
    ctx.H = PL.map(([n, x, d], i) => [x, 52, 'L' + i, `<b>${n}</b> — ${d}`]).concat(PN.map(([x, y, n, d], i) => [x, y, 'N' + i, `<b>${n}</b> — ${d}`]));
  },
  anim(g, C, ty, t) {
    const leaf = Math.floor((t || 0) * .35) % 9, k = ((t || 0) * .35) % 1, path = [];
    const find = (id, acc) => { if (id === 'L' + leaf) { path.push(...acc, id); return true; } if (id[0] === 'N') return PN[+id.slice(1)][4].some(c => find(c, [...acc, id])); return false; };
    find('N0', []); const pts = path.map(ptXY), n = pts.length - 1, f = k * n, i = Math.min(n - 1, Math.floor(f)), u = f - i;
    const x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * u, y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * u;
    E('circle', { cx: x, cy: y, r: 5, fill: BK.ramp(leaf).c, opacity: .85 }, g);
  },
  tap(x, y, ty, ctx) { return info(ctx, ctx.H || [], x, y, 22) || ''; }
}));

/* ═════════ ১২. তুলনা ═════════ */
V.cmpRadialBilat = cmp('অরীয় বনাম দ্বিপার্শ্বীয় প্রতিসাম্য', 'কতগুলো তলে দেহ সমান দুই ভাগ হয়।', 'অরীয় প্রতিসাম্য', 'দ্বিপার্শ্বীয় প্রতিসাম্য', [
  ['সমান ভাগের তল', 'কেন্দ্রীয় অক্ষ দিয়ে যাওয়া যেকোনো উল্লম্ব তল', 'কেবল একটি — মধ্য-সাজিটাল তল'],
  ['দেহের তল', 'মুখ ও বিপরীত তল (ওরাল-অ্যাবোরাল)', 'সম্মুখ-পশ্চাৎ, পৃষ্ঠ-অঙ্কীয়, ডান-বাম'],
  ['মস্তক (সেফালাইজেশন)', 'নেই', 'আছে — সম্মুখে স্নায়ু ও সংবেদী অঙ্গ কেন্দ্রীভূত'],
  ['জীবনযাপন', 'স্থির বা ধীরে ভাসমান', 'সক্রিয়ভাবে নির্দিষ্ট দিকে চলাচল'],
  ['উদাহরণ', 'হাইড্রা, জেলিফিশ; পরিণত তারামাছ (পঞ্চ-অরীয়)', 'যকৃৎ কৃমি, কেঁচো, তেলাপোকা, মানুষ']
]);
V.cmpDiploTriplo = cmp('দ্বিস্তরী বনাম ত্রিস্তরী প্রাণী', 'ভ্রূণস্তরের সংখ্যা।', 'দ্বিস্তরী (ডিপ্লোব্লাস্টিক)', 'ত্রিস্তরী (ট্রিপ্লোব্লাস্টিক)', [
  ['ভ্রূণস্তর', 'এক্টোডার্ম ও এন্ডোডার্ম', 'এক্টোডার্ম, মেসোডার্ম ও এন্ডোডার্ম'],
  ['দুই স্তরের মাঝে', 'কোষবিহীন মেসোগ্লিয়া', 'কোষীয় মেসোডার্ম'],
  ['দেহগহ্বর', 'কেবল সিলেন্টেরন (পরিপাক গহ্বর)', 'সিলোম না থাকতে পারে, ছদ্ম বা প্রকৃত সিলোম থাকতে পারে'],
  ['অঙ্গতন্ত্র', 'নেই — টিস্যু মাত্রা', 'আছে — অঙ্গতন্ত্র মাত্রা'],
  ['প্রতিসাম্য', 'সাধারণত অরীয়', 'সাধারণত দ্বিপার্শ্বীয়'],
  ['উদাহরণ', 'নিডারিয়া (হাইড্রা, ওবেলিয়া)', 'প্লাটিহেলমিনথেস থেকে কর্ডাটা']
]);
V.cmpPseudoEu = cmp('ছদ্মসিলোম বনাম প্রকৃত সিলোম', 'গহ্বর কতটা মেসোডার্মে আবৃত।', 'ছদ্মসিলোম (সিউডোসিলোম)', 'প্রকৃত সিলোম (ইউসিলোম)', [
  ['আবরণ', 'কেবল দেহপ্রাচীরের দিকে মেসোডার্ম', 'চারদিকে মেসোডার্ম (পেরিটোনিয়াম)'],
  ['উৎপত্তি', 'ভ্রূণের ব্লাস্টোসিলের অবশেষ', 'মেসোডার্ম চিরে (সাইজো) বা অন্ত্রের থলি থেকে (এন্টেরো)'],
  ['মেসেন্টারি', 'নেই — অঙ্গ ঝুলে থাকে না', 'আছে — অঙ্গ মেসেন্টারিতে ঝোলানো'],
  ['অন্ত্রের পেশি', 'নেই (অন্ত্রপ্রাচীরে মেসোডার্ম নেই)', 'আছে (ভিসেরাল মেসোডার্ম থেকে)'],
  ['উদাহরণ', 'নেমাটোডা (অ্যাসকারিস)', 'অ্যানেলিডা, আর্থ্রোপোডা, মলাস্কা, একাইনোডারমাটা, কর্ডাটা']
]);
V.cmpProtoDeutero = cmp('প্রোটোস্টোম বনাম ডিউটেরোস্টোম', 'ব্লাস্টোপোরের পরিণতি ও ভ্রূণ বিকাশ।', 'প্রোটোস্টোম', 'ডিউটেরোস্টোম', [
  ['ব্লাস্টোপোর থেকে', 'মুখ', 'পায়ু'],
  ['ক্লিভেজ', 'সর্পিল ও নির্ধারিত', 'অরীয় ও অনির্ধারিত'],
  ['সিলোম গঠন', 'সাইজোসিলোম', 'এন্টেরোসিলোম'],
  ['স্নায়ুরজ্জু', 'সাধারণত অঙ্কীয় (ভেন্ট্রাল)', 'কর্ডাটায় পৃষ্ঠীয় (ডরসাল)'],
  ['উদাহরণ', 'মলাস্কা, অ্যানেলিডা, আর্থ্রোপোডা', 'একাইনোডারমাটা, কর্ডাটা']
]);
})();
