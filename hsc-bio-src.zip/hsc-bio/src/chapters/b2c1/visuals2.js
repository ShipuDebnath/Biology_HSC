/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §১.২ ননকর্ডাটা (১): পরিফেরা, নিডারিয়া, প্লাটিহেলমিনথেস, নেমাটোডা
   spongeCanal, hydraBody, obeliaCycle, flatworms, fasciolaCycle, ascarisBody, ascarisCycle,
   cmpPolypMedusa, cmpFlatRound, cmpTaeniaFasciola
   এখানে B21X.ani (সরল প্রাণী-প্রতীক) যোগ হয় — visuals3–4 ব্যবহার করে
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B21, X = window.B21X;
const PI = Math.PI, rnd = B.rnd, hot = B.hot, lab = B.lab, arrow = X.arrow, cmp = X.cmp, layer = X.layer;
const pick = (ctx, H, x, y, r) => { const h = hot(H, x, y, r || 24); if (!h) return ''; ctx.sel = h[2]; return h[3]; };

/* ═══ সরল প্রাণী-প্রতীক (প্রায় 40×40 ঘর, (x, y) = কেন্দ্র) ═══ */
const ani = (g, kind, x, y, s = 1, o = {}) => {
  const R = o.R || BK.ramp(o.ri != null ? o.ri : 9), op = o.op != null ? o.op : 1, f = FK.alpha(R.c, .45), st = R.dk;
  const P = (d, fill = f, w = 1) => E('path', { d, fill, stroke: st, 'stroke-width': w, opacity: op, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, g);
  const O = (cx, cy, rx, ry, fill = f, a = 0) => E('ellipse', { cx, cy, rx, ry, fill, stroke: st, 'stroke-width': 1, opacity: op, transform: a ? `rotate(${a} ${cx} ${cy})` : null }, g);
  const S = v => v * s;
  switch (kind) {
    case 'sponge': P(`M${x - S(12)} ${y + S(16)}C${x - S(18)} ${y} ${x - S(12)} ${y - S(14)} ${x - S(6)} ${y - S(16)}H${x + S(6)}C${x + S(12)} ${y - S(14)} ${x + S(18)} ${y} ${x + S(12)} ${y + S(16)}Z`); O(x, y - S(16), S(6), S(2), '#fff'); for (let i = 0; i < 5; i++) E('circle', { cx: x - S(8) + rnd(i + 2) * S(16), cy: y - S(6) + rnd(i + 9) * S(18), r: S(1.4), fill: '#fff', stroke: st, 'stroke-width': .6, opacity: op }, g); break;
    case 'hydra': P(`M${x - S(4)} ${y + S(16)}Q${x - S(6)} ${y} ${x - S(4)} ${y - S(8)}H${x + S(4)}Q${x + S(6)} ${y} ${x + S(4)} ${y + S(16)}Z`); [-1, -.4, .4, 1].forEach(k => P(`M${x + k * S(3)} ${y - S(8)}q${k * S(6)} ${-S(6)} ${k * S(12)} ${-S(10)}`, 'none', 1.4)); break;
    case 'jelly': P(`M${x - S(14)} ${y}Q${x} ${y - S(22)} ${x + S(14)} ${y}Z`); for (let i = -2; i <= 2; i++) P(`M${x + i * S(5)} ${y}q${S(2)} ${S(8)} 0 ${S(16)}`, 'none', 1); break;
    case 'planaria': P(`M${x - S(18)} ${y}C${x - S(14)} ${y - S(7)} ${x + S(12)} ${y - S(7)} ${x + S(16)} ${y - S(2)}L${x + S(19)} ${y - S(6)}L${x + S(18)} ${y + S(2)}C${x + S(10)} ${y + S(7)} ${x - S(14)} ${y + S(7)} ${x - S(18)} ${y}Z`); E('circle', { cx: x + S(13), cy: y - S(2), r: S(1.2), fill: '#222', opacity: op }, g); E('circle', { cx: x + S(13), cy: y + S(2), r: S(1.2), fill: '#222', opacity: op }, g); break;
    case 'fluke': P(`M${x} ${y - S(18)}C${x + S(8)} ${y - S(14)} ${x + S(10)} ${y} ${x + S(6)} ${y + S(12)}Q${x} ${y + S(18)} ${x - S(6)} ${y + S(12)}C${x - S(10)} ${y} ${x - S(8)} ${y - S(14)} ${x} ${y - S(18)}Z`); E('circle', { cx: x, cy: y - S(14), r: S(1.8), fill: 'none', stroke: st, opacity: op }, g); E('circle', { cx: x, cy: y - S(8), r: S(2.2), fill: 'none', stroke: st, opacity: op }, g); break;
    case 'tapeworm': E('circle', { cx: x - S(18), cy: y - S(10), r: S(2.6), fill: f, stroke: st, opacity: op }, g); P(`M${x - S(16)} ${y - S(9)}C${x - S(4)} ${y - S(4)} ${x - S(10)} ${y + S(8)} ${x + S(4)} ${y + S(8)}S${x + S(18)} ${y - S(2)} ${x + S(20)} ${y + S(14)}`, 'none', S(3.2)); for (let i = 0; i < 6; i++) P(`M${x - S(6) + i * S(5)} ${y + S(4)}v${S(6)}`, 'none', .6); break;
    case 'roundworm': P(`M${x - S(18)} ${y + S(6)}C${x - S(10)} ${y - S(14)} ${x + S(2)} ${y + S(14)} ${x + S(18)} ${y - S(6)}`, 'none', S(3.4)); break;
    case 'snail': E('circle', { cx: x + S(3), cy: y - S(3), r: S(10), fill: f, stroke: st, opacity: op }, g); P(`M${x + S(3)} ${y - S(3)}m${-S(5)} 0a${S(5)} ${S(5)} 0 1 1 ${S(5)} ${S(5)}`, 'none', 1); P(`M${x - S(18)} ${y + S(8)}Q${x - S(10)} ${y + S(4)} ${x - S(6)} ${y + S(6)}H${x + S(14)}Q${x + S(18)} ${y + S(8)} ${x + S(14)} ${y + S(10)}H${x - S(16)}Z`, FK.alpha(R.c, .25)); P(`M${x - S(16)} ${y + S(6)}l${-S(2)} ${-S(7)}M${x - S(13)} ${y + S(6)}l${S(0)} ${-S(7)}`, 'none', 1); break;
    case 'mussel': O(x, y, S(18), S(10), f, -10); P(`M${x - S(16)} ${y + S(3)}Q${x} ${y - S(4)} ${x + S(16)} ${y - S(6)}`, 'none', 1); break;
    case 'octopus': O(x, y - S(8), S(10), S(10)); for (let i = -3; i <= 3; i++) P(`M${x + i * S(2.5)} ${y}q${i * S(3)} ${S(8)} ${i * S(5)} ${S(16)}`, 'none', S(2)); E('circle', { cx: x - S(3), cy: y - S(8), r: S(1.4), fill: '#222', opacity: op }, g); E('circle', { cx: x + S(3), cy: y - S(8), r: S(1.4), fill: '#222', opacity: op }, g); break;
    case 'earthworm': P(`M${x - S(18)} ${y + S(4)}C${x - S(8)} ${y - S(10)} ${x + S(6)} ${y + S(12)} ${x + S(18)} ${y - S(4)}`, 'none', S(5)); for (let i = 0; i < 7; i++) { const t = i / 6, px = x - S(16) + t * S(32), py = y + S(4) * Math.cos(t * 6); P(`M${px} ${py - S(2.5)}v${S(5)}`, 'none', .6); } P(`M${x + S(4)} ${y - S(3)}l${S(4)} ${S(4)}`, 'none', S(6)); break;
    case 'leech': P(`M${x - S(18)} ${y}C${x - S(12)} ${y - S(10)} ${x + S(12)} ${y - S(10)} ${x + S(18)} ${y}C${x + S(12)} ${y + S(8)} ${x - S(12)} ${y + S(8)} ${x - S(18)} ${y}Z`); E('circle', { cx: x + S(16), cy: y, r: S(2.6), fill: 'none', stroke: st, opacity: op }, g); E('circle', { cx: x - S(15), cy: y, r: S(3.4), fill: 'none', stroke: st, opacity: op }, g); break;
    case 'cockroach': O(x, y + S(4), S(8), S(14)); O(x, y - S(13), S(5), S(4)); P(`M${x - S(2)} ${y - S(16)}q${-S(10)} ${-S(8)} ${-S(14)} ${-S(4)}M${x + S(2)} ${y - S(16)}q${S(10)} ${-S(8)} ${S(14)} ${-S(4)}`, 'none', .9); [-1, 1].forEach(k => [-6, 2, 10].forEach(dy => P(`M${x + k * S(7)} ${y + S(dy)}l${k * S(9)} ${S(4)}`, 'none', 1.2))); P(`M${x} ${y - S(9)}V${y + S(18)}`, 'none', .7); break;
    case 'prawn': P(`M${x + S(16)} ${y - S(4)}C${x + S(6)} ${y - S(12)} ${x - S(10)} ${y - S(10)} ${x - S(14)} ${y}C${x - S(16)} ${y + S(8)} ${x - S(10)} ${y + S(12)} ${x - S(4)} ${y + S(10)}L${x - S(8)} ${y + S(4)}C${x - S(6)} ${y - S(2)} ${x + S(6)} ${y - S(2)} ${x + S(16)} ${y + S(2)}Z`); P(`M${x + S(16)} ${y - S(4)}q${S(10)} ${-S(10)} ${S(4)} ${-S(16)}M${x + S(16)} ${y - S(2)}q${S(12)} ${-S(4)} ${S(6)} ${-S(14)}`, 'none', .8); for (let i = 0; i < 4; i++) P(`M${x + S(10) - i * S(5)} ${y + S(1)}l${-S(1)} ${S(7)}`, 'none', .8); break;
    case 'spider': O(x + S(6), y, S(9), S(8)); O(x - S(7), y, S(6), S(5)); [-1, 1].forEach(k => [-4, -1.5, 1.5, 4].forEach((d, i) => P(`M${x - S(6)} ${y + S(d * .4)}q${S(-4 + i * 2.5)} ${k * S(10)} ${S(-10 + i * 5)} ${k * S(14)}`, 'none', 1))); break;
    case 'starfish': { let d = ''; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i / 10 * PI * 2, r = i % 2 ? S(6) : S(18); d += (i ? 'L' : 'M') + (x + r * Math.cos(a)).toFixed(1) + ' ' + (y + r * Math.sin(a)).toFixed(1); } P(d + 'Z'); break; }
    case 'urchin': E('circle', { cx: x, cy: y, r: S(10), fill: f, stroke: st, opacity: op }, g); for (let i = 0; i < 18; i++) { const a = i / 18 * PI * 2; P(`M${x + S(10) * Math.cos(a)} ${y + S(10) * Math.sin(a)}l${S(8) * Math.cos(a)} ${S(8) * Math.sin(a)}`, 'none', .9); } break;
    case 'tunicate': P(`M${x - S(10)} ${y + S(16)}C${x - S(14)} ${y} ${x - S(10)} ${y - S(12)} ${x - S(4)} ${y - S(14)}L${x - S(2)} ${y - S(18)}H${x + S(2)}L${x + S(2)} ${y - S(14)}C${x + S(8)} ${y - S(14)} ${x + S(14)} ${y - S(6)} ${x + S(10)} ${y + S(2)}L${x + S(14)} ${y - S(2)}V${y + S(4)}C${x + S(12)} ${y + S(10)} ${x + S(10)} ${y + S(16)} ${x + S(6)} ${y + S(16)}Z`); break;
    case 'lancelet': P(`M${x - S(18)} ${y}Q${x} ${y - S(7)} ${x + S(18)} ${y}Q${x} ${y + S(5)} ${x - S(18)} ${y}Z`); for (let i = 0; i < 8; i++) P(`M${x - S(10) + i * S(3)} ${y - S(3)}l${S(1.5)} ${S(2)}l${-S(1.5)} ${S(2)}`, 'none', .5); break;
    case 'lamprey': P(`M${x - S(18)} ${y}C${x - S(10)} ${y - S(5)} ${x + S(10)} ${y - S(5)} ${x + S(18)} ${y + S(3)}C${x + S(10)} ${y + S(4)} ${x - S(10)} ${y + S(4)} ${x - S(18)} ${y}Z`); E('circle', { cx: x - S(16), cy: y, r: S(2.6), fill: 'none', stroke: st, opacity: op }, g); for (let i = 0; i < 7; i++) E('circle', { cx: x - S(10) + i * S(2.6), cy: y, r: S(.8), fill: st, opacity: op }, g); break;
    case 'shark': P(`M${x - S(18)} ${y + S(2)}Q${x - S(6)} ${y - S(8)} ${x + S(12)} ${y - S(2)}L${x + S(20)} ${y - S(10)}L${x + S(18)} ${y + S(2)}L${x + S(22)} ${y + S(8)}L${x + S(12)} ${y + S(4)}Q${x} ${y + S(8)} ${x - S(18)} ${y + S(2)}Z`); P(`M${x - S(2)} ${y - S(5)}l${S(4)} ${-S(9)}l${S(3)} ${S(8)}`); for (let i = 0; i < 5; i++) P(`M${x - S(10) + i * S(2)} ${y - S(1)}v${S(4)}`, 'none', .6); break;
    case 'fish': P(`M${x - S(16)} ${y}Q${x - S(4)} ${y - S(10)} ${x + S(10)} ${y}L${x + S(18)} ${y - S(7)}V${y + S(7)}L${x + S(10)} ${y}Q${x - S(4)} ${y + S(10)} ${x - S(16)} ${y}Z`); E('circle', { cx: x - S(10), cy: y - S(1.5), r: S(1.3), fill: '#222', opacity: op }, g); P(`M${x - S(6)} ${y - S(5)}q${S(2)} ${S(5)} 0 ${S(10)}`, 'none', .8); break;
    case 'frog': O(x, y + S(2), S(12), S(9)); E('circle', { cx: x - S(6), cy: y - S(7), r: S(3), fill: '#fff', stroke: st, opacity: op }, g); E('circle', { cx: x + S(6), cy: y - S(7), r: S(3), fill: '#fff', stroke: st, opacity: op }, g); P(`M${x - S(10)} ${y + S(8)}l${-S(8)} ${S(6)}l${S(6)} ${S(2)}M${x + S(10)} ${y + S(8)}l${S(8)} ${S(6)}l${-S(6)} ${S(2)}`, 'none', 1.6); break;
    case 'lizard': P(`M${x - S(18)} ${y + S(6)}Q${x - S(8)} ${y + S(2)} ${x} ${y}Q${x + S(10)} ${y - S(2)} ${x + S(16)} ${y}Q${x + S(10)} ${y + S(3)} ${x} ${y + S(3)}Q${x - S(8)} ${y + S(4)} ${x - S(18)} ${y + S(6)}Z`); P(`M${x - S(2)} ${y + S(2)}l${-S(4)} ${S(6)}M${x + S(6)} ${y + S(1)}l${S(3)} ${S(7)}M${x - S(2)} ${y}l${-S(4)} ${-S(6)}M${x + S(6)} ${y}l${S(3)} ${-S(6)}`, 'none', 1.4); break;
    case 'snake': P(`M${x - S(18)} ${y + S(8)}C${x - S(10)} ${y - S(8)} ${x} ${y + S(12)} ${x + S(8)} ${y - S(2)}S${x + S(16)} ${y - S(12)} ${x + S(16)} ${y - S(12)}`, 'none', S(4)); E('circle', { cx: x + S(16), cy: y - S(12), r: S(3), fill: f, stroke: st, opacity: op }, g); break;
    case 'turtle': O(x, y, S(14), S(10)); E('circle', { cx: x + S(17), cy: y - S(1), r: S(4), fill: f, stroke: st, opacity: op }, g); P(`M${x - S(8)} ${y + S(8)}l${-S(3)} ${S(5)}M${x + S(8)} ${y + S(8)}l${S(3)} ${S(5)}M${x - S(8)} ${y - S(8)}l${-S(3)} ${-S(5)}M${x + S(8)} ${y - S(8)}l${S(3)} ${-S(5)}`, 'none', S(2.4)); break;
    case 'bird': O(x, y + S(2), S(12), S(8)); E('circle', { cx: x + S(12), cy: y - S(6), r: S(5), fill: f, stroke: st, opacity: op }, g); P(`M${x + S(17)} ${y - S(6)}l${S(5)} ${S(1)}l${-S(5)} ${S(2)}`, BK.ramp(2).c); P(`M${x - S(4)} ${y - S(2)}Q${x - S(12)} ${y - S(14)} ${x - S(18)} ${y - S(8)}Q${x - S(10)} ${y - S(2)} ${x - S(4)} ${y + S(2)}`); P(`M${x - S(2)} ${y + S(10)}v${S(6)}M${x + S(4)} ${y + S(10)}v${S(6)}`, 'none', 1.2); break;
    case 'mammal': O(x - S(2), y, S(14), S(8)); E('circle', { cx: x + S(14), cy: y - S(6), r: S(6), fill: f, stroke: st, opacity: op }, g); P(`M${x + S(12)} ${y - S(12)}l${S(1)} ${-S(5)}l${S(3)} ${S(4)}`); P(`M${x - S(10)} ${y + S(6)}v${S(10)}M${x + S(6)} ${y + S(6)}v${S(10)}M${x - S(16)} ${y - S(2)}q${-S(6)} ${-S(4)} ${-S(4)} ${-S(10)}`, 'none', S(2)); break;
  }
};
X.ani = ani;

/* ═════════ ১. স্পঞ্জের নালিতন্ত্র ═════════ */
const SPC = {
  asc: [[180, 26, 0, '<b>অস্কুলাম</b> — পানি বেরোনোর বড় ছিদ্র।'], [96, 130, 1, '<b>অস্টিয়া</b> — দেহপ্রাচীরের অসংখ্য ক্ষুদ্র ছিদ্র; পানি ঢোকে (পরিফেরা = "ছিদ্রবাহী")।'], [180, 130, 2, '<b>স্পঞ্জোসিল</b> — কেন্দ্রীয় গহ্বর; অ্যাসকনে কলার কোষে আবৃত।'], [132, 100, 3, '<b>কলার কোষ (কোয়ানোসাইট)</b> — ফ্ল্যাজেলা নেড়ে স্রোত তৈরি করে ও খাদ্যকণা ধরে।']],
  syc: [[180, 26, 0, '<b>অস্কুলাম</b>'], [84, 130, 1, '<b>অন্তর্বাহী নালি</b> — অস্টিয়া থেকে পানি আনে।'], [122, 120, 2, '<b>অরীয় নালি</b> — কলার কোষে আবৃত; এখানে খাদ্য ধরা হয়।'], [180, 130, 3, '<b>স্পঞ্জোসিল</b> — সাইকনে কলার কোষ নেই, পানি এখানে জমে অস্কুলাম দিয়ে বেরোয়।']],
  leu: [[180, 26, 0, '<b>অস্কুলাম</b>'], [90, 140, 1, '<b>অন্তর্বাহী নালি</b>'], [130, 118, 2, '<b>ফ্ল্যাজেলাযুক্ত প্রকোষ্ঠ</b> — ছোট গোল প্রকোষ্ঠে কলার কোষ।'], [180, 150, 3, '<b>বহির্বাহী নালি</b> — প্রকোষ্ঠ থেকে পানি অস্কুলামে নেয়; স্পঞ্জোসিল প্রায় লুপ্ত।']]
};
V.spongeCanal = Object.assign({}, B.seg({
  id: 'spg', t: 'স্পঞ্জের নালিতন্ত্র', H: 240, def: 'asc', sel: null,
  cap: 'পরিফেরার বিশেষ বৈশিষ্ট্য নালিতন্ত্র — কলার কোষের ফ্ল্যাজেলার আন্দোলনে দেহের ছিদ্র (অস্টিয়া) দিয়ে পানি ঢোকে, নালি দিয়ে ঘুরে অস্কুলাম দিয়ে বেরিয়ে যায়। এ স্রোতেই খাদ্য, অক্সিজেন আসে এবং বর্জ্য ও জননকোষ বেরোয়। জটিলতা অনুযায়ী তিন ধরন — অ্যাসকন, সাইকন ও লিউকন। চালাও চাপলে পানির পথ দেখবে।',
  types: {
    asc: ['অ্যাসকন', 'অ্যাসকন — সবচেয়ে সরল', 'অস্টিয়া → স্পঞ্জোসিল → অস্কুলাম; স্পঞ্জোসিল কলার কোষে আবৃত — Leucosolenia।'],
    syc: ['সাইকন', 'সাইকন — ভাঁজযুক্ত', 'অস্টিয়া → অন্তর্বাহী নালি → প্রসোপাইল → অরীয় নালি → অ্যাপোপাইল → স্পঞ্জোসিল → অস্কুলাম — Scypha (Sycon)।'],
    leu: ['লিউকন', 'লিউকন — সবচেয়ে জটিল', 'অস্টিয়া → অন্তর্বাহী নালি → ফ্ল্যাজেলাযুক্ত প্রকোষ্ঠ → বহির্বাহী নালি → অস্কুলাম — Spongilla (মিঠাপানির), Euspongia (গোসলের স্পঞ্জ)।']
  },
  art(g, C, ty, ctx) {
    const Rb = BK.ramp(6), Rn = layer('en'), wall = 'M120 220C92 180 84 120 100 70C112 40 140 30 160 30H200C220 30 248 40 260 70C276 120 268 180 240 220Z';
    E('path', { d: wall, fill: FK.alpha(Rb.c, .3), stroke: Rb.dk, 'stroke-width': 1.5 }, g);
    if (ty === 'asc') { E('path', { d: 'M138 210C116 176 112 122 124 82C132 60 150 52 166 52H194C210 52 228 60 236 82C248 122 244 176 222 210Z', fill: C.sf, stroke: Rn.dk, 'stroke-dasharray': '2 3', 'stroke-width': 2 }, g); for (let i = 0; i < 6; i++) { const y = 70 + i * 24; E('path', { d: `M100 ${y + 4}H128M260 ${y + 4}H232`, stroke: BK.ramp(5).dk, 'stroke-width': 3, opacity: .35 }, g); } }
    else if (ty === 'syc') { E('path', { d: 'M160 210C150 176 148 122 154 82C158 66 166 60 172 60H188C194 60 202 66 206 82C212 122 210 176 200 210Z', fill: C.sf, stroke: Rb.dk }, g); for (let i = 0; i < 6; i++) { const y = 74 + i * 24; [-1, 1].forEach(k => { E('path', { d: `M${180 + k * 26} ${y}H${180 + k * 64}`, stroke: Rn.c, 'stroke-width': 9, opacity: .6, 'stroke-linecap': 'round' }, g); E('path', { d: `M${180 + k * 70} ${y + 12}H${180 + k * 36}`, stroke: BK.ramp(5).c, 'stroke-width': 5, opacity: .45, 'stroke-linecap': 'round' }, g); }); } }
    else { E('path', { d: 'M174 210C170 170 170 110 174 70H186C190 110 190 170 186 210Z', fill: C.sf, stroke: Rb.dk }, g); for (let i = 0; i < 14; i++) { const k = i % 2 ? 1 : -1, y = 70 + Math.floor(i / 2) * 22, x = 180 + k * (34 + (i % 4 < 2 ? 0 : 16)); E('circle', { cx: x, cy: y, r: 8, fill: FK.alpha(Rn.c, .55), stroke: Rn.dk, 'stroke-width': .8 }, g); E('path', { d: `M${x + k * 8} ${y}H${180 + k * 74}M${x - k * 8} ${y}H${180 + k * 8}`, stroke: BK.ramp(5).dk, 'stroke-width': 1.4, opacity: .5 }, g); } }
    E('ellipse', { cx: 180, cy: 30, rx: 20, ry: 5, fill: C.sf, stroke: C.fg, 'stroke-width': 1.2 }, g);
    (SPC[ty] || []).forEach(([x, y, i]) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r: 13, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2 }, g); });
    T(g, 316, 120, 'পানি ঢোকে', { fs: 9, a: 'middle', c: BK.ramp(5).ink }); T(g, 316, 134, 'অস্টিয়া দিয়ে', { fs: 9, a: 'middle', c: C.mu }); T(g, 252, 18, 'বেরোয় অস্কুলাম দিয়ে', { fs: 9, a: 'middle', c: BK.ramp(5).ink });
  },
  anim(g, C, ty, t) {
    const R = BK.ramp(5);
    for (let i = 0; i < 12; i++) { const k = ((t || 0) * .3 + i / 12) % 1, side = i % 2 ? 1 : -1, row = 80 + (i % 6) * 24;
      let x, y; if (k < .45) { x = 180 + side * (100 - 70 * (k / .45)); y = row; } else { const u = (k - .45) / .55; x = 180 + side * 30 * (1 - u); y = row - (row - 24) * u; }
      E('circle', { cx: x, cy: y, r: 2.4, fill: R.dk, opacity: .85 }, g); }
  },
  tap(x, y, ty, ctx) { return pick(ctx, SPC[ty].map(([a, b, i, s]) => [a, b, i, s]), x, y, 30); }
}));

/* ═════════ ২. হাইড্রা — দেহ ও নিডোসাইট ═════════ */
V.hydraBody = Object.assign({}, B.seg({
  id: 'hyd', t: 'হাইড্রা — দেহগঠন, নিডোসাইট ও দুই রূপ', H: 248, def: 'body', sel: null,
  cap: 'নিডারিয়া পর্বের নামকরণ নিডোসাইট (দংশক কোষ) থেকে — কর্ষিকায় থাকা এ কোষের নেমাটোসিস্ট থলির পেঁচানো সুতা উদ্দীপনায় এক মাইক্রোসেকেন্ডেরও কম সময়ে ছিটকে বেরিয়ে শিকারকে বিদ্ধ ও অবশ করে। হাইড্রা মিঠাপানির একক পলিপ; অনেক নিডারিয়ানের জীবনে পলিপ ও মেডুসা — দুই রূপ থাকে।',
  types: {
    body: ['দেহ', 'হাইড্রার দেহ (লম্বচ্ছেদ)', 'নলাকার দেহ, ওপরে হাইপোস্টোমে মুখ ও চারপাশে 6–10টি কর্ষিকা, নিচে পাদচাকতি; পাশে মুকুল (অযৌন জনন)। দেহপ্রাচীর দ্বিস্তরী, মাঝে মেসোগ্লিয়া।'],
    cnido: ['নিডোসাইট', 'নিডোসাইট ও নেমাটোসিস্ট', 'নিডোসিল (ট্রিগার) স্পর্শ বা রাসায়নিক উদ্দীপনা পেলে ঢাকনা (অপারকুলাম) খুলে যায়; থলির ভেতরের চাপে পেঁচানো সুতা উল্টে বেরিয়ে শিকারে বিঁধে বিষ ঢালে। একবার ছোড়া নেমাটোসিস্ট আর ব্যবহার হয় না — নতুন কোষ তৈরি হয়।'],
    pm: ['পলিপ ও মেডুসা', 'নিডারিয়ার দুই রূপ', 'পলিপ — নলাকার, স্থির, মুখ ওপরে (হাইড্রা, সি-অ্যানিমোন); মেডুসা — ছাতা আকৃতির, ভাসমান, মুখ নিচে (জেলিফিশ)। মেডুসা যেন উল্টানো, চ্যাপ্টা পলিপ।']
  },
  art(g, C, ty, ctx) {
    const Re = layer('ec'), Rn = layer('en');
    if (ty === 'body') {
      [[-1, 0], [-.45, 1], [.45, 2], [1, 3]].forEach(([k]) => E('path', { d: `M${150 + k * 8} 66Q${150 + k * 26} 40 ${150 + k * 46} 26`, fill: 'none', stroke: Re.c, 'stroke-width': 6, 'stroke-linecap': 'round', opacity: .55 }, g));
      E('path', { d: 'M134 72Q120 150 136 224H164Q180 150 166 72Z', fill: FK.alpha(Re.c, .35), stroke: Re.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M142 80Q130 150 142 216H158Q170 150 158 80Z', fill: FK.alpha(Rn.c, .4), stroke: Rn.dk }, g);
      E('path', { d: 'M146 86Q138 150 146 210H154Q162 150 154 86Z', fill: C.sf }, g);
      E('path', { d: 'M162 150Q190 140 204 120', fill: 'none', stroke: Re.dk, 'stroke-width': 9, opacity: .4, 'stroke-linecap': 'round' }, g); E('circle', { cx: 206, cy: 116, r: 6, fill: FK.alpha(Re.c, .5), stroke: Re.dk }, g);
      E('ellipse', { cx: 150, cy: 226, rx: 18, ry: 5, fill: FK.alpha(BK.ramp(11).c, .5), stroke: BK.ramp(11).dk }, g);
      E('path', { d: 'M144 68Q150 60 156 68', fill: FK.alpha(Re.c, .5), stroke: Re.dk }, g);
      lab(g, 150, 64, 230, 50, 'হাইপোস্টোম ও মুখ', C, { fs: 9.6 }); lab(g, 182, 34, 250, 30, 'কর্ষিকা', C, { fs: 9.6 }); lab(g, 204, 120, 252, 120, 'মুকুল', C, { fs: 9.6 }); lab(g, 150, 160, 250, 160, 'সিলেন্টেরন', C, { fs: 9.6 }); lab(g, 138, 190, 70, 190, 'এপিডার্মিস', C, { fs: 9.6 }); lab(g, 156, 200, 250, 200, 'গ্যাস্ট্রোডার্মিস', C, { fs: 9.6 }); lab(g, 150, 228, 70, 230, 'পাদচাকতি', C, { fs: 9.6 });
    } else if (ty === 'cnido') {
      const R = BK.ramp(3);
      E('path', { d: 'M80 200V90Q80 60 120 60H160Q200 60 200 90V200Z', fill: FK.alpha(Re.c, .2), stroke: Re.dk, 'stroke-width': 1.4 }, g);
      E('ellipse', { cx: 140, cy: 132, rx: 34, ry: 52, fill: FK.alpha(R.c, .25), stroke: R.dk, 'stroke-width': 1.5 }, g);
      E('circle', { cx: 120, cy: 182, r: 9, fill: FK.alpha(BK.ramp(9).c, .5), stroke: BK.ramp(9).dk }, g); T(g, 120, 186, 'N', { fs: 9, a: 'middle', w: 700, c: C.fg });
      E('path', { d: 'M128 54L140 30', stroke: C.fg, 'stroke-width': 2 }, g);
      lab(g, 138, 36, 230, 30, 'নিডোসিল (ট্রিগার)', C, { fs: 9.6 }); lab(g, 140, 80, 230, 70, 'অপারকুলাম (ঢাকনা)', C, { fs: 9.6 }); lab(g, 160, 130, 230, 130, 'নেমাটোসিস্ট থলি', C, { fs: 9.6 }); lab(g, 120, 182, 230, 186, 'নিউক্লিয়াস', C, { fs: 9.6 });
    } else {
      const Rp = BK.ramp(0);
      E('path', { d: 'M54 210V110Q54 96 64 96H96Q106 96 106 110V210Z', fill: FK.alpha(Rp.c, .3), stroke: Rp.dk, 'stroke-width': 1.4 }, g);
      [-1, -.4, .4, 1].forEach(k => E('path', { d: `M${80 + k * 18} 98q${k * 8} -20 ${k * 14} -40`, fill: 'none', stroke: Rp.dk, 'stroke-width': 3, 'stroke-linecap': 'round' }, g));
      E('ellipse', { cx: 80, cy: 98, rx: 8, ry: 3, fill: C.sf, stroke: C.fg }, g); T(g, 80, 232, 'পলিপ (মুখ ওপরে)', { fs: 10, a: 'middle', w: 700, c: Rp.ink });
      const Rm = BK.ramp(3);
      E('path', { d: 'M210 120Q270 40 330 120Q300 112 270 112Q240 112 210 120Z', fill: FK.alpha(Rm.c, .3), stroke: Rm.dk, 'stroke-width': 1.4 }, g);
      for (let i = 0; i < 7; i++) E('path', { d: `M${214 + i * 19} 118q4 30 0 60`, fill: 'none', stroke: Rm.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M262 112v30h16v-30', fill: FK.alpha(Rm.c, .4), stroke: Rm.dk }, g); T(g, 270, 232, 'মেডুসা (মুখ নিচে)', { fs: 10, a: 'middle', w: 700, c: Rm.ink });
      arrow(g, 120, 160, 196, 160, C.mu, { w: 1.2 }); T(g, 158, 150, 'উল্টে চ্যাপ্টা', { fs: 9, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'body') { const w = Math.sin(t * 2) * 5; [-1, -.45, .45, 1].forEach(k => E('path', { d: `M${150 + k * 8} 66Q${150 + k * 26 + w} 40 ${150 + k * 46 + w * 1.6} 26`, fill: 'none', stroke: layer('ec').dk, 'stroke-width': 2.6, 'stroke-linecap': 'round' }, g)); }
    else if (ty === 'cnido') {
      const k = (t * .35) % 1, R = BK.ramp(3);
      if (k < .35) { for (let i = 0; i < 6; i++) E('path', { d: `M${116 + i * 9} 110q6 10 0 20q-6 10 0 20`, fill: 'none', stroke: R.dk, 'stroke-width': 1.3 }, g); E('path', { d: 'M126 82H154', stroke: R.dk, 'stroke-width': 3 }, g); }
      else { const u = Math.min(1, (k - .35) / .25); E('path', { d: 'M126 82l-8 -12M154 82l8 -12', stroke: R.dk, 'stroke-width': 3 }, g); E('path', { d: `M140 82V${82 - 70 * u}`, stroke: R.dk, 'stroke-width': 1.8 }, g); for (let i = 1; i < 6; i++) if (u > i / 6) E('path', { d: `M140 ${82 - i * 12}l-5 5M140 ${82 - i * 12}l5 5`, stroke: R.dk, 'stroke-width': 1 }, g); if (u > .95) { E('circle', { cx: 140, cy: 6, r: 5, fill: BK.ramp(4).c }, g); } }
      T(g, 300, 220, k < .35 ? 'অপেক্ষমাণ' : 'নিক্ষিপ্ত', { fs: 10, a: 'middle', w: 700, c: k < .35 ? C.mu : BK.ramp(4).ink });
    } else { const k = Math.sin(t * 2.2) * .5 + .5; E('path', { d: `M210 120Q270 ${40 + 14 * k} 330 120`, fill: 'none', stroke: BK.ramp(3).dk, 'stroke-width': 2.4 }, g); }
  }
}));

/* ═════════ ৩. ওবেলিয়ার জীবনচক্র — মেটাজেনেসিস ═════════ */
V.obeliaCycle = Object.assign({
  t: 'ওবেলিয়ার জীবনচক্র (মেটাজেনেসিস)', k: ['anim', 'int'],
  cap: 'ওবেলিয়া সামুদ্রিক, কলোনিবাসী নিডারিয়ান। এর জীবনচক্রে অযৌন পলিপ দশা ও যৌন মেডুসা দশা পর্যায়ক্রমে আসে — একে মেটাজেনেসিস বলে। উদ্ভিদের জনুক্রমের সাথে পার্থক্য: দুই দশাই ডিপ্লয়েড। দশায় চাপ দাও।'
}, BK.cycle({
  W: 360, H: 340, label: 'ওবেলিয়ার জীবনচক্র', center: 'মেটাজেনেসিস', sub: 'পলিপ ↔ মেডুসা', rx: 108, ry: 118,
  nodes: [
    { t: 'পলিপ কলোনি', en: 'Hydroid colony', d: 'স্থির, শাখান্বিত কলোনি; খাদ্যগ্রাহী পলিপ (হাইড্রান্থ) ও জননপলিপ (ব্লাস্টোস্টাইল) — অযৌন দশা।', io: [['অযৌন', 'in']] },
    { t: 'মেডুসা মুকুল', en: 'Budding', d: 'ব্লাস্টোস্টাইল থেকে মুকুলোদ্গমে ছোট মেডুসা তৈরি হয়ে মুক্ত হয়।' },
    { t: 'মেডুসা', en: 'Medusa', d: 'ছাতা আকৃতির, মুক্ত সাঁতারু; একলিঙ্গ — শুক্রাশয় বা ডিম্বাশয় থাকে — যৌন দশা।', io: [['যৌন', 'in']] },
    { t: 'নিষেক ও জাইগোট', en: 'Zygote', d: 'সমুদ্রের পানিতে শুক্রাণু ও ডিম্বাণুর মিলনে জাইগোট।' },
    { t: 'প্ল্যানুলা লার্ভা', en: 'Planula', d: 'সিলিয়াযুক্ত, মুক্ত সাঁতারু লার্ভা; কিছুদিন পর কোনো শক্ত বস্তুতে আটকে যায়।' },
    { t: 'নতুন পলিপ', en: 'Polyp', d: 'আটকে থাকা প্ল্যানুলা পলিপে পরিণত হয় এবং মুকুলোদ্গমে নতুন কলোনি গড়ে।' }
  ]
}));

/* ═════════ ৪. চ্যাপ্টা কৃমি ═════════ */
const FW = {
  pla: [[176, 120, 0, '<b>গলবিল</b> — অঙ্কীয় তলের মাঝে; বাইরে বেরিয়ে খাদ্য টেনে নেয়।'], [112, 104, 1, '<b>চক্ষুবিন্দু</b> — আলো টের পায়।'], [200, 92, 2, '<b>শাখান্বিত অন্ত্র</b> — তিন শাখা; পায়ু নেই।'], [256, 140, 3, '<b>শিখা কোষ</b> — রেচন।']],
  fas: [[96, 120, 0, '<b>মৌখিক চোষক</b> — মুখ ঘিরে; আটকে থাকা ও খাদ্য শোষণ।'], [130, 120, 1, '<b>অঙ্কীয় চোষক</b> — দৃঢ়ভাবে আটকে থাকার জন্য।'], [200, 106, 2, '<b>শাখান্বিত অন্ত্র</b>'], [220, 138, 3, '<b>শুক্রাশয় ও ডিম্বাশয়</b> — একই দেহে (উভলিঙ্গ)।']],
  tae: [[30, 120, 0, '<b>স্কোলেক্স</b> — চারটি চোষক ও আঁকড়াযুক্ত রোস্টেলাম দিয়ে অন্ত্রপ্রাচীরে আটকে থাকে।'], [60, 120, 1, '<b>ঘাড়</b> — এখান থেকে নতুন প্রোগ্লটিড তৈরি হয়।'], [200, 120, 2, '<b>পরিণত প্রোগ্লটিড</b> — প্রতিটিতে পুরুষ ও স্ত্রী জননাঙ্গ।'], [320, 120, 3, '<b>গ্র্যাভিড প্রোগ্লটিড</b> — ডিমে ভরা জরায়ু; মলের সাথে বেরিয়ে যায়।']]
};
V.flatworms = Object.assign({}, B.seg({
  id: 'flw', t: 'প্লাটিহেলমিনথেস — চ্যাপ্টা কৃমি', H: 230, def: 'pla', sel: null,
  cap: 'প্লাটিহেলমিনথেস (গ্রিক platys = চ্যাপ্টা, helminthes = কৃমি) — পৃষ্ঠ-অঙ্কীয়ভাবে চ্যাপ্টা, দ্বিপার্শ্বীয়, ত্রিস্তরী, অ্যাসিলোমেট কৃমি; রেচন শিখা কোষে; অধিকাংশ উভলিঙ্গ। অনেকে পরজীবী — তাদের দেহে চোষক ও আঁকড়া, পুরু টেগুমেন্ট, প্রচুর ডিম উৎপাদন ও এক বা একাধিক পোষক। অংশে চাপ দাও।',
  types: {
    pla: ['প্লানেরিয়া', 'প্লানেরিয়া (Dugesia) — মুক্তজীবী', 'মিঠাপানির মুক্তজীবী চ্যাপ্টা কৃমি; পুনরুৎপত্তি ক্ষমতা অসাধারণ — একটি ছোট টুকরো থেকেও পূর্ণ কৃমি হয়।'],
    fas: ['যকৃৎ কৃমি', 'যকৃৎ কৃমি (Fasciola hepatica)', 'ভেড়া, গরু, ছাগলের যকৃতের পিত্তনালিতে পরজীবী; মাধ্যমিক পোষক শামুক (Lymnaea)। পাতার মতো দেহ, দুটি চোষক।'],
    tae: ['ফিতাকৃমি', 'ফিতাকৃমি (Taenia solium)', 'মানুষের ক্ষুদ্রান্ত্রে পরজীবী, লম্বায় প্রায় 2–3 মিটার; মাধ্যমিক পোষক শূকর। পৌষ্টিকনালি নেই — দেহতল দিয়ে সরাসরি পরিপাকিত খাদ্য শোষণ করে।']
  },
  art(g, C, ty, ctx) {
    const R = BK.ramp(ty === 'pla' ? 11 : ty === 'fas' ? 4 : 7), Rn = layer('en');
    if (ty === 'pla') {
      E('path', { d: 'M96 120C100 96 130 92 150 94C200 98 260 104 300 116Q312 120 300 124C260 136 200 142 150 146C130 148 100 144 96 120Z', fill: FK.alpha(R.c, .3), stroke: R.dk, 'stroke-width': 1.4 }, g);
      E('path', { d: 'M96 120L86 108M96 120L86 132', stroke: R.dk, 'stroke-width': 1.4 }, g);
      E('circle', { cx: 112, cy: 110, r: 3, fill: C.fg }, g); E('circle', { cx: 112, cy: 130, r: 3, fill: C.fg }, g);
      E('path', { d: 'M130 120H170M170 120Q220 104 290 116M170 120Q220 136 290 124M150 120Q150 108 140 102', stroke: Rn.dk, 'stroke-width': 4, fill: 'none', opacity: .6, 'stroke-linecap': 'round' }, g);
      E('ellipse', { cx: 176, cy: 120, rx: 14, ry: 5, fill: FK.alpha(BK.ramp(4).c, .5), stroke: BK.ramp(4).dk }, g);
      for (let i = 0; i < 4; i++) E('path', { d: `M${200 + i * 22} 100l3 -4M${200 + i * 22} 140l3 4`, stroke: layer('ec').dk, 'stroke-width': 1.6 }, g);
    } else if (ty === 'fas') {
      E('path', { d: 'M80 120Q92 102 120 98C170 92 250 96 290 112Q300 120 290 128C250 144 170 148 120 142Q92 138 80 120Z', fill: FK.alpha(R.c, .28), stroke: R.dk, 'stroke-width': 1.4 }, g);
      E('circle', { cx: 96, cy: 120, r: 7, fill: 'none', stroke: R.dk, 'stroke-width': 2.4 }, g); E('circle', { cx: 130, cy: 120, r: 8, fill: 'none', stroke: R.dk, 'stroke-width': 2.4 }, g);
      E('path', { d: 'M104 120H150M150 112Q210 96 280 112M150 128Q210 144 280 128', stroke: Rn.dk, 'stroke-width': 3, fill: 'none', opacity: .55 }, g);
      for (let i = 0; i < 8; i++) { E('path', { d: `M${160 + i * 15} 108v-8M${160 + i * 15} 132v8`, stroke: Rn.dk, 'stroke-width': 2, opacity: .5 }, g); }
      for (let i = 0; i < 10; i++) B.blob(g, 186 + (i % 5) * 18, 114 + Math.floor(i / 5) * 12, 4, { n: 6, seed: i + 1, j: .6, fill: FK.alpha(BK.ramp(3).c, .5), stroke: BK.ramp(3).dk, sw: .7 });
    } else {
      E('circle', { cx: 30, cy: 120, r: 11, fill: FK.alpha(R.c, .45), stroke: R.dk, 'stroke-width': 1.2 }, g); [[-5, -5], [5, -5], [-5, 5], [5, 5]].forEach(([dx, dy]) => E('circle', { cx: 30 + dx, cy: 120 + dy, r: 3, fill: 'none', stroke: R.dk }, g)); for (let i = 0; i < 8; i++) { const a = i / 8 * PI * 2; E('path', { d: `M${30 + 11 * Math.cos(a)} ${120 + 11 * Math.sin(a)}l${3 * Math.cos(a)} ${3 * Math.sin(a)}`, stroke: C.fg, 'stroke-width': 1.2 }, g); }
      E('path', { d: 'M41 120H62', stroke: R.dk, 'stroke-width': 4 }, g);
      let x = 62; for (let i = 0; i < 16; i++) { const w = 5 + i * 1.2, h = 8 + i * 2.6; E('rect', { x, y: 120 - h / 2, width: w, height: h, rx: 1.5, fill: FK.alpha(R.c, .15 + i / 28), stroke: R.dk, 'stroke-width': .7 }, g); if (i > 11) E('path', { d: `M${x + w / 2} ${120 - h / 2 + 3}V${120 + h / 2 - 3}`, stroke: BK.ramp(4).dk, 'stroke-width': 2, opacity: .6 }, g); x += w + 1.2; }
      T(g, 30, 152, 'স্কোলেক্স', { fs: 9, a: 'middle', c: C.mu }); T(g, 120, 166, 'অপরিণত', { fs: 9, a: 'middle', c: C.mu }); T(g, 210, 172, 'পরিণত', { fs: 9, a: 'middle', c: C.mu }); T(g, 300, 176, 'গ্র্যাভিড', { fs: 9, a: 'middle', c: C.mu });
    }
    (FW[ty] || []).forEach(([x, y, i]) => { if (ctx.sel === i) E('circle', { cx: x, cy: y, r: 12, fill: 'none', stroke: BK.ramp(4).dk, 'stroke-width': 2.2 }, g); });
    T(g, 180, 214, ty === 'pla' ? 'মুক্তজীবী · মিঠাপানি' : ty === 'fas' ? 'পরজীবী · দুই পোষক: ভেড়া (মুখ্য), শামুক (মাধ্যমিক)' : 'পরজীবী · দুই পোষক: মানুষ (মুখ্য), শূকর (মাধ্যমিক)', { fs: 9.6, a: 'middle', w: 650, c: C.fg });
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'pla') { for (let i = 0; i < 4; i++) { const k = .5 + .5 * Math.sin(t * 10 + i); E('path', { d: `M${200 + i * 22} 100l${2 + 2 * k} ${-6 * k}`, stroke: BK.ramp(2).c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g); } }
    else if (ty === 'fas') { const k = .5 + .5 * Math.sin(t * 3); E('circle', { cx: 96, cy: 120, r: 4 + 3 * k, fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 1.6 }, g); E('circle', { cx: 130, cy: 120, r: 5 + 3 * (1 - k), fill: 'none', stroke: BK.ramp(4).c, 'stroke-width': 1.6 }, g); }
    else { const k = (t * .25) % 1; E('rect', { x: 330 + k * 14, y: 98 + k * 40, width: 22, height: 44, rx: 2, fill: FK.alpha(BK.ramp(7).c, .6 * (1 - k)), stroke: BK.ramp(7).dk, opacity: 1 - k }, g); }
  },
  tap(x, y, ty, ctx) { return pick(ctx, FW[ty], x, y, 28); }
}));

/* ═════════ ৫. যকৃৎ কৃমির জীবনচক্র ═════════ */
V.fasciolaCycle = Object.assign({
  t: 'যকৃৎ কৃমির (Fasciola hepatica) জীবনচক্র', k: ['anim', 'int'],
  cap: 'যকৃৎ কৃমির জীবনচক্রে দুটি পোষক — মুখ্য পোষক ভেড়া (বা গরু-ছাগল) ও মাধ্যমিক পোষক শামুক (Lymnaea)। শামুকের দেহে একটি মিরাসিডিয়াম থেকে বহু রেডিয়া ও সারকেরিয়া হয় (বহুগুণন) — তাই এক ডিম থেকে শত শত সংক্রামক লার্ভা। দশায় চাপ দাও।'
}, BK.cycle({
  W: 360, H: 350, label: 'যকৃৎ কৃমির জীবনচক্র', center: 'Fasciola', sub: 'ভেড়া ↔ শামুক', rx: 110, ry: 122,
  nodes: [
    { t: 'পূর্ণাঙ্গ কৃমি', en: 'Adult fluke', d: 'ভেড়ার যকৃতের পিত্তনালিতে; উভলিঙ্গ, প্রচুর ডিম পাড়ে — পিত্তরসের সাথে অন্ত্রে, তারপর মলের সাথে বাইরে।', io: [['ভেড়া', 'in']] },
    { t: 'ডিম ও মিরাসিডিয়াম', en: 'Miracidium', d: 'পানিতে ডিম ফুটে সিলিয়াযুক্ত মিরাসিডিয়াম বের হয়; কয়েক ঘণ্টার মধ্যে উপযুক্ত শামুক খুঁজে তার দেহে ঢোকে।' },
    { t: 'স্পোরোসিস্ট', en: 'Sporocyst', d: 'শামুকের দেহে মিরাসিডিয়াম সিলিয়া হারিয়ে থলির মতো স্পোরোসিস্ট হয়।', io: [['শামুক', 'in']] },
    { t: 'রেডিয়া', en: 'Redia', d: 'স্পোরোসিস্টের ভেতরে অনেকগুলো রেডিয়া; রেডিয়া আবার নতুন রেডিয়া বা সারকেরিয়া তৈরি করে — বহুগুণন।' },
    { t: 'সারকেরিয়া', en: 'Cercaria', d: 'লেজযুক্ত সারকেরিয়া শামুক ছেড়ে পানিতে সাঁতরায়।' },
    { t: 'মেটাসারকেরিয়া', en: 'Metacercaria', d: 'ঘাস বা জলজ উদ্ভিদে লেজ ফেলে শক্ত আবরণে (সিস্ট) ঢাকা পড়ে — এটিই সংক্রামক দশা।' },
    { t: 'ভেড়ার সংক্রমণ', en: 'Infection', d: 'ঘাসের সাথে মেটাসারকেরিয়া খেলে অন্ত্রে সিস্ট ফেটে কৃমি বেরিয়ে অন্ত্রপ্রাচীর ও দেহগহ্বর হয়ে যকৃতে পৌঁছায় — যকৃৎ পচা (ফ্যাসিওলিয়াসিস) রোগ।' }
  ]
}));

/* ═════════ ৬. অ্যাসকারিস ═════════ */
V.ascarisBody = Object.assign({}, B.seg({
  id: 'asc', t: 'অ্যাসকারিস (Ascaris lumbricoides) — গোলকৃমি', H: 236, def: 'mf', sel: null,
  cap: 'নেমাটোডা — নলাকার, খণ্ডহীন, দুই প্রান্ত সরু কৃমি; দেহ পুরু কিউটিকলে ঢাকা; সিউডোসিলোমেট; পৌষ্টিকনালি সম্পূর্ণ (মুখ ও পায়ু দুটোই আছে); একলিঙ্গ। মানুষের ক্ষুদ্রান্ত্রের অ্যাসকারিস সবচেয়ে পরিচিত — কোনো মাধ্যমিক পোষক নেই।',
  types: {
    mf: ['পুরুষ ও স্ত্রী', 'যৌন দ্বিরূপতা', 'স্ত্রী বড় (প্রায় 20–35 cm), পেছনের প্রান্ত সোজা; পুরুষ ছোট (প্রায় 15–30 cm), পেছনের প্রান্ত বাঁকানো ও দুটি পিনিয়াল স্পিকিউল থাকে।'],
    ts: ['প্রস্থচ্ছেদ', 'দেহের প্রস্থচ্ছেদ', 'কিউটিকল → হাইপোডার্মিস → কেবল অনুদৈর্ঘ্য পেশি (বৃত্তাকার পেশি নেই — তাই কৃমি কেবল আঁকাবাঁকা নড়ে) → সিউডোসিলোম → অন্ত্র; পার্শ্বরেখায় রেচননালি। অংশে চাপ দাও।']
  },
  art(g, C, ty, ctx) {
    const R = BK.ramp(11);
    if (ty === 'mf') {
      E('path', { d: 'M30 80Q60 70 160 72T330 80Q340 84 330 88Q240 96 160 92T30 86Z', fill: FK.alpha(BK.ramp(6).c, .45), stroke: BK.ramp(6).dk, 'stroke-width': 1.3 }, g); T(g, 180, 60, 'স্ত্রী — বড়, পেছন সোজা', { fs: 10, a: 'middle', w: 700, c: BK.ramp(6).ink });
      E('path', { d: 'M40 160Q70 152 150 154T260 160Q286 166 290 182Q284 186 280 176Q270 170 250 168Q180 170 140 168T40 166Z', fill: FK.alpha(BK.ramp(5).c, .4), stroke: BK.ramp(5).dk, 'stroke-width': 1.3 }, g); E('path', { d: 'M288 182l6 6M286 184l2 8', stroke: C.fg, 'stroke-width': 1.2 }, g); T(g, 170, 140, 'পুরুষ — ছোট, পেছন বাঁকানো, স্পিকিউল', { fs: 10, a: 'middle', w: 700, c: BK.ramp(5).ink });
      T(g, 30, 102, 'মুখ (তিনটি ঠোঁট)', { fs: 9, c: C.mu }); T(g, 180, 214, 'সংক্রমণ: দূষিত খাবার-পানির সাথে সংক্রামক ডিম গিলে', { fs: 9.6, a: 'middle', c: C.fg });
    } else {
      const cx = 140, cy = 120, Rm = layer('me'), s = ctx.sel;
      E('circle', { cx, cy, r: 92, fill: FK.alpha(R.c, .5), stroke: s === 0 ? BK.ramp(4).dk : R.dk, 'stroke-width': s === 0 ? 3 : 1.4 }, g);
      E('circle', { cx, cy, r: 84, fill: FK.alpha(layer('ec').c, .35), stroke: layer('ec').dk }, g);
      for (let q = 0; q < 4; q++) { const a0 = q * 90 + 12, a1 = q * 90 + 78, [o0x, o0y] = B.pol(cx, cy, 80, a0), [o1x, o1y] = B.pol(cx, cy, 80, a1), [i1x, i1y] = B.pol(cx, cy, 58, a1), [i0x, i0y] = B.pol(cx, cy, 58, a0);
        E('path', { d: `M${o0x} ${o0y}A80 80 0 0 1 ${o1x} ${o1y}L${i1x} ${i1y}A58 58 0 0 0 ${i0x} ${i0y}Z`, fill: FK.alpha(Rm.c, s === 1 ? .6 : .38), stroke: Rm.dk }, g); }
      E('circle', { cx, cy, r: 56, fill: C.sf, stroke: 'none' }, g);
      E('ellipse', { cx, cy, rx: 26, ry: 14, fill: FK.alpha(layer('en').c, .55), stroke: layer('en').dk }, g);
      [[0, -1], [0, 1], [-1, 0], [1, 0]].forEach(([dx, dy], i) => E('circle', { cx: cx + dx * 82, cy: cy + dy * 82, r: i > 1 ? 7 : 5, fill: i > 1 ? FK.alpha(BK.ramp(5).c, .55) : FK.alpha(BK.ramp(2).c, .6), stroke: i > 1 ? BK.ramp(5).dk : BK.ramp(2).dk }, g));
      [['কিউটিকল', 0], ['অনুদৈর্ঘ্য পেশি', 4], ['সিউডোসিলোম', 10], ['অন্ত্র', 7], ['পার্শ্বরেখা (রেচন)', 5], ['স্নায়ুরজ্জু', 2]].forEach(([n, ri], i) => { E('rect', { x: 248, y: 40 + i * 28, width: 12, height: 12, rx: 3, fill: FK.alpha(BK.ramp(ri === 0 ? 11 : ri).c, .6), stroke: BK.ramp(ri === 0 ? 11 : ri).dk }, g); T(g, 266, 50 + i * 28, n, { fs: 9.6, c: C.fg }); });
    }
  },
  anim(g, C, ty, t) { if (!t || ty !== 'mf') return; const w = Math.sin(t * 2.4) * 5; E('path', { d: `M30 83Q60 ${73 + w} 160 ${75 - w}T330 83`, fill: 'none', stroke: BK.ramp(6).dk, 'stroke-width': 1.2, opacity: .6 }, g); E('path', { d: `M40 163Q70 ${155 - w} 150 ${157 + w}T260 163`, fill: 'none', stroke: BK.ramp(5).dk, 'stroke-width': 1.2, opacity: .6 }, g); },
  tap(x, y, ty, ctx) {
    if (ty !== 'ts') return '';
    const d = Math.hypot(x - 140, y - 120); const T5 = [[92, 0, '<b>কিউটিকল</b> — পুরু, অকোষীয় আবরণ; পোষকের পরিপাক রস থেকে রক্ষা করে।'], [84, 9, '<b>হাইপোডার্মিস</b> — সিনসিশিয়াল (কোষপ্রাচীরহীন বহুনিউক্লিয়াসযুক্ত) স্তর।'], [58, 1, '<b>অনুদৈর্ঘ্য পেশি</b> — চারটি ভাগে; বৃত্তাকার পেশি নেই।'], [27, 2, '<b>সিউডোসিলোম</b> — তরলপূর্ণ ছদ্মসিলোম; জলস্থিতিক কঙ্কালের কাজ করে।'], [0, 3, '<b>অন্ত্র</b> — চ্যাপ্টা নল; অন্ত্রপ্রাচীরে পেশি নেই।']];
    if (d > 96) return ''; const r = T5.find(z => d >= z[0]) || T5[4]; ctx.sel = r[1]; return r[2];
  }
}));

/* ═════════ ৭. অ্যাসকারিসের জীবনচক্র ═════════ */
V.ascarisCycle = Object.assign({
  t: 'অ্যাসকারিসের জীবনচক্র', k: ['anim', 'int'],
  cap: 'অ্যাসকারিসের জীবনচক্রে একটিই পোষক — মানুষ; মাধ্যমিক পোষক নেই। স্ত্রী কৃমি দিনে প্রায় 2 লক্ষ ডিম পাড়তে পারে। লার্ভা অন্ত্র থেকে রক্তে ঢুকে যকৃৎ, হৃৎপিণ্ড ও ফুসফুস ঘুরে আবার অন্ত্রে ফেরে। দশায় চাপ দাও।'
}, BK.cycle({
  W: 360, H: 340, label: 'অ্যাসকারিসের জীবনচক্র', center: 'অ্যাসকারিস', sub: 'একটি পোষক — মানুষ', rx: 106, ry: 118,
  nodes: [
    { t: 'ক্ষুদ্রান্ত্রে পূর্ণাঙ্গ', en: 'Adult', d: 'ক্ষুদ্রান্ত্রে পুরুষ ও স্ত্রী কৃমি মিলিত হয়; স্ত্রী অসংখ্য ডিম পাড়ে, ডিম মলের সাথে বাইরে আসে।' },
    { t: 'মাটিতে ডিম', en: 'Eggs in soil', d: 'আর্দ্র-উষ্ণ মাটিতে প্রায় 2–3 সপ্তাহে ডিমের ভেতর লার্ভা তৈরি হয় — তখনই ডিম সংক্রামক।' },
    { t: 'সংক্রামক ডিম গেলা', en: 'Ingestion', d: 'অপরিষ্কার হাত, কাঁচা শাকসবজি বা দূষিত পানির সাথে ডিম মুখে যায়।' },
    { t: 'লার্ভা রক্তে', en: 'Migration', d: 'ক্ষুদ্রান্ত্রে ডিম ফুটে লার্ভা অন্ত্রপ্রাচীর ভেদ করে রক্তের সাথে যকৃৎ ও হৃৎপিণ্ড হয়ে ফুসফুসে যায়।' },
    { t: 'ফুসফুস থেকে গলায়', en: 'Lungs', d: 'ফুসফুসের বায়ুথলিতে বড় হয়ে শ্বাসনালি বেয়ে গলায় ওঠে (কাশি হতে পারে) এবং আবার গিলে ফেলা হয়।' },
    { t: 'আবার ক্ষুদ্রান্ত্রে', en: 'Maturation', d: 'ক্ষুদ্রান্ত্রে ফিরে প্রায় 2–3 মাসে পূর্ণাঙ্গ হয়। প্রতিরোধ: হাত ধোয়া, স্যানিটারি পায়খানা, শাকসবজি ভালো করে ধোয়া।' }
  ]
}));

/* ═════════ ৮. তুলনা ═════════ */
V.cmpPolypMedusa = cmp('পলিপ বনাম মেডুসা', 'নিডারিয়ার দুই দেহরূপ।', 'পলিপ', 'মেডুসা', [
  ['আকৃতি', 'নলাকার বা বেলনাকার', 'ছাতা বা ঘণ্টা আকৃতির'],
  ['চলন', 'সাধারণত স্থির (আটকে থাকে)', 'মুক্তভাবে সাঁতার কাটে'],
  ['মুখের অবস্থান', 'ওপরের দিকে', 'নিচের দিকে'],
  ['মেসোগ্লিয়া', 'পাতলা', 'পুরু, জেলির মতো'],
  ['জনন', 'সাধারণত অযৌন (মুকুলোদ্গম)', 'যৌন (জননকোষ তৈরি)'],
  ['উদাহরণ', 'হাইড্রা, ওবেলিয়ার পলিপ, সি-অ্যানিমোন', 'জেলিফিশ (Aurelia), ওবেলিয়ার মেডুসা']
]);
V.cmpFlatRound = cmp('প্লাটিহেলমিনথেস বনাম নেমাটোডা', 'চ্যাপ্টা কৃমি ও গোলকৃমি।', 'প্লাটিহেলমিনথেস', 'নেমাটোডা', [
  ['দেহের আকৃতি', 'পৃষ্ঠ-অঙ্কীয়ভাবে চ্যাপ্টা', 'নলাকার, দুই প্রান্ত সরু'],
  ['দেহগহ্বর', 'নেই (অ্যাসিলোমেট)', 'ছদ্মসিলোম (সিউডোসিলোমেট)'],
  ['পৌষ্টিকনালি', 'অসম্পূর্ণ (পায়ু নেই) বা অনুপস্থিত', 'সম্পূর্ণ — মুখ ও পায়ু দুটোই'],
  ['রেচন', 'শিখা কোষ (প্রোটোনেফ্রিডিয়া)', 'রেনেট কোষ বা রেচননালি'],
  ['লিঙ্গ', 'অধিকাংশ উভলিঙ্গ', 'একলিঙ্গ, যৌন দ্বিরূপতা'],
  ['আবরণ', 'টেগুমেন্ট (পরজীবীতে) বা সিলিয়াযুক্ত এপিডার্মিস', 'পুরু কিউটিকল, সিলিয়া নেই'],
  ['উদাহরণ', 'প্লানেরিয়া, যকৃৎ কৃমি, ফিতাকৃমি', 'অ্যাসকারিস, কৃমি (Enterobius), হুকওয়ার্ম, ফাইলেরিয়া কৃমি']
]);
V.cmpTaeniaFasciola = cmp('ফিতাকৃমি বনাম যকৃৎ কৃমি', 'দুই পরজীবী চ্যাপ্টা কৃমি।', 'ফিতাকৃমি (Taenia solium)', 'যকৃৎ কৃমি (Fasciola hepatica)', [
  ['মুখ্য পোষক ও অবস্থান', 'মানুষ — ক্ষুদ্রান্ত্র', 'ভেড়া, গরু — যকৃতের পিত্তনালি'],
  ['মাধ্যমিক পোষক', 'শূকর', 'শামুক (Lymnaea)'],
  ['দেহ', 'ফিতার মতো লম্বা, প্রোগ্লটিডে বিভক্ত', 'পাতার মতো, অবিভক্ত'],
  ['আটকানোর অঙ্গ', 'স্কোলেক্সে চারটি চোষক ও আঁকড়া', 'মৌখিক ও অঙ্কীয় চোষক'],
  ['পৌষ্টিকনালি', 'নেই — দেহতল দিয়ে শোষণ', 'আছে — শাখান্বিত অন্ত্র'],
  ['সংক্রামক দশা', 'শূকরের মাংসে সিস্টিসারকাস', 'ঘাসে মেটাসারকেরিয়া']
]);
})();
