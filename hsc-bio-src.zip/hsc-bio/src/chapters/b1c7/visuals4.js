/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §৭.৪ Poaceae ও Malvaceae, এবং অধ্যায় মানচিত্র
   ricePlant    : ধান গাছ — চিহ্নিত চিত্র (শিষ দোলে)
   spikelet     : ধানের স্পাইকলেট ও পুষ্পিকা — চিহ্নিত চিত্র (বাতাসে পরাগ ওড়ে)
   hibiscus     : জবা ফুল — চিহ্নিত চিত্র (পুংকেশরীয় নল ও গর্ভমুণ্ড)
   malvaDetail  : Malvaceae এর শনাক্তকারী খুঁটিনাটি — তারকা রোম, বৃক্কাকার পরাগধানী, গর্ভাশয়ের প্রস্থচ্ছেদ, ক্যাপসুল
   floralDiagram: পুষ্প প্রতীক — জবা ও ধান (স্তবক একে একে আঁকা হয়)
   monoDi       : একবীজপত্রী বনাম দ্বিবীজপত্রী — পাঁচ বৈশিষ্ট্যের চিত্র-তুলনা
   cmpPoaMal, cmpMonoDi : তুলনা ও কুইজ
   poaEcon, malEcon     : অর্থনৈতিক গুরুত্ব — মাইন্ড ম্যাপ
   malvaPractical : ব্যবহারিক — Malvaceae গোত্র শনাক্তকরণের ধাপ
   b1c7map      : অধ্যায় মানচিত্র
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B7 = window.B7;

/* ───────── ধান গাছ ───────── */
const RX = 150;
V.ricePlant = Object.assign({
  t: 'ধান গাছ (Oryza sativa) — Poaceae গোত্রের বৈশিষ্ট্য', k: ['2d', 'label', 'int', 'anim'],
  cap: 'গুচ্ছমূল; স্পষ্ট পর্ব ও ফাঁপা পর্বমধ্যের কালম কাণ্ড; একান্তর দ্বিসারি পাতা — পত্রখোল কাণ্ডকে ঘিরে থাকে, খোল ও ফলকের সংযোগে লিগিউল ও অরিকল; সমান্তরাল শিরাবিন্যাস; মাথায় স্পাইকলেটের প্যানিকল পুষ্পবিন্যাস। গোড়া থেকে কুশি (টিলার) বের হয়। চালু করলে বাতাসে শিষ দোলে।'
}, BK.diagram({
  W: 360, H: 340, label: 'ধান গাছ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rr = BK.ramp(6), soil = '#8a6b3a';
    E('rect', { x: 8, y: 286, width: 344, height: 48, rx: 8, fill: FK.alpha(soil, .2) }, g); E('rect', { x: 8, y: 276, width: 344, height: 12, fill: FK.alpha(BK.ramp(5).c, .2) }, g);
    const rt = P('root'); for (let i = 0; i < 14; i++) { const a = Math.PI / 2 + (i - 6.5) * .14; E('path', { d: `M${RX} 288Q${(RX + 14 * Math.cos(a)).toFixed(1)} 300 ${(RX + 46 * Math.cos(a)).toFixed(1)} ${(288 + 42 * Math.sin(a)).toFixed(1)}`, stroke: '#b8a070', 'stroke-width': 1.2, fill: 'none' }, rt); }
    const tl = P('tiller'); [-1, 1].forEach(s => E('path', { d: `M${RX + s * 4} 288Q${RX + s * 14} 220 ${RX + s * 30} 150`, stroke: FK.alpha(R.dk, .6), 'stroke-width': 3, fill: 'none' }, tl));
    const cu = P('culm'); E('path', { d: `M${RX} 288V96`, stroke: R.c, 'stroke-width': 6 }, cu);
    const nd = P('node'); [252, 204, 150].forEach(y => E('rect', { x: RX - 5, y: y - 2.5, width: 10, height: 5, rx: 2, fill: R.dk }, nd));
    const sh = P('sheath'); [[252, 204], [204, 150]].forEach(([y0, y1]) => E('path', { d: `M${RX - 6} ${y0}L${RX - 5} ${y1 + 8}Q${RX} ${y1 + 2} ${RX + 6} ${y1 + 8}L${RX + 7} ${y0}Z`, fill: FK.alpha(R.lt, .8), stroke: R.dk, 'stroke-width': .9 }, sh));
    const lg = P('ligule'); [204, 150].forEach(y => E('path', { d: `M${RX - 4} ${y + 8}l2 -9h4l2 9`, fill: '#fff', stroke: R.dk, 'stroke-width': .8 }, lg));
    const au = P('auricle'); [204, 150].forEach(y => E('path', { d: `M${RX - 6} ${y + 9}q-6 -2 -5 -8M${RX + 6} ${y + 9}q6 -2 5 -8`, stroke: R.dk, 'stroke-width': 1.4, fill: 'none' }, au));
    const bl = P('blade'); [[204, 1], [150, -1]].forEach(([y, s]) => { E('path', { d: `M${RX + s * 4} ${y + 4}Q${RX + s * 70} ${y - 50} ${RX + s * 130} ${y - 40}Q${RX + s * 70} ${y - 40} ${RX + s * 4} ${y + 10}Z`, fill: R.c, stroke: R.dk, 'stroke-width': .8 }, bl); [0, 1, 2].forEach(j => E('path', { d: `M${RX + s * 8} ${y + 6 - j}Q${RX + s * 70} ${y - 44 + j * 3} ${RX + s * 124} ${y - 40}`, stroke: FK.alpha(R.lt, .8), 'stroke-width': .5, fill: 'none' }, bl)); });
  },
  idle(g, C, t) {
    const Ry = BK.ramp(6), sw = 6 * Math.sin(t * 1.2);
    E('path', { d: `M${RX} 96Q${RX + 4 + sw * .3} 60 ${RX + 22 + sw} 40`, stroke: BK.ramp(10).dk, 'stroke-width': 2.2, fill: 'none' }, g);
    for (let i = 0; i < 6; i++) { const f = .25 + i * .13, x0 = RX + (22 + sw) * f * f + 2, y0 = 96 - 56 * f, s = i % 2 ? 1 : -1; const ex = x0 + s * (26 - i * 2) + sw * .6, ey = y0 + 26; E('path', { d: `M${x0.toFixed(1)} ${y0.toFixed(1)}Q${(x0 + s * 10).toFixed(1)} ${(y0 + 4).toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}`, stroke: BK.ramp(10).dk, 'stroke-width': 1, fill: 'none' }, g); for (let k = 0; k < 4; k++) { const ff = .35 + k * .2, x = x0 + (ex - x0) * ff, y = y0 + (ey - y0) * ff + 4; E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: 2.6, ry: 5, fill: Ry.c, stroke: Ry.dk, 'stroke-width': .5, transform: `rotate(${(s * 25).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})` }, g); } }
  },
  parts: [
    { id: 'culm', bn: 'কালম (কাণ্ড)', lb: 'কালম', en: 'Culm', fn: 'ঘাসের খাড়া, নলাকার কাণ্ড — পর্ব নিরেট, পর্বমধ্য সাধারণত ফাঁপা (ভুট্টা ও আখে নিরেট, শাঁসযুক্ত)।', a: [RX - 3, 230], l: [40, 230], an: 'middle' },
    { id: 'node', bn: 'পর্ব', en: 'Node', fn: 'কাণ্ডের যে স্ফীত, নিরেট অংশ থেকে পাতা বের হয়; দুই পর্বের মাঝের অংশ পর্বমধ্য।', a: [RX - 5, 252], l: [40, 262], an: 'middle' },
    { id: 'sheath', bn: 'পত্রখোল (লিফ শিথ)', lb: 'পত্রখোল', en: 'Leaf sheath', fn: 'পত্রমূল চওড়া হয়ে কাণ্ডকে নলের মতো ঘিরে থাকে — খোল খোলা (কিনারা জোড়া লাগে না); কাণ্ডকে শক্তি দেয়।', a: [RX + 7, 228], l: [300, 252], an: 'middle' },
    { id: 'ligule', bn: 'লিগিউল', en: 'Ligule', fn: 'খোল ও ফলকের সংযোগে পাতলা ঝিল্লির মতো উপাঙ্গ — পানি ও পোকা খোলের ভেতরে ঢুকতে বাধা দেয়।', a: [RX + 2, 150], l: [300, 112], an: 'middle' },
    { id: 'auricle', bn: 'অরিকল', en: 'Auricle', fn: 'খোলের মাথায় দুই পাশে কানের মতো ছোট উপাঙ্গ — ধানে রোমশ; ধানের চারা থেকে শ্যামা ঘাস (অরিকল-লিগিউলহীন) আলাদা করতে কাজে লাগে।', a: [RX - 10, 154], l: [40, 150], an: 'middle' },
    { id: 'blade', bn: 'পত্রফলক (সমান্তরাল শিরা)', lb: 'পত্রফলক', en: 'Leaf blade', fn: 'লম্বা, সরু, ফিতার মতো ফলক; শিরাবিন্যাস সমান্তরাল — একবীজপত্রী।', a: [RX + 90, 170], l: [300, 200], an: 'middle' },
    { id: 'tiller', bn: 'কুশি (টিলার)', lb: 'কুশি', en: 'Tiller', fn: 'গোড়ার পর্ব থেকে বের হওয়া পার্শ্বীয় বিটপ — প্রতিটি কুশিতে শিষ হয়; বেশি কুশি = বেশি ফলন।', a: [RX - 22, 190], l: [40, 196], an: 'middle' },
    { id: 'root', bn: 'গুচ্ছমূল', en: 'Fibrous roots', fn: 'ভ্রূণমূল দ্রুত নষ্ট হয়ে কাণ্ডের গোড়ার পর্ব থেকে অনেক সমান মোটা অস্থানিক মূল — একবীজপত্রীর বৈশিষ্ট্য।', a: [RX + 30, 318], l: [290, 318], an: 'middle' }
  ],
  extra(svg, C) { T(svg, RX + 60, 30, 'প্যানিকল (শিষ)', { fs: 12, w: 600, c: BK.ramp(6).ink }); }
}));

/* ───────── স্পাইকলেট ───────── */
const SX = 180;
V.spikelet = Object.assign({
  t: 'ধানের স্পাইকলেট ও পুষ্পিকার গঠন', k: ['2d', 'label', 'int', 'anim'],
  cap: 'স্পাইকলেট Poaceae এর পুষ্পবিন্যাসের একক। ধানে প্রতিটি স্পাইকলেটে একটি উর্বর পুষ্পিকা: বাইরে বড় নৌকাকার লেমা (মঞ্জরিপত্র) ও ছোট প্যালিয়া (উপমঞ্জরিপত্র); ভেতরে দুটি লডিকুল (পুষ্পপুট), ছয়টি পুংকেশর ও একটি গর্ভাশয় — মাথায় দুটি পালকের মতো গর্ভমুণ্ড। গোড়ায় দুটি ক্ষুদ্র তুষ ও দুটি বন্ধ্যা লেমা। চালু করলে পরাগধানী ঝুলে বাতাসে পরাগ ওড়ে।'
}, BK.diagram({
  W: 360, H: 320, label: 'ধানের স্পাইকলেট',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Ry = BK.ramp(6), Rg = BK.ramp(7), R = BK.ramp(10);
    const pd = P('pedicel'); E('path', { d: `M${SX} 316V268`, stroke: R.dk, 'stroke-width': 3 }, pd);
    const gl = P('glume'); [-1, 1].forEach(s => E('path', { d: `M${SX + s * 3} 270l${s * 4} -6l${s * -1} 6z`, fill: R.c, stroke: R.dk }, gl));
    const sl = P('sterile'); [-1, 1].forEach(s => E('path', { d: `M${SX + s * 4} 266Q${SX + s * 14} 250 ${SX + s * 9} 236Q${SX + s * 6} 252 ${SX + s * 3} 266Z`, fill: FK.alpha(R.lt, .9), stroke: R.dk }, sl));
    const lm = P('lemma'); E('path', { d: `M${SX - 4} 262C${SX - 80} 230 ${SX - 70} 90 ${SX - 6} 50C${SX - 40} 100 ${SX - 46} 220 ${SX - 2} 262Z`, fill: FK.alpha(Ry.c, .85), stroke: Ry.dk, 'stroke-width': 1.4 }, lm); for (let i = 0; i < 4; i++) E('path', { d: `M${SX - 4} 260C${SX - 64 + i * 8} 220 ${SX - 56 + i * 8} 100 ${SX - 6} 54`, stroke: Ry.dk, 'stroke-width': .5, fill: 'none' }, lm);
    const aw = P('awn'); E('path', { d: `M${SX - 6} 50L${SX - 14} 14`, stroke: Ry.dk, 'stroke-width': 1.6 }, aw);
    const pa = P('palea'); E('path', { d: `M${SX + 4} 262C${SX + 64} 226 ${SX + 56} 100 ${SX + 6} 60C${SX + 30} 110 ${SX + 34} 220 ${SX + 2} 262Z`, fill: FK.alpha(Ry.lt, .95), stroke: Ry.dk, 'stroke-width': 1.4 }, pa);
    const lo = P('lodicule'); [-1, 1].forEach(s => E('ellipse', { cx: SX + s * 9, cy: 250, rx: 4, ry: 7, fill: '#fff', stroke: R.dk }, lo));
    const ov = P('ovary'); E('ellipse', { cx: SX, cy: 232, rx: 10, ry: 14, fill: FK.alpha(Rg.lt, .95), stroke: Rg.dk, 'stroke-width': 1.2 }, ov);
    const sg = P('stigma'); [-1, 1].forEach(s => { E('path', { d: `M${SX + s * 3} 219Q${SX + s * 16} 196 ${SX + s * 26} 176`, stroke: Rg.dk, 'stroke-width': 1.6, fill: 'none' }, sg); for (let k = 0; k < 7; k++) { const f = k / 7, x = SX + s * (3 + 23 * f), y = 219 - 43 * f; E('path', { d: `M${x.toFixed(1)} ${y.toFixed(1)}l${s * 6} -2M${x.toFixed(1)} ${y.toFixed(1)}l${s * -3} -5`, stroke: Rg.c, 'stroke-width': 1 }, sg); } });
    P('stamen');
  },
  idle(g, C, t) {
    const Ra = BK.ramp(6);
    for (let i = 0; i < 6; i++) { const s = i < 3 ? -1 : 1, j = i % 3, bx = SX + s * (5 + j * 3), sw = 3 * Math.sin(t * 2 + i); const ex = SX + s * (30 + j * 16) + sw, ey = 150 + j * 18; E('path', { d: `M${bx} 246Q${bx + s * 6} 200 ${ex.toFixed(1)} ${(ey + 10).toFixed(1)}`, stroke: '#e8e0c8', 'stroke-width': 1.4, fill: 'none' }, g); E('rect', { x: (ex - 3).toFixed(1), y: ey - 6, width: 6, height: 18, rx: 3, fill: '#e8c040', stroke: '#a08020', transform: `rotate(${(sw * 4).toFixed(0)} ${ex.toFixed(1)} ${ey + 10})` }, g); }
    for (let i = 0; i < 10; i++) { const f = (t * .3 + i / 10) % 1; E('circle', { cx: (SX + 60 + f * 120).toFixed(1), cy: (150 + i * 8 - 40 * f).toFixed(1), r: 1.6, fill: '#e8c040', opacity: (1 - f).toFixed(2) }, g); }
  },
  parts: [
    { id: 'awn', bn: 'শুং (অন)', lb: 'শুং', en: 'Awn', fn: 'লেমার আগার সুতার মতো উপাঙ্গ — অনেক জাতে থাকে, অনেকে নেই।', a: [SX - 12, 22], l: [96, 22], an: 'middle' },
    { id: 'lemma', bn: 'লেমা (মঞ্জরিপত্র)', lb: 'লেমা', en: 'Lemma', fn: 'বড়, শক্ত, নৌকাকার বাইরের আবরণ — পুষ্পিকার মঞ্জরিপত্র; পাকা ধানের তুষের বড় অংশ।', a: [SX - 56, 150], l: [40, 120], an: 'middle' },
    { id: 'palea', bn: 'প্যালিয়া (উপমঞ্জরিপত্র)', lb: 'প্যালিয়া', en: 'Palea', fn: 'লেমার বিপরীতে ছোট, দুই শিরার আবরণ — উপমঞ্জরিপত্র; লেমার কিনারায় আটকে থাকে।', a: [SX + 46, 150], l: [320, 110], an: 'middle' },
    { id: 'stamen', bn: 'পুংকেশর (6টি)', lb: 'পুংকেশর', en: 'Stamens', fn: 'ধানে 6টি (দুই আবর্তে 3+3; অধিকাংশ ঘাসে 3টি); লম্বা সরু পুংদণ্ড, দোদুল্যমান (ভারসাটাইল) পরাগধানী বাইরে ঝুলে বাতাসে পরাগ ছড়ায়।', a: [SX + 46, 168], l: [320, 160], an: 'middle' },
    { id: 'stigma', bn: 'পালকসদৃশ গর্ভমুণ্ড (2টি)', lb: 'গর্ভমুণ্ড', en: 'Feathery stigmas', fn: 'দুটি পালকের মতো রোমশ গর্ভমুণ্ড — বাতাসে ভেসে আসা পরাগরেণু আটকায় (বায়ুপরাগী)।', a: [SX + 22, 182], l: [320, 210], an: 'middle' },
    { id: 'ovary', bn: 'গর্ভাশয় (উচ্চ, একপ্রকোষ্ঠী)', lb: 'গর্ভাশয়', en: 'Ovary', fn: 'উচ্চ গর্ভাশয়, এক প্রকোষ্ঠ, একটি ডিম্বক (ভিত্তীয় অমরা) — পাকলে ক্যারিওপসিস ফল (চাল)।', a: [SX - 10, 232], l: [40, 230], an: 'middle' },
    { id: 'lodicule', bn: 'লডিকুল (2টি)', lb: 'লডিকুল', en: 'Lodicules', fn: 'গর্ভাশয়ের গোড়ায় দুটি ছোট রসালো শল্ক — পুষ্পপুটের অবশেষ; ফুলে উঠে লেমা-প্যালিয়া ফাঁক করে ফুল ফোটায়।', a: [SX + 12, 252], l: [320, 262], an: 'middle' },
    { id: 'sterile', bn: 'বন্ধ্যা লেমা', en: 'Sterile lemmas', fn: 'উর্বর পুষ্পিকার নিচে দুটি ছোট বল্লমাকার বন্ধ্যা লেমা — ক্ষয়প্রাপ্ত পুষ্পিকার অবশেষ।', a: [SX - 10, 244], l: [40, 270], an: 'middle' },
    { id: 'glume', bn: 'তুষ (গ্লুম)', lb: 'তুষ (গ্লুম)', en: 'Glumes', fn: 'স্পাইকলেটের একেবারে গোড়ায় দুটি অতি ক্ষুদ্র তুষ — ধানে প্রায় বিলুপ্ত।', a: [SX - 5, 266], l: [96, 300], an: 'middle' },
    { id: 'pedicel', bn: 'স্পাইকলেটের বৃন্ত', lb: 'বৃন্ত', en: 'Pedicel', fn: 'স্পাইকলেটকে প্যানিকলের শাখার সাথে যুক্ত রাখে।', a: [SX, 300], l: [260, 306], an: 'middle' }
  ]
}));

/* ───────── জবা ফুল ───────── */
const HX = 150, HY = 270;
V.hibiscus = Object.assign({
  t: 'জবা ফুল (Hibiscus rosa-sinensis) — Malvaceae এর বৈশিষ্ট্য', k: ['2d', 'label', 'int', 'anim'],
  cap: 'বৃতির বাইরে উপবৃতি; পাঁচটি যুক্ত বৃত্যংশ; পাঁচটি বড় পাকানো (টুইস্টেড) পাপড়ি, গোড়ায় পুংকেশরীয় নলের সাথে যুক্ত; অসংখ্য পুংকেশরের পুংদণ্ড যুক্ত হয়ে নল (একগুচ্ছ), নলের উপরের দিকে বৃক্কাকার পরাগধানী; নলের ভেতর দিয়ে গর্ভদণ্ড উঠে মাথায় পাঁচটি গর্ভমুণ্ড। চালু করলে ফুল দোলে।'
}, BK.diagram({
  W: 360, H: 330, label: 'জবা ফুল',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rp = BK.ramp(4), R = BK.ramp(10), Ra = BK.ramp(6), Rg = BK.ramp(8);
    const pd = P('pedicel'); E('path', { d: `M${HX} 326V${HY + 4}`, stroke: R.dk, 'stroke-width': 4 }, pd);
    const ep = P('epicalyx'); for (let i = 0; i < 7; i++) { const a = Math.PI / 2 + (i - 3) * .3; E('path', { d: `M${HX} ${HY + 4}l${(26 * Math.cos(a + Math.PI)).toFixed(1)} ${(-10 - 4 * Math.abs(i - 3)).toFixed(1)}`, stroke: R.c, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, ep); }
    const ca = P('calyx'); E('path', { d: `M${HX - 18} ${HY - 26}L${HX - 12} ${HY}H${HX + 12}L${HX + 18} ${HY - 26}L${HX + 10} ${HY - 18}L${HX + 4} ${HY - 30}L${HX - 2} ${HY - 18}L${HX - 10} ${HY - 30}Z`, fill: R.c, stroke: R.dk }, ca);
    const pt = P('petal'); [-2, 2, -1, 1, 0].forEach(k => { const ang = k * .52, ux = Math.sin(ang), uy = -Math.cos(ang), nx = -uy, ny = ux, bx = HX, by = HY - 24, L = 122 - Math.abs(k) * 6, w = 34; const tx = bx + ux * L, ty = by + uy * L; E('path', { d: `M${bx} ${by}C${(bx + ux * L * .4 + nx * w).toFixed(1)} ${(by + uy * L * .4 + ny * w).toFixed(1)} ${(tx + nx * w * .9).toFixed(1)} ${(ty + ny * w * .9).toFixed(1)} ${tx.toFixed(1)} ${ty.toFixed(1)}C${(tx - nx * w * .9).toFixed(1)} ${(ty - ny * w * .9).toFixed(1)} ${(bx + ux * L * .4 - nx * w).toFixed(1)} ${(by + uy * L * .4 - ny * w).toFixed(1)} ${bx} ${by}Z`, fill: FK.alpha(Rp.c, Math.abs(k) === 2 ? .6 : .8), stroke: Rp.dk, 'stroke-width': 1.1 }, pt); E('path', { d: `M${bx} ${by}L${(bx + ux * L * .8).toFixed(1)} ${(by + uy * L * .8).toFixed(1)}`, stroke: FK.alpha(Rp.dk, .4), 'stroke-width': .8 }, pt); });
    const ov = P('ovary'); E('ellipse', { cx: HX, cy: HY - 34, rx: 9, ry: 10, fill: FK.alpha(BK.ramp(7).lt, .95), stroke: BK.ramp(7).dk }, ov);
    const tb = P('tube'); E('path', { d: `M${HX - 4} ${HY - 40}L${HX - 3} ${HY - 210}H${HX + 3}L${HX + 4} ${HY - 40}Z`, fill: '#f6d0d8', stroke: Rp.dk, 'stroke-width': .8 }, tb);
    const an = P('anther'); for (let i = 0; i < 18; i++) { const y = HY - 120 - i * 5, s = i % 2 ? 1 : -1, x = HX + s * (6 + (i % 3) * 2); E('path', { d: `M${HX + s * 3} ${y}L${x} ${y - 2}`, stroke: Rp.dk, 'stroke-width': .6 }, an); E('path', { d: `M${x - 3} ${y - 2}a3 3 0 1 0 6 0q-3 2 -6 0z`, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .5 }, an); }
    const st = P('style'); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * .32; E('path', { d: `M${HX} ${HY - 210}l${(18 * Math.cos(a)).toFixed(1)} ${(18 * Math.sin(a)).toFixed(1)}`, stroke: Rg.dk, 'stroke-width': 1.6 }, st); }
    const sg = P('stigma'); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * .32; E('circle', { cx: (HX + 21 * Math.cos(a)).toFixed(1), cy: (HY - 210 + 21 * Math.sin(a)).toFixed(1), r: 3.6, fill: '#a0103a', stroke: '#600020' }, sg); }
  },
  idle(g, C, t) { const k = .5 + .5 * Math.sin(t * 1.4); for (let i = 0; i < 3; i++) { const f = (t * .25 + i / 3) % 1; E('circle', { cx: (HX + 30 + 90 * f).toFixed(1), cy: (HY - 150 - 30 * Math.sin(f * 3)).toFixed(1), r: 2.2, fill: BK.ramp(6).c, opacity: (1 - f).toFixed(2) }, g); } E('circle', { cx: HX, cy: HY - 210, r: 26 + 4 * k, fill: 'none', stroke: FK.alpha('#a0103a', .25 * k), 'stroke-width': 2 }, g); },
  parts: [
    { id: 'stigma', bn: 'গর্ভমুণ্ড (5টি, মুণ্ডাকার)', lb: 'গর্ভমুণ্ড', en: 'Stigmas', fn: 'গর্ভদণ্ডের পাঁচটি শাখার মাথায় পাঁচটি গোল রোমশ গর্ভমুণ্ড — পাঁচটি গর্ভপত্রের নির্দেশক।', a: [HX + 18, HY - 222], l: [290, 26], an: 'middle' },
    { id: 'style', bn: 'গর্ভদণ্ড (5 শাখা)', lb: 'গর্ভদণ্ড', en: 'Style', fn: 'লম্বা গর্ভদণ্ড পুংকেশরীয় নলের ভেতর দিয়ে উঠে নলের মাথার উপরে পাঁচ শাখায় বিভক্ত।', a: [HX - 10, HY - 216], l: [60, 30], an: 'middle' },
    { id: 'anther', bn: 'বৃক্কাকার এক-প্রকোষ্ঠী পরাগধানী', lb: 'পরাগধানী', en: 'Reniform monothecous anthers', fn: 'নলের উপরের অংশে ছোট মুক্ত পুংদণ্ডের মাথায় বৃক্কাকার পরাগধানী — এক প্রকোষ্ঠী (মনোথিকাস); পরাগরেণু বড় ও কাঁটাযুক্ত — Malvaceae এর অন্যতম শনাক্তকারী বৈশিষ্ট্য।', a: [HX + 9, HY - 150], l: [300, 80], an: 'middle' },
    { id: 'tube', bn: 'পুংকেশরীয় নল (একগুচ্ছ)', lb: 'পুংকেশরীয় নল', en: 'Staminal column', fn: 'অসংখ্য পুংকেশরের পুংদণ্ড যুক্ত হয়ে একটি নল — একগুচ্ছ (মনোঅ্যাডেলফাস) পুংকেশর; গোড়ায় পাপড়ির সাথে যুক্ত।', a: [HX + 3, HY - 90], l: [300, 130], an: 'middle' },
    { id: 'petal', bn: 'পাপড়ি (5টি, পাকানো)', lb: 'পাপড়ি', en: 'Petals (twisted)', fn: 'পাঁচটি বড়, উজ্জ্বল, বিযুক্ত পাপড়ি — কুঁড়িতে পাকানো (টুইস্টেড) বিন্যাস; গোড়ায় পুংকেশরীয় নলের সাথে লগ্ন।', a: [HX - 80, HY - 110], l: [40, 100], an: 'middle' },
    { id: 'ovary', bn: 'গর্ভাশয় (উচ্চ, 5 প্রকোষ্ঠী)', lb: 'গর্ভাশয়', en: 'Ovary', fn: 'পাঁচটি যুক্ত গর্ভপত্র, উচ্চ গর্ভাশয়, পাঁচ প্রকোষ্ঠ, অক্ষীয় অমরা — পাপড়ি ও নলের গোড়ায় ঢাকা।', a: [HX - 8, HY - 34], l: [40, 210], an: 'middle' },
    { id: 'calyx', bn: 'বৃতি (5টি, যুক্ত)', lb: 'বৃতি', en: 'Calyx', fn: 'পাঁচটি যুক্ত সবুজ বৃত্যংশ — ভালভেট বিন্যাস; স্থায়ী।', a: [HX + 14, HY - 18], l: [300, 220], an: 'middle' },
    { id: 'epicalyx', bn: 'উপবৃতি (5–8টি)', lb: 'উপবৃতি', en: 'Epicalyx', fn: 'বৃতির ঠিক নিচে বাইরে এক সারি সরু সবুজ উপমঞ্জরিপত্র — Malvaceae এর বড় শনাক্তকারী বৈশিষ্ট্য (তুলায় 3টি বড়, ঢেঁড়সে অনেক)।', a: [HX - 22, HY - 4], l: [40, 270], an: 'middle' },
    { id: 'pedicel', bn: 'পুষ্পবৃন্ত (কাক্ষিক, একক ফুল)', lb: 'পুষ্পবৃন্ত', en: 'Pedicel', fn: 'ফুল সাধারণত পত্রকক্ষে একক (সলিটারি)।', a: [HX, 310], l: [290, 310], an: 'middle' }
  ]
}));

/* ───────── Malvaceae খুঁটিনাটি ───────── */
const MD = {
  hair: ['তারকা রোম ও মিউসিলেজ', 'পাতা ও কচি কাণ্ডে তারার মতো শাখান্বিত রোম (স্টেলেট হেয়ার); দেহে পিচ্ছিল মিউসিলেজ — ঢেঁড়সের লালার মতো।'],
  anther: ['বৃক্কাকার পরাগধানী', 'পরাগধানী এক প্রকোষ্ঠী (মনোথিকাস), বৃক্কাকার; আড়াআড়ি ফেটে বড়, কাঁটাযুক্ত পরাগরেণু ছাড়ে।'],
  ovary: ['গর্ভাশয়ের প্রস্থচ্ছেদ', 'পাঁচটি যুক্ত গর্ভপত্র, পাঁচ প্রকোষ্ঠ, অক্ষীয় অমরা — প্রতিটি প্রকোষ্ঠে এক বা একাধিক ডিম্বক।'],
  fruit: ['ক্যাপসুল ফল', 'ফল সাধারণত প্রকোষ্ঠবিদারী ক্যাপসুল (ঢেঁড়স, তুলা, জবা) — পাকলে প্রকোষ্ঠ বরাবর ফাটে; কারও খণ্ডফল (Abutilon, Sida)। তুলার বীজে লম্বা রোম — তুলা।']
};
V.malvaDetail = {
  t: 'Malvaceae গোত্রের শনাক্তকারী খুঁটিনাটি', k: ['2d', 'anim', 'int'],
  cap: 'উপবৃতি ও পুংকেশরীয় নলের পাশাপাশি এই চারটি বৈশিষ্ট্য Malvaceae শনাক্তকরণে নিশ্চয়তা দেয়। ধরন বদলাও; চালু করলে ক্যাপসুল ফাটে বা পরাগধানী খোলে।',
  html: () => `<div class="fk-row">${X.seg('md', Object.keys(MD).map(k => [k, MD[k][0]]), 'anther')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 230, cx = 180, cy = 115;
    let ty = 'anther', C, svg, lay, tt = 0;
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': MD[ty][0] }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); lay = E('g', {}, svg); $('info').innerHTML = `<b>${MD[ty][0]}</b> — ${MD[ty][1]}`; paint(); };
    const paint = () => {
      lay.innerHTML = ''; const k = (Math.sin(tt * 1.2) + 1) / 2, R = BK.ramp(10), Ra = BK.ramp(6), Rg = BK.ramp(7);
      if (ty === 'hair') { E('rect', { x: 20, y: 40, width: 320, height: 150, rx: 10, fill: FK.alpha(R.c, .35), stroke: R.dk }, lay); for (let i = 0; i < 7; i++) { const x = 60 + i * 40, y = 80 + (i % 2) * 60; for (let j = 0; j < 6; j++) { const a = j / 6 * 6.283 + tt * .3; E('path', { d: `M${x} ${y}l${(16 * Math.cos(a)).toFixed(1)} ${(16 * Math.sin(a) * .6 - 4).toFixed(1)}`, stroke: '#f0f0e0', 'stroke-width': 1.6, 'stroke-linecap': 'round' }, lay); } E('circle', { cx: x, cy: y, r: 2.6, fill: '#c8c0a0' }, lay); } T(lay, cx, 214, 'পাতার পৃষ্ঠে তারকা রোম (হ্যান্ড লেন্সে)', { fs: 11, a: 'middle', c: C.mu }); }
      if (ty === 'anther') { E('path', { d: `M${cx} 210V140`, stroke: BK.ramp(4).dk, 'stroke-width': 2 }, lay); E('path', { d: `M${cx - 50} 120a50 34 0 1 0 100 0q-50 ${-30 - 8 * k} -100 0z`, fill: Ra.c, stroke: Ra.dk, 'stroke-width': 2 }, lay); E('path', { d: `M${cx - 46} 118Q${cx} ${92 - 30 * k} ${cx + 46} 118`, stroke: Ra.dk, 'stroke-width': 1.2, fill: 'none', 'stroke-dasharray': '4 3' }, lay); for (let i = 0; i < 8; i++) { const x = cx - 36 + i * 10, y = 112 - 34 * k * Math.sin(i / 7 * Math.PI) - 10 * k; E('circle', { cx: x, cy: y, r: 4.4, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk }, lay); for (let j = 0; j < 6; j++) { const a = j * 1.047; E('path', { d: `M${(x + 4.4 * Math.cos(a)).toFixed(1)} ${(y + 4.4 * Math.sin(a)).toFixed(1)}l${(2 * Math.cos(a)).toFixed(1)} ${(2 * Math.sin(a)).toFixed(1)}`, stroke: BK.ramp(2).dk, 'stroke-width': .8 }, lay); } } T(lay, 290, 70, 'এক প্রকোষ্ঠ', { fs: 11, a: 'middle', w: 600, c: Ra.ink }); T(lay, 290, 200, 'কাঁটাযুক্ত পরাগরেণু', { fs: 11, a: 'middle', w: 600, c: BK.ramp(2).ink }); }
      if (ty === 'ovary') { E('circle', { cx, cy, r: 80, fill: FK.alpha(Rg.lt, .85), stroke: Rg.dk, 'stroke-width': 3 }, lay); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566; E('path', { d: `M${cx} ${cy}L${(cx + 80 * Math.cos(a)).toFixed(1)} ${(cy + 80 * Math.sin(a)).toFixed(1)}`, stroke: Rg.dk, 'stroke-width': 2.4 }, lay); const am = a + .628; [28, 52].forEach((r, j) => E('ellipse', { cx: (cx + r * Math.cos(am)).toFixed(1), cy: (cy + r * Math.sin(am)).toFixed(1), rx: 6, ry: 8.5, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk, transform: `rotate(${(am * 57.3).toFixed(0)} ${(cx + r * Math.cos(am)).toFixed(1)} ${(cy + r * Math.sin(am)).toFixed(1)})`, opacity: (.6 + .4 * Math.abs(Math.sin(tt * 2 + i + j))).toFixed(2) }, lay)); } E('circle', { cx, cy, r: 10, fill: R.c, stroke: R.dk }, lay); T(lay, 310, 40, '5 প্রকোষ্ঠ', { fs: 11, a: 'middle', w: 600, c: Rg.ink }); T(lay, 310, 200, 'অক্ষীয় অমরা', { fs: 11, a: 'middle', w: 600, c: R.ink }); }
      if (ty === 'fruit') { const op = Math.min(1, k * 1.3); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566, ox = cx + 22 * op * Math.cos(a), oy = cy + 22 * op * Math.sin(a), deg = a * 57.3 + 90; E('path', { d: `M${ox} ${oy - 70}Q${ox + 30} ${oy - 20} ${ox} ${oy + 60}Q${ox - 30} ${oy - 20} ${ox} ${oy - 70}Z`, fill: FK.alpha('#9a7a40', .85), stroke: '#6a5020', transform: `rotate(${(deg * .15 * op).toFixed(1)} ${cx} ${cy + 60})` }, lay); } if (op > .5) for (let i = 0; i < 6; i++) { const a = i * 1.05; E('circle', { cx: (cx + 40 * Math.cos(a)).toFixed(1), cy: (cy + 30 * Math.sin(a)).toFixed(1), r: 4, fill: '#3a2a1a' }, lay); E('path', { d: `M${(cx + 40 * Math.cos(a)).toFixed(1)} ${(cy + 30 * Math.sin(a)).toFixed(1)}l${(14 * Math.cos(a)).toFixed(1)} ${(10 * Math.sin(a)).toFixed(1)}`, stroke: '#fff', 'stroke-width': 3, opacity: (op - .5) * 2 }, lay); } T(lay, cx, 214, op > .5 ? 'প্রকোষ্ঠবিদারী ক্যাপসুল — বীজ ও রোম (তুলা)' : 'ক্যাপসুল', { fs: 11, a: 'middle', c: C.mu }); }
    };
    const A = X.anim(root, dt => { tt += dt; paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'md', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── পুষ্প প্রতীক ───────── */
const FDI = {
  jaba: ['জবা (Malvaceae)', 'উপরে মাতৃ অক্ষ, নিচে মঞ্জরিপত্র। বাইরে থেকে: উপবৃতি (5–8), যুক্ত বৃতি (5, ভালভেট), পাকানো পাপড়ি (5), পুংকেশরীয় নলে অসংখ্য বৃক্কাকার পরাগধানী, কেন্দ্রে 5 প্রকোষ্ঠী অক্ষীয় অমরার গর্ভাশয়।', ['axis', 'bract', 'epi', 'calyx', 'corolla', 'andro', 'gyno']],
  dhan: ['ধান (Poaceae)', 'উপরে মাতৃ অক্ষের দিকে প্যালিয়া (দুই শিরা), নিচে বড় লেমা। সামনে (লেমার দিকে) দুটি লডিকুল; দুই আবর্তে 3 + 3 = 6টি পুংকেশর; কেন্দ্রে একপ্রকোষ্ঠী গর্ভাশয়, একটি ডিম্বক, দুটি গর্ভমুণ্ড।', ['axis', 'lemma', 'palea', 'lodi', 'stamen6', 'gynoP']]
};
const FDN = { axis: 'মাতৃ অক্ষ', bract: 'মঞ্জরিপত্র', epi: 'উপবৃতি', calyx: 'বৃতি', corolla: 'দলমণ্ডল', andro: 'পুংস্তবক', gyno: 'স্ত্রীস্তবক', lemma: 'লেমা', palea: 'প্যালিয়া', lodi: 'লডিকুল', stamen6: 'পুংকেশর (6)', gynoP: 'স্ত্রীস্তবক' };
V.floralDiagram = {
  t: 'পুষ্প প্রতীক (ফ্লোরাল ডায়াগ্রাম) — জবা ও ধান', k: ['2d', 'anim', 'int'],
  cap: 'পুষ্প প্রতীক হলো ফুলের প্রস্থচ্ছেদের সাংকেতিক নকশা — মাতৃ অক্ষ উপরে, মঞ্জরিপত্র নিচে; স্তবকগুলো সমকেন্দ্রিক বৃত্তে, সংযুক্তি রেখায় দেখানো হয়। চালু করলে বাইরে থেকে ভেতরে স্তবক একে একে আঁকা হয়।',
  html: () => `<div class="fk-row">${X.seg('fd', Object.keys(FDI).map(k => [k, FDI[k][0]]), 'jaba')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 300, cx = 160, cy = 155;
    let ty = 'jaba', C, svg, lay, tt = 99;
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পুষ্প প্রতীক' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); lay = E('g', {}, svg); $('info').innerHTML = `<b>${FDI[ty][0]}</b> — ${FDI[ty][1]}`; paint(); };
    const arc = (r, a0, a1) => `M${(cx + r * Math.cos(a0)).toFixed(1)} ${(cy + r * Math.sin(a0)).toFixed(1)}A${r} ${r} 0 0 1 ${(cx + r * Math.cos(a1)).toFixed(1)} ${(cy + r * Math.sin(a1)).toFixed(1)}`;
    const paint = () => {
      lay.innerHTML = ''; const steps = FDI[ty][2], n = Math.min(steps.length, Math.floor(tt / 1.1) + 1), R = BK.ramp(10), Rp = BK.ramp(4), Ra = BK.ramp(6), Rg = BK.ramp(7), Ry = BK.ramp(6);
      const show = k => steps.indexOf(k) >= 0 && steps.indexOf(k) < n;
      const leg = []; steps.slice(0, n).forEach(k => leg.push(k));
      if (show('axis')) E('circle', { cx, cy: 20, r: 6, fill: C.fg }, lay);
      if (show('bract')) E('path', { d: `M${cx - 50} 292Q${cx} 270 ${cx + 50} 292Q${cx} 282 ${cx - 50} 292Z`, fill: R.c, stroke: R.dk }, lay);
      if (ty === 'jaba') {
        if (show('epi')) for (let i = 0; i < 7; i++) { const a = i / 7 * 6.283 - Math.PI / 2 + .2; E('path', { d: `M${(cx + 118 * Math.cos(a)).toFixed(1)} ${(cy + 118 * Math.sin(a)).toFixed(1)}l${(8 * Math.cos(a + 1.57)).toFixed(1)} ${(8 * Math.sin(a + 1.57)).toFixed(1)}`, stroke: R.dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, lay); }
        if (show('calyx')) { for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566 + .63; E('path', { d: arc(102, a - .55, a + .55), stroke: R.c, 'stroke-width': 9, fill: 'none' }, lay); } E('circle', { cx, cy, r: 102, fill: 'none', stroke: R.dk, 'stroke-width': 1.2 }, lay); }
        if (show('corolla')) for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566; let d = ''; for (let k = 0; k <= 20; k++) { const f = k / 20, aa = a - .78 + 1.56 * f, r = 76 + 10 * f + 6 * Math.sin(f * Math.PI); d += (k ? 'L' : 'M') + (cx + r * Math.cos(aa)).toFixed(1) + ' ' + (cy + r * Math.sin(aa)).toFixed(1); } E('path', { d, stroke: Rp.c, 'stroke-width': 8, fill: 'none', 'stroke-linecap': 'round' }, lay); }
        if (show('andro')) { E('circle', { cx, cy, r: 56, fill: 'none', stroke: FK.alpha(Rp.dk, .5), 'stroke-width': 1.2, 'stroke-dasharray': '3 2' }, lay); for (let i = 0; i < 20; i++) { const a = i / 20 * 6.283, x = cx + 56 * Math.cos(a), y = cy + 56 * Math.sin(a); E('path', { d: `M${(x - 3).toFixed(1)} ${y.toFixed(1)}a3 3 0 1 0 6 0q-3 2 -6 0z`, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .5, transform: `rotate(${(a * 57.3 + 90).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})` }, lay); } }
        if (show('gyno')) { E('circle', { cx, cy, r: 32, fill: FK.alpha(Rg.lt, .9), stroke: Rg.dk, 'stroke-width': 2 }, lay); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566; E('path', { d: `M${cx} ${cy}L${(cx + 32 * Math.cos(a)).toFixed(1)} ${(cy + 32 * Math.sin(a)).toFixed(1)}`, stroke: Rg.dk, 'stroke-width': 1.4 }, lay); E('circle', { cx: (cx + 14 * Math.cos(a + .63)).toFixed(1), cy: (cy + 14 * Math.sin(a + .63)).toFixed(1), r: 3, fill: BK.ramp(2).c }, lay); } }
      } else {
        if (show('lemma')) E('path', { d: `M${cx - 100} ${cy + 20}Q${cx} ${cy + 140} ${cx + 100} ${cy + 20}Q${cx} ${cy + 116} ${cx - 100} ${cy + 20}Z`, fill: FK.alpha(Ry.c, .85), stroke: Ry.dk }, lay);
        if (show('palea')) { E('path', { d: `M${cx - 74} ${cy - 30}Q${cx} ${cy - 112} ${cx + 74} ${cy - 30}Q${cx} ${cy - 92} ${cx - 74} ${cy - 30}Z`, fill: FK.alpha(Ry.lt, .95), stroke: Ry.dk }, lay); [-1, 1].forEach(s => E('circle', { cx: cx + s * 26, cy: cy - 82, r: 3, fill: Ry.dk }, lay)); }
        if (show('lodi')) [-1, 1].forEach(s => E('ellipse', { cx: cx + s * 24, cy: cy + 56, rx: 8, ry: 5, fill: '#fff', stroke: R.dk }, lay));
        if (show('stamen6')) for (let i = 0; i < 6; i++) { const a = (30 + i * 60) * Math.PI / 180, r = i % 2 ? 62 : 44, x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); E('path', { d: `M${(x - 7).toFixed(1)} ${y.toFixed(1)}a3.5 5 0 1 1 7 0a3.5 5 0 1 1 7 0a3.5 5 0 1 1 -7 0a3.5 5 0 1 1 -7 0z`, fill: '#e8c040', stroke: '#a08020', 'stroke-width': .8 }, lay); }
        if (show('gynoP')) { E('circle', { cx, cy, r: 22, fill: FK.alpha(Rg.lt, .9), stroke: Rg.dk, 'stroke-width': 2 }, lay); E('circle', { cx, cy: cy + 4, r: 6, fill: BK.ramp(2).c }, lay); [-1, 1].forEach(s => E('path', { d: `M${cx + s * 8} ${cy - 14}l${s * 10} -10`, stroke: Rg.dk, 'stroke-width': 2 }, lay)); }
      }
      leg.forEach((k, i) => T(lay, 300, 40 + i * 20, FDN[k], { fs: 10.5, a: 'middle', w: i === n - 1 ? 650 : 400, c: i === n - 1 ? BK.ramp(3).ink : C.mu }));
    };
    const A = X.anim(root, dt => { tt += dt; if (tt > 1.1 * FDI[ty][2].length + 1.5) tt = 0; paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'fd', v => { ty = v; tt = 99; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── একবীজপত্রী বনাম দ্বিবীজপত্রী ───────── */
const MDR = ['বীজপত্র', 'মূল', 'পাতার শিরা', 'ফুলের অংশ', 'কাণ্ডে বান্ডল'];
V.monoDi = {
  t: 'একবীজপত্রী বনাম দ্বিবীজপত্রী — পাঁচ মূল বৈশিষ্ট্য', k: ['2d', 'anim', 'int'],
  cap: 'বাঁ কলামে একবীজপত্রী (ধান), ডান কলামে দ্বিবীজপত্রী (জবা)। সারিতে চাপ দাও বা চালু করো — প্রতিটি বৈশিষ্ট্য উজ্জ্বল হয়ে ব্যাখ্যা দেখায়।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, rh = 64, H = 30 + rh * 5 + 6;
    const D = [['একটি বীজপত্র; ভ্রূণমুকুল কলিওপটাইলে ঢাকা', 'দুটি বীজপত্র'], ['গুচ্ছমূল (অস্থানিক)', 'প্রধান মূল ও শাখামূল'], ['সমান্তরাল শিরাবিন্যাস', 'জালিকা শিরাবিন্যাস'], ['ফুলের অংশ 3 বা 3 এর গুণিতক (ত্রিতয়ী)', 'ফুলের অংশ 4–5 বা এর গুণিতক (চতুর্তয়ী/পঞ্চতয়ী)'], ['বান্ডল ছড়ানো, বদ্ধ (ক্যাম্বিয়াম নেই)', 'বান্ডল বলয়ে, উন্মুক্ত (ক্যাম্বিয়াম আছে)']];
    let C, svg, sel = 0, tt = 0;
    const draw = (g, r, mono, x, y, R) => {
      if (r === 0) { E('ellipse', { cx: x, cy: y, rx: 18, ry: 22, fill: FK.alpha(BK.ramp(6).lt, .9), stroke: BK.ramp(6).dk }, g); if (mono) E('path', { d: `M${x - 6} ${y + 14}Q${x - 14} ${y} ${x - 4} ${y - 16}`, stroke: R.c, 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, g); else [-1, 1].forEach(s => E('path', { d: `M${x} ${y + 16}Q${x + s * 14} ${y} ${x + s * 4} ${y - 16}`, stroke: R.c, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g)); }
      if (r === 1) { E('path', { d: `M${x} ${y - 22}V${y - 10}`, stroke: R.c, 'stroke-width': 2 }, g); if (mono) for (let i = 0; i < 7; i++) { const a = Math.PI / 2 + (i - 3) * .3; E('path', { d: `M${x} ${y - 10}l${(24 * Math.cos(a)).toFixed(1)} ${(26 * Math.sin(a)).toFixed(1)}`, stroke: '#8a6b3a', 'stroke-width': 1.2 }, g); } else { E('path', { d: `M${x} ${y - 10}V${y + 22}`, stroke: '#8a6b3a', 'stroke-width': 3 }, g); [0, 8, 16].forEach(d => [-1, 1].forEach(s => E('path', { d: `M${x} ${y - 6 + d}l${s * 12} 6`, stroke: '#8a6b3a', 'stroke-width': 1 }, g))); } }
      if (r === 2) { if (mono) { E('path', { d: `M${x - 6} ${y + 24}C${x - 10} ${y} ${x - 4} ${y - 16} ${x} ${y - 26}C${x + 4} ${y - 16} ${x + 10} ${y} ${x + 6} ${y + 24}Z`, fill: R.c, stroke: R.dk }, g); [-3, 0, 3].forEach(d => E('path', { d: `M${x + d} ${y + 22}Q${x + d * 1.4} ${y} ${x} ${y - 24}`, stroke: R.lt, 'stroke-width': .7, fill: 'none' }, g)); } else { E('path', { d: `M${x} ${y + 24}C${x - 24} ${y + 6} ${x - 18} ${y - 18} ${x} ${y - 26}C${x + 18} ${y - 18} ${x + 24} ${y + 6} ${x} ${y + 24}Z`, fill: R.c, stroke: R.dk }, g); E('path', { d: `M${x} ${y + 24}V${y - 24}`, stroke: R.lt }, g); [12, 2, -8].forEach(d => [-1, 1].forEach(s => E('path', { d: `M${x} ${y + d}l${s * 10} -6l${s * 2} 6`, stroke: R.lt, 'stroke-width': .7, fill: 'none' }, g))); } }
      if (r === 3) { const n = mono ? 3 : 5; for (let i = 0; i < n; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / n; E('ellipse', { cx: (x + 13 * Math.cos(a)).toFixed(1), cy: (y + 13 * Math.sin(a)).toFixed(1), rx: 9, ry: 6, fill: BK.ramp(mono ? 2 : 4).c, transform: `rotate(${(a * 57.3).toFixed(0)} ${(x + 13 * Math.cos(a)).toFixed(1)} ${(y + 13 * Math.sin(a)).toFixed(1)})` }, g); } E('circle', { cx: x, cy: y, r: 5, fill: BK.ramp(6).c }, g); }
      if (r === 4) { E('circle', { cx: x, cy: y, r: 24, fill: FK.alpha(R.lt, .5), stroke: R.dk }, g); if (mono) [[-12, -8], [6, -14], [12, 6], [-4, 10], [-14, 8], [2, -2], [14, -4]].forEach(([a, b]) => E('circle', { cx: x + a, cy: y + b, r: 2.8, fill: BK.ramp(4).c }, g)); else for (let i = 0; i < 8; i++) { const a = i / 8 * 6.283; E('ellipse', { cx: (x + 15 * Math.cos(a)).toFixed(1), cy: (y + 15 * Math.sin(a)).toFixed(1), rx: 4, ry: 2.6, fill: BK.ramp(4).c, transform: `rotate(${(a * 57.3).toFixed(0)} ${(x + 15 * Math.cos(a)).toFixed(1)} ${(y + 15 * Math.sin(a)).toFixed(1)})` }, g); } }
    };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'একবীজপত্রী বনাম দ্বিবীজপত্রী' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      T(svg, 150, 20, 'একবীজপত্রী', { fs: 12, a: 'middle', w: 650, c: BK.ramp(2).ink }); T(svg, 280, 20, 'দ্বিবীজপত্রী', { fs: 12, a: 'middle', w: 650, c: BK.ramp(4).ink });
      MDR.forEach((m, r) => { const y = 30 + r * rh, on = r === sel, g = E('g', { 'data-i': r, style: 'cursor:pointer' }, svg); E('rect', { x: 6, y: y + 2, width: W - 12, height: rh - 4, rx: 9, fill: on ? FK.alpha(BK.ramp(3).c, .12) : C.s2, stroke: on ? BK.ramp(3).c : C.ln }, g); T(g, 46, y + rh / 2 + 4, m, { fs: 11, a: 'middle', w: on ? 650 : 500, c: on ? BK.ramp(3).ink : C.fg }); draw(g, r, true, 150, y + rh / 2, BK.ramp(10)); draw(g, r, false, 280, y + rh / 2, BK.ramp(10)); });
      $('info').innerHTML = `<b>${MDR[sel]}</b> — একবীজপত্রী: ${D[sel][0]}; দ্বিবীজপত্রী: ${D[sel][1]}।`;
    };
    root.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g && g.closest('svg')) { sel = +g.dataset.i; base(); } });
    const A = X.anim(root, dt => { tt += dt; const n = Math.floor(tt / 2) % 5; if (n !== sel) { sel = n; base(); } }, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

V.cmpPoaMal = Object.assign({ t: 'Poaceae ও Malvaceae গোত্রের পার্থক্য', k: ['compare', 'int', 'game'], cap: 'একবীজপত্রী ঘাস গোত্র বনাম দ্বিবীজপত্রী জবা গোত্র। "কোনটি?" মোডে বৈশিষ্ট্য দেখে গোত্র চেনো।' }, BK.compare({
  a: 'Poaceae (ধান)', b: 'Malvaceae (জবা)',
  rows: [
    ['বীজপত্র', 'একবীজপত্রী', 'দ্বিবীজপত্রী'],
    ['মূল', 'গুচ্ছমূল', 'প্রধান মূল'],
    ['কাণ্ড', 'কালম — নিরেট পর্ব, ফাঁপা পর্বমধ্য', 'নিরেট, প্রায়ই তারকা রোম ও মিউসিলেজযুক্ত'],
    ['পাতা', 'একান্তর দ্বিসারি; পত্রখোল, লিগিউল; সমান্তরাল শিরা', 'একান্তর, সরল, উপপত্রযুক্ত; জালিকা (করতলাকার) শিরা'],
    ['পুষ্পবিন্যাস', 'স্পাইকলেট — প্যানিকল বা স্পাইকে', 'সাধারণত কাক্ষিক একক ফুল'],
    ['পুষ্পপুট', 'লডিকুল (2–3) — বৃতি-দল আলাদা নেই', 'উপবৃতি, বৃতি (5, যুক্ত) ও দল (5, পাকানো)'],
    ['পুংস্তবক', '3 বা 6, বিযুক্ত; দোদুল্যমান পরাগধানী', 'অসংখ্য, একগুচ্ছ (নল); বৃক্কাকার এক-প্রকোষ্ঠী পরাগধানী'],
    ['স্ত্রীস্তবক', 'একপ্রকোষ্ঠী, একটি ডিম্বক, 2টি পালকসদৃশ গর্ভমুণ্ড', '5 প্রকোষ্ঠী (সাধারণত), অক্ষীয় অমরা, 5টি গর্ভমুণ্ড'],
    ['পরাগায়ন', 'বায়ুপরাগী', 'পতঙ্গপরাগী'],
    ['ফল', 'ক্যারিওপসিস', 'ক্যাপসুল বা খণ্ডফল'],
    ['উদাহরণ', 'ধান, গম, ভুট্টা, আখ, বাঁশ', 'জবা, তুলা, ঢেঁড়স, মেস্তা']
  ]
}));

V.cmpMonoDi = Object.assign({ t: 'একবীজপত্রী ও দ্বিবীজপত্রী উদ্ভিদের পার্থক্য', k: ['compare', 'int', 'game'], cap: 'বাহ্যিক ও অন্তর্গঠনগত পার্থক্য। "কোনটি?" মোডে নিজেকে যাচাই করো।' }, BK.compare({
  a: 'একবীজপত্রী', b: 'দ্বিবীজপত্রী',
  rows: [
    ['বীজপত্র', 'একটি', 'দুটি'],
    ['মূলতন্ত্র', 'গুচ্ছমূল', 'প্রধান মূল'],
    ['শিরাবিন্যাস', 'সমান্তরাল', 'জালিকা'],
    ['পত্রমূল', 'প্রায়ই খোলের মতো কাণ্ড ঘিরে', 'সাধারণত খোলহীন, অনেকে উপপত্রযুক্ত'],
    ['ফুলের অংশ', '3 বা 3 এর গুণিতক', '4 বা 5 বা তাদের গুণিতক'],
    ['পুষ্পপুট', 'প্রায়ই বৃতি-দল অভিন্ন (পুষ্পপুট)', 'সাধারণত বৃতি ও দল আলাদা'],
    ['কাণ্ডের বান্ডল', 'ভিত্তিকলায় ছড়ানো, বদ্ধ', 'বলয়ে সাজানো, উন্মুক্ত'],
    ['গৌণ বৃদ্ধি', 'সাধারণত নেই', 'সাধারণত আছে'],
    ['মূলের জাইলেম', 'বহু (পলিআর্ক)', 'কম (2–6, সাধারণত)'],
    ['পরাগরেণু', 'এক ছিদ্রযুক্ত (মনোকলপেট)', 'তিন ছিদ্রযুক্ত (ট্রাইকলপেট) — ইউডিকটে'],
    ['উদাহরণ', 'ধান, ঘাস, কলা, পেঁয়াজ, নারিকেল', 'জবা, আম, সরিষা, মটর']
  ]
}));

V.poaEcon = Object.assign({ t: 'Poaceae গোত্রের অর্থনৈতিক গুরুত্ব', k: ['mind', 'int'], cap: 'পৃথিবীর মানুষের খাদ্যশক্তির বড় অংশ আসে এই গোত্র থেকে। শাখায় চাপ দাও।' }, BK.mind({
  t: 'Poaceae', d: 'প্রায় 12 হাজার প্রজাতি — অর্থনৈতিকভাবে সবচেয়ে গুরুত্বপূর্ণ গোত্র।',
  c: [
    { t: 'দানাশস্য', d: 'প্রধান খাদ্য।', c: [{ t: 'ধান', d: 'Oryza sativa — বাংলাদেশের প্রধান খাদ্য; আউশ, আমন, বোরো মৌসুম।' }, { t: 'গম ও ভুট্টা', d: 'Triticum aestivum (রুটি), Zea mays (খাদ্য, পশুখাদ্য, তেল)।' }, { t: 'অন্যান্য', d: 'যব, জোয়ার, বাজরা, কাউন, চীনা।' }] },
    { t: 'চিনি ও শিল্প', d: 'আখ।', c: [{ t: 'আখ', d: 'Saccharum officinarum — চিনি, গুড়; ছোবড়া থেকে কাগজ ও জ্বালানি; চিটাগুড় থেকে অ্যালকোহল।' }] },
    { t: 'নির্মাণ ও কুটির শিল্প', d: 'বাঁশ।', c: [{ t: 'বাঁশ', d: 'Bambusa — ঘর, আসবাব, ঝুড়ি, কাগজের মণ্ড; সবচেয়ে দ্রুত বর্ধনশীল উদ্ভিদের একটি।' }, { t: 'ছন ও খড়', d: 'ঘরের ছাউনি, মাদুর, জ্বালানি।' }] },
    { t: 'পশুখাদ্য ও পরিবেশ', d: 'ঘাসভূমি।', c: [{ t: 'পশুখাদ্য', d: 'দূর্বা, নেপিয়ার ঘাস, খড়।' }, { t: 'মাটি সংরক্ষণ', d: 'গুচ্ছমূল মাটি আঁকড়ে ভূমিক্ষয় রোধ করে — বাঁধে বিন্না ঘাস।' }] },
    { t: 'সুগন্ধি ও ওষুধ', d: 'তেল।', c: [{ t: 'উদাহরণ', d: 'লেমনগ্রাস (Cymbopogon) — সুগন্ধি তেল; বিন্না (Vetiveria) মূলের তেল।' }] }
  ]
}));

V.malEcon = Object.assign({ t: 'Malvaceae গোত্রের অর্থনৈতিক গুরুত্ব', k: ['mind', 'int'], cap: 'তন্তু, সবজি ও শোভা — আধুনিক বৃহৎ Malvaceae তে পাট, শিমুল ও কোকোও অন্তর্ভুক্ত। শাখায় চাপ দাও।' }, BK.mind({
  t: 'Malvaceae', d: 'জবা গোত্র — আঁশ, খাদ্য ও শোভা।',
  c: [
    { t: 'তন্তু', d: 'বস্ত্রশিল্প।', c: [{ t: 'তুলা', d: 'Gossypium — বীজের রোম থেকে সুতা; বীজ থেকে তেল ও খৈল।' }, { t: 'মেস্তা ও কেনাফ', d: 'Hibiscus sabdariffa ও H. cannabinus — পাটের মতো আঁশ।' }, { t: 'পাট (বৃহৎ Malvaceae)', d: 'Corchorus capsularis ও C. olitorius — বাংলাদেশের সোনালি আঁশ; APG পদ্ধতিতে Malvaceae তে।' }] },
    { t: 'খাদ্য', d: 'সবজি ও পানীয়।', c: [{ t: 'ঢেঁড়স', d: 'Abelmoschus esculentus — সবজি; মিউসিলেজসমৃদ্ধ।' }, { t: 'মেস্তা বা চুকাই', d: 'H. sabdariffa — টক বৃতি দিয়ে আচার, জেলি, শরবত।' }, { t: 'কোকো (বৃহৎ Malvaceae)', d: 'Theobroma cacao — চকলেট।' }] },
    { t: 'শোভা', d: 'বাগান।', c: [{ t: 'উদাহরণ', d: 'জবা (নানা রঙের), স্থলপদ্ম (H. mutabilis), বনকাপাস।' }] },
    { t: 'অন্যান্য', d: 'কাঠ, তুলা ও ওষুধ।', c: [{ t: 'শিমুল (বৃহৎ Malvaceae)', d: 'Bombax ceiba — ফলের তুলা বালিশে; হালকা কাঠ দিয়াশলাইয়ে।' }, { t: 'ঔষধি', d: 'জবা ফুল ও পাতা চুলের যত্নে প্রচলিত; বেড়েলা (Sida) লোকজ ওষুধে।' }] }
  ]
}));

/* ───────── ব্যবহারিক ───────── */
V.malvaPractical = Object.assign({
  t: 'ব্যবহারিক: Malvaceae গোত্র শনাক্তকরণের ধাপ', k: ['2d', 'anim', 'int'],
  cap: 'নমুনা (জবা) দেখে স্বভাব থেকে স্ত্রীস্তবক পর্যন্ত বৈশিষ্ট্য লিখে পুষ্প সংকেত ও পুষ্প প্রতীক তৈরি করে গোত্র শনাক্ত করার ধাপ।'
}, BK.steps({
  W: 360, H: 240, label: 'Malvaceae শনাক্তকরণ', dur: 3,
  stages: [
    { t: 'স্বভাব ও পাতা', en: 'Habit & leaf', d: 'গুল্ম; পাতা সরল, একান্তর, উপপত্রযুক্ত, করতলাকার জালিকা শিরা, কিনারা করাতের মতো; হ্যান্ড লেন্সে তারকা রোম; কচি অংশ ভাঙলে পিচ্ছিল মিউসিলেজ।' },
    { t: 'উপবৃতি ও বৃতি', en: 'Epicalyx & calyx', d: 'বৃতির নিচে 5–8টি সরু উপবৃতি (Epi5–8); বৃতি 5টি, যুক্ত, ভালভেট — K(5)।' },
    { t: 'দলমণ্ডল', en: 'Corolla', d: 'পাপড়ি 5টি, বিযুক্ত, কুঁড়িতে পাকানো (টুইস্টেড), গোড়ায় পুংকেশরীয় নলে লগ্ন — C5।' },
    { t: 'পুংস্তবক', en: 'Androecium', d: 'অসংখ্য পুংকেশর, পুংদণ্ড যুক্ত হয়ে নল — একগুচ্ছ; পরাগধানী বৃক্কাকার, এক প্রকোষ্ঠী — A(∞)।' },
    { t: 'স্ত্রীস্তবক', en: 'Gynoecium', d: 'গর্ভাশয়ের প্রস্থচ্ছেদে 5 প্রকোষ্ঠ, অক্ষীয় অমরা; গর্ভদণ্ড নলের ভেতর দিয়ে, 5টি গর্ভমুণ্ড — G(5), উচ্চ গর্ভাশয়।' },
    { t: 'সংকেত, প্রতীক ও সিদ্ধান্ত', en: 'Formula & identification', d: 'পুষ্প সংকেত ও প্রতীক এঁকে শনাক্তকারী বৈশিষ্ট্য (উপবৃতি, একগুচ্ছ পুংকেশর, বৃক্কাকার এক-প্রকোষ্ঠী পরাগধানী, পাকানো দল, অক্ষীয় অমরা) মিলিয়ে সিদ্ধান্ত: নমুনাটি Malvaceae গোত্রের।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), Rp = BK.ramp(4), Ra = BK.ramp(6), Rg = BK.ramp(7);
    const tag = (t2, c) => T(g, 180, 228, t2, { fs: 11.5, a: 'middle', w: 650, c: c || C.fg });
    if (s === 0) { E('path', { d: 'M180 220V40', stroke: '#7a5a30', 'stroke-width': 4 }, g); [[180, 70, -1], [180, 120, 1], [180, 170, -1]].forEach(([x, y, sd]) => { E('path', { d: `M${x} ${y}q${sd * 30} -6 ${sd * 40} -24q${sd * 10} 24 ${sd * -40} 24`, fill: R.c, stroke: R.dk }, g); for (let i = 0; i < 5; i++) E('path', { d: `M${x + sd * (12 + i * 6)} ${y - 6 - i * 3}l${sd * 3} -3`, stroke: R.dk, 'stroke-width': .8 }, g); E('path', { d: `M${x} ${y}l${sd * -6} -6`, stroke: R.dk, 'stroke-width': 1.4 }, g); }); const lx = 120 + 120 * u; E('circle', { cx: lx, cy: 110, r: 26, fill: FK.alpha(BK.ramp(5).lt, .4), stroke: '#555', 'stroke-width': 3 }, g); for (let j = 0; j < 6; j++) { const a = j * 1.047; E('path', { d: `M${lx} 110l${(9 * Math.cos(a)).toFixed(1)} ${(9 * Math.sin(a)).toFixed(1)}`, stroke: '#fff', 'stroke-width': 1.4 }, g); } tag('সরল পাতা, উপপত্র, তারকা রোম', R.ink); }
    if (s === 1) { const k = Math.min(1, u * 1.4); for (let i = 0; i < 7; i++) { const a = Math.PI / 2 + (i - 3) * .28; E('path', { d: `M180 170l${(60 * Math.cos(a + Math.PI) * k).toFixed(1)} ${(-30 * k - 6 * Math.abs(i - 3)).toFixed(1)}`, stroke: R.c, 'stroke-width': 4, 'stroke-linecap': 'round' }, g); } E('path', { d: 'M150 120L158 170H202L210 120L198 134L188 110L180 134L172 110L162 134Z', fill: R.c, stroke: R.dk, opacity: k }, g); tag('উপবৃতি 5–8 · বৃতি (5) যুক্ত', R.ink); }
    if (s === 2) { for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566 + u * .3; let d = ''; for (let q = 0; q <= 16; q++) { const f = q / 16, aa = a - .8 + 1.6 * f, r = 60 + 16 * f; d += (q ? 'L' : 'M') + (180 + r * Math.cos(aa)).toFixed(1) + ' ' + (110 + r * Math.sin(aa)).toFixed(1); } E('path', { d, stroke: Rp.c, 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round' }, g); } E('circle', { cx: 180, cy: 110, r: 8, fill: Ra.c }, g); tag('পাপড়ি 5 — পাকানো বিন্যাস (কুঁড়ির প্রস্থচ্ছেদ)', Rp.ink); }
    if (s === 3) { E('path', { d: 'M176 210L177 40H183L184 210Z', fill: '#f6d0d8', stroke: Rp.dk }, g); const n = Math.floor(4 + 14 * u); for (let i = 0; i < n; i++) { const y = 130 - i * 5, sd = i % 2 ? 1 : -1, x = 180 + sd * 10; E('path', { d: `M${x - 3.5} ${y}a3.5 3.5 0 1 0 7 0q-3.5 2.4 -7 0z`, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .6 }, g); } T(g, 260, 80, 'বৃক্কাকার, এক প্রকোষ্ঠ', { fs: 11, a: 'middle', w: 600, c: Ra.ink }); tag('একগুচ্ছ পুংকেশর — পুংকেশরীয় নল', Ra.ink); }
    if (s === 4) { E('circle', { cx: 180, cy: 110, r: 70, fill: FK.alpha(Rg.lt, .85), stroke: Rg.dk, 'stroke-width': 3 }, g); const k = Math.min(1, u * 1.4); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 1.2566; E('path', { d: `M180 110L${(180 + 70 * k * Math.cos(a)).toFixed(1)} ${(110 + 70 * k * Math.sin(a)).toFixed(1)}`, stroke: Rg.dk, 'stroke-width': 2.4 }, g); if (k > .8) E('ellipse', { cx: (180 + 34 * Math.cos(a + .63)).toFixed(1), cy: (110 + 34 * Math.sin(a + .63)).toFixed(1), rx: 6, ry: 8, fill: BK.ramp(2).c }, g); } tag('5 প্রকোষ্ঠ · অক্ষীয় অমরা · উচ্চ গর্ভাশয়', Rg.ink); }
    if (s === 5) { const toks = [['Br', ''], ['Brl', ''], ['act', 's'], ['bi', 's'], ['Epi', '5–8'], ['K', '(5)'], ['C', '5'], ['A', '(∞)'], ['G', '(5)']]; let x = 20; const k = Math.ceil(toks.length * Math.min(1, u * 1.3)); toks.slice(0, k).forEach(([a, b]) => { if (b === 's') { B7.sym(g, a, x + 10, 98, 12, C.fg); x += 24; } else { T(g, x, 104, a, { fs: 18, w: 650, c: C.fg }); if (b) T(g, x + a.length * 11, 111, b, { fs: 11, w: 600, c: C.fg }); if (a === 'G') E('path', { d: `M${x} 114h34`, stroke: C.fg, 'stroke-width': 1.6 }, g); x += a.length * 11.5 + b.length * 7 + 10; } }); if (u > .75) T(g, 180, 160, 'সিদ্ধান্ত: Malvaceae', { fs: 16, a: 'middle', w: 650, c: C.ok }); tag('পুষ্প সংকেত ও প্রতীক → গোত্র শনাক্ত', C.fg); }
  }
}));

V.b1c7map = Object.assign({ t: 'অধ্যায় ৭ এর মানচিত্র', k: ['mind', 'int'], cap: 'নগ্নবীজী, আবৃতবীজী, গোত্র পরিচিতির পরিভাষা এবং Poaceae ও Malvaceae — এক নজরে। শাখায় চাপ দিলে পাঠে যাওয়ার বোতাম।' }, BK.mind({
  t: 'নগ্নবীজী ও আবৃতবীজী', d: 'বীজ উদ্ভিদ — সপুষ্পক উদ্ভিদ।',
  c: [
    { t: 'নগ্নবীজী', d: 'বীজ খোলা, ফল নেই।', id: 'b1c7s1a', c: [{ t: 'সর্বোচ্চ বৃক্ষ', d: 'Sequoia sempervirens — 116 m।', id: 'b1c7s1b' }, { t: 'বৈশিষ্ট্য', d: 'নগ্ন ডিম্বক, সস্য n, ভেসেল নেই।', id: 'b1c7s1c' }, { t: 'Cycas', d: 'কোরালয়েড মূল, বৃহৎরেণুপত্র, সাঁতারু শুক্রাণু।', id: 'b1c7s1d' }] },
    { t: 'আবৃতবীজী', d: 'ফুল ও ফল; দ্বিনিষেক।', id: 'b1c7s2a', c: [{ t: 'পার্থক্য', d: 'নগ্নবীজী বনাম আবৃতবীজী।', id: 'b1c7s2b' }, { t: 'গুরুত্ব', d: 'খাদ্য, বস্ত্র, কাঠ, ওষুধ।', id: 'b1c7s2c' }] },
    { t: 'পরিভাষা', d: 'গোত্র শনাক্তকরণের ভাষা।', id: 'b1c7s3a', c: [{ t: 'অঙ্গসংস্থান', d: 'স্বভাব, মূল, কাণ্ড, পাতা।', id: 'b1c7s3b' }, { t: 'পুষ্পবিন্যাস ও ফুল', d: 'রেসিম থেকে সাইম; গর্ভাশয়ের অবস্থান।', id: 'b1c7s3f' }, { t: 'বিন্যাস', d: 'পুষ্পপত্রবিন্যাস, অমরাবিন্যাস।', id: 'b1c7s3h' }, { t: 'ফল ও সংকেত', d: 'ফলের ধরন, পুষ্প সংকেত ও প্রতীক।', id: 'b1c7s3j' }] },
    { t: 'দুই গোত্র', d: 'Poaceae ও Malvaceae।', id: 'b1c7s4a', c: [{ t: 'Poaceae', d: 'কালম, লিগিউল, স্পাইকলেট, লডিকুল, ক্যারিওপসিস।', id: 'b1c7s4b' }, { t: 'Malvaceae', d: 'উপবৃতি, একগুচ্ছ পুংকেশর, বৃক্কাকার পরাগধানী।', id: 'b1c7s4f' }, { t: 'ব্যবহারিক', d: 'Malvaceae শনাক্তকরণ।', id: 'b1c7s4k' }] }
  ]
}));
})();
