/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §৭.৩ গোত্র পরিচিতির পরিভাষা
   habitTypes  : স্বভাব (গ্রিড)            rootTypes   : মূলের ধরন ও রূপান্তর (গ্রিড)
   stemTypes   : কাণ্ডের ধরন ও রূপান্তর (গ্রিড)   leafParts : পাতার অংশ (চিহ্নিত চিত্র)
   leafTypes   : সরল-যৌগিক পাতা ও শিরাবিন্যাস (গ্রিড)   phyllotaxy : পত্রবিন্যাস (ঘূর্ণায়মান কাণ্ড)
   inflor      : পুষ্পবিন্যাস — অনিয়ত বনাম নিয়ত, ফোটার ক্রম অ্যানিমেশন (গ্রিড)
   flowerTerms : গর্ভাশয়ের অবস্থান ও প্রতিসাম্য (ধরন বদলানো)
   aestivation : পুষ্পপত্রবিন্যাস (ধরন বদলানো)   placentation : অমরাবিন্যাস (ধরন বদলানো)
   fruitTypes  : ফলের শ্রেণিবিভাগ — গাছ         floralSymbols : পুষ্প সংকেতের চিহ্ন (চাপ দিলে অর্থ)
   floralFormula : পুষ্প সংকেত — ধাপে ধাপে পড়া (জবা, ধান, সরিষা, মটর)
   চিহ্ন নোট: অরীয়-প্রতিসম, উভলিঙ্গ, পুং ও স্ত্রী এর ইউনিকোড অক্ষর Android এ নির্ভরযোগ্য নয় — সব চিহ্ন B7.sym দিয়ে SVG তে আঁকা।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B7 = window.B7;

/* পুষ্প সংকেতের চিহ্ন আঁকা: act অরীয়, zyg একপ্রতিসম, bi উভলিঙ্গ, male পুং, female স্ত্রী */
B7.sym = (g, k, x, y, s, col) => {
  const sw = 1.6 * s / 10;
  if (k === 'act') { E('circle', { cx: x, cy: y, r: 6 * s / 10, fill: 'none', stroke: col, 'stroke-width': sw }, g); E('path', { d: `M${x} ${y - 8 * s / 10}v${16 * s / 10}M${x - 8 * s / 10} ${y}h${16 * s / 10}`, stroke: col, 'stroke-width': sw }, g); }
  if (k === 'zyg') T(g, x, y + 5 * s / 10, '%', { fs: 15 * s / 10, a: 'middle', w: 650, c: col });
  if (k === 'male' || k === 'bi') { E('circle', { cx: x - 2 * s / 10, cy: y + 2 * s / 10, r: 4.6 * s / 10, fill: 'none', stroke: col, 'stroke-width': sw }, g); E('path', { d: `M${x + 1.4 * s / 10} ${y - 1.4 * s / 10}l${5 * s / 10} ${-5 * s / 10}m${-3.4 * s / 10} 0h${3.4 * s / 10}v${3.4 * s / 10}`, stroke: col, 'stroke-width': sw, fill: 'none' }, g); }
  if (k === 'female' || k === 'bi') { const cx = k === 'bi' ? x - 2 * s / 10 : x, cy = k === 'bi' ? y + 2 * s / 10 : y - 3 * s / 10; if (k === 'female') E('circle', { cx, cy, r: 4.6 * s / 10, fill: 'none', stroke: col, 'stroke-width': sw }, g); E('path', { d: `M${cx} ${cy + 4.6 * s / 10}v${6 * s / 10}M${cx - 3 * s / 10} ${cy + 8 * s / 10}h${6 * s / 10}`, stroke: col, 'stroke-width': sw }, g); }
};

/* ───────── স্বভাব ───────── */
V.habitTypes = B7.grid({
  t: 'স্বভাব বা স্বরূপ অনুযায়ী উদ্ভিদ',
  cap: 'কাণ্ডের দৃঢ়তা, উচ্চতা ও আয়ু অনুযায়ী উদ্ভিদের স্বভাব। গোত্র শনাক্তকরণে প্রথম ধাপ। ঘরে চাপ দাও।',
  cols: 3, ch: 112,
  items: [
    ['herb', 'বীরুৎ (Herb)', 'নরম, সবুজ, অকাষ্ঠল কাণ্ড; সাধারণত 1 মিটারের কম; বর্ষজীবী বা দ্বিবর্ষজীবী।', 'ধান, সরিষা, ধনিয়া'],
    ['shrub', 'গুল্ম (Shrub)', 'কাষ্ঠল, মাঝারি উচ্চতা; গোড়া থেকে অনেক শাখা — প্রধান কাণ্ড স্পষ্ট নয়।', 'জবা, গোলাপ, রঙ্গন'],
    ['tree', 'বৃক্ষ (Tree)', 'উঁচু, কাষ্ঠল, বহুবর্ষজীবী; একটি স্পষ্ট প্রধান কাণ্ড (গুঁড়ি), উপরে শাখা।', 'আম, কাঁঠাল, শিমুল'],
    ['climber', 'আরোহী লতা (Climber)', 'দুর্বল কাণ্ড আকর্ষী, কাঁটা বা পেঁচিয়ে অবলম্বন বেয়ে ওঠে।', 'লাউ, শিম, মটর'],
    ['creeper', 'শয়ান লতা (Creeper)', 'দুর্বল কাণ্ড মাটির উপর ছড়িয়ে থাকে, পর্ব থেকে মূল বের হয়।', 'থানকুনি, দূর্বা ঘাস'],
    ['aquatic', 'জলজ (Aquatic)', 'পানিতে ভাসমান বা নিমজ্জিত; বায়ুকুঠুরিযুক্ত হালকা দেহ।', 'শাপলা, কচুরিপানা, পদ্ম']
  ],
  ramp: i => [10, 7, 10, 7, 10, 5][i],
  draw(g, k, R) {
    const tr = '#7a5a30', o = E('g', {}, g);
    return (t, on) => { o.innerHTML = ''; const sw = on ? Math.sin(t * 1.5) : 0;
      if (k === 'herb') { for (let i = 0; i < 5; i++) { const x = -12 + i * 6; E('path', { d: `M${x} 30Q${x + sw * 2} 10 ${x + (i - 2) * 3 + sw * 3} ${-6 + (i % 2) * 6}`, stroke: R.c, 'stroke-width': 2, fill: 'none' }, o); } }
      if (k === 'shrub') { for (let i = 0; i < 5; i++) E('path', { d: `M0 30Q${(i - 2) * 6} 14 ${(i - 2) * 12 + sw} 0`, stroke: tr, 'stroke-width': 2, fill: 'none' }, o); E('ellipse', { cx: sw, cy: -4, rx: 30, ry: 14, fill: R.c, opacity: .9 }, o); E('circle', { cx: -14, cy: -8, r: 3, fill: BK.ramp(4).c }, o); E('circle', { cx: 10, cy: -12, r: 3, fill: BK.ramp(4).c }, o); }
      if (k === 'tree') { E('rect', { x: -4, y: 0, width: 8, height: 30, fill: tr }, o); E('circle', { cx: sw * 2, cy: -12, r: 22, fill: R.c, stroke: R.dk }, o); }
      if (k === 'climber') { E('path', { d: 'M14 30V-30', stroke: tr, 'stroke-width': 3 }, o); let d = 'M-14 30'; for (let j = 0; j < 12; j++) { const y = 30 - j * 5, x = 8 + 7 * Math.sin(j * 1.2 + (on ? t : 0)); d += `L${x.toFixed(1)} ${y}`; } E('path', { d, stroke: R.dk, 'stroke-width': 1.8, fill: 'none' }, o); [[2, 14], [4, -4], [2, -20]].forEach(([x, y]) => E('ellipse', { cx: x - 8, cy: y, rx: 8, ry: 5, fill: R.c }, o)); }
      if (k === 'creeper') { E('path', { d: 'M-34 26H34', stroke: '#8a6b3a', 'stroke-width': 2 }, o); E('path', { d: `M-30 22Q0 ${16 + sw} 30 22`, stroke: R.dk, 'stroke-width': 2, fill: 'none' }, o); [-20, 0, 20].forEach(x => { E('circle', { cx: x, cy: 14, r: 5, fill: R.c }, o); E('path', { d: `M${x} 22v8M${x} 24l-3 6M${x} 24l3 6`, stroke: '#8a6b3a', 'stroke-width': .8 }, o); }); }
      if (k === 'aquatic') { E('rect', { x: -34, y: 10, width: 68, height: 20, fill: FK.alpha(BK.ramp(5).c, .25) }, o); E('path', { d: `M-34 10Q-17 ${8 + sw} 0 10T34 10`, stroke: BK.ramp(5).c, fill: 'none' }, o); E('ellipse', { cx: -12, cy: 9, rx: 12, ry: 4, fill: R.c }, o); E('path', { d: 'M8 10V-12', stroke: R.dk, 'stroke-width': 1.6 }, o); for (let i = 0; i < 6; i++) { const a = i / 6 * 6.283 + (on ? t * .3 : 0); E('ellipse', { cx: (8 + 6 * Math.cos(a)).toFixed(1), cy: (-14 + 3 * Math.sin(a)).toFixed(1), rx: 5, ry: 3, fill: BK.ramp(8).c, opacity: .9 }, o); } }
    };
  }
});

/* ───────── মূল ───────── */
V.rootTypes = B7.grid({
  t: 'মূলের ধরন ও রূপান্তরিত মূল',
  cap: 'ভ্রূণমূল থেকে প্রধান মূল (দ্বিবীজপত্রীর বৈশিষ্ট্য); ভ্রূণমূল নষ্ট হয়ে কাণ্ডের গোড়া থেকে গুচ্ছমূল (একবীজপত্রী)। কাণ্ড, শাখা বা পাতা থেকে জন্মানো মূল অস্থানিক। বিশেষ কাজে মূল রূপান্তরিত হয়। ঘরে চাপ দাও।',
  cols: 4, ch: 108,
  items: [
    ['tap', 'প্রধান মূল', 'ভ্রূণমূল থেকে একটি মোটা প্রধান মূল ও তার শাখা — দ্বিবীজপত্রী।', 'সরিষা, জবা, আম'],
    ['fib', 'গুচ্ছমূল', 'কাণ্ডের গোড়া থেকে প্রায় সমান মোটা অনেক সরু মূল — একবীজপত্রী।', 'ধান, ঘাস, পেঁয়াজ'],
    ['tub', 'স্ফীত মূল', 'খাদ্য সঞ্চয় করে মোটা হয় — মূলা মাকু আকৃতি, গাজর শঙ্কু আকৃতি।', 'মূলা, গাজর, শালগম'],
    ['prop', 'ঠেসমূল (স্তম্ভমূল)', 'শাখা থেকে নেমে মাটিতে ঢুকে স্তম্ভের মতো ভার বহন করে।', 'বট'],
    ['stilt', 'ঠেসমূল (খুঁটিমূল)', 'কাণ্ডের নিচের পর্ব থেকে তির্যকভাবে মাটিতে ঢুকে সোজা রাখে।', 'ভুট্টা, কেয়া, আখ'],
    ['pneu', 'শ্বাসমূল', 'লবণাক্ত কাদায় উপরের দিকে খাড়া মূল — শ্বাসছিদ্র দিয়ে বায়ু নেয়।', 'সুন্দরী, গেওয়া (সুন্দরবন)'],
    ['epi', 'বায়বীয় মূল', 'পরাশ্রয়ী উদ্ভিদের ঝুলন্ত মূল — ভেলামেন কলা বাতাস থেকে আর্দ্রতা শোষে।', 'রাস্না (অর্কিড)'],
    ['clim', 'আরোহী মূল', 'পর্ব থেকে বের হয়ে অবলম্বন আঁকড়ে ধরে উপরে উঠতে সাহায্য করে।', 'পান, মানিপ্ল্যান্ট']
  ],
  ramp: i => [6, 6, 4, 6, 7, 10, 3, 10][i],
  draw(g, k, R) {
    const soil = '#8a6b3a', tr = '#7a5a30', o = E('g', {}, g);
    const ground = (y = 0) => E('path', { d: `M-34 ${y}H34`, stroke: soil, 'stroke-width': 1.6 }, o);
    return (t, on) => { o.innerHTML = ''; const gr = on ? Math.min(1, (t * .4) % 1.4) : 1;
      if (k === 'tap') { ground(-6); E('path', { d: `M0 -24V-6`, stroke: BK.ramp(10).c, 'stroke-width': 2 }, o); E('path', { d: `M0 -6V${-6 + 36 * gr}`, stroke: R.dk, 'stroke-width': 3.4, 'stroke-linecap': 'round' }, o); [6, 14, 22].forEach((y, i) => { if (gr * 36 > y) [-1, 1].forEach(s => E('path', { d: `M0 ${y - 6}l${s * (14 - i * 3)} ${6 + i}`, stroke: R.dk, 'stroke-width': 1.2 }, o)); }); }
      if (k === 'fib') { ground(-6); E('path', { d: 'M0 -26V-6', stroke: BK.ramp(10).c, 'stroke-width': 2 }, o); for (let i = 0; i < 9; i++) { const a = Math.PI / 2 + (i - 4) * .22; E('path', { d: `M0 -6Q${(10 * Math.cos(a)).toFixed(1)} ${(10).toFixed(1)} ${(30 * gr * Math.cos(a)).toFixed(1)} ${(-6 + 32 * gr * Math.sin(a)).toFixed(1)}`, stroke: R.dk, 'stroke-width': 1.2, fill: 'none' }, o); } }
      if (k === 'tub') { ground(-8); for (let i = 0; i < 4; i++) E('path', { d: `M0 -8l${(i - 1.5) * 6} -20`, stroke: BK.ramp(10).c, 'stroke-width': 2.4 }, o); const w = 8 + 3 * gr; E('path', { d: `M${-w} -8Q${-w} 14 0 34Q${w} 14 ${w} -8Z`, fill: R.c, stroke: R.dk }, o); }
      if (k === 'prop') { ground(26); E('rect', { x: -4, y: -30, width: 8, height: 56, fill: tr }, o); E('path', { d: 'M0 -20H-30M0 -14H28', stroke: tr, 'stroke-width': 3 }, o); [-24, 22].forEach(x => E('path', { d: `M${x} ${x < 0 ? -20 : -14}V${-18 + 44 * gr}`, stroke: R.dk, 'stroke-width': 3 }, o)); }
      if (k === 'stilt') { ground(24); E('path', { d: 'M0 24V-30', stroke: BK.ramp(10).c, 'stroke-width': 4 }, o); [-1, 1].forEach(s => [0, 1].forEach(j => E('path', { d: `M0 ${4 + j * 7}l${s * (12 + j * 6) * gr} ${20 * gr}`, stroke: R.dk, 'stroke-width': 2 }, o))); }
      if (k === 'pneu') { E('rect', { x: -34, y: 6, width: 68, height: 24, fill: FK.alpha('#6a5a3a', .3) }, o); E('rect', { x: -6, y: -30, width: 8, height: 40, fill: tr }, o); E('path', { d: 'M-2 20H-30M-2 20H30', stroke: tr, 'stroke-width': 2 }, o); [-24, -14, 10, 20].forEach(x => { E('path', { d: `M${x} 20V${20 - 20 * gr}`, stroke: R.dk, 'stroke-width': 2.4 }, o); E('circle', { cx: x, cy: 20 - 20 * gr, r: 1.2, fill: '#fff' }, o); }); }
      if (k === 'epi') { E('path', { d: 'M-34 -24H34', stroke: tr, 'stroke-width': 5 }, o); E('ellipse', { cx: 0, cy: -30, rx: 10, ry: 5, fill: BK.ramp(10).c }, o); [-8, 0, 8].forEach((x, i) => E('path', { d: `M${x} -22Q${x + (on ? 4 * Math.sin(t + i) : 0)} 0 ${x} ${8 + 20 * gr}`, stroke: '#c8c0b0', 'stroke-width': 3, fill: 'none' }, o)); }
      if (k === 'clim') { E('rect', { x: 8, y: -32, width: 10, height: 62, fill: tr }, o); E('path', { d: 'M0 30V-30', stroke: BK.ramp(10).dk, 'stroke-width': 2 }, o); [-18, -4, 10, 24].forEach(y => { E('path', { d: `M0 ${y}l${8 * gr} -2`, stroke: R.dk, 'stroke-width': 1.4 }, o); E('path', { d: `M0 ${y - 4}q-12 -8 -16 4q8 4 16 -4`, fill: BK.ramp(10).c }, o); }); }
    };
  }
});

/* ───────── কাণ্ড ───────── */
V.stemTypes = B7.grid({
  t: 'কাণ্ডের বৈশিষ্ট্য ও রূপান্তরিত কাণ্ড',
  cap: 'কাণ্ডে পর্ব (যেখান থেকে পাতা বের হয়) ও পর্বমধ্য থাকে, কাক্ষিক ও শীর্ষ মুকুল থাকে — মূলে থাকে না। মাটির নিচের রূপান্তরিত কাণ্ডও পর্ব, শল্কপত্র ও মুকুল দেখে চেনা যায়। ঘরে চাপ দাও।',
  cols: 4, ch: 108,
  items: [
    ['erect', 'খাড়া কাণ্ড', 'পর্ব ও পর্বমধ্যযুক্ত, শীর্ষ ও কাক্ষিক মুকুল; দ্বিবীজপত্রীতে সাধারণত শাখান্বিত।', 'জবা, সরিষা'],
    ['culm', 'কালম (ঘাসের কাণ্ড)', 'স্পষ্ট নিরেট পর্ব ও সাধারণত ফাঁপা পর্বমধ্য — Poaceae এর বৈশিষ্ট্য।', 'ধান, বাঁশ, গম'],
    ['rhiz', 'রাইজোম (মূলাকার কাণ্ড)', 'মাটির নিচে আনুভূমিক, পর্বে শল্কপত্র ও মুকুল, নিচে অস্থানিক মূল।', 'আদা, হলুদ'],
    ['tuber', 'কন্দ (টিউবার)', 'মাটির নিচের শাখার আগা খাদ্যে ফুলে ওঠে; "চোখ" হলো মুকুল।', 'আলু'],
    ['corm', 'গুঁড়িকন্দ (কর্ম)', 'খাড়া, চ্যাপ্টা-গোল ভূনিম্নস্থ কাণ্ড; উপরে মুকুল, পর্বে শুকনো শল্কপত্র।', 'ওল, কচু'],
    ['bulb', 'কন্দ (বাল্ব)', 'খুব ছোট চাকতির মতো কাণ্ড; চারপাশে রসালো শল্কপত্রে খাদ্য; নিচে গুচ্ছমূল।', 'পেঁয়াজ, রসুন'],
    ['runner', 'ধাবক (রানার)', 'মাটির উপর দিয়ে লম্বা পর্বমধ্যের শাখা; পর্বে মূল ও নতুন উদ্ভিদ।', 'থানকুনি, দূর্বা'],
    ['tendril', 'কাণ্ড-আকর্ষী ও কাঁটা', 'কাক্ষিক মুকুল আকর্ষী (লতা বাইতে) বা কাঁটায় (রক্ষা) রূপান্তরিত।', 'লাউ (আকর্ষী), বাগানবিলাস (কাঁটা)']
  ],
  ramp: i => [10, 7, 6, 6, 6, 8, 10, 7][i],
  draw(g, k, R) {
    const o = E('g', {}, g), soil = '#8a6b3a';
    return (t, on) => { o.innerHTML = ''; const p = on ? .5 + .5 * Math.sin(t * 2) : 0;
      if (k === 'erect') { E('path', { d: 'M0 30V-30', stroke: R.dk, 'stroke-width': 2.4 }, o); [18, 2, -14].forEach((y, i) => { E('path', { d: `M0 ${y}q${i % 2 ? -14 : 14} -6 ${i % 2 ? -20 : 20} -2`, stroke: R.c, 'stroke-width': 4, 'stroke-linecap': 'round', fill: 'none' }, o); E('circle', { cx: i % 2 ? -2 : 2, cy: y - 3, r: 1.8 + p, fill: BK.ramp(4).c }, o); }); E('circle', { cx: 0, cy: -31, r: 2.6 + p, fill: BK.ramp(4).c }, o); }
      if (k === 'culm') { for (let i = 0; i < 5; i++) { const y = 26 - i * 13; E('rect', { x: -4, y: y - 13, width: 8, height: 13, fill: FK.alpha(R.lt, .6), stroke: R.dk, 'stroke-width': .8 }, o); E('rect', { x: -5, y: y - 2, width: 10, height: 3, fill: R.dk }, o); } E('rect', { x: -1.6, y: -32, width: 3.2, height: 58, fill: FK.alpha('#fff', .8 * p) }, o); }
      if (k === 'rhiz') { E('path', { d: 'M-34 -16H34', stroke: soil, 'stroke-width': 1.4 }, o); E('path', { d: 'M-28 6Q-10 0 6 6T30 4', stroke: R.c, 'stroke-width': 9, 'stroke-linecap': 'round', fill: 'none' }, o); [-18, -4, 10, 22].forEach(x => E('path', { d: `M${x} 2v4`, stroke: R.dk, 'stroke-width': 1.2 }, o)); E('path', { d: `M20 0V${-16 - 12 * p}`, stroke: BK.ramp(10).c, 'stroke-width': 2.4 }, o); [-20, -2, 14].forEach(x => E('path', { d: `M${x} 10v10`, stroke: soil }, o)); }
      if (k === 'tuber') { E('ellipse', { cx: 0, cy: 6, rx: 22, ry: 15, fill: R.c, stroke: R.dk }, o); [[-10, 0], [6, -4], [12, 10], [-4, 14]].forEach(([x, y]) => E('path', { d: `M${x - 3} ${y}q3 -3 6 0`, stroke: R.dk, 'stroke-width': 1.2, fill: 'none' }, o)); E('path', { d: `M6 -4Q${8 + 4 * p} ${-14 - 10 * p} ${10} ${-20 - 10 * p}`, stroke: BK.ramp(10).c, 'stroke-width': 2, fill: 'none' }, o); }
      if (k === 'corm') { E('path', { d: 'M-24 4Q-24 -12 0 -14Q24 -12 24 4Q24 18 0 18Q-24 18 -24 4Z', fill: R.c, stroke: R.dk }, o); [-6, 4].forEach(y => E('path', { d: `M-22 ${y}Q0 ${y - 4} 22 ${y}`, stroke: R.dk, fill: 'none', 'stroke-width': .8 }, o)); E('path', { d: `M0 -14V${-24 - 8 * p}`, stroke: BK.ramp(10).c, 'stroke-width': 3 }, o); [-14, -4, 6, 16].forEach(x => E('path', { d: `M${x} 18v10`, stroke: soil }, o)); }
      if (k === 'bulb') { E('path', { d: 'M-16 18Q-24 -6 0 -24Q24 -6 16 18Z', fill: R.c, stroke: R.dk }, o); [8, 14].forEach(w => E('path', { d: `M${-w} 16Q${-w - 4} -4 0 ${-18 + w}`, stroke: R.dk, fill: 'none', 'stroke-width': .8 }, o)); E('rect', { x: -8, y: 16, width: 16, height: 4, fill: R.dk }, o); [-6, -2, 2, 6].forEach(x => E('path', { d: `M${x} 20v10`, stroke: soil }, o)); E('path', { d: `M0 -24V${-30 - 6 * p}`, stroke: BK.ramp(10).c, 'stroke-width': 2.4 }, o); }
      if (k === 'runner') { E('path', { d: 'M-34 18H34', stroke: soil, 'stroke-width': 1.4 }, o); E('path', { d: `M-26 14Q0 ${8 - 2 * p} 26 14`, stroke: R.dk, 'stroke-width': 2, fill: 'none' }, o); [-26, 0, 26].forEach(x => { [-1, 1].forEach(s => E('ellipse', { cx: x + s * 4, cy: 6, rx: 4, ry: 6, fill: R.c, transform: `rotate(${s * 30} ${x + s * 4} 6)` }, o)); E('path', { d: `M${x} 16v10M${x} 18l-3 8M${x} 18l3 8`, stroke: soil, 'stroke-width': .8 }, o); }); }
      if (k === 'tendril') { E('path', { d: 'M-14 30V-30', stroke: BK.ramp(10).dk, 'stroke-width': 2.4 }, o); let d = 'M-14 0'; for (let j = 0; j <= 20; j++) { const a = j * .7 + (on ? t : 0) * .4, r = 2 + j * .5; d += `L${(4 + j * .8 + r * Math.cos(a)).toFixed(1)} ${(-4 - j * .6 + r * Math.sin(a)).toFixed(1)}`; } E('path', { d, stroke: R.c, 'stroke-width': 1.4, fill: 'none' }, o); E('path', { d: 'M-14 18l12 -6', stroke: '#8a4a2a', 'stroke-width': 2 }, o); }
    };
  }
});

/* ───────── পাতার অংশ ───────── */
V.leafParts = Object.assign({
  t: 'একটি আদর্শ পাতার অংশ', k: ['2d', 'label', 'int', 'anim'],
  cap: 'পত্রমূল (অনেক সময় দুই পাশে উপপত্র), পত্রবৃন্ত ও পত্রফলক — পাতার তিন প্রধান অংশ। ফলকে মধ্যশিরা থেকে শিরা ও উপশিরার জাল (জালিকা শিরাবিন্যাস — দ্বিবীজপত্রী)। পাতার কক্ষে কাক্ষিক মুকুল থাকে — যৌগিক পাতার পত্রকের কক্ষে থাকে না।'
}, BK.diagram({
  W: 360, H: 300, label: 'পাতার অংশ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rb = BK.ramp(4);
    E('path', { d: 'M150 300V170', stroke: R.dk, 'stroke-width': 6 }, g);
    const bud = P('bud'); E('ellipse', { cx: 162, cy: 238, rx: 5, ry: 7, fill: Rb.c, stroke: Rb.dk }, bud);
    const st = P('stipule'); [-1, 1].forEach(s => E('path', { d: `M${153 + s * 4} 252q${s * 14} -4 ${s * 16} -18q${-s * 8} 6 ${-s * 14} 14z`, fill: R.lt, stroke: R.dk }, st));
    const lb = P('base'); E('path', { d: 'M150 256q10 -2 14 -10', stroke: R.dk, 'stroke-width': 6, fill: 'none', 'stroke-linecap': 'round' }, lb);
    const pt = P('petiole'); E('path', { d: 'M164 246Q190 210 210 190', stroke: R.dk, 'stroke-width': 3.6, fill: 'none' }, pt);
    const la = P('lamina'); E('path', { d: 'M210 190C200 150 210 90 300 30C320 90 300 160 210 190Z', fill: R.c, stroke: R.dk, 'stroke-width': 1.4 }, la);
    const mg = P('margin'); E('path', { d: 'M300 30C320 90 300 160 210 190', stroke: R.dk, 'stroke-width': 2.2, fill: 'none', 'stroke-dasharray': '4 2' }, mg);
    const mr = P('midrib'); E('path', { d: 'M210 190Q250 110 300 30', stroke: FK.alpha(R.lt, .95), 'stroke-width': 2.4, fill: 'none' }, mr);
    const vn = P('vein'); for (let i = 1; i < 7; i++) { const t = i / 7, x = 210 + (300 - 210) * t + (1 - t) * t * 30, y = 190 + (30 - 190) * t; [-1, 1].forEach(s => { E('path', { d: `M${x.toFixed(1)} ${y.toFixed(1)}q${s * 18} ${-s * 4 - 6} ${s * 26} ${-s * 10 - 14}`, stroke: FK.alpha(R.lt, .85), 'stroke-width': 1.2, fill: 'none' }, vn); }); }
    for (let i = 0; i < 30; i++) { const x = 225 + (i * 37) % 70, y = 60 + (i * 53) % 110; E('path', { d: `M${x} ${y}l6 4M${x + 6} ${y + 4}l-3 6`, stroke: FK.alpha(R.lt, .5), 'stroke-width': .5 }, vn); }
    const ap = P('apex'); E('circle', { cx: 300, cy: 30, r: 4, fill: R.dk }, ap);
  },
  idle(g, C, t) { const k = .5 + .5 * Math.sin(t * 1.3); E('circle', { cx: 162, cy: 238, r: 8 + 3 * k, fill: 'none', stroke: BK.ramp(4).c, opacity: .5 * k }, g); for (let i = 0; i < 4; i++) { const f = (t * .3 + i / 4) % 1; E('circle', { cx: 300 - 80 * f, cy: 30 + 150 * f, r: 1.8, fill: BK.ramp(5).c, opacity: 1 - f }, g); } },
  parts: [
    { id: 'apex', bn: 'পত্রশীর্ষ', en: 'Apex', fn: 'ফলকের আগা — সূক্ষ্মাগ্র, দীর্ঘাগ্র, গোলাগ্র ইত্যাদি; শনাক্তকরণে কাজে লাগে।', a: [300, 30], l: [300, 14] },
    { id: 'lamina', bn: 'পত্রফলক', en: 'Lamina', fn: 'চ্যাপ্টা সবুজ অংশ — সালোকসংশ্লেষণ, বাষ্পমোচন ও গ্যাস বিনিময়ের প্রধান স্থান।', a: [280, 80], l: [336, 70], an: 'middle' },
    { id: 'margin', bn: 'পত্রকিনারা', en: 'Margin', fn: 'ফলকের কিনারা — অখণ্ড, করাতের মতো (জবা), ঢেউখেলানো ইত্যাদি।', a: [305, 120], l: [336, 150], an: 'middle' },
    { id: 'midrib', bn: 'মধ্যশিরা', en: 'Midrib', fn: 'পত্রবৃন্ত থেকে আগা পর্যন্ত মাঝের মোটা শিরা — পরিবহন ও দৃঢ়তা।', a: [252, 112], l: [130, 60] },
    { id: 'vein', bn: 'শিরা ও উপশিরা', lb: 'শিরা', en: 'Veins', fn: 'মধ্যশিরা থেকে বের হওয়া শাখা — জালের মতো (জালিকা — দ্বিবীজপত্রী) বা সমান্তরাল (একবীজপত্রী)।', a: [236, 140], l: [130, 110] },
    { id: 'petiole', bn: 'পত্রবৃন্ত', en: 'Petiole', fn: 'পত্রফলক ও পত্রমূলের মাঝের বোঁটা; না থাকলে পাতাকে অবৃন্তক বলে।', a: [188, 212], l: [120, 170] },
    { id: 'bud', bn: 'কাক্ষিক মুকুল', en: 'Axillary bud', fn: 'পাতা ও কাণ্ডের মাঝের কোণে (পত্রকক্ষ) — শাখা বা ফুল তৈরি করে; সরল পাতা চেনার উপায়।', a: [166, 236], l: [250, 250], an: 'middle' },
    { id: 'base', bn: 'পত্রমূল', en: 'Leaf base', fn: 'পাতা যেখানে কাণ্ডের পর্বে যুক্ত; ঘাসে এটি চওড়া হয়ে কাণ্ড ঘিরে পত্রখোল (sheath) গঠন করে।', a: [158, 252], l: [250, 280], an: 'middle' },
    { id: 'stipule', bn: 'উপপত্র', en: 'Stipules', fn: 'পত্রমূলের দুই পাশে ছোট পাতার মতো অংশ — কচি মুকুল রক্ষা করে; উপপত্রযুক্ত পাতা (জবা) ও উপপত্রহীন পাতা।', a: [140, 244], l: [70, 260], an: 'middle' }
  ]
}));

/* ───────── পাতার ধরন ───────── */
V.leafTypes = B7.grid({
  t: 'সরল ও যৌগিক পাতা এবং শিরাবিন্যাস',
  cap: 'একটি ফলক (খণ্ডিত হলেও মধ্যশিরা পর্যন্ত নয়) = সরল পাতা; ফলক সম্পূর্ণ আলাদা পত্রকে বিভক্ত = যৌগিক পাতা। শিরাবিন্যাস জালিকা (দ্বিবীজপত্রী) বা সমান্তরাল (একবীজপত্রী)। ঘরে চাপ দাও।',
  cols: 3, ch: 112,
  items: [
    ['simple', 'সরল পাতা', 'একটি অখণ্ড ফলক; কক্ষে মুকুল।', 'জবা, আম'],
    ['pinnate', 'পক্ষল যৌগিক', 'পত্রাক্ষের দুই পাশে পত্রক — একপক্ষল (নিম), দ্বিপক্ষল (লজ্জাবতী)।', 'নিম, তেঁতুল'],
    ['palmate', 'করতলাকার যৌগিক', 'পত্রবৃন্তের মাথা থেকে হাতের আঙুলের মতো পত্রক।', 'শিমুল (5–7 পত্রক), বেল (3)'],
    ['reti', 'জালিকা শিরাবিন্যাস', 'শিরা-উপশিরা জালের মতো — দ্বিবীজপত্রী।', 'জবা, কাঁঠাল'],
    ['para', 'সমান্তরাল শিরাবিন্যাস', 'শিরাগুলো গোড়া থেকে আগা পর্যন্ত প্রায় সমান্তরাল — একবীজপত্রী।', 'ধান, বাঁশ, কলা (পার্শ্বীয় সমান্তরাল)'],
    ['grass', 'ঘাসের পাতা', 'পত্রখোল কাণ্ড ঘিরে থাকে; খোল ও ফলকের সংযোগে লিগিউল (ঝিল্লি) ও অরিকল (কানের মতো উপাঙ্গ)।', 'ধান, গম']
  ],
  ramp: () => 10,
  draw(g, k, R) {
    const o = E('g', {}, g);
    const lf = (x, y, a, L, w) => { const ex = x + L * Math.cos(a), ey = y + L * Math.sin(a), nx = -Math.sin(a) * w, ny = Math.cos(a) * w; E('path', { d: `M${x} ${y}Q${(x + ex) / 2 + nx} ${(y + ey) / 2 + ny} ${ex} ${ey}Q${(x + ex) / 2 - nx} ${(y + ey) / 2 - ny} ${x} ${y}Z`, fill: R.c, stroke: R.dk, 'stroke-width': .7 }, o); };
    return (t, on) => { o.innerHTML = ''; const sw = on ? .08 * Math.sin(t * 1.6) : 0;
      if (k === 'simple') { E('path', { d: 'M0 30V12', stroke: R.dk, 'stroke-width': 2 }, o); lf(0, 12, -Math.PI / 2 + sw, 40, 14); E('path', { d: `M0 12L${(40 * Math.cos(-Math.PI / 2 + sw)).toFixed(1)} ${(12 + 40 * Math.sin(-Math.PI / 2 + sw)).toFixed(1)}`, stroke: R.lt, 'stroke-width': 1 }, o); }
      if (k === 'pinnate') { E('path', { d: 'M0 30V-30', stroke: R.dk, 'stroke-width': 1.6 }, o); for (let i = 0; i < 5; i++) { const y = 18 - i * 11; [-1, 1].forEach(s => lf(0, y, (s < 0 ? Math.PI + .3 : -.3) + s * sw, 14, 4)); } lf(0, -30, -Math.PI / 2, 10, 3.5); }
      if (k === 'palmate') { E('path', { d: 'M0 30V2', stroke: R.dk, 'stroke-width': 1.8 }, o); for (let i = 0; i < 5; i++) lf(0, 2, -Math.PI / 2 + (i - 2) * .55 + sw, 28 - Math.abs(i - 2) * 3, 6); }
      if (k === 'reti') { E('path', { d: 'M0 30C-26 10 -20 -24 0 -30C20 -24 26 10 0 30Z', fill: R.c, stroke: R.dk }, o); E('path', { d: 'M0 30V-30', stroke: R.lt, 'stroke-width': 1.2 }, o); for (let i = 0; i < 4; i++) [-1, 1].forEach(s => E('path', { d: `M0 ${18 - i * 12}q${s * 8} -4 ${s * 15} -10`, stroke: R.lt, 'stroke-width': .9, fill: 'none' }, o)); for (let i = 0; i < 10; i++) E('path', { d: `M${-12 + (i % 5) * 6} ${-12 + Math.floor(i / 5) * 16}l4 4`, stroke: R.lt, 'stroke-width': .5 }, o); }
      if (k === 'para') { E('path', { d: 'M-6 30C-12 0 -6 -20 0 -32C6 -20 12 0 6 30Z', fill: R.c, stroke: R.dk }, o); [-4, -2, 0, 2, 4].forEach(x => E('path', { d: `M${x} 30Q${x * 1.6} 0 0 -32`, stroke: R.lt, 'stroke-width': .8, fill: 'none' }, o)); }
      if (k === 'grass') { E('rect', { x: -3, y: -10, width: 6, height: 40, fill: R.dk }, o); E('path', { d: 'M-6 30V0Q0 -4 6 0V30Z', fill: FK.alpha(R.lt, .8), stroke: R.dk }, o); E('path', { d: `M4 -2Q20 ${-14 + sw * 30} 34 ${-30 + sw * 40}`, stroke: R.c, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, o); E('path', { d: 'M-4 -2l3 -6h4l3 6', fill: '#fff', stroke: R.dk, 'stroke-width': .7 }, o); E('path', { d: 'M-6 0q-5 -2 -4 -6M6 0q5 -2 4 -6', stroke: R.dk, fill: 'none' }, o); }
    };
  }
});

/* ───────── পত্রবিন্যাস ───────── */
const PX = {
  alt: ['একান্তর', 'প্রতি পর্বে একটি পাতা — পরপর পর্বে পাতা ভিন্ন দিকে (সর্পিল); ঘাসে দুই সারিতে (দ্বিসারি)।', 'জবা, আম; ধান (দ্বিসারি)', 1, 2.4],
  opp: ['প্রতিমুখ', 'প্রতি পর্বে দুটি পাতা মুখোমুখি; পরপর জোড়া সমকোণে থাকলে ক্রসমুখী (decussate)।', 'আকন্দ, তুলসী (ক্রসমুখী), পেয়ারা', 2, Math.PI / 2],
  whorl: ['আবর্ত', 'প্রতি পর্বে তিন বা ততোধিক পাতা চক্রাকারে।', 'ছাতিম, করবী', 4, Math.PI / 4]
};
V.phyllotaxy = {
  t: 'পত্রবিন্যাস — কাণ্ডে পাতা সাজানোর নিয়ম', k: ['2d', 'anim', 'int'],
  cap: 'পর্বে পাতার সংখ্যা ও সাজানোর ধরন। চালু করলে কাণ্ড ঘোরে — দেখো পাতাগুলো কীভাবে একে অপরকে কম ঢেকে আলো পায়।',
  html: () => `<div class="fk-row">${X.seg('px', Object.keys(PX).map(k => [k, PX[k][0]]), 'alt')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 240;
    let ty = 'alt', C, svg, lay, rot = .4;
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পত্রবিন্যাস' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); lay = E('g', {}, svg); const p = PX[ty]; $('info').innerHTML = `<b>${p[0]}</b> — ${p[1]}<div class="small">উদাহরণ: ${p[2]}</div>`; paint(); };
    const paint = () => {
      lay.innerHTML = ''; const R = BK.ramp(10), p = PX[ty], n = p[3], step = p[4], cx = 120;
      E('rect', { x: cx - 4, y: 20, width: 8, height: 210, fill: R.dk }, lay);
      const items = [];
      for (let j = 0; j < 6; j++) { const y = 210 - j * 34; for (let m = 0; m < n; m++) { const a = rot + j * step + m * 2 * Math.PI / n; items.push({ y, a, z: Math.sin(a) }); } E('rect', { x: cx - 6, y: y - 2, width: 12, height: 4, fill: R.dk }, lay); }
      items.sort((p1, p2) => p1.z - p2.z).forEach(({ y, a, z }) => { const L = 46, ex = cx + L * Math.cos(a), ey = y - 10 + 10 * z * .3, w = 9 * (.5 + .5 * Math.abs(Math.cos(a)) * 0 + .5); E('path', { d: `M${cx} ${y}Q${(cx + ex) / 2} ${y - 16 - w} ${ex.toFixed(1)} ${ey.toFixed(1)}Q${(cx + ex) / 2} ${y - 4 + w * .4} ${cx} ${y}Z`, fill: FK.alpha(R.c, .55 + .45 * (z + 1) / 2), stroke: R.dk, 'stroke-width': .7 }, lay); });
      const ox = 280, oy = 120; E('circle', { cx: ox, cy: oy, r: 6, fill: R.dk }, lay);
      for (let j = 0; j < 6; j++) for (let m = 0; m < n; m++) { const a = rot + j * step + m * 2 * Math.PI / n, r = 18 + j * 9; E('path', { d: `M${ox + 8 * Math.cos(a)} ${oy + 8 * Math.sin(a)}L${(ox + r * Math.cos(a)).toFixed(1)} ${(oy + r * Math.sin(a)).toFixed(1)}`, stroke: FK.alpha(R.c, 1 - j * .12), 'stroke-width': 4, 'stroke-linecap': 'round' }, lay); }
      T(lay, ox, 222, 'উপর থেকে দৃশ্য', { fs: 11, a: 'middle', c: C.mu });
    };
    const A = X.anim(root, dt => { rot += dt * .6; paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'px', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── পুষ্পবিন্যাস ───────── */
const flower = (g, x, y, r, open, col) => { if (open <= 0) { E('circle', { cx: x, cy: y, r: r * .45, fill: BK.ramp(10).c, stroke: BK.ramp(10).dk, 'stroke-width': .5 }, g); return; } for (let i = 0; i < 5; i++) { const a = i * 1.2566; E('circle', { cx: (x + r * .55 * open * Math.cos(a)).toFixed(1), cy: (y + r * .55 * open * Math.sin(a)).toFixed(1), r: r * .45, fill: col }, g); } E('circle', { cx: x, cy: y, r: r * .35, fill: BK.ramp(6).c }, g); };
V.inflor = B7.grid({
  t: 'পুষ্পবিন্যাস — অনিয়ত ও নিয়ত',
  cap: 'অনিয়ত (রেসিমোজ): প্রধান অক্ষের আগা বাড়তেই থাকে, পুরনো ফুল নিচে বা বাইরে, নতুন ফুল উপরে বা ভেতরে — ফুল ফোটে নিচ থেকে উপরে (অগ্রোন্মুখ)। নিয়ত (সাইমোজ): অক্ষের আগা ফুলে শেষ হয়, তাই প্রথম ফুল উপরে বা মাঝে — ফুল ফোটে উপর থেকে নিচে (তলোন্মুখ)। চালু করলে ফোটার ক্রম দেখাবে।',
  cols: 4, ch: 108,
  items: [
    ['raceme', 'রেসিম', 'লম্বা অক্ষে বৃন্তযুক্ত ফুল; নিচের ফুল পুরনো।', 'সরিষা, মূলা'],
    ['spike', 'স্পাইক', 'রেসিমের মতো, কিন্তু ফুল অবৃন্তক।', 'রজনীগন্ধা, আপাং'],
    ['spikelet', 'স্পাইকলেট', 'ছোট স্পাইক; গোড়ায় দুটি তুষ (গ্লুম) — Poaceae এর একক।', 'ধান, গম'],
    ['panicle', 'প্যানিকল (যৌগিক রেসিম)', 'শাখান্বিত রেসিম — শাখায় আবার ফুল বা স্পাইকলেট।', 'ধান, আম'],
    ['umbel', 'আম্বেল (ছত্রমঞ্জরি)', 'অক্ষ খুব ছোট; সমান দৈর্ঘ্যের বৃন্তে ফুল ছাতার মতো; বাইরের ফুল পুরনো।', 'ধনিয়া, পেঁয়াজ'],
    ['corymb', 'করিম্ব', 'নিচের ফুলের বৃন্ত লম্বা, ফলে সব ফুল প্রায় একই উচ্চতায়।', 'কৃষ্ণচূড়া'],
    ['capit', 'মুণ্ডক (ক্যাপিটুলাম)', 'চ্যাপ্টা আধারে অসংখ্য অবৃন্তক পুষ্পিকা; বাইরে রশ্মি, ভেতরে চাকতি পুষ্পিকা।', 'সূর্যমুখী, গাঁদা'],
    ['cyme', 'সাইম (নিয়ত)', 'অক্ষের আগা ফুলে শেষ; নিচ থেকে শাখায় নতুন ফুল — মাঝের ফুল সবচেয়ে পুরনো।', 'জুঁই, বেলি']
  ],
  ramp: i => i === 7 ? 4 : 8,
  draw(g, k, R) {
    const o = E('g', {}, g), stem = BK.ramp(10).dk;
    return (t, on) => { o.innerHTML = ''; const ph = on ? (t * .35) % 1.3 : 1.3, op = i => Math.max(0, Math.min(1, ph * 6 - i));
      if (k === 'raceme' || k === 'spike') { E('path', { d: 'M0 32V-32', stroke: stem, 'stroke-width': 1.6 }, o); for (let i = 0; i < 6; i++) { const y = 24 - i * 10, s = i % 2 ? 1 : -1, x = k === 'raceme' ? s * 12 : s * 4; if (k === 'raceme') E('path', { d: `M0 ${y + 3}L${x} ${y}`, stroke: stem }, o); flower(o, x, y, k === 'raceme' ? 6 : 4.4, op(i), R.c); } E('circle', { cx: 0, cy: -33, r: 2, fill: BK.ramp(10).c }, o); }
      if (k === 'spikelet') { E('path', { d: 'M0 32V14', stroke: stem, 'stroke-width': 1.6 }, o); [-1, 1].forEach(s => E('path', { d: `M0 14q${s * 8} -8 ${s * 3} -20`, stroke: BK.ramp(7).dk, 'stroke-width': 1.6, fill: FK.alpha(BK.ramp(7).lt, .6) }, o)); for (let i = 0; i < 3; i++) { const y = 4 - i * 10; E('path', { d: `M0 ${y + 6}q${(i % 2 ? 7 : -7)} -6 0 -12q${(i % 2 ? -3 : 3)} 6 0 12`, fill: BK.ramp(7).c, stroke: BK.ramp(7).dk, 'stroke-width': .6, opacity: .4 + .6 * op(i * 2) }, o); } }
      if (k === 'panicle') { E('path', { d: 'M0 32V-32', stroke: stem, 'stroke-width': 1.6 }, o); for (let i = 0; i < 4; i++) { const y = 22 - i * 14, s = i % 2 ? 1 : -1; E('path', { d: `M0 ${y}l${s * 20} -8`, stroke: stem }, o); [0, 1].forEach(j => flower(o, s * (8 + j * 11), y - 3 - j * 4, 4, op(i * 1.5 + j), R.c)); } }
      if (k === 'umbel') { E('path', { d: 'M0 32V4', stroke: stem, 'stroke-width': 1.6 }, o); for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (i - 3) * .32, ex = 26 * Math.cos(a), ey = 4 + 26 * Math.sin(a); E('path', { d: `M0 4L${ex.toFixed(1)} ${ey.toFixed(1)}`, stroke: stem }, o); flower(o, ex, ey, 5, op(Math.abs(i - 3) === 3 ? 0 : Math.abs(i - 3) === 2 ? 1.5 : Math.abs(i - 3) === 1 ? 3 : 4.5), R.c); } }
      if (k === 'corymb') { E('path', { d: 'M0 32V-10', stroke: stem, 'stroke-width': 1.6 }, o); for (let i = 0; i < 5; i++) { const y = 26 - i * 8, s = i % 2 ? 1 : -1, x = s * (26 - i * 5); E('path', { d: `M0 ${y}Q${x * .6} ${y - 6} ${x} -18`, stroke: stem, fill: 'none' }, o); flower(o, x, -20, 5, op(i), R.c); } }
      if (k === 'capit') { E('path', { d: 'M0 32V8', stroke: stem, 'stroke-width': 2 }, o); E('ellipse', { cx: 0, cy: 6, rx: 20, ry: 4, fill: BK.ramp(10).c }, o); for (let i = 0; i < 12; i++) { const a = i / 12 * 6.283, f = op(0); E('ellipse', { cx: (22 * Math.cos(a) * .9).toFixed(1), cy: (-8 + 16 * Math.sin(a) * .9).toFixed(1), rx: 5 * (.4 + .6 * f), ry: 2.4, fill: BK.ramp(6).c, transform: `rotate(${(a * 57.3).toFixed(0)} ${(22 * Math.cos(a) * .9).toFixed(1)} ${(-8 + 16 * Math.sin(a) * .9).toFixed(1)})` }, o); } for (let r = 0; r < 3; r++) for (let i = 0; i < 6 + r * 4; i++) { const a = i / (6 + r * 4) * 6.283, rr = 14 - r * 5; E('circle', { cx: (rr * Math.cos(a)).toFixed(1), cy: (-8 + rr * .75 * Math.sin(a)).toFixed(1), r: 1.8, fill: op(1 + r * 1.5) > .5 ? BK.ramp(2).c : BK.ramp(10).dk }, o); } }
      if (k === 'cyme') { E('path', { d: 'M0 32V-14M0 6l-16 -10M0 6l16 -10M-16 -4l-8 -12M16 -4l8 -12', stroke: stem, 'stroke-width': 1.4, fill: 'none' }, o); flower(o, 0, -18, 6, op(0), R.c); flower(o, -16, -8, 5, op(1.5), R.c); flower(o, 16, -8, 5, op(1.5), R.c); flower(o, -24, -20, 4, op(3), R.c); flower(o, 24, -20, 4, op(3), R.c); }
      if (on) T(o, 0, 38, ph < 1.1 ? 'ফুটছে…' : '', { fs: 8, a: 'middle', c: BK.ramp(9).ink });
    };
  }
});

/* ───────── গর্ভাশয়ের অবস্থান ও প্রতিসাম্য ───────── */
const FT = {
  hypo: ['অধিগর্ভ (হাইপোগাইনাস)', 'গর্ভাশয় পুষ্পাক্ষের সবচেয়ে উপরে; বৃতি, দল ও পুংকেশর গর্ভাশয়ের নিচ থেকে — গর্ভাশয় উচ্চ (superior)।', 'জবা, সরিষা, ধান'],
  peri: ['পরিগর্ভ (পেরিগাইনাস)', 'পুষ্পাক্ষ পেয়ালার মতো, গর্ভাশয় মাঝে; অন্য স্তবক পেয়ালার কিনারায় প্রায় গর্ভাশয়ের সমান উচ্চতায় — গর্ভাশয় অর্ধ-নিম্ন।', 'গোলাপ, মটর, বরই'],
  epi: ['উপগর্ভ (এপিগাইনাস)', 'পুষ্পাক্ষ গর্ভাশয়কে ঘিরে যুক্ত; অন্য স্তবক গর্ভাশয়ের মাথা থেকে — গর্ভাশয় নিম্ন (inferior)।', 'লাউ, পেয়ারা, সূর্যমুখী'],
  act: ['অরীয় প্রতিসম (অ্যাক্টিনোমর্ফিক)', 'কেন্দ্র দিয়ে যেকোনো উল্লম্ব তলে কাটলে দুটি সমান অংশ হয় (একাধিক প্রতিসাম্য তল)।', 'জবা, ধুতুরা, সরিষা'],
  zyg: ['একপ্রতিসম (জাইগোমর্ফিক)', 'কেবল একটি তলে কাটলে দুটি সমান অংশ হয়।', 'মটর, শিম, ধান (স্পাইকলেটে)']
};
V.flowerTerms = {
  t: 'গর্ভাশয়ের অবস্থান ও ফুলের প্রতিসাম্য', k: ['2d', 'anim', 'int'],
  cap: 'স্তবকগুলো গর্ভাশয়ের তুলনায় কোথা থেকে উৎপন্ন — অধিগর্ভ, পরিগর্ভ, উপগর্ভ। আর উপর থেকে দেখে প্রতিসাম্য তল — অরীয় ও একপ্রতিসম। ধরন বদলাও; চালু করলে প্রতিসাম্য তল ঘোরে।',
  html: () => `<div class="fk-row">${X.seg('ft', Object.keys(FT).map(k => [k, FT[k][0].split(' (')[0]]), 'hypo')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 240;
    let ty = 'hypo', C, svg, fx, tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': FT[ty][0] }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rs = BK.ramp(10), Rp = BK.ramp(8), Rg = BK.ramp(7), Ra = BK.ramp(6), cx = 180;
      if (ty === 'hypo' || ty === 'peri' || ty === 'epi') {
        E('path', { d: `M${cx - 4} 236V196H${cx + 4}V236`, fill: Rs.c, stroke: Rs.dk }, svg);
        const oy = ty === 'hypo' ? 150 : ty === 'peri' ? 168 : 186, base_y = ty === 'hypo' ? 192 : ty === 'peri' ? 140 : 140;
        if (ty === 'hypo') E('path', { d: `M${cx - 30} 196Q${cx} 186 ${cx + 30} 196Q${cx} 206 ${cx - 30} 196Z`, fill: Rs.c, stroke: Rs.dk }, svg);
        if (ty === 'peri') E('path', { d: `M${cx - 60} 140Q${cx - 50} 200 ${cx} 200Q${cx + 50} 200 ${cx + 60} 140L${cx + 52} 140Q${cx + 44} 192 ${cx} 192Q${cx - 44} 192 ${cx - 52} 140Z`, fill: Rs.c, stroke: Rs.dk }, svg);
        if (ty === 'epi') E('path', { d: `M${cx - 34} 140Q${cx - 40} 200 ${cx} 202Q${cx + 40} 200 ${cx + 34} 140Z`, fill: Rs.c, stroke: Rs.dk }, svg);
        E('ellipse', { cx, cy: oy, rx: ty === 'epi' ? 26 : 20, ry: ty === 'epi' ? 30 : 24, fill: FK.alpha(Rg.lt, .9), stroke: Rg.dk, 'stroke-width': 1.6 }, svg);
        [[-6, -6], [6, -6], [-6, 8], [6, 8]].forEach(([dx, dy]) => E('ellipse', { cx: cx + dx, cy: oy + dy, rx: 3.4, ry: 5, fill: BK.ramp(2).c }, svg));
        E('path', { d: `M${cx} ${oy - (ty === 'epi' ? 30 : 24)}V60`, stroke: Rg.dk, 'stroke-width': 3 }, svg); E('ellipse', { cx, cy: 58, rx: 10, ry: 5, fill: Rg.dk }, svg);
        const ax = ty === 'peri' ? 56 : ty === 'epi' ? 32 : 26, ay = base_y - (ty === 'hypo' ? 0 : 0);
        [-1, 1].forEach(s => { E('path', { d: `M${cx + s * ax} ${ay}q${s * 40} -10 ${s * 64} -60`, stroke: Rs.dk, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, svg); E('path', { d: `M${cx + s * (ax - 4)} ${ay - 2}q${s * 50} -40 ${s * 56} -110`, stroke: Rp.c, 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round', opacity: .85 }, svg); E('path', { d: `M${cx + s * (ax - 8)} ${ay - 2}q${s * 20} -40 ${s * 22} -80`, stroke: Ra.dk, 'stroke-width': 1.6, fill: 'none' }, svg); E('ellipse', { cx: cx + s * (ax + 14), cy: ay - 86, rx: 4, ry: 8, fill: Ra.c }, svg); });
        T(svg, 300, 232, ty === 'hypo' ? 'গর্ভাশয় উচ্চ' : ty === 'peri' ? 'গর্ভাশয় অর্ধ-নিম্ন' : 'গর্ভাশয় নিম্ন', { fs: 12, a: 'middle', w: 650, c: Rg.ink });
        T(svg, 60, 232, 'বৃতি · দল · পুংকেশর', { fs: 11, a: 'middle', c: C.mu });
      } else {
        const n = 5; for (let i = 0; i < n; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / n; let rx = 34, ry = 22, ox = 46; if (ty === 'zyg') { if (i === 0) { rx = 44; ry = 32; ox = 52; } else if (i === 1 || i === 4) { rx = 30; ry = 18; ox = 44; } else { rx = 22; ry = 16; ox = 34; } } E('ellipse', { cx: (cx + ox * Math.cos(a)).toFixed(1), cy: (120 + ox * Math.sin(a)).toFixed(1), rx, ry, fill: FK.alpha(Rp.c, .8), stroke: Rp.dk, transform: `rotate(${(a * 57.3 + 90).toFixed(0)} ${(cx + ox * Math.cos(a)).toFixed(1)} ${(120 + ox * Math.sin(a)).toFixed(1)})` }, svg); }
        E('circle', { cx, cy: 120, r: 14, fill: Ra.c }, svg);
      }
      fx = E('g', {}, svg); $('info').innerHTML = `<b>${FT[ty][0]}</b> — ${FT[ty][1]}<div class="small">উদাহরণ: ${FT[ty][2]}</div>`; step(0);
    };
    const step = dt => { tt += dt; if (!fx) return; fx.innerHTML = ''; if (ty === 'act') { const a = tt * .6; E('path', { d: `M${180 - 100 * Math.cos(a)} ${120 - 100 * Math.sin(a)}L${180 + 100 * Math.cos(a)} ${120 + 100 * Math.sin(a)}`, stroke: C.acc, 'stroke-width': 2, 'stroke-dasharray': '6 4' }, fx); T(fx, 180, 232, 'যেকোনো অরীয় তলে সমান দুই ভাগ', { fs: 11, a: 'middle', c: C.acc, w: 600 }); } if (ty === 'zyg') { const ok = Math.sin(tt * .8) > 0, a = ok ? Math.PI / 2 : Math.PI / 2 + .8; E('path', { d: `M${180 - 100 * Math.cos(a)} ${120 - 100 * Math.sin(a)}L${180 + 100 * Math.cos(a)} ${120 + 100 * Math.sin(a)}`, stroke: ok ? C.ok : C.bad, 'stroke-width': 2, 'stroke-dasharray': '6 4' }, fx); T(fx, 180, 232, ok ? 'একমাত্র তলে সমান দুই ভাগ' : 'অন্য তলে অসমান', { fs: 11, a: 'middle', c: ok ? C.ok : C.bad, w: 600 }); } };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'ft', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── পুষ্পপত্রবিন্যাস ───────── */
/* প্রতিটি ধরন: পাপড়ির [বাম কিনারা উপরে?, ডান কিনারা উপরে?] — true = সেই কিনারা পাশের পাপড়ির উপরে */
const AE = {
  valv: ['ভালভেট (প্রান্তস্পর্শী)', 'পাপড়িগুলোর কিনারা কেবল পরস্পরকে ছোঁয়, কেউ কাউকে ঢাকে না।', 'আকন্দ, সজিনা (বৃতি), জবার বৃতি', 'valv'],
  twist: ['টুইস্টেড (পাকানো)', 'প্রতিটি পাপড়ির এক কিনারা পাশেরটির উপরে, অন্য কিনারা অন্য পাশেরটির নিচে — ঘূর্ণির মতো।', 'জবা (দল), তুলা, ঢেঁড়স', 'twist'],
  imb: ['ইমব্রিকেট (আচ্ছাদী)', 'একটি পাপড়ির দুই কিনারাই ভেতরে (ঢাকা), একটির দুই কিনারাই বাইরে, বাকি তিনটি টুইস্টেডের মতো।', 'কৃষ্ণচূড়া, কালকাসুন্দা', 'imb'],
  quin: ['কুইনকানশিয়াল', 'দুটি পাপড়ি সম্পূর্ণ বাইরে, দুটি সম্পূর্ণ ভেতরে, একটির এক কিনারা বাইরে ও এক কিনারা ভেতরে।', 'পেয়ারা, মিষ্টিকুমড়া', 'quin'],
  vex: ['ভেক্সিলারি (প্যাপিলিওনেসিয়াস)', 'সবচেয়ে বড় পতাকা পাপড়ি দুটি পার্শ্ব পাপড়িকে ঢাকে, পার্শ্ব পাপড়ি দুটি ভেতরের দুটি নৌকা পাপড়িকে ঢাকে।', 'মটর, শিম (Fabaceae)', 'vex']
};
/* প্রতিটি পাপড়ির [বাম প্রান্ত, ডান প্রান্ত] (ঘড়ির কাঁটার দিকে): o = পাশেরটির উপরে (বাইরে), i = নিচে (ভেতরে), v = কেবল স্পর্শ */
const AEP = { valv: [['v', 'v'], ['v', 'v'], ['v', 'v'], ['v', 'v'], ['v', 'v']], twist: [['i', 'o'], ['i', 'o'], ['i', 'o'], ['i', 'o'], ['i', 'o']], imb: [['o', 'o'], ['i', 'o'], ['i', 'o'], ['i', 'i'], ['o', 'i']], quin: [['o', 'o'], ['i', 'i'], ['o', 'o'], ['i', 'o'], ['i', 'i']], vex: [['o', 'o'], ['i', 'o'], ['i', 'i'], ['i', 'i'], ['o', 'i']] };
V.aestivation = {
  t: 'পুষ্পপত্রবিন্যাস (এস্টিভেশন)', k: ['2d', 'anim', 'int'],
  cap: 'কুঁড়ি অবস্থায় বৃত্যংশ বা পাপড়িগুলো পরস্পরের সাথে কীভাবে সাজানো — কুঁড়ির প্রস্থচ্ছেদে দেখা যায়। উপরে থাকা কিনারা গাঢ় রেখায়। চালু করলে পাপড়িগুলো একে একে উজ্জ্বল হয়ে কে কাকে ঢাকে দেখায়।',
  html: () => `<div class="fk-row">${X.seg('ae', Object.keys(AE).map(k => [k, AE[k][0].split(' (')[0]]), 'twist')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 240, cx = 180, cy = 120, Rr = 62;
    let ty = 'twist', C, svg, pg, tt = 0;
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': AE[ty][0] }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); pg = E('g', {}, svg); const a = AE[ty]; $('info').innerHTML = `<b>${a[0]}</b> — ${a[1]}<div class="small">উদাহরণ: ${a[2]}</div>`; paint(); };
    const paint = () => {
      pg.innerHTML = ''; const R = BK.ramp(8), hi = Math.floor(tt * .8) % 5, st = AEP[ty];
      E('circle', { cx, cy, r: 8, fill: BK.ramp(10).c }, pg);
      for (let i = 0; i < 5; i++) {
        const big = ty === 'vex' && i === 0, half = big ? 1.0 : .62, am = -Math.PI / 2 + i * 2 * Math.PI / 5, ext = ty === 'valv' ? 0 : .2, b0 = am - half - ext, b1 = am + half + ext, on = i === hi && tt > 0;
        const rad = e => e === 'o' ? Rr + 8 : e === 'i' ? Rr - 8 : Rr, rl = rad(st[i][0]), rr = rad(st[i][1]);
        let d = ''; for (let k = 0; k <= 24; k++) { const f = k / 24, a = b0 + (b1 - b0) * f, r = rl + (rr - rl) * f + (big ? 6 * Math.sin(f * Math.PI) : 0); d += (k ? 'L' : 'M') + (cx + r * Math.cos(a)).toFixed(1) + ' ' + (cy + r * Math.sin(a)).toFixed(1); }
        E('path', { d, stroke: on ? R.dk : FK.alpha(R.c, .85), 'stroke-width': on ? 8 : 7, fill: 'none', 'stroke-linecap': 'round' }, pg);
        const lab = ty === 'vex' ? ['পতাকা', 'পাখা', 'নৌকা', 'নৌকা', 'পাখা'][i] : String(i + 1).replace(/\d/g, x => '০১২৩৪৫৬৭৮৯'[x]);
        const lr = Rr + 30; T(pg, cx + lr * Math.cos(am), cy + lr * Math.sin(am) + 4, lab, { fs: 12, a: 'middle', w: 650, c: on ? R.ink : C.mu });
      }
      T(pg, 300, 226, ty === 'valv' ? 'কেউ কাউকে ঢাকে না' : 'বাইরের বৃত্তে থাকা প্রান্ত উপরে', { fs: 10.5, a: 'middle', c: C.mu });
    };
    const A = X.anim(root, dt => { tt += dt; paint(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'ae', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── অমরাবিন্যাস ───────── */
const PL = {
  marg: ['প্রান্তীয় (মার্জিনাল)', 'একগর্ভপত্রী একপ্রকোষ্ঠী গর্ভাশয়; ডিম্বক গর্ভপত্রের জোড়া লাগা কিনারা বরাবর এক সারিতে।', 'মটর, শিম, ছোলা'],
  axile: ['অক্ষীয় (অ্যাক্সাইল)', 'বহুগর্ভপত্রী যুক্তগর্ভপত্রী গর্ভাশয়; প্রাচীর কেন্দ্রে মিলে বহুপ্রকোষ্ঠী; ডিম্বক কেন্দ্রীয় অক্ষে।', 'জবা, টমেটো, লেবু, তুলা'],
  pari: ['বহুপ্রান্তীয় (প্যারাইটাল)', 'যুক্তগর্ভপত্রী একপ্রকোষ্ঠী গর্ভাশয়; ডিম্বক প্রাচীরের গায়ে গর্ভপত্রের সংযোগস্থলে। সরিষায় মিথ্যা প্রাচীরে দুই প্রকোষ্ঠ।', 'সরিষা, পেঁপে, শসা'],
  free: ['মুক্তমধ্য (ফ্রি সেন্ট্রাল)', 'একপ্রকোষ্ঠী গর্ভাশয়; ডিম্বক মাঝের মুক্ত অক্ষে — প্রাচীরের সাথে যুক্ত নয় (প্রাচীর নষ্ট হয়ে)।', 'ডায়ান্থাস, প্রিমুলা'],
  basal: ['ভিত্তীয় (বেসাল)', 'একপ্রকোষ্ঠী গর্ভাশয়ের তলায় একটি মাত্র ডিম্বক।', 'সূর্যমুখী, ধান ও অন্যান্য ঘাস'],
  super: ['পৃষ্ঠলগ্ন (সুপারফিশিয়াল)', 'বহুপ্রকোষ্ঠী গর্ভাশয়; ডিম্বক প্রকোষ্ঠ বিভাজক প্রাচীরের সারা গায়ে ছড়ানো।', 'শাপলা']
};
V.placentation = {
  t: 'অমরাবিন্যাস (প্লাসেন্টেশন) — গর্ভাশয়ের প্রস্থচ্ছেদ', k: ['2d', 'anim', 'int'],
  cap: 'গর্ভাশয়ের ভেতরে যে কলায় ডিম্বক যুক্ত থাকে তা অমরা; অমরার বিন্যাসই অমরাবিন্যাস। গর্ভপত্রের সংখ্যা, প্রকোষ্ঠ ও ডিম্বকের অবস্থান দেখে চেনা যায়। ধরন বদলাও; চালু করলে ডিম্বকে খাদ্য প্রবাহ (অমরা থেকে) দেখায়।',
  html: () => `<div class="fk-row">${X.seg('pl', Object.keys(PL).map(k => [k, PL[k][0].split(' (')[0]]), 'axile')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 240, cx = 180, cy = 120;
    let ty = 'axile', C, svg, fx, tt = 0, ov = [];
    const O = (x, y, a, g) => { ov.push([x, y]); E('ellipse', { cx: x, cy: y, rx: 6, ry: 8.5, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk, transform: `rotate(${(a * 57.3).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})` }, g); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; ov = []; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': PL[ty][0] }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rg = BK.ramp(7), Rp = BK.ramp(10), g = E('g', {}, svg), wall = { fill: FK.alpha(Rg.lt, .85), stroke: Rg.dk, 'stroke-width': 3 };
      if (ty === 'marg') { E('path', { d: `M${cx} ${cy - 80}C${cx + 70} ${cy - 70} ${cx + 70} ${cy + 70} ${cx} ${cy + 80}C${cx - 50} ${cy + 70} ${cx - 50} ${cy - 70} ${cx} ${cy - 80}Z`, ...wall }, g); E('path', { d: `M${cx - 36} ${cy - 50}Q${cx - 46} ${cy} ${cx - 36} ${cy + 50}`, stroke: Rp.dk, 'stroke-width': 5, fill: 'none' }, g); for (let i = 0; i < 4; i++) O(cx - 22, cy - 42 + i * 28, Math.PI / 2, g); }
      if (ty === 'axile') { E('circle', { cx, cy, r: 82, ...wall }, g); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; E('path', { d: `M${cx} ${cy}L${(cx + 82 * Math.cos(a)).toFixed(1)} ${(cy + 82 * Math.sin(a)).toFixed(1)}`, stroke: Rg.dk, 'stroke-width': 3 }, g); } E('circle', { cx, cy, r: 12, fill: Rp.c, stroke: Rp.dk }, g); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i + .5) * 2 * Math.PI / 5; [24, 50].forEach(r => O(cx + r * Math.cos(a), cy + r * Math.sin(a), a, g)); } }
      if (ty === 'pari') { E('circle', { cx, cy, r: 82, ...wall }, g); for (let i = 0; i < 3; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 3; const px = cx + 76 * Math.cos(a), py = cy + 76 * Math.sin(a); E('circle', { cx: px, cy: py, r: 10, fill: Rp.c, stroke: Rp.dk }, g); [-.25, .25].forEach(d => O(cx + 54 * Math.cos(a + d), cy + 54 * Math.sin(a + d), a + d, g)); } }
      if (ty === 'free') { E('circle', { cx, cy, r: 82, ...wall }, g); E('circle', { cx, cy, r: 22, fill: Rp.c, stroke: Rp.dk }, g); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; O(cx + 34 * Math.cos(a), cy + 34 * Math.sin(a), a, g); } }
      if (ty === 'basal') { E('path', { d: `M${cx - 70} ${cy + 70}Q${cx - 80} ${cy - 80} ${cx} ${cy - 86}Q${cx + 80} ${cy - 80} ${cx + 70} ${cy + 70}Z`, ...wall }, g); E('rect', { x: cx - 16, y: cy + 56, width: 32, height: 12, fill: Rp.c, stroke: Rp.dk }, g); E('ellipse', { cx, cy: cy + 22, rx: 22, ry: 34, fill: BK.ramp(2).c, stroke: BK.ramp(2).dk }, g); ov.push([cx, cy + 22]); T(g, cx, 230, 'লম্বচ্ছেদ', { fs: 11, a: 'middle', c: C.mu }); }
      if (ty === 'super') { E('circle', { cx, cy, r: 82, ...wall }, g); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; E('path', { d: `M${cx} ${cy}L${(cx + 82 * Math.cos(a)).toFixed(1)} ${(cy + 82 * Math.sin(a)).toFixed(1)}`, stroke: Rp.c, 'stroke-width': 6 }, g); [28, 48, 66].forEach(r => [-1, 1].forEach(s => O(cx + r * Math.cos(a) - s * 7 * Math.sin(a), cy + r * Math.sin(a) + s * 7 * Math.cos(a), a, g))); } }
      T(svg, 40, 30, 'অমরা', { fs: 11, a: 'middle', w: 650, c: Rp.ink }); E('rect', { x: 18, y: 36, width: 44, height: 6, fill: Rp.c }, svg);
      fx = E('g', {}, svg); $('info').innerHTML = `<b>${PL[ty][0]}</b> — ${PL[ty][1]}<div class="small">উদাহরণ: ${PL[ty][2]}</div>`; step(0);
    };
    const step = dt => { tt += dt; if (!fx) return; fx.innerHTML = ''; ov.forEach(([x, y], i) => { const k = (Math.sin(tt * 3 - i * .6) + 1) / 2; E('circle', { cx: x, cy: y, r: 2 + 2 * k, fill: BK.ramp(10).c, opacity: (.3 + .5 * k).toFixed(2) }, fx); }); };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'pl', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── ফল ───────── */
V.fruitTypes = Object.assign({ t: 'ফলের শ্রেণিবিভাগ', k: ['tree', 'int'], cap: 'একটি ফুলের একটি গর্ভাশয় থেকে সরল ফল, একটি ফুলের বিযুক্ত গর্ভপত্র থেকে গুচ্ছফল, পুরো পুষ্পবিন্যাস থেকে যৌগিক ফল। শাখায় চাপ দাও।' }, BK.tree({
  t: 'ফল', d: 'নিষিক্ত ও পরিণত গর্ভাশয়; ফলত্বক তিন স্তর — বহিঃত্বক, মধ্যত্বক, অন্তঃত্বক।',
  c: [
    { t: 'সরল ফল', d: 'একটি ফুলের একটি (যুক্ত) গর্ভাশয় থেকে।', c: [
      { t: 'রসালো', d: 'ফলত্বক রসালো।', c: [{ t: 'ড্রুপ (অষ্টিফল)', d: 'অন্তঃত্বক শক্ত আঁটি — আম, নারিকেল, বরই।' }, { t: 'বেরি (সরস ফল)', d: 'বহুবীজী, ভেতর রসালো — টমেটো, পেয়ারা, কলা।' }, { t: 'পেপো ও হেসপেরিডিয়াম', d: 'লাউ-কুমড়া (পেপো); কমলা-লেবু (হেসপেরিডিয়াম — রসালো রোম)।' }] },
      { t: 'শুষ্ক বিদারী', d: 'পাকলে ফেটে বীজ ছড়ায়।', c: [{ t: 'লেগিউম (শিম)', d: 'একগর্ভপত্রী, দুই সেলাইয়ে ফাটে — মটর, শিম।' }, { t: 'ক্যাপসুল', d: 'যুক্তগর্ভপত্রী, অনেক পথে ফাটে — ঢেঁড়স, তুলা, জবা (Malvaceae)।' }, { t: 'সিলিকুয়া', d: 'দুই কপাটে নিচ থেকে উপরে ফাটে, মাঝে মিথ্যা প্রাচীর — সরিষা।' }] },
      { t: 'শুষ্ক অবিদারী', d: 'ফাটে না।', c: [{ t: 'ক্যারিওপসিস', d: 'একবীজী; ফলত্বক বীজত্বকের সাথে সম্পূর্ণ যুক্ত — ধান, গম, ভুট্টা (Poaceae)।' }, { t: 'সিপসেলা ও নাট', d: 'সূর্যমুখী (সিপসেলা); কাজুবাদাম, লিচু (নাট)।' }] },
      { t: 'সাইজোকার্প (খণ্ডফল)', d: 'পাকলে একবীজী খণ্ডে ভাঙে — ধনিয়া, কিছু Malvaceae (Abutilon, Sida)।' }
    ] },
    { t: 'গুচ্ছফল', d: 'একটি ফুলের অনেক বিযুক্ত গর্ভপত্র থেকে ক্ষুদ্র ফলের গুচ্ছ — আতা, স্ট্রবেরি, আকন্দ।' },
    { t: 'যৌগিক ফল', d: 'পুরো পুষ্পবিন্যাস থেকে একটি ফল — কাঁঠাল ও আনারস (সোরোসিস), বট-ডুমুর (সাইকোনাস)।' }
  ]
}, { colW: 120 }));

/* ───────── পুষ্প সংকেতের চিহ্ন ───────── */
const SY = [
  ['Br', 'Br', 'মঞ্জরিপত্রিক (ব্র্যাক্টিয়েট) — ফুলের নিচে মঞ্জরিপত্র আছে; না থাকলে Ebr (মঞ্জরিপত্রহীন)।'],
  ['Brl', 'Brl', 'উপমঞ্জরিপত্রিক — পুষ্পবৃন্তে ছোট উপমঞ্জরিপত্র আছে।'],
  ['act', '', 'অরীয় প্রতিসম (অ্যাক্টিনোমর্ফিক) — বৃত্তের ভেতর যোগ চিহ্ন।'],
  ['zyg', '', 'একপ্রতিসম (জাইগোমর্ফিক) — শতাংশ চিহ্নের মতো।'],
  ['bi', '', 'উভলিঙ্গ (দ্বিলিঙ্গ) ফুল — পুং ও স্ত্রী চিহ্ন একসাথে।'],
  ['male', '', 'পুং ফুল (কেবল পুংস্তবক)।'],
  ['female', '', 'স্ত্রী ফুল (কেবল স্ত্রীস্তবক)।'],
  ['Epi', 'Epi', 'উপবৃতি (এপিক্যালিক্স) — বৃতির বাইরে আরেক সারি বৃতির মতো অংশ; জবায় 5–8টি।'],
  ['K', 'K', 'বৃতি (ক্যালিক্স); পাশে সংখ্যা = বৃত্যংশের সংখ্যা।'],
  ['C', 'C', 'দলমণ্ডল (করোলা); পাশে পাপড়ির সংখ্যা।'],
  ['P', 'P', 'পুষ্পপুট (পেরিয়ান্থ) — বৃতি ও দল আলাদা করা না গেলে; ঘাসে লডিকুল।'],
  ['A', 'A', 'পুংস্তবক (অ্যান্ড্রোসিয়াম); পাশে পুংকেশরের সংখ্যা।'],
  ['G', 'G', 'স্ত্রীস্তবক (গাইনোসিয়াম); পাশে গর্ভপত্রের সংখ্যা।'],
  ['par', '( )', 'বন্ধনী — একই স্তবকের অংশগুলো যুক্ত (সংযুক্তি); যেমন K(5) = যুক্তবৃতি।'],
  ['inf', '∞', 'অসংখ্য (সাধারণত 10 এর বেশি)।'],
  ['sup', 'G', 'G এর নিচে রেখা — গর্ভাশয় উচ্চ (অধিগর্ভ ফুল)।'],
  ['infr', 'G', 'G এর উপরে রেখা — গর্ভাশয় নিম্ন (উপগর্ভ ফুল)।'],
  ['adh', '', 'দুই স্তবকের উপরে বাঁকা রেখা — ভিন্ন স্তবক যুক্ত (আসঞ্জন); যেমন দললগ্ন পুংকেশর।']
];
V.floralSymbols = {
  t: 'পুষ্প সংকেতের চিহ্ন', k: ['2d', 'int', 'anim'],
  cap: 'পুষ্প সংকেত হলো ফুলের গঠন সংক্ষেপে প্রকাশের সাংকেতিক সূত্র। প্রতিটি চিহ্নে চাপ দিলে অর্থ দেখাবে; চালু করলে একে একে সব চিহ্ন ঘুরে দেখাবে।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, cols = 6, cw = 60, ch = 56, H = Math.ceil(SY.length / cols) * ch + 10;
    let C, svg, sel = 0, tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পুষ্প সংকেতের চিহ্ন' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      SY.forEach((s, i) => {
        const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + 6, on = i === sel, R = BK.ramp(on ? 3 : 9), g = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - cw / 2 + 4, y: y + 2, width: cw - 8, height: ch - 8, rx: 9, fill: on ? FK.alpha(R.c, .16) : C.s2, stroke: on ? R.c : C.ln, 'stroke-width': on ? 2 : 1 }, g);
        const col = on ? R.ink : C.fg, my = y + ch / 2 - 2;
        if (['act', 'zyg', 'bi', 'male', 'female'].includes(s[0])) B7.sym(g, s[0], x, my, 14, col);
        else if (s[0] === 'adh') { T(g, x - 8, my + 9, 'C', { fs: 15, a: 'middle', w: 650, c: col }); T(g, x + 8, my + 9, 'A', { fs: 15, a: 'middle', w: 650, c: col }); E('path', { d: `M${x - 12} ${my - 4}Q${x} ${my - 16} ${x + 12} ${my - 4}`, stroke: col, 'stroke-width': 1.8, fill: 'none' }, g); }
        else { T(g, x, my + 7, s[1], { fs: 19, a: 'middle', w: 650, c: col }); if (s[0] === 'sup') E('path', { d: `M${x - 8} ${my + 12}h16`, stroke: col, 'stroke-width': 2 }, g); if (s[0] === 'infr') E('path', { d: `M${x - 8} ${my - 12}h16`, stroke: col, 'stroke-width': 2 }, g); }
      });
      $('info').innerHTML = `<b>${SY[sel][1] || (SY[sel][0] === 'adh' ? 'আসঞ্জন রেখা' : 'চিহ্ন')}</b> — ${SY[sel][2]}`;
    };
    root.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g && g.closest('svg')) { sel = +g.dataset.i; base(); } });
    const A = X.anim(root, dt => { tt += dt; const n = Math.floor(tt / 1.6) % SY.length; if (n !== sel) { sel = n; base(); } }, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── পুষ্প সংকেত পড়া ───────── */
/* টোকেন: [ধরন, প্রধান লেখা, সাবস্ক্রিপ্ট, ব্যাখ্যা, বিশেষ] — বিশেষ: 'sup' নিচে রেখা, 'adh' আগের টোকেনের সাথে বাঁকা সংযোগ */
const FF = {
  jaba: ['জবা (Hibiscus rosa-sinensis) — Malvaceae', [
    ['t', 'Br', '', 'মঞ্জরিপত্রিক'], ['t', 'Brl', '', 'উপমঞ্জরিপত্রিক'], ['s', 'act', '', 'অরীয় প্রতিসম'], ['s', 'bi', '', 'উভলিঙ্গ'],
    ['t', 'Epi', '5–8', 'উপবৃতি 5–8টি, বিযুক্ত'], ['t', 'K', '(5)', 'বৃতি 5টি, যুক্ত (যুক্তবৃতি)'], ['t', 'C', '5', 'পাপড়ি 5টি, বিযুক্ত (তবে গোড়ায় পুংকেশরীয় নলের সাথে যুক্ত)'],
    ['t', 'A', '(∞)', 'পুংকেশর অসংখ্য, পুংদণ্ড যুক্ত হয়ে একটি নল — একগুচ্ছ (মনোঅ্যাডেলফাস)', 'adh'], ['t', 'G', '(5)', 'গর্ভপত্র 5টি, যুক্ত; গর্ভাশয় উচ্চ (নিচে রেখা)', 'sup']]],
  dhan: ['ধান (Oryza sativa) — Poaceae', [
    ['t', 'Br', '', 'মঞ্জরিপত্রিক (লেমা)'], ['t', 'Brl', '', 'উপমঞ্জরিপত্রিক (প্যালিয়া)'], ['s', 'zyg', '', 'একপ্রতিসম'], ['s', 'bi', '', 'উভলিঙ্গ'],
    ['t', 'P', '2', 'পুষ্পপুট — 2টি লডিকুল'], ['t', 'A', '3+3', 'পুংকেশর 6টি, দুই আবর্তে (অধিকাংশ ঘাসে A3)'], ['t', 'G', '(2–3)', 'গর্ভপত্র যুক্ত, গর্ভাশয় উচ্চ, একপ্রকোষ্ঠী, একটি ডিম্বক; 2টি পালকসদৃশ গর্ভমুণ্ড', 'sup']]],
  sarisha: ['সরিষা (Brassica) — Brassicaceae', [
    ['t', 'Ebr', '', 'মঞ্জরিপত্রহীন'], ['s', 'act', '', 'অরীয় প্রতিসম'], ['s', 'bi', '', 'উভলিঙ্গ'], ['t', 'K', '2+2', 'বৃতি 4টি, দুই আবর্তে, বিযুক্ত'],
    ['t', 'C', '4', 'পাপড়ি 4টি, ক্রুশাকারে'], ['t', 'A', '2+4', 'পুংকেশর 6টি — বাইরে 2টি খাটো, ভেতরে 4টি লম্বা (চতুর্দীর্ঘ)'], ['t', 'G', '(2)', 'গর্ভপত্র 2টি, যুক্ত, গর্ভাশয় উচ্চ; বহুপ্রান্তীয় অমরা', 'sup']]],
  motor: ['মটর (Pisum sativum) — Fabaceae', [
    ['t', 'Br', '', 'মঞ্জরিপত্রিক'], ['s', 'zyg', '', 'একপ্রতিসম'], ['s', 'bi', '', 'উভলিঙ্গ'], ['t', 'K', '(5)', 'বৃতি 5টি, যুক্ত'],
    ['t', 'C', '1+2+(2)', 'পাপড়ি 5টি — 1টি পতাকা, 2টি পাখা, 2টি যুক্ত নৌকা (ভেক্সিলারি)'], ['t', 'A', '(9)+1', 'পুংকেশর 10টি — 9টি যুক্ত, 1টি মুক্ত (দ্বিগুচ্ছ)'], ['t', 'G', '1', 'একটি গর্ভপত্র, গর্ভাশয় উচ্চ; প্রান্তীয় অমরা', 'sup']]]
};
V.floralFormula = {
  t: 'পুষ্প সংকেত পড়া — ধাপে ধাপে', k: ['2d', 'anim', 'int'],
  cap: 'সংকেত বাম থেকে ডানে পড়া হয়: মঞ্জরিপত্র → প্রতিসাম্য → লিঙ্গ → বাইরের স্তবক থেকে ভেতরের স্তবক (উপবৃতি, বৃতি, দল, পুংস্তবক, স্ত্রীস্তবক)। উদ্ভিদ বেছে নাও, টোকেনে চাপ দাও বা চালু করো।',
  html: () => `<div class="fk-row">${X.seg('ff', Object.keys(FF).map(k => [k, FF[k][0].split(' (')[0]]), 'jaba')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 170;
    let ty = 'jaba', C, svg, sel = -1, tt = 0, pos = [];
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পুষ্প সংকেত' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      T(svg, W / 2, 26, FF[ty][0], { fs: 12, a: 'middle', w: 650, c: C.mu });
      const toks = FF[ty][1]; pos = [];
      const wOf = t => t[0] === 's' ? 24 : (t[1].length * 11.5 + (t[2] ? t[2].length * 7 + 3 : 0) + 8);
      const total = toks.reduce((s, t) => s + wOf(t), 0); let x = Math.max(8, (W - total) / 2); const y = 86;
      toks.forEach((t, i) => {
        const w = wOf(t), on = i === sel, R = BK.ramp(on ? 3 : 9), col = on ? R.ink : C.fg, g = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - 2, y: y - 26, width: w, height: 40, rx: 6, fill: on ? FK.alpha(R.c, .18) : 'transparent' }, g);
        if (t[0] === 's') B7.sym(g, t[1], x + w / 2 - 2, y - 6, 13, col);
        else { T(g, x + 2, y, t[1], { fs: 19, w: 650, c: col }); if (t[2]) T(g, x + 2 + t[1].length * 11, y + 7, t[2], { fs: 11.5, w: 600, c: col }); if (t[4] === 'sup') E('path', { d: `M${x + 1} ${y + 11}h${w - 6}`, stroke: col, 'stroke-width': 1.8 }, g); }
        pos.push([x, w]); x += w;
      });
      toks.forEach((t, i) => { if (t[4] === 'adh' && i > 0) { const [x0, w0] = pos[i - 1], [x1, w1] = pos[i]; E('path', { d: `M${x0 + 6} ${y - 24}Q${(x0 + x1 + w1) / 2} ${y - 44} ${x1 + w1 - 8} ${y - 24}`, stroke: sel === i ? BK.ramp(3).c : C.mu, 'stroke-width': 1.6, fill: 'none' }, svg); } });
      T(svg, W / 2, 150, sel >= 0 ? `${FK.bn(sel + 1)}/${FK.bn(toks.length)}` : 'টোকেনে চাপ দাও', { fs: 11, a: 'middle', c: C.mu });
      $('info').innerHTML = sel >= 0 ? `<b>${toks[sel][0] === 's' ? 'চিহ্ন' : toks[sel][1] + (toks[sel][2] || '')}</b> — ${toks[sel][3]}` : `<b>${FF[ty][0]}</b> — বাম থেকে ডানে পড়ো।`;
    };
    root.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g && g.closest('svg')) { sel = +g.dataset.i; base(); } });
    const A = X.anim(root, dt => { tt += dt; const n = Math.floor(tt / 1.8) % FF[ty][1].length; if (n !== sel) { sel = n; base(); } }, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'ff', v => { ty = v; sel = -1; tt = 0; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
})();
