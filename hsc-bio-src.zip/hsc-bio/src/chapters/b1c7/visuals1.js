/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৭.১ নগ্নবীজী উদ্ভিদ ও Cycas
   gymnoGroups : নগ্নবীজীর পরিচিত উদাহরণ (গ্রিড, অ্যানিমেটেড)
   tallTrees   : বিশ্বের সর্বোচ্চ বৃক্ষ — উচ্চতার তুলনা (চাপ দিলে তথ্য, চালু করলে বাড়ে)
   gymnoTraits : নগ্নবীজীর বৈশিষ্ট্য — মাইন্ড ম্যাপ
   cycasPlant  : স্ত্রী Cycas উদ্ভিদ — চিহ্নিত চিত্র (পাতা দোলে)
   cycasCones  : পুং কোণ, ক্ষুদ্ররেণুপত্র ও বৃহৎরেণুপত্র (ধরন বদলানো, পরাগরেণু ওড়ে)
   cycasOvule  : Cycas এর ডিম্বকের লম্বচ্ছেদ — চিহ্নিত চিত্র
   cycasCycle  : Cycas এর জীবনচক্র — ধাপে ধাপে
   তথ্যসূত্র নোট: উচ্চতা — Wikipedia "List of tallest trees" (2025–26 অনুযায়ী): Hyperion 116.07 m,
   South Tibetan cypress 102.3 m, Sitka spruce 100.2 m, Douglas-fir 99.5 m, Menara 97.58 m (ঢালে গড়),
   giant sequoia 96.37 m, Centurion 96 m (2019 আগুনের পর; 2018 সালে 100.5 m)।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

const B7 = window.B7 = {};
B7.grid = (o) => ({
  t: o.t, k: ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, cols = o.cols || 3, ch = o.ch || 112, L = o.items;
    let sel = 0, C, svg, cells = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; cells = [];
      const rows = Math.ceil(L.length / cols), cw = W / cols, H = rows * ch + 8;
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.t }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      L.forEach((it, i) => {
        const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + 4, R = BK.ramp(o.ramp ? o.ramp(i) : i);
        const cg = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - cw / 2 + 4, y: y + 2, width: cw - 8, height: ch - 8, rx: 10, fill: i === sel ? FK.alpha(R.c, .14) : C.s2, stroke: i === sel ? R.c : C.ln, 'stroke-width': i === sel ? 2 : 1 }, cg);
        const gg = E('g', { transform: `translate(${x} ${y + (ch - 30) / 2})` }, cg);
        const u = o.draw(gg, it[0], R, C);
        T(cg, x, y + ch - 14, it[1], { fs: 10.5, a: 'middle', w: 600, c: R.ink });
        cells.push({ gg, u });
      });
      info(); step(0);
    };
    const info = () => { const it = L[sel]; $('info').innerHTML = `<b>${it[1]}</b> — ${it[2]}${it[3] ? `<div class="small">উদাহরণ: <i>${it[3]}</i></div>` : ''}`; };
    const step = dt => { tt += dt; cells.forEach((c, i) => { if (c.u) c.u(tt, i === sel); }); };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    root.addEventListener('click', e => { const c = e.target.closest('[data-i]'); if (c && root.contains(c) && c.closest('svg')) { sel = +c.dataset.i; base(); } });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
/* পালকসদৃশ যৌগিক পাতা: (x,y) থেকে কোণ a, দৈর্ঘ্য L, n জোড়া পত্রক */
B7.pinnate = (g, x, y, a, L, n, R, bend = .25, lw = 1.4) => {
  const ex = x + L * Math.cos(a), ey = y + L * Math.sin(a), mx = x + L * .5 * Math.cos(a - bend), my = y + L * .5 * Math.sin(a - bend) + L * .12;
  E('path', { d: `M${x.toFixed(1)} ${y.toFixed(1)}Q${mx.toFixed(1)} ${my.toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}`, stroke: R.dk, 'stroke-width': lw, fill: 'none' }, g);
  for (let i = 1; i <= n; i++) { const t = .15 + .82 * i / n, px = (1 - t) ** 2 * x + 2 * (1 - t) * t * mx + t * t * ex, py = (1 - t) ** 2 * y + 2 * (1 - t) * t * my + t * t * ey; const dx = 2 * (1 - t) * (mx - x) + 2 * t * (ex - mx), dy = 2 * (1 - t) * (my - y) + 2 * t * (ey - my), d = Math.hypot(dx, dy) || 1, nx = -dy / d, ny = dx / d, l = L * .16 * (1 - t * .45); [-1, 1].forEach(s => E('path', { d: `M${px.toFixed(1)} ${py.toFixed(1)}l${((nx * s + dx / d * .55) * l).toFixed(1)} ${((ny * s + dy / d * .55) * l).toFixed(1)}`, stroke: R.c, 'stroke-width': lw + .9, 'stroke-linecap': 'round' }, g)); }
};

/* ───────── উদাহরণ ───────── */
V.gymnoGroups = B7.grid({
  t: 'নগ্নবীজী উদ্ভিদের পরিচিত উদাহরণ',
  cap: 'নগ্নবীজী উদ্ভিদের বীজ ফলের ভেতরে ঢাকা থাকে না — রেণুপত্রের উপর খোলা অবস্থায় থাকে। কেউ পামগাছের মতো (Cycas), কেউ শঙ্কু আকৃতির চিরসবুজ বৃক্ষ (Pinus, Sequoia), কেউ পাখার মতো পাতার (Ginkgo), কেউ লতানো (Gnetum)। ঘরে চাপ দাও।',
  cols: 3, ch: 112,
  items: [
    ['cycas', 'Cycas (সাইকাস)', 'পামগাছের মতো অশাখ কাণ্ড, মাথায় পালকসদৃশ যৌগিক পাতার মুকুট; ভিন্নবাসী; "জীবন্ত জীবাশ্ম"।', 'C. revoluta, C. pectinata'],
    ['pinus', 'Pinus (পাইন)', 'শঙ্কু আকৃতির চিরসবুজ বৃক্ষ; সুচের মতো পাতা গুচ্ছে; পুং ও স্ত্রী কোণ একই গাছে; কাঠ, তার্পিন তেল, রজন।', 'P. roxburghii, P. kesiya'],
    ['ginkgo', 'Ginkgo (জিঙ্কো)', 'পাখার মতো দ্বিখণ্ডিত পাতা; একমাত্র জীবিত প্রজাতি; Cycas এর মতো সাঁতারু শুক্রাণু।', 'Ginkgo biloba'],
    ['sequoia', 'Sequoia (রেডউড)', 'পৃথিবীর সবচেয়ে উঁচু বৃক্ষ — 116 মিটারের বেশি; হাজার বছরেরও বেশি বাঁচে।', 'Sequoia sempervirens'],
    ['gnetum', 'Gnetum (নিটাম)', 'অধিকাংশ কাষ্ঠল লতা; চওড়া জালিকা শিরার পাতা ও জাইলেমে ভেসেল — আবৃতবীজীর সাথে মিল।', 'G. gnemon, G. montanum'],
    ['araucaria', 'Araucaria (ক্রিসমাস ট্রি)', 'স্তরে স্তরে আবর্ত শাখা; শোভাবর্ধক; বাংলাদেশে বাগানে লাগানো হয়।', 'A. heterophylla']
  ],
  ramp: i => [7, 10, 6, 10, 7, 10][i],
  draw(g, k, R) {
    const Rb = BK.ramp(6), trunk = '#7a5a30';
    if (k === 'cycas') { E('rect', { x: -4, y: -4, width: 8, height: 34, fill: trunk }, g); const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; const sw = on ? .08 * Math.sin(t * 1.2) : 0; for (let i = 0; i < 7; i++) B7.pinnate(o, 0, -4, -Math.PI + .25 + i * .44 + sw, 30, 6, R, .35 * (i < 3 ? -1 : 1), 1); }; }
    if (k === 'pinus') { E('rect', { x: -2.5, y: 14, width: 5, height: 16, fill: trunk }, g); const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; const sw = on ? 1.5 * Math.sin(t * 1.3) : 0; for (let j = 0; j < 5; j++) { const y = 14 - j * 9, w = 22 - j * 4; E('path', { d: `M${-w + sw * j / 4} ${y}L${sw * (j + 1) / 4} ${y - 14}L${w + sw * j / 4} ${y}Z`, fill: R.c, stroke: R.dk, 'stroke-width': .6 }, o); } E('ellipse', { cx: 12, cy: 6, rx: 3, ry: 5, fill: Rb.c, stroke: Rb.dk }, o); }; }
    if (k === 'ginkgo') { E('path', { d: 'M0 30V-6M0 8l-12 -8M0 0l12 -8', stroke: trunk, 'stroke-width': 2.4 }, g); const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; [[-12, 0], [12, -8], [0, -6], [-6, -16], [8, -20]].forEach(([x, y], i) => { const a = (on ? .2 * Math.sin(t * 2 + i) : 0); E('path', { d: 'M0 0L-8 -10Q0 -15 8 -10Z', fill: R.c, stroke: R.dk, 'stroke-width': .6, transform: `translate(${x} ${y}) rotate(${(a * 57).toFixed(1)})` }, o); E('path', { d: 'M0 -11V-5', stroke: R.dk, 'stroke-width': .8, transform: `translate(${x} ${y}) rotate(${(a * 57).toFixed(1)})` }, o); }); }; }
    if (k === 'sequoia') { const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; const h = on ? 52 + 4 * Math.sin(t * .8) : 56; E('rect', { x: -3, y: 30 - h * .45, width: 6, height: h * .45, fill: '#8a4a2a' }, o); E('path', { d: `M-9 ${30 - h * .35}L0 ${30 - h}L9 ${30 - h * .35}Z`, fill: R.c, stroke: R.dk, 'stroke-width': .6 }, o); E('path', { d: 'M-24 30h48', stroke: R.dk, opacity: .4 }, o); E('rect', { x: 14, y: 22, width: 5, height: 8, fill: BK.ramp(9).c }, o); }; }
    if (k === 'gnetum') { E('path', { d: 'M-18 30V-20', stroke: trunk, 'stroke-width': 3 }, g); const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; let d = 'M-18 26'; for (let j = 0; j <= 12; j++) { const y = 26 - j * 4, x = -18 + 6 * Math.sin(j * 1.1 + (on ? t : 0)); d += `L${x.toFixed(1)} ${y}`; } E('path', { d, stroke: R.dk, 'stroke-width': 1.8, fill: 'none' }, o); [[-8, 14], [-4, -2], [-10, -14], [6, 4]].forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: 8, ry: 4, fill: R.c, stroke: R.dk, 'stroke-width': .6 }, o)); [[10, 18], [14, 12], [18, 18]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 2.8, fill: BK.ramp(4).c }, o)); }; }
    if (k === 'araucaria') { E('rect', { x: -2, y: -28, width: 4, height: 58, fill: trunk }, g); const o = E('g', {}, g); return (t, on) => { o.innerHTML = ''; for (let j = 0; j < 5; j++) { const y = 22 - j * 12, w = 22 - j * 4, s = on ? 1.5 * Math.sin(t * 1.3 + j) : 0; E('path', { d: `M0 ${y}L${-w} ${y + 4 + s}M0 ${y}L${w} ${y + 4 - s}`, stroke: R.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, o); } }; }
  }
});

/* ───────── সর্বোচ্চ বৃক্ষ ───────── */
const TT = [
  ['Sequoia sempervirens', 'কোস্ট রেডউড', 116.07, 'g', 'Hyperion — রেডউড জাতীয় উদ্যান, ক্যালিফোর্নিয়া (যুক্তরাষ্ট্র); 2006 সালে আবিষ্কৃত; পৃথিবীর সবচেয়ে উঁচু জীবিত বৃক্ষ।'],
  ['Cupressus austrotibetica', 'দক্ষিণ তিব্বতি সাইপ্রেস', 102.3, 'g', 'ইয়ারলুং সাংপো গিরিখাত, তিব্বত (চীন); 2023 সালে মাপা — এশিয়ার সবচেয়ে উঁচু বৃক্ষ।'],
  ['Picea sitchensis', 'সিটকা স্প্রুস', 100.2, 'g', 'ক্যালিফোর্নিয়া (যুক্তরাষ্ট্র); উত্তর আমেরিকার উপকূলীয় বনের নগ্নবীজী।'],
  ['Pseudotsuga menziesii', 'ডগলাস ফার', 99.5, 'g', 'ওরেগন (যুক্তরাষ্ট্র); কাঠের জন্য গুরুত্বপূর্ণ নগ্নবীজী।'],
  ['Shorea (Richetia) faguetiana', 'হলুদ মেরান্টি', 97.58, 'a', 'Menara — সাবাহ, বোর্নিও (মালয়েশিয়া); সবচেয়ে উঁচু ফুলধারী (আবৃতবীজী) ও গ্রীষ্মমণ্ডলীয় বৃক্ষ; ঢালে থাকায় মাপ নিয়ে ভিন্নতা (প্রথমে 100.8 m বলা হয়েছিল)।'],
  ['Sequoiadendron giganteum', 'জায়ান্ট সিকুইয়া', 96.37, 'g', 'সিকুইয়া জাতীয় উদ্যান (যুক্তরাষ্ট্র); আয়তনে পৃথিবীর বৃহত্তম বৃক্ষ — "জেনারেল শারম্যান" এর কাণ্ডের আয়তন প্রায় 1,500 ঘনমিটার।'],
  ['Eucalyptus regnans', 'মাউন্টেন অ্যাশ', 96, 'a', 'Centurion — তাসমানিয়া (অস্ট্রেলিয়া); 2018 সালে 100.5 m ছিল, 2019 এর দাবানলে আগা পুড়ে প্রায় 96 m।']
];
V.tallTrees = {
  t: 'বিশ্বের সবচেয়ে উঁচু বৃক্ষ — উচ্চতার তুলনা', k: ['2d', 'anim', 'int', 'calc'],
  cap: 'প্রতিটি প্রজাতির সবচেয়ে উঁচু মাপা জীবিত গাছ (মিটার)। শঙ্কু আকৃতি = নগ্নবীজী, গোল মুকুট = আবৃতবীজী। শীর্ষ চারটিই নগ্নবীজী। তুলনার জন্য 30 তলা ভবন প্রায় 100 m। গাছে চাপ দাও; চালু করলে গাছগুলো বেড়ে ওঠে। (নতুন মাপে ক্রম বদলাতে পারে।)',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 300, gy = 262, sc = 1.9;
    let C, svg, trees = [], sel = 0, k = 1;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; trees = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'সর্বোচ্চ বৃক্ষ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      [0, 25, 50, 75, 100].forEach(m => { const y = gy - m * sc; E('path', { d: `M30 ${y}H352`, stroke: C.ln, 'stroke-dasharray': m ? '3 4' : null }, svg); T(svg, 26, y + 4, String(m), { fs: 10, a: 'end', c: C.mu }); });
      T(svg, 6, 16, 'মিটার', { fs: 10, c: C.mu });
      E('rect', { x: 38, y: gy - 100 * sc, width: 20, height: 100 * sc, fill: FK.alpha(C.mu, .18), stroke: C.mu }, svg); for (let f = 0; f < 30; f += 3) E('path', { d: `M40 ${gy - f * 3.33 * sc}h16`, stroke: FK.alpha(C.mu, .4) }, svg); T(svg, 48, gy + 14, 'ভবন', { fs: 9.5, a: 'middle', c: C.mu });
      TT.forEach((t, i) => { const x = 82 + i * 39, g = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg); trees.push({ g, x, t }); });
      paint(); info();
    };
    const paint = () => {
      trees.forEach(({ g, x, t }, i) => {
        g.innerHTML = ''; const kq = Math.min(1, k), h = t[2] * sc * kq, R = BK.ramp(t[3] === 'g' ? 10 : 7), on = i === sel;
        E('rect', { x: x - 18, y: gy - 116 * sc - 8, width: 36, height: 116 * sc + 22, fill: on ? FK.alpha(R.c, .12) : 'transparent' }, g);
        E('rect', { x: x - 2.2, y: gy - h, width: 4.4, height: h, fill: '#8a5a30' }, g);
        if (t[3] === 'g') E('path', { d: `M${x - 12} ${gy - h * .3}L${x} ${gy - h}L${x + 12} ${gy - h * .3}Z`, fill: R.c, stroke: R.dk, 'stroke-width': on ? 2 : .8 }, g);
        else E('ellipse', { cx: x, cy: gy - h * .82, rx: 15, ry: h * .18 + 2, fill: R.c, stroke: R.dk, 'stroke-width': on ? 2 : .8 }, g);
        T(g, x, gy - h - 6, (t[2] * kq).toFixed(t[2] % 1 ? 1 : 0), { fs: 10, a: 'middle', w: 650, c: R.ink });
        T(g, x, gy + 14, String(i + 1).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]), { fs: 11, a: 'middle', w: 650, c: on ? R.ink : C.mu });
      });
    };
    const info = () => { const t = TT[sel]; $('info').innerHTML = `<b>${t[1]}</b> <i>(${t[0]})</i> — ${t[2]} m · ${t[3] === 'g' ? 'নগ্নবীজী' : 'আবৃতবীজী'}<div class="small">${t[4]}</div>`; };
    const A = X.anim(root, dt => { k += dt * .3; if (k > 1.4) k = 0; paint(); }, { paused: true }); X.pp(root, A);
    root.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g && g.closest('svg')) { sel = +g.dataset.i; paint(); info(); } });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

V.gymnoTraits = Object.assign({ t: 'নগ্নবীজী উদ্ভিদের বৈশিষ্ট্য', k: ['mind', 'int'], cap: 'দেহ, অন্তর্গঠন, জনন ও জনুঃক্রম — নগ্নবীজীর চার দিক। শাখায় চাপ দিলে বিস্তারিত।' }, BK.mind({
  t: 'নগ্নবীজী', d: 'বীজ আছে কিন্তু ফল নেই — ডিম্বক ও বীজ খোলা অবস্থায় রেণুপত্রে।',
  c: [
    { t: 'দেহ', d: 'বহুবর্ষজীবী কাষ্ঠল স্পোরোফাইট।', c: [{ t: 'স্বভাব', d: 'অধিকাংশ চিরসবুজ বৃক্ষ বা গুল্ম; কেউ লতা (Gnetum)।' }, { t: 'মূল', d: 'প্রধান মূল; Cycas এ কোরালয়েড মূল (সায়ানোব্যাকটেরিয়া), Pinus এ মাইকোরাইজা।' }, { t: 'পাতা', d: 'সুচসদৃশ (Pinus), শল্কসদৃশ বা বড় পালকসদৃশ যৌগিক (Cycas); অনেকে মরুজ বৈশিষ্ট্যযুক্ত।' }] },
    { t: 'অন্তর্গঠন', d: 'ভাস্কুলার।', c: [{ t: 'জাইলেম', d: 'প্রধানত ট্র্যাকিড; ভেসেল নেই (Gnetales বাদে)।' }, { t: 'ফ্লোয়েম', d: 'সিভ কোষ, অ্যালবুমিনাস কোষ; সঙ্গীকোষ নেই।' }, { t: 'গৌণ বৃদ্ধি', d: 'ক্যাম্বিয়াম আছে — কাঠ তৈরি হয়; অনেকে রজন নালিযুক্ত।' }] },
    { t: 'জনন', d: 'বীজের মাধ্যমে।', c: [{ t: 'বিষমরেণু', d: 'ক্ষুদ্ররেণু (পরাগরেণু) ও বৃহৎরেণু; সাধারণত কোণ বা স্ট্রোবিলাসে।' }, { t: 'নগ্ন ডিম্বক', d: 'গর্ভাশয় নেই; ডিম্বক বৃহৎরেণুপত্রে খোলা — তাই ফল হয় না।' }, { t: 'পরাগায়ন', d: 'প্রধানত বায়ুর মাধ্যমে; পরাগরেণু সরাসরি ডিম্বকের ছিদ্রে পৌঁছায়।' }, { t: 'নিষেক', d: 'পরাগনালি; Cycas ও Ginkgo তে সাঁতারু শুক্রাণু, Pinus এ অচল পুং গ্যামিট; দ্বিনিষেক নেই।' }] },
    { t: 'বীজ ও জনুঃক্রম', d: 'স্পোরোফাইট প্রধান।', c: [{ t: 'সস্যটিস্যু (n)', d: 'নিষেকের আগেই তৈরি স্ত্রী গ্যামিটোফাইটই বীজের খাদ্য — হ্যাপ্লয়েড।' }, { t: 'বহুভ্রূণতা', d: 'একাধিক স্ত্রীধানী থাকায় একটি বীজে কয়েকটি ভ্রূণ শুরু হতে পারে।' }, { t: 'গ্যামিটোফাইট', d: 'অতি ক্ষুদ্র, স্পোরোফাইটের উপর নির্ভরশীল।' }] }
  ]
}));

/* ───────── Cycas উদ্ভিদ ───────── */
const CX = 180, CY = 140;
const LEAVES = [-2.95, -2.65, -2.3, -1.95, -1.2, -.85, -.5, -.2];
const MEGA = (ms, ov) => {
  const Ro = BK.ramp(2);
  [-1, 1].forEach(s => { [0, 1, 2].forEach(j => { const a = -Math.PI / 2 + s * (.18 + j * .16), L = 46 - j * 4; const ex = CX + L * Math.cos(a), ey = CY + L * Math.sin(a); E('path', { d: `M${CX} ${CY}L${ex.toFixed(1)} ${ey.toFixed(1)}`, stroke: '#a07040', 'stroke-width': 4, 'stroke-linecap': 'round' }, ms); E('path', { d: `M${ex.toFixed(1)} ${ey.toFixed(1)}l${(8 * Math.cos(a - .5)).toFixed(1)} ${(8 * Math.sin(a - .5)).toFixed(1)}M${ex.toFixed(1)} ${ey.toFixed(1)}l${(8 * Math.cos(a + .5)).toFixed(1)} ${(8 * Math.sin(a + .5)).toFixed(1)}`, stroke: '#a07040', 'stroke-width': 2 }, ms); [.45, .65].forEach(f => { const l = L * f; E('circle', { cx: (CX + l * Math.cos(a) + s * 4).toFixed(1), cy: (CY + l * Math.sin(a)).toFixed(1), r: 3.6, fill: Ro.c, stroke: Ro.dk, 'stroke-width': .7 }, ov); }); }); });
};
V.cycasPlant = Object.assign({
  t: 'Cycas এর স্ত্রী উদ্ভিদ (স্পোরোফাইট)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'অশাখ, স্তম্ভাকার কাণ্ড পুরনো পত্রমূলে ঢাকা; মাথায় পালকসদৃশ যৌগিক পাতার মুকুট, মাঝে বাদামি শল্কপত্র। স্ত্রী গাছে মুকুটের কেন্দ্রে পাতার মতো বৃহৎরেণুপত্রের কিনারায় কমলা নগ্ন ডিম্বক — কোনো কোণ (স্ট্রোবিলাস) নেই। মাটির উপরিভাগে প্রবালের মতো কোরালয়েড মূল। চালু করলে পাতা দোলে।'
}, BK.diagram({
  W: 360, H: 340, label: 'Cycas উদ্ভিদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const R = BK.ramp(10), Rb = BK.ramp(6), soil = '#8a6b3a', tr = '#7a5a30';
    E('rect', { x: 8, y: 290, width: 344, height: 44, rx: 8, fill: FK.alpha(soil, .16) }, g); E('path', { d: 'M8 290H352', stroke: soil, opacity: .6 }, g);
    const tp = P('taproot'); E('path', { d: `M${CX} 296Q${CX + 4} 316 ${CX - 2} 332M${CX - 1} 312l-14 10M${CX + 2} 320l12 8`, stroke: tr, 'stroke-width': 3, fill: 'none' }, tp);
    const co = P('coral'); [[CX - 34, 292], [CX + 30, 294]].forEach(([x, y]) => { for (let i = 0; i < 4; i++) { const a = -Math.PI / 2 + (i - 1.5) * .5; E('path', { d: `M${x} ${y + 6}l${(8 * Math.cos(a)).toFixed(1)} ${(8 * Math.sin(a)).toFixed(1)}`, stroke: BK.ramp(0).c, 'stroke-width': 3.4, 'stroke-linecap': 'round' }, co); E('circle', { cx: (x + 9 * Math.cos(a)).toFixed(1), cy: (y + 6 + 9 * Math.sin(a)).toFixed(1), r: 2.6, fill: BK.ramp(0).c }, co); } });
    const tk = P('trunk'); E('rect', { x: CX - 15, y: CY, width: 30, height: 152, rx: 4, fill: '#9a7a50', stroke: tr }, tk); for (let y = CY + 6; y < 290; y += 10) for (let x = CX - 12 + ((y / 10) % 2) * 6; x < CX + 14; x += 12) E('path', { d: `M${x} ${y}l5 -4l5 4l-5 4z`, fill: '#7a5a30', opacity: .7 }, tk);
    const sl = P('scale'); for (let i = 0; i < 6; i++) { const x = CX - 13 + i * 5.2; E('path', { d: `M${x} ${CY + 2}l2.6 -12l2.6 12z`, fill: '#8a5a2a', stroke: '#5a3a1a', 'stroke-width': .6 }, sl); }
    MEGA(P('mega'), P('ovule'));
    P('leaf'); P('leaflet'); P('rachis'); P('spine');
  },
  idle(g, C, t) {
    const R = BK.ramp(10);
    LEAVES.forEach((a, i) => { const sw = .04 * Math.sin(t * 1.1 + i); B7.pinnate(g, CX, CY, a + sw, 118, 12, R, a < -1.6 ? -.3 : .3, 1.4); });
    MEGA(g, g);
    [-1, 1].forEach(s => E('path', { d: `M${CX + s * 6} ${CY + 14}l${s * 4} -3M${CX + s * 7} ${CY + 22}l${s * 4} -3`, stroke: '#5a3a1a', 'stroke-width': 1.4 }, g));
  },
  parts: [
    { id: 'leaflet', bn: 'পত্রক (পিনা)', lb: 'পত্রক', en: 'Leaflet', fn: 'সরু, শক্ত, চামড়ার মতো পত্রক — কেবল একটি মধ্যশিরা, পার্শ্বশিরা নেই; পুরু কিউটিকল ও নিমজ্জিত পত্ররন্ধ্র (মরুজ বৈশিষ্ট্য)।', a: [CX + 118 * Math.cos(-.2) - 14, CY + 118 * Math.sin(-.2) - 8], l: [320, 70], an: 'middle' },
    { id: 'rachis', bn: 'পত্রাক্ষ', en: 'Rachis', fn: 'যৌগিক পাতার মাঝের অক্ষ, দুই পাশে অসংখ্য পত্রক।', a: [CX + 80 * Math.cos(-2.95), CY + 80 * Math.sin(-2.95) + 6], l: [36, 70], an: 'middle' },
    { id: 'spine', bn: 'পত্রবৃন্তের কাঁটা', lb: 'কাঁটা', en: 'Petiole spines', fn: 'পত্রবৃন্তের গোড়ার দিকের পত্রক কাঁটায় রূপান্তরিত — রক্ষা করে।', a: [CX + 6, CY + 14], l: [262, 196], an: 'middle' },
    { id: 'mega', bn: 'বৃহৎরেণুপত্র (মেগাস্পোরোফিল)', lb: 'বৃহৎরেণুপত্র', en: 'Megasporophyll', fn: 'স্ত্রী গাছের মুকুটের কেন্দ্রে পাতার মতো, বাদামি রোমশ রেণুপত্র — আলগাভাবে সাজানো, কোণ তৈরি করে না; উপরের অংশ খাঁজকাটা, নিচের বৃন্তের দুই কিনারায় ডিম্বক।', a: [CX + 40 * Math.cos(-Math.PI / 2 + .5), CY + 40 * Math.sin(-Math.PI / 2 + .5)], l: [250, 26], an: 'middle' },
    { id: 'ovule', bn: 'নগ্ন ডিম্বক', lb: 'ডিম্বক', en: 'Naked ovules', fn: 'বৃহৎরেণুপত্রের কিনারায় খোলা অবস্থায় — কোনো গর্ভাশয়ে ঢাকা নয়; উদ্ভিদজগতের সবচেয়ে বড় ডিম্বকগুলোর একটি; নিষেকের পর বীজ।', a: [CX - 22 * Math.cos(-Math.PI / 2 + .34) + 0, CY + 22 * Math.sin(-Math.PI / 2 + .34)], l: [110, 26], an: 'middle' },
    { id: 'scale', bn: 'শল্কপত্র', en: 'Scale leaves', fn: 'মুকুটে বাদামি, ছোট, রোমশ শল্কপত্র — পালকসদৃশ পাতার সাথে পর্যায়ক্রমে জন্মায়; কচি শীর্ষ রক্ষা করে।', a: [CX + 8, CY - 6], l: [300, 150], an: 'middle' },
    { id: 'trunk', bn: 'কাণ্ড (পত্রমূলের আবরণ)', lb: 'কাণ্ড', en: 'Stem with leaf bases', fn: 'অশাখ, মোটা, স্তম্ভাকার কাণ্ড — ঝরে যাওয়া পাতা ও শল্কপত্রের স্থায়ী গোড়ায় বর্মের মতো ঢাকা; ভেতরে বড় মজ্জায় শ্বেতসার (সাগু)।', a: [CX - 14, 230], l: [60, 230], an: 'middle' },
    { id: 'coral', bn: 'কোরালয়েড মূল', lb: 'কোরালয়েড মূল', en: 'Coralloid roots', fn: 'মাটির উপরিভাগে উপরের দিকে বাড়া, প্রবালের মতো দ্বিবিভাজিত মূল; ভেতরে সায়ানোব্যাকটেরিয়া (Anabaena, Nostoc) বাস করে নাইট্রোজেন সংবন্ধন করে।', a: [CX - 34, 288], l: [60, 276], an: 'middle' },
    { id: 'taproot', bn: 'প্রধান মূল', en: 'Tap root', fn: 'মাটির গভীরে যাওয়া প্রধান মূল ও শাখামূল — আটকে রাখে ও পানি শোষণ করে।', a: [CX + 2, 318], l: [270, 322], an: 'middle' }
  ]
}));

/* ───────── পুং কোণ ও রেণুপত্র ───────── */
const CC = {
  male: ['পুং কোণ (ক্ষুদ্ররেণুস্থলীধর)', 'পুং গাছের মাথায় একটি বড়, খাড়া, শঙ্কু আকৃতির কোণ — কয়েকশ ক্ষুদ্ররেণুপত্র একটি অক্ষে সর্পিলভাবে সাজানো; প্রজাতিভেদে অর্ধ মিটার পর্যন্ত লম্বা হতে পারে। পরিণত হলে রাশি রাশি পরাগরেণু বাতাসে ছড়ায়।'],
  micro: ['ক্ষুদ্ররেণুপত্র (মাইক্রোস্পোরোফিল)', 'চ্যাপ্টা, কাষ্ঠল, ওয়েজ আকৃতির রেণুপত্র — আগা সূচালো (অ্যাপোফাইসিস)। নিচের (অঙ্কীয়) তলে হাজারখানেক ক্ষুদ্ররেণুস্থলী 3–5টির গুচ্ছে (সোরাস); প্রতিটিতে মায়োসিসে অসংখ্য ক্ষুদ্ররেণু (পরাগরেণু)।'],
  mega: ['বৃহৎরেণুপত্র (মেগাস্পোরোফিল)', 'পাতার মতো, প্রায় 15–30 সেমি, বাদামি রোমে ঢাকা; উপরের ফলক খাঁজকাটা, নিচের বৃন্তের দুই কিনারায় 2–10টি নগ্ন ডিম্বক। স্ত্রী গাছে কোণ হয় না — রেণুপত্র মুকুটে আলগা।']
};
V.cycasCones = {
  t: 'Cycas এর জননাঙ্গ — পুং কোণ, ক্ষুদ্ররেণুপত্র ও বৃহৎরেণুপত্র', k: ['2d', 'anim', 'int'],
  cap: 'Cycas ভিন্নবাসী: পুং গাছে কোণ, স্ত্রী গাছে আলগা বৃহৎরেণুপত্র। ধরন বদলে দেখো; চালু করলে পুং কোণ থেকে পরাগরেণু বাতাসে ছড়ায়।',
  html: () => `<div class="fk-row">${X.seg('cc', Object.keys(CC).map(k => [k, CC[k][0].split(' (')[0]]), 'male')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 260;
    let ty = 'male', C, svg, fx, tt = 0;
    const lab = (x1, y1, x2, y2, s, an) => { E('path', { d: `M${x1} ${y1}L${x2} ${y2}`, stroke: C.mu, 'stroke-width': 1 }, svg); E('circle', { cx: x1, cy: y1, r: 2.2, fill: C.fg }, svg); T(svg, x2 + (an === 'start' ? 3 : an === 'end' ? -3 : 0), y2 + 4, s, { fs: 12, a: an || 'start', w: 560, c: C.fg }); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': CC[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rb = BK.ramp(6), Ro = BK.ramp(2), wood = '#a07040';
      if (ty === 'male') {
        E('rect', { x: 128, y: 210, width: 24, height: 44, fill: '#9a7a50' }, svg);
        E('path', { d: 'M140 18C176 40 182 150 172 210H108C98 150 104 40 140 18Z', fill: FK.alpha(Rb.lt, .9), stroke: Rb.dk, 'stroke-width': 1.4 }, svg);
        for (let r = 0; r < 18; r++) for (let c = 0; c < 6; c++) { const y = 34 + r * 10, half = Math.min(32, 10 + r * 3.2), x = 140 - half + (c + (r % 2) * .5) * (half * 2 / 6.2); if (x > 140 + half - 4) continue; E('path', { d: `M${x.toFixed(1)} ${y}l5 -4l5 4l-5 4z`, fill: Rb.c, stroke: Rb.dk, 'stroke-width': .5 }, svg); }
        lab(152, 60, 220, 40, 'ক্ষুদ্ররেণুপত্র (সর্পিল)'); lab(140, 110, 220, 110, 'কোণের অক্ষ'); lab(150, 230, 220, 230, 'কাণ্ডের শীর্ষ');
      } else if (ty === 'micro') {
        E('path', { d: 'M80 200L60 60Q140 36 220 52L250 70L190 210Z', fill: FK.alpha(Rb.lt, .9), stroke: Rb.dk, 'stroke-width': 1.6 }, svg);
        E('path', { d: 'M220 52L262 40L250 70', fill: Rb.c, stroke: Rb.dk }, svg);
        for (let r = 0; r < 7; r++) for (let c = 0; c < 6; c++) { const x = 84 + c * 20 + r * 3, y = 76 + r * 17; if (x > 214 - r * 4) continue; [[0, 0], [5, -3], [5, 3]].forEach(([dx, dy]) => E('circle', { cx: x + dx, cy: y + dy, r: 2.8, fill: Rb.c, stroke: Rb.dk, 'stroke-width': .5 }, svg)); }
        lab(256, 50, 300, 30, 'অ্যাপোফাইসিস', 'middle'); lab(140, 112, 300, 120, 'ক্ষুদ্ররেণুস্থলীর', 'start'); T(svg, 303, 136, 'গুচ্ছ (সোরাস)', { fs: 12, w: 560, c: C.fg }); lab(100, 190, 60, 240, 'অঙ্কীয় তল', 'middle');
      } else {
        E('path', { d: 'M150 250L156 150', stroke: wood, 'stroke-width': 8, 'stroke-linecap': 'round' }, svg);
        E('path', { d: 'M156 150C120 140 110 90 122 40C140 20 176 20 192 40C204 90 194 140 156 150Z', fill: FK.alpha(wood, .55), stroke: '#7a5030', 'stroke-width': 1.4 }, svg);
        for (let i = 0; i < 9; i++) { const y = 46 + i * 11; [-1, 1].forEach(s => E('path', { d: `M${157 + s * (22 - Math.abs(i - 4) * 2)} ${y}l${s * 18} -6`, stroke: '#7a5030', 'stroke-width': 3, 'stroke-linecap': 'round' }, svg)); }
        [[148, 172], [162, 196], [146, 216], [160, 236]].forEach(([x, y], i) => { const s = i % 2 ? 1 : -1; E('ellipse', { cx: x + s * 14, cy: y, rx: 9, ry: 11, fill: Ro.c, stroke: Ro.dk, 'stroke-width': 1 }, svg); E('path', { d: `M${x + s * 14} ${y - 11}v-3`, stroke: Ro.dk, 'stroke-width': 1.4 }, svg); });
        lab(132, 172, 60, 172, 'নগ্ন ডিম্বক', 'end'); lab(194, 70, 260, 60, 'খাঁজকাটা ফলক'); lab(154, 200, 260, 200, 'বৃন্ত'); lab(176, 160, 260, 140, 'বাদামি রোম');
      }
      fx = E('g', {}, svg); $('info').innerHTML = `<b>${CC[ty][0]}</b> — ${CC[ty][1]}`; step(0);
    };
    const step = dt => { tt += dt; fx.innerHTML = ''; if (ty !== 'male') return; for (let i = 0; i < 18; i++) { const f = (tt * .25 + i / 18) % 1, x = 160 + f * 180 + 10 * Math.sin(tt * 2 + i), y = 40 + (i % 9) * 18 - 30 * f; E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 1.8, fill: BK.ramp(6).c, opacity: (1 - f).toFixed(2) }, fx); } };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'cc', v => { ty = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── ডিম্বকের লম্বচ্ছেদ ───────── */
const OX = 136, OY = 170;
V.cycasOvule = Object.assign({
  t: 'Cycas এর ডিম্বকের লম্বচ্ছেদ', k: ['2d', 'label', 'int'],
  cap: 'একটি মাত্র পুরু ত্বক (ইন্টিগুমেন্ট) — বাইরে মাংসল, মাঝে শক্ত পাথুরে, ভেতরে মাংসল স্তর; ত্বক নিউসেলাসের সাথে প্রায় পুরোটা যুক্ত, কেবল আগায় মুক্ত। আগায় ডিম্বকরন্ধ্র, তার নিচে পরাগ প্রকোষ্ঠ; তারপর স্ত্রী গ্যামিটোফাইট (সস্যটিস্যু, n) ও তার মাথায় কয়েকটি স্ত্রীধানী, উপরে স্ত্রীধানী প্রকোষ্ঠ।'
}, BK.diagram({
  W: 360, H: 330, label: 'Cycas ডিম্বক',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Ro = BK.ramp(2), Rw = BK.ramp(6), Rn = BK.ramp(8), Rg = BK.ramp(10), Rv = BK.ramp(9);
    const shape = (rx, ry, top) => `M${OX} ${OY - ry - top}C${OX + rx * .5} ${OY - ry} ${OX + rx} ${OY - ry * .6} ${OX + rx} ${OY}C${OX + rx} ${OY + ry * .7} ${OX + rx * .5} ${OY + ry} ${OX} ${OY + ry}C${OX - rx * .5} ${OY + ry} ${OX - rx} ${OY + ry * .7} ${OX - rx} ${OY}C${OX - rx} ${OY - ry * .6} ${OX - rx * .5} ${OY - ry} ${OX} ${OY - ry - top}Z`;
    const st = P('stalk'); E('rect', { x: OX - 14, y: OY + 128, width: 28, height: 26, fill: '#a07040' }, st);
    const sa = P('sarco'); E('path', { d: shape(104, 132, 14), fill: Ro.c, stroke: Ro.dk, 'stroke-width': 1.4 }, sa);
    const sc = P('sclero'); E('path', { d: shape(90, 118, 10), fill: '#d8c8a0', stroke: '#8a7040', 'stroke-width': 2 }, sc);
    const en = P('endo'); E('path', { d: shape(80, 108, 6), fill: FK.alpha(Ro.lt, .9), stroke: Ro.dk, 'stroke-width': .8 }, en);
    const nu = P('nucellus'); E('path', { d: shape(72, 100, 4), fill: FK.alpha(Rn.lt, .8), stroke: Rn.dk, 'stroke-width': .8 }, nu); E('path', { d: `M${OX - 12} ${OY - 100}Q${OX} ${OY - 122} ${OX + 12} ${OY - 100}`, fill: FK.alpha(Rn.lt, .9), stroke: Rn.dk }, nu);
    const fg = P('femgam'); E('ellipse', { cx: OX, cy: OY + 18, rx: 62, ry: 80, fill: FK.alpha(Rg.lt, .8), stroke: Rg.dk, 'stroke-width': 1.2 }, fg); for (let i = 0; i < 40; i++) { const a = i * 2.4, r = Math.sqrt(i / 40) * 54; E('circle', { cx: (OX + r * Math.cos(a)).toFixed(1), cy: (OY + 30 + r * 1.2 * Math.sin(a)).toFixed(1), r: 1.3, fill: FK.alpha(Rg.dk, .4) }, fg); }
    const ac = P('archch'); E('path', { d: `M${OX - 40} ${OY - 58}Q${OX} ${OY - 74} ${OX + 40} ${OY - 58}`, fill: FK.alpha(BK.ramp(5).lt, .7), stroke: BK.ramp(5).dk, 'stroke-width': 1 }, ac);
    const ar = P('arche'); [-24, 0, 24].forEach(dx => { E('path', { d: `M${OX + dx - 9} ${OY - 56}Q${OX + dx - 12} ${OY - 30} ${OX + dx} ${OY - 26}Q${OX + dx + 12} ${OY - 30} ${OX + dx + 9} ${OY - 56}Z`, fill: FK.alpha(Rn.c, .5), stroke: Rn.dk, 'stroke-width': 1.2 }, ar); E('circle', { cx: OX + dx, cy: OY - 40, r: 6, fill: Rn.c }, ar); });
    const pc = P('pollench'); E('ellipse', { cx: OX, cy: OY - 106, rx: 14, ry: 8, fill: FK.alpha(BK.ramp(5).lt, .8), stroke: BK.ramp(5).dk }, pc); [[-5, -106], [4, -104]].forEach(([x, y]) => E('circle', { cx: OX + x, cy: OY + y, r: 2.6, fill: Rw.c }, pc));
    const mp = P('micro'); E('path', { d: `M${OX} ${OY - 146}V${OY - 114}`, stroke: C.fg, 'stroke-width': 2, 'stroke-dasharray': '3 2' }, mp);
    const vb = P('vasc'); [-1, 1].forEach(s => { E('path', { d: `M${OX + s * 8} ${OY + 132}Q${OX + s * 98} ${OY + 60} ${OX + s * 96} ${OY - 40}`, stroke: Rv.dk, 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '5 3' }, vb); E('path', { d: `M${OX + s * 6} ${OY + 132}Q${OX + s * 76} ${OY + 90} ${OX + s * 76} ${OY + 10}`, stroke: Rv.dk, 'stroke-width': 1.2, fill: 'none', 'stroke-dasharray': '2 3' }, vb); });
  },
  parts: [
    { id: 'micro', bn: 'ডিম্বকরন্ধ্র (মাইক্রোপাইল)', lb: 'ডিম্বকরন্ধ্র', en: 'Micropyle', fn: 'ত্বকের আগার সরু ছিদ্র — পরাগায়নের সময় এখানে পরাগ-ফোঁটা জমে; ফোঁটা শুকানোর সময় পরাগরেণু ভেতরে টেনে নেয়।', a: [OX, OY - 140], l: [256, 22] },
    { id: 'pollench', bn: 'পরাগ প্রকোষ্ঠ', en: 'Pollen chamber', fn: 'নিউসেলাসের আগা (নিউসেলার চঞ্চু) ভেঙে তৈরি গহ্বর — পরাগরেণু এখানে জমা হয়ে অঙ্কুরিত হয়।', a: [OX + 12, OY - 106], l: [256, 48] },
    { id: 'nucellus', bn: 'নিউসেলাস (বৃহৎরেণুস্থলী, 2n)', lb: 'নিউসেলাস', en: 'Nucellus', fn: 'ডিম্বকের মূল ভাগ — বৃহৎরেণুস্থলী; এর ভেতরে একটি বৃহৎরেণু মাতৃকোষের মায়োসিসে একটি কার্যকর বৃহৎরেণু থেকে স্ত্রী গ্যামিটোফাইট তৈরি হয়।', a: [OX + 70, OY - 30], l: [256, 74] },
    { id: 'archch', bn: 'স্ত্রীধানী প্রকোষ্ঠ', lb: 'স্ত্রীধানী প্রকোষ্ঠ', en: 'Archegonial chamber', fn: 'স্ত্রী গ্যামিটোফাইটের মাথার উপরের ফাঁকা গহ্বর — নিষেকের সময় তরলে ভরে যায়; পরাগনালি থেকে মুক্ত শুক্রাণু এখানে সাঁতরে স্ত্রীধানীতে যায়।', a: [OX + 30, OY - 63], l: [256, 100] },
    { id: 'arche', bn: 'স্ত্রীধানী (আর্কিগোনিয়াম)', lb: 'স্ত্রীধানী', en: 'Archegonia', fn: 'স্ত্রী গ্যামিটোফাইটের মাথায় সাধারণত 2–8টি; ছোট গ্রীবা ও বড় ডিম্বাণু — উদ্ভিদজগতের সবচেয়ে বড় ডিম্বাণুগুলোর একটি।', a: [OX + 24, OY - 40], l: [256, 126] },
    { id: 'femgam', bn: 'স্ত্রী গ্যামিটোফাইট বা সস্যটিস্যু (n)', lb: 'সস্যটিস্যু (n)', en: 'Female gametophyte (endosperm)', fn: 'বহুকোষী হ্যাপ্লয়েড স্ত্রী গ্যামিটোফাইট — খাদ্যে পূর্ণ; নিষেকের পর বীজের সস্য হিসেবে ভ্রূণকে খাদ্য দেয়। আবৃতবীজীর ট্রিপ্লয়েড সস্য থেকে আলাদা।', a: [OX + 30, OY + 50], l: [256, 230] },
    { id: 'endo', bn: 'ভেতরের মাংসল স্তর', lb: 'ভেতরের মাংসল স্তর', en: 'Inner fleshy layer', fn: 'ত্বকের সবচেয়ে ভেতরের মাংসল স্তর — বীজ পাকলে শুকিয়ে কাগজের মতো হয়।', a: [OX + 79, OY + 40], l: [256, 204] },
    { id: 'sclero', bn: 'পাথুরে স্তর (স্ক্লেরোটেস্টা)', lb: 'পাথুরে স্তর', en: 'Sclerotesta', fn: 'ত্বকের মাঝের শক্ত স্ক্লেরেনকাইমার স্তর — বীজকে রক্ষা করে।', a: [OX + 89, OY + 12], l: [256, 178] },
    { id: 'sarco', bn: 'বাইরের মাংসল স্তর (সারকোটেস্টা)', lb: 'বাইরের মাংসল স্তর', en: 'Sarcotesta', fn: 'উজ্জ্বল কমলা বা লাল মাংসল স্তর — প্রাণীকে আকৃষ্ট করে বীজ বিস্তারে সাহায্য করে।', a: [OX + 103, OY - 20], l: [256, 152] },
    { id: 'vasc', bn: 'ভাস্কুলার বান্ডল', lb: 'ভাস্কুলার বান্ডল', en: 'Vascular supply', fn: 'বৃন্ত থেকে ত্বকের বাইরের ও ভেতরের দুই সারি বান্ডল — বাড়ন্ত ডিম্বকে পানি ও খাদ্য আনে।', a: [OX + 92, OY + 40], l: [256, 256] },
    { id: 'stalk', bn: 'বৃন্ত', en: 'Stalk', fn: 'ছোট বৃন্ত — বৃহৎরেণুপত্রের সাথে যুক্ত।', a: [OX + 14, OY + 144], l: [256, 300] }
  ]
}));

/* ───────── Cycas জীবনচক্র ───────── */
V.cycasCycle = Object.assign({
  t: 'Cycas এর জীবনচক্র', k: ['2d', 'anim', 'int'],
  cap: 'স্পোরোফাইট (2n) প্রধান ও স্বাধীন; পুং ও স্ত্রী গ্যামিটোফাইট অতি ক্ষুদ্র ও স্পোরোফাইটের উপর নির্ভরশীল। পরাগায়ন বাতাসে; পরাগনালি নিউসেলাসে শোষক অঙ্গের মতো কাজ করে এবং শেষে দুটি বিশাল বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু মুক্ত করে — বীজ উদ্ভিদে সাঁতারু শুক্রাণুর বিরল উদাহরণ।'
}, BK.steps({
  W: 360, H: 250, label: 'Cycas জীবনচক্র', dur: 2.8,
  stages: [
    { t: 'স্পোরোফাইট (2n)', en: 'Sporophyte', d: 'ভিন্নবাসী — পুং গাছে কোণ, স্ত্রী গাছে বৃহৎরেণুপত্রে ডিম্বক।' },
    { t: 'ক্ষুদ্ররেণু → পরাগরেণু', en: 'Microspores', d: 'ক্ষুদ্ররেণুস্থলীতে মায়োসিসে ক্ষুদ্ররেণু (n); নিউক্লিয়াস বিভাজনে তিন কোষী পরাগরেণু — প্রোথ্যালাস কোষ, জনন কোষ ও নালিকা কোষ — পুং গ্যামিটোফাইটের শুরু।' },
    { t: 'পরাগায়ন', en: 'Pollination', d: 'বাতাসে উড়ে আসা পরাগরেণু ডিম্বকরন্ধ্রের পরাগ-ফোঁটায় আটকায়; ফোঁটা শুকিয়ে গেলে পরাগ প্রকোষ্ঠে টেনে নেয়।' },
    { t: 'পরাগনালি ও শুক্রাণু', en: 'Sperms', d: 'পরাগনালি নিউসেলাসে শিকড়ের মতো ঢুকে খাদ্য শোষণ করে (কয়েক মাস); জনন কোষ থেকে দেহকোষ → দুটি লাটিমের মতো বিশাল শুক্রাণু — সর্পিল বলয়ে হাজার হাজার ফ্ল্যাজেলা।' },
    { t: 'নিষেক', en: 'Fertilization', d: 'পরাগনালি ফেটে শুক্রাণু ও তরল স্ত্রীধানী প্রকোষ্ঠে পড়ে; শুক্রাণু সাঁতরে স্ত্রীধানীর ডিম্বাণুকে নিষিক্ত করে → জাইগোট (2n)। দ্বিনিষেক নেই।' },
    { t: 'বীজ ও অঙ্কুরোদগম', en: 'Seed', d: 'জাইগোট থেকে দুই বীজপত্রযুক্ত ভ্রূণ; স্ত্রী গ্যামিটোফাইট (n) হয় সস্য; ত্বক বীজত্বক — নগ্ন বীজ, ফল নেই। বীজ সুপ্তাবস্থা ছাড়াই অঙ্কুরিত হয়ে নতুন স্পোরোফাইট।' }
  ],
  draw(g, C, s, u) {
    const R = BK.ramp(10), Rb = BK.ramp(6), Ro = BK.ramp(2), Rs = BK.ramp(5), Rn = BK.ramp(8);
    const svg = g.ownerSVGElement; svg._ph = (svg._ph || 0) + .03; const ph = svg._ph;
    const tag = (x, y, s2, c) => T(g, x, y, s2, { fs: 11.5, a: 'middle', w: 650, c: c || C.fg });
    const plant = (x, y, sc, female) => { E('rect', { x: x - 4 * sc, y: y - 40 * sc, width: 8 * sc, height: 40 * sc, fill: '#9a7a50' }, g); for (let i = 0; i < 7; i++) B7.pinnate(g, x, y - 40 * sc, -Math.PI + .25 + i * .44, 34 * sc, 7, R, i < 3 ? -.3 : .3, 1); if (female) [-1, 1].forEach(s2 => E('circle', { cx: x + s2 * 5 * sc, cy: y - 46 * sc, r: 2.4 * sc, fill: Ro.c }, g)); else E('path', { d: `M${x} ${y - 40 * sc}L${x - 5 * sc} ${y - 52 * sc}Q${x} ${y - 66 * sc} ${x + 5 * sc} ${y - 52 * sc}Z`, fill: Rb.c, stroke: Rb.dk }, g); };
    if (s === 0) { plant(110, 210, 2.2, false); plant(260, 210, 2.2, true); tag(110, 232, 'পুং গাছ', Rb.ink); tag(260, 232, 'স্ত্রী গাছ', Ro.ink); }
    if (s === 1) { const k = Math.min(1, u * 1.3); for (let i = 0; i < 12; i++) { const x = 60 + (i % 6) * 48, y = 80 + Math.floor(i / 6) * 70; E('circle', { cx: x, cy: y, r: 16, fill: FK.alpha(Rb.lt, .9), stroke: Rb.dk }, g); if (k > .4) { E('path', { d: `M${x - 10} ${y + 6}h20`, stroke: Rb.dk, opacity: (k - .4) / .6 }, g); E('circle', { cx: x - 6, cy: y + 10, r: 2.4, fill: C.mu }, g); E('circle', { cx: x + 4, cy: y - 2, r: 4, fill: Rb.c }, g); } else E('circle', { cx: x, cy: y, r: 4, fill: Rb.c }, g); } tag(180, 220, k > .4 ? 'তিন কোষী পরাগরেণু (n)' : 'ক্ষুদ্ররেণু (n)', Rb.ink); }
    if (s === 2) { E('path', { d: 'M260 220C330 220 340 120 300 70C290 60 278 54 260 52C242 54 230 60 220 70C180 120 190 220 260 220Z', fill: Ro.c, stroke: Ro.dk }, g); E('circle', { cx: 260, cy: 46, r: 8 * (1 - u * .8), fill: FK.alpha(Rs.lt, .9), stroke: Rs.dk }, g); for (let i = 0; i < 10; i++) { const f = Math.min(1, u * 1.4 + i * .04), x = 30 + (230 - 30) * f + 6 * Math.sin(ph * 3 + i), y = 40 + i * 14 + (46 - 40 - i * 14) * f; E('circle', { cx: x, cy: y, r: 2.6, fill: Rb.c }, g); } tag(120, 220, 'বাতাসে পরাগায়ন', Rs.ink); }
    if (s === 3) { E('rect', { x: 60, y: 60, width: 240, height: 150, rx: 18, fill: FK.alpha(Rn.lt, .5), stroke: Rn.dk }, g); const L = 30 + 130 * u; E('path', { d: `M180 60V${60 + L * .5}`, stroke: Rb.dk, 'stroke-width': 6, 'stroke-linecap': 'round' }, g); for (let i = 0; i < 5; i++) E('path', { d: `M180 ${70 + i * 12}l${(i % 2 ? 1 : -1) * L * .35} ${10 + i * 2}`, stroke: Rb.c, 'stroke-width': 2.4 }, g); if (u > .55) [-1, 1].forEach(s2 => { const x = 180 + s2 * 30, y = 150; E('ellipse', { cx: x, cy: y, rx: 14, ry: 18, fill: FK.alpha(Rs.lt, .9), stroke: Rs.dk }, g); let d = ''; for (let j = 0; j <= 24; j++) { const a = j * .5 + ph, r = 4 + j * .4; d += (j ? 'L' : 'M') + (x + r * Math.cos(a)).toFixed(1) + ' ' + (y - 8 + r * .5 * Math.sin(a)).toFixed(1); } E('path', { d, stroke: Rs.dk, 'stroke-width': 1, fill: 'none' }, g); }); tag(180, 230, u > .55 ? 'দুটি বিশাল বহু-ফ্ল্যাজেলাযুক্ত শুক্রাণু' : 'পরাগনালি নিউসেলাসে শোষক', Rs.ink); }
    if (s === 4) { E('path', { d: 'M60 90Q180 60 300 90', fill: FK.alpha(Rs.lt, .6), stroke: Rs.dk }, g); [120, 180, 240].forEach((x, i) => { E('path', { d: `M${x - 18} 90Q${x - 22} 170 ${x} 180Q${x + 22} 170 ${x + 18} 90Z`, fill: FK.alpha(Rn.lt, .6), stroke: Rn.dk }, g); E('circle', { cx: x, cy: 140, r: 14, fill: i === 1 && u > .7 ? Rb.c : Rn.c }, g); }); const k = Math.min(1, u * 1.4); E('ellipse', { cx: 180, cy: 70 + 60 * k, rx: 8, ry: 10, fill: FK.alpha(Rs.lt, .9), stroke: Rs.dk }, g); tag(180, 220, u > .7 ? 'জাইগোট (2n)' : 'শুক্রাণু সাঁতরে স্ত্রীধানীতে', u > .7 ? Rb.ink : Rs.ink); }
    if (s === 5) { E('ellipse', { cx: 120, cy: 120, rx: 50, ry: 64, fill: Ro.c, stroke: Ro.dk }, g); E('ellipse', { cx: 120, cy: 124, rx: 34, ry: 48, fill: FK.alpha(BK.ramp(10).lt, .9), stroke: R.dk }, g); E('path', { d: 'M120 84v50M120 134l-8 10M120 134l8 10', stroke: Rb.dk, 'stroke-width': 3 }, g); T(g, 120, 200, 'বীজ: সস্য (n) + ভ্রূণ (2n)', { fs: 11, a: 'middle', w: 600, c: C.fg }); if (u > .3) { const k = (u - .3) / .7; plant(270, 210, .6 + 1.2 * k, k > .5); } tag(180, 232, 'নগ্ন বীজ → নতুন উদ্ভিদ', R.ink); }
  }
}));
})();
