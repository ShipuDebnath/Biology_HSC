/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §৫.৩ ছত্রাকঘটিত রোগ
   fungalDis    : উদ্ভিদ ও মানুষের প্রধান ছত্রাকঘটিত রোগ — গাছ
   blightLeaf   : আক্রান্ত পাতার প্রস্থচ্ছেদ — পত্ররন্ধ্র দিয়ে স্পোরাঞ্জিওফোর, লেবু-আকৃতির স্পোরাঞ্জিয়াম (জুস্পোর বেরোয়)
   blightCycle  : গোলআলুর বিলম্বিত ধ্বসা রোগের চক্র (ধাপে ধাপে)
   blightWeather: আবহাওয়া ও রোগের ঝুঁকি — তাপমাত্রা ও আর্দ্রতা স্লাইডার
   ringworm     : দাদ — দেহের কোথায়, আর বলয় কেন বাইরের দিকে বাড়ে (অ্যানিমেশন)
   cmpBlightRing: দুই রোগের তুলনা
   নোট: Phytophthora infestans উমাইসিটিস ("জলজ ছত্রাক") — প্রাচীর সেলুলোজের, অঙ্গজ দেহ ডিপ্লয়েড; ঐতিহ্যগতভাবে ছত্রাক হিসেবে পড়ানো হয়।
   ঝুঁকির নিয়ম শিক্ষামূলক সরলীকরণ: 10–25 °C ও আপেক্ষিক আর্দ্রতা ≥ 90% → উচ্চ।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B5 = window.B5;

V.fungalDis = Object.assign({ t: 'কয়েকটি গুরুত্বপূর্ণ ছত্রাকঘটিত রোগ', k: ['tree', 'int'], cap: 'উদ্ভিদ ও মানুষ — দুই ধরনের পোষকে ছত্রাকের রোগ। বাংলাদেশের ফসলের অনেক বড় ক্ষতির কারণ ছত্রাক। শাখায় চাপ দাও।' }, BK.tree({
  t: 'ছত্রাকঘটিত রোগ', d: 'ছত্রাক (ও ছত্রাকসদৃশ উমাইসিটিস) দিয়ে সৃষ্ট রোগ।',
  c: [
    { t: 'উদ্ভিদের রোগ', d: 'ফসলের ফলন ও মান কমে।', c: [{ t: 'আলুর বিলম্বিত ধ্বসা', d: 'Phytophthora infestans — ঠান্ডা, কুয়াশাচ্ছন্ন আর্দ্র আবহাওয়ায় দ্রুত ছড়ায়।' }, { t: 'ধানের ব্লাস্ট', d: 'Magnaporthe oryzae (Pyricularia oryzae) — পাতায় চোখের মতো দাগ, শিষ ভেঙে পড়ে।' }, { t: 'ধানের বাদামি দাগ', d: 'Bipolaris oryzae (Helminthosporium) — 1943 সালের বাংলার দুর্ভিক্ষের একটি কারণ।' }, { t: 'গমের ব্লাস্ট ও মরিচা', d: 'গমের ব্লাস্ট বাংলাদেশে প্রথম 2016 সালে; মরিচা — Puccinia।' }, { t: 'আখের লাল পচা ও চীনাবাদামের টিক্কা', d: 'Colletotrichum falcatum; Cercospora।' }] },
    { t: 'মানুষের রোগ', d: 'ত্বক থেকে অভ্যন্তরীণ অঙ্গ।', c: [{ t: 'দাদ (টিনিয়া)', d: 'Trichophyton, Microsporum, Epidermophyton — ত্বক, চুল ও নখের কেরাটিনে।' }, { t: 'ক্যানডিডিয়াসিস', d: 'Candida albicans — মুখ ও যৌনাঙ্গে সাদা আস্তর; রোগপ্রতিরোধ কমলে বাড়ে।' }, { t: 'অ্যাসপারজিলোসিস', d: 'Aspergillus — ফুসফুসের সংক্রমণ।' }, { t: 'মিউকরমাইকোসিস', d: 'Rhizopus, Mucor — অনিয়ন্ত্রিত ডায়াবেটিস বা স্টেরয়েড ব্যবহারে নাক-চোখ-মস্তিষ্কে মারাত্মক সংক্রমণ।' }] }
  ]
}, { colW: 122 }));

/* ───────── আক্রান্ত পাতার প্রস্থচ্ছেদ ───────── */
V.blightLeaf = Object.assign({
  t: 'বিলম্বিত ধ্বসায় আক্রান্ত আলুপাতার প্রস্থচ্ছেদ', k: ['2d', 'label', 'int', 'anim'],
  cap: 'পর্দাহীন হাইফা পাতার কোষের ফাঁকে ফাঁকে ছড়ায় এবং হস্টোরিয়া দিয়ে কোষ থেকে খাদ্য শোষে। পাতার নিচের পত্ররন্ধ্র দিয়ে শাখান্বিত স্পোরাঞ্জিওফোর বেরিয়ে লেবু-আকৃতির স্পোরাঞ্জিয়াম তৈরি করে — এগুলোই পাতার নিচে সাদা তুলার মতো আস্তর। ঠান্ডা পানিতে স্পোরাঞ্জিয়াম থেকে জুস্পোর বের হয়।'
}, BK.diagram({
  W: 360, H: 300, label: 'আক্রান্ত পাতা',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rl = BK.ramp(10), Rw = BK.ramp(11), Rh = BK.ramp(9), Rs = BK.ramp(6), Rd = BK.ramp(4);
    E('rect', { x: 20, y: 30, width: 320, height: 14, fill: FK.alpha(Rl.lt, .5), stroke: Rw.dk }, g);
    for (let i = 0; i < 10; i++) E('rect', { x: 22 + i * 32, y: 46, width: 28, height: 50, rx: 4, fill: FK.alpha(Rl.c, i > 6 ? .25 : .55), stroke: Rw.dk }, g);
    const dead = P('lesion'); for (let i = 7; i < 10; i++) E('rect', { x: 22 + i * 32, y: 46, width: 28, height: 50, rx: 4, fill: FK.alpha(Rd.dk, .35) }, dead);
    for (let i = 0; i < 14; i++) E('circle', { cx: 30 + (i * 23) % 300, cy: 112 + (i * 13) % 24, r: 9, fill: FK.alpha(Rl.c, .3), stroke: Rw.dk, 'stroke-width': .8 }, g);
    const lw = P('epid'); E('path', { d: 'M20 142H150M172 142H340', stroke: Rw.dk, 'stroke-width': 8 }, lw);
    const sto = P('stoma'); E('ellipse', { cx: 155, cy: 142, rx: 6, ry: 5, fill: Rl.c, stroke: Rw.dk }, sto); E('ellipse', { cx: 167, cy: 142, rx: 6, ry: 5, fill: Rl.c, stroke: Rw.dk }, sto);
    const hy = P('hypha'); E('path', { d: 'M60 104C90 100 110 130 140 118S170 112 200 104S260 120 300 106M161 120V140', stroke: Rh.dk, 'stroke-width': 2.4, fill: 'none' }, hy);
    const ha = P('haust'); [[86, 96], [200, 98], [262, 96]].forEach(([x, y]) => { E('path', { d: `M${x} ${y + 6}V${y - 6}`, stroke: Rh.dk, 'stroke-width': 2 }, ha); E('circle', { cx: x, cy: y - 9, r: 4, fill: Rh.c, stroke: Rh.dk }, ha); });
    const sp = P('sporph'); E('path', { d: 'M161 146V230M161 180L130 205M161 198L196 222M140 196L122 228M161 214L150 248', stroke: Rh.dk, 'stroke-width': 2, fill: 'none' }, sp);
    const sg = P('spgium'); [[161, 238], [118, 238], [204, 230], [146, 258], [128, 212]].forEach(([x, y]) => E('path', { d: `M${x} ${y - 9}Q${x + 7} ${y - 4} ${x + 6} ${y + 3}Q${x} ${y + 12} ${x - 6} ${y + 3}Q${x - 7} ${y - 4} ${x} ${y - 9}Z`, fill: Rs.lt, stroke: Rs.dk, 'stroke-width': 1.2 }, sg));
  },
  idle(g, C, t) { const R = BK.ramp(6); for (let i = 0; i < 6; i++) { const f = (t * .4 + i / 6) % 1, a = i * 1.05; B5.swimmer(g, 161 + 30 * f * Math.cos(a) + 50 * f, 258 + 26 * f * Math.sin(a), 2.6, 2, R, t + i, a); } },
  parts: [
    { id: 'epid', bn: 'নিম্নত্বক', en: 'Lower epidermis', fn: 'পাতার নিচের ত্বক — এখানেই বেশি পত্ররন্ধ্র থাকে।', a: [60, 142], l: [60, 170], an: 'middle' },
    { id: 'stoma', bn: 'পত্ররন্ধ্র', en: 'Stoma', fn: 'রক্ষীকোষের মাঝের ছিদ্র — এ পথে স্পোরাঞ্জিওফোর বাইরে আসে (আবার জার্মটিউব এ পথেও ঢুকতে পারে)।', a: [167, 146], l: [250, 170] },
    { id: 'hypha', bn: 'আন্তঃকোষীয় হাইফা', lb: 'হাইফা', en: 'Intercellular hypha', fn: 'পর্দাহীন (সিনোসাইটিক) হাইফা কোষের ফাঁকে ছড়ায়।', a: [300, 106], l: [300, 20], an: 'middle' },
    { id: 'haust', bn: 'হস্টোরিয়াম', en: 'Haustorium', fn: 'হাইফার শাখা কোষে ঢুকে গোল চোষক অঙ্গ — পোষককোষ থেকে খাদ্য শোষে।', a: [86, 87], l: [86, 20], an: 'middle' },
    { id: 'lesion', bn: 'মৃত কলা (দাগ)', lb: 'মৃত কলা', en: 'Necrotic tissue', fn: 'আক্রান্ত কোষ মরে বাদামি-কালো পানিভেজা দাগ তৈরি হয়; দাগের কিনারায় পরজীবী সক্রিয়।', a: [300, 70], l: [200, 20], an: 'middle' },
    { id: 'sporph', bn: 'স্পোরাঞ্জিওফোর', en: 'Sporangiophore', fn: 'পত্ররন্ধ্র দিয়ে বের হওয়া শাখান্বিত হাইফা; শাখার মাথায় স্পোরাঞ্জিয়াম — পাতার নিচে সাদা আস্তর।', a: [161, 190], l: [60, 196] },
    { id: 'spgium', bn: 'স্পোরাঞ্জিয়াম', en: 'Sporangium', fn: 'লেবুর মতো আকৃতি; বাতাস ও বৃষ্টির ছিটায় ছড়ায়। ঠান্ডা (প্রায় 15 °C এর নিচে) পানিতে ভেতর থেকে কয়েকটি দুই-ফ্ল্যাজেলাযুক্ত জুস্পোর বের হয়; উষ্ণতায় সরাসরি জার্মটিউব গজায়।', a: [204, 230], l: [270, 240] }
  ]
}));

/* ───────── রোগচক্র ───────── */
V.blightCycle = Object.assign({
  t: 'গোলআলুর বিলম্বিত ধ্বসা রোগের চক্র', k: ['2d', 'anim', 'int'],
  cap: 'আক্রান্ত বীজআলু থেকে শুরু; স্পোরাঞ্জিয়াম বাতাসে ক্ষেত থেকে ক্ষেতে ছড়ায় এবং অনুকূল আবহাওয়ায় প্রতি 3–5 দিনে নতুন প্রজন্ম — তাই কয়েক দিনেই পুরো ক্ষেত ধ্বংস হতে পারে। বৃষ্টির পানিতে স্পোর মাটিতে নেমে কন্দ সংক্রমিত করে, আর আক্রান্ত কন্দ পরের মৌসুমে রোগ বয়ে আনে।'
}, BK.steps({
  W: 360, H: 240, label: 'ধ্বসা রোগচক্র', dur: 2.6,
  stages: [
    { t: 'আক্রান্ত বীজআলু', en: 'Infected seed tuber', d: 'সংরক্ষিত বা বীজ হিসেবে লাগানো আক্রান্ত আলুতে মাইসেলিয়াম বেঁচে থাকে; অঙ্কুরিত গাছে উঠে প্রাথমিক সংক্রমণ ঘটায়।' },
    { t: 'পাতায় দাগ ও সাদা আস্তর', en: 'Leaf lesions', d: 'পাতার কিনারা ও আগায় পানিভেজা দাগ, পরে কালো; আর্দ্র সকালে দাগের কিনারায় নিচের পিঠে সাদা আস্তর (স্পোরাঞ্জিওফোর)।' },
    { t: 'স্পোর ছড়ানো', en: 'Spread', d: 'স্পোরাঞ্জিয়াম বাতাস ও বৃষ্টির ছিটায় পাশের গাছ ও দূরের ক্ষেতে যায়।' },
    { t: 'নতুন সংক্রমণ', en: 'Infection', d: 'পাতায় পানির স্তরে ঠান্ডায় জুস্পোর বের হয়ে বা উষ্ণতায় সরাসরি জার্মটিউব দিয়ে ঢোকে; 3–5 দিনে নতুন দাগ — বারবার চক্র (বহুচক্রী রোগ)।' },
    { t: 'কন্দ পচা', en: 'Tuber rot', d: 'বৃষ্টির পানিতে স্পোর মাটিতে নেমে কন্দে লালচে-বাদামি শুকনো পচা ঘটায়; গুদামে অন্য জীবাণু মিলে নরম পচা। আক্রান্ত কন্দ পরের মৌসুমের উৎস।' }
  ],
  draw(g, C, s, u) {
    const Rl = BK.ramp(10), Rs = BK.ramp(11), Rd = BK.ramp(4), Rp = BK.ramp(6), Rw = BK.ramp(9);
    E('rect', { x: 10, y: 176, width: 340, height: 56, rx: 6, fill: FK.alpha(Rs.c, .2) }, g);
    const tuber = (x, y, rot) => { E('ellipse', { cx: x, cy: y, rx: 20, ry: 13, fill: Rp.lt, stroke: Rp.dk, 'stroke-width': 1.4 }, g); if (rot) E('ellipse', { cx: x + 4, cy: y + 2, rx: 11 * rot, ry: 7 * rot, fill: FK.alpha(Rd.dk, .55) }, g); };
    const plant = (x, k, sick) => { E('path', { d: `M${x} 176V${176 - 70 * k}`, stroke: Rl.dk, 'stroke-width': 2.4 }, g); for (let i = 0; i < 4; i++) { const y = 176 - 18 * (i + 1) * k, sd = i % 2 ? 1 : -1, d = sick > i / 4 ? 1 : 0; E('path', { d: `M${x} ${y}q${sd * 14} -10 ${sd * 28} -2q${-sd * 12} 10 ${-sd * 28} 2Z`, fill: d ? FK.alpha(Rd.dk, .7) : Rl.c, stroke: Rl.dk, 'stroke-width': .8 }, g); if (d && s < 4) for (let j = 0; j < 3; j++) E('circle', { cx: x + sd * (10 + j * 6), cy: y + 3, r: 1.6, fill: '#fff', stroke: Rw.dk, 'stroke-width': .4 }, g); } };
    if (s === 0) { tuber(120, 200, .6); const k = u; plant(120, k, 0); T(g, 240, 120, 'আক্রান্ত বীজআলু থেকে', { fs: 11, a: 'middle', w: 600, c: C.fg }); T(g, 240, 138, 'রোগাক্রান্ত চারা', { fs: 11, a: 'middle', w: 600, c: C.fg }); }
    if (s === 1) { tuber(120, 200, .6); plant(120, 1, u); }
    if (s === 2) { plant(80, 1, 1); plant(260, 1, 0); for (let i = 0; i < 8; i++) { const f = (u + i / 8) % 1, x = 100 + 150 * f, y = 110 - 50 * Math.sin(f * 3.14) + i * 3; E('path', { d: `M${x} ${y - 4}q4 2 3 5q-3 5 -6 0q-1 -3 3 -5Z`, fill: Rp.lt, stroke: Rp.dk, 'stroke-width': .8 }, g); } E('path', { d: 'M40 40h60m-12 -5l12 5l-12 5', stroke: C.mu, 'stroke-width': 1.4, fill: 'none' }, g); T(g, 70, 30, 'বাতাস', { fs: 10, a: 'middle', w: 560, c: C.mu }); }
    if (s === 3) { plant(80, 1, 1); plant(260, 1, Math.min(1, u * 1.2)); T(g, 260, 30, '3–5 দিনে নতুন দাগ', { fs: 11, a: 'middle', w: 600, c: Rd.ink }); }
    if (s === 4) { plant(180, 1, 1); for (let i = 0; i < 6; i++) { const f = (u * 2 + i / 6) % 1; E('path', { d: `M${150 + i * 12} ${110 + f * 80}v6`, stroke: BK.ramp(5).c, 'stroke-width': 1.6 }, g); } tuber(150, 206, Math.min(1, u * 1.3)); tuber(214, 210, Math.max(0, u * 1.3 - .3)); }
  }
}));

/* ───────── আবহাওয়া ও ঝুঁকি ───────── */
V.blightWeather = {
  t: 'আবহাওয়া ও বিলম্বিত ধ্বসার ঝুঁকি', k: ['graph', 'anim', 'int'],
  cap: 'ঠান্ডা (প্রায় 10–25 °C), মেঘলা, কুয়াশাচ্ছন্ন ও খুব আর্দ্র (আপেক্ষিক আর্দ্রতা 90% এর বেশি) আবহাওয়া — বাংলাদেশে সাধারণত ডিসেম্বর-জানুয়ারি — রোগের জন্য সবচেয়ে অনুকূল। স্লাইডার সরিয়ে দেখো। (শিক্ষামূলক সরলীকরণ; বাস্তবে পাতা কতক্ষণ ভেজা থাকে সেটিও গুরুত্বপূর্ণ।)',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row">${FK.sl('tc', 'তাপমাত্রা', 0, 35, 1, 14, ' °C')}</div><div class="fk-row">${FK.sl('rh', 'আর্দ্রতা', 40, 100, 1, 94, '%')}</div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 200;
    let tc = 14, rh = 94, C, svg, fog = [], sp = [], bar, lab, tt = 0;
    const risk = () => { const tOk = tc >= 10 && tc <= 25, tNear = tc >= 7 && tc <= 28; if (tOk && rh >= 90) return 2; if ((tOk && rh >= 80) || (tNear && rh >= 90)) return 1; return 0; };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; fog = []; sp = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'আবহাওয়া ও রোগের ঝুঁকি' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      E('rect', { x: 0, y: 150, width: 220, height: 50, fill: FK.alpha(BK.ramp(11).c, .2) }, svg);
      for (let i = 0; i < 4; i++) { const x = 40 + i * 50; E('path', { d: `M${x} 150V100`, stroke: BK.ramp(10).dk, 'stroke-width': 2 }, svg); [-1, 1].forEach(sd => E('path', { d: `M${x} ${120 + sd * 6}q${sd * 14} -10 ${sd * 24} -2q${-sd * 10} 8 ${-sd * 24} 2Z`, fill: BK.ramp(10).c }, svg)); }
      for (let i = 0; i < 26; i++) fog.push(E('circle', { r: 9 + (i % 4) * 3, fill: C.mu, opacity: 0 }, svg));
      for (let i = 0; i < 10; i++) sp.push(E('ellipse', { rx: 2.6, ry: 3.6, fill: BK.ramp(6).c, stroke: BK.ramp(6).dk, 'stroke-width': .6, opacity: 0 }, svg));
      E('rect', { x: 250, y: 30, width: 26, height: 140, rx: 13, fill: C.s2, stroke: C.ln }, svg);
      bar = E('rect', { x: 253, y: 33, width: 20, height: 0, rx: 10 }, svg);
      T(svg, 296, 44, 'উচ্চ', { fs: 10.5, w: 600, c: BK.ramp(4).ink }); T(svg, 296, 104, 'মাঝারি', { fs: 10.5, w: 600, c: BK.ramp(6).ink }); T(svg, 296, 164, 'কম', { fs: 10.5, w: 600, c: BK.ramp(10).ink });
      T(svg, 263, 190, 'ঝুঁকি', { fs: 11, a: 'middle', w: 650, c: C.fg });
      lab = T(svg, 110, 24, '', { fs: 11.5, a: 'middle', w: 650, c: C.fg });
      paint();
    };
    const paint = () => {
      const r = risk(), col = [BK.ramp(10), BK.ramp(6), BK.ramp(4)][r], h = [40, 85, 134][r];
      bar.setAttribute('height', h); bar.setAttribute('y', 167 - h); bar.setAttribute('fill', col.c);
      const s = tc < 15 ? 'ঠান্ডা: জুস্পোর দিয়ে অঙ্কুরোদ্গম' : tc <= 25 ? 'জার্মটিউব দিয়ে সরাসরি অঙ্কুরোদ্গম' : 'অতিরিক্ত গরম: বৃদ্ধি থেমে যায়'; if (lab.textContent !== s) lab.textContent = s;
      $('info').innerHTML = `<b>${tc} °C, আর্দ্রতা ${rh}% — ঝুঁকি ${['কম', 'মাঝারি', 'উচ্চ'][r]}</b><div class="small">${r === 2 ? 'স্পোরাঞ্জিয়াম প্রচুর তৈরি হয় ও পাতা ভেজা থাকে — প্রতিরোধমূলক ছত্রাকনাশক স্প্রের সময়; কৃষি বিভাগের সতর্কবার্তা অনুসরণ করো।' : r === 1 ? 'পরিস্থিতি নজরে রাখো — কুয়াশা বা বৃষ্টি দীর্ঘ হলে ঝুঁকি দ্রুত বাড়ে।' : tc > 28 ? 'গরম ও শুকনো আবহাওয়ায় পরজীবী সক্রিয় থাকতে পারে না — এজন্য বাংলাদেশে রোগটি শীতকালীন।' : 'শুকনো বা খুব ঠান্ডা আবহাওয়ায় স্পোর তৈরি ও সংক্রমণ কমে।'}</div>`;
    };
    const step = dt => { tt += dt; const r = risk(), nf = Math.round(Math.max(0, (rh - 60) / 40) * fog.length), ns = [1, 4, 10][r]; fog.forEach((f, i) => { const x = ((i * 47 + tt * 12) % 260) - 20, y = 40 + (i * 29) % 90; f.setAttribute('cx', x.toFixed(1)); f.setAttribute('cy', y); f.setAttribute('opacity', i < nf ? .12 : 0); }); sp.forEach((p, i) => { const fq = (tt * .25 + i / 10) % 1; p.setAttribute('cx', (30 + fq * 190).toFixed(1)); p.setAttribute('cy', (110 - 40 * Math.sin(fq * 3.14) + (i % 3) * 8).toFixed(1)); p.setAttribute('opacity', i < ns ? (1 - fq).toFixed(2) : 0); }); };
    FK.bindSl(root, 'tc', v => { tc = v; paint(); }, ' °C', 0); FK.bindSl(root, 'rh', v => { rh = v; paint(); }, '%', 0);
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(() => { base(); step(0); }); base(); step(0);
    return () => { A.stop(); unT(); };
  }
};

/* ───────── দাদ ───────── */
const RW = {
  cor: ['দেহে (টিনিয়া কর্পোরিস)', [70, 92], 'বুক, পেট, পিঠ, হাত-পায়ে গোল লালচে চুলকানিযুক্ত দাগ — কিনারা উঁচু ও আঁশযুক্ত, মাঝখান পরিষ্কার হতে থাকে।'],
  cap: ['মাথায় (টিনিয়া ক্যাপিটিস)', [70, 30], 'প্রধানত শিশুদের — চুল ভেঙে গোল টাকের মতো আঁশযুক্ত দাগ; মুখে খাওয়ার ওষুধ লাগে।'],
  cru: ['কুঁচকিতে (টিনিয়া ক্রুরিস)', [70, 128], 'ঘাম ও আঁটসাঁট পোশাকে কুঁচকি ও ঊরুর ভাঁজে লাল চুলকানিযুক্ত দাগ।'],
  ped: ['পায়ে (টিনিয়া পেডিস)', [62, 190], 'পায়ের আঙুলের ফাঁকে সাদা ভেজা ফাটা চামড়া, চুলকানি ("অ্যাথলিটস ফুট") — বন্ধ জুতা ও ভেজা মোজায় বাড়ে।'],
  ung: ['নখে (টিনিয়া আঙ্গুইয়াম)', [104, 130], 'নখ পুরু, হলদেটে ও ভঙ্গুর — দীর্ঘ চিকিৎসা লাগে।']
};
V.ringworm = {
  t: 'দাদ (ডার্মাটোফাইটোসিস) — কেন বলয় তৈরি হয়', k: ['2d', 'anim', 'int'],
  cap: 'দাদ কৃমি নয় — ডার্মাটোফাইট ছত্রাক ত্বকের বাইরের মৃত স্তর, চুল ও নখের কেরাটিন খেয়ে বাঁচে। হাইফা কেন্দ্র থেকে চারদিকে বাড়ে; সক্রিয় ছত্রাক থাকে বাইরের কিনারায় (লাল, উঁচু, আঁশযুক্ত), আর মাঝখানে প্রদাহ কমে চামড়া প্রায় স্বাভাবিক হয় — তাই আংটির মতো দেখায়।',
  html: () => `<div class="fk-row">${X.seg('rw', Object.keys(RW).map(k => [k, RW[k][0].split(' (')[0]]), 'cor')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 230, ZX = 250, ZY = 112;
    let m = 'cor', C, svg, spot, ring, inner, scales = [], hy = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; scales = []; hy = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'দাদ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rb = BK.ramp(6), Rr = BK.ramp(4), Rh = BK.ramp(9);
      /* দেহরেখা */
      const bd = { fill: FK.alpha(Rb.lt, .7), stroke: Rb.dk, 'stroke-width': 1.4 };
      E('circle', Object.assign({ cx: 70, cy: 30, r: 16 }, bd), svg); E('rect', Object.assign({ x: 50, y: 50, width: 40, height: 74, rx: 12 }, bd), svg);
      E('path', Object.assign({ d: 'M50 58L30 118M90 58L110 118' }, bd, { fill: 'none', 'stroke-width': 9, 'stroke-linecap': 'round' }), svg);
      E('path', Object.assign({ d: 'M60 122L58 196M80 122L82 196' }, bd, { fill: 'none', 'stroke-width': 11, 'stroke-linecap': 'round' }), svg);
      const [sx, sy] = RW[m][1]; spot = E('circle', { cx: sx, cy: sy, r: 6, fill: 'none', stroke: Rr.c, 'stroke-width': 2.4 }, svg);
      E('path', { d: `M${sx + 8} ${sy}L${ZX - 72} ${ZY}`, stroke: C.mu, 'stroke-dasharray': '3 3' }, svg);
      /* বড় করে দেখা ত্বক */
      E('circle', { cx: ZX, cy: ZY, r: 92, fill: FK.alpha(Rb.lt, .8), stroke: C.ln, 'stroke-width': 2 }, svg);
      inner = E('circle', { cx: ZX, cy: ZY, fill: FK.alpha(Rr.lt, .35) }, svg);
      for (let i = 0; i < 18; i++) hy.push(E('path', { stroke: Rh.dk, 'stroke-width': 1, fill: 'none', opacity: .7 }, svg));
      ring = E('circle', { cx: ZX, cy: ZY, fill: 'none', stroke: Rr.c, 'stroke-width': 9, opacity: .75 }, svg);
      for (let i = 0; i < 22; i++) scales.push(E('path', { stroke: '#fff', 'stroke-width': 1.6, opacity: .9 }, svg));
      T(svg, ZX, H - 6, 'সক্রিয় কিনারা বাইরের দিকে সরে', { fs: 10.5, a: 'middle', w: 600, c: C.mu });
      $('info').innerHTML = `<b>${RW[m][0]}</b> — ${RW[m][2]}<div class="small">জীবাণু: <i>Trichophyton, Microsporum, Epidermophyton</i>; চিকিৎসকের পরামর্শে ছত্রাকনাশক মলম বা ওষুধ; স্টেরয়েড মিশ্রিত মলম রোগ বাড়িয়ে দেয়।</div>`;
      step(0);
    };
    const step = dt => {
      tt += dt; const r = 24 + ((tt * 9) % 56);
      ring.setAttribute('r', r.toFixed(1)); inner.setAttribute('r', Math.max(0, r - 5).toFixed(1));
      hy.forEach((h, i) => { const a = i / 18 * 6.283; let d = `M${ZX + (r - 14) * Math.cos(a)} ${ZY + (r - 14) * Math.sin(a)}`; d += `L${(ZX + (r + 6) * Math.cos(a + .08)).toFixed(1)} ${(ZY + (r + 6) * Math.sin(a + .08)).toFixed(1)}`; h.setAttribute('d', d); });
      scales.forEach((s, i) => { const a = i / 22 * 6.283 + .1; const x = ZX + r * Math.cos(a), y = ZY + r * Math.sin(a); s.setAttribute('d', `M${(x - 3).toFixed(1)} ${(y - 1).toFixed(1)}l6 2`); });
      spot.setAttribute('r', (5 + 2 * Math.sin(tt * 3)).toFixed(1));
    };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'rw', v => { m = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

V.cmpBlightRing = Object.assign({ t: 'আলুর বিলম্বিত ধ্বসা ও দাদের তুলনা', k: ['cmp', 'int'], cap: 'একটি উদ্ভিদের, অন্যটি মানুষের রোগ — কিন্তু দুটিই আর্দ্রতায় বাড়ে।' }, BK.compare({
  a: 'আলুর বিলম্বিত ধ্বসা', b: 'দাদ',
  rows: [
    ['পোষক', 'গোলআলু (টমেটোতেও)', 'মানুষ (কিছু ধরন পোষা প্রাণীতেও)'],
    ['জীবাণু', 'Phytophthora infestans (উমাইসিটিস)', 'Trichophyton, Microsporum, Epidermophyton (ডার্মাটোফাইট)'],
    ['আক্রান্ত অংশ', 'পাতা, কাণ্ড ও কন্দ', 'ত্বক, চুল ও নখের কেরাটিন'],
    ['বিস্তার', 'বাতাস ও বৃষ্টির ছিটায় স্পোরাঞ্জিয়াম; আক্রান্ত বীজআলু', 'সরাসরি সংস্পর্শ, তোয়ালে, চিরুনি, পোশাক, পোষা প্রাণী'],
    ['অনুকূল অবস্থা', 'ঠান্ডা, কুয়াশা, আর্দ্রতা 90% এর বেশি', 'গরম, আর্দ্র, ঘাম, আঁটসাঁট পোশাক'],
    ['প্রধান লক্ষণ', 'পাতায় কালো পানিভেজা দাগ, নিচে সাদা আস্তর; কন্দ পচা', 'লাল আঁশযুক্ত চুলকানিযুক্ত বলয়, মাঝখান পরিষ্কার'],
    ['প্রতিকার', 'রোগমুক্ত বীজ, প্রতিরোধী জাত, প্রতিরোধমূলক ছত্রাকনাশক স্প্রে', 'ছত্রাকনাশক মলম বা ওষুধ, শুকনো ও পরিষ্কার থাকা, জিনিস ভাগ না করা']
  ]
}));
})();
