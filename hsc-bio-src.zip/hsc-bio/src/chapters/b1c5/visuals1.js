/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৫.১ শৈবাল
   algaeForms   : শৈবালের দৈহিক গঠনের রূপ — এককোষী থেকে বৃহৎ সামুদ্রিক কেল্প (গ্রিড, অ্যানিমেটেড)
   algaeCell    : Chlamydomonas — একটি আদর্শ শৈবাল কোষের চিহ্নিত চিত্র (ফ্ল্যাজেলা নড়ে)
   chloroShapes : ক্লোরোপ্লাস্টের নানা আকৃতি (গ্রিড)
   algaeClass   : রঞ্জক অনুযায়ী প্রধান শ্রেণি — গাছ
   algaeRepro   : জননের প্রকারভেদ — গাছ
   gameteTypes  : আইসোগ্যামি, অ্যানাইসোগ্যামি, উগ্যামি — গ্যামিট মিলনের অ্যানিমেশন
   ulothrixFil  : Ulothrix এর ফিলামেন্ট — চিহ্নিত চিত্র (পানির স্রোত)
   ulothrixCycle: Ulothrix এর জীবনচক্র — অযৌন (জুস্পোর) ও যৌন (আইসোগ্যামি, জাইগোটে মায়োসিস) ধাপে ধাপে
   algaeEcon    : অর্থনৈতিক গুরুত্ব — মাইন্ড ম্যাপ
   জীববৈজ্ঞানিক নোট: Ulothrix — হ্যাপ্লয়েড ফিলামেন্ট, জাইগোটই একমাত্র ডিপ্লয়েড দশা (হ্যাপ্লন্টিক);
   জুস্পোর চার-ফ্ল্যাজেলাযুক্ত, গ্যামিট দুই-ফ্ল্যাজেলাযুক্ত; ভিন্ন ফিলামেন্টের গ্যামিট মেলে (হেটারোথ্যালিক)।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;

/* ───────── অধ্যায় ৫ এর সাধারণ গ্রিড সহায়ক: ঘরে চাপ দিলে নির্বাচন, নির্বাচিত ঘর নড়ে ─────────
   items: [[key, নাম, বর্ণনা, উদাহরণ]], draw(gg, key, R, C) → ঐচ্ছিক u(t) ফাংশন (অ্যানিমেশন) */
const B5 = window.B5 = {};
B5.grid = (o) => ({
  t: o.t, k: ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, cols = o.cols || 3, ch = o.ch || 112, L = o.items;
    let sel = 0, C, svg, cells = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; cells = [];
      const rows = Math.ceil(L.length / cols), cw = W / cols, H = rows * ch + 8;
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.t }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      L.forEach((it, i) => {
        const x = (i % cols) * cw + cw / 2, y = Math.floor(i / cols) * ch + 4, R = BK.ramp(o.ramp ? o.ramp(i) : i);
        const cg = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        E('rect', { x: x - cw / 2 + 4, y: y + 2, width: cw - 8, height: ch - 8, rx: 10, fill: i === sel ? FK.alpha(R.c, .14) : C.s2, stroke: i === sel ? R.c : C.ln, 'stroke-width': i === sel ? 2 : 1 }, cg);
        const gg = E('g', { transform: `translate(${x} ${y + (ch - 30) / 2})` }, cg);
        const u = o.draw(gg, it[0], R, C);
        T(cg, x, y + ch - 14, it[1], { fs: 10.5, a: 'middle', w: 600, c: R.ink });
        cells.push({ gg, x, y: y + (ch - 30) / 2, u });
      });
      info(); step(0);
    };
    const info = () => { const it = L[sel]; $('info').innerHTML = `<b>${it[1]}</b> — ${it[2]}${it[3] ? `<div class="small">উদাহরণ: <i>${it[3]}</i></div>` : ''}`; };
    const step = dt => { tt += dt; cells.forEach((c, i) => { if (c.u) c.u(tt, i === sel); if (!o.still) { const dx = i === sel ? 2.5 * Math.sin(tt * 2) : 0; c.gg.setAttribute('transform', `translate(${(c.x + dx).toFixed(1)} ${c.y})`); } }); };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    root.addEventListener('click', e => { const c = e.target.closest('[data-i]'); if (c && root.contains(c) && c.closest('svg')) { sel = +c.dataset.i; base(); } });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});
/* ছোট সাঁতারু কোষ: জুস্পোর/গ্যামিট — nf = ফ্ল্যাজেলার সংখ্যা */
B5.swimmer = (g, x, y, r, nf, R, t = 0, ang = -Math.PI / 2) => {
  const c = Math.cos(ang), s = Math.sin(ang);
  E('ellipse', { cx: x, cy: y, rx: r, ry: r * 1.35, fill: R.c, stroke: R.dk, 'stroke-width': 1, transform: `rotate(${ang * 180 / Math.PI + 90} ${x} ${y})` }, g);
  const hx = x + c * r * 1.3, hy = y + s * r * 1.3;
  for (let k = 0; k < nf; k++) {
    const sp = (k - (nf - 1) / 2) * .55; let d = `M${hx.toFixed(1)} ${hy.toFixed(1)}`;
    for (let j = 1; j <= 5; j++) { const L = j * r * .55, w = r * .35 * Math.sin(t * 10 - j + k), a = ang + sp; d += `L${(hx + L * Math.cos(a) - w * Math.sin(a)).toFixed(1)} ${(hy + L * Math.sin(a) + w * Math.cos(a)).toFixed(1)}`; }
    E('path', { d, stroke: R.dk, 'stroke-width': .9, fill: 'none' }, g);
  }
};

/* ───────── দৈহিক গঠন ───────── */
V.algaeForms = B5.grid({
  t: 'শৈবালের দৈহিক গঠনের নানা রূপ',
  cap: 'শৈবালের দেহ থ্যালাস — মূল, কাণ্ড, পাতায় বিভক্ত নয়। আকার এক মাইক্রোমিটারের কাছাকাছি এককোষী থেকে কয়েক দশ মিটার লম্বা কেল্প পর্যন্ত। ঘরে চাপ দাও, চালু করলে নির্বাচিত রূপ নড়ে।',
  cols: 4, ch: 104,
  items: [
    ['uni', 'এককোষী চলনশীল', 'একটি কোষই পূর্ণ জীব; দুটি ফ্ল্যাজেলা দিয়ে সাঁতার কাটে।', 'Chlamydomonas'],
    ['nonm', 'এককোষী অচল', 'ফ্ল্যাজেলাহীন গোল কোষ।', 'Chlorella'],
    ['col', 'কলোনিয়াল', 'নির্দিষ্ট সংখ্যক কোষ শ্লেষ্মায় একত্রে — ফাঁপা গোলক (সিনোবিয়াম); কোষগুলো ফ্ল্যাজেলা দিয়ে ঘোরায়।', 'Volvox'],
    ['fil', 'অশাখ ফিলামেন্ট', 'কোষ এক সারিতে সুতার মতো; গোড়ায় আটকানো কোষ (হোল্ডফাস্ট)।', 'Ulothrix, Spirogyra'],
    ['br', 'শাখান্বিত ফিলামেন্ট', 'সুতার মতো দেহ থেকে শাখা বের হয়।', 'Cladophora'],
    ['sip', 'সাইফোনাস', 'প্রস্থপ্রাচীরহীন নলাকার বহুনিউক্লিয়াসযুক্ত দেহ (সিনোসাইটিক)।', 'Vaucheria'],
    ['par', 'পাতার মতো প্যারেনকাইমাটাস', 'দুই স্তর কোষের চ্যাপ্টা পাতার মতো থ্যালাস।', 'Ulva (সামুদ্রিক লেটুস)'],
    ['kelp', 'বৃহৎ কেল্প', 'হোল্ডফাস্ট, বৃন্ত (স্টাইপ) ও ফলকে (ল্যামিনা) বিভক্ত; বায়ুথলিতে ভাসে; দৈত্যাকার কেল্প কয়েক দশ মিটার লম্বা।', 'Laminaria, Macrocystis, Sargassum']
  ],
  ramp: i => i === 7 ? 6 : (i % 2 ? 7 : 10),
  draw(g, k, R) {
    if (k === 'uni') { const o = E('g', {}, g); return (t) => { o.innerHTML = ''; B5.swimmer(o, 0, 6, 10, 2, R, t); }; }
    if (k === 'nonm') { E('circle', { cx: 0, cy: 4, r: 15, fill: R.c, stroke: R.dk }, g); E('path', { d: 'M-9 4a9 9 0 0 0 18 0', stroke: R.dk, 'stroke-width': 3, fill: 'none' }, g); return; }
    if (k === 'col') { const o = E('g', {}, g); E('circle', { cx: 0, cy: 4, r: 24, fill: FK.alpha(R.c, .15), stroke: R.dk }, g); const dots = []; for (let i = 0; i < 18; i++) dots.push(E('circle', { r: 2.6, fill: R.dk }, o)); return t => dots.forEach((d, i) => { const a = i / 18 * 6.283 + t * .8; d.setAttribute('cx', (21 * Math.cos(a)).toFixed(1)); d.setAttribute('cy', (4 + 21 * Math.sin(a) * .95).toFixed(1)); d.setAttribute('opacity', Math.sin(a) > -.2 ? 1 : .45); }); }
    if (k === 'fil') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const b = 3 * Math.sin(t * 1.5); for (let i = 0; i < 6; i++) { const y = 26 - i * 9, x = b * (i / 5) ** 2; E('rect', { x: x - 5, y: y - 9, width: 10, height: 9, fill: R.c, stroke: R.dk, 'stroke-width': .8 }, o); E('rect', { x: x - 5, y: y - 6.5, width: 10, height: 4, fill: R.dk, opacity: .5 }, o); } E('path', { d: 'M-4 26l-3 6M4 26l3 6M0 26v7', stroke: R.dk }, o); }; }
    if (k === 'br') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const b = 2.5 * Math.sin(t * 1.4); E('path', { d: `M0 30V-4M0 14L${-14 + b} -2M0 4L${13 + b} -12M${-7 + b / 2} 7L${-18 + b} 4`, stroke: R.c, 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }, o); }; }
    if (k === 'sip') { E('path', { d: 'M-26 20C-10 18 -4 0 10 -6S26 -16 28 -20M-4 6c-6 -10 -8 -18 -6 -24', stroke: R.c, 'stroke-width': 7, fill: 'none', 'stroke-linecap': 'round' }, g); for (let i = 0; i < 9; i++) E('circle', { cx: -22 + i * 6, cy: 18 - i * 4.4, r: 1.3, fill: R.dk }, g); return; }
    if (k === 'par') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const w = 3 * Math.sin(t * 1.6); E('path', { d: `M0 30C-22 18 ${-28 + w} -6 ${-10 + w} -22C-2 -14 2 -26 ${12 - w} -20C${26 - w} -6 18 18 0 30Z`, fill: R.c, stroke: R.dk, opacity: .85 }, o); }; }
    if (k === 'kelp') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const w = 4 * Math.sin(t * 1.2); E('path', { d: `M0 30V10`, stroke: R.dk, 'stroke-width': 3 }, o); E('path', { d: 'M-8 32l4 -4M8 32l-4 -4M0 33v-4', stroke: R.dk, 'stroke-width': 2 }, o); E('path', { d: `M0 12C-14 0 ${-10 + w} -18 ${-4 + w} -28C${4 + w} -18 14 0 0 12Z`, fill: R.c, stroke: R.dk }, o); E('circle', { cx: 0, cy: 12, r: 3, fill: FK.alpha(R.lt, .9), stroke: R.dk }, o); }; }
  }
});

/* ───────── Chlamydomonas কোষ ───────── */
V.algaeCell = Object.assign({
  t: 'একটি আদর্শ শৈবাল কোষ (Chlamydomonas)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'সবুজ শৈবাল Chlamydomonas — সুকেন্দ্রিক এককোষী কোষ: সেলুলোজের কোষপ্রাচীর, সামনে দুটি সমান ফ্ল্যাজেলা ও দুটি সংকোচী গহ্বর, লাল চক্ষুবিন্দু, পেয়ালাকার ক্লোরোপ্লাস্ট ও তাতে শ্বেতসার তৈরির কেন্দ্র পাইরিনয়েড।'
}, BK.diagram({
  W: 360, H: 290, label: 'Chlamydomonas কোষ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const svg = g.ownerSVGElement, Rg = BK.ramp(10), Rw = BK.ramp(11), Rn = BK.ramp(3), Rr = BK.ramp(4);
    const cell = 'M180 72C226 72 236 150 228 192C220 232 140 232 132 192C124 150 134 72 180 72Z';
    const wl = P('wall'); E('path', { d: cell, fill: BK.lg(svg, FK.alpha(Rg.lt, .5), FK.alpha(Rg.c, .12), { a: 90 }), stroke: Rw.dk, 'stroke-width': 3.5 }, wl);
    P('cyto');
    const cp = P('chloro'); E('path', { d: 'M142 108C136 158 146 218 180 218C214 218 224 158 218 108L204 108C206 150 200 178 180 178C160 178 154 150 156 108Z', fill: Rg.c, stroke: Rg.dk, 'stroke-width': 1.4 }, cp);
    const py = P('pyren'); E('circle', { cx: 180, cy: 199, r: 9, fill: FK.alpha(Rg.lt, .95), stroke: Rg.dk, 'stroke-width': 1.6 }, py);
    const st = P('starch'); [[166, 196], [194, 196], [180, 210]].forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: 4, ry: 3, fill: '#fff', stroke: Rg.dk, 'stroke-width': .8 }, st));
    const nu = P('nucleus'); E('circle', { cx: 180, cy: 138, r: 15, fill: FK.alpha(Rn.lt, .9), stroke: Rn.dk, 'stroke-width': 1.6 }, nu); E('circle', { cx: 183, cy: 136, r: 4.5, fill: Rn.dk }, nu);
    const ey = P('eyespot'); E('ellipse', { cx: 146, cy: 116, rx: 4, ry: 7, fill: Rr.c, stroke: Rr.dk }, ey);
    const cv = P('cv'); [[171, 86], [189, 86]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 5, fill: FK.alpha(BK.ramp(5).lt, .7), stroke: BK.ramp(5).dk }, cv));
    P('flag');
  },
  idle(g, C, t) {
    const Rf = BK.ramp(11);
    [-1, 1].forEach(sd => { let d = `M${180 + sd * 4} 73`; for (let j = 1; j <= 10; j++) { const s = j * 6.5, w = 7 * Math.sin(t * 8 - j * .7); const a = -Math.PI / 2 + sd * (.45 + .25 * Math.sin(t * 8)); d += `L${(180 + sd * 4 + s * Math.cos(a) - w * Math.sin(a) * sd).toFixed(1)} ${(73 + s * Math.sin(a) + w * Math.cos(a) * .2).toFixed(1)}`; } E('path', { d, stroke: Rf.dk, 'stroke-width': 1.8, fill: 'none', 'stroke-linecap': 'round' }, g); });
  },
  parts: [
    { id: 'flag', bn: 'ফ্ল্যাজেলা (দুটি, সমান)', lb: 'ফ্ল্যাজেলা', en: 'Flagella', fn: 'সামনের প্রান্তে দুটি সমান দৈর্ঘ্যের চাবুকের মতো ফ্ল্যাজেলা (9 + 2 গঠন) — সাঁতারে সাহায্য করে।', a: [170, 40], l: [108, 26] },
    { id: 'cv', bn: 'সংকোচী গহ্বর', en: 'Contractile vacuole', fn: 'ফ্ল্যাজেলার গোড়ায় দুটি; অতিরিক্ত পানি বের করে অভিস্রবণ নিয়ন্ত্রণ করে — মিঠাপানিতে কোষ ফেটে যাওয়া ঠেকায়।', a: [171, 86], l: [108, 70] },
    { id: 'eyespot', bn: 'চক্ষুবিন্দু (স্টিগমা)', lb: 'চক্ষুবিন্দু', en: 'Eyespot', fn: 'ক্যারোটিনয়েডের লাল দাগ — আলোর দিক বুঝে কোষকে আলোর দিকে সাঁতারে সাহায্য করে (ফটোট্যাক্সিস)।', a: [146, 116], l: [108, 118] },
    { id: 'wall', bn: 'কোষপ্রাচীর (সেলুলোজ বা গ্লাইকোপ্রোটিন)', lb: 'কোষপ্রাচীর', en: 'Cell wall', fn: 'অধিকাংশ সবুজ শৈবালে সেলুলোজ ও পেকটিনের প্রাচীর (Chlamydomonas এ মূলত গ্লাইকোপ্রোটিন); আকৃতি দেয় ও রক্ষা করে।', a: [133, 186], l: [108, 196] },
    { id: 'starch', bn: 'শ্বেতসার দানা', lb: 'শ্বেতসার', en: 'Starch grains', fn: 'সালোকসংশ্লেষণে তৈরি খাদ্য শ্বেতসার হিসেবে জমা থাকে — সবুজ শৈবালের বৈশিষ্ট্য।', a: [166, 196], l: [108, 250] },
    { id: 'cyto', bn: 'সাইটোপ্লাজম', en: 'Cytoplasm', fn: 'কোষঝিল্লির ভেতরের অর্ধতরল অংশ; মাইটোকন্ড্রিয়া, গলজি বস্তু, রাইবোজোম ইত্যাদি এখানে।', a: [196, 104], l: [252, 60] },
    { id: 'nucleus', bn: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'নিউক্লিয়ার ঝিল্লিবেষ্টিত সুগঠিত নিউক্লিয়াস — শৈবাল সুকেন্দ্রিক; ক্লোরোপ্লাস্টের পেয়ালার ভেতরে থাকে।', a: [194, 138], l: [252, 112] },
    { id: 'chloro', bn: 'পেয়ালাকার ক্লোরোপ্লাস্ট', lb: 'ক্লোরোপ্লাস্ট', en: 'Cup-shaped chloroplast', fn: 'একটি বড় পেয়ালার মতো ক্লোরোপ্লাস্ট — ক্লোরোফিল a ও b থাকায় সবুজ; সালোকসংশ্লেষণের স্থান।', a: [216, 160], l: [252, 164] },
    { id: 'pyren', bn: 'পাইরিনয়েড', en: 'Pyrenoid', fn: 'ক্লোরোপ্লাস্টের ভেতরে প্রোটিনসমৃদ্ধ (RuBisCO এনজাইমসমৃদ্ধ) গোল অংশ; চারপাশে শ্বেতসার জমে — শ্বেতসার সৃষ্টির কেন্দ্র।', a: [189, 202], l: [252, 222] }
  ]
}));

/* ───────── ক্লোরোপ্লাস্টের আকৃতি ───────── */
V.chloroShapes = B5.grid({
  t: 'শৈবালের ক্লোরোপ্লাস্টের নানা আকৃতি',
  cap: 'শৈবাল শনাক্তকরণে ক্লোরোপ্লাস্টের আকৃতি গুরুত্বপূর্ণ বৈশিষ্ট্য। ছোট সাদা বিন্দু = পাইরিনয়েড। ঘরে চাপ দাও।',
  cols: 3, ch: 108, ramp: () => 10,
  items: [
    ['cup', 'পেয়ালাকার', 'কোষের বেশির ভাগ জুড়ে পেয়ালার মতো একটি ক্লোরোপ্লাস্ট।', 'Chlamydomonas'],
    ['gir', 'বলয়াকার (গার্ডল)', 'কোষের প্রাচীর ঘেঁষে কোমরবন্ধের মতো খোলা বা বন্ধ বলয়; একাধিক পাইরিনয়েড।', 'Ulothrix'],
    ['spi', 'সর্পিল ফিতাকার', 'এক বা একাধিক ফিতার মতো ক্লোরোপ্লাস্ট সর্পিলভাবে প্যাঁচানো; প্রান্ত ঢেউখেলানো।', 'Spirogyra'],
    ['ste', 'তারকাকার', 'প্রতি কোষে দুটি তারার মতো ক্লোরোপ্লাস্ট, মাঝে নিউক্লিয়াস।', 'Zygnema'],
    ['ret', 'জালিকাকার', 'জালের মতো ছড়ানো ক্লোরোপ্লাস্ট।', 'Oedogonium, Cladophora'],
    ['dis', 'চাকতির মতো', 'অনেকগুলো ছোট চাকতির মতো ক্লোরোপ্লাস্ট।', 'Vaucheria, Chara']
  ],
  draw(g, k, R) {
    const box = () => E('rect', { x: -20, y: -24, width: 40, height: 50, rx: 6, fill: FK.alpha(R.lt, .35), stroke: R.dk, 'stroke-width': 1.2 }, g);
    const py = (x, y) => E('circle', { cx: x, cy: y, r: 2.2, fill: '#fff', stroke: R.dk, 'stroke-width': .6 }, g);
    if (k === 'cup') { E('path', { d: 'M0 -26C18 -26 22 4 18 14C14 28 -14 28 -18 14C-22 4 -18 -26 0 -26Z', fill: FK.alpha(R.lt, .35), stroke: R.dk }, g); E('path', { d: 'M-14 -14C-16 8 -12 22 0 22C12 22 16 8 14 -14L8 -14C9 2 6 10 0 10C-6 10 -9 2 -8 -14Z', fill: R.c }, g); py(0, 16); return; }
    box();
    if (k === 'gir') { E('rect', { x: -20, y: -10, width: 40, height: 20, fill: R.c }, g); E('rect', { x: 10, y: -10, width: 4, height: 20, fill: FK.alpha(R.lt, .8) }, g); [-12, 0, 18].forEach(x => py(x, 0)); return; }
    if (k === 'spi') { const o = E('path', { fill: 'none', stroke: R.c, 'stroke-width': 5, 'stroke-linecap': 'round' }, g); return t => { let d = ''; for (let j = 0; j <= 20; j++) { const y = -22 + j * 2.3, x = 15 * Math.sin(j * .6 + t * 1.5); d += (j ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } o.setAttribute('d', d); }; }
    if (k === 'ste') { [-11, 11].forEach(cy => { let d = ''; for (let j = 0; j < 16; j++) { const a = j / 16 * 6.283, r = j % 2 ? 4 : 10; d += (j ? 'L' : 'M') + (r * Math.cos(a)).toFixed(1) + ' ' + (cy + r * Math.sin(a)).toFixed(1); } E('path', { d: d + 'Z', fill: R.c }, g); py(0, cy); }); E('circle', { cx: 0, cy: 0, r: 3, fill: BK.ramp(5).dk }, g); return; }
    if (k === 'ret') { E('path', { d: 'M-16 -20L-4 -8L10 -20M-4 -8L-6 8L-16 20M-6 8L10 6L14 20M10 6L10 -20M-16 -2L-6 8', stroke: R.c, 'stroke-width': 3.2, fill: 'none', 'stroke-linejoin': 'round' }, g); py(-4, -8); py(10, 6); return; }
    if (k === 'dis') { for (let i = 0; i < 14; i++) E('ellipse', { cx: -13 + (i % 4) * 8.7, cy: -18 + Math.floor(i / 4) * 12, rx: 3.6, ry: 2.6, fill: R.c }, g); }
  }
});

/* ───────── শ্রেণি ও জনন ───────── */
V.algaeClass = Object.assign({ t: 'রঞ্জক ও সঞ্চিত খাদ্য অনুযায়ী শৈবালের প্রধান শ্রেণি', k: ['tree', 'int'], cap: 'প্রধান রঞ্জক, সঞ্চিত খাদ্য ও কোষপ্রাচীরের উপাদান দিয়ে শৈবালের শ্রেণি চেনা যায়। (নীলাভ সবুজ "শৈবাল" আসলে আদিকোষী সায়ানোব্যাকটেরিয়া।)' }, BK.tree({
  t: 'শৈবাল', d: 'সালোকসংশ্লেষী, থ্যালয়েড, প্রধানত জলজ সুকেন্দ্রিক জীব।',
  c: [
    { t: 'সবুজ শৈবাল', d: 'Chlorophyceae — ক্লোরোফিল a ও b; সঞ্চিত খাদ্য শ্বেতসার; প্রাচীর সেলুলোজ; সমান দৈর্ঘ্যের ফ্ল্যাজেলা।', c: [{ t: 'উদাহরণ', d: 'Ulothrix, Chlamydomonas, Spirogyra, Volvox, Ulva।' }] },
    { t: 'বাদামি শৈবাল', d: 'Phaeophyceae — ক্লোরোফিল a ও c, ফিউকোজ্যান্থিন; সঞ্চিত খাদ্য ল্যামিনারিন ও ম্যানিটল; প্রাচীরে অ্যালজিন।', c: [{ t: 'উদাহরণ', d: 'Sargassum, Laminaria, Fucus — প্রায় সবই সামুদ্রিক।' }] },
    { t: 'লাল শৈবাল', d: 'Rhodophyceae — ক্লোরোফিল a, ফাইকোইরিথ্রিন ও ফাইকোসায়ানিন; ফ্লোরিডিয়ান শ্বেতসার; ফ্ল্যাজেলাযুক্ত দশা নেই।', c: [{ t: 'উদাহরণ', d: 'Gracilaria, Gelidium (আগার), Porphyra (নরি), Polysiphonia।' }] },
    { t: 'ডায়াটম', d: 'Bacillariophyceae — ক্লোরোফিল a ও c, ফিউকোজ্যান্থিন; সিলিকার দুই খণ্ডের খোলস; তেল সঞ্চয়।', c: [{ t: 'উদাহরণ', d: 'Navicula, Pinnularia; সাগরের প্রধান উদ্ভিদ-প্লাংকটন।' }] }
  ]
}, { colW: 120 }));

V.algaeRepro = Object.assign({ t: 'শৈবালের জননের প্রকারভেদ', k: ['tree', 'int'], cap: 'অঙ্গজ, অযৌন ও যৌন — তিন ধরনের জনন। যৌন জননে গ্যামিটের আকার ও আচরণ অনুযায়ী তিন ধরন।' }, BK.tree({
  t: 'শৈবালের জনন', d: 'অঙ্গজ, অযৌন ও যৌন।',
  c: [
    { t: 'অঙ্গজ', d: 'দেহের অংশ থেকে নতুন জীব।', c: [{ t: 'কোষ বিভাজন', d: 'এককোষীতে — Chlamydomonas, ডায়াটম।' }, { t: 'খণ্ডায়ন', d: 'ফিলামেন্ট ভেঙে টুকরা থেকে নতুন ফিলামেন্ট — Ulothrix, Spirogyra।' }, { t: 'অস্থানিক শাখা ও কন্দ', d: 'Chara এর তারকাকার কন্দ (বুলবিল)।' }] },
    { t: 'অযৌন', d: 'বিশেষ স্পোর দিয়ে; মায়োসিস নেই।', c: [{ t: 'জুস্পোর', d: 'ফ্ল্যাজেলাযুক্ত চলনশীল স্পোর — Ulothrix (চার ফ্ল্যাজেলা)।' }, { t: 'অ্যাপ্লানোস্পোর', d: 'ফ্ল্যাজেলাহীন পাতলা প্রাচীরের স্পোর।' }, { t: 'হিপনোস্পোর ও অ্যাকাইনিট', d: 'পুরু প্রাচীরের প্রতিকূলতা-সহিষ্ণু স্পোর ও কোষ।' }] },
    { t: 'যৌন', d: 'গ্যামিট মিলনে জাইগোট।', c: [{ t: 'আইসোগ্যামি', d: 'দুই গ্যামিট আকারে ও আচরণে এক — Ulothrix।' }, { t: 'অ্যানাইসোগ্যামি', d: 'দুটিই চলনশীল কিন্তু আকারে ভিন্ন — Chlamydomonas braunii।' }, { t: 'উগ্যামি', d: 'বড় অচল ডিম্বাণু + ছোট চলনশীল শুক্রাণু — Volvox, Oedogonium, Chara।' }] }
  ]
}, { colW: 120 }));

/* ───────── গ্যামিট মিলনের ধরন ───────── */
const GT = {
  iso: ['আইসোগ্যামি', 'দুটি গ্যামিট আকার, গঠন ও আচরণে অভিন্ন — দুটিই চলনশীল। পুং-স্ত্রী আলাদা করা যায় না; কেবল + ও − স্ট্রেইন।', 'Ulothrix, অনেক Chlamydomonas প্রজাতি', [7, 7], [true, true]],
  aniso: ['অ্যানাইসোগ্যামি', 'দুটি গ্যামিটই চলনশীল, কিন্তু আকারে ভিন্ন — বড়টি স্ত্রী, ছোটটি পুং।', 'Chlamydomonas braunii', [10, 5], [true, true]],
  oo: ['উগ্যামি', 'বড়, খাদ্যসমৃদ্ধ, অচল স্ত্রী গ্যামিট (ডিম্বাণু) ও ছোট, চলনশীল পুং গ্যামিট (শুক্রাণু)। ডিম্বাণু সাধারণত উগোনিয়ামের ভেতরে থাকে।', 'Volvox, Oedogonium, Chara, Fucus', [16, 4], [false, true]]
};
V.gameteTypes = {
  t: 'যৌন জননের তিন ধরন — গ্যামিটের মিলন', k: ['2d', 'anim', 'int'],
  cap: 'বিবর্তনের ধারায় শৈবালে আইসোগ্যামি → অ্যানাইসোগ্যামি → উগ্যামি দেখা যায় — শেষটিতে স্ত্রী গ্যামিট খাদ্য সঞ্চয় করে অচল হয়েছে। প্রতিটির মিলনে ডিপ্লয়েড জাইগোট। ধরন বদলে চালাও।',
  html: () => `<div class="fk-row">${X.seg('gt', Object.keys(GT).map(k => [k, GT[k][0]]), 'iso')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 190;
    let ty = 'iso', C, svg, layer, tl, tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = '';
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'গ্যামিট মিলন' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      layer = E('g', {}, svg);
      T(svg, 60, 34, ty === 'iso' ? '+ স্ট্রেইন' : 'স্ত্রী গ্যামিট', { fs: 12, a: 'middle', w: 650, c: BK.ramp(0).ink }); T(svg, 300, 34, ty === 'iso' ? '− স্ট্রেইন' : 'পুং গ্যামিট', { fs: 12, a: 'middle', w: 650, c: BK.ramp(5).ink });
      tl = T(svg, W / 2, H - 14, '', { fs: 11.5, a: 'middle', w: 600, c: C.fg });
      const g = GT[ty]; $('info').innerHTML = `<b>${g[0]}</b> — ${g[1]}<div class="small">উদাহরণ: <i>${g[2]}</i></div>`;
      step(0);
    };
    const step = dt => {
      tt = (tt + dt) % 4; const g = GT[ty], [r1, r2] = g[3], [m1, m2] = g[4], R1 = BK.ramp(0), R2 = BK.ramp(5), Rz = BK.ramp(10);
      layer.innerHTML = ''; const k = Math.min(1, tt / 2.2), y = 82;
      if (k < 1) {
        const x1 = m1 ? 60 + (180 - r1 - 60) * k : 180 - r1, x2 = 300 - (300 - 180 - r2) * k;
        if (!m1 && ty === 'oo') E('circle', { cx: 180 - r1 + 0, cy: y, r: r1 + 8, fill: 'none', stroke: R1.dk, 'stroke-dasharray': '3 3' }, layer);
        if (m1) B5.swimmer(layer, x1, y, r1, 2, R1, tt, 0); else E('circle', { cx: x1, cy: y, r: r1, fill: R1.c, stroke: R1.dk }, layer);
        B5.swimmer(layer, x2, y, r2, 2, R2, tt, Math.PI);
        const s = 'গ্যামিট দুটি কাছে আসছে'; if (tl.textContent !== s) tl.textContent = s;
      } else {
        const rz = Math.max(r1, r2) + 3, ring = Math.min(1, (tt - 2.2) / .6);
        E('circle', { cx: 180, cy: y, r: rz, fill: Rz.c, stroke: Rz.dk, 'stroke-width': 1 + 3 * ring }, layer);
        E('circle', { cx: 180, cy: y, r: 3.5, fill: Rz.dk }, layer);
        const s = 'জাইগোট (2n)'; if (tl.textContent !== s) tl.textContent = s;
      }
      
    };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'gt', v => { ty = v; tt = 0; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── Ulothrix ফিলামেন্ট ───────── */
const UX = 180, UW = 44, UH = 34, UY0 = 34;
V.ulothrixFil = Object.assign({
  t: 'Ulothrix এর ফিলামেন্টের গঠন', k: ['2d', 'label', 'int', 'anim'],
  cap: 'মিঠাপানির ঠান্ডা স্রোতে পাথরে আটকে থাকা অশাখ ফিলামেন্ট। গোড়ার লম্বাটে বর্ণহীন কোষ (হোল্ডফাস্ট) আটকে রাখে; বাকি প্রতিটি কোষ একই রকম — এক নিউক্লিয়াস ও একটি বলয়াকার ক্লোরোপ্লাস্ট, তাতে কয়েকটি পাইরিনয়েড। শীর্ষকোষ গোলাকার।'
}, BK.diagram({
  W: 360, H: 300, label: 'Ulothrix ফিলামেন্ট',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rg = BK.ramp(10), Rw = BK.ramp(11), Rn = BK.ramp(3);
    const n = 6, yb = UY0 + n * UH;
    const ap = P('apical'); E('path', { d: `M${UX - UW / 2} ${UY0 + UH}V${UY0 + 10}Q${UX - UW / 2} ${UY0} ${UX} ${UY0}Q${UX + UW / 2} ${UY0} ${UX + UW / 2} ${UY0 + 10}V${UY0 + UH}`, fill: FK.alpha(Rg.lt, .4), stroke: Rw.dk, 'stroke-width': 2.4 }, ap);
    const wl = P('wall'); for (let i = 1; i < n; i++) E('rect', { x: UX - UW / 2, y: UY0 + i * UH, width: UW, height: UH, fill: FK.alpha(Rg.lt, .4), stroke: Rw.dk, 'stroke-width': 2.4 }, wl);
    const sp = P('septum'); for (let i = 1; i <= n; i++) E('path', { d: `M${UX - UW / 2} ${UY0 + i * UH}H${UX + UW / 2}`, stroke: Rw.dk, 'stroke-width': 3 }, sp);
    const vc = P('vacuole'); for (let i = 0; i < n; i++) { const y = UY0 + i * UH; E('rect', { x: UX - UW / 2 + 3, y: y + 3 + (i === 0 ? 6 : 0), width: UW - 6, height: 5, fill: FK.alpha(BK.ramp(5).lt, .6) }, vc); E('rect', { x: UX - UW / 2 + 3, y: y + UH - 8, width: UW - 6, height: 5, fill: FK.alpha(BK.ramp(5).lt, .6) }, vc); }
    const cp = P('chloro'); for (let i = 0; i < n; i++) { const y = UY0 + i * UH; E('rect', { x: UX - UW / 2 + 2, y: y + 9, width: UW - 4, height: UH - 18, fill: Rg.c, stroke: Rg.dk, 'stroke-width': .8 }, cp); E('rect', { x: UX + UW / 2 - 9, y: y + 9, width: 5, height: UH - 18, fill: FK.alpha(Rg.lt, .8) }, cp); }
    const py = P('pyren'); for (let i = 0; i < n; i++) { const y = UY0 + i * UH + UH / 2; [-14, 12].forEach(dx => E('circle', { cx: UX + dx, cy: y, r: 2.6, fill: '#fff', stroke: Rg.dk, 'stroke-width': .8 }, py)); }
    const nu = P('nucleus'); for (let i = 0; i < n; i++) E('ellipse', { cx: UX - 1, cy: UY0 + i * UH + UH / 2, rx: 6, ry: 5, fill: FK.alpha(Rn.lt, .95), stroke: Rn.dk, 'stroke-width': 1.2 }, nu);
    const hf = P('holdfast'); E('path', { d: `M${UX - UW / 2 + 4} ${yb}C${UX - 18} ${yb + 18} ${UX - 10} ${yb + 26} ${UX - 22} ${yb + 40}M${UX - 12} ${yb + 28}L${UX - 4} ${yb + 42}M${UX + UW / 2 - 4} ${yb}C${UX + 16} ${yb + 18} ${UX + 10} ${yb + 26} ${UX + 20} ${yb + 40}`, stroke: Rw.dk, 'stroke-width': 2.4, fill: 'none' }, hf); E('path', { d: `M${UX - UW / 2 + 4} ${yb}C${UX - 16} ${yb + 18} ${UX + 14} ${yb + 18} ${UX + UW / 2 - 4} ${yb}Z`, fill: FK.alpha(C.mu, .12) }, hf);
    E('path', { d: `M${UX - 60} ${yb + 44}H${UX + 60}`, stroke: C.mu, 'stroke-width': 4, 'stroke-linecap': 'round', opacity: .5 }, g);
  },
  idle(g, C, t) { const R = BK.ramp(5); for (let i = 0; i < 8; i++) { const y = 30 + i * 32, x = ((t * 40 + i * 47) % 120); [UX - 120 + x * .7, UX + 50 + x * .7].forEach(xx => E('path', { d: `M${xx.toFixed(1)} ${y}h14`, stroke: R.c, 'stroke-width': 1.4, opacity: .45, 'stroke-linecap': 'round' }, g)); } },
  parts: [
    { id: 'apical', bn: 'শীর্ষকোষ', en: 'Apical cell', fn: 'ফিলামেন্টের মাথার গোলাকার কোষ; অন্য কোষের মতোই ক্লোরোপ্লাস্টযুক্ত।', a: [UX - 16, UY0 + 6], l: [138, 22] },
    { id: 'wall', bn: 'কোষপ্রাচীর', en: 'Cell wall', fn: 'ভেতরে সেলুলোজ, বাইরে পেকটিন জাতীয় পদার্থের পাতলা প্রাচীর।', a: [UX - UW / 2, UY0 + 1.5 * UH], l: [138, 64] },
    { id: 'chloro', bn: 'বলয়াকার ক্লোরোপ্লাস্ট', lb: 'ক্লোরোপ্লাস্ট', en: 'Girdle-shaped chloroplast', fn: 'প্রতি কোষে একটি কোমরবন্ধ বা বলয়ের মতো (খোলা বা বন্ধ) ক্লোরোপ্লাস্ট — প্রাচীরের ভেতরের দিক ঘেঁষে কোষের মাঝ বরাবর থাকে।', a: [UX + UW / 2 - 2, UY0 + 2.5 * UH - 4], l: [222, 100] },
    { id: 'pyren', bn: 'পাইরিনয়েড', en: 'Pyrenoid', fn: 'ক্লোরোপ্লাস্টে এক বা একাধিক — শ্বেতসার তৈরির কেন্দ্র।', a: [UX + 12, UY0 + 3.5 * UH], l: [222, 150] },
    { id: 'nucleus', bn: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'প্রতিটি কোষে একটি নিউক্লিয়াস (হ্যাপ্লয়েড) — কোষের মাঝখানে।', a: [UX - 1, UY0 + 2.5 * UH], l: [138, 118] },
    { id: 'vacuole', bn: 'কোষগহ্বর', en: 'Vacuole', fn: 'কোষরসপূর্ণ গহ্বর — কোষের দুই প্রান্তের দিকে।', a: [UX - 10, UY0 + 4 * UH - 5], l: [138, 172] },
    { id: 'septum', bn: 'প্রস্থপ্রাচীর', en: 'Cross wall', fn: 'পাশাপাশি দুই কোষের মাঝের প্রাচীর — Ulothrix এর ফিলামেন্ট কোষে বিভক্ত (সিনোসাইটিক নয়)।', a: [UX + UW / 2, UY0 + 5 * UH], l: [222, 200] },
    { id: 'holdfast', bn: 'হোল্ডফাস্ট (মূলকোষ)', lb: 'হোল্ডফাস্ট', en: 'Holdfast / basal cell', fn: 'গোড়ার লম্বাটে, প্রায় বর্ণহীন কোষ — পাথর বা অন্য বস্তুতে ফিলামেন্টকে আটকে রাখে; সাধারণত বিভাজিত হয় না।', a: [UX - 10, UY0 + 6 * UH + 22], l: [138, 262] }
  ]
}));

/* ───────── Ulothrix জীবনচক্র ───────── */
V.ulothrixCycle = Object.assign({
  t: 'Ulothrix এর জীবনচক্র', k: ['2d', 'anim', 'int'],
  cap: 'হ্যাপ্লন্টিক জীবনচক্র: ফিলামেন্টের প্রতিটি কোষ হ্যাপ্লয়েড (n); কেবল জাইগোট ডিপ্লয়েড (2n), এবং জাইগোট অঙ্কুরোদ্গমের সময়েই মায়োসিস হয়। অনুকূল পরিবেশে অযৌন জুস্পোর, প্রতিকূলতার শুরুতে যৌন গ্যামিট তৈরি হয়।'
}, BK.steps({
  W: 360, H: 250, label: 'Ulothrix জীবনচক্র', dur: 2.6,
  stages: [
    { t: 'হ্যাপ্লয়েড ফিলামেন্ট', en: 'Haploid filament (n)', d: 'প্রতিটি কোষে একটি হ্যাপ্লয়েড নিউক্লিয়াস। খণ্ডায়নে টুকরা থেকেও নতুন ফিলামেন্ট হয় (অঙ্গজ জনন)।' },
    { t: 'জুস্পোর (অযৌন)', en: 'Zoospores', d: 'যেকোনো কোষ (হোল্ডফাস্ট ছাড়া) থেকে 2–32টি চার-ফ্ল্যাজেলাযুক্ত জুস্পোর; প্রাচীরের ছিদ্র দিয়ে বেরিয়ে সাঁতরে কোথাও আটকে নতুন ফিলামেন্ট গড়ে।' },
    { t: 'গ্যামিট গঠন', en: 'Gametes', d: 'প্রতিকূলতার শুরুতে কোষে 8–64টি দুই-ফ্ল্যাজেলাযুক্ত ছোট গ্যামিট তৈরি হয়ে পানিতে মুক্ত হয়।' },
    { t: 'আইসোগ্যামি → জাইগোট', en: 'Isogamy', d: 'ভিন্ন ফিলামেন্টের (+ ও −) দুটি একই রকম গ্যামিট মিলে চার-ফ্ল্যাজেলাযুক্ত জাইগোট; পরে ফ্ল্যাজেলা হারিয়ে পুরু প্রাচীরের বিশ্রামরত জাইগোট (2n)।' },
    { t: 'মায়োসিস → নতুন ফিলামেন্ট', en: 'Meiosis', d: 'অনুকূল পরিবেশে জাইগোটে মায়োসিস হয়ে 4–16টি হ্যাপ্লয়েড জুস্পোর বা অ্যাপ্লানোস্পোর (মিওস্পোর); প্রতিটি থেকে নতুন ফিলামেন্ট।' }
  ],
  draw(g, C, s, u, t = 0) {
    const Rg = BK.ramp(10), Rw = BK.ramp(11), Rz = BK.ramp(0), Rp = BK.ramp(5), Rm = BK.ramp(1);
    const svg = g.ownerSVGElement; if (!svg._b5u) { svg._b5u = 1; svg._ph = 0; }
    svg._ph += .03; const ph = svg._ph;
    const fil = (x0, y, n, rel, col) => { for (let i = 0; i < n; i++) { const x = x0 + i * 24; E('rect', { x, y: y - 10, width: 24, height: 20, fill: i === rel ? FK.alpha(Rg.lt, .5) : FK.alpha(Rg.lt, .35), stroke: Rw.dk, 'stroke-width': 1.4 }, g); if (i !== rel) { E('rect', { x: x + 1, y: y - 5, width: 22, height: 10, fill: col || Rg.c }, g); E('circle', { cx: x + 12, cy: y, r: 2.6, fill: BK.ramp(5).lt, stroke: BK.ramp(5).dk, 'stroke-width': .6 }, g); } } E('path', { d: `M${x0} ${y - 10}q-10 10 0 20`, stroke: Rw.dk, 'stroke-width': 1.4, fill: FK.alpha(C.mu, .15) }, g); };
    const tag = (x, y, s2, c) => T(g, x, y, s2, { fs: 10.5, a: 'middle', w: 650, c });
    if (s === 0) { fil(60, 120, 10, -1); tag(180, 160, 'n', Rg.ink); const b = 40 + 200 * u; E('path', { d: `M${b} 104v32`, stroke: C.bad, 'stroke-width': 1.6, 'stroke-dasharray': '3 3', opacity: .7 }, g); }
    if (s === 1) { fil(60, 80, 10, 4); for (let i = 0; i < 4; i++) { const a = -1.2 + i * .8, d = 10 + 80 * u; B5.swimmer(g, 168 + d * Math.cos(a + .6), 80 + 20 + d * Math.sin(a + .6) * .9, 5, 4, Rg, ph, a + .6); } tag(180, 220, 'চার-ফ্ল্যাজেলাযুক্ত জুস্পোর (n)', Rg.ink); }
    if (s === 2) { fil(20, 60, 6, 3, Rg.c); fil(196, 60, 6, 2, Rm.c); tag(80, 40, '+', Rg.ink); tag(256, 40, '−', Rm.ink); for (let i = 0; i < 6; i++) { B5.swimmer(g, 92 + (i % 3) * 10 + 30 * u * Math.cos(i), 90 + 60 * u + (i > 2 ? 10 : 0), 3.2, 2, Rg, ph + i, Math.PI / 2 + Math.sin(i)); B5.swimmer(g, 256 + (i % 3) * 10 - 30 * u * Math.cos(i), 90 + 60 * u + (i > 2 ? 10 : 0), 3.2, 2, Rm, ph + i, Math.PI / 2 - Math.sin(i)); } tag(180, 220, 'দুই-ফ্ল্যাজেলাযুক্ত গ্যামিট (n)', C.fg); }
    if (s === 3) { const k = Math.min(1, u * 1.6); if (k < 1) { B5.swimmer(g, 120 + 52 * k, 110, 4, 2, Rg, ph, 0); B5.swimmer(g, 240 - 52 * k, 110, 4, 2, Rm, ph, Math.PI); } else { const w = (u - .62) / .38; if (w < .5) B5.swimmer(g, 180, 110, 7, 4, Rz, ph); else { E('circle', { cx: 180, cy: 110, r: 14, fill: Rz.c, stroke: Rz.dk, 'stroke-width': 2 + 4 * (w - .5) }, g); } } tag(180, 160, k < 1 ? '+ গ্যামিট      − গ্যামিট' : 'জাইগোট (2n)', Rz.ink); }
    if (s === 4) { const k = Math.min(1, u * 1.4); E('circle', { cx: 180, cy: 90, r: 14, fill: FK.alpha(Rz.c, 1 - k * .7), stroke: Rz.dk, 'stroke-width': 4, 'stroke-dasharray': k > .5 ? '4 3' : null }, g); for (let i = 0; i < 4; i++) { const a = i * 1.571 + .785, d = 6 + 50 * k; B5.swimmer(g, 180 + d * Math.cos(a), 90 + d * Math.sin(a), 4, 4, Rg, ph + i, a); } tag(180, 30, 'মায়োসিস: 2n → n', Rp.ink); if (u > .7) { const f = (u - .7) / .3; for (let i = 0; i < 4; i++) { const x = 40 + i * 80; for (let j = 0; j < Math.ceil(f * 4); j++) E('rect', { x: x - 6, y: 200 - j * 12, width: 12, height: 12, fill: FK.alpha(Rg.c, .8), stroke: Rw.dk, 'stroke-width': 1 }, g); } } tag(180, 228, 'মিওস্পোর → নতুন ফিলামেন্ট (n)', Rg.ink); }
  }
}));

/* ───────── অর্থনৈতিক গুরুত্ব ───────── */
V.algaeEcon = Object.assign({ t: 'শৈবালের অর্থনৈতিক গুরুত্ব', k: ['mind', 'int'], cap: 'উপকারী ও অপকারী দিক। পাতায় চাপ দিলে বিস্তারিত।' }, BK.mind({
  t: 'শৈবালের গুরুত্ব', d: 'খাদ্য, শিল্প, কৃষি, পরিবেশ ও গবেষণা; আবার কিছু ক্ষতি।',
  c: [
    { t: 'খাদ্য ও পশুখাদ্য', d: 'মানুষ ও প্রাণীর খাদ্য।', c: [{ t: 'মানুষের খাদ্য', d: 'Porphyra (নরি), Ulva (সামুদ্রিক লেটুস), Laminaria (কম্বু); Chlorella প্রোটিন সম্পূরক।' }, { t: 'মাছের খাদ্য', d: 'উদ্ভিদ-প্লাংকটন জলজ খাদ্যশৃঙ্খলের ভিত্তি।' }] },
    { t: 'শিল্প', d: 'শৈবালজাত রাসায়নিক।', c: [{ t: 'আগার', d: 'Gelidium, Gracilaria — অণুজীবের কালচার মাধ্যম, জেলি, আইসক্রিম।' }, { t: 'অ্যালজিন ও ক্যারাজিনান', d: 'বাদামি ও লাল শৈবাল — খাদ্য, প্রসাধনী, ওষুধে ঘনত্ব বাড়ায়।' }, { t: 'আয়োডিন ও ডায়াটোমাইট', d: 'কেল্প থেকে আয়োডিন; ডায়াটমের খোলস থেকে ফিল্টার ও ঘষামাজার পাউডার।' }] },
    { t: 'কৃষি ও পরিবেশ', d: 'জমি ও বায়ুমণ্ডল।', c: [{ t: 'অক্সিজেন', d: 'পৃথিবীর সালোকসংশ্লেষণের প্রায় অর্ধেক সমুদ্রের প্লাংকটনে (শৈবাল ও সায়ানোব্যাকটেরিয়া)।' }, { t: 'জৈবসার', d: 'সামুদ্রিক শৈবাল সার হিসেবে।' }, { t: 'জৈবজ্বালানি ও বর্জ্য শোধন', d: 'তেলসমৃদ্ধ শৈবাল থেকে বায়োডিজেল গবেষণা; পয়ঃশোধনে অক্সিজেন জোগায়।' }] },
    { t: 'গবেষণা', d: 'মৌলিক বিজ্ঞান।', c: [{ t: 'ক্যালভিন চক্র', d: 'মেলভিন ক্যালভিন Chlorella ব্যবহার করে সালোকসংশ্লেষণের অন্ধকার বিক্রিয়ার পথ বের করেন।' }] },
    { t: 'অপকারী দিক', d: 'ক্ষতি।', c: [{ t: 'শৈবাল প্রস্ফুটন', d: 'অতিরিক্ত পুষ্টিতে (ইউট্রোফিকেশন) পানিতে অক্সিজেন কমে মাছ মরে।' }, { t: 'লাল জোয়ার', d: 'কিছু ডাইনোফ্ল্যাজেলেটের বিষে মাছ ও শামুক বিষাক্ত হয়।' }, { t: 'চায়ের লাল মরিচা', d: 'পরজীবী শৈবাল Cephaleuros virescens চা গাছের পাতা ও কাণ্ডে রোগ ঘটায়।' }, { t: 'পানি সরবরাহে সমস্যা', d: 'পাইপ ও ফিল্টার বন্ধ, পানিতে দুর্গন্ধ।' }] }
  ]
}));
})();
