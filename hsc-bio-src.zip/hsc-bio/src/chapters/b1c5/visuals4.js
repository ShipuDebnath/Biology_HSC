/* ═══════════════════════════════════════════════════════════════════
   visuals4 — §৫.৪ লাইকেন ও §৫.৫ সার-সংক্ষেপ
   lichenSection: হেটারোমেরাস লাইকেন থ্যালাসের প্রস্থচ্ছেদ — চিহ্নিত চিত্র (সোরেডিয়া ঝরে)
   lichenTypes  : ক্রাস্টোজ, ফোলিওজ, ফ্রুটিকোজ — গ্রিড
   lichenExchange: শৈবাল ও ছত্রাকের পারস্পরিক আদান-প্রদান — চলমান কণা; সবুজ শৈবাল বনাম সায়ানোব্যাকটেরিয়া
   lichenSO2    : বায়ুদূষণের নির্দেশক — SO₂ স্লাইডার, কোন লাইকেন টিকে থাকে (আনুমানিক অঞ্চল)
   lichenUses   : লাইকেনের গুরুত্ব — মাইন্ড ম্যাপ
   b1c5map      : অধ্যায়ের মাইন্ড ম্যাপ
   নোট: SO₂ সীমা হকসওয়ার্থ ও রোজ (1970) স্কেলের ভাবধারায় শিক্ষামূলক সরলীকরণ — সংখ্যা আনুমানিক।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B5 = window.B5;

V.lichenSection = Object.assign({
  t: 'লাইকেন থ্যালাসের প্রস্থচ্ছেদ (হেটারোমেরাস)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'ফোলিওজ লাইকেনে স্তরগুলো আলাদা (হেটারোমেরাস): উপরের ঘন ছত্রাক-স্তর কর্টেক্স, তার নিচে শৈবাল-স্তর, মাঝে ঢিলা হাইফার মেডুলা, নিচের কর্টেক্স এবং আটকে থাকার রাইজাইন। দেহের বেশির ভাগই ছত্রাক। উপরে সোরেডিয়া — শৈবালকোষ ঘিরে থাকা হাইফার গুঁড়া — অঙ্গজ জননের একক।'
}, BK.diagram({
  W: 360, H: 290, label: 'লাইকেনের প্রস্থচ্ছেদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rf = BK.ramp(9), Ra = BK.ramp(10), Rw = BK.ramp(11), Rs = BK.ramp(6);
    const X0 = 30, X1 = 280;
    const uc = P('ucortex'); E('rect', { x: X0, y: 50, width: X1 - X0, height: 30, rx: 6, fill: FK.alpha(Rf.c, .55), stroke: Rf.dk }, uc); for (let i = 0; i < 24; i++) E('path', { d: `M${X0 + 6 + i * 10.4} 54v22`, stroke: Rf.dk, 'stroke-width': .8, opacity: .6 }, uc);
    const al = P('algal'); E('rect', { x: X0, y: 80, width: X1 - X0, height: 34, fill: FK.alpha(Ra.lt, .45) }, al); for (let i = 0; i < 30; i++) E('circle', { cx: X0 + 8 + (i * 37) % (X1 - X0 - 16), cy: 86 + (i * 11) % 24, r: 5, fill: Ra.c, stroke: Ra.dk, 'stroke-width': .8 }, al);
    const md = P('medulla'); E('rect', { x: X0, y: 114, width: X1 - X0, height: 70, fill: FK.alpha(Rf.lt, .3) }, md); for (let i = 0; i < 16; i++) E('path', { d: `M${X0 + (i * 53) % 220} ${118 + (i % 4) * 14}C${X0 + 40 + (i * 31) % 190} ${130 + (i * 7) % 40} ${X0 + 80 + (i * 17) % 150} ${120 + (i * 13) % 50} ${X0 + 120 + (i * 29) % 120} ${150 + (i % 5) * 6}`, stroke: Rf.dk, 'stroke-width': 1, fill: 'none', opacity: .75 }, md);
    const lc = P('lcortex'); E('rect', { x: X0, y: 184, width: X1 - X0, height: 18, rx: 4, fill: FK.alpha(Rf.c, .5), stroke: Rf.dk }, lc);
    const rz = P('rhizine'); for (let i = 0; i < 6; i++) { const x = X0 + 24 + i * 42; E('path', { d: `M${x} 202V236M${x} 228l-8 8M${x} 224l7 9`, stroke: Rf.dk, 'stroke-width': 2, fill: 'none' }, rz); }
    E('rect', { x: 14, y: 236, width: 282, height: 22, rx: 4, fill: FK.alpha(Rw.c, .35) }, g); T(g, 155, 251, 'আশ্রয়স্থল: গাছের বাকল বা পাথর', { fs: 10, a: 'middle', w: 560, c: Rw.ink });
    const so = P('soredia'); [[100, 44], [210, 42]].forEach(([x, y]) => { E('path', { d: `M${x - 16} 50Q${x} 30 ${x + 16} 50`, fill: FK.alpha(Rs.lt, .6), stroke: Rs.dk }, so); });
  },
  idle(g, C, t) { const Ra = BK.ramp(10), Rf = BK.ramp(9); for (let i = 0; i < 8; i++) { const f = (t * .3 + i / 8) % 1, x0 = i % 2 ? 210 : 100, x = x0 - 10 + (i * 7) % 20 + 30 * f, y = 40 - 30 * f; E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 3.4, fill: Ra.c, stroke: Rf.dk, 'stroke-width': 1.2, opacity: (1 - f).toFixed(2) }, g); } },
  parts: [
    { id: 'soredia', bn: 'সোরেডিয়া', en: 'Soredia', fn: 'কয়েকটি শৈবালকোষকে ঘিরে হাইফার ছোট গুঁড়ার মতো দানা — বাতাসে ছড়িয়ে নতুন লাইকেন তৈরি করে (দুই সঙ্গী একসাথে যায়)।', a: [100, 40], l: [50, 20], an: 'middle' },
    { id: 'ucortex', bn: 'উপরিস্তরের কর্টেক্স', lb: 'উপরের কর্টেক্স', en: 'Upper cortex', fn: 'ঘনভাবে সাজানো ছত্রাক হাইফা — রক্ষা করে, অতিরিক্ত আলো ও অতিবেগুনি রশ্মি আটকায় (অনেক সময় রঞ্জকযুক্ত)।', a: [250, 64], l: [260, 20], an: 'middle' },
    { id: 'algal', bn: 'শৈবাল-স্তর (গোনিডিয়াল স্তর)', lb: 'শৈবাল-স্তর', en: 'Algal (photobiont) layer', fn: 'হাইফার ফাঁকে ফাঁকে সবুজ শৈবাল (যেমন Trebouxia) বা সায়ানোব্যাকটেরিয়া (Nostoc) — সালোকসংশ্লেষণে খাদ্য তৈরি করে।', a: [276, 96], l: [290, 100], an: 'start' },
    { id: 'medulla', bn: 'মেডুলা', en: 'Medulla', fn: 'ঢিলাভাবে জড়ানো হাইফার স্তর, বায়ুপূর্ণ ফাঁক — পানি জমিয়ে রাখে ও গ্যাস চলাচলে সাহায্য করে; দেহের সবচেয়ে পুরু অংশ।', a: [250, 150], l: [290, 150], an: 'start' },
    { id: 'lcortex', bn: 'নিম্নস্তরের কর্টেক্স', lb: 'নিচের কর্টেক্স', en: 'Lower cortex', fn: 'নিচের ঘন হাইফার স্তর।', a: [70, 192], l: [30, 172], an: 'start' },
    { id: 'rhizine', bn: 'রাইজাইন', en: 'Rhizines', fn: 'নিচের কর্টেক্স থেকে বের হওয়া হাইফার গুচ্ছ — আশ্রয়স্থলে আটকে রাখে; প্রকৃত মূল নয়, পানি শোষণে সামান্য ভূমিকা।', a: [116, 226], l: [40, 280], an: 'middle' }
  ]
}));

V.lichenTypes = B5.grid({
  t: 'থ্যালাসের আকৃতি অনুযায়ী লাইকেনের প্রকারভেদ',
  cap: 'থ্যালাসের আকৃতি ও আশ্রয়ের সাথে আটকে থাকার ধরন অনুযায়ী প্রধান তিন ধরন। ফ্রুটিকোজ খাড়া বা ঝুলন্ত হতে পারে। ঘরে চাপ দাও।',
  cols: 2, ch: 124, ramp: i => [6, 10, 7, 11][i],
  items: [
    ['cru', 'ক্রাস্টোজ (খোলসসদৃশ)', 'পাতলা খোলসের মতো থ্যালাস আশ্রয়ের (পাথর, বাকল) সাথে সম্পূর্ণ লেগে থাকে — না ভেঙে আলাদা করা যায় না; নিচের কর্টেক্স নেই।', 'Graphis, Lecanora'],
    ['fol', 'ফোলিওজ (পত্রসদৃশ)', 'চ্যাপ্টা, খাঁজকাটা পাতার মতো থ্যালাস; রাইজাইন দিয়ে আলগাভাবে আটকানো — সহজে তোলা যায়।', 'Parmelia, Physcia'],
    ['fru', 'ফ্রুটিকোজ — খাড়া', 'ছোট গুল্মের মতো শাখান্বিত খাড়া থ্যালাস; একটি বিন্দুতে আটকানো।', 'Cladonia (রেইনডিয়ার মস)'],
    ['hang', 'ফ্রুটিকোজ — ঝুলন্ত', 'সুতার মতো শাখান্বিত থ্যালাস গাছের ডাল থেকে ঝুলে থাকে।', 'Usnea ("বুড়োর দাড়ি")']
  ],
  draw(g, k, R) {
    if (k === 'cru') { E('rect', { x: -60, y: 8, width: 120, height: 26, rx: 4, fill: BK.ramp(9).lt }, g); E('path', { d: 'M-46 8Q-30 2 -10 6T30 4T50 8', fill: 'none', stroke: R.dk, 'stroke-width': 5, opacity: .8 }, g); for (let i = 0; i < 9; i++) E('circle', { cx: -40 + i * 10, cy: 4 + (i % 2), r: 2, fill: R.dk }, g); return; }
    if (k === 'fol') { const o = E('g', {}, g); return t => { o.innerHTML = ''; E('rect', { x: -60, y: 20, width: 120, height: 14, rx: 4, fill: BK.ramp(11).lt }, o); const w = 2 * Math.sin(t * 1.5); for (let i = 0; i < 5; i++) { const a = -2.6 + i * .55; E('path', { d: `M0 18Q${36 * Math.cos(a) - 8} ${18 + 30 * Math.sin(a)} ${40 * Math.cos(a) + w} ${18 + 34 * Math.sin(a) * .9}Q${36 * Math.cos(a) + 10} ${18 + 30 * Math.sin(a) + 6} 0 18Z`, fill: R.c, stroke: R.dk }, o); } }; }
    if (k === 'fru') { const o = E('g', {}, g); return t => { o.innerHTML = ''; const w = 2.5 * Math.sin(t * 1.4); E('path', { d: `M0 34V6M0 18L${-12 + w} 2M0 12L${12 + w} -4M${-12 + w} 2L${-18 + w} -10M${12 + w} -4L${16 + w} -16M-8 34V20L${-20 + w} 10`, stroke: R.c, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, o); [[-18, -12], [16, -18]].forEach(([x, y]) => E('circle', { cx: x + w, cy: y, r: 4, fill: BK.ramp(4).c }, o)); }; }
    if (k === 'hang') { E('path', { d: 'M-60 -20H60', stroke: BK.ramp(11).dk, 'stroke-width': 6, 'stroke-linecap': 'round' }, g); const o = E('g', {}, g); return t => { o.innerHTML = ''; for (let j = 0; j < 4; j++) { const x0 = -36 + j * 24, w = 4 * Math.sin(t * 1.2 + j); E('path', { d: `M${x0} -18C${x0 + w} 0 ${x0 - w} 14 ${x0 + w} 34M${x0 + w / 2} 6l8 10`, stroke: R.c, 'stroke-width': 2, fill: 'none' }, o); } }; }
  }
});

/* ───────── পারস্পরিক নির্ভরশীলতা ───────── */
V.lichenExchange = {
  t: 'লাইকেনে শৈবাল ও ছত্রাকের পারস্পরিক নির্ভরশীলতা', k: ['2d', 'anim', 'int'],
  cap: 'শৈবাল (ফটোবায়োন্ট) সালোকসংশ্লেষণে তৈরি শর্করা ছত্রাককে দেয়; সায়ানোব্যাকটেরিয়া হলে সংবন্ধিত নাইট্রোজেনও দেয়। ছত্রাক (মাইকোবায়োন্ট) পানি ও খনিজ শোষণ করে জোগায়, শুকিয়ে যাওয়া ও তীব্র আলো থেকে রক্ষা করে এবং আশ্রয়ে আটকে রাখে — এ সম্পর্ককে মিথোজীবিতা বলে।',
  html: () => `<div class="fk-row">${X.seg('pb', [['grn', 'সবুজ শৈবাল সঙ্গী'], ['cya', 'সায়ানোব্যাকটেরিয়া সঙ্গী']], 'grn')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 230;
    let m = 'grn', C, svg, up = [], dn = [], nn = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; up = []; dn = []; nn = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'আদান-প্রদান' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Ra = m === 'grn' ? BK.ramp(10) : BK.ramp(5), Rf = BK.ramp(9), Rs = BK.ramp(6), Rw = BK.ramp(2), Rn = BK.ramp(3);
      E('rect', { x: 30, y: 30, width: 130, height: 150, rx: 16, fill: FK.alpha(Ra.lt, .5), stroke: Ra.dk }, svg);
      for (let i = 0; i < 9; i++) { const x = 60 + (i % 3) * 35, y = 70 + Math.floor(i / 3) * 38; if (m === 'grn') E('circle', { cx: x, cy: y, r: 11, fill: Ra.c, stroke: Ra.dk }, svg); else { for (let j = 0; j < 4; j++) E('circle', { cx: x - 12 + j * 8, cy: y, r: 4, fill: j === 2 ? BK.ramp(6).c : Ra.c, stroke: Ra.dk, 'stroke-width': .7 }, svg); } }
      E('rect', { x: 200, y: 30, width: 130, height: 150, rx: 16, fill: FK.alpha(Rf.lt, .4), stroke: Rf.dk }, svg);
      for (let i = 0; i < 7; i++) E('path', { d: `M206 ${46 + i * 20}C240 ${36 + i * 22} 280 ${60 + i * 16} 324 ${44 + i * 20}`, stroke: Rf.dk, 'stroke-width': 1.6, fill: 'none' }, svg);
      T(svg, 95, 22, m === 'grn' ? 'সবুজ শৈবাল (Trebouxia)' : 'সায়ানোব্যাকটেরিয়া (Nostoc)', { fs: 11, a: 'middle', w: 650, c: Ra.ink });
      T(svg, 265, 22, 'ছত্রাক (অ্যাসকোমাইসিটিস)', { fs: 11, a: 'middle', w: 650, c: Rf.ink });
      T(svg, 180, 200, m === 'grn' ? '→ শর্করা (রিবিটল ইত্যাদি)' : '→ গ্লুকোজ ও নাইট্রোজেন যৌগ', { fs: 10.5, a: 'middle', w: 600, c: Rs.ink });
      T(svg, 180, 218, '← পানি, খনিজ, আশ্রয় ও সুরক্ষা', { fs: 10.5, a: 'middle', w: 600, c: Rw.ink });
      for (let i = 0; i < 6; i++) up.push(E('rect', { width: 7, height: 7, rx: 1.5, fill: Rs.c, stroke: Rs.dk, 'stroke-width': .6 }, svg));
      for (let i = 0; i < 6; i++) dn.push(E('circle', { r: 3.6, fill: Rw.c, stroke: Rw.dk, 'stroke-width': .6 }, svg));
      if (m === 'cya') for (let i = 0; i < 4; i++) nn.push(E('circle', { r: 3, fill: Rn.c, stroke: Rn.dk, 'stroke-width': .6 }, svg));
      $('info').innerHTML = m === 'grn' ? '<b>সবুজ শৈবাল সঙ্গী</b> — প্রায় 90% লাইকেনে; শৈবাল শর্করা অ্যালকোহল (যেমন রিবিটল) হিসেবে খাদ্য ছত্রাককে দেয়।<div class="small">ছত্রাক ছাড়া এ শৈবাল শুকনো পাথরে বাঁচতে পারত না; আবার শৈবাল ছাড়া ছত্রাক খাদ্য পেত না।</div>' : '<b>সায়ানোব্যাকটেরিয়া সঙ্গী</b> — যেমন Nostoc; গ্লুকোজের সাথে হেটারোসিস্টে বাতাসের নাইট্রোজেন সংবন্ধন করে নাইট্রোজেন যৌগও দেয় (কমলা কোষ = হেটারোসিস্ট)।<div class="small">কিছু লাইকেনে সবুজ শৈবাল ও সায়ানোব্যাকটেরিয়া দুটিই থাকে।</div>';
      step(0);
    };
    const step = dt => { tt += dt; up.forEach((p, i) => { const f = (tt * .3 + i / 6) % 1; p.setAttribute('x', (160 + 40 * f - 3).toFixed(1)); p.setAttribute('y', (70 + i * 14 - 3).toFixed(1)); p.setAttribute('opacity', Math.sin(f * 3.14).toFixed(2)); }); dn.forEach((p, i) => { const f = (tt * .3 + i / 6 + .5) % 1; p.setAttribute('cx', (200 - 40 * f).toFixed(1)); p.setAttribute('cy', (77 + i * 14).toFixed(1)); p.setAttribute('opacity', Math.sin(f * 3.14).toFixed(2)); }); nn.forEach((p, i) => { const f = (tt * .25 + i / 4) % 1; p.setAttribute('cx', (160 + 40 * f).toFixed(1)); p.setAttribute('cy', (150 + i * 6).toFixed(1)); p.setAttribute('opacity', Math.sin(f * 3.14).toFixed(2)); }); };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'pb', v => { m = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── দূষণ নির্দেশক ───────── */
V.lichenSO2 = {
  t: 'বায়ুদূষণের নির্দেশক হিসেবে লাইকেন', k: ['graph', 'anim', 'int'],
  cap: 'লাইকেনের কিউটিকল নেই, বৃষ্টি ও বাতাস থেকে সরাসরি সবকিছু শোষে এবং বর্জ্য বের করতে পারে না — তাই সালফার ডাইঅক্সাইডে (SO₂) শৈবালের ক্লোরোফিল নষ্ট হয়। ফ্রুটিকোজ সবচেয়ে সংবেদনশীল, ক্রাস্টোজ সবচেয়ে সহনশীল। স্লাইডার সরাও। (সীমাগুলো আনুমানিক, শিক্ষামূলক।)',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row">${FK.sl('so', 'SO₂', 0, 180, 5, 20, ' µg/m³')}</div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 210;
    let so = 20, C, svg, smoke = [], groups = {}, tt = 0;
    const lim = { fru: 35, fol: 70, cru: 150 };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; smoke = []; groups = {};
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'লাইকেন ও দূষণ' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rb = BK.ramp(11);
      E('rect', { x: 150, y: 10, width: 60, height: 200, fill: FK.alpha(Rb.c, .55), stroke: Rb.dk }, svg);
      for (let i = 0; i < 9; i++) E('path', { d: `M${156 + i * 6} 12V208`, stroke: Rb.dk, 'stroke-width': .6, opacity: .5 }, svg);
      const gF = E('g', {}, svg), gL = E('g', {}, svg), gC = E('g', {}, svg);
      const Rf = BK.ramp(7), Rl = BK.ramp(10), Rc = BK.ramp(6);
      for (let j = 0; j < 4; j++) { const x0 = 156 + j * 14, w = j % 2 ? 3 : -3; E('path', { d: `M${x0} 30C${x0 + w} 46 ${x0 - w} 58 ${x0 + w} 74`, stroke: Rf.c, 'stroke-width': 2.4, fill: 'none' }, gF); }
      [[165, 100], [196, 118], [172, 136]].forEach(([x, y]) => { for (let i = 0; i < 5; i++) { const a = i * 1.256; E('ellipse', { cx: x + 6 * Math.cos(a), cy: y + 6 * Math.sin(a), rx: 6, ry: 4, fill: Rl.c, stroke: Rl.dk, 'stroke-width': .6, transform: `rotate(${a * 57} ${x + 6 * Math.cos(a)} ${y + 6 * Math.sin(a)})` }, gL); } });
      [[168, 170], [192, 186], [176, 196]].forEach(([x, y]) => E('ellipse', { cx: x, cy: y, rx: 12, ry: 5, fill: Rc.c, opacity: .8 }, gC));
      groups = { fru: gF, fol: gL, cru: gC };
      T(svg, 222, 52, 'ফ্রুটিকোজ', { fs: 11, w: 650, c: Rf.ink }); T(svg, 222, 120, 'ফোলিওজ', { fs: 11, w: 650, c: Rl.ink }); T(svg, 222, 186, 'ক্রাস্টোজ', { fs: 11, w: 650, c: Rc.ink });
      for (let i = 0; i < 24; i++) smoke.push(E('circle', { r: 5 + (i % 3) * 3, fill: C.mu, opacity: 0 }, svg));
      paint();
    };
    const paint = () => {
      const alive = Object.keys(lim).filter(k => so <= lim[k]);
      Object.keys(groups).forEach(k => { const ok = so <= lim[k]; groups[k].setAttribute('opacity', ok ? 1 : .12); });
      const z = so > lim.cru ? 'প্রায় লাইকেনশূন্য অঞ্চল ("লাইকেন মরুভূমি") — তীব্র দূষণ' : alive.length === 1 ? 'কেবল সহনশীল ক্রাস্টোজ — উচ্চ দূষণ' : alive.length === 2 ? 'ক্রাস্টোজ ও ফোলিওজ — মাঝারি দূষণ' : 'তিন ধরনই, ঝুলন্ত Usnea সহ — নির্মল বাতাস';
      $('info').innerHTML = `<b>SO₂ প্রায় ${so} µg/m³</b> — ${z}<div class="small">শহরের কেন্দ্র থেকে বাইরের দিকে গাছের বাকলে লাইকেনের ধরন গুনে বায়ুর মান অনুমান করা যায় — সস্তা জৈব নির্দেশক।</div>`;
    };
    const step = dt => { tt += dt; const n = Math.round(so / 180 * smoke.length); smoke.forEach((s, i) => { const f = (tt * .15 + i / smoke.length) % 1; s.setAttribute('cx', (20 + f * 110).toFixed(1)); s.setAttribute('cy', (190 - f * 170 + 10 * Math.sin(i + tt)).toFixed(1)); s.setAttribute('opacity', i < n ? (.25 * (1 - f)).toFixed(2) : 0); }); };
    FK.bindSl(root, 'so', v => { so = v; paint(); }, ' µg/m³', 0);
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(() => { base(); step(0); }); base(); step(0);
    return () => { A.stop(); unT(); };
  }
};

V.lichenUses = Object.assign({ t: 'লাইকেনের গুরুত্ব', k: ['mind', 'int'], cap: 'অর্থনৈতিক ও পরিবেশীয় গুরুত্ব। পাতায় চাপ দাও।' }, BK.mind({
  t: 'লাইকেনের গুরুত্ব', d: 'খাদ্য, রং, সুগন্ধি, ওষুধ; পরিবেশে অগ্রগামী ও নির্দেশক।',
  c: [
    { t: 'খাদ্য ও পশুখাদ্য', d: 'খাদ্য হিসেবে।', c: [{ t: 'রেইনডিয়ার মস', d: 'Cladonia rangiferina — তুন্দ্রায় রেইনডিয়ারের শীতের প্রধান খাদ্য।' }, { t: 'মসলা ও খাদ্য', d: 'Parmelia ("পাথরফুল") দক্ষিণ এশিয়ায় মসলায়; আইসল্যান্ড মস (Cetraria) খাদ্যে।' }] },
    { t: 'শিল্প', d: 'রং ও সুগন্ধি।', c: [{ t: 'লিটমাস', d: 'Roccella থেকে — অম্ল-ক্ষার নির্দেশক।' }, { t: 'রঞ্জক', d: 'অর্কিল ও অন্যান্য প্রাকৃতিক রং — পশমি কাপড় রাঙাতে।' }, { t: 'সুগন্ধি', d: 'ওকমস (Evernia prunastri) সুগন্ধি শিল্পে।' }] },
    { t: 'ওষুধ', d: 'জীবাণুনাশক যৌগ।', c: [{ t: 'উসনিক অ্যাসিড', d: 'Usnea সহ বহু লাইকেনে — ব্যাকটেরিয়ানাশক গুণ; মলমে ব্যবহার।' }] },
    { t: 'পরিবেশ', d: 'বাস্তুতন্ত্রে ভূমিকা।', c: [{ t: 'অগ্রগামী উদ্ভিদ', d: 'খালি পাথরে প্রথম বসতি; লাইকেন অ্যাসিড পাথর ক্ষয় করে মাটি তৈরি শুরু করে।' }, { t: 'দূষণ নির্দেশক', d: 'SO₂ ও ভারী ধাতুর জৈব নির্দেশক।' }, { t: 'নাইট্রোজেন সংবন্ধন', d: 'সায়ানোব্যাকটেরিয়াযুক্ত লাইকেন মাটিতে নাইট্রোজেন যোগ করে।' }, { t: 'তেজস্ক্রিয়তা জমা', d: 'চেরনোবিল দুর্ঘটনার পর লাইকেন থেকে রেইনডিয়ার হয়ে মানুষে তেজস্ক্রিয় পদার্থ পৌঁছেছিল।' }] },
    { t: 'অপকারী দিক', d: 'ক্ষতি।', c: [{ t: 'স্থাপনা ক্ষয়', d: 'পাথরের ভাস্কর্য ও পুরনো ইমারত ক্ষয় করে।' }, { t: 'বিষাক্ত লাইকেন', d: 'কিছু লাইকেন (যেমন Letharia vulpina) বিষাক্ত।' }] }
  ]
}));

V.b1c5map = Object.assign({ t: 'শৈবাল ও ছত্রাক — এক নজরে', k: ['mind', 'int'], cap: 'অধ্যায়ের সবচেয়ে জরুরি তথ্য এক জায়গায়। পাতায় চাপ দিলে বিস্তারিত।' }, BK.mind({
  t: 'শৈবাল ও ছত্রাক', d: 'থ্যালয়েড সুকেন্দ্রিক জীব ও তাদের সহাবস্থান।',
  c: [
    { t: 'শৈবাল', d: 'ক্লোরোফিলযুক্ত, স্বভোজী, প্রধানত জলজ।', c: [{ t: 'দেহ', d: 'এককোষী, কলোনিয়াল, ফিলামেন্টাস, সাইফোনাস, প্যারেনকাইমাটাস।' }, { t: 'জনন', d: 'অঙ্গজ; অযৌন (জুস্পোর); যৌন (আইসো-, অ্যানাইসো-, উগ্যামি)।' }, { t: 'Ulothrix', d: 'অশাখ ফিলামেন্ট, বলয়াকার ক্লোরোপ্লাস্ট; চার-ফ্ল্যাজেলা জুস্পোর, দুই-ফ্ল্যাজেলা গ্যামিট; জাইগোটে মায়োসিস।' }] },
    { t: 'ছত্রাক', d: 'ক্লোরোফিলহীন, শোষণভোজী, কাইটিন প্রাচীর, গ্লাইকোজেন।', c: [{ t: 'দেহ', d: 'ইস্ট বা হাইফার মাইসেলিয়াম — পর্দাযুক্ত বা পর্দাহীন।' }, { t: 'যৌন জনন', d: 'প্লাজমোগ্যামি → ডাইক্যারিয়ন → ক্যারিওগ্যামি → মায়োসিস।' }, { t: 'Agaricus', d: 'পাইলিয়াস, গিল, অ্যানুলাস, স্টাইপ; গিলে ট্রামা-সাবহাইমেনিয়াম-হাইমেনিয়াম; ব্যাসিডিওস্পোর।' }] },
    { t: 'রোগ', d: 'ছত্রাকঘটিত।', c: [{ t: 'আলুর বিলম্বিত ধ্বসা', d: 'Phytophthora infestans; ঠান্ডা কুয়াশা; রোগমুক্ত বীজ ও ছত্রাকনাশক।' }, { t: 'দাদ', d: 'ডার্মাটোফাইট; লাল আঁশযুক্ত বলয়; ছত্রাকনাশক মলম।' }] },
    { t: 'লাইকেন', d: 'শৈবাল + ছত্রাকের মিথোজীবিতা।', c: [{ t: 'গঠন', d: 'কর্টেক্স, শৈবাল-স্তর, মেডুলা, রাইজাইন।' }, { t: 'প্রকার', d: 'ক্রাস্টোজ, ফোলিওজ, ফ্রুটিকোজ।' }, { t: 'গুরুত্ব', d: 'অগ্রগামী, দূষণ নির্দেশক, লিটমাস, খাদ্য।' }] }
  ]
}));
})();
