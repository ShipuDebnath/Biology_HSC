/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৫.২ ছত্রাক ও Agaricus
   fungiForms   : ছত্রাকের নানা দেহরূপ — ইস্ট থেকে মাশরুম (গ্রিড; ইস্ট মুকুল গজায়)
   hyphaTypes   : পর্দাযুক্ত বনাম পর্দাহীন (সিনোসাইটিক) হাইফা — শীর্ষবৃদ্ধি ও সাইটোপ্লাজম প্রবাহ
   fungalCell   : পর্দাযুক্ত হাইফার একটি কোষ — চিহ্নিত চিত্র (ছিদ্র দিয়ে প্রবাহ)
   fungiClass   : প্রধান দল — গাছ
   fungiRepro   : জননের প্রকারভেদ — গাছ
   sexPhases    : যৌন জননের তিন দশা — প্লাজমোগ্যামি, ক্যারিওগ্যামি, মায়োসিস (ধাপে ধাপে)
   fungiEcon    : ছত্রাকের গুরুত্ব — মাইন্ড ম্যাপ
   agaricusBody : Agaricus এর ব্যাসিডিওকার্প — চিহ্নিত চিত্র (গিল থেকে স্পোর ঝরে)
   gillTS       : গিলের প্রস্থচ্ছেদ — ট্রামা, সাবহাইমেনিয়াম, হাইমেনিয়াম, ব্যাসিডিয়াম (স্পোর ছিটকে পড়ে)
   basidiocarpDev: ব্যাসিডিওস্পোর থেকে পরিণত ব্যাসিডিওকার্প (ধাপে ধাপে)
   cmpAlgaeFungi: শৈবাল ও ছত্রাকের পার্থক্য
   নোট: Agaricus এ ভলভা নেই (Amanita তে থাকে); A. bisporus এর ব্যাসিডিয়ামে সাধারণত 2টি, A. campestris এ 4টি স্পোর।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B5 = window.B5;

V.fungiForms = B5.grid({
  t: 'ছত্রাকের নানা দেহরূপ',
  cap: 'অধিকাংশ ছত্রাকের দেহ সুতার মতো হাইফার জাল — মাইসেলিয়াম; ইস্ট এককোষী। মাশরুম আসলে মাটির নিচের মাইসেলিয়ামের ফলদেহ। ঘরে চাপ দাও, চালু করো।',
  cols: 3, ch: 116, ramp: i => [6, 9, 10, 7, 6, 11][i],
  items: [
    ['yeast', 'ইস্ট (এককোষী)', 'ডিম্বাকার এককোষী ছত্রাক; মুকুলোদ্গমে বংশবৃদ্ধি — মুকুল আলাদা না হলে শিকল (সিউডোমাইসেলিয়াম)।', 'Saccharomyces cerevisiae'],
    ['rhiz', 'পর্দাহীন মাইসেলিয়াম', 'প্রস্থপ্রাচীরহীন বহুনিউক্লিয়াসযুক্ত হাইফা; স্টোলন, রাইজয়েড ও কালো স্পোরাঞ্জিয়াম।', 'Rhizopus (রুটির ছত্রাক)'],
    ['pen', 'পর্দাযুক্ত, ঝাড়ুর মতো কনিডিওফোর', 'প্রস্থপ্রাচীরযুক্ত হাইফা; কনিডিওফোরের মাথায় তুলির মতো শাখায় কনিডিয়ার শিকল।', 'Penicillium'],
    ['asp', 'ফোলা মাথার কনিডিওফোর', 'কনিডিওফোরের মাথা গোল ভেসিকল, তাতে চারদিকে কনিডিয়ার শিকল।', 'Aspergillus'],
    ['mush', 'ছাতার মতো ফলদেহ', 'মাটির নিচে মাইসেলিয়াম, উপরে বৃন্ত ও টুপিযুক্ত ব্যাসিডিওকার্প।', 'Agaricus (মাশরুম)'],
    ['brk', 'তাক বা আঙুলের মতো', 'গাছের গুঁড়িতে তাকের মতো শক্ত ফলদেহ — কাঠ পচায়।', 'Ganoderma, Polyporus']
  ],
  draw(g, k, R) {
    if (k === 'yeast') { const a = E('ellipse', { cx: -6, cy: 6, rx: 13, ry: 10, fill: R.c, stroke: R.dk }, g), b = E('ellipse', { cx: 10, cy: -4, rx: 2, ry: 2, fill: R.c, stroke: R.dk }, g); E('circle', { cx: -7, cy: 6, r: 3, fill: R.dk }, g); return t => { const f = (t * .4) % 1; b.setAttribute('rx', (2 + 7 * f).toFixed(1)); b.setAttribute('ry', (2 + 5.5 * f).toFixed(1)); b.setAttribute('cx', (8 + 6 * f).toFixed(1)); b.setAttribute('cy', (-2 - 6 * f).toFixed(1)); }; }
    if (k === 'rhiz') { E('path', { d: 'M-30 22Q0 8 30 22M-18 15v-26M10 13v-30M-18 15l-4 8M-18 15l3 8M10 13l-3 9M10 13l4 9', stroke: R.dk, 'stroke-width': 1.6, fill: 'none' }, g); E('circle', { cx: -18, cy: -15, r: 7, fill: R.dk }, g); E('circle', { cx: 10, cy: -21, r: 8, fill: R.dk }, g); return; }
    if (k === 'pen') { E('path', { d: 'M-28 24H28M0 24V-2M-14 24v-4M14 24v-4', stroke: R.dk, 'stroke-width': 1.6 }, g); const gg = E('g', {}, g); [-10, -4, 4, 10].forEach(x => { E('path', { d: `M0 -2L${x} -10`, stroke: R.dk, 'stroke-width': 1.2 }, gg); for (let j = 0; j < 4; j++) E('circle', { cx: x * 1.1, cy: -13 - j * 5, r: 2.2, fill: R.c, stroke: R.dk, 'stroke-width': .5 }, gg); }); return; }
    if (k === 'asp') { E('path', { d: 'M-28 24H28M0 24V0', stroke: R.dk, 'stroke-width': 1.6 }, g); E('circle', { cx: 0, cy: -4, r: 6, fill: R.c, stroke: R.dk }, g); for (let i = 0; i < 9; i++) { const a = -Math.PI + .2 + i * .34; for (let j = 1; j <= 3; j++) E('circle', { cx: (6 + j * 4.2) * Math.cos(a), cy: -4 + (6 + j * 4.2) * Math.sin(a), r: 1.9, fill: R.c, stroke: R.dk, 'stroke-width': .5 }, g); } return; }
    if (k === 'mush') { E('path', { d: 'M-30 26H30', stroke: BK.ramp(11).dk, 'stroke-width': 2 }, g); E('path', { d: 'M-4 26V-2h8V26', fill: R.lt, stroke: R.dk }, g); E('path', { d: 'M-24 -2Q-22 -26 0 -26Q22 -26 24 -2Z', fill: R.c, stroke: R.dk }, g); E('path', { d: 'M-4 8h8', stroke: R.dk, 'stroke-width': 3 }, g); const sp = []; for (let i = 0; i < 5; i++) sp.push(E('circle', { r: 1.3, fill: R.dk }, g)); return t => sp.forEach((c, i) => { const f = (t * .5 + i / 5) % 1; c.setAttribute('cx', (-16 + i * 8).toFixed(1)); c.setAttribute('cy', (0 + f * 24).toFixed(1)); c.setAttribute('opacity', (1 - f).toFixed(2)); }); }
    if (k === 'brk') { E('rect', { x: -30, y: -28, width: 10, height: 56, fill: BK.ramp(11).c, stroke: BK.ramp(11).dk }, g); [-14, 2, 16].forEach((y, i) => E('path', { d: `M-20 ${y}Q${14 - i * 4} ${y - 12} ${22 - i * 5} ${y + 2}Q0 ${y + 6} -20 ${y + 6}Z`, fill: R.c, stroke: R.dk }, g)); }
  }
});

/* ───────── হাইফার ধরন ───────── */
V.hyphaTypes = {
  t: 'পর্দাযুক্ত ও পর্দাহীন হাইফা', k: ['2d', 'anim', 'int'],
  cap: 'হাইফা শীর্ষে বাড়ে। পর্দাযুক্ত হাইফায় প্রস্থপ্রাচীরে (সেপটাম) ছিদ্র থাকে, তাই সাইটোপ্লাজম ও নিউক্লিয়াস কোষ থেকে কোষে চলাচল করে। পর্দাহীন (সিনোসাইটিক) হাইফা একটি লম্বা বহুনিউক্লিয়াসযুক্ত নল।',
  html: () => `<div class="fk-row">${X.seg('h', [['sep', 'পর্দাযুক্ত'], ['coe', 'পর্দাহীন (সিনোসাইটিক)']], 'sep')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 170, Y = 80, X0 = 20;
    let m = 'sep', C, svg, tube, dots = [], tt = 0;
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; dots = [];
      svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'হাইফা' }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const Rw = BK.ramp(11), Rn = BK.ramp(3), Rc = BK.ramp(6);
      tube = E('path', { fill: FK.alpha(Rc.lt, .55), stroke: Rw.dk, 'stroke-width': 2.4 }, svg);
      if (m === 'sep') for (let i = 1; i <= 4; i++) { const x = X0 + i * 62; E('path', { d: `M${x} ${Y - 14}V${Y - 3}M${x} ${Y + 3}V${Y + 14}`, stroke: Rw.dk, 'stroke-width': 2.4 }, svg); }
      for (let i = 0; i < 14; i++) dots.push({ e: E(i < 6 ? 'ellipse' : 'circle', i < 6 ? { rx: 5, ry: 3.6, fill: Rn.c, stroke: Rn.dk } : { r: 1.8, fill: BK.ramp(6).dk }, svg), i, nu: i < 6 });
      T(svg, X0, 26, 'পুরনো অংশ', { fs: 10.5, w: 560, c: C.mu }); T(svg, W - 16, 26, 'শীর্ষ (বৃদ্ধি)', { fs: 10.5, a: 'end', w: 560, c: C.mu });
      if (m === 'sep') T(svg, X0 + 62, Y + 34, 'সেপটাম (ছিদ্রসহ)', { fs: 10.5, a: 'middle', w: 600, c: Rw.ink });
      T(svg, W / 2, H - 12, m === 'sep' ? 'প্রতি কোষে এক বা দুটি নিউক্লিয়াস' : 'একটি নলে অসংখ্য নিউক্লিয়াস', { fs: 11, a: 'middle', w: 600, c: C.fg });
      $('info').innerHTML = m === 'sep' ? '<b>পর্দাযুক্ত (সেপটেট) হাইফা</b> — প্রস্থপ্রাচীরে হাইফা কোষে বিভক্ত; প্রাচীরে কেন্দ্রীয় ছিদ্র। <div class="small">উদাহরণ: <i>Penicillium, Aspergillus, Agaricus</i> (ব্যাসিডিওমাইসিটিসে ডোলিপোর সেপটাম)।</div>' : '<b>পর্দাহীন বা সিনোসাইটিক হাইফা</b> — প্রস্থপ্রাচীর নেই; সাইটোপ্লাজমে অসংখ্য নিউক্লিয়াস ছড়ানো। <div class="small">উদাহরণ: <i>Rhizopus, Mucor</i>; প্রস্থপ্রাচীর কেবল জননাঙ্গের গোড়ায় তৈরি হয়।</div>';
      step(0);
    };
    const step = dt => {
      tt += dt; const tip = 290 + 40 * ((tt * .12) % 1);
      tube.setAttribute('d', `M${X0} ${Y - 14}H${tip}Q${tip + 18} ${Y - 14} ${tip + 18} ${Y}Q${tip + 18} ${Y + 14} ${tip} ${Y + 14}H${X0}`);
      dots.forEach(d => { const L = tip - X0; let x = X0 + ((d.i * 37 + tt * (d.nu ? 9 : 22)) % L); if (m === 'sep' && d.nu) { const cell = d.i % 5; x = X0 + 31 + cell * 62 + 8 * Math.sin(tt + d.i); } const y = Y + (d.nu ? 0 : 7 * Math.sin(d.i * 2.1)); d.e.setAttribute(d.nu ? 'cx' : 'cx', x.toFixed(1)); d.e.setAttribute('cy', y.toFixed(1)); });
    };
    const A = X.anim(root, step, { paused: true }); X.pp(root, A);
    X.onSeg(root, 'h', v => { m = v; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── ছত্রাক কোষ ───────── */
const HY = 130, HX0 = 30, HX1 = 330;
V.fungalCell = Object.assign({
  t: 'পর্দাযুক্ত হাইফার কোষীয় গঠন', k: ['2d', 'label', 'int', 'anim'],
  cap: 'ছত্রাক কোষ সুকেন্দ্রিক, কিন্তু প্লাস্টিড ও ক্লোরোফিল নেই। কোষপ্রাচীর কাইটিন ও গ্লুকানের; কোষঝিল্লিতে কোলেস্টেরলের বদলে আর্গোস্টেরল; সঞ্চিত খাদ্য গ্লাইকোজেন ও তেল — শ্বেতসার নয়। সেপটামের ছিদ্র দিয়ে সাইটোপ্লাজম প্রবাহিত হয়।'
}, BK.diagram({
  W: 360, H: 290, label: 'ছত্রাকের হাইফা কোষ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rw = BK.ramp(11), Rm = BK.ramp(2), Rn = BK.ramp(3), Rv = BK.ramp(5), Rc = BK.ramp(6), Rmi = BK.ramp(0);
    const wl = P('wall'); E('rect', { x: HX0, y: HY - 46, width: HX1 - HX0, height: 92, rx: 8, fill: FK.alpha(Rc.lt, .35), stroke: Rw.dk, 'stroke-width': 6 }, wl);
    const mb = P('mem'); E('rect', { x: HX0 + 6, y: HY - 40, width: HX1 - HX0 - 12, height: 80, rx: 5, fill: 'none', stroke: Rm.c, 'stroke-width': 1.6 }, mb);
    const sp = P('septum'); [130, 240].forEach(x => E('path', { d: `M${x} ${HY - 46}V${HY - 6}M${x} ${HY + 6}V${HY + 46}`, stroke: Rw.dk, 'stroke-width': 5 }, sp));
    P('pore');
    const nu = P('nucleus'); [[86, HY - 6], [186, HY + 4], [200, HY - 14]].forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 11, fill: FK.alpha(Rn.lt, .9), stroke: Rn.dk, 'stroke-width': 1.5 }, nu); E('circle', { cx: x + 2, cy: y - 1, r: 3, fill: Rn.dk }, nu); });
    const vc = P('vacuole'); E('ellipse', { cx: 290, cy: HY, rx: 24, ry: 22, fill: FK.alpha(Rv.lt, .7), stroke: Rv.dk }, vc);
    const mi = P('mito'); [[60, HY + 22], [110, HY + 24], [160, HY - 28], [218, HY + 26], [282, HY - 32]].forEach(([x, y]) => { E('ellipse', { cx: x, cy: y, rx: 9, ry: 4.5, fill: FK.alpha(Rmi.c, .5), stroke: Rmi.dk }, mi); E('path', { d: `M${x - 6} ${y}q3 -3 6 0t6 0`, stroke: Rmi.dk, fill: 'none', 'stroke-width': .8 }, mi); });
    const gl = P('glyco'); for (let i = 0; i < 16; i++) E('circle', { cx: 50 + (i * 53) % 270, cy: HY - 30 + (i * 23) % 60, r: 1.8, fill: BK.ramp(6).dk }, gl);
    const oi = P('oil'); [[100, HY - 26], [262, HY + 28], [154, HY + 22]].forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 5.5, fill: FK.alpha(BK.ramp(6).c, .7), stroke: BK.ramp(6).dk }, oi));
  },
  idle(g, C, t) { const R = BK.ramp(9); for (let i = 0; i < 10; i++) { const x = 40 + ((t * 26 + i * 29) % 280), near = [130, 240].some(s => Math.abs(x - s) < 6); E('circle', { cx: x.toFixed(1), cy: (HY + (near ? 0 : 14 * Math.sin(i * 1.7))).toFixed(1), r: 1.6, fill: R.dk, opacity: .55 }, g); } },
  parts: [
    { id: 'wall', bn: 'কোষপ্রাচীর (কাইটিন)', lb: 'কোষপ্রাচীর', en: 'Cell wall (chitin)', fn: 'প্রধানত কাইটিন (N-অ্যাসিটাইলগ্লুকোসামিনের পলিমার) ও গ্লুকান — সেলুলোজ নয়। (Phytophthora এর মতো উমাইসিটিসে সেলুলোজ — তারা প্রকৃত ছত্রাক নয়।)', a: [70, HY - 46], l: [60, 30], an: 'middle' },
    { id: 'mem', bn: 'কোষঝিল্লি (আর্গোস্টেরলযুক্ত)', lb: 'কোষঝিল্লি', en: 'Plasma membrane', fn: 'প্রাণিকোষের কোলেস্টেরলের বদলে আর্গোস্টেরল থাকে — অনেক ছত্রাকনাশক ওষুধ (অ্যাজোল) আর্গোস্টেরল তৈরি বন্ধ করে।', a: [300, HY - 40], l: [250, 262], an: 'middle' },
    { id: 'septum', bn: 'সেপটাম (প্রস্থপ্রাচীর)', lb: 'সেপটাম', en: 'Septum', fn: 'হাইফাকে কোষে ভাগ করে; মাঝখানে ছিদ্র থাকে।', a: [130, HY + 40], l: [50, 232], an: 'middle' },
    { id: 'pore', bn: 'সেপটাল ছিদ্র', lb: 'ছিদ্র', en: 'Septal pore', fn: 'এ ছিদ্র দিয়ে সাইটোপ্লাজম, অঙ্গাণু, এমনকি নিউক্লিয়াস পাশের কোষে যেতে পারে।', a: [240, HY], l: [230, 232], an: 'middle' },
    { id: 'nucleus', bn: 'নিউক্লিয়াস', en: 'Nucleus', fn: 'সুগঠিত ছোট নিউক্লিয়াস; প্রতি কোষে এক বা দুটি (ডাইক্যারিয়ন — n + n)।', a: [200, HY - 24], l: [165, 30], an: 'middle' },
    { id: 'mito', bn: 'মাইটোকন্ড্রিয়া', en: 'Mitochondria', fn: 'সবাত শ্বসনে ATP তৈরি।', a: [110, HY + 24], l: [140, 232], an: 'middle' },
    { id: 'glyco', bn: 'গ্লাইকোজেন দানা', lb: 'গ্লাইকোজেন', en: 'Glycogen', fn: 'ছত্রাকের প্রধান সঞ্চিত শর্করা — প্রাণীর মতো গ্লাইকোজেন, উদ্ভিদের মতো শ্বেতসার নয়।', a: [262, HY + 6], l: [110, 262], an: 'middle' },
    { id: 'oil', bn: 'তেলবিন্দু', en: 'Oil globule', fn: 'সঞ্চিত লিপিড।', a: [262, HY + 28], l: [310, 232], an: 'middle' },
    { id: 'vacuole', bn: 'কোষগহ্বর', en: 'Vacuole', fn: 'পুরনো কোষে বড় গহ্বর — কোষরস ও বর্জ্য।', a: [306, HY - 12], l: [285, 30], an: 'middle' }
  ]
}));

/* ───────── শ্রেণি ও জনন ───────── */
V.fungiClass = Object.assign({ t: 'ছত্রাকের প্রধান দল', k: ['tree', 'int'], cap: 'যৌন স্পোরের ধরন অনুযায়ী প্রধান দল। যাদের যৌন দশা জানা নেই, তারা অসম্পূর্ণ ছত্রাক।' }, BK.tree({
  t: 'ছত্রাক (Fungi)', d: 'ক্লোরোফিলহীন, শোষণভোজী সুকেন্দ্রিক জীব।',
  c: [
    { t: 'জাইগোমাইসিটিস', d: 'পর্দাহীন হাইফা; যৌন স্পোর জাইগোস্পোর; অযৌন স্পোরাঞ্জিওস্পোর।', c: [{ t: 'উদাহরণ', d: 'Rhizopus, Mucor।' }] },
    { t: 'অ্যাসকোমাইসিটিস', d: 'পর্দাযুক্ত হাইফা; অ্যাসকাস থলিতে সাধারণত 8টি অ্যাসকোস্পোর; অযৌন কনিডিয়া।', c: [{ t: 'উদাহরণ', d: 'ইস্ট, Penicillium, Aspergillus, Neurospora।' }] },
    { t: 'ব্যাসিডিওমাইসিটিস', d: 'পর্দাযুক্ত হাইফা; ব্যাসিডিয়ামের বাইরে সাধারণত 4টি ব্যাসিডিওস্পোর; দীর্ঘস্থায়ী ডাইক্যারিয়ন।', c: [{ t: 'উদাহরণ', d: 'Agaricus, Pleurotus, Puccinia (মরিচা), Ustilago (ঝুল)।' }] },
    { t: 'ডিউটেরোমাইসিটিস', d: 'অসম্পূর্ণ ছত্রাক — যৌন জনন জানা নেই; কনিডিয়া দিয়ে জনন।', c: [{ t: 'উদাহরণ', d: 'Alternaria, Fusarium, Helminthosporium।' }] }
  ]
}, { colW: 124 }));

V.fungiRepro = Object.assign({ t: 'ছত্রাকের জননের প্রকারভেদ', k: ['tree', 'int'], cap: 'অঙ্গজ, অযৌন ও যৌন। যৌন জননে প্লাজমোগ্যামি, ক্যারিওগ্যামি ও মায়োসিস — তিনটি দশা।' }, BK.tree({
  t: 'ছত্রাকের জনন', d: 'অঙ্গজ, অযৌন ও যৌন।',
  c: [
    { t: 'অঙ্গজ', d: 'দেহাংশ থেকে।', c: [{ t: 'খণ্ডায়ন', d: 'হাইফা ভেঙে টুকরা থেকে নতুন মাইসেলিয়াম।' }, { t: 'মুকুলোদ্গম', d: 'ইস্টে কোষ থেকে কুঁড়ি।' }, { t: 'বিভাজন', d: 'Schizosaccharomyces এ দুই ভাগ।' }, { t: 'স্ক্লেরোশিয়াম ও রাইজোমর্ফ', d: 'শক্ত হাইফা-পিণ্ড ও দড়ির মতো হাইফা-গুচ্ছ — প্রতিকূলতায় টিকে থাকা।' }] },
    { t: 'অযৌন', d: 'স্পোর দিয়ে।', c: [{ t: 'স্পোরাঞ্জিওস্পোর', d: 'স্পোরাঞ্জিয়ামের ভেতরে — Rhizopus।' }, { t: 'কনিডিয়া', d: 'কনিডিওফোরের মাথায় বাইরে — Penicillium, Aspergillus।' }, { t: 'জুস্পোর', d: 'ফ্ল্যাজেলাযুক্ত — কাইট্রিড ছত্রাক।' }, { t: 'ক্ল্যামাইডোস্পোর ও ওইডিয়া', d: 'পুরু প্রাচীরের কোষ ও হাইফা ভাঙা টুকরা।' }] },
    { t: 'যৌন', d: 'প্লাজমোগ্যামি → ক্যারিওগ্যামি → মায়োসিস।', c: [{ t: 'প্ল্যানোগ্যামেটিক মিলন', d: 'চলনশীল গ্যামিটের মিলন — Synchytrium।' }, { t: 'গ্যামিট্যাঞ্জিয়াল মিলন', d: 'দুই গ্যামিট্যাঞ্জিয়াম সম্পূর্ণ মিলে জাইগোস্পোর — Rhizopus।' }, { t: 'স্পার্মাটাইজেশন', d: 'স্পার্মাশিয়া গ্রাহক হাইফায় — Puccinia।' }, { t: 'সোমাটোগ্যামি', d: 'জননাঙ্গ ছাড়া দুটি অঙ্গজ হাইফার মিলন — Agaricus।' }] }
  ]
}, { colW: 120 }));

V.sexPhases = Object.assign({
  t: 'ছত্রাকের যৌন জননের তিন দশা', k: ['2d', 'anim', 'int'],
  cap: 'ছত্রাকে দুই কোষের সাইটোপ্লাজম মিলন (প্লাজমোগ্যামি) আর নিউক্লিয়াস মিলন (ক্যারিওগ্যামি) একসাথে হয় না — মাঝে দীর্ঘ ডাইক্যারিয়টিক (n + n) দশা থাকে, বিশেষত ব্যাসিডিওমাইসিটিসে। ক্যারিওগ্যামির পরপরই মায়োসিস।'
}, BK.steps({
  W: 360, H: 210, label: 'যৌন জননের দশা', dur: 2.4,
  stages: [
    { t: 'দুই মিলনক্ষম হাইফা', en: '+ and − hyphae', d: 'দুটি ভিন্ন মিলন-ধরনের (+ ও −) হ্যাপ্লয়েড (n) হাইফা কাছাকাছি আসে।' },
    { t: 'প্লাজমোগ্যামি', en: 'Plasmogamy', d: 'দুই কোষের সাইটোপ্লাজম মিলে যায়, কিন্তু নিউক্লিয়াস আলাদা থাকে।' },
    { t: 'ডাইক্যারিয়ন (n + n)', en: 'Dikaryon', d: 'প্রতি কোষে দুটি ভিন্ন নিউক্লিয়াস জোড়ায় একসাথে বিভাজিত হয় — Agaricus এ এই দশাই দীর্ঘস্থায়ী মাইসেলিয়াম।' },
    { t: 'ক্যারিওগ্যামি (2n)', en: 'Karyogamy', d: 'নিউক্লিয়াস দুটি মিলে ডিপ্লয়েড নিউক্লিয়াস — জীবনচক্রের একমাত্র ডিপ্লয়েড দশা (ব্যাসিডিয়াম বা অ্যাসকাসে)।' },
    { t: 'মায়োসিস → স্পোর (n)', en: 'Meiosis', d: 'ডিপ্লয়েড নিউক্লিয়াস মায়োসিসে চারটি হ্যাপ্লয়েড নিউক্লিয়াস → ব্যাসিডিওস্পোর বা অ্যাসকোস্পোর।' }
  ],
  draw(g, C, s, u) {
    const Rp = BK.ramp(0), Rm = BK.ramp(5), Rz = BK.ramp(4), Rw = BK.ramp(11);
    const nuc = (x, y, R, r = 6) => E('circle', { cx: x, cy: y, r, fill: R.c, stroke: R.dk, 'stroke-width': 1.2 }, g);
    const hy = (x0, x1, y) => E('rect', { x: Math.min(x0, x1), y: y - 16, width: Math.abs(x1 - x0), height: 32, rx: 16, fill: FK.alpha(BK.ramp(6).lt, .45), stroke: Rw.dk, 'stroke-width': 2 }, g);
    const y = 95;
    if (s === 0) { const gp = 60 * (1 - u); hy(30, 150 - gp / 2, y); hy(210 + gp / 2, 330, y); nuc(110 - gp / 2, y, Rp); nuc(250 + gp / 2, y, Rm); }
    if (s === 1) { hy(30, 330, y); nuc(110 + 40 * u, y, Rp); nuc(250 - 40 * u, y, Rm); }
    if (s === 2) { hy(30, 330, y); for (let i = 0; i < 3; i++) { const x = 80 + i * 100; nuc(x - 10, y, Rp, 5.5); nuc(x + 10, y, Rm, 5.5); if (i) E('path', { d: `M${x - 50} ${y - 16}V${y + 16}`, stroke: Rw.dk, 'stroke-width': 2 }, g); } }
    if (s === 3) { E('path', { d: 'M150 150V90Q150 50 180 50Q210 50 210 90V150Z', fill: FK.alpha(BK.ramp(6).lt, .5), stroke: Rw.dk, 'stroke-width': 2 }, g); if (u < .5) { nuc(180 - 12 * (1 - u * 2), 90, Rp); nuc(180 + 12 * (1 - u * 2), 90, Rm); } else nuc(180, 90, Rz, 9); }
    if (s === 4) { E('path', { d: 'M150 150V90Q150 50 180 50Q210 50 210 90V150Z', fill: FK.alpha(BK.ramp(6).lt, .5), stroke: Rw.dk, 'stroke-width': 2 }, g); const k = Math.min(1, u * 1.5); [[-24, Rp], [-8, Rm], [8, Rp], [24, Rm]].forEach(([dx, R], i) => { E('path', { d: `M${180 + dx * .6} 52L${180 + dx} ${40 - 6 * k}`, stroke: Rw.dk, 'stroke-width': 1.4 }, g); nuc(180 + dx * (u > .66 ? 1 : .5), u > .66 ? 32 - 6 * k : 90 + (i % 2 ? 8 : -8), R, 5); }); }
    const lab = ['n          n', 'n + n (এক কোষে)', 'ডাইক্যারিয়টিক মাইসেলিয়াম', '2n', '4 × n'][s];
    T(g, 180, 190, lab, { fs: 12, a: 'middle', w: 650, c: C.fg });
  }
}));

V.fungiEcon = Object.assign({ t: 'ছত্রাকের গুরুত্ব', k: ['mind', 'int'], cap: 'উপকারী ও অপকারী দিক। পাতায় চাপ দাও।' }, BK.mind({
  t: 'ছত্রাকের গুরুত্ব', d: 'প্রকৃতির প্রধান বিয়োজক; খাদ্য, শিল্প ও ওষুধ; আবার রোগ ও বিষ।',
  c: [
    { t: 'খাদ্য ও শিল্প', d: 'গাঁজন ও সরাসরি খাদ্য।', c: [{ t: 'মাশরুম', d: 'Agaricus (বাটন), Pleurotus (ঝিনুক মাশরুম — বাংলাদেশে বহুল চাষ), Volvariella (খড় মাশরুম)।' }, { t: 'ইস্ট', d: 'Saccharomyces cerevisiae — রুটি ফোলানো ও অ্যালকোহল গাঁজন।' }, { t: 'পনির ও জৈব অ্যাসিড', d: 'Penicillium roqueforti পনিরে; Aspergillus niger থেকে সাইট্রিক অ্যাসিড।' }] },
    { t: 'ওষুধ', d: 'জীবন রক্ষাকারী যৌগ।', c: [{ t: 'পেনিসিলিন', d: 'ফ্লেমিং (1928), Penicillium — প্রথম অ্যান্টিবায়োটিক।' }, { t: 'গ্রিসিওফালভিন', d: 'Penicillium griseofulvum — দাদের ওষুধ।' }, { t: 'সাইক্লোস্পোরিন ও স্ট্যাটিন', d: 'অঙ্গ প্রতিস্থাপনে প্রতিরোধ দমন; কোলেস্টেরল কমানো (লোভাস্ট্যাটিন — Aspergillus terreus)।' }] },
    { t: 'পরিবেশ ও কৃষি', d: 'পুষ্টিচক্র।', c: [{ t: 'বিয়োজন', d: 'কাঠের লিগনিন ও সেলুলোজ ভেঙে মাটিতে পুষ্টি ফেরায়।' }, { t: 'মাইকোরাইজা', d: 'অধিকাংশ স্থলজ উদ্ভিদের মূলের সাথে মিথোজীবী — ফসফরাস ও পানি শোষণে সাহায্য।' }, { t: 'জৈব নিয়ন্ত্রণ', d: 'Trichoderma (রোগজীবাণু দমন), Beauveria (কীট দমন)।' }] },
    { t: 'গবেষণা', d: 'মডেল জীব।', c: [{ t: 'Neurospora ও ইস্ট', d: 'বিডল ও টাটামের "এক জিন এক এনজাইম" তত্ত্ব Neurospora তে; ইস্ট কোষচক্র গবেষণার মডেল।' }] },
    { t: 'অপকারী দিক', d: 'রোগ ও বিষ।', c: [{ t: 'ফসলের রোগ', d: 'ধানের ব্লাস্ট, গমের মরিচা ও ব্লাস্ট (বাংলাদেশে 2016), আখের লাল পচা, চীনাবাদামের টিক্কা।' }, { t: 'মানুষের রোগ', d: 'দাদ, ক্যানডিডিয়াসিস, অ্যাসপারজিলোসিস, মিউকরমাইকোসিস।' }, { t: 'মাইকোটক্সিন', d: 'Aspergillus flavus এর অ্যাফ্লাটক্সিন — যকৃতের ক্যান্সারের ঝুঁকি; Claviceps এর আর্গট বিষ।' }, { t: 'বিষাক্ত মাশরুম ও পচন', d: 'Amanita phalloides প্রাণঘাতী; খাদ্য, কাঠ, চামড়া, কাগজ নষ্ট।' }] }
  ]
}));

/* ───────── Agaricus ব্যাসিডিওকার্প ───────── */
const AX0 = 180;
V.agaricusBody = Object.assign({
  t: 'Agaricus এর দৈহিক গঠন', k: ['2d', 'label', 'int', 'anim'],
  cap: 'মাটি বা কম্পোস্টের ভেতরে মৃতজীবী মাইসেলিয়াম, উপরে ছাতার মতো ফলদেহ — ব্যাসিডিওকার্প: বৃন্ত (স্টাইপ), টুপি (পাইলিয়াস), টুপির নিচে অরীয় গিল (ল্যামেলি) এবং বৃন্তে বলয় (অ্যানুলাস)। গিল থেকে কোটি কোটি ব্যাসিডিওস্পোর ঝরে।'
}, BK.diagram({
  W: 360, H: 300, label: 'Agaricus',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const svg = g.ownerSVGElement, Rc = BK.ramp(6), Rs = BK.ramp(11), Rg = BK.ramp(8), Rm = BK.ramp(9);
    E('rect', { x: 20, y: 222, width: 320, height: 66, rx: 6, fill: FK.alpha(Rs.c, .18) }, g);
    const my = P('mycel'); for (let i = 0; i < 12; i++) { const x = 60 + i * 22; E('path', { d: `M${AX0} 226Q${(AX0 + x) / 2} ${246 + (i % 3) * 8} ${x} ${262 + (i * 7) % 20}`, stroke: Rm.c, 'stroke-width': 1.2, fill: 'none' }, my); }
    const rz = P('rhizo'); E('path', { d: `M${AX0 - 6} 226C${AX0 - 30} 246 ${AX0 - 70} 250 ${AX0 - 110} 270M${AX0 + 6} 226C${AX0 + 34} 250 ${AX0 + 80} 252 ${AX0 + 120} 276`, stroke: Rm.dk, 'stroke-width': 3.4, fill: 'none', 'stroke-linecap': 'round' }, rz);
    const st = P('stipe'); E('path', { d: `M${AX0 - 13} 226L${AX0 - 10} 112H${AX0 + 10}L${AX0 + 13} 226Q${AX0} 232 ${AX0 - 13} 226Z`, fill: BK.lg(svg, Rc.lt, '#fff', { a: 0 }), stroke: Rc.dk, 'stroke-width': 1.6 }, st);
    const gi = P('gills'); E('path', { d: `M${AX0 - 92} 104Q${AX0} 120 ${AX0 + 92} 104L${AX0 + 80} 96H${AX0 - 80}Z`, fill: Rg.c, stroke: Rg.dk }, gi); for (let i = -8; i <= 8; i++) E('path', { d: `M${AX0 + i * 10} 98L${AX0 + i * 10.8} ${108 + (1 - Math.abs(i) / 8) * 6}`, stroke: Rg.dk, 'stroke-width': 1 }, gi);
    const pi = P('pileus'); E('path', { d: `M${AX0 - 96} 104Q${AX0 - 92} 34 ${AX0} 30Q${AX0 + 92} 34 ${AX0 + 96} 104Q${AX0} 92 ${AX0 - 96} 104Z`, fill: BK.lg(svg, '#fff', Rc.lt, { a: 90 }), stroke: Rc.dk, 'stroke-width': 1.8 }, pi);
    const an = P('annulus'); E('path', { d: `M${AX0 - 11} 138Q${AX0 - 24} 150 ${AX0 - 18} 156Q${AX0} 148 ${AX0 + 18} 156Q${AX0 + 24} 150 ${AX0 + 11} 138Z`, fill: '#fff', stroke: Rc.dk, 'stroke-width': 1.4 }, an);
  },
  idle(g, C, t) { const R = BK.ramp(8); for (let i = 0; i < 14; i++) { const f = (t * .35 + i / 14) % 1, x = AX0 - 80 + (i * 37) % 160 + 6 * Math.sin(t + i); E('circle', { cx: x.toFixed(1), cy: (112 + f * 100).toFixed(1), r: 1.4, fill: R.dk, opacity: (1 - f).toFixed(2) }, g); } },
  parts: [
    { id: 'pileus', bn: 'পাইলিয়াস (টুপি)', lb: 'পাইলিয়াস', en: 'Pileus (cap)', fn: 'ছাতার মতো মাংসল টুপি; উপরের ত্বক সাদা থেকে বাদামি; ভেতরে হাইফার ঘন জাল (সিউডোপ্যারেনকাইমা)।', a: [AX0 + 40, 50], l: [270, 30] },
    { id: 'gills', bn: 'গিল বা ল্যামেলি', lb: 'গিল', en: 'Gills (lamellae)', fn: 'টুপির নিচে বৃন্ত থেকে কিনারার দিকে অরীয়ভাবে সাজানো পাতলা পর্দা; বৃন্তের সাথে যুক্ত নয় (মুক্ত); কচি অবস্থায় গোলাপি, পরিণত হলে গাঢ় বাদামি — দুই পাশে ব্যাসিডিওস্পোর তৈরি হয়।', a: [AX0 + 60, 104], l: [270, 90] },
    { id: 'annulus', bn: 'অ্যানুলাস (বলয়)', lb: 'অ্যানুলাস', en: 'Annulus', fn: 'কচি অবস্থায় টুপির কিনারা থেকে বৃন্ত পর্যন্ত বিস্তৃত পর্দা (ভেলাম) ছিঁড়ে বৃন্তে থেকে যাওয়া বলয়।', a: [AX0 + 18, 152], l: [270, 150] },
    { id: 'stipe', bn: 'স্টাইপ (বৃন্ত)', lb: 'স্টাইপ', en: 'Stipe (stalk)', fn: 'নলাকার মাংসল বৃন্ত — টুপিকে মাটির উপরে তুলে ধরে যাতে স্পোর বাতাসে ছড়ায়। Agaricus এ গোড়ায় ভলভা (পেয়ালা) নেই।', a: [AX0 - 11, 190], l: [80, 190] },
    { id: 'mycel', bn: 'মাইসেলিয়াম', en: 'Mycelium', fn: 'মাটি বা কম্পোস্টের ভেতরে পর্দাযুক্ত হাইফার জাল — মৃতজীবী, জৈব পদার্থ থেকে পুষ্টি শোষণ করে। দীর্ঘস্থায়ী অংশ ডাইক্যারিয়টিক (n + n)।', a: [AX0 + 70, 262], l: [270, 248] },
    { id: 'rhizo', bn: 'রাইজোমর্ফ', en: 'Rhizomorph', fn: 'অনেক হাইফা একত্রে দড়ির মতো গুচ্ছ — পুষ্টি পরিবহন ও বিস্তার।', a: [AX0 - 80, 256], l: [80, 236] }
  ]
}));

/* ───────── গিলের প্রস্থচ্ছেদ ───────── */
V.gillTS = Object.assign({
  t: 'গিলের অন্তর্গঠন (প্রস্থচ্ছেদ)', k: ['2d', 'label', 'int', 'anim'],
  cap: 'একটি গিলের প্রস্থচ্ছেদ: মাঝে ঢিলা হাইফার ট্রামা, দুই পাশে ছোট কোষের সাবহাইমেনিয়াম, সবার বাইরে উর্বর স্তর হাইমেনিয়াম — গদাকার ব্যাসিডিয়াম ও বন্ধ্যা প্যারাফাইসিস পাশাপাশি। প্রতিটি ব্যাসিডিয়ামের স্টেরিগমার মাথায় ব্যাসিডিওস্পোর।'
}, BK.diagram({
  W: 360, H: 290, label: 'গিলের প্রস্থচ্ছেদ',
  art(g, C, part) {
    const P = id => { const x = part(id); g.appendChild(x); return x; };
    const Rt = BK.ramp(6), Rs = BK.ramp(11), Rh = BK.ramp(8), Rb = BK.ramp(3), Rp = BK.ramp(9);
    const cx = 180, top = 20, bot = 270, tw = 22;
    const tr = P('trama'); E('path', { d: `M${cx - tw} ${top}V${bot - 30}Q${cx} ${bot} ${cx + tw} ${bot - 30}V${top}Z`, fill: FK.alpha(Rt.lt, .6), stroke: Rt.dk }, tr); for (let i = 0; i < 9; i++) E('path', { d: `M${cx - 14 + (i % 3) * 14} ${top}C${cx - 20 + i * 4} ${top + 80} ${cx + 18 - i * 3} ${top + 150} ${cx - 10 + (i % 4) * 7} ${bot - 34}`, stroke: Rt.dk, 'stroke-width': .9, fill: 'none' }, tr);
    const sh = P('subhy'); [-1, 1].forEach(sd => { for (let j = 0; j < 12; j++) E('circle', { cx: cx + sd * (tw + 7), cy: top + 10 + j * 19, r: 7, fill: FK.alpha(Rs.lt, .7), stroke: Rs.dk, 'stroke-width': .9 }, sh); });
    const hy = P('hymen'); [-1, 1].forEach(sd => { for (let j = 0; j < 12; j++) { const y = top + 10 + j * 19, basid = j % 3 === 1; if (!basid) E('rect', { x: sd > 0 ? cx + tw + 14 : cx - tw - 14 - 18, y: y - 5, width: 18, height: 10, rx: 5, fill: FK.alpha(Rp.lt, .8), stroke: Rp.dk, 'stroke-width': .8 }, hy); } });
    P('para');
    const ba = P('basid'); [-1, 1].forEach(sd => { for (let j = 1; j < 12; j += 3) { const y = top + 10 + j * 19, x0 = sd > 0 ? cx + tw + 14 : cx - tw - 14; E('path', { d: `M${x0} ${y - 5}L${x0 + sd * 26} ${y - 8}Q${x0 + sd * 34} ${y} ${x0 + sd * 26} ${y + 8}L${x0} ${y + 5}Z`, fill: Rh.lt, stroke: Rh.dk, 'stroke-width': 1 }, ba); [-6, -2, 2, 6].forEach(dy => E('path', { d: `M${x0 + sd * 31} ${y + dy * .9}L${x0 + sd * 40} ${y + dy * 1.6}`, stroke: Rh.dk, 'stroke-width': 1 }, ba)); } });
    const sp = P('spore'); [-1, 1].forEach(sd => { for (let j = 1; j < 12; j += 3) { const y = top + 10 + j * 19, x0 = sd > 0 ? cx + tw + 14 : cx - tw - 14; [-6, -2, 2, 6].forEach(dy => E('ellipse', { cx: x0 + sd * 44, cy: y + dy * 1.7, rx: 3.4, ry: 2.4, fill: Rb.c, stroke: Rb.dk, 'stroke-width': .7 }, sp)); } });
  },
  idle(g, C, t) { const R = BK.ramp(3); [-1, 1].forEach(sd => { for (let k = 0; k < 4; k++) { const f = (t * .45 + k / 4) % 1, y = 20 + 10 + (1 + 3 * k) * 19 + f * 40, x = 180 + sd * (22 + 14 + 48 + 14 * Math.sin(f * 3)); E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: 3.4, ry: 2.4, fill: R.c, opacity: (1 - f).toFixed(2) }, g); } }); },
  parts: [
    { id: 'trama', bn: 'ট্রামা', en: 'Trama', fn: 'গিলের মাঝখানের অংশ — লম্বালম্বি ঢিলাভাবে সাজানো ডাইক্যারিয়টিক হাইফা; গিলকে ভিত্তি দেয়।', a: [180, 120], l: [180, 286] },
    { id: 'subhy', bn: 'সাবহাইমেনিয়াম', en: 'Subhymenium', fn: 'ট্রামার দুই পাশে ছোট, প্রায় গোল কোষের স্তর — এখান থেকে হাইমেনিয়ামের কোষ তৈরি হয়।', a: [151, 48], l: [90, 22] },
    { id: 'hymen', bn: 'হাইমেনিয়াম', en: 'Hymenium', fn: 'গিলের দুই পৃষ্ঠের উর্বর স্তর — ব্যাসিডিয়াম ও প্যারাফাইসিস পাশাপাশি খাড়া সারিতে।', a: [225, 48], l: [270, 22] },
    { id: 'para', bn: 'প্যারাফাইসিস', en: 'Paraphyses', fn: 'হাইমেনিয়ামের বন্ধ্যা কোষ — ব্যাসিডিয়ামগুলোকে আলাদা রাখে, স্পোর তৈরি করে না।', a: [127, 162], l: [60, 152] },
    { id: 'basid', bn: 'ব্যাসিডিয়াম', en: 'Basidium', fn: 'গদাকার উর্বর কোষ; এখানে ক্যারিওগ্যামি (2n) ও মায়োসিস হয়; মাথায় সাধারণত চারটি সরু স্টেরিগমা (A. bisporus এ দুটি)।', a: [240, 105], l: [300, 70] },
    { id: 'spore', bn: 'ব্যাসিডিওস্পোর', en: 'Basidiospore', fn: 'স্টেরিগমার মাথায় হ্যাপ্লয়েড (n), এক-নিউক্লিয়াসযুক্ত স্পোর; পরিণত হলে জোর করে ছিটকে পড়ে বাতাসে ছড়ায়।', a: [224, 238], l: [300, 250] }
  ]
}));

/* ───────── ব্যাসিডিওকার্পের উৎপত্তি ───────── */
V.basidiocarpDev = Object.assign({
  t: 'Agaricus এর ব্যাসিডিওকার্পের উৎপত্তি', k: ['2d', 'anim', 'int'],
  cap: 'ব্যাসিডিওস্পোর (n) → প্রাথমিক মাইসেলিয়াম (এক-নিউক্লিয়াস) → সোমাটোগ্যামি → গৌণ ডাইক্যারিয়টিক মাইসেলিয়াম (n + n) → বোতাম দশা → ভেলাম ছিঁড়ে পরিণত ব্যাসিডিওকার্প → ব্যাসিডিয়ামে ক্যারিওগ্যামি ও মায়োসিস → নতুন ব্যাসিডিওস্পোর।'
}, BK.steps({
  W: 360, H: 240, label: 'ব্যাসিডিওকার্পের উৎপত্তি', dur: 2.6,
  stages: [
    { t: 'স্পোরের অঙ্কুরোদ্গম', en: 'Spore germination', d: 'ব্যাসিডিওস্পোর (n) অঙ্কুরিত হয়ে এক-নিউক্লিয়াসযুক্ত প্রাথমিক মাইসেলিয়াম (+ বা −) তৈরি করে — স্বল্পস্থায়ী।' },
    { t: 'সোমাটোগ্যামি', en: 'Somatogamy', d: 'ভিন্ন মিলন-ধরনের দুটি প্রাথমিক হাইফা মিলে প্লাজমোগ্যামি — জননাঙ্গ ছাড়াই।' },
    { t: 'গৌণ মাইসেলিয়াম (n + n)', en: 'Secondary mycelium', d: 'প্রতি কোষে দুটি নিউক্লিয়াস — দীর্ঘস্থায়ী ডাইক্যারিয়টিক মাইসেলিয়াম মাটিতে ছড়ায়; অনুকূল আর্দ্রতা ও তাপে হাইফা জট পাকায়।' },
    { t: 'বোতাম দশা', en: 'Button stage', d: 'জট থেকে ছোট গোল বোতাম মাটি ফুঁড়ে ওঠে; ভেতরে বৃন্ত, টুপি ও গিল তৈরি হতে থাকে; গিল ভেলাম পর্দায় ঢাকা।' },
    { t: 'পরিণত ব্যাসিডিওকার্প', en: 'Mature basidiocarp', d: 'বৃন্ত লম্বা ও টুপি প্রসারিত হলে ভেলাম ছিঁড়ে গিল উন্মুক্ত হয়, বৃন্তে থাকে অ্যানুলাস। ব্যাসিডিয়ামে ক্যারিওগ্যামি (2n) → মায়োসিস → ব্যাসিডিওস্পোর (n) ঝরে।' }
  ],
  draw(g, C, s, u) {
    const Rc = BK.ramp(6), Rs = BK.ramp(11), Rm = BK.ramp(9), Rp = BK.ramp(0), Rn = BK.ramp(5), Rg = BK.ramp(8);
    E('rect', { x: 10, y: 176, width: 340, height: 54, rx: 6, fill: FK.alpha(Rs.c, .18) }, g);
    const nuc = (x, y, R) => E('circle', { cx: x, cy: y, r: 3, fill: R.c, stroke: R.dk, 'stroke-width': .6 }, g);
    if (s === 0) { [[90, Rp], [270, Rn]].forEach(([x, R]) => { E('ellipse', { cx: x, cy: 196, rx: 6, ry: 4, fill: R.c, stroke: R.dk }, g); for (let b = 0; b < 3; b++) { const a = b * 2.1 + .3, L = 10 + 50 * u; E('path', { d: `M${x} 196q${L * .4 * Math.cos(a)} ${L * .3} ${L * Math.cos(a)} ${L * .5 * Math.sin(a) + 6}`, stroke: R.dk, 'stroke-width': 1.4, fill: 'none' }, g); } }); T(g, 90, 166, '+ (n)', { fs: 11, a: 'middle', w: 650, c: Rp.ink }); T(g, 270, 166, '− (n)', { fs: 11, a: 'middle', w: 650, c: Rn.ink }); }
    if (s === 1) { const m = 140 + 40 * u; E('path', { d: `M40 200H${m}`, stroke: Rp.dk, 'stroke-width': 3 }, g); E('path', { d: `M320 200H${360 - m}`, stroke: Rn.dk, 'stroke-width': 3 }, g); nuc(m - 10, 200, Rp); nuc(370 - m, 200, Rn); if (u > .9) E('circle', { cx: 180, cy: 200, r: 8, fill: 'none', stroke: C.fg, 'stroke-dasharray': '2 2' }, g); }
    if (s === 2) { for (let i = 0; i < 9; i++) { const a = i * .7, L = 30 + 120 * u; E('path', { d: `M180 196Q${180 + L * .5 * Math.cos(a)} ${190 + 10 * Math.sin(i)} ${180 + L * Math.cos(a) * (i % 2 ? 1 : -1)} ${200 + 14 * Math.sin(a)}`, stroke: Rm.dk, 'stroke-width': 1.4, fill: 'none' }, g); } for (let i = 0; i < 5; i++) { const x = 120 + i * 30; nuc(x - 3, 192 + (i % 2) * 14, Rp); nuc(x + 3, 192 + (i % 2) * 14, Rn); } }
    if (s === 3) { const h = 10 + 22 * u; E('ellipse', { cx: 180, cy: 178 - h / 2, rx: 14 + 6 * u, ry: h / 2 + 4, fill: '#fff', stroke: Rc.dk, 'stroke-width': 1.6 }, g); E('path', { d: `M180 ${180 - h}V178`, stroke: Rc.dk, 'stroke-dasharray': '2 2' }, g); for (let i = 0; i < 7; i++) E('path', { d: `M180 182q${-40 + i * 13} 10 ${-60 + i * 20} 30`, stroke: Rm.dk, 'stroke-width': 1, fill: 'none' }, g); }
    if (s === 4) { const k = Math.min(1, u * 1.3), sh = 40 + 60 * k, cw = 30 + 40 * k, top = 176 - sh; E('path', { d: `M172 176L174 ${top + 10}H186L188 176Z`, fill: '#fff', stroke: Rc.dk, 'stroke-width': 1.4 }, g); E('path', { d: `M${180 - cw} ${top + 12}Q${180 - cw} ${top - 24 - 10 * k} 180 ${top - 26 - 10 * k}Q${180 + cw} ${top - 24 - 10 * k} ${180 + cw} ${top + 12}Z`, fill: Rc.lt, stroke: Rc.dk, 'stroke-width': 1.6 }, g); E('path', { d: `M${180 - cw + 4} ${top + 12}H${180 + cw - 4}`, stroke: Rg.dk, 'stroke-width': 3 }, g); if (k < .5) E('path', { d: `M${180 - cw + 4} ${top + 13}L174 ${top + 30}M${180 + cw - 4} ${top + 13}L186 ${top + 30}`, stroke: Rc.dk, 'stroke-width': 1.2 }, g); else E('path', { d: `M168 ${top + 36}Q180 ${top + 30} 192 ${top + 36}`, stroke: Rc.dk, 'stroke-width': 2.4, fill: 'none' }, g); if (u > .6) for (let i = 0; i < 8; i++) { const f = ((u - .6) * 2.5 + i / 8) % 1; E('circle', { cx: 180 - cw + 10 + i * (cw * 2 - 20) / 7, cy: top + 18 + f * 50, r: 1.4, fill: Rg.dk, opacity: 1 - f }, g); } }
  }
}));

/* ───────── শৈবাল বনাম ছত্রাক ───────── */
V.cmpAlgaeFungi = Object.assign({ t: 'শৈবাল ও ছত্রাকের পার্থক্য', k: ['cmp', 'int'], cap: 'দুটিই থ্যালয়েড ও সুকেন্দ্রিক, কিন্তু পুষ্টি ও কোষের রসায়ন সম্পূর্ণ ভিন্ন।' }, BK.compare({
  a: 'শৈবাল', b: 'ছত্রাক',
  rows: [
    ['ক্লোরোফিল', 'আছে', 'নেই'],
    ['পুষ্টি', 'স্বভোজী (সালোকসংশ্লেষী)', 'পরভোজী — শোষণ (মৃতজীবী, পরজীবী, মিথোজীবী)'],
    ['কোষপ্রাচীর', 'প্রধানত সেলুলোজ (ডায়াটমে সিলিকা)', 'প্রধানত কাইটিন'],
    ['সঞ্চিত খাদ্য', 'শ্বেতসার (শ্রেণিভেদে ল্যামিনারিন, ফ্লোরিডিয়ান শ্বেতসার)', 'গ্লাইকোজেন ও তেল'],
    ['দেহ', 'এককোষী থেকে বৃহৎ থ্যালাস; প্লাস্টিড আছে', 'ইস্ট বা হাইফার মাইসেলিয়াম; প্লাস্টিড নেই'],
    ['আবাস', 'প্রধানত জলজ ও আর্দ্র স্থান', 'প্রধানত স্থলজ — জৈব পদার্থে, জীবদেহে'],
    ['চলনশীল দশা', 'প্রায়ই ফ্ল্যাজেলাযুক্ত জুস্পোর ও গ্যামিট', 'সাধারণত নেই (কেবল কাইট্রিডে)'],
    ['উদাহরণ', 'Ulothrix, Chlamydomonas, Sargassum', 'Agaricus, Penicillium, ইস্ট']
  ]
}));
})();
