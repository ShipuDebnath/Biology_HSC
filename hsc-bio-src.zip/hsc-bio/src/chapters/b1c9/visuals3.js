/* ═══════════════════════════════════════════════════════════════════
   visuals3 — §৯.৫ সালোকসংশ্লেষণের প্রভাবক ও গুরুত্ব, §৯.৬ সবাত শ্বসন
   o2source  : নির্গত O2 এর উৎস — রুবেন-কামেনের 18O পরীক্ষা, ভ্যান নীলের ধারণা
   limiting  : ব্ল্যাকম্যানের সীমাবদ্ধতা নীতি — আলো স্লাইডার, CO2/তাপের দুই রেখা
   bubbleCount: জলজ উদ্ভিদের বুদবুদ গুনে সালোকসংশ্লেষণের হার (বাতির দূরত্ব স্লাইডার, বিপরীত বর্গ সূত্র)
   rateCtrl  : আলো, CO2 ও তাপ নিয়ন্ত্রণে হার (গ্রিনহাউস) — তিন স্লাইডার
   psFactors : সালোকসংশ্লেষণের প্রভাবক (লেখচিত্র)       molls : মোলের অর্ধপত্র পরীক্ষা (CO2 এর অপরিহার্যতা)
   psImportance: সালোকসংশ্লেষণের গুরুত্ব
   atpStruct : ATP এর গঠন ও ATP-ADP চক্র          respOverview: সবাত শ্বসনের চার ধাপ ও স্থান
   glycolysis: গ্লাইকোলাইসিসের ১০ ধাপ — ATP/NADH হিসাব   linkReaction: পাইরুভিক অ্যাসিডের জারণ
   etc       : ইলেকট্রন পরিবহন শৃঙ্খল ও অক্সিডেটিভ ফসফোরাইলেশন (NADH, FADH2, বিকল্প অক্সিডেজ, O2 না থাকলে)
   atpCalc   : ATP এর হিসাব — পাঠ্যবই বনাম আধুনিক, দুই শাটল       plantMito : উদ্ভিদ মাইটোকন্ড্রিয়ার স্বকীয়তা
   cmpGlyPhotolysis, cmpGlyKrebs, cmpKrebsPA, cmpPhotoOx : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B9 = window.B9;
const PI = Math.PI, ch = B9.ch, cl = B9.cl, rnd = B9.rnd, node = B9.node;
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));

/* ═════════ ১. নির্গত O2 এর উৎস ═════════ */
const flask = (g, C, x, lab, tint) => {
  const Rw = BK.ramp(5), Rg = BK.ramp(10);
  E('path', { d: `M${x - 18} 70V110L${x - 52} 200Q${x - 56} 214 ${x - 40} 214H${x + 40}Q${x + 56} 214 ${x + 52} 200L${x + 18} 110V70Z`, fill: FK.alpha(Rw.c, .25), stroke: C.fg, 'stroke-width': 1.3 }, g);
  for (let i = 0; i < 14; i++) E('circle', { cx: x - 34 + (i % 7) * 11, cy: 186 + Math.floor(i / 7) * 12, r: 3.4, fill: Rg.c }, g);
  T(g, x, 232, lab, { fs: 10.5, a: 'middle', w: 600, c: C.fg }); if (tint) T(g, x, 248, tint, { fs: 9.5, a: 'middle', c: C.mu });
};
V.o2source = Object.assign({}, B9.seg({
  id: 'o2s', t: 'সালোকসংশ্লেষণে নির্গত অক্সিজেনের উৎস', H: 262, def: 'ruben',
  cap: 'আগে ধারণা ছিল O2 আসে CO2 থেকে। ভ্যান নীল (1931) সালফার ব্যাকটেরিয়া দেখে প্রস্তাব দেন — O2 আসে পানি থেকে। রুবেন ও কামেন (1941) অক্সিজেনের ভারী আইসোটোপ 18O দিয়ে তা প্রমাণ করেন। চালাও — কোন পাত্রে নির্গত O2 "ভারী"।',
  types: {
    ruben: ['রুবেন-কামেন', 'রুবেন ও কামেনের আইসোটোপ পরীক্ষা (1941)', 'ক্লোরেলা শৈবালকে দুই পাত্রে রাখা হয়: (১) H<sub>2</sub><sup>18</sup>O + সাধারণ CO<sub>2</sub> → নির্গত O<sub>2</sub> তে <sup>18</sup>O পাওয়া গেল; (২) সাধারণ H<sub>2</sub>O + C<sup>18</sup>O<sub>2</sub> → নির্গত O<sub>2</sub> সাধারণ। সিদ্ধান্ত: নির্গত O<sub>2</sub> এর সবটুকু আসে পানি থেকে।'],
    vanniel: ['ভ্যান নীল', 'ভ্যান নীলের সাধারণ সমীকরণ (1931)', 'বেগুনি সালফার ব্যাকটেরিয়া পানির বদলে H<sub>2</sub>S ব্যবহার করে এবং O<sub>2</sub> এর বদলে সালফার ছাড়ে: CO<sub>2</sub> + 2H<sub>2</sub>S → (CH<sub>2</sub>O) + 2S + H<sub>2</sub>O। সাধারণ রূপ: CO<sub>2</sub> + 2H<sub>2</sub>A → (CH<sub>2</sub>O) + 2A + H<sub>2</sub>O। সবুজ উদ্ভিদে H<sub>2</sub>A = H<sub>2</sub>O, তাই 2A = O<sub>2</sub>।']
  },
  art(g, C, ty) {
    if (ty === 'vanniel') {
      T(g, 180, 36, ch('CO_2 + 2H_2A → (CH_2O) + 2A + H_2O'), { fs: 14, a: 'middle', w: 650, c: C.fg });
      [[90, 'সবুজ উদ্ভিদ', 'H_2O', 'O_2', 5, 0], [270, 'সালফার ব্যাকটেরিয়া', 'H_2S', 'S', 6, 6]].forEach(([x, s, a, b, r1, r2]) => {
        E('rect', { x: x - 78, y: 62, width: 156, height: 170, rx: 14, fill: FK.alpha(BK.ramp(r1 === 5 ? 10 : 3).c, .1), stroke: FK.alpha(C.mu, .6) }, g);
        T(g, x, 84, s, { fs: 11, a: 'middle', w: 600, c: C.fg });
        B9.ion(g, x - 36, 130, a, BK.ramp(r1), 17, { fs: 10 }); B9.ion(g, x + 36, 200, b, BK.ramp(r2), 17, { fs: 10 });
        BK.arrow(g, x - 20, 144, x + 22, 186, C.mu, 1.6); T(g, x - 36, 166, ch('2H_2A'), { fs: 9.5, a: 'middle', c: C.mu }); T(g, x + 36, 230, '2A', { fs: 9.5, a: 'middle', c: C.mu });
      });
      T(g, 180, 254, 'দুই ক্ষেত্রেই "A" আসে হাইড্রোজেন দাতা থেকে — CO2 থেকে নয়', { fs: 9.5, a: 'middle', c: C.mu });
      return;
    }
    flask(g, C, 90, ch('H_2^{18}O + CO_2'), 'ভারী পানি'); flask(g, C, 270, ch('H_2O + C^{18}O_2'), 'ভারী CO2');
    T(g, 90, 40, 'নির্গত গ্যাস', { fs: 9.5, a: 'middle', c: C.mu }); T(g, 270, 40, 'নির্গত গ্যাস', { fs: 9.5, a: 'middle', c: C.mu });
    B9.chip(g, 90, 22, ch('ভারী O_2 (^{18}O)'), BK.ramp(4), { w: 96 }); B9.chip(g, 270, 22, ch('সাধারণ O_2 (^{16}O)'), BK.ramp(0), { w: 100 });
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'vanniel') { [90, 270].forEach((x, k) => { const u = (t * .35 + k * .3) % 1, e = FK.ease(u); B9.dot(g, x - 20 + 42 * e, 144 + 42 * e, 3.5, BK.ramp(k ? 6 : 5).dk); }); return; }
    [[90, 4], [270, 0]].forEach(([x, r]) => { for (let i = 0; i < 5; i++) { const u = (t * .3 + i / 5) % 1; E('circle', { cx: (x - 10 + i * 5 + Math.sin(t * 3 + i) * 3).toFixed(1), cy: (180 - u * 140).toFixed(1), r: 3.4 + u * 1.5, fill: FK.alpha(BK.ramp(r).c, .75), stroke: BK.ramp(r).dk, 'stroke-width': .8 }, g); } });
  }
}));

/* ═════════ ২. ব্ল্যাকম্যানের সীমাবদ্ধতা নীতি ═════════ */
const LFb = [46, 34, 284, 150];
const LFc = { co2: [['উচ্চ CO2', 1.0, 4], ['নিম্ন CO2', .45, 9]], temp: [['উচ্চ CO2, 30 °C', 1.0, 2], ['উচ্চ CO2, 15 °C', .5, 5]] };
const lfR = (L, P) => P * (1 - Math.exp(-L / (22 * P)));
V.limiting = Object.assign({}, B9.seg({
  id: 'lf', t: 'লিমিটিং ফ্যাক্টর — ব্ল্যাকম্যানের নীতি (1905)', H: 250, def: 'co2',
  cap: '"কোনো প্রক্রিয়া একাধিক প্রভাবকের ওপর নির্ভরশীল হলে তার হার নিয়ন্ত্রণ করে সবচেয়ে কম পরিমাণে থাকা (সীমাবদ্ধ) প্রভাবকটি।" আলো বাড়ালে প্রথমে হার বাড়ে (আলো সীমাবদ্ধ), তারপর স্থির হয় — তখন CO2 বা তাপ সীমাবদ্ধ। স্লাইডারে আলো বদলাও।',
  types: {
    co2: ['আলো ও CO<sub>2</sub>', 'আলো ও CO2 এর পারস্পরিক সীমাবদ্ধতা', 'নিম্ন CO<sub>2</sub> রেখা আগে সমতল হয় — সেখানে আলো যতই বাড়াও, হার বাড়ে না; CO<sub>2</sub> বাড়ালে তবেই বাড়ে। গ্রিনহাউসে CO<sub>2</sub> বাড়িয়ে (প্রায় 1000 ppm) ফলন বাড়ানো হয় এ জন্যই।'],
    temp: ['আলো ও তাপ', 'আলো ও তাপমাত্রার পারস্পরিক সীমাবদ্ধতা', 'কম আলোতে তাপমাত্রার প্রভাব প্রায় নেই (আলোক রাসায়নিক বিক্রিয়া তাপে কম বদলায়); বেশি আলোতে এনজাইম-নির্ভর আলোক নিরপেক্ষ পর্যায় সীমাবদ্ধ হয় — তখন তাপ বাড়ালে হার বাড়ে।']
  },
  sl: [{ k: 'L', l: 'আলোর তীব্রতা (% সর্বোচ্চ)', min: 0, max: 100, step: 1, val: 30 }],
  art(g, C, ty, ctx) {
    const P = B9.axes(g, C, LFb, { xr: [0, 100], yr: [0, 1.1], lx: 'আলোর তীব্রতা →', ly: 'সালোকসংশ্লেষণের হার', xt: [0, 25, 50, 75, 100], yt: [] });
    ctx.P = P; const L = ctx.v.L;
    LFc[ty].forEach(([s, Pm, r]) => { const R = BK.ramp(r); B9.curve(g, P, x => lfR(x, Pm), 0, 100, { stroke: R.c, 'stroke-width': 3 }); const [lx, ly] = P(96, lfR(96, Pm)); T(g, lx, ly - 8, s.replace('CO2', 'CO<tspan dy="3" font-size="72%">2</tspan><tspan dy="-3"></tspan>'), { fs: 10, a: 'end', w: 600, c: R.ink }); });
    const [x0] = P(L, 0); E('path', { d: `M${x0} ${LFb[1]}V${LFb[1] + LFb[3]}`, stroke: C.mu, 'stroke-dasharray': '3 3' }, g);
    LFc[ty].forEach(([s, Pm, r]) => { const [px, py] = P(L, lfR(L, Pm)); E('circle', { cx: px, cy: py, r: 5, fill: BK.ramp(r).c, stroke: C.sf, 'stroke-width': 2 }, g); });
    const lowPm = LFc[ty][1][1], lim = Math.exp(-L / (22 * lowPm)) > .12 ? 'আলো' : ty === 'co2' ? 'CO2' : 'তাপমাত্রা';
    ctx.lim = lim;
    E('rect', { x: 60, y: 212, width: 240, height: 26, rx: 13, fill: FK.alpha(BK.ramp(6).c, .15), stroke: BK.ramp(6).c }, g);
    T(g, 180, 229, `নিচের রেখায় এখন সীমাবদ্ধ: ${lim}`.replace('CO2', 'CO<tspan dy="3" font-size="72%">2</tspan><tspan dy="-3"></tspan>'), { fs: 11, a: 'middle', w: 650, c: BK.ramp(6).ink });
  },
  more(ty, ctx) { const L = ctx.v.L, [a, b] = LFc[ty]; return `<div class="small">আলো ${L}%: ${a[0]} রেখায় হার ≈ ${Math.round(lfR(L, a[1]) * 100)}%, ${b[0]} রেখায় ≈ ${Math.round(lfR(L, b[1]) * 100)}% (সর্বোচ্চের তুলনায়)। ${ctx.lim === 'আলো' ? 'দুই রেখা প্রায় একসাথে — এখানে আলোই সীমাবদ্ধ।' : 'রেখা দুটি আলাদা হয়ে গেছে — এখন আলো নয়, অন্য প্রভাবকটি সীমাবদ্ধ।'}</div>`; },
  anim(g, C, ty, t, ctx) { if (!t || !ctx.P) return; const L = ctx.v.L; LFc[ty].forEach(([s, Pm, r]) => { const [px, py] = ctx.P(L, lfR(L, Pm)); E('circle', { cx: px, cy: py, r: (8 + 3 * Math.sin(t * 4)).toFixed(1), fill: 'none', stroke: BK.ramp(r).c, 'stroke-width': 1.4, opacity: .7 }, g); }); }
}));

/* ═════════ ৩. বুদবুদ গণনা ═════════ */
const bubRate = d => { const I = 100 * Math.pow(10 / d, 2); return 60 * (1 - Math.exp(-I / 40)); };
V.bubbleCount = Object.assign({}, B9.seg({
  id: 'bub', t: 'জলজ উদ্ভিদের বুদবুদ গুনে সালোকসংশ্লেষণের হার', H: 250, def: 'a',
  cap: 'পানিতে ডোবানো হাইড্রিলার কাটা প্রান্ত থেকে O2 এর বুদবুদ বের হয়। বাতি কাছে আনলে আলোর তীব্রতা বাড়ে (তীব্রতা ∝ 1/দূরত্ব²), বুদবুদের হারও বাড়ে — একসময় স্থির হয়। পানিতে একটু NaHCO3 দিলে CO2 সীমাবদ্ধ থাকে না। স্লাইডারে বাতির দূরত্ব বদলাও।',
  types: { a: ['বুদবুদ', 'হাইড্রিলার বুদবুদ পরীক্ষা', 'প্রতি মিনিটে বুদবুদের সংখ্যা ≈ সালোকসংশ্লেষণের হার (তুলনামূলক)। সঠিক মাপতে সংগৃহীত গ্যাসের আয়তন মাপা হয়। বুদবুদে প্রধানত O<sub>2</sub>, তবে সামান্য N<sub>2</sub> ও CO<sub>2</sub> ও থাকে।'] },
  sl: [{ k: 'd', l: 'বাতির দূরত্ব (cm)', min: 10, max: 60, step: 1, val: 25 }],
  art(g, C, ty, ctx) {
    const d = ctx.v.d, lx = 40 + (d - 10) / 50 * 140, Rw = BK.ramp(5), Rg = BK.ramp(10), Ry = BK.ramp(6);
    ctx.lx = lx;
    E('path', { d: `M${lx} 120l-14 -22h28Z`, fill: Ry.c, stroke: Ry.dk }, g); E('circle', { cx: lx, cy: 126, r: 10, fill: '#fff6c4', stroke: Ry.dk }, g); E('path', { d: `M${lx} 98V40`, stroke: C.mu, 'stroke-width': 2 }, g);
    for (let k = 0; k < 4; k++) E('path', { d: `M${lx + 16 + k * 12} ${126 - 6 + k * 4}h${Math.max(4, 22 - d / 3)}`, stroke: FK.alpha(Ry.c, .7), 'stroke-width': 2 }, g);
    E('rect', { x: 230, y: 60, width: 110, height: 150, rx: 6, fill: FK.alpha(Rw.c, .3), stroke: C.fg, 'stroke-width': 1.3 }, g);
    E('path', { d: 'M285 196V110', stroke: Rg.dk, 'stroke-width': 3 }, g); for (let i = 0; i < 6; i++) { const y = 186 - i * 14; E('path', { d: `M285 ${y}l-14 -6M285 ${y}l14 -6`, stroke: Rg.c, 'stroke-width': 3, 'stroke-linecap': 'round' }, g); }
    E('path', { d: 'M285 108l-6 -8h12Z', fill: Rg.dk }, g);
    E('path', { d: `M${lx} 140V214H230`, stroke: FK.alpha(C.mu, .5), 'stroke-dasharray': '3 3', fill: 'none' }, g); T(g, (lx + 230) / 2, 230, `দূরত্ব ${d} cm`, { fs: 10.5, a: 'middle', c: C.fg });
    const I = 100 * Math.pow(10 / d, 2), r = bubRate(d);
    T(g, 12, 22, `আলোর তীব্রতা ∝ 1/d² → ${FK.n(I, 0)} একক`, { fs: 10.5, c: C.fg }); T(g, 348, 46, `≈ ${FK.n(r, 0)} বুদবুদ/মিনিট`, { fs: 11.5, a: 'end', w: 650, c: Rw.ink });
    T(g, 285, 222, 'হাইড্রিলা', { fs: 9.5, a: 'middle', c: C.mu });
  },
  more(ty, ctx) { const d = ctx.v.d; return `<div class="small">বিপরীত বর্গ সূত্র: দূরত্ব ${d} cm থেকে অর্ধেক (${FK.n(d / 2, 1)} cm) করলে আলো 4 গুণ হয়। বেশি কাছে আনলে বাতির তাপও প্রভাব ফেলে — তাই মাঝে পানির পাত্র (তাপ শোষক) রাখা ভালো।</div>`; },
  anim(g, C, ty, t, ctx) { if (!t) return; const r = bubRate(ctx.v.d), sp = r / 60, n = Math.max(1, Math.round(r / 8)); for (let i = 0; i < n; i++) { const u = (t * (.25 + sp * .6) + i / n) % 1; E('circle', { cx: (285 + Math.sin(t * 3 + i) * 2).toFixed(1), cy: (104 - u * 44).toFixed(1), r: 2.6 + u, fill: '#fff', stroke: BK.ramp(5).dk, 'stroke-width': .8, opacity: 1 - u * .4 }, g); } const lx = ctx.lx; E('circle', { cx: lx, cy: 126, r: (14 + 2 * Math.sin(t * 6)).toFixed(1), fill: FK.alpha(BK.ramp(6).c, .25) }, g); }
}));

/* ═════════ ৪. হার নিয়ন্ত্রণ (গ্রিনহাউস) ═════════ */
const fL = L => 1 - Math.exp(-L / 25), fC = c => 1 - Math.exp(-c / 450), fT = T => T <= 30 ? Math.max(0, (T - 0) / 30) ** 1.2 : Math.max(0, 1 - ((T - 30) / 14) ** 2);
V.rateCtrl = Object.assign({}, B9.seg({
  id: 'rc', t: 'আলো, CO2 ও তাপ নিয়ন্ত্রণ করে হার বাড়ানো (গ্রিনহাউস)', H: 230, def: 'a', k: ['2d', 'anim', 'int'],
  cap: 'তিনটি স্লাইডার — আলো, CO2 ও তাপমাত্রা। হার নির্ধারণ করে যেটি সবচেয়ে "কম অনুকূল" (সীমাবদ্ধ)। সীমাবদ্ধটি বাড়ালেই হার বাড়ে, অন্যটি বাড়িয়ে লাভ হয় না — কৃষক ও গ্রিনহাউস চাষিরা এভাবেই খরচ বাঁচিয়ে ফলন বাড়ান।',
  types: { a: ['নিয়ন্ত্রণ', 'হার নিয়ন্ত্রণ', 'আলো: কৃত্রিম বাতি বা ছায়া-জাল; CO<sub>2</sub>: গ্রিনহাউসে 800–1000 ppm পর্যন্ত বাড়ানো; তাপ: 25–30 °C এর কাছে রাখা; ক্লোরোফিল: N ও Mg সার দিয়ে সুস্থ সবুজ পাতা রাখা।'] },
  sl: [{ k: 'L', l: 'আলো (%)', min: 0, max: 100, step: 1, val: 70 }, { k: 'c', l: 'CO<sub>2</sub> (ppm)', min: 100, max: 1500, step: 10, val: 420 }, { k: 'T', l: 'তাপমাত্রা (°C)', min: 5, max: 45, step: 1, val: 28 }],
  art(g, C, ty, ctx) {
    const v = ctx.v, a = [['আলো', fL(v.L), 6], ['CO2', fC(v.c), 9], ['তাপ', fT(v.T), 2]], m = Math.min(...a.map(x => x[1])), lim = a.find(x => x[1] === m)[0];
    ctx.rate = m; ctx.lim = lim;
    a.forEach(([s, f, r], i) => { const y = 28 + i * 36, R = BK.ramp(r), on = s === lim; T(g, 12, y + 13, s.replace('CO2', 'CO<tspan dy="3" font-size="72%">2</tspan><tspan dy="-3"></tspan>'), { fs: 11, w: 600, c: on ? R.ink : C.fg }); E('rect', { x: 60, y, width: 200, height: 18, rx: 9, fill: FK.alpha(R.c, .14) }, g); E('rect', { x: 60, y, width: Math.max(18, 200 * f), height: 18, rx: 9, fill: R.c, stroke: on ? C.fg : 'none', 'stroke-width': 1.6 }, g); T(g, 270, y + 13, `${Math.round(f * 100)}%`, { fs: 10.5, w: 600, c: R.ink }); if (on) T(g, 352, y + 13, 'সীমাবদ্ধ', { fs: 10, a: 'end', w: 650, c: BK.ramp(4).ink }); });
    E('path', { d: `M${60 + 200 * m} 22V128`, stroke: C.fg, 'stroke-dasharray': '4 3' }, g);
    T(g, 12, 158, 'সালোকসংশ্লেষণের হার', { fs: 11, w: 600, c: C.fg }); E('rect', { x: 12, y: 166, width: 300, height: 22, rx: 11, fill: FK.alpha(BK.ramp(10).c, .14) }, g); E('rect', { x: 12, y: 166, width: Math.max(22, 300 * m), height: 22, rx: 11, fill: BK.ramp(10).c }, g); T(g, 320, 182, `${Math.round(m * 100)}%`, { fs: 12, w: 650, c: BK.ramp(10).ink });
    T(g, 12, 214, `হার = সবচেয়ে কম অনুকূল প্রভাবক (${lim}) — ব্ল্যাকম্যানের নীতির সরল রূপ`.replace('CO2', 'CO<tspan dy="3" font-size="72%">2</tspan><tspan dy="-3"></tspan>'), { fs: 9.5, c: C.mu });
  },
  more(ty, ctx) { return `<div class="small">এখন সীমাবদ্ধ: <b>${ctx.lim === 'CO2' ? 'CO<sub>2</sub>' : ctx.lim}</b> — এটি বাড়ালে হার বাড়বে।${ctx.v.T > 38 ? ' অতিরিক্ত তাপে এনজাইম বিনষ্ট হয় ও রন্ধ্র বন্ধ হয় — হার দ্রুত কমে।' : ''}</div>`; },
  anim(g, C, ty, t, ctx) { if (!t) return; const m = ctx.rate || 0, n = Math.round(m * 6); for (let i = 0; i < n; i++) { const u = (t * .5 + i / Math.max(1, n)) % 1; B9.dot(g, 16 + u * 290 * m, 177, 3, '#fff', .8); } }
}));

/* ═════════ ৫. সালোকসংশ্লেষণের প্রভাবক ═════════ */
V.psFactors = B9.gseg({
  id: 'psf', t: 'সালোকসংশ্লেষণের প্রভাবক', def: 'co2',
  cap: 'বাহ্যিক প্রভাবক: আলো, CO2, তাপমাত্রা, পানি, O2, খনিজ। অভ্যন্তরীণ: ক্লোরোফিল, পাতার গঠন, পাতার বয়স, জমা খাদ্য, এনজাইম। লেখচিত্রে চাপ দিলে ব্যাখ্যা।',
  types: {
    light: { b: 'আলো', t: 'আলোর তীব্রতা', d: 'কম আলোতে হার আলোর সমানুপাতিক; আলোক পূরণ বিন্দুতে সালোকসংশ্লেষণ = শ্বসন। আলো আরও বাড়লে হার স্থির (সম্পৃক্ত); খুব তীব্র আলোতে ক্লোরোফিল বিনষ্ট হয় (সোলারাইজেশন) — হার কমে।', c: 6, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'আলো (% পূর্ণ রোদ)', u: '%', f: x => Math.max(0, (1 - Math.exp(-x / 18)) - (x > 85 ? (x - 85) * .012 : 0)), mk: [[3, 'আলোক পূরণ বিন্দু', 0, 'start']], read: x => x < 4 ? 'আলোক পূরণ বিন্দুর কাছে — নিট O2 নির্গমন প্রায় শূন্য।' : x > 85 ? 'অতি তীব্র আলো — আলোক-বাধা (ফটোইনহিবিশন)।' : 'আলো বাড়লে হার বাড়ে, পরে স্থির।' },
    co2: { b: 'CO<sub>2</sub>', t: 'বাতাসে CO2 এর ঘনত্ব', d: 'বাতাসে CO<sub>2</sub> মাত্র প্রায় 0.04% (≈ 420 ppm) — প্রায়ই এটিই সীমাবদ্ধ। CO<sub>2</sub> বাড়ালে হার বাড়ে, প্রায় 0.1% (1000 ppm) এর পর স্থির; অনেক বেশি হলে (প্রায় 1% এর বেশি) রন্ধ্র বন্ধ হয়, বিষক্রিয়া।', c: 9, xr: [0, 2000], xt: [0, 500, 1000, 1500, 2000], lx: 'CO2 (ppm)', u: ' ppm', f: x => Math.max(0, 1 - Math.exp(-(x - 50) / 380)), mk: [[420, 'এখনকার বাতাস', 0, 'start']], read: x => x < 60 ? 'CO2 পূরণ বিন্দুর নিচে — সালোকসংশ্লেষণ শ্বসনের চেয়ে কম।' : x > 1200 ? 'সম্পৃক্তির কাছে — অন্য প্রভাবক সীমাবদ্ধ।' : 'CO2 বাড়ালে হার বাড়ে।' },
    temp: { b: 'তাপমাত্রা', t: 'তাপমাত্রা', d: 'আলোক নিরপেক্ষ পর্যায় এনজাইম-নির্ভর — প্রায় 25–35 °C এ সর্বোচ্চ (Q<sub>10</sub> ≈ 2)। বেশি তাপে এনজাইম বিনষ্ট ও রন্ধ্র বন্ধ, আলোকশ্বসন বাড়ে — হার দ্রুত কমে।', c: 2, xr: [0, 50], xt: [0, 10, 20, 30, 40, 50], lx: 'তাপমাত্রা (°C)', u: ' °C', f: x => x <= 30 ? Math.pow(x / 30, 1.3) : Math.max(0, 1 - Math.pow((x - 30) / 14, 2)), mk: [[30, 'অনুকূল', 1]], read: x => x > 40 ? 'এনজাইম বিনষ্ট হতে শুরু করে।' : x < 8 ? 'এনজাইম প্রায় নিষ্ক্রিয়।' : 'তাপ বাড়লে এনজাইমের ক্রিয়া বাড়ে।' },
    water: { b: 'পানি', t: 'মাটিতে পানি', d: 'বিক্রিয়ায় পানি লাগে মোট শোষিত পানির 1% এরও কম — তাই পানির প্রভাব মূলত পরোক্ষ: পানির অভাবে রন্ধ্র বন্ধ (ABA), CO<sub>2</sub> ঢুকতে পারে না, কোষের রসস্ফীতি ও এনজাইম কমে।', c: 5, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'মাটির পানি (% ধারণক্ষমতা)', u: '%', f: x => .05 + .95 / (1 + Math.exp(-(x - 35) / 8)), read: x => x < 25 ? 'রন্ধ্র বন্ধ — CO2 প্রবেশ কমে।' : 'যথেষ্ট পানি।' },
    o2: { b: 'O<sub>2</sub>', t: 'অক্সিজেনের ঘনত্ব (ওয়ারবার্গ প্রভাব)', d: 'O<sub>2</sub> বাড়লে RuBisCO এর অক্সিজিনেশন (আলোকশ্বসন) বাড়ে, C3 উদ্ভিদে সালোকসংশ্লেষণ কমে — ওয়ারবার্গ প্রভাব (1920)। C4 উদ্ভিদে এ প্রভাব প্রায় নেই।', c: 0, xr: [0, 100], xt: [0, 21, 50, 75, 100], lx: 'O2 (%)', u: '%', f: x => 1 - .55 * x / (x + 25), mk: [[21, 'বাতাস (21%)', 1]], read: x => x > 21 ? 'বেশি O2 — আলোকশ্বসন বেশি।' : 'কম O2 — আলোকশ্বসন কম, নিট হার বেশি।' },
    chl: { b: 'ক্লোরোফিল', t: 'ক্লোরোফিলের পরিমাণ (অভ্যন্তরীণ)', d: 'ক্লোরোফিল ছাড়া সালোকসংশ্লেষণ হয় না; তবে ক্লোরোফিল বাড়লেই হার সমানুপাতে বাড়ে না — প্রতি একক ক্লোরোফিলে হার (সমীকরণ সংখ্যা) সবুজ-হলুদ (কম ক্লোরোফিল) পাতায় বরং বেশি হতে পারে। N, Mg, Fe এর অভাবে ক্লোরোফিল কমে (ক্লোরোসিস)।', c: 10, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'ক্লোরোফিল (% স্বাভাবিক)', u: '%', f: x => 1 - Math.exp(-x / 30), read: x => x < 20 ? 'ক্লোরোটিক পাতা — হার কম।' : 'আলো বা CO2 সীমাবদ্ধ হলে বাড়তি ক্লোরোফিলে লাভ কম।' }
  }
});

/* ═════════ ৬. মোলের অর্ধপত্র পরীক্ষা ═════════ */
const mollLeaf = (g, C, res) => {
  const Rg = BK.ramp(10), Rb = BK.ramp(9);
  E('path', { d: 'M40 150Q110 96 190 150Q110 204 40 150Z', fill: res ? (res === 1 ? FK.alpha(BK.ramp(6).c, .5) : FK.alpha(BK.ramp(6).c, .5)) : Rg.c, stroke: Rg.dk }, g);
  E('path', { d: 'M190 150Q260 96 330 150Q260 204 190 150Z', fill: res ? 'rgb(52,48,92)' : Rg.c, stroke: Rg.dk }, g);
  E('path', { d: 'M40 150H330', stroke: Rg.dk, 'stroke-width': 1.2 }, g);
  if (res) { T(g, 115, 154, 'বাদামি-হলুদ', { fs: 10, a: 'middle', w: 600, c: BK.ramp(6).ink }); T(g, 262, 154, 'নীল-কালো', { fs: 10, a: 'middle', w: 600, c: '#fff', st: 'stroke:none' }); }
  E('rect', { x: 180, y: 118, width: 20, height: 64, rx: 4, fill: res ? FK.alpha(BK.ramp(6).c, .5) : BK.ramp(2).c, stroke: BK.ramp(2).dk, opacity: res ? .9 : 1 }, g);
};
V.molls = Object.assign({ t: 'ব্যবহারিক: সালোকসংশ্লেষণে CO2 এর অপরিহার্যতা (মোলের অর্ধপত্র পরীক্ষা)', k: ['anim', 'steps', 'lab'], cap: 'একই পাতার একটি অংশ CO2-হীন বাতাসে (KOH শোষণ করে নেয়), অন্য অংশ সাধারণ বাতাসে রেখে আলো দেওয়া হয়। আয়োডিন পরীক্ষায় শুধু বাইরের অংশে শ্বেতসার পাওয়া যায় — অর্থাৎ CO2 ছাড়া সালোকসংশ্লেষণ হয় না।' }, BK.steps({
  W: 360, H: 250, label: 'মোলের অর্ধপত্র পরীক্ষা', dur: 2.8,
  stages: [
    { t: 'শ্বেতসারমুক্ত করা', en: 'Destarch the plant', d: 'টবের গাছটি 48 ঘণ্টা অন্ধকারে রাখো — পাতার জমা শ্বেতসার খরচ হয়ে যায়। (পরীক্ষার আগে একটি পাতায় আয়োডিন দিয়ে নিশ্চিত হও।)' },
    { t: 'অর্ধেক পাতা KOH বোতলে', en: 'Half leaf in KOH flask', d: 'একটি চওড়া মুখের বোতলে কিছু KOH দ্রবণ নাও। গাছে থাকা অবস্থাতেই একটি পাতার অর্ধেক লম্বালম্বি চেরা কর্কের ফাঁক দিয়ে বোতলের ভেতরে ঢোকাও; অর্ধেক বাইরে থাকে। কর্কে ভেসলিন লাগিয়ে বায়ুরোধী করো। KOH বোতলের CO<sub>2</sub> শোষণ করে।' },
    { t: 'আলোতে রাখা', en: 'Expose to light', d: 'পুরো ব্যবস্থাটি কয়েক ঘণ্টা সূর্যালোকে রাখো। পাতার বাইরের অংশ পায় আলো + CO<sub>2</sub>; ভেতরের অংশ পায় আলো, কিন্তু CO<sub>2</sub> নেই।' },
    { t: 'আয়োডিন পরীক্ষা', en: 'Starch test', d: 'পাতাটি ছিঁড়ে ফুটন্ত পানিতে 2–3 মিনিট সেদ্ধ করো (কোষ মরে, ঝিল্লি ভাঙে), তারপর গরম পানিতে বসানো অ্যালকোহলে রেখে ক্লোরোফিল সরাও (সাদাটে), পানিতে ধুয়ে নরম করে আয়োডিন দ্রবণে ডোবাও।' },
    { t: 'ফলাফল ও সিদ্ধান্ত', en: 'Result', d: 'বোতলের বাইরের অংশ নীল-কালো (শ্বেতসার আছে); বোতলের ভেতরের অংশ ও কর্কে চাপা অংশ বাদামি-হলুদ (শ্বেতসার নেই)। সিদ্ধান্ত: সালোকসংশ্লেষণে CO<sub>2</sub> অপরিহার্য। (কর্কের অংশ নিয়ন্ত্রণ নয় — সেখানে আলো ও CO<sub>2</sub> দুটোই কম।)' }
  ],
  draw(g, C, s, u) {
    const Rg = BK.ramp(10), Rw = BK.ramp(5);
    if (s === 0) { E('rect', { x: 0, y: 0, width: 360, height: 250, rx: 12, fill: FK.alpha('#000', .25 * FK.ease(u)) }, g); E('path', { d: 'M150 220h60l-8 -40h-44Z', fill: BK.ramp(2).c }, g); E('path', { d: 'M180 182V70', stroke: Rg.dk, 'stroke-width': 3 }, g); [[120, -1], [100, 1], [84, -1]].forEach(([y, sd]) => E('path', { d: `M180 ${y}q${sd * 18} -14 ${sd * 44} -4q${-sd * 24} 14 ${-sd * 44} 4Z`, fill: Rg.c, stroke: Rg.dk }, g)); T(g, 180, 240, `অন্ধকারে ${Math.round(48 * u)} ঘণ্টা`, { fs: 11, a: 'middle', w: 600, c: C.fg }); return; }
    const res = s === 4 ? 1 : 0;
    if (s < 3) {
      E('path', { d: 'M196 112V100h30v12Q290 120 290 170Q290 224 211 226Q132 224 132 170Q132 120 196 112Z', fill: FK.alpha(Rw.c, .15), stroke: C.fg, 'stroke-width': 1.3 }, g);
      E('rect', { x: 140, y: 196, width: 142, height: 26, rx: 10, fill: FK.alpha(BK.ramp(3).c, .35) }, g); T(g, 211, 214, 'KOH দ্রবণ', { fs: 10, a: 'middle', w: 600, c: BK.ramp(3).ink });
      E('path', { d: 'M211 100V30', stroke: Rg.dk, 'stroke-width': 3 }, g);
      E('path', { d: 'M211 104Q260 96 274 150Q230 150 211 104Z', fill: Rg.c, stroke: Rg.dk, opacity: s >= 1 ? 1 : 0 }, g);
      E('path', { d: `M211 100Q${150 - 20 * (s >= 1 ? 1 : u)} 70 120 40Q170 60 211 100Z`, fill: Rg.c, stroke: Rg.dk }, g);
      E('rect', { x: 194, y: 92, width: 34, height: 14, rx: 3, fill: BK.ramp(2).c }, g); T(g, 238, 98, 'চেরা কর্ক', { fs: 9.5, c: C.mu });
      T(g, 90, 30, 'বাইরের অংশ', { fs: 10, a: 'middle', c: C.fg }); T(g, 320, 140, 'ভেতরের', { fs: 10, a: 'middle', c: C.fg }); T(g, 320, 154, 'অংশ', { fs: 10, a: 'middle', c: C.fg });
      if (s === 2) { for (let k = 0; k < 6; k++) { const a = -PI * .9 + k * .15; E('path', { d: `M${40 + 10 * Math.cos(a)} ${40 + 10 * Math.sin(a)}l${-12 * Math.cos(a)} ${-12 * Math.sin(a)}`, stroke: BK.ramp(6).c, 'stroke-width': 2 }, g); } E('circle', { cx: 40, cy: 40, r: 12 + 2 * Math.sin(u * 20), fill: BK.ramp(6).c }, g); for (let k = 0; k < 3; k++) B9.ion(g, 100 + k * 26, 66 + ((u * 3 + k) % 1) * 20, 'CO_2', BK.ramp(9), 9, { fs: 6.5 }); }
      if (s === 1) { const k = FK.ease(u); B9.ion(g, 211, 150 + 50 * k, 'CO_2', BK.ramp(9), 10, { fs: 7, op: 1 - k }); }
      return;
    }
    if (s === 3) { const st = Math.min(2, Math.floor(u * 3)); ['ফুটন্ত পানি', 'অ্যালকোহল', 'আয়োডিন'].forEach((n, i) => { const R = BK.ramp([5, 7, 2][i]); E('rect', { x: 30 + i * 108, y: 110, width: 84, height: 80, rx: 10, fill: FK.alpha(R.c, i === st ? .45 : .15), stroke: R.dk, 'stroke-width': i === st ? 2 : 1 }, g); T(g, 72 + i * 108, 210, n, { fs: 10.5, a: 'middle', w: i === st ? 650 : 500, c: R.ink }); }); E('path', { d: `M${50 + st * 108} 150q22 -18 44 0q-22 18 -44 0Z`, fill: st === 0 ? Rg.c : FK.alpha(Rg.c, .25), stroke: Rg.dk }, g); return; }
    mollLeaf(g, C, res); T(g, 115, 92, 'KOH বোতলের ভেতরে ছিল', { fs: 10, a: 'middle', c: C.fg }); T(g, 262, 92, 'বাইরে ছিল', { fs: 10, a: 'middle', c: C.fg }); T(g, 190, 204, 'কর্কে চাপা', { fs: 9.5, a: 'middle', c: C.mu });
    T(g, 115, 226, ch('CO_2 নেই → শ্বেতসার নেই'), { fs: 10, a: 'middle', w: 600, c: BK.ramp(6).ink }); T(g, 262, 226, 'শ্বেতসার আছে', { fs: 10, a: 'middle', w: 600, c: BK.ramp(3).ink });
  }
}));

/* ═════════ ৭. সালোকসংশ্লেষণের গুরুত্ব ═════════ */
V.psImportance = Object.assign({ t: 'জীবজগতে সালোকসংশ্লেষণের গুরুত্ব', k: ['mind', 'int'], cap: 'পৃথিবীর প্রায় সব জীবের খাদ্য, বাতাসের অক্সিজেন ও জীবাশ্ম জ্বালানির উৎস সালোকসংশ্লেষণ। শাখায় চাপ দাও।' }, BK.mind({
  t: 'সালোকসংশ্লেষণ', d: 'আলোক শক্তিকে রাসায়নিক শক্তিতে রূপান্তরের একমাত্র বড় প্রাকৃতিক প্রক্রিয়া।',
  c: [
    { t: 'খাদ্যের উৎস', d: 'উৎপাদক হিসেবে উদ্ভিদ শর্করা তৈরি করে — খাদ্যশৃঙ্খলের ভিত্তি; সব প্রাণী প্রত্যক্ষ বা পরোক্ষভাবে নির্ভরশীল।' },
    { t: 'O2 সরবরাহ', d: 'বায়ুমণ্ডলের প্রায় 21% O<sub>2</sub> সালোকসংশ্লেষণের দান — সবাত শ্বসন ও ওজোন স্তরের উৎস।' },
    { t: 'CO2 এর ভারসাম্য', d: 'শ্বসন ও দহনে তৈরি CO<sub>2</sub> শোষণ করে বাতাসের CO<sub>2</sub> নিয়ন্ত্রণ করে — বৈশ্বিক উষ্ণায়ন কমাতে বনায়ন।' },
    { t: 'শক্তির উৎস', d: 'কয়লা, পেট্রোলিয়াম, প্রাকৃতিক গ্যাস — অতীতের সালোকসংশ্লেষণে জমা সৌরশক্তি; কাঠ ও জৈব জ্বালানিও।' },
    { t: 'অর্থনৈতিক গুরুত্ব', d: 'খাদ্যশস্য, ফল, কাঠ, তুলা-পাট, ওষুধ, রাবার — সব সালোকসংশ্লেষণের উৎপাদ।' },
    { t: 'অন্যান্য', d: 'শ্বসনের কাঁচামাল (শর্করা) জোগায়; প্রোটিন, চর্বি সংশ্লেষণের কার্বন কঙ্কাল দেয়; জলজ জীবের জন্য পানিতে O<sub>2</sub> দ্রবীভূত করে।' }
  ]
}, { colW: 120 }));

/* ═════════ ৮. ATP এর গঠন ═════════ */
V.atpStruct = Object.assign({}, B9.seg({
  id: 'atp', t: 'কোষের শক্তির মুদ্রা — ATP', H: 236, def: 'str',
  cap: 'ATP = অ্যাডেনিন (নাইট্রোজেন ক্ষারক) + রাইবোজ (5C শর্করা) + তিনটি ফসফেট। শেষ দুটি ফসফেটের বন্ধন "উচ্চ শক্তির" — শেষ ফসফেট ভাঙলে (হাইড্রোলাইসিস) প্রায় 30.5 kJ (7.3 kcal) প্রতি মোল শক্তি মুক্ত হয় এবং ADP + Pi হয়। চালাও।',
  types: {
    str: ['গঠন', 'ATP এর গঠন ও হাইড্রোলাইসিস', 'ATP + H<sub>2</sub>O → ADP + Pi + প্রায় 30.5 kJ/mol (প্রমিত অবস্থায়; কোষের ভেতরে প্রায় 50 kJ/mol)। ATP নামকরণ: অ্যাডেনোসিন ট্রাইফসফেট — অ্যাডেনোসিন = অ্যাডেনিন + রাইবোজ। আবিষ্কার: লোহম্যান (1929)।'],
    cyc: ['ATP-ADP চক্র', 'ATP-ADP চক্র', 'শ্বসন ও সালোকসংশ্লেষণে ADP + Pi থেকে ATP তৈরি হয় (ফসফোরাইলেশন); পেশি সংকোচন, সক্রিয় পরিবহন, জৈব সংশ্লেষণে ATP ভেঙে শক্তি খরচ হয়। একটি কোষে ATP প্রতি মিনিটে বহুবার পুনর্ব্যবহৃত হয় — তাই একে শক্তির মুদ্রা বলে।']
  },
  art(g, C, ty) {
    if (ty === 'cyc') {
      node(g, 180, 50, 'ATP', BK.ramp(6), 70, 28, { fs: 13 }); node(g, 180, 190, 'ADP + Pi', BK.ramp(9), 96, 28, { fs: 12 });
      E('path', { d: 'M140 180Q60 120 140 62', stroke: BK.ramp(10).c, 'stroke-width': 4, fill: 'none' }, g); BK.arrow(g, 132, 70, 142, 60, BK.ramp(10).c, 3);
      E('path', { d: 'M220 62Q300 120 220 180', stroke: BK.ramp(4).c, 'stroke-width': 4, fill: 'none' }, g); BK.arrow(g, 228, 172, 218, 182, BK.ramp(4).c, 3);
      T(g, 70, 112, 'শক্তি গ্রহণ', { fs: 10.5, a: 'middle', w: 600, c: BK.ramp(10).ink }); T(g, 70, 128, 'শ্বসন, সালোকসংশ্লেষণ', { fs: 9.5, a: 'middle', c: C.mu });
      T(g, 290, 112, 'শক্তি মুক্তি', { fs: 10.5, a: 'middle', w: 600, c: BK.ramp(4).ink }); T(g, 290, 128, 'কাজ: পরিবহন, সংশ্লেষ', { fs: 9.5, a: 'middle', c: C.mu });
      T(g, 180, 226, 'ফসফোরাইলেশন ⇄ হাইড্রোলাইসিস', { fs: 10, a: 'middle', c: C.mu });
      return;
    }
    const Ra = BK.ramp(3), Rr = BK.ramp(7), Rp = BK.ramp(6);
    E('path', { d: 'M22 70l18 -12l18 12v22l-18 12l-18 -12Z', fill: FK.alpha(Ra.c, .35), stroke: Ra.dk, 'stroke-width': 1.3 }, g); E('path', { d: 'M58 70l16 -6l10 14l-10 14l-16 -6', fill: FK.alpha(Ra.c, .35), stroke: Ra.dk, 'stroke-width': 1.3 }, g);
    T(g, 50, 120, 'অ্যাডেনিন', { fs: 10, a: 'middle', w: 600, c: Ra.ink });
    E('path', { d: 'M84 78L100 96', stroke: C.fg, 'stroke-width': 1.4 }, g);
    E('path', { d: 'M100 96l14 -10l18 4l4 18l-20 8Z', fill: FK.alpha(Rr.c, .35), stroke: Rr.dk, 'stroke-width': 1.3 }, g); T(g, 118, 136, 'রাইবোজ', { fs: 10, a: 'middle', w: 600, c: Rr.ink });
    E('path', { d: 'M132 90L150 80', stroke: C.fg, 'stroke-width': 1.4 }, g);
    E('path', { d: 'M28 150H134', stroke: C.mu, 'stroke-width': 1 }, g); T(g, 80, 166, 'অ্যাডেনোসিন', { fs: 9.5, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    const Rp = BK.ramp(6);
    if (ty === 'cyc') { if (!t) return; const a = t * .9; B9.dot(g, 180 + 92 * Math.cos(a) * .9, 120 + 70 * Math.sin(a), 5, Rp.dk); return; }
    const u = t ? (t * .3) % 1 : 0, br = u > .45, k = br ? FK.ease(Math.min(1, (u - .45) / .4)) : 0;
    [0, 1, 2].forEach(i => { const x = 166 + i * 52 + (i === 2 ? 30 * k : 0), y = 80 - (i === 2 ? 30 * k : 0); E('circle', { cx: x, cy: y, r: 16, fill: FK.alpha(Rp.c, .5), stroke: Rp.dk, 'stroke-width': 1.3 }, g); T(g, x, y + 4, 'P', { fs: 12, a: 'middle', w: 650, c: Rp.ink }); if (i > 0) { const px = 166 + (i - 1) * 52 + 16, nx = x - 16; if (!(i === 2 && br)) E('path', { d: `M${px} 80L${nx} ${y}`, stroke: Rp.dk, 'stroke-width': 2.6, 'stroke-dasharray': '1 3' }, g); } });
    T(g, 218, 50, i18(), { fs: 9, a: 'middle', c: C.mu });
    T(g, 192, 116, '~', { fs: 14, a: 'middle', c: Rp.ink }); T(g, 244, 116, '~', { fs: 14, a: 'middle', c: Rp.ink }); T(g, 218, 134, 'উচ্চ শক্তির বন্ধন', { fs: 9.5, a: 'middle', c: Rp.ink });
    if (br) { for (let i = 0; i < 6; i++) { const a = i / 6 * PI * 2, r = 10 + 30 * k; E('path', { d: `M${246 + r * Math.cos(a)} ${66 + r * Math.sin(a)}l${4 * Math.cos(a)} ${4 * Math.sin(a)}`, stroke: Rp.c, 'stroke-width': 2, opacity: 1 - k * .6 }, g); } T(g, 270, 196, '≈ 30.5 kJ/mol মুক্ত', { fs: 11, a: 'middle', w: 650, c: Rp.ink }); T(g, 180, 222, ch('ATP + H_2O → ADP + Pi'), { fs: 11, a: 'middle', w: 600, c: C.fg }); } else T(g, 180, 222, 'ATP — অ্যাডেনোসিন ট্রাইফসফেট', { fs: 11, a: 'middle', w: 600, c: C.fg });
  }
}));
function i18() { return 'α          β          γ'; }

/* ═════════ ৯. শ্বসনের চার ধাপ ═════════ */
const RS = [
  ['গ্লাইকোলাইসিস', 'সাইটোপ্লাজম', 'গ্লুকোজ (6C) → 2 পাইরুভিক অ্যাসিড (3C); নিট 2 ATP + 2 NADH। O<sub>2</sub> লাগে না — সবাত ও অবাত দুই শ্বসনেই সাধারণ ধাপ।', [70, 150]],
  ['পাইরুভিক অ্যাসিডের জারণ', 'মাইটোকন্ড্রিয়ার ম্যাট্রিক্স', 'পাইরুভিক অ্যাসিড ম্যাট্রিক্সে ঢুকে 2C অ্যাসিটাইল CoA হয়; প্রতি পাইরুভেটে 1 CO<sub>2</sub> ও 1 NADH — গ্লুকোজপ্রতি 2 CO<sub>2</sub>, 2 NADH। (সংযোগ বিক্রিয়া)', [190, 92]],
  ['ক্রেবস চক্র', 'মাইটোকন্ড্রিয়ার ম্যাট্রিক্স', 'অ্যাসিটাইল CoA সম্পূর্ণ জারিত হয়: গ্লুকোজপ্রতি (চক্র দুবার) 4 CO<sub>2</sub>, 6 NADH, 2 FADH<sub>2</sub>, 2 ATP।', [262, 130]],
  ['ইলেকট্রন পরিবহন ও অক্সিডেটিভ ফসফোরাইলেশন', 'মাইটোকন্ড্রিয়ার অন্তঃপর্দা (ক্রিস্টি)', 'NADH ও FADH<sub>2</sub> এর ইলেকট্রন শৃঙ্খল বেয়ে O<sub>2</sub> তে যায় (পানি তৈরি হয়); মুক্ত শক্তিতে H<sup>+</sup> পাম্প হয়ে ATP সিনথেজে সবচেয়ে বেশি ATP তৈরি হয়।', [300, 196]]
];
V.respOverview = Object.assign({}, B9.seg({
  id: 'rso', t: 'সবাত শ্বসনের চারটি ধাপ ও কোষে তাদের স্থান', H: 262, def: '0',
  cap: 'C6H12O6 + 6O2 → 6CO2 + 6H2O + শক্তি (প্রায় 2870 kJ/mol; তার একটি অংশ ATP তে জমা হয়)। ধাপ বেছে নিলে কোষের কোথায় ঘটে তা আলোকিত হবে।',
  types: { 0: ['১. গ্লাইকোলাইসিস', ...RS[0].slice(0, 1), RS[0][2]], 1: ['২. সংযোগ', RS[1][0], RS[1][2]], 2: ['৩. ক্রেবস', RS[2][0], RS[2][2]], 3: ['৪. ইলেকট্রন পরিবহন', RS[3][0], RS[3][2]] },
  art(g, C, ty) {
    const k = +ty, Rc = BK.ramp(11), Rm = BK.ramp(2);
    E('rect', { x: 8, y: 20, width: 344, height: 222, rx: 30, fill: FK.alpha(Rc.c, k === 0 ? .3 : .1), stroke: Rc.dk, 'stroke-width': 1.5 }, g); T(g, 26, 40, 'কোষ — সাইটোপ্লাজম', { fs: 10, w: 600, c: Rc.ink });
    E('ellipse', { cx: 256, cy: 148, rx: 92, ry: 72, fill: FK.alpha(Rm.c, .15), stroke: Rm.dk, 'stroke-width': 2.4 }, g);
    E('ellipse', { cx: 256, cy: 148, rx: 82, ry: 62, fill: FK.alpha(Rm.c, k === 1 || k === 2 ? .3 : .1), stroke: Rm.dk, 'stroke-width': k === 3 ? 3.4 : 1.4 }, g);
    for (let i = 0; i < 5; i++) { const x = 196 + i * 28; E('path', { d: `M${x} ${92 + (i % 2) * 112}q8 ${(i % 2 ? -1 : 1) * 46} 14 0`, fill: 'none', stroke: k === 3 ? BK.ramp(3).dk : Rm.dk, 'stroke-width': k === 3 ? 3 : 1.4 }, g); }
    T(g, 256, 70, 'মাইটোকন্ড্রিয়া', { fs: 10, a: 'middle', w: 600, c: Rm.ink });
    E('circle', { cx: 262, cy: 140, r: 24, fill: 'none', stroke: BK.ramp(0).c, 'stroke-width': 5, opacity: k === 2 ? .9 : .3 }, g);
    node(g, 70, 150, 'গ্লুকোজ → 2 পাইরুভেট', BK.ramp(7), 118, 24, { fs: 9.5, sw: k === 0 ? 2.4 : 1 });
    node(g, 166, 98, 'অ্যাসিটাইল CoA', BK.ramp(9), 92, 22, { fs: 9.5, sw: k === 1 ? 2.4 : 1 });
    BK.arrow(g, 120, 140, 150, 110, C.mu, 1.4); BK.arrow(g, 200, 106, 236, 126, C.mu, 1.4);
    T(g, 262, 144, 'TCA', { fs: 10, a: 'middle', w: 650, c: BK.ramp(0).ink });
    T(g, 300, 226, 'ETC + ATP সিনথেজ', { fs: 9.5, a: 'middle', w: 600, c: BK.ramp(3).ink });
    const [x, y] = RS[k][3]; E('circle', { cx: x, cy: y, r: 18, fill: 'none', stroke: BK.ramp(6).c, 'stroke-width': 2.4, 'stroke-dasharray': '4 3' }, g);
    T(g, 26, 232, `স্থান: ${RS[k][1]}`, { fs: 10.5, w: 600, c: C.fg });
  },
  anim(g, C, ty, t) {
    if (!t) return; const k = +ty;
    if (k === 0) for (let i = 0; i < 3; i++) { const u = (t * .3 + i / 3) % 1; B9.dot(g, 30 + u * 80, 186 + Math.sin(u * 6) * 6, 3.4, BK.ramp(7).dk); }
    if (k === 1) { const u = (t * .3) % 1; B9.dot(g, 120 + 30 * u, 140 - 30 * u, 3.6, BK.ramp(7).dk); B9.ion(g, 190 + 10 * u, 80 - 40 * u, 'CO_2', BK.ramp(9), 9, { fs: 7, op: 1 - u }); }
    if (k === 2) for (let i = 0; i < 3; i++) { const a = t * 1.4 + i * 2.1; B9.dot(g, 262 + 24 * Math.cos(a), 140 + 24 * Math.sin(a), 3.4, BK.ramp(0).dk); }
    if (k === 3) for (let i = 0; i < 4; i++) { const u = (t * .25 + i / 4) % 1, a = PI * .2 + u * PI * .6; B9.dot(g, 256 + 82 * Math.cos(a), 148 + 62 * Math.sin(a), 3, BK.ramp(3).dk); }
  }
}));

/* ═════════ ১০. গ্লাইকোলাইসিস ═════════ */
const GLY = [
  ['গ্লুকোজ → গ্লুকোজ-6-ফসফেট', 'হেক্সোকাইনেজ', 'ATP থেকে একটি ফসফেট গ্লুকোজের 6 নম্বর কার্বনে যুক্ত হয় — গ্লুকোজ কোষে আটকে যায়।', -1, 0, 1],
  ['G-6-P → ফ্রুক্টোজ-6-ফসফেট', 'ফসফোগ্লুকোআইসোমারেজ', 'অ্যালডোজ থেকে কিটোজ — সমাণু রূপান্তর।', 0, 0, 1],
  ['F-6-P → ফ্রুক্টোজ-1,6-বিসফসফেট', 'ফসফোফ্রুক্টোকাইনেজ (PFK)', 'দ্বিতীয় ATP খরচ। PFK গ্লাইকোলাইসিসের প্রধান নিয়ন্ত্রক এনজাইম (বেশি ATP তে বাধা পায়)।', -1, 0, 1],
  ['F-1,6-BP → DHAP + G3P', 'অ্যালডোলেজ', '6C যৌগ ভেঙে দুটি 3C ট্রায়োজ ফসফেট — ডাইহাইড্রক্সি-অ্যাসিটোন ফসফেট ও গ্লিসারালডিহাইড-3-ফসফেট।', 0, 0, 1],
  ['DHAP → G3P', 'ট্রায়োজ ফসফেট আইসোমারেজ', 'DHAP ও G3P সমাণু — DHAP G3P হয়ে যায়, তাই পরের সব ধাপ দুবার (×2) ঘটে।', 0, 0, 2],
  ['2 G3P → 2 (1,3-বিসফসফোগ্লিসারিক অ্যাসিড)', 'G3P ডিহাইড্রোজিনেজ', 'জারণ: 2 NAD<sup>+</sup> → 2 NADH; অজৈব ফসফেট (Pi) যুক্ত হয়।', 0, 2, 2],
  ['2 (1,3-BPG) → 2 (3-ফসফোগ্লিসারিক অ্যাসিড)', 'ফসফোগ্লিসারেট কাইনেজ', 'সাবস্ট্রেট-স্তরের ফসফোরাইলেশন: 2 ATP তৈরি।', 2, 0, 2],
  ['2 (3-PGA) → 2 (2-PGA)', 'ফসফোগ্লিসারেট মিউটেজ', 'ফসফেট 3 নম্বর থেকে 2 নম্বর কার্বনে সরে।', 0, 0, 2],
  ['2 (2-PGA) → 2 PEP', 'ইনোলেজ', 'দুই অণু পানি বের হয় — উচ্চ শক্তির ফসফোইনলপাইরুভিক অ্যাসিড। (ফ্লোরাইড এ এনজাইমে বাধা দেয়।)', 0, 0, 2],
  ['2 PEP → 2 পাইরুভিক অ্যাসিড', 'পাইরুভেট কাইনেজ', 'সাবস্ট্রেট-স্তরের ফসফোরাইলেশন: আরও 2 ATP। মোট তৈরি 4 ATP − খরচ 2 = নিট 2 ATP।', 2, 0, 2]
];
const GLYn = ['গ্লুকোজ', 'G-6-P', 'F-6-P', 'F-1,6-BP', 'DHAP + G3P', '2 G3P', '2 (1,3-BPG)', '2 (3-PGA)', '2 (2-PGA)', '2 PEP', '2 পাইরুভেট'];
V.glycolysis = Object.assign({ t: 'গ্লাইকোলাইসিস — ধাপে ধাপে ATP ও NADH এর হিসাব', k: ['anim', 'steps'], cap: 'এমডেন-মেয়ারহফ-পারনাস (EMP) পথ: সাইটোপ্লাজমে দশটি এনজাইম-নিয়ন্ত্রিত ধাপে এক অণু গ্লুকোজ দুই অণু পাইরুভিক অ্যাসিডে ভাঙে। প্রথম পাঁচ ধাপে শক্তি বিনিয়োগ (2 ATP খরচ), পরের পাঁচ ধাপে শক্তি আহরণ (4 ATP ও 2 NADH)।' }, BK.steps({
  W: 360, H: 300, label: 'গ্লাইকোলাইসিস', dur: 2.4,
  stages: GLY.map(([t, en, d]) => ({ t: t.split(' → ')[1] || t, en, d: `<b>${t}</b> — এনজাইম: ${en}। ${d}` })),
  draw(g, C, s, u) {
    const used = GLY.slice(0, s + 1).reduce((a, x) => a + (x[3] < 0 ? -x[3] : 0), 0), made = GLY.slice(0, s + 1).reduce((a, x) => a + (x[3] > 0 ? x[3] : 0), 0), nadh = GLY.slice(0, s + 1).reduce((a, x) => a + x[4], 0);
    for (let i = 0; i <= 10; i++) {
      const y = 18 + i * 25.5, on = i === s + 1, done = i <= s + 1, R = i <= 5 ? BK.ramp(7) : BK.ramp(2);
      E('rect', { x: 14, y: y - 10, width: 104, height: 20, rx: 10, fill: on ? R.c : FK.alpha(R.c, done ? .25 : .08), stroke: on ? R.dk : FK.alpha(R.dk, done ? .7 : .3) }, g);
      T(g, 66, y + 4, GLYn[i], { fs: 9.5, a: 'middle', w: 600, c: on ? '#fff' : done ? R.ink : C.mu, st: on ? 'stroke:none' : '' });
      if (i < 10) { const st = GLY[i]; E('path', { d: `M66 ${y + 10}v5.5`, stroke: done && i <= s ? C.fg : C.mu, 'stroke-width': 1.2 }, g); if (st[3] || st[4]) T(g, 122, y + 18, st[3] < 0 ? '− ATP' : st[3] > 0 ? '+ 2 ATP' : '+ 2 NADH', { fs: 9, w: 600, c: st[3] < 0 ? BK.ramp(4).ink : st[3] > 0 ? BK.ramp(6).ink : BK.ramp(3).ink }); }
    }
    E('path', { d: 'M8 136H170', stroke: C.mu, 'stroke-dasharray': '3 3' }, g); T(g, 172, 132, '↑ বিনিয়োগ পর্ব', { fs: 9, c: C.mu }); T(g, 172, 146, '↓ আহরণ পর্ব (×2)', { fs: 9, c: C.mu });
    const R6 = BK.ramp(6), R4 = BK.ramp(4), R3 = BK.ramp(3), bx = 236;
    [['ATP খরচ', used, R4, 2], ['ATP তৈরি', made, R6, 4], ['NADH তৈরি', nadh, R3, 2]].forEach(([n, v, R, mx], i) => { const y = 170 + i * 30; T(g, bx, y, n, { fs: 10, w: 600, c: R.ink }); for (let k = 0; k < mx; k++) E('circle', { cx: bx + 8 + k * 18, cy: y + 12, r: 7, fill: k < v ? R.c : 'none', stroke: R.dk }, g); });
    T(g, bx, 268, `নিট ATP = ${made} − ${used} = ${made - used}`, { fs: 11, w: 650, c: C.fg });
    const st = GLY[s]; T(g, bx, 30, st[1], { fs: 9.5, w: 600, c: BK.ramp(0).ink }); T(g, bx, 46, 'এনজাইম', { fs: 9, c: C.mu });
    const y0 = 18 + s * 25.5, y1 = y0 + 25.5, py = y0 + (y1 - y0) * u; E('circle', { cx: 66, cy: py, r: 4.5, fill: BK.ramp(0).dk }, g);
  }
}));

/* ═════════ ১১. পাইরুভিক অ্যাসিডের জারণ ═════════ */
V.linkReaction = Object.assign({}, B9.seg({
  id: 'lnk', t: 'পাইরুভিক অ্যাসিডের জারণ (সংযোগ বিক্রিয়া)', H: 236, def: 'a',
  cap: 'সাইটোপ্লাজমে তৈরি পাইরুভিক অ্যাসিড মাইটোকন্ড্রিয়ার ম্যাট্রিক্সে ঢোকে। পাইরুভেট ডিহাইড্রোজিনেজ জটিল (তিন এনজাইম ও পাঁচ কো-ফ্যাক্টর: TPP, লাইপোইক অ্যাসিড, CoA, FAD, NAD+) এটিকে একসাথে ডিকার্বক্সিলেট ও জারিত করে অ্যাসিটাইল CoA বানায়। এটি গ্লাইকোলাইসিস ও ক্রেবস চক্রের সংযোগ।',
  types: { a: ['সংযোগ', 'অক্সিডেটিভ ডিকার্বক্সিলেশন', 'পাইরুভিক অ্যাসিড (3C) + CoA + NAD<sup>+</sup> → অ্যাসিটাইল CoA (2C) + CO<sub>2</sub> + NADH + H<sup>+</sup>। গ্লুকোজপ্রতি দুবার: 2 CO<sub>2</sub>, 2 NADH (পাঠ্যবইয়ের হিসাবে 6 ATP)। এ ধাপে সরাসরি ATP তৈরি হয় না।'] },
  art(g, C) {
    const Rm = BK.ramp(2);
    E('rect', { x: 150, y: 20, width: 204, height: 200, rx: 30, fill: FK.alpha(Rm.c, .12), stroke: Rm.dk, 'stroke-width': 2.2 }, g); E('rect', { x: 158, y: 28, width: 188, height: 184, rx: 26, fill: 'none', stroke: Rm.dk, 'stroke-width': 1.2 }, g);
    T(g, 252, 46, 'ম্যাট্রিক্স', { fs: 10, a: 'middle', w: 600, c: Rm.ink }); T(g, 70, 46, 'সাইটোপ্লাজম', { fs: 10, a: 'middle', w: 600, c: C.mu });
    node(g, 70, 120, 'পাইরুভিক অ্যাসিড', BK.ramp(7), 110, 26, { fs: 10 }); T(g, 70, 146, '(3C)', { fs: 9.5, a: 'middle', c: C.mu });
    E('rect', { x: 210, y: 96, width: 64, height: 48, rx: 12, fill: FK.alpha(BK.ramp(0).c, .35), stroke: BK.ramp(0).dk }, g); T(g, 242, 116, 'PDH', { fs: 11, a: 'middle', w: 650, c: BK.ramp(0).ink }); T(g, 242, 132, 'জটিল', { fs: 9.5, a: 'middle', c: BK.ramp(0).ink });
    node(g, 300, 190, 'অ্যাসিটাইল CoA (2C)', BK.ramp(9), 104, 24, { fs: 9.5 }); T(g, 300, 214, '→ ক্রেবস চক্রে', { fs: 9, a: 'middle', c: C.mu });
    BK.arrow(g, 126, 120, 206, 120, C.mu, 1.4); BK.arrow(g, 260, 146, 290, 176, C.mu, 1.4);
    node(g, 196, 70, ch('CoA + NAD^+'), BK.ramp(3), 74, 20, { fs: 9 });
  },
  anim(g, C, ty, t) {
    if (!t) return; const u = (t * .3) % 1, a = FK.ease(cl(u / .4)), b = FK.ease(cl((u - .4) / .5));
    if (u < .4) B9.ion(g, 126 + 84 * a, 120, '3C', BK.ramp(7), 11, { fs: 8 });
    else { B9.ion(g, 260 + 34 * b, 146 + 36 * b, '2C', BK.ramp(9), 11, { fs: 8 }); B9.ion(g, 270 + 50 * b, 96 - 60 * b, 'CO_2', BK.ramp(9), 11, { fs: 7.5, op: 1 - b * .5 }); B9.chip(g, 320, 120 + 10 * b, 'NADH', BK.ramp(3), { w: 44, h: 16, fs: 9 }); }
  }
}));

/* ═════════ ১২. ইলেকট্রন পরিবহন শৃঙ্খল ═════════ */
const EY = 124;
const ETCp = { nadh: [[46, 214], [46, 132], [98, 128], [150, 124], [190, 164], [234, 128], [240, 190]], fadh: [[98, 196], [98, 128], [150, 124], [190, 164], [234, 128], [240, 190]], aox: [[46, 214], [46, 132], [98, 128], [112, 166], [118, 200]], noo2: [[46, 214], [46, 132], [98, 128], [150, 124], [190, 164], [234, 128]] };
V.etc = Object.assign({}, B9.seg({
  id: 'etc', t: 'ইলেকট্রন পরিবহন শৃঙ্খল ও অক্সিডেটিভ ফসফোরাইলেশন', H: 270, def: 'nadh',
  cap: 'মাইটোকন্ড্রিয়ার অন্তঃপর্দায় চারটি জটিল (I–IV), ইউবিকুইনোন ও সাইটোক্রোম c। NADH ও FADH2 এর ইলেকট্রন ধাপে ধাপে কম শক্তিস্তরে নেমে শেষে O2 কে বিজারিত করে পানি তৈরি করে। মুক্ত শক্তিতে জটিল I, III ও IV H+ কে আন্তঃপর্দা স্থানে পাম্প করে; সেই H+ ATP সিনথেজ দিয়ে ফেরার সময় ATP তৈরি হয় (কেমিঅসমোসিস)।',
  types: {
    nadh: ['NADH', 'NADH থেকে', 'NADH → জটিল I (4 H<sup>+</sup>) → UQ → জটিল III (4 H<sup>+</sup>) → সাইটোক্রোম c → জটিল IV (2 H<sup>+</sup>) → ½O<sub>2</sub> + 2H<sup>+</sup> → H<sub>2</sub>O। মোট 10 H<sup>+</sup> — আধুনিক হিসাবে প্রায় 2.5 ATP (পাঠ্যবইয়ে 3 ATP)।'],
    fadh: ['FADH<sub>2</sub>', 'FADH2 থেকে', 'FADH<sub>2</sub> (সাক্সিনেট ডিহাইড্রোজিনেজ = জটিল II) ইলেকট্রন সরাসরি UQ তে দেয় — জটিল I বাদ পড়ে, জটিল II H<sup>+</sup> পাম্প করে না। মোট 6 H<sup>+</sup> — প্রায় 1.5 ATP (পাঠ্যবইয়ে 2 ATP)।'],
    aox: ['বিকল্প অক্সিডেজ', 'উদ্ভিদের বিকল্প অক্সিডেজ (সায়ানাইড-সহিষ্ণু শ্বসন)', 'উদ্ভিদ মাইটোকন্ড্রিয়ায় UQ থেকে ইলেকট্রন সরাসরি বিকল্প অক্সিডেজ (AOX) হয়ে O<sub>2</sub> তে যেতে পারে — জটিল III ও IV বাদ পড়ে, তাই ATP কম হয়, শক্তি তাপ হিসেবে বের হয়। সায়ানাইড জটিল IV বন্ধ করলেও এ পথ চলে। কচু-জাতীয় (Arum) ফুলের মঞ্জরিদণ্ড এভাবে গরম হয়ে গন্ধ ছড়িয়ে পতঙ্গ আকর্ষণ করে।'],
    noo2: ['O<sub>2</sub> না থাকলে', 'অক্সিজেনের প্রয়োজনীয়তা', 'O<sub>2</sub> হলো শেষ ইলেকট্রন গ্রাহক। O<sub>2</sub> না থাকলে জটিল IV ইলেকট্রন ছাড়তে পারে না — পুরো শৃঙ্খল বিজারিত অবস্থায় আটকে যায় ("যানজট"), NADH জমে NAD<sup>+</sup> ফুরায়, ক্রেবস চক্র ও সংযোগ বিক্রিয়া থেমে যায়। তখন কোষ শুধু গ্লাইকোলাইসিস ও গাঁজনের ওপর নির্ভর করে — ATP অনেক কম।']
  },
  art(g, C, ty) {
    const Rm = BK.ramp(2), Rb = BK.ramp(4), Ra = BK.ramp(6), R3 = BK.ramp(3);
    E('rect', { x: 0, y: 0, width: 360, height: EY - 24, fill: FK.alpha(Rb.c, .07) }, g); T(g, 8, 16, ch('আন্তঃপর্দা স্থান — বেশি H^+'), { fs: 10, w: 560, c: Rb.ink });
    E('rect', { x: 0, y: EY + 24, width: 360, height: 122, fill: FK.alpha(Rm.c, .06) }, g); T(g, 8, 262, ch('ম্যাট্রিক্স — কম H^+'), { fs: 10, w: 560, c: C.mu });
    E('rect', { x: 0, y: EY - 24, width: 360, height: 48, fill: FK.alpha(Rm.c, .22) }, g); T(g, 354, EY - 28, 'অন্তঃপর্দা', { fs: 9, a: 'end', c: C.mu });
    const box = (x, w, h, s, R, dim) => { E('rect', { x: x - w / 2, y: EY - h / 2, width: w, height: h, rx: 10, fill: FK.alpha(R.c, dim ? .15 : .45), stroke: R.dk, 'stroke-width': 1.3, opacity: dim ? .5 : 1 }, g); T(g, x, EY + 4, s, { fs: 10, a: 'middle', w: 650, c: R.ink }); };
    box(46, 40, 66, 'I', R3, ty === 'fadh'); box(98, 34, 44, 'II', BK.ramp(11), ty !== 'fadh'); box(150, 40, 60, 'III', R3, ty === 'aox'); box(234, 40, 64, 'IV', R3, ty === 'aox');
    E('ellipse', { cx: 124, cy: EY + 4, rx: 10, ry: 7, fill: Ra.lt, stroke: Ra.dk }, g); T(g, 124, EY + 7, 'UQ', { fs: 7.5, a: 'middle', w: 650, c: Ra.ink });
    E('circle', { cx: 190, cy: EY + 40, r: 9, fill: BK.ramp(4).lt, stroke: BK.ramp(4).dk, opacity: ty === 'aox' ? .4 : 1 }, g); T(g, 190, EY + 43, 'c', { fs: 9, a: 'middle', w: 650, c: BK.ramp(4).ink });
    if (ty === 'aox') { E('rect', { x: 104, y: EY + 20, width: 28, height: 20, rx: 6, fill: FK.alpha(BK.ramp(10).c, .5), stroke: BK.ramp(10).dk }, g); T(g, 118, EY + 34, 'AOX', { fs: 8, a: 'middle', w: 650, c: BK.ramp(10).ink }); B9.chip(g, 118, 214, ch('O_2 → H_2O + তাপ'), BK.ramp(4), { w: 100, fs: 9 }); }
    if (ty !== 'fadh') node(g, 46, 222, ch('NADH → NAD^+'), R3, 84, 20, { fs: 9 }); else node(g, 98, 214, ch('FADH_2 → FAD'), BK.ramp(11), 84, 20, { fs: 9 });
    if (ty !== 'aox') node(g, 246, 206, ty === 'noo2' ? ch('O_2 নেই!') : ch('½O_2 + 2H^+ → H_2O'), ty === 'noo2' ? BK.ramp(4) : BK.ramp(0), ty === 'noo2' ? 64 : 104, 20, { fs: 9 });
    E('rect', { x: 306, y: EY - 22, width: 22, height: 44, rx: 4, fill: FK.alpha(Ra.c, .5), stroke: Ra.dk, opacity: ty === 'noo2' ? .4 : 1 }, g); E('path', { d: `M317 ${EY + 22}V${EY + 46}`, stroke: Ra.dk, 'stroke-width': 4 }, g);
    T(g, 317, EY - 30, 'ATP সিনথেজ', { fs: 9, a: 'middle', w: 600, c: Ra.ink }); T(g, 317, EY + 92, 'ADP+Pi → ATP', { fs: 9, a: 'middle', w: 600, c: Ra.ink });
    const pumps = ty === 'fadh' ? [[150, 4], [234, 2]] : ty === 'aox' ? [[46, 4]] : ty === 'noo2' ? [] : [[46, 4], [150, 4], [234, 2]];
    pumps.forEach(([x, n]) => T(g, x, 40, ch(`${n} H^+`), { fs: 10, a: 'middle', w: 650, c: Rb.ink }));
    B9.poly(g, ETCp[ty], { stroke: R3.c, 'stroke-width': 1.2, 'stroke-dasharray': '3 3', opacity: .7 });
  },
  anim(g, C, ty, t) {
    if (!t) return; const Rb = BK.ramp(4), Ra = BK.ramp(6);
    if (ty === 'noo2') { for (let i = 0; i < 6; i++) { const [x, y] = B9.along(ETCp.noo2, Math.min(.98, .55 + i * .08) + Math.sin(t * 6 + i) * .004); B9.dot(g, x, y, 3.6, BK.ramp(3).dk); } return; }
    for (let i = 0; i < 4; i++) { const [x, y] = B9.along(ETCp[ty], (t * .15 + i / 4) % 1); B9.dot(g, x, y, 3.6, BK.ramp(3).dk); }
    const pumps = ty === 'fadh' ? [150, 234] : ty === 'aox' ? [46] : [46, 150, 234];
    pumps.forEach((x, k) => { const u = (t * .4 + k * .3) % 1; B9.ion(g, x + 10, 190 - u * 150, 'H^+', Rb, 6.5, { fs: 6.5, op: u > .85 ? (1 - u) * 6 : 1 }); });
    for (let i = 0; i < 2; i++) { const u = (t * .35 + i / 2) % 1; B9.ion(g, 317, 50 + u * 160, 'H^+', Rb, 6.5, { fs: 6.5 }); }
    for (let k = 0; k < 3; k++) { const a = t * 3 + k * 2.09; E('ellipse', { cx: (317 + 12 * Math.cos(a)).toFixed(1), cy: (EY + 56 + 4 * Math.sin(a)).toFixed(1), rx: 7, ry: 6, fill: FK.alpha(Ra.c, .8), stroke: Ra.dk }, g); }
    if (ty === 'aox') for (let i = 0; i < 3; i++) { const u = (t * .5 + i / 3) % 1; E('path', { d: `M${150 + i * 8} ${206 - u * 30}q4 -6 0 -12`, stroke: BK.ramp(4).c, 'stroke-width': 1.6, fill: 'none', opacity: 1 - u }, g); }
  }
}));

/* ═════════ ১৩. ATP এর হিসাব ═════════ */
const AC = { b38: [3, 2, 3], b36: [3, 2, 2], m32: [2.5, 1.5, 2.5], m30: [2.5, 1.5, 1.5] };
V.atpCalc = Object.assign({}, B9.seg({
  id: 'atc', t: 'এক অণু গ্লুকোজে মোট ATP — পাঠ্যবই বনাম আধুনিক হিসাব', H: 270, def: 'b38',
  cap: 'পুরোনো হিসাবে 1 NADH = 3 ATP, 1 FADH2 = 2 ATP ধরে মোট 38 ATP। আধুনিক পরিমাপে (H+ পাম্প ও ATP সিনথেজের হিসাব) 1 NADH ≈ 2.5, 1 FADH2 ≈ 1.5 ATP — মোট প্রায় 30–32। গ্লাইকোলাইসিসের NADH সাইটোপ্লাজমে তৈরি; সেটি কোন শাটলে মাইটোকন্ড্রিয়ায় ঢোকে তার ওপরও হিসাব বদলায়। পরীক্ষায় পাঠ্যবইয়ের 38 লিখবে।',
  types: {
    b38: ['38 (বই)', 'পাঠ্যবইয়ের হিসাব — 38 ATP', 'NADH = 3, FADH<sub>2</sub> = 2; সাইটোপ্লাজমের NADH ম্যালেট-অ্যাসপারটেট শাটলে ঢোকে (3 ATP করে) — উদ্ভিদ, যকৃৎ, হৃৎপিণ্ড। প্রোক্যারিওটে মাইটোকন্ড্রিয়া নেই বলে শাটলের খরচও নেই — তাই 38 ATP সাধারণত প্রোক্যারিওটের সর্বোচ্চ হিসাব হিসেবেও বলা হয়।'],
    b36: ['36 (বই)', 'গ্লিসারল-ফসফেট শাটলে — 36 ATP', 'কঙ্কাল পেশি ও মস্তিষ্কে সাইটোপ্লাজমের NADH এর ইলেকট্রন FAD এর মাধ্যমে ঢোকে — তাই প্রতি NADH এ 2 ATP; মোট 2 কম = 36।'],
    m32: ['32 (আধুনিক)', 'আধুনিক হিসাব — প্রায় 32 ATP', 'NADH ≈ 2.5, FADH<sub>2</sub> ≈ 1.5 ATP (10 H<sup>+</sup> ও 6 H<sup>+</sup>; প্রতি ATP তে প্রায় 4 H<sup>+</sup> লাগে, ATP বাইরে পাঠানোর খরচসহ)। ম্যালেট-অ্যাসপারটেট শাটলে।'],
    m30: ['30 (আধুনিক)', 'আধুনিক হিসাব, গ্লিসারল-ফসফেট শাটলে — প্রায় 30 ATP', 'সাইটোপ্লাজমের NADH ≈ 1.5 ATP করে — মোট প্রায় 30।']
  },
  art(g, C, ty) {
    const [nd, fd, sh] = AC[ty], rows = [['গ্লাইকোলাইসিস', [['ATP (সরাসরি)', 2, 1], ['2 NADH', 2, sh]]], ['পাইরুভেটের জারণ', [['2 NADH', 2, nd]]], ['ক্রেবস চক্র (×2)', [['ATP/GTP', 2, 1], ['6 NADH', 6, nd], ['2 FADH2', 2, fd]]]];
    let y = 24, tot = 0; const mx = 40, X0 = 150, Wd = 200;
    rows.forEach(([n, it], i) => {
      const R = BK.ramp([7, 9, 0][i]); let sub = 0;
      T(g, 10, y + 4, n, { fs: 10.5, w: 650, c: R.ink }); y += 14;
      it.forEach(([s, a, f]) => { const v = a * f; sub += v; T(g, 22, y + 9, s.replace('FADH2', 'FADH<tspan dy="3" font-size="72%">2</tspan><tspan dy="-3"></tspan>') + (f !== 1 ? ` × ${FK.n(f, 1)}` : ''), { fs: 9.5, c: C.fg }); E('rect', { x: X0, y, width: Wd * v / mx, height: 12, rx: 6, fill: R.c, 'data-w': Wd * v / mx }, g); T(g, X0 + Wd * v / mx + 6, y + 10, FK.n(v, 1), { fs: 9.5, w: 600, c: R.ink }); y += 17; });
      T(g, 352, y - 2, `= ${FK.n(sub, 1)}`, { fs: 10, a: 'end', w: 650, c: R.ink }); tot += sub; y += 10;
    });
    E('path', { d: `M10 ${y}H350`, stroke: C.mu }, g);
    T(g, 10, y + 22, 'মোট ATP', { fs: 12, w: 650, c: C.fg }); T(g, 352, y + 22, FK.n(tot, 1), { fs: 18, a: 'end', w: 650, c: BK.ramp(6).ink });
  },
  anim(g, C, ty, t) { if (!t) return; const u = (t * .4) % 1; E('rect', { x: 150, y: 20, width: 200 * u, height: 216, fill: FK.alpha(BK.ramp(6).c, .06) }, g); }
}));

/* ═════════ ১৪. উদ্ভিদ মাইটোকন্ড্রিয়ার স্বকীয়তা ═════════ */
V.plantMito = Object.assign({ t: 'উদ্ভিদ মাইটোকন্ড্রিয়ার স্বকীয়তা', k: ['tree', 'int'], cap: 'প্রাণীর মাইটোকন্ড্রিয়ার মতো হলেও উদ্ভিদের মাইটোকন্ড্রিয়ায় কয়েকটি বাড়তি ব্যবস্থা আছে। শাখায় চাপ দাও।' }, BK.tree({
  t: 'উদ্ভিদ মাইটোকন্ড্রিয়া', d: 'উদ্ভিদকোষের শ্বসনিক অঙ্গাণু — আলোকশ্বসন ও সালোকসংশ্লেষণের সাথে বিপাকীয়ভাবে যুক্ত।',
  c: [
    { t: 'বিকল্প অক্সিডেজ', d: 'UQ থেকে সরাসরি O<sub>2</sub> তে ইলেকট্রন — সায়ানাইড-সহিষ্ণু শ্বসন; কম ATP, বেশি তাপ (তাপ উৎপাদনকারী ফুল)।' },
    { t: 'রোটেনোন-অসংবেদী ডিহাইড্রোজিনেজ', d: 'জটিল I ছাড়াও বাড়তি NAD(P)H ডিহাইড্রোজিনেজ — ভেতরের ও বাইরের দিকে; সাইটোপ্লাজমের NADH সরাসরি জারিত করতে পারে।' },
    { t: 'আলোকশ্বসনে অংশগ্রহণ', d: 'গ্লাইসিন ডিকার্বক্সিলেজ জটিল: 2 গ্লাইসিন → সেরিন + CO<sub>2</sub> + NH<sub>3</sub> — পাতার মাইটোকন্ড্রিয়ায় খুব বেশি পরিমাণে থাকে।' },
    { t: 'ম্যালিক এনজাইম', d: 'NAD-ম্যালিক এনজাইম ম্যালেট থেকে সরাসরি পাইরুভেট বানায় — গ্লাইকোলাইসিস ছাড়াই ক্রেবস চক্র চালাতে পারে।' },
    { t: 'ক্রেবস চক্রে ATP', d: 'সাক্সিনাইল CoA সিনথেটেজ উদ্ভিদে সরাসরি ATP দেয় (প্রাণীতে প্রধানত GTP)।' },
    { t: 'বড় জিনোম', d: 'উদ্ভিদ মাইটোকন্ড্রিয়ার DNA প্রাণীর (প্রায় 16.5 kb) চেয়ে বহুগুণ বড় — প্রায় 200 থেকে 2000+ kb; RNA সম্পাদনা (এডিটিং) ঘটে।' }
  ]
}, { colW: 116 }));

/* ═════════ তুলনা (৯.৬) ═════════ */
V.cmpGlyPhotolysis = cmp('গ্লাইকোলাইসিস বনাম ফটোলাইসিস', 'নামে দুটিই "লাইসিস" (ভাঙন) — কিন্তু ভাঙে একেবারে ভিন্ন জিনিস, ভিন্ন জায়গায়।', 'গ্লাইকোলাইসিস', 'ফটোলাইসিস (পানির সালোকবিভাজন)', [
  ['প্রক্রিয়া', 'শ্বসনের প্রথম ধাপ', 'সালোকসংশ্লেষণের আলোকনির্ভর পর্যায়ের অংশ'],
  ['কী ভাঙে', 'গ্লুকোজ → 2 পাইরুভিক অ্যাসিড', 'পানি → O<sub>2</sub> + H<sup>+</sup> + e<sup>−</sup>'],
  ['স্থান', 'সাইটোপ্লাজম', 'ক্লোরোপ্লাস্টের থাইলাকয়েড (PS-II এর লুমেন দিক)'],
  ['আলো', 'লাগে না', 'লাগে'],
  ['এনজাইম/উপাদান', '10টি এনজাইম', 'Mn<sub>4</sub>CaO<sub>5</sub> গুচ্ছ, Cl<sup>−</sup>'],
  ['উৎপাদ', 'নিট 2 ATP, 2 NADH, 2 পাইরুভেট', 'O<sub>2</sub>, H<sup>+</sup>, ইলেকট্রন (ATP সরাসরি নয়)'],
  ['কোন জীবে', 'সব জীবে', 'সবুজ উদ্ভিদ, শৈবাল, সায়ানোব্যাকটেরিয়া']
]);
V.cmpGlyKrebs = cmp('গ্লাইকোলাইসিস বনাম ক্রেবস চক্র', 'সারিতে চাপ দিলে চিহ্নিত হয়; যাচাই খেলায় নিজেকে পরীক্ষা করো।', 'গ্লাইকোলাইসিস', 'ক্রেবস চক্র', [
  ['স্থান', 'সাইটোপ্লাজম', 'মাইটোকন্ড্রিয়ার ম্যাট্রিক্স (প্রোক্যারিওটে সাইটোপ্লাজম)'],
  ['O<sub>2</sub>', 'লাগে না (সবাত-অবাত দুটিতেই)', 'পরোক্ষভাবে লাগে (শুধু সবাত শ্বসনে)'],
  ['ধরন', 'রৈখিক পথ, 10 ধাপ', 'চক্রাকার পথ, 8 ধাপ'],
  ['শুরুর যৌগ', 'গ্লুকোজ (6C)', 'অ্যাসিটাইল CoA (2C) + OAA (4C)'],
  ['শেষ উৎপাদ', '2 পাইরুভিক অ্যাসিড', 'CO<sub>2</sub>; OAA পুনরুৎপন্ন'],
  ['CO<sub>2</sub>', 'নির্গত হয় না', 'গ্লুকোজপ্রতি 4 CO<sub>2</sub>'],
  ['ATP', 'নিট 2 ATP', '2 ATP (GTP)'],
  ['বিজারিত কো-এনজাইম', '2 NADH', '6 NADH + 2 FADH<sub>2</sub>'],
  ['আবিষ্কারক', 'এমডেন, মেয়ারহফ ও পারনাস', 'হ্যান্স ক্রেবস (1937; নোবেল 1953)']
]);
V.cmpKrebsPA = cmp('উদ্ভিদ ও প্রাণীর ক্রেবস চক্রের পার্থক্য', 'মূল পথ একই; পার্থক্য কয়েকটি এনজাইম ও সংযোগে।', 'উদ্ভিদ', 'প্রাণী', [
  ['সাক্সিনাইল CoA → সাক্সিনেট', 'সরাসরি ATP তৈরি হয়', 'প্রধানত GTP তৈরি হয় (পরে ATP তে রূপান্তর)'],
  ['গ্লাইঅক্সিলেট চক্র', 'অঙ্কুরিত তেলবীজে (গ্লাইঅক্সিজোমে) থাকে — চর্বি থেকে শর্করা', 'থাকে না'],
  ['ম্যালিক এনজাইম', 'NAD-ম্যালিক এনজাইম সক্রিয় — ম্যালেট থেকে পাইরুভেট', 'তুলনামূলক কম গুরুত্বপূর্ণ'],
  ['বিকল্প অক্সিডেজ সংযোগ', 'আছে — শৃঙ্খল আংশিক বাদ দিতে পারে', 'নেই'],
  ['আলোকশ্বসনের সংযোগ', 'গ্লাইসিন জারণ মাইটোকন্ড্রিয়ায় NADH যোগায়', 'নেই']
]);
V.cmpPhotoOx = cmp('ফটোফসফোরাইলেশন বনাম অক্সিডেটিভ ফসফোরাইলেশন', 'দুটিতেই কেমিঅসমোসিসে ATP সিনথেজ ATP বানায় — শক্তির উৎস ও স্থান আলাদা।', 'ফটোফসফোরাইলেশন', 'অক্সিডেটিভ ফসফোরাইলেশন', [
  ['শক্তির উৎস', 'আলোক শক্তি', 'খাদ্যের জারণ (NADH, FADH<sub>2</sub>)'],
  ['স্থান', 'ক্লোরোপ্লাস্টের থাইলাকয়েড ঝিল্লি', 'মাইটোকন্ড্রিয়ার অন্তঃপর্দা'],
  ['প্রক্রিয়া', 'সালোকসংশ্লেষণ', 'সবাত শ্বসন'],
  ['ইলেকট্রনের উৎস', 'পানি (অচক্রীয়) বা P700 (চক্রীয়)', 'NADH ও FADH<sub>2</sub>'],
  ['শেষ ইলেকট্রন গ্রাহক', 'NADP<sup>+</sup> (অচক্রীয়)', 'O<sub>2</sub>'],
  ['H<sup>+</sup> জমে', 'থাইলাকয়েড লুমেনে', 'আন্তঃপর্দা স্থানে'],
  ['ATP যায়', 'স্ট্রোমায় — ক্যালভিন চক্রে', 'সাইটোপ্লাজমে — কোষের সব কাজে'],
  ['O<sub>2</sub>', 'নির্গত হয় (অচক্রীয়)', 'খরচ হয়']
]);
})();
