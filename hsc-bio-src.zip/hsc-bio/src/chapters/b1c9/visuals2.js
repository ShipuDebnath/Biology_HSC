/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৯.৩ আলোক পর্যায়, §৯.৪ আলোক নিরপেক্ষ পর্যায়
   spectrum   : আলোর তরঙ্গদৈর্ঘ্য, রং ও ফোটনের শক্তি (E = hc/λ, স্লাইডার)
   absorb     : ক্লোরোফিল a, b ও ক্যারোটিনয়েডের শোষণ বর্ণালি; ক্রিয়া বর্ণালি ও এঙ্গেলম্যানের পরীক্ষা
   photoOverview: সালোকসংশ্লেষণের দুই পর্যায়ের সংযোগ; সমীকরণে O-পরমাণুর উৎস
   antenna    : আলোক সংগ্রাহী অ্যান্টেনা ও বিক্রিয়া কেন্দ্র (P680, P700) — শক্তির অনুনাদ স্থানান্তর
   photolysis : পানির সালোকবিভাজন — ধাপে ধাপে
   zscheme    : Z-স্কিম — অচক্রীয় ও চক্রীয় ইলেকট্রন প্রবাহ (রেডক্স বিভব অনুযায়ী)
   thylakoid  : থাইলাকয়েড ঝিল্লিতে ইলেকট্রন ও H+ প্রবাহ, ATP সিনথেজ (কেমিঅসমোসিস)
   calvinCount: ক্যালভিন চক্রের হিসাব — n টি CO2 এ কত ATP, NADPH, G3P (স্লাইডার)
   starchSucrose: দিনে-রাতে স্টার্চ ও সুক্রোজ তৈরি       photoresp : আলোকশ্বসন (C2 চক্র), তাপমাত্রা স্লাইডার
   hatchSlack : হ্যাচ-স্ল্যাক (C4) চক্র                  kranz     : C3 ও C4 পাতার প্রস্থচ্ছেদ (ক্র্যাঞ্জ অঙ্গসংস্থান)
   cmpPS, cmpCycNon, cmpLightDark, cmpPRResp, cmpC3C4, cmpCalvinHS : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B9 = window.B9;
const PI = Math.PI, ch = B9.ch, cl = B9.cl, rnd = B9.rnd;
let uid = 0;
/* তরঙ্গদৈর্ঘ্য → রং */
const wl = l => {
  let r = 0, g = 0, b = 0;
  if (l < 380) return 'rgb(120,90,160)'; if (l > 750) return 'rgb(110,40,40)';
  if (l < 440) { r = (440 - l) / 60; b = 1; } else if (l < 490) { g = (l - 440) / 50; b = 1; } else if (l < 510) { g = 1; b = (510 - l) / 20; } else if (l < 580) { r = (l - 510) / 70; g = 1; } else if (l < 645) { r = 1; g = (645 - l) / 65; } else r = 1;
  const f = l < 420 ? .35 + .65 * (l - 380) / 40 : l > 700 ? .35 + .65 * (750 - l) / 50 : 1, k = v => Math.round(255 * Math.pow(v * f, .8));
  return `rgb(${k(r)},${k(g)},${k(b)})`;
};
const colName = l => l < 380 ? 'অতিবেগুনি (UV) — অদৃশ্য' : l < 450 ? 'বেগুনি-নীল' : l < 495 ? 'নীল' : l < 570 ? 'সবুজ' : l < 590 ? 'হলুদ' : l < 620 ? 'কমলা' : l <= 750 ? 'লাল' : 'অবলোহিত (IR) — অদৃশ্য';
const specGrad = (g, x0, x1, l0, l1) => { const id = 'spg' + (++uid), lg = E('linearGradient', { id, x1: 0, x2: 1, y1: 0, y2: 0 }, g); for (let k = 0; k <= 12; k++) E('stop', { offset: k / 12, 'stop-color': wl(l0 + (l1 - l0) * k / 12) }, lg); return `url(#${id})`; };
const Gs = (x, m, s) => Math.exp(-.5 * Math.pow((x - m) / s, 2));
const PIG = {
  a: { n: 'ক্লোরোফিল a', c: 10, f: x => .9 * Gs(x, 430, 14) + .16 * Gs(x, 410, 22) + .78 * Gs(x, 662, 10) + .13 * Gs(x, 615, 16) },
  b: { n: 'ক্লোরোফিল b', c: 7, f: x => 1.0 * Gs(x, 453, 13) + .12 * Gs(x, 430, 20) + .46 * Gs(x, 642, 10) + .1 * Gs(x, 595, 16) },
  k: { n: 'ক্যারোটিনয়েড', c: 2, f: x => .42 * Gs(x, 425, 11) + .7 * Gs(x, 450, 13) + .62 * Gs(x, 478, 12) }
};
const ACT = x => Math.min(1, .82 * Gs(x, 440, 32) + .72 * Gs(x, 668, 24) + .2 * Gs(x, 550, 55) + .12 * Gs(x, 490, 20));

/* ═════════ ১. আলোর বর্ণালি ═════════ */
V.spectrum = Object.assign({}, B9.seg({
  id: 'spc', t: 'আলোর তরঙ্গদৈর্ঘ্য, রং ও ফোটনের শক্তি', k: ['2d', 'anim', 'int'], H: 236, def: 'a',
  cap: 'আলো তড়িৎচৌম্বক তরঙ্গ এবং ফোটন নামের শক্তিকণার স্রোত। দৃশ্যমান আলো প্রায় 380–750 nm; সালোকসংশ্লেষণে কাজে লাগে 400–700 nm (PAR)। তরঙ্গদৈর্ঘ্য যত ছোট, ফোটনের শক্তি তত বেশি: E = hc/λ। স্লাইডার টেনে দেখো।',
  types: { a: ['বর্ণালি', 'তড়িৎচৌম্বক বর্ণালি ও দৃশ্যমান আলো', 'সূর্যের আলোর প্রায় অর্ধেক শক্তি দৃশ্যমান অংশে। ক্লোরোফিল প্রধানত নীল-বেগুনি ও লাল আলো শোষণ করে, সবুজ আলো প্রতিফলিত করে — তাই পাতা সবুজ দেখায়।'] },
  sl: [{ k: 'l', l: 'তরঙ্গদৈর্ঘ্য λ (nm)', min: 300, max: 800, step: 5, val: 680 }],
  art(g, C, ty, ctx) {
    const l = ctx.v.l, bands = [['γ', 18], ['X', 26], ['UV', 34], ['দৃশ্য', 44], ['IR', 60], ['মাইক্রো', 82], ['রেডিও', 96]];
    let x = 12; bands.forEach(([s, w], i) => { const R = BK.ramp(i === 3 ? 10 : 9); E('rect', { x, y: 16, width: w - 2, height: 20, rx: 4, fill: i === 3 ? specGrad(g, 0, 1, 400, 700) : FK.alpha(R.c, .25 + i * .05) }, g); T(g, x + (w - 2) / 2, 30, s, { fs: 9, a: 'middle', w: 560, c: i === 3 ? '#fff' : C.fg, st: i === 3 ? 'stroke:none' : '' }); x += w; });
    T(g, 12, 50, 'ছোট λ, বেশি শক্তি', { fs: 9, c: C.mu }); T(g, 348, 50, 'বড় λ, কম শক্তি', { fs: 9, a: 'end', c: C.mu });
    E('path', { d: 'M90 37L30 66M132 37L330 66', stroke: C.mu, 'stroke-width': .8, 'stroke-dasharray': '2 2' }, g);
    const X = v => 30 + (v - 380) / 370 * 300;
    E('rect', { x: 30, y: 66, width: 300, height: 24, rx: 4, fill: specGrad(g, 0, 1, 380, 750) }, g);
    [400, 500, 600, 700].forEach(v => { E('path', { d: `M${X(v)} 90v5`, stroke: C.mu }, g); T(g, X(v), 106, String(v), { fs: 9.5, a: 'middle', c: C.mu }); });
    E('path', { d: `M${X(400)} 112v4H${X(700)}v-4`, stroke: BK.ramp(10).dk, fill: 'none', 'stroke-width': 1.3 }, g); T(g, X(550), 128, 'PAR: 400–700 nm', { fs: 10, a: 'middle', w: 600, c: BK.ramp(10).ink });
    const xm = X(cl(l, 380, 750)); E('path', { d: `M${xm} 60l-6 -8h12Z`, fill: C.fg }, g); E('rect', { x: xm - 2, y: 64, width: 4, height: 28, fill: 'none', stroke: C.fg, 'stroke-width': 1.5 }, g);
    const eV = 1239.84 / l, kJ = 119626 / l;
    T(g, 14, 226, `${FK.n(l, 0)} nm · ${colName(l)}`, { fs: 11, w: 600, c: C.fg });
    T(g, 346, 208, `E = ${FK.n(eV, 2)} eV`, { fs: 11.5, a: 'end', w: 650, c: BK.ramp(6).ink }); T(g, 346, 226, `${FK.n(kJ, 0)} kJ/mol ফোটন`, { fs: 10.5, a: 'end', c: C.mu });
    ctx.l = l;
  },
  anim(g, C, ty, t, ctx) {
    const l = ctx.l || 680, lam = l / 10, col = wl(l); let d = '';
    for (let x = 14; x <= 346; x += 3) { const y = 168 + 16 * Math.sin(2 * PI * (x - 14) / lam - t * 5); d += (x === 14 ? 'M' : 'L') + x + ' ' + y.toFixed(1); }
    E('path', { d, stroke: col, 'stroke-width': 2.6, fill: 'none' }, g);
    const px = 14 + ((t * 70) % 332); E('circle', { cx: px, cy: 168, r: 5, fill: col, stroke: C.fg, 'stroke-width': .8 }, g);
    E('path', { d: `M30 192h${lam}`, stroke: C.mu, 'stroke-width': 1 }, g); E('path', { d: `M30 188v8M${30 + lam} 188v8`, stroke: C.mu }, g); T(g, 34 + lam, 196, 'λ', { fs: 10, c: C.mu, st: 'font-style:italic' });
  },
  more(ty, ctx) { const l = ctx.v.l, ab = Math.max(PIG.a.f(l), PIG.b.f(l)); return `<div class="small">λ = ${FK.n(l, 0)} nm: ফোটনের শক্তি E = hc/λ = (6.626×10<sup>−34</sup> × 3×10<sup>8</sup>) / (${FK.n(l, 0)}×10<sup>−9</sup>) ≈ <b>${FK.n(1239.84 / l, 2)} eV</b> ≈ ${FK.n(119626 / l, 0)} kJ প্রতি মোল ফোটন। ${l < 400 || l > 700 ? 'PAR-এর বাইরে — সালোকসংশ্লেষণে প্রায় কাজে লাগে না।' : ab > .4 ? 'ক্লোরোফিল এ আলো ভালোভাবে শোষণ করে।' : 'ক্লোরোফিল এ আলো কম শোষণ করে (প্রধানত প্রতিফলিত/সঞ্চারিত হয়)।'}</div>`; }
}));

/* ═════════ ২. শোষণ ও ক্রিয়া বর্ণালি ═════════ */
const ABb = [46, 26, 290, 158], ABX = v => ABb[0] + (v - 380) / 340 * ABb[2];
V.absorb = Object.assign({}, B9.seg({
  id: 'abs', t: 'শোষণ বর্ণালি ও ক্রিয়া বর্ণালি', k: ['graph', 'anim', 'int'], H: 262, def: 'abs',
  cap: 'কোন তরঙ্গদৈর্ঘ্যের আলো একটি রঞ্জক কতটা শোষণ করে — তার লেখচিত্র শোষণ বর্ণালি। কোন আলোতে সালোকসংশ্লেষণ কতটা হয় — তা ক্রিয়া বর্ণালি। দুটির শিখর প্রায় মিলে যায় — নীল ও লাল আলোয়। লেখচিত্রে চাপ দিলে সেই λ এর মান।',
  types: {
    abs: ['শোষণ বর্ণালি', 'শোষণ বর্ণালি (Absorption spectrum)', 'ক্লোরোফিল a: শিখর প্রায় 430 ও 662 nm; ক্লোরোফিল b: প্রায় 453 ও 642 nm; ক্যারোটিনয়েড: 400–500 nm এর নীল-বেগুনি অংশে (প্রায় 425, 450, 478 nm)। সবুজ (প্রায় 500–600 nm) সবচেয়ে কম শোষিত হয়। মান দ্রাবকভেদে কয়েক nm সরে যায়।'],
    act: ['ক্রিয়া বর্ণালি', 'ক্রিয়া বর্ণালি ও এঙ্গেলম্যানের পরীক্ষা (1882)', 'এঙ্গেলম্যান প্রিজম দিয়ে বর্ণালি ফেলেছিলেন একটি সবুজ শৈবালের সূত্রের (ক্ল্যাডোফোরা) ওপর, পাশে O<sub>2</sub>-প্রেমী ব্যাকটেরিয়া। ব্যাকটেরিয়া জড়ো হলো নীল ও লাল আলোর অংশে — সেখানেই বেশি O<sub>2</sub>, অর্থাৎ বেশি সালোকসংশ্লেষণ। 680 nm এর পরে হার হঠাৎ কমে — "রেড ড্রপ" (এমারসন)।']
  },
  art(g, C, ty, ctx) {
    const P = (u, v) => [ABX(u), ABb[1] + ABb[3] - v / 1.08 * ABb[3]];
    E('path', { d: `M${ABb[0]} ${ABb[1] - 6}V${ABb[1] + ABb[3]}H${ABb[0] + ABb[2] + 6}`, stroke: C.fg, 'stroke-width': 1.3, fill: 'none' }, g);
    [400, 450, 500, 550, 600, 650, 700].forEach(v => { E('path', { d: `M${ABX(v)} ${ABb[1] + ABb[3]}v4`, stroke: C.mu }, g); T(g, ABX(v), ABb[1] + ABb[3] + 15, String(v), { fs: 9.5, a: 'middle', c: C.mu }); });
    T(g, ABb[0] + ABb[2] + 6, ABb[1] + ABb[3] + 28, 'λ (nm)', { fs: 10, a: 'end', c: C.mu }); T(g, ABb[0] + 6, ABb[1] - 2, ty === 'abs' ? 'শোষণ' : 'আপেক্ষিক হার / শোষণ', { fs: 10, c: C.mu });
    E('rect', { x: ABX(380), y: 212, width: ABb[2], height: 8, fill: specGrad(g, 0, 1, 380, 720) }, g);
    if (ty === 'abs') {
      Object.keys(PIG).forEach((k, i) => { const R = BK.ramp(PIG[k].c); B9.area(g, P, PIG[k].f, 380, 720, 0, { fill: FK.alpha(R.c, .08) }); B9.curve(g, P, PIG[k].f, 380, 720, { stroke: R.c, 'stroke-width': 2.6 }, 120); E('rect', { x: 236, y: 30 + i * 16, width: 12, height: 4, rx: 2, fill: R.c }, g); T(g, 252, 36 + i * 16, PIG[k].n, { fs: 10, c: C.fg }); });
      T(g, ABX(550), 230, 'সবুজ কম শোষিত → প্রতিফলিত', { fs: 9.5, a: 'middle', c: BK.ramp(10).ink });
    } else {
      Object.keys(PIG).forEach(k => B9.curve(g, P, PIG[k].f, 380, 720, { stroke: FK.alpha(BK.ramp(PIG[k].c).c, .35), 'stroke-width': 1.4 }, 100));
      B9.area(g, P, ACT, 380, 720, 0, { fill: FK.alpha(C.fg, .06) }); B9.curve(g, P, ACT, 380, 720, { stroke: C.fg, 'stroke-width': 2.8 }, 120);
      T(g, 236, 36, 'ক্রিয়া বর্ণালি', { fs: 10.5, w: 600, c: C.fg }); T(g, 236, 52, 'হালকা: শোষণ বর্ণালি', { fs: 9.5, c: C.mu });
      const [rx, ry] = P(700, ACT(700)); T(g, rx + 8, ry - 22, 'রেড ড্রপ', { fs: 9.5, a: 'end', c: BK.ramp(4).ink });
      E('path', { d: `M${ABX(385)} 236H${ABX(715)}`, stroke: BK.ramp(10).dk, 'stroke-width': 5, 'stroke-linecap': 'round' }, g);
      T(g, 180, 256, ch('শৈবাল সূত্র + O_2-প্রেমী ব্যাকটেরিয়া'), { fs: 9.5, a: 'middle', c: C.mu });
    }
    if (ctx.sel != null) { const x = ABX(ctx.sel); E('path', { d: `M${x} ${ABb[1]}V${ABb[1] + ABb[3]}`, stroke: C.fg, 'stroke-dasharray': '3 3' }, g); }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'act') { for (let i = 0; i < 80; i++) { const l = 385 + rnd(i * 3 + 1) * 330, p = ACT(l); if (rnd(i * 7 + 2) > p * 1.1) continue; const x = ABX(l) + Math.sin(t * 3 + i) * 1.6, y = 236 + (rnd(i + 9) - .5) * 14 + Math.cos(t * 4 + i) * 1.2; E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: 2.4, ry: 1.3, fill: BK.ramp(3).dk, opacity: .85 }, g); } return; }
    const u = (1 - Math.cos(t * .5)) / 2, l = 400 + u * 300, x = ABX(l); E('path', { d: `M${x} ${ABb[1]}V${ABb[1] + ABb[3]}`, stroke: wl(l), 'stroke-width': 2, opacity: .8 }, g);
    Object.keys(PIG).forEach(k => { const v = PIG[k].f(l), y = ABb[1] + ABb[3] - v / 1.08 * ABb[3]; E('circle', { cx: x, cy: y, r: 3.6, fill: BK.ramp(PIG[k].c).dk }, g); });
  },
  tap(x, y, ty, ctx) {
    if (x < ABb[0] || x > ABb[0] + ABb[2] || y > 222) return null; const l = 380 + (x - ABb[0]) / ABb[2] * 340; ctx.sel = l;
    return `<b>λ ≈ ${FK.n(l, 0)} nm</b> (${colName(l)}) — আপেক্ষিক শোষণ: ক্লোরোফিল a ${FK.n(PIG.a.f(l), 2)}, ক্লোরোফিল b ${FK.n(PIG.b.f(l), 2)}, ক্যারোটিনয়েড ${FK.n(PIG.k.f(l), 2)}; আপেক্ষিক সালোকসংশ্লেষণ ${FK.n(ACT(l), 2)}।<div class="small muted">লেখচিত্রের মান প্রবণতা বোঝানোর জন্য (সর্বোচ্চ ≈ 1)।</div>`;
  }
}));

/* ═════════ ৩. দুই পর্যায়ের সংযোগ ═════════ */
const node = B9.node = (g, x, y, s, R, w = 64, h = 22, o = {}) => { E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: o.rx != null ? o.rx : 7, fill: o.fill || FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': o.sw || 1.1 }, g); T(g, x, y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
V.photoOverview = Object.assign({}, B9.seg({
  id: 'pov', t: 'সালোকসংশ্লেষণের দুই পর্যায় ও সমীকরণ', H: 268, def: 'link',
  cap: 'আলোকনির্ভর পর্যায় (থাইলাকয়েডে) আলো দিয়ে পানি ভেঙে O2 ছাড়ে এবং ATP ও NADPH তৈরি করে। আলোক নিরপেক্ষ পর্যায় (স্ট্রোমায়) সেই ATP ও NADPH দিয়ে CO2 কে শর্করায় পরিণত করে, আর ADP, Pi ও NADP+ ফেরত পাঠায়। দুটি পর্যায় একে অপরের ওপর নির্ভরশীল।',
  types: {
    link: ['দুই পর্যায়', 'আলোকনির্ভর ও আলোক নিরপেক্ষ পর্যায়ের সংযোগ', 'আলোকনির্ভর: আলো + H<sub>2</sub>O + ADP + Pi + NADP<sup>+</sup> → O<sub>2</sub> + ATP + NADPH। আলোক নিরপেক্ষ: CO<sub>2</sub> + ATP + NADPH → (CH<sub>2</sub>O) + ADP + Pi + NADP<sup>+</sup>। আলোক নিরপেক্ষ পর্যায় সরাসরি আলো চায় না, তবে ATP-NADPH ফুরালে থেমে যায় — তাই কার্যত দিনেই চলে।'],
    eq: ['সমীকরণ', 'সমীকরণ ও অক্সিজেনের উৎস', 'রুবেন ও কামেন (1941) ভারী অক্সিজেন (<sup>18</sup>O) দিয়ে দেখান: নির্গত O<sub>2</sub> আসে পানি থেকে, CO<sub>2</sub> থেকে নয়। তাই পূর্ণ সমীকরণে 12 অণু পানি দেখাতে হয় — 12 H<sub>2</sub>O এর 12টি O পরমাণুই 6 O<sub>2</sub> হয়; CO<sub>2</sub> এর O যায় গ্লুকোজ ও নতুন পানিতে।']
  },
  art(g, C, ty) {
    if (ty === 'eq') {
      const Rw = BK.ramp(5), Rc = BK.ramp(9), Ro = BK.ramp(0), Rs = BK.ramp(7);
      T(g, 180, 34, ch('6CO_2 + 12H_2O → C_6H_{12}O_6 + 6O_2 + 6H_2O'), { fs: 14, a: 'middle', w: 650, c: C.fg });
      T(g, 180, 54, 'আলো ও ক্লোরোফিল', { fs: 10, a: 'middle', c: C.mu });
      node(g, 70, 110, ch('12 H_2^{18}O'), Rw, 88, 26, { fs: 11 }); node(g, 70, 190, ch('6 CO_2'), Rc, 88, 26, { fs: 11 });
      node(g, 290, 90, ch('6 ^{18}O_2'), Ro, 88, 26, { fs: 11 }); node(g, 290, 150, ch('C_6H_{12}O_6'), Rs, 88, 26, { fs: 11 }); node(g, 290, 210, ch('6 H_2O'), Rw, 88, 26, { fs: 11 });
      BK.arrow(g, 116, 106, 244, 92, Ro.c, 2.4); BK.arrow(g, 116, 192, 244, 154, Rc.c, 1.6); BK.arrow(g, 116, 196, 244, 208, Rc.c, 1.6);
      T(g, 180, 86, ch('পানির O → O_2'), { fs: 10.5, a: 'middle', w: 600, c: Ro.ink });
      T(g, 180, 238, ch('CO_2 এর O → গ্লুকোজ ও নতুন পানি'), { fs: 10, a: 'middle', c: Rc.ink });
      T(g, 180, 258, 'সরল রূপ: 6CO2 + 6H2O → C6H12O6 + 6O2', { fs: 9.5, a: 'middle', c: C.mu });
      return;
    }
    const Rt = BK.ramp(10), Rs = BK.ramp(0);
    E('rect', { x: 8, y: 54, width: 150, height: 150, rx: 18, fill: FK.alpha(Rt.c, .2), stroke: Rt.dk, 'stroke-width': 1.4 }, g);
    for (let i = 0; i < 4; i++) E('rect', { x: 36, y: 86 + i * 20, width: 94, height: 13, rx: 6, fill: FK.alpha(Rt.c, .6), stroke: Rt.dk, 'stroke-width': .8 }, g);
    T(g, 83, 74, 'আলোকনির্ভর পর্যায়', { fs: 11, a: 'middle', w: 650, c: Rt.ink }); T(g, 83, 186, 'থাইলাকয়েড (গ্রানা)', { fs: 9.5, a: 'middle', c: C.mu });
    E('rect', { x: 202, y: 54, width: 150, height: 150, rx: 18, fill: FK.alpha(Rs.c, .14), stroke: Rs.dk, 'stroke-width': 1.4 }, g);
    E('circle', { cx: 277, cy: 132, r: 38, fill: 'none', stroke: Rs.c, 'stroke-width': 7, opacity: .6 }, g); T(g, 277, 136, 'ক্যালভিন চক্র', { fs: 10, a: 'middle', w: 600, c: Rs.ink });
    T(g, 277, 74, 'আলোক নিরপেক্ষ পর্যায়', { fs: 11, a: 'middle', w: 650, c: Rs.ink }); T(g, 277, 194, 'স্ট্রোমা', { fs: 9.5, a: 'middle', c: C.mu });
    BK.arrow(g, 160, 104, 200, 104, BK.ramp(6).c, 2); BK.arrow(g, 160, 124, 200, 124, BK.ramp(3).c, 2); BK.arrow(g, 200, 152, 160, 152, C.mu, 1.4); BK.arrow(g, 200, 170, 160, 170, C.mu, 1.4);
    T(g, 180, 100, 'ATP', { fs: 9, a: 'middle', w: 600, c: BK.ramp(6).ink }); T(g, 180, 120, 'NADPH', { fs: 9, a: 'middle', w: 600, c: BK.ramp(3).ink }); T(g, 180, 148, 'ADP+Pi', { fs: 8.5, a: 'middle', c: C.mu }); T(g, 180, 166, 'NADP+', { fs: 8.5, a: 'middle', c: C.mu });
    T(g, 40, 28, 'আলো', { fs: 10.5, w: 600, c: BK.ramp(6).ink }); node(g, 40, 232, ch('H_2O'), BK.ramp(5), 50); node(g, 126, 232, ch('O_2'), BK.ramp(0), 50);
    node(g, 236, 28, ch('CO_2'), BK.ramp(9), 50); node(g, 318, 232, 'শর্করা', BK.ramp(7), 58);
    BK.arrow(g, 40, 220, 60, 192, BK.ramp(5).c, 1.6); BK.arrow(g, 104, 192, 122, 220, BK.ramp(0).c, 1.6); BK.arrow(g, 240, 40, 262, 92, BK.ramp(9).c, 1.6); BK.arrow(g, 296, 172, 314, 220, BK.ramp(7).c, 1.6);
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'eq') { for (let i = 0; i < 3; i++) { const u = (t * .35 + i / 3) % 1; B9.dot(g, 116 + 128 * u, 106 - 14 * u, 4, BK.ramp(0).dk); } return; }
    for (let i = 0; i < 3; i++) { const u = (t * .5 + i / 3) % 1, x = 20 + u * 34, y = 14 + u * 56; E('path', { d: `M${x} ${y}l4 4l-3 2l4 4`, stroke: BK.ramp(6).c, 'stroke-width': 1.8, fill: 'none', opacity: 1 - u }, g); }
    const u = (t * .45) % 1; B9.dot(g, 160 + 40 * u, 104, 3.6, BK.ramp(6).dk); B9.dot(g, 160 + 40 * ((u + .5) % 1), 124, 3.6, BK.ramp(3).dk); B9.dot(g, 200 - 40 * u, 152, 2.8, C.mu); B9.dot(g, 200 - 40 * ((u + .5) % 1), 170, 2.8, C.mu);
    const a = t * 1.2; B9.dot(g, 277 + 38 * Math.cos(a), 132 + 38 * Math.sin(a), 4, BK.ramp(0).dk); B9.dot(g, 277 + 38 * Math.cos(a + PI), 132 + 38 * Math.sin(a + PI), 4, BK.ramp(9).dk);
  }
}));

/* ═════════ ৪. অ্যান্টেনা ও বিক্রিয়া কেন্দ্র ═════════ */
const ANT = (() => { const out = []; [[38, 6, 10], [66, 10, 7], [94, 14, 2]].forEach(([r, n, c], k) => { for (let i = 0; i < n; i++) { const a = i / n * PI * 2 + k * .3; out.push([150 + r * Math.cos(a), 128 + r * .82 * Math.sin(a), c, k]); } }); return out; })();
const hopPath = [ANT[30 - 10], ANT[16 + 1], ANT[16], ANT[6 + 2], ANT[2], [150, 128]];
V.antenna = Object.assign({}, B9.seg({
  id: 'ant', t: 'আলোক সংগ্রাহী অ্যান্টেনা ও বিক্রিয়া কেন্দ্র', H: 258, def: 'ps2',
  cap: 'একটি ফটোসিস্টেমে কয়েকশো রঞ্জক অণু অ্যান্টেনার মতো আলো ধরে। শোষিত শক্তি অনুনাদ স্থানান্তরে (রেজোন্যান্স) অণু থেকে অণুতে কেন্দ্রের দিকে যায় — বাইরে বেশি শক্তির (ছোট λ) রঞ্জক, কেন্দ্রের কাছে কম শক্তির (বড় λ)। শেষে বিক্রিয়া কেন্দ্রের বিশেষ ক্লোরোফিল a জোড়া উত্তেজিত হয়ে একটি ইলেকট্রন প্রাথমিক গ্রাহককে দিয়ে দেয়। রঞ্জকে চাপ দাও।',
  types: {
    ps2: ['PS-II', 'ফটোসিস্টেম-II (বিক্রিয়া কেন্দ্র P680)', 'P680 সর্বোচ্চ 680 nm আলো শোষণ করে; উত্তেজিত P680* ইলেকট্রন দেয় ফিওফাইটিনকে। ইলেকট্রন হারানো P680<sup>+</sup> সবচেয়ে শক্তিশালী জৈব জারক (প্রায় +1.2 V) — পানি ভেঙে ইলেকট্রন পূরণ করে।'],
    ps1: ['PS-I', 'ফটোসিস্টেম-I (বিক্রিয়া কেন্দ্র P700)', 'P700 সর্বোচ্চ 700 nm আলো শোষণ করে; উত্তেজিত P700* ইলেকট্রন দেয় A<sub>0</sub> (ক্লোরোফিল) → A<sub>1</sub> → Fe-S → ফেরেডক্সিনকে। ইলেকট্রন পূরণ হয় প্লাস্টোসায়ানিন থেকে (PS-II এর পথ ঘুরে আসা ইলেকট্রন)।']
  },
  art(g, C, ty, ctx) {
    const pn = ty === 'ps2' ? 'P680' : 'P700';
    E('ellipse', { cx: 150, cy: 128, rx: 112, ry: 94, fill: FK.alpha(BK.ramp(10).c, .08), stroke: FK.alpha(BK.ramp(10).dk, .4), 'stroke-dasharray': '4 3' }, g);
    ANT.forEach(([x, y, c], i) => { const R = BK.ramp(c), on = ctx.sel === i; E('circle', { cx: x, cy: y, r: on ? 10 : 8, fill: FK.alpha(R.c, .7), stroke: on ? C.fg : R.dk, 'stroke-width': on ? 2 : 1 }, g); });
    E('circle', { cx: 143, cy: 128, r: 9, fill: BK.ramp(10).dk }, g); E('circle', { cx: 157, cy: 128, r: 9, fill: BK.ramp(10).dk }, g);
    T(g, 150, 152, pn, { fs: 11, a: 'middle', w: 650, c: BK.ramp(10).ink });
    node(g, 306, 60, ty === 'ps2' ? 'ফিওফাইটিন' : ch('A_0 → Fd'), BK.ramp(3), 84, 24);
    T(g, 306, 84, 'প্রাথমিক গ্রাহক', { fs: 9.5, a: 'middle', c: C.mu });
    node(g, 306, 210, ty === 'ps2' ? ch('H_2O → O_2') : 'প্লাস্টোসায়ানিন', ty === 'ps2' ? BK.ramp(5) : BK.ramp(5), 92, 24);
    T(g, 306, 234, 'ইলেকট্রন দাতা', { fs: 9.5, a: 'middle', c: C.mu });
    [[2, 'ক্যারোটিনয়েড (বাইরে)'], [7, 'ক্লোরোফিল b'], [10, 'ক্লোরোফিল a']].forEach(([c, s], i) => { E('circle', { cx: 16, cy: 18 + i * 16, r: 5, fill: BK.ramp(c).c }, g); T(g, 26, 22 + i * 16, s, { fs: 9.5, c: C.fg }); });
  },
  anim(g, C, ty, t) {
    if (!t) return; const u = (t * .32) % 1, R = BK.ramp(6);
    if (u < .15) { const k = u / .15, [x, y] = hopPath[0]; E('path', { d: `M${x - 60 + 60 * k} ${y - 50 + 50 * k}l5 3l-4 3l5 3`, stroke: R.c, 'stroke-width': 2, fill: 'none' }, g); }
    else if (u < .6) { const k = (u - .15) / .45, [x, y] = B9.along(hopPath, k); E('circle', { cx: x, cy: y, r: 12, fill: FK.alpha(R.c, .45) }, g); E('circle', { cx: x, cy: y, r: 5, fill: R.c }, g); }
    else if (u < .8) { const k = FK.ease((u - .6) / .2); E('circle', { cx: 150, cy: 128, r: 18 - 6 * k, fill: FK.alpha(R.c, .35) }, g); B9.dot(g, 150 + (306 - 150) * k, 128 - (128 - 72) * k, 4.2, BK.ramp(3).dk); T(g, 150 + (306 - 150) * k + 6, 128 - (128 - 72) * k - 4, 'e', { fs: 9, c: BK.ramp(3).ink }); }
    else { const k = FK.ease((u - .8) / .2); B9.dot(g, 306 - (306 - 156) * k, 198 - (198 - 136) * k, 4.2, BK.ramp(5).dk); }
  },
  tap(x, y, ty, ctx) {
    if (Math.hypot(x - 150, y - 128) < 18) { ctx.sel = null; return `<b>বিক্রিয়া কেন্দ্র — ${ty === 'ps2' ? 'P680' : 'P700'}</b><div class="small">বিশেষ অবস্থানে প্রোটিনের সাথে যুক্ত এক জোড়া ক্লোরোফিল a — একমাত্র রঞ্জক যা আলোর শক্তিকে রাসায়নিক শক্তিতে (ইলেকট্রন স্থানান্তরে) রূপান্তর করে। বাকিরা কেবল শক্তি সংগ্রহ করে।</div>`; }
    let k = -1, dm = 14; ANT.forEach(([px, py], i) => { const d = Math.hypot(x - px, y - py); if (d < dm) { dm = d; k = i; } }); if (k < 0) return null; ctx.sel = k;
    const c = ANT[k][2]; return c === 2 ? '<b>ক্যারোটিনয়েড (ক্যারোটিন, জ্যান্থোফিল)</b><div class="small">সহকারী রঞ্জক — 400–500 nm এর নীল-বেগুনি আলো শোষণ করে শক্তি ক্লোরোফিলে দেয়; তীব্র আলোয় অতিরিক্ত শক্তি সরিয়ে ক্লোরোফিলকে আলোক-জারণ থেকে রক্ষা করে।</div>' : c === 7 ? '<b>ক্লোরোফিল b</b><div class="small">সহকারী রঞ্জক — প্রায় 453 ও 642 nm শোষণ করে শক্তি ক্লোরোফিল a তে দেয়। গঠনে ক্লোরোফিল a এর CH<sub>3</sub> এর জায়গায় CHO।</div>' : '<b>অ্যান্টেনা ক্লোরোফিল a</b><div class="small">শক্তি সংগ্রহ করে বিক্রিয়া কেন্দ্রের দিকে পাঠায়; সংকেত C<sub>55</sub>H<sub>72</sub>O<sub>5</sub>N<sub>4</sub>Mg — কেন্দ্রে Mg পরমাণু।</div>';
  }
}));

/* ═════════ ৫. পানির সালোকবিভাজন ═════════ */
V.photolysis = Object.assign({ t: 'পানির সালোকবিভাজন (ফটোলাইসিস)', k: ['anim', 'steps'], cap: 'PS-II এর অক্সিজেন-নিঃসরণকারী জটিলে (ম্যাঙ্গানিজ গুচ্ছ, Mn4CaO5) চারটি ফোটনের শক্তিতে ধাপে ধাপে দুই অণু পানি ভেঙে এক অণু O2, চারটি H+ ও চারটি ইলেকট্রন হয়। Mn, Ca ও Cl আয়ন এ জন্য অপরিহার্য।' }, BK.steps({
  W: 360, H: 240, label: 'পানির সালোকবিভাজন', dur: 2.6,
  stages: [
    { t: 'P680 উত্তেজিত হয়', en: 'P680 → P680*', d: 'ফোটন শোষণ করে P680 উত্তেজিত হয় এবং একটি ইলেকট্রন ফিওফাইটিনকে দিয়ে P680<sup>+</sup> হয়।' },
    { t: 'P680+ ইলেকট্রন টানে', en: 'P680+ is a strong oxidant', d: 'P680<sup>+</sup> অত্যন্ত শক্তিশালী জারক — টাইরোসিন (Y<sub>Z</sub>) হয়ে ম্যাঙ্গানিজ গুচ্ছ থেকে একটি ইলেকট্রন টেনে নিয়ে আবার P680 হয়।' },
    { t: 'চারবার আবৃত্তি', en: 'S-state cycle S0 → S4', d: 'ম্যাঙ্গানিজ গুচ্ছ চারটি ফোটনের চারটি ধাপে (S<sub>0</sub> → S<sub>4</sub>) চারটি ইলেকট্রন হারিয়ে জারিত হয় (কক চক্র)।' },
    { t: 'পানি ভাঙে, O2 বের হয়', en: '2H2O → O2 + 4H+ + 4e−', d: 'S<sub>4</sub> অবস্থা দুই অণু পানি থেকে চারটি ইলেকট্রন নিয়ে নেয়: 2H<sub>2</sub>O → 4H<sup>+</sup> + 4e<sup>−</sup> + O<sub>2</sub>। O<sub>2</sub> বাতাসে যায়, H<sup>+</sup> থাইলাকয়েড লুমেনে জমে (ATP তৈরির জন্য)।' }
  ],
  draw(g, C, s, u) {
    const Rm = BK.ramp(3), Rw = BK.ramp(5), Ro = BK.ramp(0), Rh = BK.ramp(4), Rp = BK.ramp(10);
    E('rect', { x: 0, y: 70, width: 360, height: 46, fill: FK.alpha(BK.ramp(2).c, .14) }, g); T(g, 352, 66, 'থাইলাকয়েড ঝিল্লি', { fs: 9.5, a: 'end', c: C.mu }); T(g, 10, 232, 'লুমেন (ভেতর)', { fs: 10, c: C.mu }); T(g, 10, 20, 'স্ট্রোমা', { fs: 10, c: C.mu });
    E('rect', { x: 120, y: 56, width: 120, height: 74, rx: 14, fill: FK.alpha(Rp.c, .25), stroke: Rp.dk }, g); T(g, 180, 50, 'PS-II', { fs: 11, a: 'middle', w: 650, c: Rp.ink });
    const exc = s === 0 ? u : 0; E('circle', { cx: 180, cy: 92, r: 13 + 4 * exc, fill: s === 0 && u > .5 ? FK.alpha(BK.ramp(6).c, .7) : Rp.dk }, g); T(g, 180, 96, 'P680', { fs: 8.5, a: 'middle', w: 650, c: '#fff', st: 'stroke:none' });
    E('rect', { x: 150, y: 148, width: 60, height: 30, rx: 8, fill: FK.alpha(Rm.c, .35), stroke: Rm.dk }, g); T(g, 180, 167, ch('Mn_4CaO_5'), { fs: 9.5, a: 'middle', w: 600, c: Rm.ink });
    const S = s < 2 ? 0 : s === 2 ? Math.min(4, Math.floor(u * 5)) : 4; T(g, 222, 196, `S${S}`.replace(/(\d)/, '<tspan dy="3" font-size="72%">$1</tspan>'), { fs: 11, w: 650, c: Rm.ink });
    for (let i = 0; i < 4; i++) E('circle', { cx: 150 + i * 20, cy: 194, r: 5, fill: i < S ? Rm.c : 'none', stroke: Rm.dk }, g);
    if (s === 0) { const k = FK.ease(u); E('path', { d: `M${40 + 100 * k} ${10 + 60 * k}l5 3l-4 3l5 3`, stroke: BK.ramp(6).c, 'stroke-width': 2.2, fill: 'none' }, g); if (u > .6) { const m = (u - .6) / .4; B9.dot(g, 180 + 100 * m, 92 - 40 * m, 4, Rm.dk); } }
    if (s === 1) { const k = FK.ease(u); B9.dot(g, 180, 148 - 40 * k, 4, Rm.dk); T(g, 194, 140 - 30 * k, 'e', { fs: 9, c: Rm.ink }); }
    if (s === 2) { const k = (u * 4) % 1; B9.dot(g, 180, 148 - 40 * k, 3.6, Rm.dk); }
    const wx = [[110, 214], [250, 214]];
    if (s < 3 || u < .3) wx.forEach(([x, y]) => B9.ion(g, x, y, 'H_2O', Rw, 13));
    if (s === 3 && u >= .3) { const k = FK.ease((u - .3) / .7); B9.ion(g, 180 + 120 * k, 20 + 0 * k + (1 - k) * 160, 'O_2', Ro, 13); for (let i = 0; i < 4; i++) B9.ion(g, 90 + i * 60, 222, 'H^+', Rh, 9); for (let i = 0; i < 4; i++) B9.dot(g, 160 + i * 14, 150 - 20 * k, 3, Rm.dk); }
  }
}));

/* ═════════ ৬. Z-স্কিম ═════════ */
const ZY = e => 34 + (e + 1.4) * 82;
const ZC = {
  h2o: ['H2O', 58, .82, 'পানি', 'ইলেকট্রনের আদি উৎস: 2H<sub>2</sub>O → O<sub>2</sub> + 4H<sup>+</sup> + 4e<sup>−</sup> (E°′ ≈ +0.82 V)।', [0, 16, 'middle']],
  p680: ['P680', 92, 1.2, 'P680 (PS-II এর বিক্রিয়া কেন্দ্র)', 'ইলেকট্রন হারালে P680<sup>+</sup> হয় — প্রায় +1.2 V, পানির চেয়েও শক্তিশালী জারক, তাই পানি থেকে ইলেকট্রন টানতে পারে।', [8, 12, 'start']],
  p680s: ['P680*', 92, -.8, 'উত্তেজিত P680*', 'ফোটনের শক্তিতে ইলেকট্রন উচ্চ শক্তিস্তরে (প্রায় −0.8 V) ওঠে।', [-8, -2, 'end']],
  pheo: ['Pheo', 118, -.52, 'ফিওফাইটিন', 'PS-II এর প্রাথমিক ইলেকট্রন গ্রাহক (Mg বিহীন ক্লোরোফিল)।', [6, -6, 'start']],
  pq: ['PQ', 146, .02, 'প্লাস্টোকুইনোন', 'ঝিল্লিতে চলমান বাহক — দুটি ইলেকট্রন ও স্ট্রোমা থেকে দুটি H<sup>+</sup> নিয়ে PQH<sub>2</sub> হয়ে সাইটোক্রোম b<sub>6</sub>f এ যায়।', [6, -7, 'start']],
  b6f: ['Cyt b6f', 174, .3, 'সাইটোক্রোম b6f জটিল', 'PQH<sub>2</sub> থেকে ইলেকট্রন নিয়ে H<sup>+</sup> লুমেনে পাম্প করে — এই H<sup>+</sup> নতি থেকেই ATP তৈরি হয় (ফটোফসফোরাইলেশন)।', [-4, -10, 'end']],
  pc: ['PC', 202, .37, 'প্লাস্টোসায়ানিন', 'লুমেনে চলমান Cu-যুক্ত প্রোটিন — ইলেকট্রন PS-I এ পৌঁছে দেয়।', [0, 18, 'middle']],
  p700: ['P700', 232, .45, 'P700 (PS-I এর বিক্রিয়া কেন্দ্র)', 'প্লাস্টোসায়ানিন থেকে ইলেকট্রন পেয়ে আবার উত্তেজিত হওয়ার জন্য প্রস্তুত হয়।', [8, 12, 'start']],
  p700s: ['P700*', 232, -1.25, 'উত্তেজিত P700*', 'দ্বিতীয় ফোটনে ইলেকট্রন আরও উঁচু শক্তিস্তরে (প্রায় −1.3 V) ওঠে — জীবজগতের অন্যতম শক্তিশালী বিজারক।', [-8, -2, 'end']],
  fes: ['A0/Fe-S', 262, -.62, 'A0, A1 ও Fe-S কেন্দ্র', 'PS-I এর ভেতরের ইলেকট্রন বাহক শৃঙ্খল (ক্লোরোফিল A<sub>0</sub>, ফাইলোকুইনোন A<sub>1</sub>, আয়রন-সালফার কেন্দ্র)।', [6, -7, 'start']],
  fd: ['Fd', 290, -.42, 'ফেরেডক্সিন', 'স্ট্রোমার দিকে চলমান Fe-S প্রোটিন। অচক্রীয়ে NADP রিডাক্টেজে, চক্রীয়ে আবার সাইটোক্রোম b<sub>6</sub>f এ ইলেকট্রন দেয়।', [0, -9, 'middle']],
  nadp: ['NADP+', 332, -.32, 'NADP+ → NADPH', 'ফেরেডক্সিন-NADP<sup>+</sup> রিডাক্টেজ (FNR): NADP<sup>+</sup> + 2e<sup>−</sup> + H<sup>+</sup> → NADPH — ক্যালভিন চক্রের বিজারক।', [0, 18, 'middle']]
};
const zp = k => [ZC[k][1], ZY(ZC[k][2])];
const ZNON = ['h2o', 'p680', 'p680s', 'pheo', 'pq', 'b6f', 'pc', 'p700', 'p700s', 'fes', 'fd', 'nadp'].map(zp);
const ZCYC = (() => { const a = zp('fd'), b = zp('b6f'), pts = []; for (let i = 0; i <= 10; i++) { const k = i / 10, x = (1 - k) * (1 - k) * a[0] + 2 * k * (1 - k) * 300 + k * k * b[0], y = (1 - k) * (1 - k) * a[1] + 2 * k * (1 - k) * 290 + k * k * b[1]; pts.push([x, y]); } return [zp('p700'), zp('p700s'), zp('fes'), ...pts, zp('pc'), zp('p700')]; })();
V.zscheme = Object.assign({}, B9.seg({
  id: 'zs', t: 'Z-স্কিম: অচক্রীয় ও চক্রীয় ফটোফসফোরাইলেশন', H: 292, def: 'non',
  cap: 'বাহকগুলোকে রেডক্স বিভব (E) অনুযায়ী সাজালে ইলেকট্রনের পথ ইংরেজি Z অক্ষরের মতো দেখায় (হিল ও বেনডাল, 1960)। দুটি ফোটন দুবার ইলেকট্রনকে ওপরে তোলে; নামার পথে মুক্ত শক্তি H+ পাম্প করে ATP বানায়। বাহকে চাপ দিলে পরিচয়।',
  types: {
    non: ['অচক্রীয়', 'অচক্রীয় ফটোফসফোরাইলেশন', 'ইলেকট্রন পানি → PS-II → PQ → সাইটোক্রোম b<sub>6</sub>f → PC → PS-I → Fd → NADP<sup>+</sup> — একমুখী, ফিরে আসে না। দুই ফটোসিস্টেমই লাগে; উৎপন্ন হয় ATP, NADPH ও O<sub>2</sub>। প্রতি 2টি ইলেকট্রনে 1 NADPH (পাঠ্যবইয়ের হিসাবে সাথে 1 ATP)।'],
    cyc: ['চক্রীয়', 'চক্রীয় ফটোফসফোরাইলেশন', 'কেবল PS-I কাজ করে: P700* → Fe-S → Fd → আবার সাইটোক্রোম b<sub>6</sub>f → PC → P700 — ইলেকট্রন ঘুরে নিজের জায়গায় ফেরে। শুধু ATP তৈরি হয়; পানি ভাঙে না, O<sub>2</sub> ও NADPH হয় না। NADP<sup>+</sup> ফুরিয়ে গেলে বা বাড়তি ATP দরকার হলে (ক্যালভিন চক্রে ATP:NADPH = 3:2) চলে।']
  },
  art(g, C, ty, ctx) {
    E('path', { d: `M30 ${ZY(-1.4)}V${ZY(1.4)}`, stroke: C.fg, 'stroke-width': 1.2 }, g);
    [-1.2, -.8, -.4, 0, .4, .8, 1.2].forEach(v => { E('path', { d: `M30 ${ZY(v)}h-4`, stroke: C.mu }, g); T(g, 24, ZY(v) + 3, FK.n(v, 1), { fs: 8.5, a: 'end', c: C.mu }); });
    T(g, 4, 18, 'E (V)', { fs: 9.5, c: C.mu }); T(g, 34, ZY(-1.4) - 4, '↑ শক্তিশালী বিজারক', { fs: 8.5, c: C.mu });
    const on = k => ty === 'non' || ['p700', 'p700s', 'fes', 'fd', 'b6f', 'pc'].indexOf(k) >= 0;
    E('rect', { x: 78, y: ZY(-.9), width: 28, height: ZY(1.28) - ZY(-.9), rx: 8, fill: FK.alpha(BK.ramp(10).c, ty === 'non' ? .14 : .05), stroke: FK.alpha(BK.ramp(10).dk, .5), 'stroke-dasharray': '3 3' }, g); T(g, 92, ZY(-.9) - 6, 'PS-II', { fs: 10, a: 'middle', w: 650, c: BK.ramp(10).ink });
    E('rect', { x: 218, y: ZY(-1.35), width: 28, height: ZY(.53) - ZY(-1.35), rx: 8, fill: FK.alpha(BK.ramp(10).c, .14), stroke: FK.alpha(BK.ramp(10).dk, .5), 'stroke-dasharray': '3 3' }, g); T(g, 250, ZY(-1.02), 'PS-I', { fs: 10, a: 'start', w: 650, c: BK.ramp(10).ink });
    if (ty === 'non') B9.poly(g, ZNON, { stroke: BK.ramp(3).c, 'stroke-width': 2, opacity: .7 });
    else { B9.poly(g, ZNON, { stroke: FK.alpha(C.mu, .3), 'stroke-width': 1.2, 'stroke-dasharray': '3 3' }); B9.poly(g, ZCYC, { stroke: BK.ramp(3).c, 'stroke-width': 2.2, opacity: .8 }); }
    [['p680', 'p680s', '680 nm'], ['p700', 'p700s', '700 nm']].forEach(([a, b, s]) => { if (a === 'p680' && ty !== 'non') return; const [x, y1] = zp(a), [, y2] = zp(b); let d = ''; for (let k = 0; k <= 40; k++) { const yy = y1 - 6 - k * (y1 - y2 - 16) / 40; d += (k ? 'L' : 'M') + (x - 14 + 3 * Math.sin(k * 1.4)).toFixed(1) + ' ' + yy.toFixed(1); } E('path', { d, stroke: BK.ramp(6).c, 'stroke-width': 1.8, fill: 'none' }, g); T(g, x - 20, (y1 + y2) / 2, 'আলো', { fs: 9, a: 'end', c: BK.ramp(6).ink }); T(g, x - 20, (y1 + y2) / 2 + 12, s, { fs: 8.5, a: 'end', c: C.mu }); });
    Object.keys(ZC).forEach(k => { const [s, x, e, , , [dx, dy, an]] = ZC[k], y = ZY(e), R = on(k) ? BK.ramp(3) : BK.ramp(9), sel = ctx.sel === k; E('circle', { cx: x, cy: y, r: sel ? 7 : 5, fill: on(k) ? R.c : FK.alpha(R.c, .4), stroke: sel ? C.fg : R.dk, 'stroke-width': sel ? 2 : 1 }, g); T(g, x + dx, y + dy, s.replace(/b6f/, 'b<tspan dy="3" font-size="72%">6</tspan><tspan dy="-3">f</tspan>').replace('+', '<tspan dy="-4" font-size="72%">+</tspan>'), { fs: 9.5, a: an, w: 600, c: on(k) ? C.fg : C.mu }); });
    B9.chip(g, 150, ZY(.3) + 50, 'H+ পাম্প → ATP'.replace('H+', 'H<tspan dy="-4" font-size="72%">+</tspan><tspan dy="4"></tspan>'), BK.ramp(6), { w: 92 });
    if (ty === 'non') { B9.chip(g, 92, 284, '2H2O → O2 + 4H+', BK.ramp(5), { w: 104, fs: 9 }); B9.chip(g, 318, ZY(-.32) + 40, 'NADPH', BK.ramp(3), { w: 56 }); }
    else T(g, 300, 270, 'ইলেকট্রন ফিরে আসে', { fs: 9.5, a: 'middle', c: BK.ramp(3).ink });
  },
  anim(g, C, ty, t) { if (!t) return; const P = ty === 'non' ? ZNON : ZCYC; for (let i = 0; i < 6; i++) { const [x, y] = B9.along(P, (t * .09 + i / 6) % 1); B9.dot(g, x, y, 3.8, BK.ramp(6).dk); } },
  tap(x, y, ty, ctx) { let k = null, dm = 16; Object.keys(ZC).forEach(q => { const [px, py] = zp(q), d = Math.hypot(x - px, y - py); if (d < dm) { dm = d; k = q; } }); if (!k) return null; ctx.sel = k; const z = ZC[k]; return `<b>${z[3]}</b> <span class="muted small">(E ≈ ${FK.n(z[2], 2)} V)</span><div class="small">${z[4]}</div>`; }
}));

/* ═════════ ৭. থাইলাকয়েড ঝিল্লি — কেমিঅসমোসিস ═════════ */
const TMy = 120;
const TMe = { non: [[52, 196], [52, 124], [92, 126], [134, 122], [176, 168], [214, 130], [250, 78], [284, 64]], cyc: [[214, 130], [250, 78], [190, 92], [134, 122], [176, 168], [214, 130]] };
V.thylakoid = Object.assign({}, B9.seg({
  id: 'thy', t: 'থাইলাকয়েড ঝিল্লিতে ইলেকট্রন ও প্রোটন প্রবাহ', H: 262, def: 'non',
  cap: 'ইলেকট্রন বাহক শৃঙ্খল H+ কে স্ট্রোমা থেকে থাইলাকয়েড লুমেনে জমায়; পানি ভাঙার H+ ও সেখানে যোগ হয়। লুমেন অম্লীয় (pH প্রায় 5), স্ট্রোমা প্রায় 8 — প্রায় 1000 গুণ ঘনত্ব পার্থক্য। H+ ATP সিনথেজের ভেতর দিয়ে স্ট্রোমায় ফেরার সময় ADP + Pi → ATP হয় — মিচেলের কেমিঅসমোটিক মতবাদ (1961)।',
  types: {
    non: ['অচক্রীয়', 'অচক্রীয় — PS-II থেকে NADPH পর্যন্ত', 'ইলেকট্রন: পানি → PS-II → PQ → b<sub>6</sub>f → PC → PS-I → Fd → FNR → NADPH। H<sup>+</sup> লুমেনে আসে দুই উৎস থেকে: পানির সালোকবিভাজন ও PQH<sub>2</sub> এর মাধ্যমে b<sub>6</sub>f এ।'],
    cyc: ['চক্রীয়', 'চক্রীয় — শুধু PS-I', 'Fd এর ইলেকট্রন PQ/b<sub>6</sub>f এ ফিরে গিয়ে আবার PS-I এ আসে। NADPH হয় না, কিন্তু b<sub>6</sub>f এ H<sup>+</sup> পাম্প চলে — তাই ATP হয়।']
  },
  art(g, C, ty) {
    const Rm = BK.ramp(2), Rp = BK.ramp(10), Rb = BK.ramp(4), Ra = BK.ramp(6), Rc = BK.ramp(3);
    E('rect', { x: 0, y: 0, width: 360, height: TMy - 22, fill: FK.alpha(BK.ramp(0).c, .07) }, g); E('rect', { x: 0, y: TMy + 22, width: 360, height: 120, fill: FK.alpha(Rb.c, .07) }, g);
    T(g, 8, 16, ch('স্ট্রোমা (pH ≈ 8) — কম H^+'), { fs: 10, w: 560, c: C.mu }); T(g, 8, 254, ch('লুমেন (pH ≈ 5) — বেশি H^+'), { fs: 10, w: 560, c: Rb.ink });
    E('rect', { x: 0, y: TMy - 22, width: 360, height: 44, fill: FK.alpha(Rm.c, .22) }, g);
    const cx = (x, y, w, h, R, s, ty2) => { E('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: 10, fill: FK.alpha(R.c, .45), stroke: R.dk, 'stroke-width': 1.3, opacity: ty2 ? .4 : 1 }, g); T(g, x, y + 4, s, { fs: 9.5, a: 'middle', w: 650, c: R.ink }); };
    cx(52, TMy, 46, 64, Rp, 'PS-II', ty === 'cyc'); cx(134, TMy, 40, 56, Rc, ch('b_6f')); cx(214, TMy, 46, 64, Rp, 'PS-I');
    E('ellipse', { cx: 92, cy: TMy + 6, rx: 11, ry: 7, fill: Ra.lt, stroke: Ra.dk }, g); T(g, 92, TMy + 9, 'PQ', { fs: 7.5, a: 'middle', w: 650, c: Ra.ink });
    E('circle', { cx: 176, cy: 168, r: 9, fill: BK.ramp(5).lt, stroke: BK.ramp(5).dk }, g); T(g, 176, 171, 'PC', { fs: 7.5, a: 'middle', w: 650, c: BK.ramp(5).ink });
    E('circle', { cx: 250, cy: 78, r: 9, fill: BK.ramp(11).lt, stroke: BK.ramp(11).dk }, g); T(g, 250, 81, 'Fd', { fs: 7.5, a: 'middle', w: 650, c: BK.ramp(11).ink });
    if (ty === 'non') { node(g, 290, 56, 'FNR', Rc, 34, 18, { fs: 8.5 }); T(g, 256, 26, ch('NADP^+ → NADPH'), { fs: 9.5, a: 'middle', w: 600, c: Rc.ink }); B9.ion(g, 52, 204, 'H_2O', BK.ramp(5), 12); T(g, 70, 222, ch('→ O_2 + H^+'), { fs: 9.5, c: C.fg }); }
    E('rect', { x: 316, y: TMy - 20, width: 20, height: 40, rx: 4, fill: FK.alpha(Ra.c, .5), stroke: Ra.dk }, g); E('path', { d: `M326 ${TMy - 20}V${TMy - 40}`, stroke: Ra.dk, 'stroke-width': 4 }, g);
    T(g, 326, TMy + 36, 'ATP সিনথেজ', { fs: 9, a: 'middle', w: 600, c: Ra.ink }); T(g, 354, 46, 'ADP+Pi → ATP', { fs: 8.5, a: 'end', w: 600, c: Ra.ink });
    [[30, 'আলো'], [196, 'আলো']].forEach(([x, s], i) => { if (i === 0 && ty === 'cyc') return; E('path', { d: `M${x} 40l6 4l-5 3l6 4l-5 3l6 4`, stroke: Ra.c, 'stroke-width': 1.8, fill: 'none' }, g); T(g, x - 4, 36, s, { fs: 9, a: 'middle', c: Ra.ink }); });
    B9.poly(g, TMe[ty], { stroke: Rc.c, 'stroke-width': 1.3, 'stroke-dasharray': '3 3', opacity: .8 });
  },
  anim(g, C, ty, t) {
    if (!t) return; const Rb = BK.ramp(4), Ra = BK.ramp(6);
    for (let i = 0; i < 4; i++) { const [x, y] = B9.along(TMe[ty], (t * .14 + i / 4) % 1); B9.dot(g, x, y, 3.6, BK.ramp(3).dk); }
    for (let i = 0; i < 2; i++) { const u = (t * .4 + i / 2) % 1; B9.ion(g, 128 + i * 12, 70 + u * 130, 'H^+', Rb, 6.5, { fs: 6.5 }); }
    if (ty === 'non') { const u = (t * .3) % 1; B9.ion(g, 60 + u * 20, 200 + u * 10, 'H^+', Rb, 6.5, { fs: 6.5 }); B9.ion(g, 52, 190 - u * 160, 'O_2', BK.ramp(0), 8, { fs: 7, op: u < .1 ? 0 : 1 - u * .6 }); }
    for (let i = 0; i < 3; i++) { const u = (t * .35 + i / 3) % 1; B9.ion(g, 326, 200 - u * 170, 'H^+', Rb, 6.5, { fs: 6.5, op: u > .8 ? (1 - u) * 5 : 1 }); }
    for (let k = 0; k < 3; k++) { const a = t * 3 + k * 2.09; E('ellipse', { cx: (326 + 12 * Math.cos(a)).toFixed(1), cy: (TMy - 50 + 4 * Math.sin(a)).toFixed(1), rx: 7, ry: 6, fill: FK.alpha(Ra.c, .8), stroke: Ra.dk }, g); }
  }
}));

/* ═════════ ৮. ক্যালভিন চক্রের হিসাব ═════════ */
V.calvinCount = Object.assign({}, B9.seg({
  id: 'cvc', t: 'ক্যালভিন চক্রের হিসাব — কতটা CO2 এ কত ATP ও NADPH', H: 286, def: 'a',
  cap: 'তিনটি ধাপ: কার্বন সংবন্ধন (কার্বক্সিলেশন), বিজারণ ও RuBP পুনর্গঠন। প্রতি CO2 এ লাগে 3 ATP ও 2 NADPH। স্লাইডারে CO2 এর সংখ্যা বদলালে প্রতিটি তীরের সংখ্যা ও কার্বনের হিসাব বদলাবে।',
  types: { a: ['হিসাব', 'ক্যালভিন চক্রের পরিমাণগত হিসাব', 'n অণু CO<sub>2</sub>: n RuBP + n CO<sub>2</sub> → 2n 3-PGA; 2n 3-PGA + 2n ATP + 2n NADPH → 2n G3P; n/3 G3P বের হয়; 5n/3 G3P + n ATP → n RuBP।'] },
  sl: [{ k: 'n', l: 'CO<sub>2</sub> অণুর সংখ্যা', min: 3, max: 18, step: 3, val: 6 }],
  art(g, C, ty, ctx) {
    const n = ctx.v.n, Rc = BK.ramp(9), Rp = BK.ramp(7), Ra = BK.ramp(6), Rn = BK.ramp(3), Rr = BK.ramp(0);
    const A = [180, 62], B = [290, 190], D = [70, 190];
    E('path', { d: `M${A[0] + 46} ${A[1] + 10}Q${B[0] + 30} ${A[1] + 30} ${B[0]} ${B[1] - 22}`, stroke: Rp.c, 'stroke-width': 5, fill: 'none', opacity: .5 }, g); BK.arrow(g, B[0] + 2, B[1] - 40, B[0], B[1] - 22, Rp.c, 3);
    E('path', { d: `M${B[0] - 50} ${B[1] + 6}H${D[0] + 50}`, stroke: Rp.c, 'stroke-width': 5, opacity: .5 }, g); BK.arrow(g, D[0] + 70, B[1] + 6, D[0] + 50, B[1] + 6, Rp.c, 3);
    E('path', { d: `M${D[0]} ${D[1] - 22}Q${D[0] - 30} ${A[1] + 30} ${A[0] - 46} ${A[1] + 10}`, stroke: Rr.c, 'stroke-width': 5, fill: 'none', opacity: .5 }, g); BK.arrow(g, A[0] - 64, A[1] + 16, A[0] - 46, A[1] + 10, Rr.c, 3);
    node(g, A[0], A[1], '১. কার্বন সংবন্ধন', Rc, 104, 26, { fs: 10.5 }); node(g, B[0], B[1], '২. বিজারণ', Ra, 96, 26, { fs: 10.5 }); node(g, D[0], D[1], '৩. RuBP পুনর্গঠন', Rr, 112, 26, { fs: 10.5 });
    T(g, A[0], A[1] + 26, 'RuBisCO', { fs: 9, a: 'middle', c: C.mu });
    T(g, A[0], 24, ch(`${n} CO_2 (${n} C) প্রবেশ`), { fs: 11, a: 'middle', w: 650, c: Rc.ink }); BK.arrow(g, A[0], 30, A[0], A[1] - 14, Rc.c, 1.6);
    T(g, 274, 112, `${2 * n} 3-PGA`, { fs: 10.5, a: 'end', w: 600, c: Rp.ink }); T(g, 274, 126, `(${6 * n} C)`, { fs: 9, a: 'end', c: C.mu });
    T(g, B[0] + 52, B[1] + 34, `${2 * n} ATP`, { fs: 10.5, a: 'end', w: 600, c: Ra.ink }); T(g, B[0] + 52, B[1] + 48, `${2 * n} NADPH`, { fs: 10.5, a: 'end', w: 600, c: Rn.ink });
    T(g, 180, B[1] - 6, `${2 * n} G3P → ${5 * n / 3} ফেরে`, { fs: 10, a: 'middle', w: 600, c: Rp.ink });
    T(g, D[0] - 50, D[1] + 34, `${n} ATP`, { fs: 10.5, w: 600, c: Ra.ink }); T(g, 88, 112, `${n} RuBP`, { fs: 10.5, w: 600, c: Rr.ink }); T(g, 88, 126, `(${5 * n} C)`, { fs: 9, c: C.mu });
    node(g, 180, 250, `${n / 3} G3P বের হয় (${n} C)`, Rp, 150, 24, { fs: 10.5 }); BK.arrow(g, 180, B[1] + 10, 180, 236, Rp.c, 1.8);
    T(g, 180, 278, `মোট: ${3 * n} ATP + ${2 * n} NADPH${n % 6 === 0 ? ` → ${n / 6} গ্লুকোজ` : ''}`, { fs: 11, a: 'middle', w: 650, c: C.fg });
  },
  more(ty, ctx) { const n = ctx.v.n; return `<div class="small">কার্বনের হিসাব: ঢোকে ${5 * n} (RuBP) + ${n} (CO<sub>2</sub>) = ${6 * n} C = ${2 * n} × 3C (3-PGA)। বের হয় ${n} C (${n / 3} G3P), ফেরে ${5 * n} C (${n} RuBP)। 1 অণু গ্লুকোজ (6C) এর জন্য লাগে 6 CO<sub>2</sub>, 18 ATP ও 12 NADPH — অর্থাৎ চক্র ঘোরে 6 বার।</div>`; },
  anim(g, C, ty, t) {
    if (!t) return; const P = [[226, 72], [300, 90], [292, 168], [240, 196], [120, 196], [64, 168], [64, 110], [134, 72]];
    for (let i = 0; i < 6; i++) { const [x, y] = B9.along(P.concat([P[0]]), (t * .12 + i / 6) % 1); B9.dot(g, x, y, 3.6, BK.ramp(7).dk); }
    const u = (t * .4) % 1; B9.dot(g, 180, 30 + u * 18, 3.6, BK.ramp(9).dk); B9.dot(g, 180, 200 + u * 36, 3.6, BK.ramp(7).dk, 1 - u * .5);
  }
}));

/* ═════════ ৯. স্টার্চ ও সুক্রোজ ═════════ */
const SSpath = { day: [[[66, 46], [112, 96], [178, 118], [238, 118], [238, 160], [268, 204], [312, 238]], [[112, 96], [86, 150], [86, 196], [60, 236]]], night: [[[60, 236], [120, 224], [178, 214], [238, 200], [268, 214], [312, 238]]] };
V.starchSucrose = Object.assign({}, B9.seg({
  id: 'ss', t: 'স্টার্চ ও সুক্রোজ উৎপাদন', H: 262, def: 'day',
  cap: 'ক্যালভিন চক্রের ট্রায়োজ ফসফেট (G3P) দুই পথে যায়: ক্লোরোপ্লাস্টের ভেতরে স্টার্চ (সাময়িক সঞ্চয়), আর ফসফেট ট্রান্সলোকেটর দিয়ে সাইটোসলে গিয়ে সুক্রোজ — যা ফ্লোয়েমে করে সারা দেহে যায়। রাতে স্টার্চ ভেঙে সুক্রোজ তৈরি চলতে থাকে।',
  types: {
    day: ['দিন', 'দিনে — সালোকসংশ্লেষণ চলছে', 'G3P → (ট্রায়োজ ফসফেট/Pi ট্রান্সলোকেটর, বিনিময়ে Pi ভেতরে) → সাইটোসলে F-1,6-BP → F-6-P; UDP-গ্লুকোজ + F-6-P → সুক্রোজ-6-P → সুক্রোজ। বাড়তি G3P ক্লোরোপ্লাস্টে F-6-P → G-6-P → G-1-P → ADP-গ্লুকোজ → স্টার্চ।'],
    night: ['রাত', 'রাতে — সালোকসংশ্লেষণ বন্ধ', 'দিনে জমা স্টার্চ ভেঙে মল্টোজ ও গ্লুকোজ হয়, ক্লোরোপ্লাস্ট থেকে বেরিয়ে সাইটোসলে সুক্রোজ তৈরি করে — তাই রাতেও ফ্লোয়েমে খাদ্য পরিবহন চলে।']
  },
  art(g, C, ty) {
    const Rch = BK.ramp(10), Rs = BK.ramp(7), Rst = BK.ramp(11), Rp = BK.ramp(6);
    E('rect', { x: 6, y: 18, width: 172, height: 236, rx: 26, fill: FK.alpha(Rch.c, .12), stroke: Rch.dk, 'stroke-width': 1.6 }, g); T(g, 92, 14, 'ক্লোরোপ্লাস্ট (স্ট্রোমা)', { fs: 10, a: 'middle', w: 600, c: Rch.ink });
    T(g, 268, 14, 'সাইটোসল', { fs: 10, a: 'middle', w: 600, c: C.mu });
    E('rect', { x: 170, y: 108, width: 16, height: 20, rx: 4, fill: Rp.c }, g); T(g, 196, 102, 'Pi ট্রান্সলোকেটর', { fs: 8.5, c: Rp.ink });
    E('circle', { cx: 52, cy: 50, r: 22, fill: 'none', stroke: Rch.c, 'stroke-width': 5, opacity: ty === 'day' ? .7 : .2 }, g); T(g, 52, 54, 'ক্যালভিন', { fs: 8.5, a: 'middle', w: 600, c: Rch.ink });
    node(g, 112, 92, 'G3P', Rs, 46, 20); node(g, 86, 150, 'F-6-P → G-1-P', Rst, 92, 20, { fs: 9 }); node(g, 86, 196, 'ADP-গ্লুকোজ', Rst, 82, 20, { fs: 9 }); node(g, 60, 236, 'স্টার্চ', Rst, 60, 22);
    node(g, 238, 140, 'ট্রায়োজ-P → F-6-P', Rs, 112, 20, { fs: 9 }); node(g, 268, 194, 'UDP-গ্লুকোজ + F-6-P', Rs, 126, 20, { fs: 9 }); node(g, 312, 238, 'সুক্রোজ', BK.ramp(2), 66, 22);
    BK.arrow(g, 312, 226, 340, 200, BK.ramp(2).c, 1.6); T(g, 344, 194, 'ফ্লোয়েমে', { fs: 9, a: 'end', c: C.mu });
    if (ty === 'night') { E('rect', { x: 170, y: 206, width: 16, height: 18, rx: 4, fill: BK.ramp(5).c }, g); T(g, 192, 230, 'মল্টোজ/গ্লুকোজ', { fs: 8.5, c: BK.ramp(5).ink }); E('rect', { x: 0, y: 0, width: 360, height: 262, rx: 12, fill: FK.alpha('#000', .06) }, g); }
  },
  anim(g, C, ty, t) { if (!t) return; SSpath[ty].forEach((P, j) => { for (let i = 0; i < 4; i++) { const [x, y] = B9.along(P, (t * .14 + i / 4 + j * .13) % 1); B9.dot(g, x, y, 3.4, j ? BK.ramp(11).dk : BK.ramp(7).dk); } }); }
}));

/* ═════════ ১০. আলোকশ্বসন ═════════ */
const PRp = [[42, 58], [42, 108], [94, 108], [94, 150], [180, 150], [180, 108], [180, 64], [292, 64], [292, 160], [180, 200], [180, 238], [94, 238], [42, 238], [42, 200]];
V.photoresp = Object.assign({}, B9.seg({
  id: 'pr', t: 'আলোকশ্বসন (ফটোরেসপিরেশন) — C2 চক্র', H: 286, def: 'a',
  cap: 'RuBisCO একটি দ্বৈত এনজাইম — CO2 এর বদলে O2 যুক্ত করলে (অক্সিজিনেশন) তৈরি হয় 2-ফসফোগ্লাইকোলেট। একে কাজে লাগাতে ক্লোরোপ্লাস্ট, পারঅক্সিজোম ও মাইটোকন্ড্রিয়া মিলে C2 চক্র চালায় — এতে CO2 বেরিয়ে যায়, শক্তি খরচ হয়, কোনো ATP তৈরি হয় না। স্লাইডারে তাপমাত্রা বদলাও।',
  types: { a: ['C2 চক্র', 'আলোকশ্বসনের পথ', 'RuBP + O<sub>2</sub> → 3-PGA + 2-ফসফোগ্লাইকোলেট → গ্লাইকোলেট → (পারঅক্সিজোম) গ্লাইঅক্সিলেট + H<sub>2</sub>O<sub>2</sub> → গ্লাইসিন → (মাইটোকন্ড্রিয়া) 2 গ্লাইসিন → সেরিন + CO<sub>2</sub> + NH<sub>3</sub> → (পারঅক্সিজোম) হাইড্রক্সিপাইরুভেট → গ্লিসারেট → (ক্লোরোপ্লাস্ট, ATP) → 3-PGA। দুটি গ্লাইকোলেটের 4টি C এর 1টি CO<sub>2</sub> হয়ে হারায় — 25%।'] },
  sl: [{ k: 'T', l: 'পাতার তাপমাত্রা (°C)', min: 15, max: 40, step: 1, val: 25 }],
  art(g, C, ty, ctx) {
    const Rch = BK.ramp(10), Rpx = BK.ramp(6), Rmt = BK.ramp(2);
    E('rect', { x: 4, y: 22, width: 128, height: 232, rx: 22, fill: FK.alpha(Rch.c, .12), stroke: Rch.dk, 'stroke-width': 1.4 }, g); T(g, 68, 16, 'ক্লোরোপ্লাস্ট', { fs: 10, a: 'middle', w: 600, c: Rch.ink });
    E('rect', { x: 138, y: 40, width: 86, height: 214, rx: 40, fill: FK.alpha(Rpx.c, .12), stroke: Rpx.dk, 'stroke-width': 1.4 }, g); T(g, 181, 34, 'পারঅক্সিজোম', { fs: 10, a: 'middle', w: 600, c: Rpx.ink });
    E('rect', { x: 232, y: 40, width: 124, height: 150, rx: 40, fill: FK.alpha(Rmt.c, .12), stroke: Rmt.dk, 'stroke-width': 1.4 }, g); T(g, 294, 34, 'মাইটোকন্ড্রিয়া', { fs: 10, a: 'middle', w: 600, c: Rmt.ink });
    B9.poly(g, PRp, { stroke: FK.alpha(C.mu, .7), 'stroke-width': 1.2, 'stroke-dasharray': '3 3' });
    const R7 = BK.ramp(7);
    node(g, 42, 58, ch('RuBP + O_2'), BK.ramp(0), 72, 20, { fs: 9 }); T(g, 46, 80, 'RuBisCO', { fs: 8.5, c: C.mu });
    node(g, 42, 110, '3-PGA', R7, 52, 20, { fs: 9 }); node(g, 94, 128, 'ফসফো-', R7, 54, 20, { fs: 8.5 }); T(g, 94, 150, 'গ্লাইকোলেট', { fs: 8.5, a: 'middle', c: C.mu });
    node(g, 181, 150, 'গ্লাইকোলেট', Rpx, 70, 20, { fs: 9 }); node(g, 181, 108, 'গ্লাইঅক্সিলেট', Rpx, 74, 20, { fs: 9 }); node(g, 181, 66, 'গ্লাইসিন', Rpx, 60, 20, { fs: 9 });
    B9.chip(g, 181, 128, ch('H_2O_2 → H_2O'), Rpx, { w: 72, h: 14, fs: 8 });
    node(g, 294, 80, '2 গ্লাইসিন', Rmt, 70, 20, { fs: 9 }); node(g, 294, 160, 'সেরিন', Rmt, 52, 20, { fs: 9 }); B9.chip(g, 294, 120, ch('CO_2 + NH_3'), BK.ramp(4), { w: 82, h: 18, fs: 9 });
    node(g, 181, 200, 'হাইড্রক্সি-', Rpx, 66, 20, { fs: 8.5 }); T(g, 181, 222, 'পাইরুভেট', { fs: 8.5, a: 'middle', c: C.mu }); node(g, 181, 240, 'গ্লিসারেট', Rpx, 60, 18, { fs: 8.5 });
    node(g, 80, 238, 'গ্লিসারেট + ATP', R7, 86, 20, { fs: 8.5 }); node(g, 42, 196, '3-PGA', R7, 52, 20, { fs: 9 }); T(g, 72, 176, 'ক্যালভিন চক্রে', { fs: 8.5, c: C.mu });
    const Tc = ctx.v.T, fo = cl(.12 + (Tc - 15) * .011, 0, .6); ctx.fo = fo;
    T(g, 8, 270, 'RuBisCO:', { fs: 9.5, w: 600, c: C.fg }); E('rect', { x: 70, y: 262, width: 270, height: 10, rx: 5, fill: BK.ramp(9).c }, g); E('rect', { x: 70 + 270 * (1 - fo), y: 262, width: 270 * fo, height: 10, rx: 5, fill: BK.ramp(4).c }, g);
    T(g, 72, 284, `কার্বক্সিলেশন ≈ ${Math.round((1 - fo) * 100)}%`, { fs: 9, c: BK.ramp(9).ink }); T(g, 340, 284, `অক্সিজিনেশন ≈ ${Math.round(fo * 100)}%`, { fs: 9, a: 'end', c: BK.ramp(4).ink });
  },
  more(ty, ctx) { return `<div class="small">${ctx.v.T} °C: আনুমানিক প্রতি ১০০ বার RuBisCO বিক্রিয়ায় প্রায় ${Math.round(ctx.fo * 100)} বার O<sub>2</sub> যুক্ত হয় (প্রবণতা; বাতাসের সাধারণ CO<sub>2</sub>/O<sub>2</sub> এ)। তাপ বাড়লে CO<sub>2</sub> এর চেয়ে O<sub>2</sub> এর দ্রবণীয়তা কম কমে এবং RuBisCO এর CO<sub>2</sub>-প্রীতি কমে — তাই গরম, উজ্জ্বল, শুষ্ক দিনে (রন্ধ্র বন্ধ, পাতায় CO<sub>2</sub> কম) C3 উদ্ভিদে আলোকশ্বসন বাড়ে।</div>`; },
  anim(g, C, ty, t, ctx) { if (!t) return; const n = 2 + Math.round((ctx.fo || .2) * 10); for (let i = 0; i < n; i++) { const [x, y] = B9.along(PRp, (t * .07 + i / n) % 1); B9.dot(g, x, y, 3.4, BK.ramp(4).dk); } const u = (t * .3) % 1; B9.ion(g, 330 + u * 10, 120 - u * 90, 'CO_2', BK.ramp(9), 9, { fs: 7, op: 1 - u }); }
}));

/* ═════════ ১১. হ্যাচ-স্ল্যাক চক্র ═════════ */
const HSp = { c: [[30, 22], [42, 58], [60, 118], [128, 82], [128, 160], [180, 160], [232, 160], [232, 206]], co2: [[262, 130], [290, 100], [300, 74]], back: [[232, 206], [180, 214], [120, 214], [60, 214], [60, 126]] };
V.hatchSlack = Object.assign({}, B9.seg({
  id: 'hs', t: 'হ্যাচ-স্ল্যাক চক্র (C4 পথ)', H: 256, def: 'a',
  cap: 'C4 উদ্ভিদে (ভুট্টা, আখ) মেসোফিল কোষে PEP কার্বক্সিলেজ CO2 কে প্রথমে 4C যৌগ অক্সালো-অ্যাসিটিক অ্যাসিডে বাঁধে। ম্যালেট হয়ে তা বান্ডল শিথ কোষে গিয়ে CO2 ছাড়ে — সেখানে CO2 এর ঘনত্ব বেড়ে যায়, RuBisCO প্রায় শুধু ক্যালভিন চক্র চালায়, আলোকশ্বসন প্রায় হয় না। যৌগে চাপ দাও।',
  types: { a: ['C4 পথ', 'হ্যাচ ও স্ল্যাক (1966) চক্র', 'মেসোফিল: CO<sub>2</sub> (HCO<sub>3</sub><sup>−</sup>) + PEP → OAA (PEPCase) → ম্যালেট (NADPH)। বান্ডল শিথ: ম্যালেট → পাইরুভেট + CO<sub>2</sub> + NADPH (ম্যালিক এনজাইম); CO<sub>2</sub> → ক্যালভিন চক্র। পাইরুভেট মেসোফিলে ফিরে ATP খরচ করে আবার PEP হয় (পাইরুভেট ফসফেট ডাইকাইনেজ: ATP → AMP + PPi)। তাই প্রতি CO<sub>2</sub> এ বাড়তি 2 ATP — মোট 5 ATP ও 2 NADPH।'] },
  art(g, C, ty, ctx) {
    const Rm = BK.ramp(10), Rb = BK.ramp(11), R7 = BK.ramp(7), Rc = BK.ramp(9);
    E('rect', { x: 6, y: 34, width: 160, height: 200, rx: 16, fill: FK.alpha(Rm.c, .1), stroke: Rm.dk, 'stroke-width': 1.4 }, g); T(g, 86, 28, 'মেসোফিল কোষ', { fs: 10.5, a: 'middle', w: 600, c: Rm.ink });
    E('rect', { x: 196, y: 34, width: 158, height: 200, rx: 16, fill: FK.alpha(Rb.c, .22), stroke: Rb.dk, 'stroke-width': 1.4 }, g); T(g, 275, 28, 'বান্ডল শিথ কোষ', { fs: 10.5, a: 'middle', w: 600, c: Rb.ink });
    for (let y = 60; y < 230; y += 26) E('path', { d: `M166 ${y}h30`, stroke: C.mu, 'stroke-width': 1 }, g); T(g, 181, 250, 'প্লাজমোডেসমাটা', { fs: 8.5, a: 'middle', c: C.mu });
    const N = { co2: [42, 58, ch('CO_2 → HCO_3^-'), Rc, 92], pep: [60, 126, 'PEP (3C)', R7, 64], oaa: [128, 82, 'OAA (4C)', BK.ramp(2), 64], mal: [128, 160, 'ম্যালেট (4C)', BK.ramp(2), 70], mal2: [232, 160, 'ম্যালেট', BK.ramp(2), 56], pyr2: [232, 206, 'পাইরুভেট (3C)', R7, 86], co2b: [262, 122, ch('CO_2'), Rc, 44], cal: [300, 74, 'ক্যালভিন চক্র', BK.ramp(0), 84], pyr: [96, 214, 'পাইরুভেট', R7, 64] };
    ctx.N = N;
    Object.keys(N).forEach(k => { const [x, y, s, R, w] = N[k]; node(g, x, y, s, R, w, 20, { fs: 9, sw: ctx.sel === k ? 2.4 : 1.1 }); });
    BK.arrow(g, 76, 116, 104, 92, BK.ramp(2).c, 1.4); BK.arrow(g, 128, 94, 128, 148, BK.ramp(2).c, 1.4); BK.arrow(g, 164, 160, 202, 160, BK.ramp(2).c, 1.4); BK.arrow(g, 232, 172, 232, 194, R7.c, 1.4); BK.arrow(g, 246, 150, 258, 134, Rc.c, 1.4); BK.arrow(g, 272, 112, 290, 88, Rc.c, 1.4); BK.arrow(g, 188, 214, 130, 214, R7.c, 1.4); BK.arrow(g, 70, 202, 64, 140, R7.c, 1.4);
    T(g, 112, 104, 'PEPCase', { fs: 8.5, a: 'end', c: C.mu }); T(g, 136, 124, 'NADPH', { fs: 8.5, c: BK.ramp(3).ink }); T(g, 300, 190, 'NADPH বের হয়', { fs: 8.5, a: 'middle', c: BK.ramp(3).ink }); T(g, 18, 176, 'ATP→AMP', { fs: 8.5, c: BK.ramp(6).ink }); T(g, 300, 110, 'RuBisCO', { fs: 8.5, a: 'middle', c: C.mu }); node(g, 318, 34 + 10, 'শর্করা', R7, 46, 16, { fs: 8.5 });
  },
  anim(g, C, ty, t) { if (!t) return; for (let i = 0; i < 4; i++) { const [x, y] = B9.along(HSp.c, (t * .1 + i / 4) % 1); B9.dot(g, x, y, 3.6, BK.ramp(2).dk); } for (let i = 0; i < 3; i++) { const [x, y] = B9.along(HSp.back, (t * .1 + i / 3) % 1); B9.dot(g, x, y, 3.2, BK.ramp(7).dk); } const [x, y] = B9.along(HSp.co2, (t * .25) % 1); B9.dot(g, x, y, 3.6, BK.ramp(9).dk); },
  tap(x, y, ty, ctx) { const N = ctx.N || {}; let k = null; Object.keys(N).forEach(q => { const [px, py, , , w] = N[q]; if (Math.abs(x - px) < w / 2 && Math.abs(y - py) < 12) k = q; }); if (!k) return null; ctx.sel = k; return ({ co2: '<b>CO<sub>2</sub> → HCO<sub>3</sub><sup>−</sup></b><div class="small">মেসোফিলে কার্বনিক অ্যানহাইড্রেজ CO<sub>2</sub> কে বাইকার্বনেটে পরিণত করে — PEPCase আসলে HCO<sub>3</sub><sup>−</sup> নিয়েই কাজ করে।</div>', pep: '<b>PEP — ফসফোইনলপাইরুভিক অ্যাসিড (3C)</b><div class="small">C4 পথের প্রাথমিক CO<sub>2</sub> গ্রাহক। PEPCase এর O<sub>2</sub> এর প্রতি আসক্তি নেই এবং CO<sub>2</sub>/HCO<sub>3</sub><sup>−</sup> এর প্রতি আসক্তি বেশি — তাই কম CO<sub>2</sub> তেও কাজ করে।</div>', oaa: '<b>অক্সালো-অ্যাসিটিক অ্যাসিড (OAA, 4C)</b><div class="small">C4 পথের প্রথম স্থায়ী যৌগ — এ জন্যই নাম C4 উদ্ভিদ।</div>', mal: '<b>ম্যালিক অ্যাসিড (4C)</b><div class="small">OAA NADPH দিয়ে বিজারিত হয়ে ম্যালেট হয় (NADP-ম্যালেট ডিহাইড্রোজিনেজ)। ম্যালেট প্লাজমোডেসমাটা দিয়ে বান্ডল শিথে যায়। (কিছু C4 উদ্ভিদে অ্যাসপারটেট যায়।)</div>', mal2: '<b>বান্ডল শিথে ম্যালেট</b><div class="small">NADP-ম্যালিক এনজাইম ম্যালেটকে ডিকার্বক্সিলেট করে: ম্যালেট → পাইরুভেট + CO<sub>2</sub> + NADPH।</div>', pyr2: '<b>পাইরুভেট (3C)</b><div class="small">বান্ডল শিথ থেকে মেসোফিলে ফিরে যায়।</div>', co2b: '<b>মুক্ত CO<sub>2</sub></b><div class="small">বান্ডল শিথে CO<sub>2</sub> এর ঘনত্ব বাতাসের চেয়ে প্রায় 10 গুণ বা তারও বেশি হয় — RuBisCO এর অক্সিজিনেশন প্রায় বন্ধ থাকে।</div>', cal: '<b>ক্যালভিন চক্র</b><div class="small">C4 উদ্ভিদেও শর্করা তৈরি হয় বান্ডল শিথের ক্যালভিন চক্রে — C4 পথ কেবল CO<sub>2</sub> "পাম্প"।</div>', pyr: '<b>পাইরুভেট → PEP</b><div class="small">পাইরুভেট ফসফেট ডাইকাইনেজ: পাইরুভেট + ATP + Pi → PEP + AMP + PPi — এক ATP থেকে দুটি উচ্চশক্তির ফসফেট বন্ধন খরচ হয় (2 ATP এর সমান)।</div>' })[k]; }
}));

/* ═════════ ১২. ক্র্যাঞ্জ অঙ্গসংস্থান ═════════ */
V.kranz = Object.assign({}, B9.seg({
  id: 'kr', t: 'C3 ও C4 পাতার প্রস্থচ্ছেদ — ক্র্যাঞ্জ অঙ্গসংস্থান', H: 250, def: 'c4',
  cap: 'C4 পাতায় প্রতিটি ভাস্কুলার বান্ডলের চারপাশে ক্লোরোপ্লাস্টে ভরা বড় বান্ডল শিথ কোষের মালা, তার বাইরে অরীয়ভাবে সাজানো মেসোফিল — জার্মান শব্দ "Kranz" মানে মালা। C3 পাতায় মেসোফিল প্যালিসেড ও স্পঞ্জিতে বিভক্ত, বান্ডল শিথ কোষ ছোট ও প্রায় ক্লোরোপ্লাস্টহীন। চালাও — CO2 কোথায় সংবন্ধিত হয় দেখো।',
  types: {
    c3: ['C3 পাতা', 'C3 পাতা (যেমন ধান, গম, আলু)', 'সব মেসোফিল কোষে RuBisCO সরাসরি CO<sub>2</sub> সংবন্ধন করে (ক্যালভিন চক্র)। রন্ধ্র আংশিক বন্ধ হলে পাতার ভেতরে CO<sub>2</sub> কমে, O<sub>2</sub> বাড়ে — আলোকশ্বসন বাড়ে।'],
    c4: ['C4 পাতা', 'C4 পাতা (যেমন ভুট্টা, আখ, জোয়ার, মুথা ঘাস)', 'মেসোফিলে PEPCase CO<sub>2</sub> ধরে 4C যৌগ বানায়; বান্ডল শিথে CO<sub>2</sub> ছেড়ে ঘনীভূত করে। দুই ধরনের কোষে দুই রকম ক্লোরোপ্লাস্ট (দ্বিরূপতা): মেসোফিলে গ্রানাযুক্ত, বান্ডল শিথে (NADP-ME ধরনে) গ্রানাহীন বড় ক্লোরোপ্লাস্ট।']
  },
  art(g, C, ty) {
    const Rm = BK.ramp(10), Rb = BK.ramp(11), Re = BK.ramp(0), Rx = BK.ramp(4);
    [20, 214].forEach(y => { E('rect', { x: 0, y, width: 360, height: 14, fill: FK.alpha(Re.c, .22) }, g); for (let x = 0; x < 360; x += 20) E('path', { d: `M${x} ${y}v14`, stroke: Re.dk, 'stroke-width': .7 }, g); });
    E('rect', { x: 176, y: 214, width: 16, height: 14, fill: C.sf }, g); E('ellipse', { cx: 178, cy: 221, rx: 3, ry: 6, fill: Rm.c }, g); E('ellipse', { cx: 190, cy: 221, rx: 3, ry: 6, fill: Rm.c }, g);
    const vein = (cx, cy) => { for (let i = 0; i < 6; i++) B9.blob(g, cx - 8 + (i % 3) * 8, cy - 5 + Math.floor(i / 3) * 10, 4.5, { fill: i < 3 ? FK.alpha(Rx.c, .5) : FK.alpha(BK.ramp(10).c, .3), stroke: i < 3 ? Rx.dk : Rm.dk, sw: .7, seed: i + 70 }); };
    if (ty === 'c4') {
      [[90, 124], [270, 124]].forEach(([cx, cy], v) => {
        for (let i = 0; i < 9; i++) { const a = i / 9 * PI * 2, x = cx + 26 * Math.cos(a), y = cy + 26 * Math.sin(a); B9.blob(g, x, y, 11, { fill: FK.alpha(Rb.c, .7), stroke: Rb.dk, sw: 1, seed: i + v * 9 }); for (let k = 0; k < 3; k++) E('ellipse', { cx: x + Math.cos(a) * 4 + (k - 1) * 3 * Math.sin(a), cy: y + Math.sin(a) * 4 - (k - 1) * 3 * Math.cos(a), rx: 2.6, ry: 1.8, fill: Rm.dk }, g); }
        for (let i = 0; i < 14; i++) { const a = i / 14 * PI * 2 + .1, x = cx + 52 * Math.cos(a), y = cy + 48 * Math.sin(a); if (y < 40 || y > 208) continue; E('ellipse', { cx: x, cy: y, rx: 15, ry: 7, transform: `rotate(${a * 180 / PI} ${x} ${y})`, fill: FK.alpha(Rm.c, .32), stroke: Rm.dk, 'stroke-width': .8 }, g); }
        vein(cx, cy);
      });
      B9.lab(g, 116, 124, 180, 66, 'বান্ডল শিথ (মালা)', C, { a: 'middle' }); B9.lab(g, 270, 72, 300, 46, 'অরীয় মেসোফিল', C, { a: 'start' }); B9.lab(g, 90, 124, 40, 196, 'জাইলেম/ফ্লোয়েম', C, { a: 'end' });
    } else {
      for (let x = 4; x < 360; x += 15) E('rect', { x, y: 36, width: 11, height: 48, rx: 5, fill: FK.alpha(Rm.c, .5), stroke: Rm.dk, 'stroke-width': .7 }, g);
      for (let i = 0; i < 30; i++) { const x = 12 + (i % 15) * 24 + (i > 14 ? 12 : 0), y = 110 + (i > 14 ? 60 : 0) + (rnd(i) - .5) * 10; if (Math.abs(x - 180) < 34 && Math.abs(y - 140) < 40) continue; B9.blob(g, x, y, 10, { fill: FK.alpha(Rm.c, .3), stroke: Rm.dk, sw: .7, seed: i + 30 }); }
      for (let i = 0; i < 8; i++) { const a = i / 8 * PI * 2; B9.blob(g, 180 + 22 * Math.cos(a), 140 + 22 * Math.sin(a), 8, { fill: FK.alpha(Rb.c, .2), stroke: Rb.dk, sw: .8, seed: i + 60 }); }
      vein(180, 140);
      B9.lab(g, 120, 60, 80, 50, 'প্যালিসেড', C, { a: 'end' }); B9.lab(g, 300, 110, 320, 196, 'স্পঞ্জি', C, { a: 'start' }); B9.lab(g, 202, 140, 250, 196, 'বান্ডল শিথ (হালকা)', C, { a: 'start' });
    }
  },
  anim(g, C, ty, t) {
    if (!t) return; const R = BK.ramp(9);
    for (let i = 0; i < 8; i++) { const u = (t * .18 + i / 8) % 1, tx = ty === 'c4' ? (i % 2 ? 270 : 90) : 30 + i * 42, ty2 = ty === 'c4' ? 124 : 70 + (i % 3) * 40; const x = 184 + (tx - 184) * Math.min(1, u * 1.3), y = 222 + (ty2 - 222) * Math.min(1, u * 1.3); const fade = ty === 'c4' ? 1 : u > .75 ? (1 - u) * 4 : 1; B9.dot(g, x, y, 3, R.dk, fade); }
    if (ty === 'c4') [[90, 124], [270, 124]].forEach(([cx, cy], v) => { for (let k = 0; k < 5; k++) { const a = t * .8 + k * 1.25 + v; B9.dot(g, cx + 26 * Math.cos(a), cy + 26 * Math.sin(a), 2.6, R.dk, .9); } });
  }
}));

/* ═════════ তুলনা ═════════ */
const cmp = (t, cap, a, b, rows) => Object.assign({ t, k: ['compare', 'int'], cap }, BK.compare({ a, b, rows }));
V.cmpPS = cmp('ফটোসিস্টেম-I বনাম ফটোসিস্টেম-II', 'সারিতে চাপ দিলে চিহ্নিত হয়।', 'ফটোসিস্টেম-I (PS-I)', 'ফটোসিস্টেম-II (PS-II)', [
  ['বিক্রিয়া কেন্দ্র', 'P700 (সর্বোচ্চ 700 nm শোষণ)', 'P680 (সর্বোচ্চ 680 nm শোষণ)'],
  ['অবস্থান', 'প্রধানত স্ট্রোমা থাইলাকয়েড ও গ্রানার বাইরের দিকে', 'প্রধানত গ্রানা থাইলাকয়েডের চাপা অংশে'],
  ['রঞ্জক', 'ক্লোরোফিল a বেশি, ক্লোরোফিল b কম', 'ক্লোরোফিল b তুলনামূলক বেশি'],
  ['প্রাথমিক গ্রাহক', 'A<sub>0</sub> (ক্লোরোফিল) → A<sub>1</sub> → Fe-S', 'ফিওফাইটিন'],
  ['ইলেকট্রন দাতা', 'প্লাস্টোসায়ানিন', 'পানি (ম্যাঙ্গানিজ গুচ্ছের মাধ্যমে)'],
  ['পানির সালোকবিভাজন', 'জড়িত নয়', 'জড়িত — O<sub>2</sub> নির্গত হয়'],
  ['ফটোফসফোরাইলেশন', 'চক্রীয় ও অচক্রীয় দুটিতেই', 'শুধু অচক্রীয়তে'],
  ['NADPH', 'তৈরি করে (Fd → NADP<sup>+</sup>)', 'সরাসরি তৈরি করে না']
]);
V.cmpCycNon = cmp('চক্রীয় বনাম অচক্রীয় ফটোফসফোরাইলেশন', 'সারিতে চাপ দিলে চিহ্নিত হয়; যাচাই খেলায় নিজেকে পরীক্ষা করো।', 'চক্রীয়', 'অচক্রীয়', [
  ['ফটোসিস্টেম', 'শুধু PS-I', 'PS-I ও PS-II দুটোই'],
  ['ইলেকট্রনের পথ', 'চক্রাকার — P700 থেকে বেরিয়ে আবার P700 তে ফেরে', 'একমুখী — পানি থেকে NADP<sup>+</sup> পর্যন্ত'],
  ['ইলেকট্রনের উৎস', 'P700 নিজেই', 'পানি'],
  ['শেষ ইলেকট্রন গ্রাহক', 'P700', 'NADP<sup>+</sup>'],
  ['পানির সালোকবিভাজন ও O<sub>2</sub>', 'হয় না', 'হয়, O<sub>2</sub> নির্গত হয়'],
  ['উৎপাদ', 'শুধু ATP', 'ATP, NADPH ও O<sub>2</sub>'],
  ['আলোর তরঙ্গদৈর্ঘ্য', '680 nm এর বেশি (দূর-লাল) আলোতেও চলে', '680 nm বা কম দৈর্ঘ্যের আলো লাগে'],
  ['কখন', 'NADP<sup>+</sup> কম বা বাড়তি ATP দরকার হলে; কিছু ব্যাকটেরিয়ায়', 'সবুজ উদ্ভিদে সাধারণ অবস্থায়']
]);
V.cmpLightDark = cmp('আলোকনির্ভর বনাম আলোক নিরপেক্ষ পর্যায়', 'সারিতে চাপ দিলে চিহ্নিত হয়।', 'আলোকনির্ভর পর্যায়', 'আলোক নিরপেক্ষ পর্যায়', [
  ['আলো', 'সরাসরি প্রয়োজন', 'সরাসরি প্রয়োজন নেই (আলোর উৎপাদ লাগে)'],
  ['স্থান', 'থাইলাকয়েড ঝিল্লি (গ্রানা)', 'স্ট্রোমা'],
  ['কাঁচামাল', 'পানি, ADP, Pi, NADP<sup>+</sup>', 'CO<sub>2</sub>, ATP, NADPH, RuBP'],
  ['উৎপাদ', 'ATP, NADPH, O<sub>2</sub>', 'শর্করা (G3P), ADP, Pi, NADP<sup>+</sup>'],
  ['প্রধান ঘটনা', 'আলো শোষণ, পানির সালোকবিভাজন, ফটোফসফোরাইলেশন', 'CO<sub>2</sub> সংবন্ধন, বিজারণ, RuBP পুনর্গঠন'],
  ['শক্তির রূপান্তর', 'আলোক শক্তি → রাসায়নিক শক্তি (ATP, NADPH)', 'ATP-NADPH এর শক্তি → শর্করার রাসায়নিক বন্ধন'],
  ['তাপমাত্রার প্রভাব', 'কম (আলোক রাসায়নিক)', 'বেশি (এনজাইম-নির্ভর)'],
  ['আবিষ্কার/নাম', 'হিল বিক্রিয়া (1937)', 'ক্যালভিন চক্র (ক্যালভিন, বেনসন, বাশাম)']
]);
V.cmpPRResp = cmp('আলোকশ্বসন বনাম শ্বসন', 'নামে "শ্বসন" হলেও আলোকশ্বসন শক্তি দেয় না — উল্টো শক্তি খরচ করে।', 'আলোকশ্বসন', 'শ্বসন (সবাত)', [
  ['আলো', 'শুধু আলোতে হয়', 'আলো-অন্ধকার সবসময়'],
  ['কোষ', 'শুধু সবুজ কোষে (C3 উদ্ভিদে বেশি)', 'সব জীবিত কোষে'],
  ['অঙ্গাণু', 'ক্লোরোপ্লাস্ট, পারঅক্সিজোম ও মাইটোকন্ড্রিয়া', 'সাইটোপ্লাজম ও মাইটোকন্ড্রিয়া'],
  ['উপাদান (সাবস্ট্রেট)', 'RuBP থেকে তৈরি গ্লাইকোলেট', 'গ্লুকোজ ইত্যাদি শর্করা, চর্বি, প্রোটিন'],
  ['এনজাইম', 'RuBisCO এর অক্সিজিনেজ ক্রিয়া', 'গ্লাইকোলাইসিস ও ক্রেবস চক্রের এনজাইম'],
  ['ATP', 'তৈরি হয় না, বরং খরচ হয়', '38 ATP (পাঠ্যবই) বা প্রায় 30–32 ATP'],
  ['H<sub>2</sub>O<sub>2</sub>', 'তৈরি হয় (পারঅক্সিজোমে)', 'তৈরি হয় না'],
  ['ফল', 'সংবন্ধিত কার্বনের অপচয়, ফলন কমে', 'শক্তি সরবরাহ — জীবনের জন্য অপরিহার্য']
]);
V.cmpC3C4 = cmp('C3 উদ্ভিদ বনাম C4 উদ্ভিদ', 'সারিতে চাপ দিলে চিহ্নিত হয়; যাচাই খেলায় নিজেকে পরীক্ষা করো।', 'C3 উদ্ভিদ', 'C4 উদ্ভিদ', [
  ['প্রথম স্থায়ী যৌগ', '3-ফসফোগ্লিসারিক অ্যাসিড (3C)', 'অক্সালো-অ্যাসিটিক অ্যাসিড (4C)'],
  ['প্রাথমিক CO<sub>2</sub> গ্রাহক', 'RuBP (5C)', 'PEP (3C)'],
  ['সংবন্ধক এনজাইম', 'RuBisCO', 'মেসোফিলে PEPCase, বান্ডল শিথে RuBisCO'],
  ['ক্র্যাঞ্জ অঙ্গসংস্থান', 'নেই', 'আছে'],
  ['ক্লোরোপ্লাস্ট', 'একরূপ', 'দ্বিরূপ (মেসোফিল ও বান্ডল শিথে আলাদা)'],
  ['আলোকশ্বসন', 'বেশি', 'প্রায় নেই'],
  ['CO<sub>2</sub> পূরণ বিন্দু', 'বেশি — প্রায় 40–100 ppm', 'খুব কম — প্রায় 0–10 ppm'],
  ['অনুকূল তাপমাত্রা', 'প্রায় 15–25 °C', 'প্রায় 30–40 °C'],
  ['প্রতি CO<sub>2</sub> এ শক্তি', '3 ATP + 2 NADPH', '5 ATP + 2 NADPH'],
  ['উৎপাদনশীলতা', 'কম (উষ্ণ-উজ্জ্বল পরিবেশে)', 'বেশি'],
  ['উদাহরণ', 'ধান, গম, আলু, সয়াবিন, আম', 'ভুট্টা, আখ, জোয়ার, মুথা ঘাস, অ্যামারান্থাস']
]);
V.cmpCalvinHS = cmp('ক্যালভিন চক্র বনাম হ্যাচ-স্ল্যাক চক্র', 'C4 উদ্ভিদে দুটিই চলে — দুই আলাদা কোষে।', 'ক্যালভিন চক্র (C3)', 'হ্যাচ-স্ল্যাক চক্র (C4)', [
  ['উদ্ভিদ', 'সব সবুজ উদ্ভিদে', 'শুধু C4 উদ্ভিদে'],
  ['কোষ', 'C3 তে মেসোফিল; C4 তে বান্ডল শিথ', 'মেসোফিল ও বান্ডল শিথ দুটিতে মিলে'],
  ['CO<sub>2</sub> গ্রাহক', 'RuBP', 'PEP'],
  ['প্রথম স্থায়ী যৌগ', '3-PGA (3C)', 'OAA (4C)'],
  ['এনজাইম', 'RuBisCO', 'PEPCase, ম্যালিক এনজাইম, পাইরুভেট ফসফেট ডাইকাইনেজ'],
  ['O<sub>2</sub> এর প্রভাব', 'O<sub>2</sub> RuBisCO-র সাথে প্রতিযোগিতা করে (আলোকশ্বসন)', 'PEPCase O<sub>2</sub> দ্বারা বাধাগ্রস্ত হয় না'],
  ['কাজ', 'শর্করা তৈরি', 'CO<sub>2</sub> সংগ্রহ ও ঘনীভূত করা (শর্করা তৈরি করে না)'],
  ['আবিষ্কারক', 'মেলভিন ক্যালভিন ও সহকর্মীরা (নোবেল 1961)', 'হ্যাচ ও স্ল্যাক (1966)']
]);
})();
