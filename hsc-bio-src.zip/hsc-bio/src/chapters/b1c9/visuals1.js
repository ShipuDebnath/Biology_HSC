/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৯.১ খনিজ লবণ ও পানি পরিশোষণ, §৯.২ প্রস্বেদন
   B9 সহায়ক: seg (ধরন বদলানো চিত্র + ঐচ্ছিক স্লাইডার + চাপ দিলে তথ্য), gseg (লেখচিত্র-ধরন),
              ch / chH (রাসায়নিক সংকেত: "NO_3^-" → SVG tspan / HTML sub-sup — ইউনিকোড সাবস্ক্রিপ্ট নয়),
              axes, curve, along (রেখা বরাবর বিন্দু), ion, blob
   nutrients    : ১৭টি অত্যাবশ্যকীয় উপাদান — গৃহীত রূপ, কাজ, অভাবের লক্ষণ (পাতায় আঁকা), চলনশীলতা
   soilPH       : মাটির pH ও পুষ্টি উপাদানের প্রাপ্যতা (স্লাইডার)
   ionExch      : কলয়েড মাইসেল, সংস্পর্শ বিনিময় ও কার্বনিক অ্যাসিড বিনিময়
   uptake       : নিষ্ক্রিয় (গণপ্রবাহ, ব্যাপন, আয়ন বিনিময়, ডোনান) ও সক্রিয় (বাহক, সাইটোক্রোম পাম্প) পরিশোষণ
   carrierSteps : বাহক মতবাদ — ধাপে ধাপে
   waterPath    : মূলে পানির পথ — অ্যাপোপ্লাস্ট, সিমপ্লাস্ট, ট্রান্সমেমব্রেন; ক্যাসপেরিয়ান ফিতা
   ascent       : রসের ঊর্ধ্বগমন — সংসক্তি-টান (পানিবিভব, RH স্লাইডার), মূলচাপ, কৈশিকতা
   upFactors    : খনিজ পরিশোষণের প্রভাবক (লেখচিত্র)
   transpTypes  : পত্ররন্ধ্রীয়, কিউটিকুলার ও লেন্টিকুলার প্রস্বেদন
   stomaMech    : রক্ষীকোষ খোলা-বন্ধ — K+ পাম্প, শ্বেতসার-শর্করা, ABA (দিনের সময় স্লাইডার)
   transpFactors: প্রস্বেদনের প্রভাবক (লেখচিত্র)      potometer : গ্যানংয়ের পটোমিটার
   stomaPeel    : ব্যবহারিক — পত্ররন্ধ্র পর্যবেক্ষণ      transpImp : প্রস্বেদনের গুরুত্ব
   cmpActPass, cmpWaterMin, cmpStomaCut, cmpStromaStoma, cmpTranspEvap : তুলনা
   রঙের নিয়ম (পুরো অধ্যায়ে এক): পানি = ৫ আকাশি, খনিজ আয়ন = ২ কমলা, H+ = ৪ লাল, ATP/শক্তি = ৬ অ্যাম্বার,
   ক্লোরোফিল/পাতা = ১০ সবুজ, শর্করা = ৭ লাইম, CO2 = ৯ স্লেট, O2 = ০ টিল, NADPH/NADH = ৩ বেগুনি
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B9 = window.B9 = {};
const PI = Math.PI;
const bn = B9.bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const rnd = B9.rnd = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
const cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
B9.cl = cl;

/* রাসায়নিক সংকেত */
const tok = s => { const out = [], re = /_\{([^}]*)\}|_(\d+)|\^\{([^}]*)\}|\^(\d*[+\-−])/g; let i = 0, m; while ((m = re.exec(s))) { if (m.index > i) out.push([s.slice(i, m.index), 0]); if (m[1] != null || m[2] != null) out.push([m[1] != null ? m[1] : m[2], 1]); else out.push([(m[3] != null ? m[3] : m[4]).replace('-', '−'), 2]); i = re.lastIndex; } if (i < s.length) out.push([s.slice(i), 0]); return out; };
B9.ch = s => { let off = 0; return tok(s).map(([t, l]) => { const o = l === 1 ? 3.5 : l === 2 ? -5 : 0, dy = o - off; off = o; return `<tspan dy="${dy}"${l ? ' font-size="72%"' : ''}>${t}</tspan>`; }).join(''); };
B9.chH = s => tok(s).map(([t, l]) => l === 1 ? `<sub>${t}</sub>` : l === 2 ? `<sup>${t}</sup>` : t).join('');
const ch = B9.ch, chH = B9.chH;

/* ধরন বদলানো চিত্র
   o: { id, t, k?, cap, W?, H? (সংখ্যা বা ty→সংখ্যা), types:{key:[বোতাম, শিরোনাম, বর্ণনা, নোট?]}, def,
        sl?:[{k,l,min,max,step,val,unit,d}], art(g,C,ty,ctx), anim?(g,C,ty,t,ctx), tap?(x,y,ty,ctx)→html, more?(ty,ctx)→html } */
B9.seg = o => ({
  t: o.t, k: o.k || ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `${Object.keys(o.types).length > 1 ? `<div class="fk-row">${X.seg(o.id, Object.keys(o.types).map(k => [k, o.types[k][0]]), o.def)}</div>` : ''}<div class="fk-stage bk-stage" data-k="st"></div>${(o.sl || []).map(s => `<div class="fk-row">${FK.sl(s.k, s.l, s.min, s.max, s.step, s.val, s.unit || '')}</div>`).join('')}<div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = o.W || 360;
    let ty = o.def, C, svg, ga, gd, tt = 0;
    const ctx = { root, v: {}, sel: o.sel != null ? o.sel : null };
    (o.sl || []).forEach(s => { ctx.v[s.k] = s.val; });
    const defInfo = () => { const a = o.types[ty]; return `<b>${a[1] || a[0]}</b> — ${a[2]}${a[3] ? `<div class="small">${a[3]}</div>` : ''}${o.more ? o.more(ty, ctx) || '' : ''}`; };
    const info = h => { $('info').innerHTML = h; };
    const frame = () => { gd.innerHTML = ''; if (o.anim) o.anim(gd, C, ty, tt, ctx); };
    const redraw = () => { ga.innerHTML = ''; o.art(ga, C, ty, ctx); frame(); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const h = typeof o.H === 'function' ? o.H(ty) : (o.H || 260);
      svg = E('svg', { viewBox: `0 0 ${W} ${h}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.types[ty][1] || o.types[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: h, rx: 12, fill: C.sf }, svg);
      ga = E('g', {}, svg); gd = E('g', { style: 'pointer-events:none' }, svg); ctx.svg = svg; ctx.C = C;
      redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo());
    };
    ctx.info = info; ctx.redraw = redraw; ctx.def = defInfo;
    root.addEventListener('click', e => {
      if (!o.tap || !svg || !svg.contains(e.target)) return;
      const m = svg.getScreenCTM(); if (!m) return; const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const q = p.matrixTransform(m.inverse());
      const h = o.tap(q.x, q.y, ty, ctx); if (h) info(h); redraw();
    });
    (o.sl || []).forEach(s => FK.bindSl(root, s.k, v => { ctx.v[s.k] = v; redraw(); info(ctx.selInfo ? ctx.selInfo() : defInfo()); }, s.unit || '', s.d != null ? s.d : 0));
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, o.id, v => { ty = v; tt = 0; ctx.sel = o.sel != null ? o.sel : null; ctx.selInfo = null; base(); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* অক্ষ: b = [x, y, w, h]; o = { xr, yr, lx, ly, xt, yt, xf } → P(u, v) */
B9.axes = (g, C, b, o) => {
  const [x, y, w, h] = b, xr = o.xr, yr = o.yr, P = (u, v) => [x + (u - xr[0]) / (xr[1] - xr[0]) * w, y + h - (v - yr[0]) / (yr[1] - yr[0]) * h];
  (o.yt || []).forEach(t => { const [, py] = P(xr[0], t); E('path', { d: `M${x} ${py}H${x + w}`, stroke: C.ln, 'stroke-width': .6, opacity: .45 }, g); T(g, x - 5, py + 3.5, o.yf ? o.yf(t) : String(t), { fs: 9.5, a: 'end', c: C.mu }); });
  (o.xt || []).forEach(t => { const [px] = P(t, yr[0]); E('path', { d: `M${px} ${y + h}v4`, stroke: C.mu, 'stroke-width': 1 }, g); T(g, px, y + h + 14, o.xf ? o.xf(t) : String(t), { fs: 9.5, a: 'middle', c: C.mu }); });
  E('path', { d: `M${x} ${y - 6}V${y + h}H${x + w + 6}`, stroke: C.fg, 'stroke-width': 1.3, fill: 'none' }, g);
  E('path', { d: `M${x} ${y - 10}l-3.5 7h7z`, fill: C.fg }, g); E('path', { d: `M${x + w + 10} ${y + h}l-7 -3.5v7z`, fill: C.fg }, g);
  if (o.lx) T(g, x + w + 8, y + h + 28, o.lx, { fs: 10.5, a: 'end', c: C.mu });
  if (o.ly) T(g, x + 6, y - 4, o.ly, { fs: 10.5, c: C.mu });
  return P;
};
B9.curve = (g, P, f, a, b, at, n = 64) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } return E('path', Object.assign({ d, fill: 'none', 'stroke-width': 2.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, at), g); };
B9.area = (g, P, f, a, b, y0, at, n = 48) => { let d = ''; for (let i = 0; i <= n; i++) { const u = a + (b - a) * i / n, [px, py] = P(u, f(u)); d += (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); } const [xb] = P(b, y0), [xa, ya] = P(a, y0); d += `L${xb} ${ya}L${xa} ${ya}Z`; return E('path', Object.assign({ d, stroke: 'none' }, at), g); };
/* রেখা বরাবর u (০→১) অবস্থানের বিন্দু */
B9.along = (pts, u) => {
  let L = 0; const sg = [];
  for (let i = 1; i < pts.length; i++) { const l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); sg.push(l); L += l; }
  let d = (((u % 1) + 1) % 1) * L;
  for (let i = 0; i < sg.length; i++) { if (d <= sg[i]) { const k = sg[i] ? d / sg[i] : 0; return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * k, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * k]; } d -= sg[i]; }
  return pts[pts.length - 1];
};
B9.poly = (g, pts, at) => E('path', Object.assign({ d: pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(''), fill: 'none' }, at), g);
/* আয়ন বা অণুর বল */
B9.ion = (g, x, y, s, R, r = 10, o = {}) => { E('circle', { cx: x, cy: y, r, fill: o.fill || R.lt, stroke: R.dk, 'stroke-width': 1.1, opacity: o.op != null ? o.op : 1 }, g); T(g, x, y + 3.2, ch(s), { fs: o.fs || 8.5, a: 'middle', w: 650, c: R.ink }); };
B9.dot = (g, x, y, r, c, op = 1) => E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r, fill: c, opacity: op }, g);
B9.blob = (g, x, y, r, o = {}) => {
  const n = o.n || 7, sd = o.seed || 1; let d = '';
  for (let i = 0; i <= n; i++) { const a = i / n * PI * 2 + (o.rot || 0), rr = r * (1 + (rnd(sd * 31 + (i % n)) - .5) * (o.j != null ? o.j : .16)); d += (i ? 'L' : 'M') + (x + rr * Math.cos(a)).toFixed(1) + ' ' + (y + rr * Math.sin(a)).toFixed(1); }
  return E('path', { d: d + 'Z', fill: o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || 1, 'stroke-linejoin': 'round' }, g);
};
/* লেবেল রেখা ও লেখা */
B9.lab = (g, ax, ay, lx, ly, s, C, o = {}) => {
  E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': .9, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2, fill: C.fg }, g);
  const an = o.a || (lx < ax ? 'end' : 'start'); T(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 4, s, { fs: o.fs || 11, a: an, w: 560, c: o.c || C.fg });
};
/* চিপ (গোল কোণের লেবেল) */
B9.chip = (g, x, y, s, R, o = {}) => { const w = o.w || 60, h = o.h || 18; E('rect', { x: x - (o.a === 'start' ? 0 : w / 2), y: y - h / 2, width: w, height: h, rx: h / 2, fill: o.fill || FK.alpha(R.c, .16), stroke: R.c, 'stroke-width': 1 }, g); T(g, x + (o.a === 'start' ? w / 2 : 0), y + 4, s, { fs: o.fs || 10, a: 'middle', w: 600, c: R.ink }); };
/* ঝিল্লি (দ্বিস্তরী লিপিড) — অনুভূমিক */
B9.mem = (g, C, x0, x1, y, o = {}) => {
  const R = o.R || BK.ramp(2), sp = o.sp || 9, gaps = o.gaps || [];
  E('rect', { x: x0, y: y - 8, width: x1 - x0, height: 16, fill: FK.alpha(R.c, .14) }, g);
  let d = '';
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; d += `M${x.toFixed(1)} ${y - 5}v3.2M${x.toFixed(1)} ${y + 1.8}v3.2`; }
  E('path', { d, stroke: R.dk, 'stroke-width': 1, opacity: .55 }, g);
  for (let x = x0 + sp / 2; x < x1; x += sp) { if (gaps.some(([a, b]) => x > a && x < b)) continue; E('circle', { cx: x, cy: y - 7, r: 3, fill: R.c }, g); E('circle', { cx: x, cy: y + 7, r: 3, fill: R.c }, g); }
};

/* লেখচিত্র-ধরন: o.types[k] = { b, t, d, f, xr, xt, lx, ly, read?(x) → নোট, mk?:[[x, লেখা]] } */
B9.gseg = o => {
  const ty = {}; Object.keys(o.types).forEach(k => { const G = o.types[k]; ty[k] = [G.b, G.t, G.d]; });
  const box = [46, 34, 284, 160];
  return B9.seg({
    id: o.id, t: o.t, cap: o.cap, k: ['graph', 'anim', 'int'], H: 236, def: o.def, types: ty,
    art(g, C, k, ctx) {
      const G = o.types[k], R = BK.ramp(G.c != null ? G.c : 0);
      const P = B9.axes(g, C, box, { xr: G.xr, yr: [0, 1.08], lx: G.lx, ly: G.ly || 'আপেক্ষিক হার', xt: G.xt, yt: [.5, 1], yf: v => v === 1 ? 'সর্বোচ্চ' : '' });
      ctx.P = P; ctx.G = G;
      B9.area(g, P, G.f, G.xr[0], G.xr[1], 0, { fill: FK.alpha(R.c, .13) });
      B9.curve(g, P, G.f, G.xr[0], G.xr[1], { stroke: R.c, 'stroke-width': 3 });
      (G.mk || []).forEach(([xv, s, up, an]) => { const [px, py] = P(xv, G.f(xv)); E('circle', { cx: px, cy: py, r: 3.2, fill: R.dk }, g); T(g, px + (an ? 7 : 0), py + (up ? -9 : 17), s, { fs: 9.8, a: an || 'middle', w: 560, c: R.ink }); });
      if (ctx.sel != null) { const [px, py] = P(ctx.sel, G.f(ctx.sel)), [, pb] = P(ctx.sel, 0), [pa] = P(G.xr[0], 0); E('path', { d: `M${px} ${pb}V${py}H${pa}`, stroke: C.mu, 'stroke-dasharray': '3 3', fill: 'none' }, g); E('circle', { cx: px, cy: py, r: 5, fill: R.c, stroke: C.sf, 'stroke-width': 2 }, g); }
    },
    anim(g, C, k, t, ctx) {
      const G = ctx.G, P = ctx.P; if (!G || !t) return; const R = BK.ramp(G.c != null ? G.c : 0), u = (1 - Math.cos(t * .7)) / 2, xv = G.xr[0] + u * (G.xr[1] - G.xr[0]), [px, py] = P(xv, G.f(xv));
      E('circle', { cx: px, cy: py, r: 9, fill: FK.alpha(R.c, .25) }, g); E('circle', { cx: px, cy: py, r: 4.5, fill: R.dk }, g);
    },
    tap(x, y, k, ctx) {
      const G = ctx.G; if (!G || x < box[0] - 4 || x > box[0] + box[2] + 4 || y > box[1] + box[3] + 6) return null;
      const xv = cl(G.xr[0] + (x - box[0]) / box[2] * (G.xr[1] - G.xr[0]), G.xr[0], G.xr[1]); ctx.sel = xv;
      const v = Math.round(G.f(xv) * 100);
      return `<b>${G.lx}: ${FK.n(xv, G.dp != null ? G.dp : 0)}${G.u || ''}</b> → আপেক্ষিক হার ≈ <b>${v}%</b> (সর্বোচ্চের তুলনায়)${G.read ? `<div class="small">${G.read(xv)}</div>` : ''}<div class="small muted">এটি প্রবণতা বোঝানোর লেখচিত্র — মান উদ্ভিদভেদে বদলায়।</div>`;
    }
  });
};

/* ═════════ ১. অত্যাবশ্যকীয় পুষ্টি উপাদান ═════════ */
/* [প্রতীক, বাংলা নাম, গৃহীত রূপ, মুখ্য?, চলনশীলতা (২ চলনশীল, ১ আংশিক, ০ অচলনশীল, −১ অখনিজ), লক্ষণ-কোড, কাজ, অভাবের লক্ষণ] */
const EL = [
  ['C', 'কার্বন', 'CO_2', 1, -1, 'none', 'সব জৈব যৌগের মূল কাঠামো — শর্করা, প্রোটিন, লিপিড, নিউক্লিক অ্যাসিড।', 'বাতাসের CO<sub>2</sub> থেকে আসে, তাই মাঠে ঘাটতি সাধারণত হয় না; CO<sub>2</sub> কমলে সালোকসংশ্লেষণ কমে।'],
  ['H', 'হাইড্রোজেন', 'H_2O', 1, -1, 'none', 'সব জৈব যৌগে; পানির সালোকবিভাজনে H<sup>+</sup> ও ইলেকট্রন যোগায়।', 'পানি থেকে আসে — পানির অভাবে ঢলে পড়া।'],
  ['O', 'অক্সিজেন', 'O_2, H_2O, CO_2', 1, -1, 'none', 'জৈব যৌগে; সবাত শ্বসনে শেষ ইলেকট্রন গ্রাহক।', 'জলাবদ্ধ মাটিতে মূলের O<sub>2</sub> কমলে শ্বসন ও খনিজ পরিশোষণ কমে।'],
  ['N', 'নাইট্রোজেন', 'NO_3^-, NH_4^+', 1, 2, 'oldY', 'অ্যামিনো অ্যাসিড, প্রোটিন, নিউক্লিক অ্যাসিড, ক্লোরোফিল, ATP, NAD ও কো-এনজাইমের উপাদান।', 'পুরোনো পাতা আগে সম্পূর্ণ হলদে (ক্লোরোসিস); বৃদ্ধি কম, গাছ খর্বাকার, ফলন কম।'],
  ['P', 'ফসফরাস', 'H_2PO_4^-, HPO_4^{2-}', 1, 2, 'oldP', 'ATP, NADP, নিউক্লিক অ্যাসিড ও ফসফোলিপিডের উপাদান — শক্তি স্থানান্তর ও ফসফোরাইলেশন।', 'পুরোনো পাতা গাঢ় সবুজ থেকে বেগুনি-লালচে (অ্যান্থোসায়ানিন জমে); মূলের বৃদ্ধি কম, ফসল দেরিতে পাকে।'],
  ['K', 'পটাশিয়াম', 'K^+', 1, 2, 'oldM', 'বহু এনজাইম সক্রিয় করে; রক্ষীকোষে K<sup>+</sup> ঢুকে পত্ররন্ধ্র খোলে; কোষের অভিস্রবণ চাপ ও প্রোটিন সংশ্লেষ।', 'পুরোনো পাতার কিনারা ও অগ্রভাগ হলদে থেকে বাদামি হয়ে পোড়ার মতো শুকায় (মার্জিনাল নেক্রোসিস); কাণ্ড দুর্বল।'],
  ['Ca', 'ক্যালসিয়াম', 'Ca^{2+}', 1, 0, 'tip', 'মধ্যপর্দায় ক্যালসিয়াম পেকটেট; মাকুতন্ত্র গঠন, ঝিল্লির স্থায়িত্ব; কোষে সংকেত বাহক।', 'কচি পাতা ও শীর্ষ মুকুল বিকৃত হয়ে মরে যায়, পাতার অগ্রভাগ বাঁকা; টমেটোর ব্লসম-এন্ড রট।'],
  ['Mg', 'ম্যাগনেসিয়াম', 'Mg^{2+}', 1, 2, 'oldIV', 'ক্লোরোফিল অণুর কেন্দ্রীয় পরমাণু; ATP-নির্ভর বহু এনজাইম ও RuBisCO সক্রিয় করে; রাইবোজোমের উপএকক জোড়া রাখে।', 'পুরোনো পাতায় শিরা সবুজ থাকে কিন্তু শিরার মাঝের অংশ হলদে (আন্তঃশিরা ক্লোরোসিস)।'],
  ['S', 'সালফার', 'SO_4^{2-}', 1, 1, 'youngY', 'সিস্টেইন ও মিথিওনিন অ্যামিনো অ্যাসিড, কো-এনজাইম A, বায়োটিন, থায়ামিন ও ফেরেডক্সিনের উপাদান।', 'কচি পাতা আগে সম্পূর্ণ হলদে (N-এর মতো, তবে কচি পাতায়); কাণ্ড সরু ও শক্ত।'],
  ['Fe', 'আয়রন', 'Fe^{2+}, Fe^{3+}', 0, 0, 'youngIV', 'সাইটোক্রোম ও ফেরেডক্সিনে ইলেকট্রন বাহক; ক্লোরোফিল সংশ্লেষে লাগে (তবে ক্লোরোফিলের উপাদান নয়)।', 'কচি পাতায় আন্তঃশিরা ক্লোরোসিস — শিরা সবুজ, মাঝে হলদে-সাদা; চুনযুক্ত ক্ষারীয় মাটিতে বেশি দেখা যায়।'],
  ['Mn', 'ম্যাঙ্গানিজ', 'Mn^{2+}', 0, 0, 'spot', 'পানির সালোকবিভাজনে (PS-II এর অক্সিজেন-নিঃসরণকারী জটিলে) অপরিহার্য; ক্রেবস চক্রের কিছু এনজাইম সক্রিয় করে।', 'কচি পাতায় আন্তঃশিরা ক্লোরোসিস ও ধূসর-বাদামি মৃত দাগ (ওটের গ্রে স্পেক)।'],
  ['Zn', 'জিংক', 'Zn^{2+}', 0, 0, 'little', 'অক্সিনের পূর্বসূরি ট্রিপটোফ্যান সংশ্লেষে লাগে; কার্বনিক অ্যানহাইড্রেজ ও অ্যালকোহল ডিহাইড্রোজিনেজ এনজাইমে থাকে।', 'পাতা ছোট (লিটল লিফ), পর্বমধ্য খাটো হয়ে পাতা গুচ্ছাকার (রোজেটিং); ধানের খয়রা রোগ — বাংলাদেশে পরিচিত।'],
  ['Cu', 'কপার', 'Cu^{2+}', 0, 0, 'tip', 'প্লাস্টোসায়ানিন (সালোকসংশ্লেষণের ইলেকট্রন বাহক) ও সাইটোক্রোম অক্সিডেজের উপাদান।', 'কচি পাতা নীলচে-সবুজ হয়ে কুঁকড়ে যায়, শীর্ষ শুকিয়ে মরে (ডাইব্যাক); লেবুর এক্সানথেমা।'],
  ['B', 'বোরন', 'H_3BO_3', 0, 0, 'tip', 'পরাগরেণুর অঙ্কুরোদগম ও পরাগনালির বৃদ্ধি, Ca এর ব্যবহার, শর্করা পরিবহন ও কোষবিভাজন।', 'শীর্ষ মুকুল মরে যায়; বিটের হার্ট রট, ফুলকপির ফাঁপা কাণ্ড ও বাদামি দাগ; ফুল-ফল ঝরে পড়ে।'],
  ['Mo', 'মলিবডেনাম', 'MoO_4^{2-}', 0, 1, 'whip', 'নাইট্রেট রিডাক্টেজ ও নাইট্রোজিনেজ এনজাইমের উপাদান — নাইট্রেট বিজারণ ও N<sub>2</sub> সংবন্ধন।', 'পাতার ফলক সরু হয়ে চাবুকের মতো (ফুলকপির হুইপটেইল); পুরোনো পাতায় N-ঘাটতির মতো হলদেভাব।'],
  ['Cl', 'ক্লোরিন', 'Cl^-', 0, 2, 'wilt', 'পানির সালোকবিভাজনে সহায়ক; কোষে আয়ন ও অভিস্রবণ ভারসাম্য; রক্ষীকোষে K<sup>+</sup> এর সঙ্গী অ্যানায়ন।', 'পাতা ঢলে পড়ে, ব্রোঞ্জের মতো রং হয়; মূল খাটো ও মোটা। মাঠে ঘাটতি বিরল।'],
  ['Ni', 'নিকেল', 'Ni^{2+}', 0, 1, 'tipNec', 'ইউরিয়েজ এনজাইমের উপাদান — ইউরিয়া ভেঙে অ্যামোনিয়া তৈরি করে (1987 সালে অত্যাবশ্যকীয় হিসেবে স্বীকৃত)।', 'পাতার অগ্রভাগে ইউরিয়া জমে মৃত দাগ; পিকান গাছের "মাউস-ইয়ার"।']
];
const ELpos = EL.map((e, i) => i < 9 ? [6 + i * 39, 26] : [25.5 + (i - 9) * 39, 92]);
const mobTxt = m => m === 2 ? 'চলনশীল — লক্ষণ আগে পুরোনো পাতায়' : m === 1 ? 'আংশিক চলনশীল' : m === 0 ? 'অচলনশীল — লক্ষণ আগে কচি পাতায়' : 'বাতাস ও পানি থেকে আসে';
const leafP = (g, x, y, ang, L, w, fill, vein, o = {}) => {
  const lg = E('g', { transform: `translate(${x} ${y}) rotate(${ang})` }, g);
  E('path', { d: `M0 0Q${L * .35} ${-w} ${L} 0Q${L * .35} ${w} 0 0Z`, fill, stroke: o.edge || vein, 'stroke-width': o.ew || 1 }, lg);
  let d = `M0 0L${L * .96} 0`; for (let k = 1; k <= 3; k++) { const x0 = L * k / 4.6; d += `M${x0} 0l${L * .17} ${-w * .52}M${x0} 0l${L * .17} ${w * .52}`; }
  E('path', { d, stroke: vein, 'stroke-width': o.vw || .9, fill: 'none', 'stroke-linecap': 'round' }, lg);
  if (o.tipC) E('path', { d: `M${L * .78} ${-w * .28}Q${L * .9} 0 ${L * .78} ${w * .28}L${L} 0Z`, fill: o.tipC }, lg);
  if (o.spots) for (let k = 0; k < 4; k++) E('circle', { cx: L * (.3 + k * .15), cy: (k % 2 ? 1 : -1) * w * .28, r: 1.8, fill: o.spots }, lg);
};
V.nutrients = Object.assign({}, B9.seg({
  id: 'nut', t: 'উদ্ভিদের ১৭টি অত্যাবশ্যকীয় পুষ্টি উপাদান', k: ['2d', 'anim', 'int'], H: 300, def: 'ess', sel: 3,
  cap: 'উপরের ঘরগুলোতে চাপ দিলে উপাদানটির গৃহীত রূপ, কাজ ও অভাবের লক্ষণ দেখাবে; নিচের গাছে সেই লক্ষণ আঁকা হবে। চালালে দেখা যায় — চলনশীল উপাদান পুরোনো পাতা থেকে কচি পাতায় সরে যায়, তাই অভাবের লক্ষণ আগে পুরোনো পাতায়।',
  types: { ess: ['মুখ্য ও গৌণ', 'মুখ্য ও গৌণ উপাদান', 'প্রয়োজনের পরিমাণ অনুযায়ী ৯টি মুখ্য (ম্যাক্রো) ও ৮টি গৌণ (মাইক্রো) উপাদান। C, H, O আসে বাতাস ও পানি থেকে; বাকি ১৪টি মাটি থেকে খনিজ লবণ (আয়ন) হিসেবে।'], mob: ['চলনশীলতা', 'চলনশীল ও অচলনশীল উপাদান', 'ফ্লোয়েমে সহজে চলাচল করতে পারা উপাদান (N, P, K, Mg, Cl) অভাবের সময় পুরোনো পাতা থেকে কচি পাতায় সরে যায় — তাই লক্ষণ আগে পুরোনো পাতায়। অচলনশীল উপাদানের (Ca, Fe, B, Cu, Mn, Zn) লক্ষণ আগে কচি পাতা ও শীর্ষে।'] },
  art(g, C, ty, ctx) {
    if (ctx.sel == null) ctx.sel = 3;
    const sel = ctx.sel, e = EL[sel];
    const tc = x => ty === 'ess' ? (x[4] < 0 ? BK.ramp(9) : x[3] ? BK.ramp(10) : BK.ramp(5)) : (x[4] < 0 ? BK.ramp(9) : x[4] === 2 ? BK.ramp(2) : x[4] === 1 ? BK.ramp(6) : BK.ramp(3));
    T(g, 6, 18, 'মুখ্য (ম্যাক্রো) উপাদান — ৯টি', { fs: 11, w: 560, c: C.mu }); T(g, 25, 84, 'গৌণ (মাইক্রো) উপাদান — ৮টি', { fs: 11, w: 560, c: C.mu });
    EL.forEach((x, i) => {
      const [px, py] = ELpos[i], R = tc(x), on = i === sel;
      E('rect', { x: px, y: py, width: 36, height: 40, rx: 7, fill: on ? R.c : FK.alpha(R.c, .17), stroke: on ? R.dk : FK.alpha(R.c, .7), 'stroke-width': on ? 2 : 1 }, g);
      T(g, px + 18, py + 19, x[0], { fs: 15, a: 'middle', w: 650, c: on ? '#fff' : R.ink, st: on ? 'stroke:none' : '' });
      T(g, px + 18, py + 33, ch(x[2].split(',')[0]), { fs: 7.6, a: 'middle', c: on ? '#fff' : C.mu, st: on ? 'stroke:none' : '' });
    });
    const lg = ty === 'ess' ? [[9, 'অখনিজ'], [10, 'মুখ্য'], [5, 'গৌণ']] : [[2, 'চলনশীল'], [6, 'আংশিক'], [3, 'অচলনশীল'], [9, 'অখনিজ']];
    lg.forEach(([r, s], i) => { const x0 = 10 + i * 86; E('rect', { x: x0, y: 140, width: 11, height: 11, rx: 3, fill: BK.ramp(r).c }, g); T(g, x0 + 16, 150, s, { fs: 10, c: C.fg }); });
    /* গাছ */
    const Gr = BK.ramp(10), Yl = BK.ramp(6), Pu = BK.ramp(3), Br = BK.ramp(2), sx = 100, s = e[5];
    E('rect', { x: 8, y: 284, width: 182, height: 12, rx: 4, fill: FK.alpha(BK.ramp(11).c, .45) }, g);
    E('path', { d: `M${sx} 286L${sx} 160`, stroke: Gr.dk, 'stroke-width': 4, 'stroke-linecap': 'round' }, g);
    const nodes = [[270, 54, 15, 'old'], [238, 50, 14, 'old'], [204, 40, 12, 'young'], [178, 28, 9, 'young']];
    nodes.forEach(([y, L, w, age]) => [[-1, 196], [1, -16]].forEach(([sd, ang]) => {
      let fill = Gr.c, vein = Gr.dk, o = {}, LL = L, ww = w, a = ang;
      const tgt = (age === 'old') === (s.indexOf('old') === 0);
      if (s === 'oldY' && age === 'old') { fill = Yl.lt; vein = Yl.c; }
      if (s === 'oldP' && age === 'old') { fill = FK.alpha(Pu.c, .75); vein = Pu.dk; }
      if (s === 'oldM' && age === 'old') { o.edge = Br.dk; o.ew = 3; fill = Gr.c; }
      if (s === 'oldIV' && age === 'old') { fill = Yl.lt; vein = Gr.dk; o.vw = 2.2; }
      if (s === 'youngY' && age === 'young') { fill = Yl.lt; vein = Yl.c; }
      if ((s === 'youngIV' || s === 'spot') && age === 'young') { fill = Yl.lt; vein = Gr.dk; o.vw = 2; if (s === 'spot') o.spots = Br.dk; }
      if (s === 'little' && age === 'young') { LL = L * .5; ww = w * .7; }
      if (s === 'whip' && age === 'young') { ww = w * .28; fill = FK.alpha(Yl.c, .7); }
      if (s === 'tip' && age === 'young') { o.tipC = Br.dk; a = ang + (sd < 0 ? -22 : 22); }
      if (s === 'tipNec') o.tipC = Br.dk;
      if (s === 'wilt') { a = ang + (sd < 0 ? -38 : 38); fill = FK.alpha(Br.c, .55); vein = Br.dk; }
      leafP(g, sx, y, a, LL, ww, fill, vein, o); void tgt;
    }));
    if (s === 'little') for (let k = 0; k < 4; k++) leafP(g, sx, 170, -150 + k * 40, 16, 6, Gr.c, Gr.dk);
    E('circle', { cx: sx, cy: 158, r: 5, fill: s === 'tip' ? Br.dk : Gr.lt, stroke: Gr.dk }, g);
    T(g, 6, 262, 'পুরোনো', { fs: 9.5, c: C.mu }); T(g, 6, 196, 'কচি', { fs: 9.5, c: C.mu });
    /* ডান প্যানেল */
    const R = tc(e);
    E('circle', { cx: 222, cy: 184, r: 24, fill: R.c, stroke: R.dk, 'stroke-width': 1.5 }, g);
    T(g, 222, 190, e[0], { fs: 19, a: 'middle', w: 650, c: '#fff', st: 'stroke:none' });
    T(g, 254, 180, e[1], { fs: 13.5, w: 600, c: R.ink }); T(g, 254, 198, ch(e[2].split(',')[0]) + (e[2].indexOf(',') > 0 ? ' …' : ''), { fs: 11, c: C.fg });
    T(g, 198, 230, e[3] ? 'মুখ্য পুষ্টি উপাদান' : 'গৌণ পুষ্টি উপাদান', { fs: 11, w: 560, c: C.fg });
    T(g, 198, 250, mobTxt(e[4]).split(' — ')[0], { fs: 11, w: 560, c: e[4] === 2 ? BK.ramp(2).ink : e[4] === 0 ? BK.ramp(3).ink : C.mu });
    if (mobTxt(e[4]).indexOf(' — ') > 0) T(g, 198, 266, mobTxt(e[4]).split(' — ')[1], { fs: 10, c: C.mu });
    T(g, 198, 284, 'ঘরে চাপ দিয়ে অন্যটি দেখো', { fs: 9.5, c: C.mu });
    ctx.selInfo = () => `<b>${e[0]} — ${e[1]}</b> · গৃহীত রূপ: ${e[2].split(', ').map(chH).join(', ')} · ${e[3] ? 'মুখ্য' : 'গৌণ'} · ${mobTxt(e[4])}<div class="small"><b>কাজ:</b> ${e[6]}</div><div class="small"><b>অভাব হলে:</b> ${e[7]}</div>`;
  },
  anim(g, C, ty, t, ctx) {
    if (!t) return; const e = EL[ctx.sel], m = e[4], sx = 100, R = BK.ramp(2);
    if (m < 0) { const Rc = BK.ramp(9); for (let i = 0; i < 4; i++) { const u = (t * .35 + i / 4) % 1; B9.dot(g, 40 + i * 40 - u * 10, 150 - 40 + u * 60, 3, Rc.c, 1 - u); } return; }
    if (m >= 1) for (let i = 0; i < (m === 2 ? 6 : 3); i++) { const u = (t * (m === 2 ? .32 : .16) + i / 6) % 1, side = i % 2 ? 1 : -1; const pts = [[sx + side * 34, 268], [sx, 262], [sx, 200], [sx + side * 26, 196]]; const [x, y] = B9.along(pts, u); B9.dot(g, x, y, 3.2, R.c, .9); }
    else for (let i = 0; i < 4; i++) { const side = i % 2 ? 1 : -1, x = sx + side * (24 + (i > 1 ? 14 : 0)), y = 266 - (i > 1 ? 32 : 0) + Math.sin(t * 6 + i) * 1.5; B9.dot(g, x + Math.sin(t * 5 + i * 2), y, 3.2, BK.ramp(3).c, .9); }
  },
  tap(x, y, ty, ctx) { for (let i = 0; i < EL.length; i++) { const [px, py] = ELpos[i]; if (x >= px && x <= px + 36 && y >= py && y <= py + 40) { ctx.sel = i; return null; } } return null; }
}));

/* ═════════ ২. মাটির pH ও প্রাপ্যতা ═════════ */
const sg = z => 1 / (1 + Math.exp(-z));
const bell = (a, b, s, lo) => x => lo + (1 - lo) * sg((x - a) / s) * sg((b - x) / s);
const PH = [
  ['N', bell(5.4, 8.3, .35, .22)], ['P', bell(6.0, 7.6, .3, .14)], ['K', bell(5.5, 11, .4, .25)], ['S', bell(5.5, 11, .4, .25)],
  ['Ca', bell(6.5, 11, .4, .14)], ['Mg', bell(6.5, 11, .4, .14)], ['Fe', bell(1, 6.6, .4, .12)], ['Mn', bell(1, 6.6, .4, .12)],
  ['B', x => Math.min(1, bell(5.0, 7.3, .35, .2)(x) + .45 * sg((x - 8.9) / .3))], ['Cu', bell(1, 7.0, .4, .14)], ['Zn', bell(1, 7.0, .4, .14)], ['Mo', bell(6.4, 13, .5, .18)]
];
const PHx = v => 50 + (v - 4) / 6 * 296;
V.soilPH = Object.assign({}, B9.seg({
  id: 'sph', t: 'মাটির pH ও পুষ্টি উপাদানের প্রাপ্যতা', k: ['graph', 'anim', 'int'], H: 300, def: 'a',
  cap: 'প্রতিটি পট্টির পুরুত্ব = ঐ pH-এ উপাদানটি মূলের জন্য কতটা সহজলভ্য (প্রবণতা)। স্লাইডারে pH বদলাও — বেশিরভাগ উপাদান pH 6–7 এ সবচেয়ে বেশি পাওয়া যায়; অম্লীয় মাটিতে P, Ca, Mg, Mo কমে, ক্ষারীয় মাটিতে Fe, Mn, Zn, Cu, B কমে।',
  types: { a: ['pH', 'মাটির pH ও প্রাপ্যতা', 'খনিজ লবণ মাটিতে থাকলেও pH ঠিক না হলে তা অদ্রবণীয় হয়ে যায় বা চুইয়ে চলে যায় — মূল নিতে পারে না।'] },
  sl: [{ k: 'ph', l: 'মাটির pH', min: 4, max: 10, step: .1, val: 6.5, d: 1 }],
  art(g, C, ty, ctx) {
    const ph = ctx.v.ph, y0 = 30, dy = 19;
    [[4, 5.5, 4, 'তীব্র অম্লীয়'], [6, 7, 10, 'উত্তম'], [7.5, 10, 5, 'ক্ষারীয়']].forEach(([a, b, r, s]) => { E('rect', { x: PHx(a), y: 20, width: PHx(b) - PHx(a), height: 240, fill: FK.alpha(BK.ramp(r).c, .09) }, g); T(g, (PHx(a) + PHx(b)) / 2, 16, s, { fs: 9.5, a: 'middle', c: BK.ramp(r).ink }); });
    PH.forEach(([s, f], i) => {
      const yc = y0 + i * dy, R = BK.ramp(i); let top = '', bot = '';
      for (let k = 0; k <= 40; k++) { const v = 4 + k * 6 / 40, th = 1.5 + 13 * f(v); top += (k ? 'L' : 'M') + PHx(v).toFixed(1) + ' ' + (yc - th / 2).toFixed(1); bot = 'L' + PHx(v).toFixed(1) + ' ' + (yc + th / 2).toFixed(1) + bot; }
      E('path', { d: top + bot + 'Z', fill: FK.alpha(R.c, .75), stroke: R.dk, 'stroke-width': .7 }, g);
      T(g, 40, yc + 4, s, { fs: 11.5, a: 'end', w: 600, c: R.ink });
    });
    for (let v = 4; v <= 10; v++) { E('path', { d: `M${PHx(v)} 258v5`, stroke: C.mu }, g); T(g, PHx(v), 276, String(v), { fs: 10, a: 'middle', c: C.mu }); }
    T(g, 348, 292, 'pH →', { fs: 10, a: 'end', c: C.mu });
    E('path', { d: `M${PHx(ph)} 20V262`, stroke: C.fg, 'stroke-width': 1.6, 'stroke-dasharray': '4 3' }, g);
    T(g, PHx(ph), 290, 'pH ' + FK.n(ph, 1), { fs: 10.5, a: 'middle', w: 650, c: C.fg });
  },
  more(ty, ctx) {
    const ph = ctx.v.ph, hi = PH.filter(([, f]) => f(ph) > .7).map(x => x[0]), lo = PH.filter(([, f]) => f(ph) < .35).map(x => x[0]);
    return `<div class="small">pH ${FK.n(ph, 1)}: সহজলভ্য — <b>${hi.join(', ') || '—'}</b>; কম পাওয়া যায় — <b>${lo.join(', ') || '—'}</b>।${ph < 5.5 ? ' অম্লীয় মাটিতে Al ও Fe ফসফেটকে অদ্রবণীয় করে; চুন প্রয়োগে pH বাড়ানো যায়।' : ph > 7.5 ? ' ক্ষারীয় মাটিতে Fe, Mn, Zn অদ্রবণীয় হাইড্রক্সাইড হয় — কচি পাতায় ক্লোরোসিস; জিপসাম বা জৈব সার উপকারী।' : ''}</div>`;
  },
  anim(g, C, ty, t, ctx) { if (!t) return; const ph = ctx.v.ph; PH.forEach(([, f], i) => { const yc = 30 + i * 19, v = f(ph), r = 2 + 4 * v * (0.8 + .2 * Math.sin(t * 4 + i)); E('circle', { cx: PHx(ph), cy: yc, r: r.toFixed(1), fill: BK.ramp(i).dk, opacity: .85 }, g); }); }
}));

/* ═════════ ৩. আয়ন বিনিময় ═════════ */
const CAT = [['K^+', 2], ['Ca^{2+}', 6], ['Mg^{2+}', 10], ['H^+', 4], ['NH_4^+', 7], ['Na^+', 9], ['K^+', 2], ['Ca^{2+}', 6]];
const minus = (g, x, y, c) => E('path', { d: `M${x - 3} ${y}h6`, stroke: c, 'stroke-width': 1.6 }, g);
const micelle = (g, C, cx, cy, rx, ry, n) => {
  const R = BK.ramp(11);
  E('ellipse', { cx, cy, rx, ry, fill: FK.alpha(R.c, .55), stroke: R.dk, 'stroke-width': 1.4 }, g);
  for (let i = 0; i < 6; i++) E('path', { d: `M${cx - rx * .7} ${cy - ry * .5 + i * ry * .2}H${cx + rx * .7}`, stroke: FK.alpha(R.dk, .35), 'stroke-width': 1 }, g);
  for (let i = 0; i < n; i++) { const a = i / n * PI * 2; minus(g, cx + (rx - 7) * Math.cos(a), cy + (ry - 7) * Math.sin(a), R.dk); }
  T(g, cx, cy + 4, 'কাদা কণা (মাইসেল)', { fs: 10.5, a: 'middle', w: 600, c: R.ink });
};
const rootHair = (g, C, x) => { const R = BK.ramp(10); E('path', { d: `M${x} 20Q${x - 18} 20 ${x - 18} 60V250H360V20Z`, fill: FK.alpha(R.c, .25), stroke: R.dk, 'stroke-width': 1.5 }, g); T(g, x + 30, 40, 'মূলরোম', { fs: 11, w: 600, c: R.ink }); T(g, x + 30, 55, '(কোষপ্রাচীর)', { fs: 9.5, c: C.mu }); };
V.ionExch = Object.assign({}, B9.seg({
  id: 'iex', t: 'মাটির কণায় আয়ন ও আয়ন বিনিময়', H: 260, def: 'clay',
  cap: 'কাদা ও হিউমাসের কণা (কলয়েড মাইসেল) ঋণাত্মক আধানযুক্ত — তাই K+, Ca2+, Mg2+, NH4+ এর মতো ক্যাটায়ন এর গায়ে আটকে থাকে, সহজে ধুয়ে যায় না। মূলরোম H+ ছেড়ে দিয়ে এই ক্যাটায়ন বদলে নেয় — সংস্পর্শ বিনিময় বা কার্বনিক অ্যাসিড বিনিময়ে। চালাও।',
  types: {
    clay: ['কলয়েড', 'কলয়েড মাইসেলে আয়ন', 'ক্যাটায়ন মাইসেলের গায়ে অধিশোষিত (adsorbed) থাকে — বিনিময়যোগ্য, তাই ধীরে ধীরে পাওয়া যায়। NO<sub>3</sub><sup>−</sup>, SO<sub>4</sub><sup>2−</sup> এর মতো অ্যানায়ন মুক্ত থাকে, বৃষ্টির পানিতে চুইয়ে নিচে চলে যায় (লিচিং) — তাই নাইট্রেট সার বারবার দিতে হয়।'],
    contact: ['সংস্পর্শ বিনিময়', 'সংস্পর্শ বিনিময় (Contact exchange)', 'জেনি ও ওভারস্ট্রিট (1939): মূলরোম ও কাদা কণা খুব কাছে থাকলে দুজনের গায়ে আটকানো আয়নের দোলনের পরিসর একে অপরের ওপর পড়ে। তখন মূলের H<sup>+</sup> কণায় যায়, কণার K<sup>+</sup> মূলে আসে — মাটির দ্রবণে না নেমেই।'],
    carb: ['কার্বনিক অ্যাসিড', 'কার্বনিক অ্যাসিড বিনিময়', 'মূলের শ্বসনে বের হওয়া CO<sub>2</sub> মাটির পানির সাথে মিশে H<sub>2</sub>CO<sub>3</sub> হয়, যা ভেঙে H<sup>+</sup> ও HCO<sub>3</sub><sup>−</sup> দেয়। H<sup>+</sup> কাদা কণার K<sup>+</sup> কে সরিয়ে দেয়; মুক্ত K<sup>+</sup> (KHCO<sub>3</sub> রূপে) মূলের দিকে যায় ও শোষিত হয়।']
  },
  art(g, C, ty) {
    if (ty === 'clay') {
      micelle(g, C, 150, 120, 104, 62, 22);
      CAT.forEach(([s, r], i) => { const a = i / CAT.length * PI * 2 + .2; B9.ion(g, 150 + 124 * Math.cos(a), 120 + 82 * Math.sin(a), s, BK.ramp(r), 12); });
      T(g, 300, 30, 'মুক্ত অ্যানায়ন', { fs: 10.5, a: 'middle', w: 600, c: BK.ramp(3).ink });
      E('path', { d: 'M300 214V246', stroke: BK.ramp(5).c, 'stroke-width': 2 }, g); BK.arrow(g, 300, 230, 300, 250, BK.ramp(5).c, 2);
      T(g, 290, 250, 'চুইয়ে যায়', { fs: 9.5, a: 'end', c: C.mu });
      T(g, 12, 248, 'ক্যাটায়ন আটকে থাকে → বিনিময়ে পাওয়া যায়', { fs: 10, c: C.mu });
    } else {
      micelle(g, C, 98, 140, 78, 56, 18);
      rootHair(g, C, 262);
      [['H^+', 70], ['H^+', 120], ['H^+', 170], ['H^+', 210]].forEach(([s, y]) => B9.ion(g, 256, y, s, BK.ramp(4), 9));
      [['Ca^{2+}', -2.2], ['Mg^{2+}', 2.4], ['Ca^{2+}', -1.2], ['NH_4^+', 1.4]].forEach(([s, a]) => B9.ion(g, 98 + 92 * Math.cos(a), 140 + 68 * Math.sin(a), s, BK.ramp(6), 11));
      if (ty === 'carb') {
        T(g, 12, 22, ch('CO_2 + H_2O → H_2CO_3 → H^+ + HCO_3^-'), { fs: 11.5, w: 560, c: C.fg });
        B9.ion(g, 234, 236, 'CO_2', BK.ramp(9), 12); B9.ion(g, 200, 236, 'H_2O', BK.ramp(5), 12);
        T(g, 234, 256, 'শ্বসন', { fs: 9.5, a: 'middle', c: C.mu });
      } else {
        E('circle', { cx: 176, cy: 140, r: 22, fill: 'none', stroke: C.mu, 'stroke-dasharray': '3 3' }, g); E('circle', { cx: 222, cy: 140, r: 22, fill: 'none', stroke: C.mu, 'stroke-dasharray': '3 3' }, g);
        T(g, 199, 186, 'দোলনের পরিসর মেলে', { fs: 9.5, a: 'middle', c: C.mu });
      }
    }
  },
  anim(g, C, ty, t) {
    if (!t) return;
    if (ty === 'clay') { ['NO_3^-', 'SO_4^{2-}', 'Cl^-', 'H_2PO_4^-'].forEach((s, i) => { const u = (t * .12 + i / 4) % 1; B9.ion(g, 272 + 26 * Math.sin(i * 2 + t), 44 + u * 170, s, BK.ramp(3), 12, { op: 1 - u * .6 }); }); CAT.forEach(([s, r], i) => { if (i % 3) return; const a = i / CAT.length * PI * 2 + .2, j = Math.sin(t * 7 + i) * 2.2; E('circle', { cx: 150 + (124 + j) * Math.cos(a), cy: 120 + (82 + j) * Math.sin(a), r: 14, fill: 'none', stroke: BK.ramp(r).c, 'stroke-width': 1.2, opacity: .7 }, g); }); return; }
    const u = (t * .33) % 1, k = FK.ease(cl((u - .15) / .55));
    if (ty === 'contact') { B9.ion(g, 176 + (256 - 176) * k, 140 + Math.sin(k * PI) * -14, 'K^+', BK.ramp(2), 11); B9.ion(g, 222 - (222 - 178) * k, 140 + Math.sin(k * PI) * 14, 'H^+', BK.ramp(4), 9); }
    else {
      const a = FK.ease(cl(u / .3)), b = FK.ease(cl((u - .3) / .3)), c = FK.ease(cl((u - .6) / .35));
      const hx = 214 - (214 - 172) * b, hy = 206 - (206 - 150) * b;
      if (u < .3) B9.ion(g, 214, 214 - 8 * a, 'H_2CO_3', BK.ramp(9), 13, { fs: 7.5 });
      else { B9.ion(g, hx, hy, 'H^+', BK.ramp(4), 9); B9.ion(g, 214 + 26 * b, 200, 'HCO_3^-', BK.ramp(9), 13, { fs: 7.5 }); }
      if (u > .6) B9.ion(g, 172 + (250 - 172) * c, 150 - 10 * Math.sin(c * PI), 'K^+', BK.ramp(2), 11);
      else B9.ion(g, 172, 150, 'K^+', BK.ramp(2), 11);
    }
  }
}));

/* ═════════ ৪. পরিশোষণের মতবাদ ═════════ */
const UPy = 132;  /* ঝিল্লির মধ্যরেখা */
const upBase = (g, C, gaps) => {
  T(g, 10, 18, 'বাইরে: মাটির দ্রবণ', { fs: 10.5, w: 560, c: C.mu }); T(g, 10, 250, 'ভেতরে: সাইটোপ্লাজম', { fs: 10.5, w: 560, c: C.mu });
  E('rect', { x: 0, y: UPy - 32, width: 360, height: 22, fill: FK.alpha(BK.ramp(11).c, .3) }, g); T(g, 352, UPy - 17, 'কোষপ্রাচীর (মুক্ত স্থান)', { fs: 9.5, a: 'end', c: BK.ramp(11).ink });
  E('rect', { x: 0, y: UPy + 10, width: 360, height: 130, fill: FK.alpha(BK.ramp(10).c, .07) }, g);
  B9.mem(g, C, 0, 360, UPy, { gaps });
};
V.uptake = Object.assign({}, B9.seg({
  id: 'upk', t: 'খনিজ লবণ পরিশোষণের প্রক্রিয়া', H: 262, def: 'diff',
  cap: 'নিষ্ক্রিয় পরিশোষণে শক্তি লাগে না, আয়ন ঘনত্ব নতি অনুসারে চলে। সক্রিয় পরিশোষণে শ্বসনের ATP খরচ করে বাহক ঘনত্ব নতির বিপরীতে আয়ন ভেতরে আনে — তাই কোষে বাইরের চেয়ে বহুগুণ বেশি আয়ন জমে। ধরন বদলে চালাও।',
  types: {
    mass: ['গণপ্রবাহ', 'গণপ্রবাহ মতবাদ (নিষ্ক্রিয়)', 'প্রস্বেদন টানে পানির স্রোতের সাথে আয়ন মুক্ত স্থানে (কোষপ্রাচীর ও আন্তঃকোষীয় ফাঁক) ঢোকে — হিলমো (1953), ক্রেমার। প্রস্বেদন বাড়লে পরিশোষণও বাড়ে।'],
    diff: ['ব্যাপন', 'সরল ব্যাপন (নিষ্ক্রিয়)', 'বাইরে আয়নের ঘনত্ব বেশি হলে ঘনত্ব নতি অনুসারে আয়ন ঝিল্লির প্রোটিন চ্যানেল দিয়ে ভেতরে আসে, যতক্ষণ না দুপাশে ঘনত্ব সমান হয়। শক্তি লাগে না।'],
    ionx: ['আয়ন বিনিময়', 'আয়ন বিনিময় (নিষ্ক্রিয়)', 'কোষপ্রাচীর ও ঝিল্লির গায়ে আটকানো H<sup>+</sup> বাইরের K<sup>+</sup> এর সাথে এবং OH<sup>−</sup> বা HCO<sub>3</sub><sup>−</sup> বাইরের অ্যানায়নের সাথে সমান আধানে জায়গা বদল করে।'],
    donnan: ['ডোনান সাম্য', 'ডোনান সাম্যাবস্থা (নিষ্ক্রিয়)', 'কোষের ভেতরে ঝিল্লি পার হতে পারে না এমন স্থির অ্যানায়ন (প্রোটিন ইত্যাদি) থাকে। আধান নিরপেক্ষ রাখতে বাড়তি ক্যাটায়ন ভেতরে ঢুকে জমে — শক্তি ছাড়াই ভেতরে ক্যাটায়ন বেশি হয়।'],
    carrier: ['বাহক', 'বাহক মতবাদ (সক্রিয়)', 'ভ্যান ডেন হনার্ট (1937): ঝিল্লির বাহক প্রোটিন বাইরের দিকে নির্দিষ্ট আয়নের সাথে যুক্ত হয়ে বাহক-আয়ন জটিল গঠন করে, ATP এর শক্তিতে ভেতরে নিয়ে আয়ন ছেড়ে দেয়। ঘনত্ব নতির বিপরীতে, নির্বাচনী (বাছাই করে)।'],
    cyto: ['সাইটোক্রোম পাম্প', 'সাইটোক্রোম পাম্প মতবাদ (সক্রিয়)', 'লুন্ডেগার্ড (1950): অ্যানায়ন পরিশোষণ শ্বসনের সাথে যুক্ত (লবণ শ্বসন)। সাইটোক্রোম শৃঙ্খলে ইলেকট্রন ভেতর থেকে বাইরে যায়, আর অ্যানায়ন বাইরে থেকে ভেতরে আসে; ক্যাটায়ন নিষ্ক্রিয়ভাবে অনুসরণ করে।']
  },
  art(g, C, ty) {
    upBase(g, C, ty === 'diff' ? [[106, 124], [236, 254]] : ty === 'carrier' ? [[160, 200]] : ty === 'cyto' ? [[162, 198]] : []);
    const Ri = BK.ramp(2);
    if (ty === 'diff') { [115, 245].forEach(x => { E('rect', { x: x - 9, y: UPy - 11, width: 18, height: 22, rx: 4, fill: FK.alpha(BK.ramp(0).c, .55), stroke: BK.ramp(0).dk }, g); }); T(g, 180, UPy + 26, 'চ্যানেল প্রোটিন', { fs: 9.5, a: 'middle', c: C.mu }); }
    if (ty === 'carrier') { E('ellipse', { cx: 180, cy: UPy, rx: 20, ry: 15, fill: FK.alpha(BK.ramp(3).c, .6), stroke: BK.ramp(3).dk, 'stroke-width': 1.4 }, g); T(g, 212, UPy + 26, 'বাহক প্রোটিন', { fs: 9.5, c: C.mu }); B9.chip(g, 84, UPy + 44, 'ATP → ADP + Pi', BK.ramp(6), { w: 104 }); BK.arrow(g, 136, UPy + 40, 160, UPy + 14, BK.ramp(6).c, 1.4); }
    if (ty === 'cyto') { [UPy - 9, UPy, UPy + 9].forEach((y, i) => E('circle', { cx: 180, cy: y, r: 6.5, fill: BK.ramp(4).lt, stroke: BK.ramp(4).dk }, g)); T(g, 204, UPy + 26, 'সাইটোক্রোম শৃঙ্খল', { fs: 9.5, c: C.mu }); }
    if (ty === 'donnan') for (let i = 0; i < 6; i++) { const x = 40 + i * 56, y = 196 + (i % 2) * 22; E('circle', { cx: x, cy: y, r: 12, fill: BK.ramp(9).lt, stroke: BK.ramp(9).dk }, g); minus(g, x, y, BK.ramp(9).dk); }
    const out = { mass: 6, diff: 9, ionx: 6, donnan: 4, carrier: 3, cyto: 4 }[ty], ins = { mass: 1, diff: 3, ionx: 3, donnan: 9, carrier: 10, cyto: 7 }[ty];
    for (let i = 0; i < out; i++) B9.dot(g, 20 + rnd(i + 3) * 320, 30 + rnd(i + 40) * 60, 4.2, Ri.c);
    for (let i = 0; i < ins; i++) B9.dot(g, 20 + rnd(i + 90) * 320, UPy + 22 + rnd(i + 60) * 50, 4.2, Ri.c);
    if (ty === 'ionx') for (let i = 0; i < 6; i++) B9.ion(g, 30 + i * 60, UPy - 21, 'H^+', BK.ramp(4), 7, { fs: 7 });
    const a = ty === 'carrier' || ty === 'cyto';
    B9.chip(g, 300, 50, a ? 'সক্রিয়' : 'নিষ্ক্রিয়', a ? BK.ramp(6) : BK.ramp(5), { w: 66 });
    T(g, 300, 72, a ? 'ATP লাগে' : 'শক্তি লাগে না', { fs: 9.5, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    if (!t) return; const Ri = BK.ramp(2), Rw = BK.ramp(5);
    if (ty === 'mass') for (let i = 0; i < 8; i++) { const u = (t * .3 + i / 8) % 1, x = 20 + i * 44 + u * 20, y = 26 + u * 84; B9.dot(g, x, y, 2.6, Rw.c, .8); if (i % 2) B9.dot(g, x + 4, y, 4, Ri.c, .9); }
    if (ty === 'diff') [115, 245].forEach((x, k) => { const u = (t * .3 + k * .5) % 1; B9.dot(g, x, 70 + u * 110, 4.2, Ri.c); });
    if (ty === 'ionx') for (let k = 0; k < 2; k++) { const u = (t * .35 + k * .5) % 1, x = 90 + k * 180, e = FK.ease(cl(u / .6)); B9.dot(g, x, 60 + e * 60, 4.2, Ri.c); B9.ion(g, x + 14, UPy - 21 - e * 60, 'H^+', BK.ramp(4), 7, { fs: 7, op: 1 - e * .5 }); }
    if (ty === 'donnan') for (let k = 0; k < 3; k++) { const u = (t * .25 + k / 3) % 1; B9.dot(g, 60 + k * 110, 60 + u * 140, 4.2, Ri.c); }
    if (ty === 'carrier') { const u = (t * .45) % 1, ph = u < .5 ? u * 2 : 2 - u * 2, rot = ph * 180; E('ellipse', { cx: 180, cy: UPy, rx: 20, ry: 15, fill: 'none', stroke: BK.ramp(3).dk, 'stroke-width': 2, transform: `rotate(${rot.toFixed(0)} 180 ${UPy})` }, g); if (u < .5) B9.dot(g, 180, UPy - 12 + 24 * FK.ease(ph), 4.6, Ri.c); else B9.dot(g, 180 + (u - .5) * 60, UPy + 14 + (u - .5) * 80, 4.2, Ri.c, 1.6 - u); B9.dot(g, 136 + 24 * ((t * .9) % 1), UPy + 40 - 26 * ((t * .9) % 1), 2.6, BK.ramp(6).c); }
    if (ty === 'cyto') { for (let k = 0; k < 2; k++) { const u = (t * .5 + k * .5) % 1; B9.dot(g, 172, UPy + 22 - u * 44, 2.8, BK.ramp(3).c); T(g, 160, UPy + 24 - u * 44, 'e', { fs: 8, a: 'end', c: BK.ramp(3).ink }); } const v = (t * .3) % 1; B9.dot(g, 190, 60 + v * 130, 4.2, BK.ramp(3).c); B9.dot(g, 110, 60 + ((t * .2) % 1) * 130, 4.2, Ri.c, .8); }
  }
}));

/* ═════════ ৫. বাহক মতবাদ — ধাপ ═════════ */
V.carrierSteps = Object.assign({ t: 'বাহক মতবাদ — সক্রিয় পরিশোষণ ধাপে ধাপে', k: ['anim', 'steps'], cap: 'ঝিল্লির বাহক নির্দিষ্ট আয়নকে বাইরের দিকে ধরে, ATP এর শক্তিতে ভেতরের দিকে নিয়ে ছেড়ে দেয়, তারপর আবার আগের অবস্থায় ফেরে। এভাবে ঘনত্ব নতির বিপরীতে আয়ন জমে।' }, BK.steps({
  W: 360, H: 230, label: 'বাহক মতবাদ', dur: 2.6,
  stages: [
    { t: 'আয়ন বাহকে যুক্ত হয়', en: 'Ion binds the carrier', d: 'ঝিল্লির বাইরের দিকে বাহকের নির্দিষ্ট স্থানে (যেমন K<sup>+</sup> এর জন্য নির্দিষ্ট বাহক) আয়ন যুক্ত হয়ে বাহক-আয়ন জটিল তৈরি হয়। বাহক নির্দিষ্ট — তাই পরিশোষণ নির্বাচনী।' },
    { t: 'ATP থেকে শক্তি', en: 'Carrier phosphorylated', d: 'শ্বসনে তৈরি ATP ভেঙে (ATP → ADP + Pi) বাহক ফসফোরাইলিত হয় — বাহকের আকৃতি বদলায়। এজন্য শ্বসন বন্ধ করলে (সায়ানাইড, কম O<sub>2</sub>, কম তাপ) সক্রিয় পরিশোষণ বন্ধ হয়।' },
    { t: 'আয়ন ভেতরে মুক্ত হয়', en: 'Ion released inside', d: 'আকৃতি বদলে জটিলটি ঝিল্লির ভেতরের দিকে মুখ ফেরায় এবং আয়ন সাইটোপ্লাজমে ছেড়ে দেয় — যদিও ভেতরে আয়নের ঘনত্ব আগে থেকেই বেশি।' },
    { t: 'বাহক আগের অবস্থায় ফেরে', en: 'Carrier regenerated', d: 'ফসফেটেজ এনজাইম ফসফেট সরিয়ে নেয়, বাহক আবার বাইরের দিকে মুখ করে নতুন আয়ন ধরার জন্য প্রস্তুত হয়। এক বাহক বারবার ব্যবহৃত হয়।' }
  ],
  draw(g, C, s, u) {
    const y = 118, Ri = BK.ramp(2), Rc = BK.ramp(3), Ra = BK.ramp(6);
    T(g, 10, 22, 'বাইরে — আয়ন কম', { fs: 10.5, c: C.mu }); T(g, 10, 222, 'ভেতরে — আয়ন বেশি', { fs: 10.5, c: C.mu });
    B9.mem(g, C, 0, 360, y, { gaps: [[150, 210]] });
    for (let i = 0; i < 3; i++) B9.dot(g, 40 + i * 110, 50 + (i % 2) * 14, 4.5, Ri.c);
    for (let i = 0; i < 8; i++) B9.dot(g, 30 + i * 40, 160 + (i % 3) * 16, 4.5, Ri.c);
    const rot = s === 0 ? 0 : s === 1 ? 0 : s === 2 ? 180 * u : 180 * (1 - u), cy = y;
    const cg = E('g', { transform: `rotate(${rot.toFixed(1)} 180 ${cy})` }, g);
    E('path', { d: `M160 ${cy}a20 18 0 1 1 40 0a20 18 0 1 1 -40 0Z M172 ${cy - 18}l8 10l8 -10`, fill: FK.alpha(Rc.c, .55), stroke: Rc.dk, 'stroke-width': 1.5 }, cg);
    if (s >= 1 && s <= 2) { E('circle', { cx: 196, cy: cy + 8, r: 6, fill: Ra.c }, cg); T(cg, 196, cy + 11, 'P', { fs: 8, a: 'middle', w: 650, c: '#fff', st: 'stroke:none' }); }
    let ix, iy;
    if (s === 0) { ix = 120 + 60 * u; iy = 60 + (cy - 60 - 14) * u; } else if (s === 1) { ix = 180; iy = cy - 12; } else if (s === 2) { const a = PI * u; ix = 180 + 12 * Math.sin(a); iy = cy - 12 * Math.cos(a) + (u > .8 ? (u - .8) * 150 : 0); } else { ix = 200 + 60 * u; iy = 170 + 10 * u; }
    if (!(s === 3 && u > .95)) B9.dot(g, ix, iy, 5.5, Ri.dk);
    if (s === 1) { const k = FK.ease(u); B9.chip(g, 78, 170, 'ATP', Ra, { w: 44 }); BK.arrow(g, 100, 162, 100 + 70 * k, 162 - 30 * k, Ra.c, 1.6); if (u > .6) B9.chip(g, 78, 196, 'ADP + Pi', Ra, { w: 70 }); }
    if (s === 3) { B9.chip(g, 282, 82, 'ফসফেটেজ', Rc, { w: 70 }); }
  }
}));

/* ═════════ ৬. মূলে পানির পথ ═════════ */
const WPc = { x0: 14, cw: 37, y0: 66, rh: 42 };
const wpX = i => WPc.x0 + i * WPc.cw, wpY = r => WPc.y0 + r * WPc.rh;
const WPpath = {
  apo: [[34, 24], [34, 64], [30, wpY(1) - 1], [wpX(5) - 2, wpY(1) - 1], [wpX(5) + 10, wpY(1) - 12], [wpX(5) + 18, wpY(0) + 20], [wpX(6) - 1, wpY(0) + 24], [wpX(6) + 4, wpY(1) - 1], [wpX(7) - 1, wpY(1) - 1], [wpX(7) + 20, wpY(1) - 2], [wpX(7) + 20, 30]],
  sym: [[34, 24], [34, 70], [wpX(0) + 18, wpY(1) + 21], [wpX(6) + 18, wpY(1) + 21], [wpX(7) + 20, wpY(1) + 21], [wpX(7) + 20, 30]],
  trans: [[34, 24], [34, 70], [wpX(0) + 14, wpY(2) + 21], [wpX(1) + 4, wpY(2) + 15], [wpX(1) + 18, wpY(2) + 27], [wpX(2) + 4, wpY(2) + 15], [wpX(2) + 18, wpY(2) + 27], [wpX(3) + 4, wpY(2) + 15], [wpX(3) + 18, wpY(2) + 27], [wpX(4) + 4, wpY(2) + 15], [wpX(4) + 18, wpY(2) + 27], [wpX(5) + 18, wpY(2) + 21], [wpX(6) + 18, wpY(2) + 21], [wpX(7) + 20, wpY(2) + 21], [wpX(7) + 20, 30]]
};
const WPcol = { apo: 5, sym: 10, trans: 3 };
V.waterPath = Object.assign({}, B9.seg({
  id: 'wp', t: 'মূলে পানি ও খনিজের পথ', H: 262, def: 'apo',
  cap: 'মূলরোম থেকে জাইলেম পর্যন্ত পানি তিন পথে যায়: কোষপ্রাচীর ও ফাঁক দিয়ে (অ্যাপোপ্লাস্ট), প্লাজমোডেসমাটা হয়ে সাইটোপ্লাজম দিয়ে (সিমপ্লাস্ট), আর প্রতিটি কোষের ঝিল্লি ও কোষগহ্বর পেরিয়ে (ট্রান্সমেমব্রেন)। এন্ডোডার্মিসের ক্যাসপেরিয়ান ফিতা অ্যাপোপ্লাস্ট পথ আটকে দেয় — পানিকে ঝিল্লি পেরোতে বাধ্য করে।',
  types: {
    apo: ['অ্যাপোপ্লাস্ট', 'অ্যাপোপ্লাস্ট পথ', 'জীবিত প্রোটোপ্লাস্টের বাইরে — কোষপ্রাচীর ও আন্তঃকোষীয় ফাঁক দিয়ে। সবচেয়ে দ্রুত, কোনো বাধা নেই — কিন্তু এন্ডোডার্মিসে ক্যাসপেরিয়ান ফিতায় (সুবেরিন) থেমে যায়; সেখানে পানি কোষে ঢুকে সিমপ্লাস্টে যেতে বাধ্য হয়।'],
    sym: ['সিমপ্লাস্ট', 'সিমপ্লাস্ট পথ', 'মূলরোম কোষে একবার ঝিল্লি পেরিয়ে ঢোকার পর পাশের কোষের সাইটোপ্লাজমে প্লাজমোডেসমাটা দিয়ে যায় — আর ঝিল্লি পেরোতে হয় না। ক্যাসপেরিয়ান ফিতায় বাধা পায় না।'],
    trans: ['ট্রান্সমেমব্রেন', 'ট্রান্সমেমব্রেন (কোষগহ্বর) পথ', 'প্রতিটি কোষে ঢোকা ও বের হওয়ার সময় কোষঝিল্লি এবং কোষগহ্বরের টনোপ্লাস্ট পেরোয়; অ্যাকোয়াপোরিন চ্যানেল প্রোটিন এ পথ দ্রুত করে। ধীরতম।']
  },
  art(g, C, ty) {
    const Rw = BK.ramp(11), Re = BK.ramp(3), Rp = BK.ramp(2), Rx = BK.ramp(4);
    const nm = ['ত্বক', 'কর্টেক্স', '', '', '', 'এন্ডো-', 'পেরি-', 'জাইলেম'];
    for (let i = 0; i < 7; i++) for (let r = 0; r < 3; r++) {
      const x = wpX(i) + 2, y = wpY(r) + 2, R = i === 5 ? Re : i === 6 ? Rp : i === 0 ? BK.ramp(0) : Rw;
      E('rect', { x, y, width: WPc.cw - 4, height: WPc.rh - 4, rx: 5, fill: FK.alpha(R.c, .22), stroke: R.dk, 'stroke-width': .9 }, g);
      E('rect', { x: x + 7, y: y + 9, width: WPc.cw - 18, height: WPc.rh - 22, rx: 4, fill: FK.alpha(BK.ramp(5).c, .14), stroke: FK.alpha(R.dk, .5), 'stroke-width': .6 }, g);
      if (i < 6) E('path', { d: `M${wpX(i + 1)} ${wpY(r) + 18}v6`, stroke: BK.ramp(10).dk, 'stroke-width': 2.4 }, g);
    }
    for (let r = 0; r <= 3; r++) E('rect', { x: wpX(5) + 8, y: wpY(r) - 3, width: 20, height: 6, rx: 2, fill: Re.dk }, g);
    E('rect', { x: wpX(7) + 4, y: 28, width: 34, height: 196, rx: 6, fill: FK.alpha(BK.ramp(5).c, .2), stroke: Rx.dk, 'stroke-width': 1.4 }, g);
    for (let y = 40; y < 220; y += 14) E('path', { d: `M${wpX(7) + 4} ${y}h34`, stroke: Rx.c, 'stroke-width': 2.2, opacity: .7 }, g);
    E('path', { d: `M28 ${wpY(0) + 2}V20a6 6 0 0 1 12 0V${wpY(0) + 2}`, fill: FK.alpha(BK.ramp(0).c, .22), stroke: BK.ramp(0).dk, 'stroke-width': .9 }, g);
    nm.forEach((s, i) => { if (s) T(g, i === 1 ? wpX(2) + 18 : wpX(i) + 18, 244, s, { fs: 9.5, a: 'middle', w: 560, c: i === 5 ? Re.ink : C.mu }); });
    T(g, wpX(5) + 18, 256, 'ডার্মিস', { fs: 9.5, a: 'middle', c: Re.ink }); T(g, wpX(6) + 18, 256, 'সাইকল', { fs: 9.5, a: 'middle', c: C.mu });
    T(g, 50, 18, 'মাটির পানি', { fs: 10, c: BK.ramp(5).ink }); T(g, wpX(5) + 4, 56, 'ক্যাসপেরিয়ান ফিতা', { fs: 9.5, a: 'middle', w: 560, c: Re.ink });
    Object.keys(WPpath).forEach(k => B9.poly(g, WPpath[k], { stroke: BK.ramp(WPcol[k]).c, 'stroke-width': k === ty ? 2.2 : 1, 'stroke-dasharray': k === ty ? '5 3' : '2 4', opacity: k === ty ? .95 : .3 }));
    if (ty === 'apo') { E('circle', { cx: wpX(5) + 4, cy: wpY(1) - 1, r: 9, fill: 'none', stroke: Re.dk, 'stroke-width': 1.6 }, g); }
  },
  anim(g, C, ty, t) { if (!t) return; const R = BK.ramp(WPcol[ty]), sp = ty === 'trans' ? .07 : ty === 'sym' ? .09 : .12; for (let i = 0; i < 7; i++) { const [x, y] = B9.along(WPpath[ty], (t * sp + i / 7) % 1); B9.dot(g, x, y, 3.6, R.dk); } }
}));

/* ═════════ ৭. রসের ঊর্ধ্বগমন ═════════ */
const PSIk = 135.0;  /* RT/Vw (MPa), 20 °C */
V.ascent = Object.assign({}, B9.seg({
  id: 'asc', t: 'রসের ঊর্ধ্বগমন: সংসক্তি-টান, মূলচাপ ও কৈশিকতা', H: 300, def: 'coh',
  cap: 'পানি সবসময় বেশি পানিবিভব থেকে কম পানিবিভবের দিকে যায়। মাটি → মূল → কাণ্ড → পাতা → বাতাস — পানিবিভব ক্রমে কমে, বাতাসে সবচেয়ে কম। পাতা থেকে বাষ্প বের হলে জাইলেমের অবিচ্ছিন্ন পানির স্তম্ভে টান পড়ে (সংসক্তি-টান মতবাদ)। স্লাইডারে বাতাসের আপেক্ষিক আর্দ্রতা বদলাও।',
  types: {
    coh: ['সংসক্তি-টান', 'সংসক্তি-টান মতবাদ (ডিক্সন ও জলি, 1894)', 'পানির অণুর পারস্পরিক আকর্ষণ (সংসক্তি) ও জাইলেম প্রাচীরের সাথে আকর্ষণ (আসঞ্জন) মিলে সরু নলে অবিচ্ছিন্ন পানির স্তম্ভ তৈরি হয়। প্রস্বেদন সেই স্তম্ভের মাথায় টান (ঋণাত্মক চাপ) দেয় — স্তম্ভটি দড়ির মতো ওপরে উঠে আসে। শক্তি আসে সূর্যের তাপ থেকে; উদ্ভিদের ATP লাগে না।'],
    root: ['মূলচাপ', 'মূলচাপ (Root pressure)', 'মূলের কোষ সক্রিয়ভাবে জাইলেমে আয়ন জমায়, ফলে জাইলেমের পানিবিভব কমে এবং অভিস্রবণে পানি ঢুকে নিচ থেকে চাপ দেয় — সাধারণত 0.1–0.2 MPa। রাতে বা প্রস্বেদন কম হলে এ চাপে পাতার কিনারা দিয়ে পানির ফোঁটা বের হয় (গাটেশন)। কিন্তু এটি বড় গাছে পানি তুলতে যথেষ্ট নয়, অনেক গাছে (যেমন কনিফার) মূলচাপ পাওয়াই যায় না, এবং দিনে প্রস্বেদন বেশি থাকলে জাইলেমে চাপ ঋণাত্মক থাকে।'],
    cap: ['কৈশিকতা', 'কৈশিকতা (Capillarity)', 'সরু নলে পানি নিজে থেকে কিছুটা ওঠে: h = 2γcosθ / (ρgr)। 20 µm ব্যাসার্ধের জাইলেম ভেসেলে এ উচ্চতা মাত্র প্রায় 0.74 m — উঁচু গাছের জন্য যথেষ্ট নয়, আর জাইলেমের মাথা খোলা পানিপৃষ্ঠে থাকে না। তাই কৈশিকতা কেবল সহায়ক।']
  },
  sl: [{ k: 'rh', l: 'বাতাসের আর্দ্রতা (RH %)', min: 30, max: 99, step: 1, val: 50, unit: '%' }],
  art(g, C, ty, ctx) {
    const Rw = BK.ramp(5), Rg = BK.ramp(10), Rs = BK.ramp(11);
    E('rect', { x: 8, y: 262, width: 344, height: 32, rx: 6, fill: FK.alpha(Rs.c, .45) }, g); T(g, 16, 286, 'মাটি', { fs: 10.5, w: 560, c: Rs.ink });
    if (ty === 'cap') {
      const rs = [[10, 1.48], [20, 0.74], [50, 0.30]];
      E('rect', { x: 40, y: 220, width: 280, height: 40, rx: 6, fill: FK.alpha(Rw.c, .35), stroke: Rw.dk }, g);
      rs.forEach(([r, h], i) => { const x = 90 + i * 90, w = 4 + i * 6; E('rect', { x: x - w / 2, y: 30, width: w, height: 220, fill: 'none', stroke: C.fg, 'stroke-width': 1.1 }, g); T(g, x + w / 2 + 6, 46, `r = ${r} µm`, { fs: 10, c: C.fg }); T(g, x + w / 2 + 6, 60, `h ≈ ${FK.n(h, 2)} m`, { fs: 10, w: 600, c: Rw.ink }); });
      T(g, 180, 20, 'h = 2γcosθ / (ρgr) — ব্যাস যত সরু, পানি তত ওপরে', { fs: 10, a: 'middle', c: C.mu });
      return;
    }
    E('path', { d: 'M86 262L92 110L104 110L110 262Z', fill: FK.alpha(BK.ramp(2).c, .4), stroke: BK.ramp(2).dk }, g);
    E('path', { d: 'M92 266l-30 22M98 266l2 26M104 266l34 20', stroke: BK.ramp(2).dk, 'stroke-width': 2.4, fill: 'none' }, g);
    E('ellipse', { cx: 98, cy: 74, rx: 84, ry: 48, fill: FK.alpha(Rg.c, .4), stroke: Rg.dk }, g);
    E('rect', { x: 95, y: 92, width: 6, height: 172, fill: FK.alpha(Rw.c, .5) }, g);
    if (ty === 'coh') {
      const rh = ctx.v.rh / 100, air = PSIk * Math.log(rh);
      const rows = [['বাতাস', air, 36], ['পাতার কোষ', -0.8, 84], ['কাণ্ডের জাইলেম', -0.6, 150], ['মূলের জাইলেম', -0.5, 228], ['মাটি', -0.3, 278]];
      T(g, 208, 16, 'পানিবিভব Ψ (MPa)', { fs: 10.5, w: 600, c: C.mu });
      rows.forEach(([s, v, y], i) => { const R = BK.ramp(i === 0 ? 4 : 5); E('path', { d: `M114 ${y - 4}H204`, stroke: FK.alpha(C.mu, .5), 'stroke-dasharray': '2 3' }, g); T(g, 208, y, s, { fs: 10.5, c: C.fg }); T(g, 352, y, FK.n(v, i === 0 ? 1 : 1), { fs: 11.5, a: 'end', w: 650, c: R.ink }); });
      T(g, 208, 52, `RH ${Math.round(rh * 100)}% → Ψ = 135 × ln(${FK.n(rh, 2)})`, { fs: 9.2, c: C.mu });
    } else {
      T(g, 208, 40, 'মূলচাপ ≈ 0.1–0.2 MPa', { fs: 11, w: 600, c: Rw.ink }); T(g, 208, 58, '→ সর্বোচ্চ ~10–20 m (তত্ত্বে)', { fs: 10, c: C.mu });
      T(g, 208, 150, 'রাতে: গাটেশন', { fs: 10.5, w: 560, c: C.fg }); T(g, 208, 166, '(পানি-পত্ররন্ধ্র দিয়ে ফোঁটা)', { fs: 9.5, c: C.mu });
      T(g, 208, 228, 'এন্ডোডার্মিস: আয়ন পাম্প', { fs: 10, c: BK.ramp(3).ink });
    }
  },
  more(ty, ctx) { if (ty !== 'coh') return ''; const rh = ctx.v.rh / 100, air = PSIk * Math.log(rh); return `<div class="small">RH ${Math.round(rh * 100)}% এ বাতাসের Ψ ≈ <b>${FK.n(air, 1)} MPa</b> (Ψ = (RT/V<sub>w</sub>) ln RH, 20 °C এ RT/V<sub>w</sub> ≈ 135 MPa)। আর্দ্রতা বাড়লে বাতাস-পাতার পার্থক্য কমে — প্রস্বেদন ও পানির টান কমে।</div>`; },
  anim(g, C, ty, t, ctx) {
    if (!t) return; const Rw = BK.ramp(5);
    if (ty === 'cap') { const k = FK.ease(cl(((t * .25) % 1.2) / .9)); [[10, 1.48], [20, .74], [50, .3]].forEach(([r, h], i) => { const x = 90 + i * 90, w = 4 + i * 6, top = 222 - k * h * 120; E('rect', { x: x - w / 2 + 1, y: top.toFixed(1), width: w - 2, height: (230 - top).toFixed(1), fill: Rw.c, opacity: .8 }, g); }); return; }
    if (ty === 'coh') { const rh = ctx.v.rh / 100, sp = .08 + .5 * (-Math.log(rh)) / (-Math.log(.3)); for (let i = 0; i < 8; i++) { const u = (t * sp + i / 8) % 1; B9.dot(g, 98, 262 - u * 170, 2.8, Rw.dk); } for (let i = 0; i < 5; i++) { const u = (t * sp * 1.4 + i / 5) % 1; B9.dot(g, 40 + i * 30 + Math.sin(t + i) * 4, 56 - u * 40, 2.4, Rw.c, 1 - u); } return; }
    for (let i = 0; i < 5; i++) { const u = (t * .12 + i / 5) % 1; B9.dot(g, 98, 262 - u * 130, 2.8, Rw.dk, u > .85 ? (1 - u) * 6 : 1); }
    const d = (t * .5) % 1; B9.dot(g, 182, 80 + d * 30, 3.4, Rw.c, 1 - d * .7);
  }
}));

/* ═════════ ৮. পরিশোষণের প্রভাবক ═════════ */
V.upFactors = B9.gseg({
  id: 'upf', t: 'খনিজ লবণ পরিশোষণের প্রভাবক', def: 'temp',
  cap: 'সক্রিয় পরিশোষণ শ্বসনের ওপর নির্ভরশীল — তাই তাপ, O2 ও আলো যা শ্বসন বা ATP সরবরাহ বদলায়, তা পরিশোষণও বদলায়। লেখচিত্রে চাপ দিলে সেই বিন্দুর মান ও ব্যাখ্যা।',
  types: {
    temp: { b: 'তাপমাত্রা', t: 'তাপমাত্রা', d: 'প্রায় 30–35 °C পর্যন্ত এনজাইম ও শ্বসন বাড়ে বলে পরিশোষণ বাড়ে; তার বেশি হলে এনজাইম ও বাহক প্রোটিন বিনষ্ট হয়, পরিশোষণ দ্রুত কমে।', c: 2, xr: [0, 50], xt: [0, 10, 20, 30, 40, 50], lx: 'তাপমাত্রা (°C)', u: ' °C', f: x => x <= 32 ? Math.pow(x / 32, 1.4) : Math.max(0, 1 - Math.pow((x - 32) / 15, 2)), mk: [[32, 'অনুকূল', 1]], read: x => x < 10 ? 'কম তাপে শ্বসন ধীর — ATP কম, বাহক কম কাজ করে।' : x > 38 ? 'অতিরিক্ত তাপে প্রোটিন বিনষ্ট (ডিন্যাচার) হয়, ঝিল্লি ক্ষতিগ্রস্ত।' : 'অনুকূল পরিসর।' },
    o2: { b: 'অক্সিজেন', t: 'মাটিতে অক্সিজেন', d: 'O<sub>2</sub> বাড়লে মূলের সবাত শ্বসন ও ATP বাড়ে — পরিশোষণ বাড়ে, একসময় স্থির হয়। জলাবদ্ধ মাটিতে O<sub>2</sub> কম বলে গাছ খনিজ নিতে পারে না।', c: 0, xr: [0, 21], xt: [0, 5, 10, 15, 20], lx: 'O2 (%)', u: '%', f: x => .1 + .9 * (1 - Math.exp(-x / 3.5)), mk: [[0.3, 'অবাতে: শুধু নিষ্ক্রিয় অংশ', 0, 'start']], read: x => x < 2 ? 'প্রায় অবাত — কেবল নিষ্ক্রিয় পরিশোষণ চলে।' : 'শ্বসন সচল — সক্রিয় পরিশোষণ চলে।' },
    conc: { b: 'ঘনত্ব', t: 'বাইরের আয়নের ঘনত্ব (এপস্টাইনের দ্বৈত ধরন)', d: 'কম ঘনত্বে উচ্চ-আসক্তির বাহক (তন্ত্র-১) দ্রুত সম্পৃক্ত হয়; বেশি ঘনত্বে নিম্ন-আসক্তির তন্ত্র-২ কাজ করে। বাহক সীমিত বলে হার একসময় স্থির হয় — এনজাইমের মতো সম্পৃক্তি।', c: 3, xr: [0, 20], xt: [0, 5, 10, 15, 20], lx: 'বাইরের ঘনত্ব (mM)', u: ' mM', dp: 1, f: x => (.6 * x / (x + .2) + .4 * x / (x + 8)) / .9, mk: [[1, 'তন্ত্র-১ প্রায় সম্পৃক্ত', 0, 'start']], read: x => x < 1 ? 'বাহক খালি — ঘনত্ব বাড়ালে হার দ্রুত বাড়ে।' : 'বাহক প্রায় ভরা — বাড়তি ঘনত্বে হার অল্প বাড়ে।' },
    ph: { b: 'pH', t: 'মাটির pH', d: 'pH বদলালে আয়নের দ্রবণীয়তা ও আধান বদলায় — বেশিরভাগ উপাদান pH 6–7 এ সবচেয়ে সহজে শোষিত হয়।', c: 10, xr: [3, 10], xt: [3, 4, 5, 6, 7, 8, 9, 10], lx: 'pH', dp: 1, f: x => Math.exp(-Math.pow((x - 6.5) / 1.6, 2)), mk: [[6.5, 'অনুকূল', 1]], read: x => x < 5.5 ? 'অম্লীয়: P, Ca, Mg কম পাওয়া যায়; Al বিষাক্ত হতে পারে।' : x > 7.5 ? 'ক্ষারীয়: Fe, Mn, Zn, B কম পাওয়া যায়।' : 'অনুকূল।' },
    light: { b: 'আলো', t: 'আলো (পরোক্ষ প্রভাব)', d: 'আলোতে সালোকসংশ্লেষণে শর্করা ও ATP বাড়ে, পত্ররন্ধ্র খোলে ও প্রস্বেদন বাড়ে — ফলে মূলে শ্বসনের খাদ্য ও গণপ্রবাহ দুটোই বাড়ে।', c: 6, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'আলো (% সর্বোচ্চ)', u: '%', f: x => .3 + .7 * (1 - Math.exp(-x / 30)), read: () => 'আলো সরাসরি নয় — শর্করা, ATP ও প্রস্বেদনের মাধ্যমে প্রভাব ফেলে।' }
  }
});

/* ═════════ তুলনা (৯.১) ═════════ */
V.cmpActPass = Object.assign({ t: 'সক্রিয় বনাম নিষ্ক্রিয় পরিশোষণ', k: ['compare', 'int'], cap: 'সারিতে চাপ দিলে চিহ্নিত হয়; "যাচাই খেলা" তে নিজেকে পরীক্ষা করো।' }, BK.compare({
  a: 'সক্রিয় পরিশোষণ', b: 'নিষ্ক্রিয় পরিশোষণ',
  rows: [
    ['শক্তি', 'শ্বসনের ATP খরচ হয়', 'বিপাকীয় শক্তি লাগে না'],
    ['ঘনত্ব নতি', 'নতির বিপরীতে (কম → বেশি)', 'নতি অনুসারে (বেশি → কম)'],
    ['বাহক', 'নির্দিষ্ট বাহক প্রোটিন লাগে', 'বাহক লাগে না (চ্যানেল বা প্রাচীর দিয়ে)'],
    ['শ্বসনের সম্পর্ক', 'সরাসরি নির্ভরশীল', 'নির্ভরশীল নয়'],
    ['O<sub>2</sub>, তাপ ও বিষের প্রভাব', 'কম O<sub>2</sub>, কম তাপ বা সায়ানাইডে বন্ধ হয়', 'প্রায় প্রভাব পড়ে না'],
    ['নির্বাচন', 'নির্বাচনী — নির্দিষ্ট আয়ন বাছাই', 'সাধারণত অনির্বাচনী'],
    ['কোষে আয়ন জমা', 'বাইরের চেয়ে বহুগুণ বেশি জমতে পারে', 'বড়জোর সাম্যাবস্থা পর্যন্ত (ডোনান ছাড়া)'],
    ['মতবাদ', 'বাহক মতবাদ, সাইটোক্রোম পাম্প, প্রোটিন-লেসিথিন বাহক', 'গণপ্রবাহ, সরল ব্যাপন, আয়ন বিনিময়, ডোনান সাম্য']
  ]
}));
V.cmpWaterMin = Object.assign({ t: 'পানি শোষণ বনাম খনিজ লবণ পরিশোষণ', k: ['compare', 'int'], cap: 'দুটি একসাথে মূলরোম দিয়ে ঘটে, কিন্তু একে অপরের ওপর নির্ভরশীল নয় (হোগল্যান্ড)।' }, BK.compare({
  a: 'পানি শোষণ', b: 'খনিজ লবণ পরিশোষণ',
  rows: [
    ['শোষিত বস্তু', 'পানির অণু', 'আয়ন (ক্যাটায়ন ও অ্যানায়ন)'],
    ['প্রধান প্রক্রিয়া', 'অভিস্রবণ ও প্রস্বেদন টান — মূলত নিষ্ক্রিয়', 'সক্রিয় (বাহক) ও নিষ্ক্রিয় দুটোই; মূলত সক্রিয়'],
    ['শক্তি', 'সাধারণত ATP লাগে না', 'সক্রিয় পরিশোষণে ATP লাগে'],
    ['চালিকা শক্তি', 'পানিবিভবের পার্থক্য', 'ঘনত্ব নতি, আধান ও বাহক'],
    ['নির্বাচন', 'অনির্বাচনী', 'নির্বাচনী — নির্দিষ্ট আয়ন বেছে নেয়'],
    ['শ্বসন বন্ধ করলে', 'প্রায় প্রভাব পড়ে না', 'সক্রিয় অংশ বন্ধ হয়'],
    ['প্রস্বেদনের ভূমিকা', 'সরাসরি — প্রস্বেদন বাড়লে শোষণ বাড়ে', 'পরোক্ষ — গণপ্রবাহের মাধ্যমে কিছুটা'],
    ['পারস্পরিক সম্পর্ক', 'খনিজ পরিশোষণ থেকে স্বাধীন', 'পানি শোষণ থেকে স্বাধীন']
  ]
}));

/* ═════════ ৯. প্রস্বেদনের ধরন ═════════ */
const leafTS = (g, C, thick) => {
  const Rg = BK.ramp(10), Re = BK.ramp(0), Rc = BK.ramp(6);
  E('rect', { x: 0, y: 34, width: 360, height: thick ? 6 : 3, fill: Rc.c, opacity: .8 }, g);
  E('rect', { x: 0, y: 40, width: 360, height: 12, fill: FK.alpha(Re.c, .25) }, g); for (let x = 0; x < 360; x += 24) E('path', { d: `M${x} 40v12`, stroke: Re.dk, 'stroke-width': .8 }, g);
  for (let x = 4; x < 360; x += 16) E('rect', { x, y: 54, width: 12, height: 44, rx: 5, fill: FK.alpha(Rg.c, .5), stroke: Rg.dk, 'stroke-width': .7 }, g);
  for (let i = 0; i < 26; i++) { const x = 10 + (i % 13) * 27 + (i > 12 ? 13 : 0), y = 112 + (i > 12 ? 26 : 0); if (Math.abs(x - 180) < 30 && y > 125) continue; B9.blob(g, x, y, 10, { fill: FK.alpha(Rg.c, .32), stroke: Rg.dk, sw: .7, seed: i + 3 }); }
  E('rect', { x: 0, y: 158, width: 360, height: 12, fill: FK.alpha(Re.c, .25) }, g); for (let x = 0; x < 360; x += 24) if (Math.abs(x - 180) > 20) E('path', { d: `M${x} 158v12`, stroke: Re.dk, 'stroke-width': .8 }, g);
  E('rect', { x: 0, y: 170, width: 360, height: 2, fill: Rc.c, opacity: .8 }, g);
  E('rect', { x: 162, y: 157, width: 12, height: 15, rx: 6, fill: FK.alpha(Rg.c, .7), stroke: Rg.dk }, g); E('rect', { x: 186, y: 157, width: 12, height: 15, rx: 6, fill: FK.alpha(Rg.c, .7), stroke: Rg.dk }, g);
  E('ellipse', { cx: 180, cy: 142, rx: 22, ry: 13, fill: FK.alpha(BK.ramp(5).c, .12), stroke: FK.alpha(C.mu, .6), 'stroke-dasharray': '2 2' }, g);
};
V.transpTypes = Object.assign({}, B9.seg({
  id: 'trt', t: 'প্রস্বেদনের ধরন: পত্ররন্ধ্রীয়, কিউটিকুলার ও লেন্টিকুলার', H: 250, def: 'stoma',
  cap: 'পাতার মেসোফিল কোষের ভেজা প্রাচীর থেকে পানি বাষ্প হয়ে আন্তঃকোষীয় ফাঁকে জমে, তারপর বাইরে যায়। কোন পথে যায় তার ওপর প্রস্বেদন তিন রকম — মোট প্রস্বেদনের সিংহভাগ হয় পত্ররন্ধ্র দিয়ে।',
  types: {
    stoma: ['পত্ররন্ধ্রীয়', 'পত্ররন্ধ্রীয় প্রস্বেদন — প্রায় 80–90%', 'বাষ্প মেসোফিলের ফাঁক থেকে অধঃরন্ধ্রীয় গহ্বরে, তারপর খোলা পত্ররন্ধ্র দিয়ে বাইরে যায়। দিনে রন্ধ্র খোলা থাকে বলে দিনেই বেশি; উদ্ভিদ রন্ধ্র খুলে-বন্ধ করে এটি নিয়ন্ত্রণ করে।'],
    cut: ['কিউটিকুলার', 'কিউটিকুলার (ত্বকীয়) প্রস্বেদন — প্রায় 5–10%', 'পাতার ত্বকের ওপরের কিউটিকল স্তর ভেদ করে সরাসরি বাষ্প বের হয় — দিন-রাত সবসময়, উদ্ভিদের নিয়ন্ত্রণ নেই। পাতলা কিউটিকলের ছায়াপ্রিয় বা কচি পাতায় এটি বেশি (প্রায় 20% পর্যন্ত); মরুজ উদ্ভিদে পুরু কিউটিকল একে কমায়।'],
    lent: ['লেন্টিকুলার', 'লেন্টিকুলার প্রস্বেদন — প্রায় 0.1%', 'কাঠল কাণ্ড ও ফলের বাকলে লেন্টিসেলের আলগা সাজানো পূরক কোষের ফাঁক দিয়ে বাষ্প বের হয়। খুব সামান্য, নিয়ন্ত্রণহীন; পাতা ঝরে গেলে শীতে এটিই চলে।']
  },
  art(g, C, ty) {
    if (ty === 'lent') {
      const Rk = BK.ramp(2), Rp = BK.ramp(11);
      for (let r = 0; r < 4; r++) for (let x = 0; x < 360; x += 22) { if (Math.abs(x + 11 - 180) < 44) continue; E('rect', { x: x + 1, y: 40 + r * 14, width: 20, height: 12, rx: 2, fill: FK.alpha(Rk.c, .5), stroke: Rk.dk, 'stroke-width': .7 }, g); }
      for (let i = 0; i < 14; i++) B9.blob(g, 150 + (i % 5) * 15 + (i > 9 ? 7 : 0), 46 + Math.floor(i / 5) * 16, 6.5, { fill: FK.alpha(Rp.c, .5), stroke: Rp.dk, sw: .7, seed: i + 9 });
      E('rect', { x: 0, y: 98, width: 360, height: 10, fill: FK.alpha(BK.ramp(6).c, .5) }, g);
      for (let i = 0; i < 24; i++) B9.blob(g, 10 + (i % 12) * 30, 128 + Math.floor(i / 12) * 28, 12, { fill: FK.alpha(BK.ramp(10).c, .2), stroke: BK.ramp(10).dk, sw: .7, seed: i + 30 });
      B9.lab(g, 160, 52, 120, 22, 'লেন্টিসেল (পূরক কোষ)', C, { a: 'end' }); B9.lab(g, 300, 54, 320, 22, 'কর্ক (সুবেরিন)', C, { a: 'end' }); B9.lab(g, 40, 103, 22, 196, 'ফেলোজেন', C, { a: 'start' }); B9.lab(g, 260, 140, 270, 196, 'কর্টেক্স', C, { a: 'start' });
      B9.chip(g, 296, 236, '≈ 0.1%', BK.ramp(2), { w: 70 });
      return;
    }
    leafTS(g, C, ty === 'stoma');
    B9.lab(g, 300, 36, 320, 18, 'কিউটিকল', C, { a: 'end' }); B9.lab(g, 60, 76, 22, 18, 'প্যালিসেড', C, { a: 'start' }); B9.lab(g, 240, 124, 300, 206, 'স্পঞ্জি (বায়ুফাঁক)', C, { a: 'start' }); B9.lab(g, 172, 170, 130, 200, 'পত্ররন্ধ্র', C, { a: 'end' }); B9.lab(g, 200, 140, 236, 220, 'অধঃরন্ধ্রীয় গহ্বর', C, { a: 'start' });
    B9.chip(g, 60, 236, ty === 'stoma' ? '≈ 80–90%' : '≈ 5–10%', BK.ramp(5), { w: 78 });
  },
  anim(g, C, ty, t) {
    if (!t) return; const Rw = BK.ramp(5);
    if (ty === 'stoma') for (let i = 0; i < 9; i++) { const u = (t * .3 + i / 9) % 1, sx = 30 + (i * 37) % 300; const pts = [[sx, 120], [180, 142], [180, 172], [180 + (i - 4) * 12, 242]]; const [x, y] = B9.along(pts, u); B9.dot(g, x, y, 2.8, Rw.dk, u > .8 ? (1 - u) * 5 : 1); }
    else if (ty === 'cut') for (let i = 0; i < 6; i++) { const u = (t * .12 + i / 6) % 1, x = 30 + i * 55; B9.dot(g, x + Math.sin(t + i) * 3, 52 - u * 46, 2.6, Rw.dk, 1 - u * .8); }
    else for (let i = 0; i < 5; i++) { const u = (t * .2 + i / 5) % 1; B9.dot(g, 165 + i * 8, 100 - u * 92, 2.6, Rw.dk, 1 - u * .7); }
  }
}));

/* ═════════ ১০. পত্ররন্ধ্র খোলা-বন্ধ ═════════ */
const openAt = h => { const L = Math.max(0, Math.sin(PI * (h - 6) / 12)); return cl(L * 1.35); };
const guard = (g, cx, cy, Lh, a, side, R, C) => {
  const w = 2 + 9 * a, Tk = 30 + 4 * a, s = side;
  const d = `M${cx} ${cy - Lh}Q${cx + s * 2 * w} ${cy} ${cx} ${cy + Lh}Q${cx + s * 2 * (w + Tk)} ${cy} ${cx} ${cy - Lh}Z`;
  E('path', { d, fill: FK.alpha(R.c, .45 + .25 * a), stroke: R.dk, 'stroke-width': 1.4 }, g);
  E('path', { d: `M${cx} ${cy - Lh}Q${cx + s * 2 * w} ${cy} ${cx} ${cy + Lh}`, fill: 'none', stroke: R.dk, 'stroke-width': 3.6, 'stroke-linecap': 'round' }, g);
  for (let k = 0; k < 5; k++) { const v = -0.6 + k * .3, y = cy + v * Lh, mx = cx + s * (w + Tk * .5) * 2 * (1 - v * v) * .5 + s * 2; E('ellipse', { cx: mx, cy: y, rx: 4, ry: 2.6, fill: R.dk, opacity: .75 }, g); }
  E('circle', { cx: cx + s * (w + Tk * .5) * .95, cy: cy + 4, r: 4.5, fill: FK.alpha(BK.ramp(3).c, .6), stroke: BK.ramp(3).dk, 'stroke-width': .7 }, g);
  return w;
};
V.stomaMech = Object.assign({}, B9.seg({
  id: 'smc', t: 'পত্ররন্ধ্র খোলা ও বন্ধ হওয়ার কৌশল', H: 290, def: 'k',
  cap: 'রক্ষীকোষের ভেতরের (রন্ধ্রের দিকের) প্রাচীর পুরু ও অনমনীয়, বাইরের প্রাচীর পাতলা ও প্রসারণশীল। রক্ষীকোষে পানি ঢুকে রসস্ফীত হলে পাতলা বাইরের প্রাচীর বেশি প্রসারিত হয় — কোষ দুটি বাইরের দিকে বেঁকে যায়, মাঝে রন্ধ্র খোলে। স্লাইডারে দিনের সময় বদলাও।',
  types: {
    k: ['K+ পাম্প', 'K+ আয়ন পাম্প মতবাদ (প্রচলিত আধুনিক মতবাদ)', 'আলোতে (বিশেষত নীল আলো) রক্ষীকোষের ঝিল্লির H<sup>+</sup>-ATPase পাম্প H<sup>+</sup> বাইরে পাঠায় → ভেতরটা ঋণাত্মক হয় → K<sup>+</sup> চ্যানেল দিয়ে K<sup>+</sup> ঢোকে, সাথে Cl<sup>−</sup>; শ্বেতসার ভেঙে ম্যালেট<sup>2−</sup> তৈরি হয়। দ্রব বাড়ায় পানিবিভব কমে → পাশের কোষ থেকে পানি ঢোকে → রসস্ফীতি → রন্ধ্র খোলে। অন্ধকারে উল্টোটা ঘটে।'],
    starch: ['শ্বেতসার-শর্করা', 'শ্বেতসার-শর্করা আন্তঃরূপান্তর মতবাদ (সেয়ার, 1923; স্টুয়ার্ড, 1964)', 'দিনে সালোকসংশ্লেষণে CO<sub>2</sub> খরচ হয় → রক্ষীকোষের pH বাড়ে (প্রায় 7) → ফসফোরাইলেজ এনজাইম শ্বেতসারকে গ্লুকোজ-১-ফসফেট ও শর্করায় ভাঙে → দ্রব বাড়ে, পানি ঢোকে, রন্ধ্র খোলে। রাতে CO<sub>2</sub> জমে pH কমে (প্রায় 5) → শর্করা আবার শ্বেতসার হয় → রন্ধ্র বন্ধ। (বর্তমানে K<sup>+</sup> মতবাদই বেশি গ্রহণযোগ্য।)'],
    aba: ['ABA (পানির অভাব)', 'অ্যাবসিসিক অ্যাসিড (ABA) — পানির অভাবে বন্ধ', 'মাটিতে পানি কমলে মূল ও পাতায় ABA তৈরি হয়ে রক্ষীকোষে পৌঁছায় → K<sup>+</sup> ও অ্যানায়ন বাইরে বেরিয়ে যায় → পানি বেরিয়ে রক্ষীকোষ শিথিল হয় → দিনের বেলাতেও রন্ধ্র বন্ধ হয়, পানি বাঁচে।']
  },
  sl: [{ k: 'h', l: 'দিনের সময় (ঘণ্টা)', min: 0, max: 24, step: .5, val: 10, d: 1 }],
  art(g, C, ty, ctx) {
    const h = ctx.v.h, a = ty === 'aba' ? openAt(h) * .12 : openAt(h), Rg = BK.ramp(10), Re = BK.ramp(0), cx = 112, cy = 126, Lh = 80;
    ctx.a = a;
    E('rect', { x: 8, y: 30, width: 208, height: 196, rx: 10, fill: FK.alpha(Re.c, .12), stroke: FK.alpha(Re.c, .5) }, g);
    [[-1], [1]].forEach(([s]) => { E('path', { d: `M${cx} ${cy - Lh - 14}Q${cx + s * 110} ${cy - 40} ${cx + s * 96} ${cy}Q${cx + s * 110} ${cy + 40} ${cx} ${cy + Lh + 14}`, fill: 'none', stroke: FK.alpha(Re.dk, .55), 'stroke-width': 1 }, g); });
    E('path', { d: `M${cx} ${cy - Lh}Q${cx - 2 * (2 + 9 * a)} ${cy} ${cx} ${cy + Lh}Q${cx + 2 * (2 + 9 * a)} ${cy} ${cx} ${cy - Lh}Z`, fill: FK.alpha(C.fg, .1) }, g);
    guard(g, cx, cy, Lh, a, -1, Rg, C); guard(g, cx, cy, Lh, a, 1, Rg, C);
    T(g, 112, 22, 'রক্ষীকোষ (উপরের দৃশ্য)', { fs: 10.5, a: 'middle', w: 560, c: C.mu });
    T(g, 112, 222, a > .5 ? 'রন্ধ্র খোলা' : a > .15 ? 'আংশিক খোলা' : 'রন্ধ্র বন্ধ', { fs: 11.5, a: 'middle', w: 650, c: a > .15 ? BK.ramp(10).ink : BK.ramp(4).ink });
    /* ডান প্যানেল */
    const L = Math.max(0, Math.sin(PI * (h - 6) / 12)), bars = ty === 'starch' ? [['আলো', L, 6], ['pH', .2 + .6 * a, 0], ['শর্করা', a, 7], ['রসস্ফীতি', a, 5]] : [['আলো', L, 6], ['K+ ভেতরে', a, 2], [ty === 'aba' ? 'ABA' : 'ম্যালেট', ty === 'aba' ? .9 : a * .9, 3], ['রসস্ফীতি', a, 5]];
    bars.forEach(([s, v, r], i) => { const y = 44 + i * 40, R = BK.ramp(r); T(g, 226, y, s.replace('K+', 'K<tspan dy="-4" font-size="72%">+</tspan><tspan dy="4"></tspan>'), { fs: 10.5, w: 560, c: C.fg }); E('rect', { x: 226, y: y + 6, width: 120, height: 10, rx: 5, fill: FK.alpha(R.c, .15) }, g); E('rect', { x: 226, y: y + 6, width: Math.max(10, 120 * v), height: 10, rx: 5, fill: R.c }, g); if (s === 'pH') T(g, 346, y, FK.n(5 + 2 * a, 1), { fs: 10, a: 'end', c: R.ink }); });
    /* ২৪ ঘণ্টার লেখচিত্র */
    const gx = 26, gw = 310, gy = 240, gh = 34; let d = '';
    for (let k = 0; k <= 48; k++) { const hh = k / 2, v = ty === 'aba' ? openAt(hh) * .12 : openAt(hh); d += (k ? 'L' : 'M') + (gx + hh / 24 * gw).toFixed(1) + ' ' + (gy + gh - v * gh).toFixed(1); }
    E('rect', { x: gx, y: gy, width: gw * 6 / 24, height: gh, fill: FK.alpha(C.fg, .07) }, g); E('rect', { x: gx + gw * 18 / 24, y: gy, width: gw * 6 / 24, height: gh, fill: FK.alpha(C.fg, .07) }, g);
    E('path', { d, stroke: BK.ramp(10).c, 'stroke-width': 2, fill: 'none' }, g); E('path', { d: `M${gx} ${gy + gh}H${gx + gw}`, stroke: C.mu }, g);
    [0, 6, 12, 18, 24].forEach(v => T(g, gx + v / 24 * gw, gy + gh + 12, String(v), { fs: 9, a: 'middle', c: C.mu }));
    E('circle', { cx: gx + h / 24 * gw, cy: gy + gh - a * gh, r: 4, fill: BK.ramp(10).dk }, g);
  },
  more(ty, ctx) { const h = ctx.v.h; return `<div class="small">সময় ${FK.n(h, 1)} টা: ${h < 6 || h > 18 ? 'অন্ধকার — ' : 'আলো — '}রন্ধ্রের খোলা প্রায় ${Math.round((ctx.a || 0) * 100)}%।</div>`; },
  anim(g, C, ty, t, ctx) {
    if (!t) return; const a = ctx.a || 0, h = ctx.v.h, light = h > 6 && h < 18, cx = 112, cy = 126;
    const inn = ty === 'aba' ? false : light;
    for (let i = 0; i < 4; i++) { const u = (t * .35 + i / 4) % 1, s = i % 2 ? 1 : -1, y = cy - 50 + i * 30, x0 = cx + s * 96, x1 = cx + s * 30, x = inn ? x0 + (x1 - x0) * u : x1 + (x0 - x1) * u; if (ty === 'starch') B9.dot(g, x, y, 3, BK.ramp(5).dk, .9); else B9.ion(g, x, y, 'K^+', BK.ramp(2), 7, { fs: 7 }); }
    if (ty === 'starch') for (let i = 0; i < 4; i++) { const s = i % 2 ? 1 : -1, r = 2 + 4 * (1 - a) + Math.sin(t * 3 + i) * .4; E('ellipse', { cx: cx + s * (34 + 10 * a), cy: cy - 30 + i * 20, rx: r * 1.4, ry: r, fill: '#fff', stroke: C.mu, 'stroke-width': .7 }, g); }
    if (ty === 'aba') for (let i = 0; i < 3; i++) { const u = (t * .25 + i / 3) % 1; B9.chip(g, 40 + i * 70, 40 + u * 60, 'ABA', BK.ramp(3), { w: 34, h: 14, fs: 8.5 }); }
    if (ty === 'k' && light) for (let i = 0; i < 2; i++) { const u = (t * .4 + i / 2) % 1, s = i ? 1 : -1; B9.ion(g, cx + s * (40 + u * 50), cy + 60, 'H^+', BK.ramp(4), 6.5, { fs: 6.5, op: 1 - u * .6 }); }
  }
}));

/* ═════════ ১১. প্রস্বেদনের প্রভাবক ═════════ */
V.transpFactors = B9.gseg({
  id: 'trf', t: 'প্রস্বেদনের প্রভাবক', def: 'hum',
  cap: 'প্রস্বেদনের হার নির্ভর করে পাতা ও বাতাসের জলীয় বাষ্পের পার্থক্য এবং পত্ররন্ধ্র কতটা খোলা তার ওপর। প্রতিটি প্রভাবক এ দুটির কোনো একটিকে বদলায়। লেখচিত্রে চাপ দিলে ব্যাখ্যা।',
  types: {
    light: { b: 'আলো', t: 'আলো', d: 'আলোতে পত্ররন্ধ্র খোলে এবং পাতা গরম হয় — প্রস্বেদন বাড়ে; অন্ধকারে রন্ধ্র বন্ধ, কেবল সামান্য কিউটিকুলার প্রস্বেদন।', c: 6, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'আলো (% সর্বোচ্চ)', u: '%', f: x => .12 + .88 * (1 - Math.exp(-x / 22)), read: x => x < 5 ? 'অন্ধকার: রন্ধ্র বন্ধ — শুধু কিউটিকুলার।' : 'রন্ধ্র খোলা।' },
    temp: { b: 'তাপমাত্রা', t: 'তাপমাত্রা', d: 'তাপ বাড়লে পানির বাষ্পীভবন ও বাতাসের বাষ্প ধারণক্ষমতা বাড়ে — প্রস্বেদন বাড়ে। খুব বেশি তাপে (প্রায় 35–40 °C এর ওপরে) পানির অভাবে রন্ধ্র বন্ধ হতে থাকে।', c: 2, xr: [0, 50], xt: [0, 10, 20, 30, 40, 50], lx: 'তাপমাত্রা (°C)', u: ' °C', f: x => x <= 36 ? .05 + .95 * Math.pow(x / 36, 1.6) : Math.max(.15, 1 - .9 * Math.pow((x - 36) / 14, 2)), read: x => x > 38 ? 'অতিরিক্ত তাপে রন্ধ্র বন্ধ — দুপুরে পাতা ঢলে পড়লে এমন হয়।' : 'তাপ বাড়লে বাষ্পীভবন বাড়ে।' },
    hum: { b: 'আর্দ্রতা', t: 'বাতাসের আপেক্ষিক আর্দ্রতা', d: 'বাতাস শুষ্ক হলে পাতা ও বাতাসের বাষ্প পার্থক্য বেশি — দ্রুত প্রস্বেদন। আর্দ্রতা বাড়লে প্রস্বেদন কমে; 100% এ প্রায় বন্ধ (তখন গাটেশন হতে পারে)।', c: 5, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'আপেক্ষিক আর্দ্রতা (%)', u: '%', f: x => Math.max(.03, 1 - .97 * x / 100), read: x => x > 90 ? 'প্রায় সম্পৃক্ত বাতাস — বর্ষার সকালে পাতার কিনারায় পানির ফোঁটা (গাটেশন)।' : 'শুষ্ক বাতাস প্রস্বেদন বাড়ায়।' },
    wind: { b: 'বাতাস', t: 'বায়ুপ্রবাহ', d: 'মৃদু বাতাস পাতার চারপাশের আর্দ্র স্তর সরিয়ে দেয় — প্রস্বেদন দ্রুত বাড়ে, তারপর স্থির হয়। খুব জোরালো বাতাসে পাতা ঠান্ডা হয় ও রন্ধ্র বন্ধ হতে পারে — সামান্য কমে।', c: 9, xr: [0, 40], xt: [0, 10, 20, 30, 40], lx: 'বাতাসের বেগ (km/h)', u: ' km/h', f: x => .25 + .75 * (1 - Math.exp(-x / 5)) - (x > 22 ? (x - 22) * .016 : 0), read: x => x > 25 ? 'ঝড়ো বাতাস — রন্ধ্র বন্ধ হতে শুরু করে।' : 'আর্দ্র স্তর সরে যায়।' },
    soil: { b: 'মাটির পানি', t: 'মাটিতে পানির পরিমাণ', d: 'মাটিতে পর্যাপ্ত পানি থাকলে শোষণ চলে, প্রস্বেদন অবাধ। পানি কমে স্থায়ী ঢলে পড়া বিন্দুর কাছে গেলে রক্ষীকোষ শিথিল হয়, ABA তৈরি হয় — প্রস্বেদন প্রায় বন্ধ।', c: 11, xr: [0, 100], xt: [0, 25, 50, 75, 100], lx: 'মাটির পানি (% ধারণক্ষমতা)', u: '%', f: x => .05 + .95 / (1 + Math.exp(-(x - 32) / 7)), read: x => x < 20 ? 'ঢলে পড়ার অবস্থা — ABA রন্ধ্র বন্ধ করে।' : 'যথেষ্ট পানি।' },
    co2: { b: 'CO<sub>2</sub>', t: 'বাতাসে CO2 এর ঘনত্ব', d: 'CO<sub>2</sub> বেশি হলে রক্ষীকোষ বন্ধ হতে থাকে — প্রস্বেদন কমে। (বর্তমান বাতাসে প্রায় 420 ppm।)', c: 9, xr: [0, 1500], xt: [0, 500, 1000, 1500], lx: 'CO2 (ppm)', u: ' ppm', f: x => 1 - .62 * x / (x + 500), mk: [[420, '≈ এখনকার বাতাস', 1]], read: x => x > 800 ? 'উচ্চ CO2 — রন্ধ্র আংশিক বন্ধ।' : 'স্বাভাবিক।' }
  }
});

/* ═════════ ১২. পটোমিটার ═════════ */
const POT = { still: 3, wind: 6.5, dark: .6, humid: 1.2 };
const POTr = .5;  /* কৈশিক নলের অভ্যন্তরীণ ব্যাসার্ধ, mm */
V.potometer = Object.assign({}, B9.seg({
  id: 'pot', t: 'গ্যানংয়ের পটোমিটার — প্রস্বেদনের হার মাপা', H: 250, def: 'still',
  cap: 'কাটা পাতাসহ ডাল পানিভর্তি বোতলে বায়ুরোধীভাবে বসানো, পাশে দাগাঙ্কিত সরু কৈশিক নল। ডালটি যত পানি টানে, নলের বায়ুবুদবুদ তত দ্রুত ডালের দিকে সরে। শোষিত পানির প্রায় সবটাই প্রস্বেদিত হয় — তাই বুদবুদের সরণ দিয়ে প্রস্বেদনের হার পাওয়া যায়। পরিবেশ বদলে চালাও।',
  types: {
    still: ['স্বাভাবিক', 'স্বাভাবিক আলো ও স্থির বাতাস', 'বুদবুদ মাঝারি গতিতে সরে।'],
    wind: ['পাখা', 'পাখার বাতাস', 'পাতার চারপাশের আর্দ্র বায়ুস্তর সরে যায় — প্রস্বেদন দ্রুত, বুদবুদ দ্রুত সরে।'],
    dark: ['অন্ধকার', 'অন্ধকার ঘর', 'পত্ররন্ধ্র বন্ধ — শুধু কিউটিকুলার প্রস্বেদন; বুদবুদ খুব ধীরে সরে।'],
    humid: ['পলিথিন ব্যাগ', 'ডাল পলিথিন ব্যাগে ঢাকা (আর্দ্র বাতাস)', 'ব্যাগের ভেতরের বাতাস দ্রুত সম্পৃক্ত হয় — প্রস্বেদন অনেক কমে, ব্যাগের গায়ে পানির ফোঁটা জমে।']
  },
  art(g, C, ty) {
    const Rw = BK.ramp(5), Rg = BK.ramp(10), Rgl = BK.ramp(9);
    E('path', { d: 'M60 120v-16h40v16Q132 128 132 168Q132 210 80 212Q28 210 28 168Q28 128 60 120Z', fill: FK.alpha(Rw.c, .35), stroke: Rgl.dk, 'stroke-width': 1.5 }, g);
    E('rect', { x: 58, y: 96, width: 44, height: 12, rx: 3, fill: BK.ramp(2).c }, g);
    E('path', { d: 'M80 98V24', stroke: Rg.dk, 'stroke-width': 3 }, g);
    [[70, -1], [52, 1], [36, -1], [24, 1]].forEach(([y, s], i) => { const L = 34 - i * 4; E('path', { d: `M80 ${y}q${s * L * .4} ${-12} ${s * L} ${-4}q${-s * L * .5} ${12} ${-s * L} ${4}Z`, fill: ty === 'dark' ? FK.alpha(Rg.c, .4) : Rg.c, stroke: Rg.dk }, g); });
    E('path', { d: 'M124 190H346', stroke: Rgl.dk, 'stroke-width': 9, 'stroke-linecap': 'round' }, g); E('path', { d: 'M124 190H346', stroke: FK.alpha(Rw.c, .9), 'stroke-width': 5 }, g);
    for (let x = 150; x <= 340; x += 10) E('path', { d: `M${x} ${x % 30 === 0 ? 198 : 196}v-${x % 30 === 0 ? 4 : 2}`, stroke: C.fg, 'stroke-width': .8, transform: 'translate(0 6)' }, g);
    for (let k = 0; k <= 6; k++) T(g, 340 - k * 30, 216, String(k * 30), { fs: 8.5, a: 'middle', c: C.mu });
    T(g, 346, 230, 'mm', { fs: 9, a: 'end', c: C.mu });
    E('path', { d: 'M160 186V140M152 120h16l-5 20h-6Z', stroke: Rgl.dk, fill: FK.alpha(Rw.c, .3), 'stroke-width': 1.4 }, g); E('rect', { x: 154, y: 156, width: 12, height: 6, rx: 2, fill: BK.ramp(2).c }, g);
    T(g, 176, 132, 'জলাধার ও স্টপকক', { fs: 9.5, c: C.mu }); T(g, 220, 176, 'কৈশিক নল (r = 0.5 mm)', { fs: 9.5, c: C.mu });
    if (ty === 'wind') { E('circle', { cx: 300, cy: 60, r: 22, fill: 'none', stroke: C.mu, 'stroke-width': 1.4 }, g); E('path', { d: 'M300 82v40', stroke: C.mu, 'stroke-width': 2 }, g); T(g, 300, 30, 'পাখা', { fs: 10, a: 'middle', c: C.mu }); }
    if (ty === 'dark') { E('rect', { x: 0, y: 0, width: 360, height: 250, rx: 12, fill: FK.alpha('#000', .2) }, g); T(g, 300, 40, 'অন্ধকার', { fs: 11, a: 'middle', w: 600, c: C.fg }); }
    if (ty === 'humid') E('path', { d: 'M44 100Q30 40 60 8H100Q130 40 116 100Z', fill: FK.alpha(C.fg, .07), stroke: C.mu, 'stroke-dasharray': '4 3' }, g);
  },
  anim(g, C, ty, t) {
    const r = POT[ty], span = 200, min = (t || 0) % (span / r), d = r * min, bx = 340 - d;
    E('ellipse', { cx: bx.toFixed(1), cy: 190, rx: 5, ry: 2.6, fill: '#fff', stroke: C.fg, 'stroke-width': .8 }, g);
    const vol = PI * POTr * POTr * d;
    T(g, 240, 26 + (ty === 'wind' ? 100 : 0), `সময় ${FK.n(min, 0)} মিনিট`, { fs: 10.5, c: C.fg }); T(g, 240, 42 + (ty === 'wind' ? 100 : 0), `সরণ ${FK.n(d, 0)} mm`, { fs: 10.5, c: C.fg }); T(g, 240, 58 + (ty === 'wind' ? 100 : 0), `আয়তন ≈ ${FK.n(vol, 1)} mm³`, { fs: 10.5, w: 600, c: BK.ramp(5).ink });
    if (ty === 'wind' && t) for (let i = 0; i < 3; i++) { const u = (t * .8 + i / 3) % 1; E('path', { d: `M${276 - u * 150} ${50 + i * 12}h-14`, stroke: C.mu, 'stroke-width': 1.4, opacity: 1 - u }, g); }
    if (ty === 'humid' && t) for (let i = 0; i < 5; i++) E('circle', { cx: 48 + (i % 2) * 64 + Math.sin(i) * 4, cy: 30 + i * 14, r: 2 + .6 * Math.sin(t * 2 + i), fill: BK.ramp(5).c, opacity: .8 }, g);
  },
  more(ty) { const r = POT[ty]; return `<div class="small">উদাহরণ হিসাব: হার ${FK.n(r, 1)} mm/মিনিট → ১০ মিনিটে সরণ ${FK.n(r * 10, 0)} mm; আয়তন = πr²d = 3.1416 × (0.5)² × ${FK.n(r * 10, 0)} ≈ <b>${FK.n(PI * .25 * r * 10, 1)} mm³</b>। (পটোমিটার আসলে পানি শোষণ মাপে — শোষিত পানির প্রায় 95–99% প্রস্বেদিত হয়।)</div>`; }
}));

/* ═════════ ১৩. ব্যবহারিক: পত্ররন্ধ্র পর্যবেক্ষণ ═════════ */
V.stomaPeel = Object.assign({ t: 'ব্যবহারিক: পত্ররন্ধ্রের গঠন পর্যবেক্ষণ', k: ['anim', 'steps', 'lab'], cap: 'পাতার নিচের ত্বকের পাতলা খোসা তুলে রঞ্জিত করে অণুবীক্ষণে দেখলে রক্ষীকোষ, রন্ধ্র, সহকারী কোষ ও ত্বককোষ পরিষ্কার দেখা যায়। শেষ ধাপে চিহ্নিত চিত্র।' }, BK.steps({
  W: 360, H: 250, label: 'পত্ররন্ধ্র পর্যবেক্ষণ', dur: 2.8,
  stages: [
    { t: 'পাতা সংগ্রহ', en: 'Collect a fresh leaf', d: 'রয়ো (Rhoeo/Tradescantia), কলাবতী বা যেকোনো তাজা দ্বিবীজপত্রী পাতা নাও। নিচের ত্বকে পত্ররন্ধ্র বেশি থাকে।' },
    { t: 'নিচের ত্বকের খোসা তোলা', en: 'Peel the lower epidermis', d: 'পাতা একটু ভাঁজ করে ছিঁড়ে বা ফরসেপ দিয়ে টেনে নিচের ত্বকের স্বচ্ছ পাতলা স্তর তুলে সাথে সাথে ওয়াচগ্লাসের পানিতে রাখো — শুকাতে দিও না।' },
    { t: 'রঞ্জিত করা', en: 'Stain with safranin', d: 'খোসাটি স্যাফ্রানিন দ্রবণে (প্রায় 1%) 1–2 মিনিট রাখো, তারপর পানিতে ধুয়ে বাড়তি রং সরাও।' },
    { t: 'স্লাইডে স্থাপন', en: 'Mount in glycerine', d: 'পরিষ্কার স্লাইডে এক ফোঁটা গ্লিসারিনে খোসা রেখে নিডল দিয়ে আস্তে কভারস্লিপ নামাও — যাতে বায়ুবুদবুদ না থাকে। বাড়তি গ্লিসারিন ব্লটিং পেপারে মুছে নাও।' },
    { t: 'পর্যবেক্ষণ ও চিহ্নিতকরণ', en: 'Observe and label', d: 'প্রথমে কম, পরে বেশি বিবর্ধনে দেখো। দেখা যাবে: বৃক্কাকার রক্ষীকোষ (ক্লোরোপ্লাস্টযুক্ত), মাঝে রন্ধ্র, চারপাশে সহকারী কোষ ও আঁকাবাঁকা প্রাচীরের ত্বককোষ (ক্লোরোপ্লাস্টহীন)।' }
  ],
  draw(g, C, s, u) {
    const Rg = BK.ramp(10), Rs = BK.ramp(4), Rw = BK.ramp(5);
    if (s === 0) { const k = FK.ease(u); E('path', { d: `M80 ${200 - 60 * k}Q180 ${60 - 40 * k} 280 ${200 - 60 * k}Q180 ${230 - 40 * k} 80 ${200 - 60 * k}Z`, fill: Rg.c, stroke: Rg.dk }, g); E('path', { d: `M80 ${200 - 60 * k}L280 ${200 - 60 * k}`, stroke: Rg.dk }, g); return; }
    if (s === 1) { E('path', { d: 'M60 170Q180 80 300 170Q180 210 60 170Z', fill: Rg.c, stroke: Rg.dk }, g); const k = FK.ease(u); E('path', { d: `M180 182Q${200 + 60 * k} ${190 - 50 * k} ${220 + 80 * k} ${150 - 60 * k}`, stroke: FK.alpha(C.fg, .5), 'stroke-width': 9, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d: `M${226 + 80 * k} ${146 - 60 * k}l16 -10M${226 + 80 * k} ${146 - 60 * k}l18 -2`, stroke: C.fg, 'stroke-width': 2 }, g); T(g, 180, 236, 'স্বচ্ছ খোসা টেনে তোলা', { fs: 11, a: 'middle', c: C.mu }); return; }
    if (s === 2) { E('ellipse', { cx: 180, cy: 150, rx: 110, ry: 34, fill: FK.alpha(Rs.c, .2 + .4 * u), stroke: C.mu }, g); E('rect', { x: 140, y: 140, width: 80, height: 14, rx: 4, fill: FK.alpha(Rs.c, .3 + .5 * u) }, g); T(g, 180, 222, 'স্যাফ্রানিন (1%) — 1–2 মিনিট', { fs: 11, a: 'middle', c: Rs.ink }); E('path', { d: `M250 ${60 + 40 * u}v20`, stroke: Rs.c, 'stroke-width': 3 }, g); return; }
    if (s === 3) { E('rect', { x: 50, y: 130, width: 260, height: 50, rx: 4, fill: FK.alpha(Rw.c, .15), stroke: C.mu }, g); E('rect', { x: 150, y: 146, width: 60, height: 16, fill: FK.alpha(Rs.c, .5) }, g); const a = -40 * (1 - FK.ease(u)); E('rect', { x: 132, y: 140, width: 96, height: 4, fill: FK.alpha(C.fg, .25), stroke: C.mu, transform: `rotate(${a.toFixed(1)} 132 142)` }, g); T(g, 180, 214, 'গ্লিসারিন + কভারস্লিপ (কোণ করে নামাও)', { fs: 11, a: 'middle', c: C.mu }); return; }
    const cx = 150, cy = 128, R = 104, sz = 34, N = 8, x0 = cx - 4 * sz, y0 = cy - 4 * sz;
    const cid = 'spv' + Math.round(rnd(u + 3) * 1e6);
    const cp = E('clipPath', { id: cid }, g); E('circle', { cx, cy, r: R - 2 }, cp);
    E('circle', { cx, cy, r: R, fill: FK.alpha(Rs.c, .07), stroke: C.mu, 'stroke-width': 2 }, g);
    const mesh = E('g', { 'clip-path': `url(#${cid})` }, g), Vx = (i, j) => [x0 + i * sz + (rnd(i * 17 + j * 5 + 1) - .5) * 14, y0 + j * sz + (rnd(i * 7 + j * 19 + 2) - .5) * 14];
    let d = ''; const wav = (p, q, k) => { const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2, dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy) || 1, o = (rnd(k) - .5) * 9; return `M${p[0].toFixed(1)} ${p[1].toFixed(1)}Q${(mx - dy / L * o).toFixed(1)} ${(my + dx / L * o).toFixed(1)} ${q[0].toFixed(1)} ${q[1].toFixed(1)}`; };
    for (let i = 0; i <= N; i++) for (let j = 0; j <= N; j++) { if (i < N) d += wav(Vx(i, j), Vx(i + 1, j), i * 31 + j * 3 + 7); if (j < N) d += wav(Vx(i, j), Vx(i, j + 1), i * 13 + j * 29 + 11); }
    E('path', { d, fill: 'none', stroke: FK.alpha(Rs.dk, .75), 'stroke-width': 1.2 }, mesh);
    [[116, 112], [196, 168]].forEach(([x, y]) => { const s1 = 17; E('ellipse', { cx: x, cy: y, rx: 30, ry: 26, fill: '#fbeff0', stroke: FK.alpha(Rs.dk, .75), 'stroke-width': 1.2 }, mesh); E('path', { d: `M${x - 30} ${y}h-6M${x + 30} ${y}h6M${x} ${y - 26}v-6M${x} ${y + 26}v6`, stroke: FK.alpha(Rs.dk, .75), 'stroke-width': 1.2 }, mesh); E('path', { d: `M${x} ${y - s1}Q${x - 6} ${y} ${x} ${y + s1}Q${x - 26} ${y} ${x} ${y - s1}Z M${x} ${y - s1}Q${x + 6} ${y} ${x} ${y + s1}Q${x + 26} ${y} ${x} ${y - s1}Z`, fill: FK.alpha(Rg.c, .55), stroke: Rs.dk, 'stroke-width': 1.2 }, g); E('path', { d: `M${x} ${y - s1 + 3}Q${x - 3} ${y} ${x} ${y + s1 - 3}Q${x + 3} ${y} ${x} ${y - s1 + 3}Z`, fill: FK.alpha(C.fg, .25) }, g); for (let j = 0; j < 3; j++) { E('circle', { cx: x - 9, cy: y - 7 + j * 7, r: 1.8, fill: Rg.dk }, g); E('circle', { cx: x + 9, cy: y - 7 + j * 7, r: 1.8, fill: Rg.dk }, g); } });
    B9.lab(g, 116, 90, 290, 56, 'সহকারী কোষ', C, { a: 'start' }); B9.lab(g, 104, 112, 290, 92, 'রক্ষীকোষ', C, { a: 'start' }); B9.lab(g, 116, 122, 290, 128, 'রন্ধ্র', C, { a: 'start' }); B9.lab(g, 205, 168, 290, 168, 'ক্লোরোপ্লাস্ট', C, { a: 'start' }); B9.lab(g, 150, 214, 290, 206, 'ত্বককোষ', C, { a: 'start' });
  }
}));

/* ═════════ ১৪. প্রস্বেদনের গুরুত্ব ═════════ */
V.transpImp = Object.assign({ t: 'প্রস্বেদন — উপকারিতা ও অপকারিতা', k: ['tree', 'int'], cap: 'কার্টিস (1926) প্রস্বেদনকে "প্রয়োজনীয় অমঙ্গল" বলেছেন — পানি অপচয় হয়, তবু উদ্ভিদের জীবনে এর ভূমিকা অপরিহার্য। শাখায় চাপ দিলে খোলে।' }, BK.tree({
  t: 'প্রস্বেদন', d: 'উদ্ভিদের বায়বীয় অংশ, প্রধানত পাতা থেকে বাষ্প আকারে পানি হারানো।',
  c: [
    { t: 'উপকারিতা', d: 'উদ্ভিদের জীবনে প্রয়োজনীয়তা।', c: [
      { t: 'পানি শোষণ ও পরিবহন', d: 'প্রস্বেদন টান (সংসক্তি-টান) মূল থেকে পাতা পর্যন্ত পানির স্তম্ভ টেনে তোলে।' },
      { t: 'খনিজ লবণের বণ্টন', d: 'জাইলেমের পানির স্রোতের সাথে খনিজ লবণ সারা দেহে ছড়ায়; গণপ্রবাহে কিছু খনিজ শোষণও বাড়ে।' },
      { t: 'তাপমাত্রা নিয়ন্ত্রণ', d: '1 g পানি বাষ্প হতে প্রায় 2.4–2.5 kJ সুপ্ত তাপ নেয় — পাতা ঠান্ডা থাকে, প্রখর রোদে পুড়ে যায় না।' },
      { t: 'সালোকসংশ্লেষণে সহায়তা', d: 'খোলা পত্ররন্ধ্র দিয়ে CO<sub>2</sub> ঢোকে; প্রস্বেদন ও গ্যাস বিনিময় একই পথে।' },
      { t: 'রসস্ফীতি ও গঠন', d: 'পানির নিরবচ্ছিন্ন প্রবাহ কোষকে সতেজ রাখে, কোষ প্রসারণ ও বৃদ্ধিতে সাহায্য করে।' }
    ] },
    { t: 'অপকারিতা', d: 'ক্ষতিকর দিক।', c: [
      { t: 'পানির অপচয়', d: 'শোষিত পানির প্রায় 95–99% প্রস্বেদনে বেরিয়ে যায়; সামান্য অংশই বিপাকে লাগে।' },
      { t: 'ঢলে পড়া', d: 'শোষণের চেয়ে প্রস্বেদন বেশি হলে কোষ শিথিল হয়ে গাছ ঢলে পড়ে; দীর্ঘ হলে স্থায়ী ঢলে পড়া ও মৃত্যু।' },
      { t: 'বৃদ্ধি ও ফলন কমে', d: 'পানির অভাবে রন্ধ্র বন্ধ হলে CO<sub>2</sub> ঢুকতে পারে না — সালোকসংশ্লেষণ কমে।' }
    ] },
    { t: 'প্রয়োজনীয় অমঙ্গল', d: 'কার্টিস (1926): ক্ষতিকর হলেও অপরিহার্য — কারণ CO<sub>2</sub> নিতে রন্ধ্র খোলা রাখতেই হয়, আর খোলা রন্ধ্রে পানি হারানো অনিবার্য।' }
  ]
}, { colW: 112 }));

/* ═════════ তুলনা (৯.২) ═════════ */
V.cmpStomaCut = Object.assign({ t: 'পত্ররন্ধ্রীয় বনাম কিউটিকুলার প্রস্বেদন', k: ['compare', 'int'], cap: 'সারিতে চাপ দিলে চিহ্নিত হয়।' }, BK.compare({
  a: 'পত্ররন্ধ্রীয় প্রস্বেদন', b: 'কিউটিকুলার প্রস্বেদন',
  rows: [
    ['পথ', 'পত্ররন্ধ্রের ছিদ্র দিয়ে', 'ত্বকের কিউটিকল স্তর ভেদ করে'],
    ['পরিমাণ', 'মোট প্রস্বেদনের প্রায় 80–90%', 'প্রায় 5–10% (পাতলা কিউটিকলে বেশি)'],
    ['নিয়ন্ত্রণ', 'রক্ষীকোষ খুলে-বন্ধ করে নিয়ন্ত্রণ করে', 'উদ্ভিদের নিয়ন্ত্রণ নেই'],
    ['সময়', 'প্রধানত দিনে (রন্ধ্র খোলা)', 'দিন-রাত সবসময়'],
    ['গ্যাস বিনিময়', 'একই পথে CO<sub>2</sub> ও O<sub>2</sub> বিনিময় হয়', 'গ্যাস বিনিময়ে ভূমিকা নেই'],
    ['প্রভাবক', 'আলো, CO<sub>2</sub>, ABA, K<sup>+</sup> — রন্ধ্রের অবস্থা', 'কিউটিকলের পুরুত্ব ও বাষ্প পার্থক্য']
  ]
}));
V.cmpStromaStoma = Object.assign({ t: 'স্ট্রোমা বনাম স্টোম্যাটা', k: ['compare', 'int'], cap: 'বানানে কাছাকাছি, কিন্তু একেবারে আলাদা জিনিস — পরীক্ষায় প্রায়ই জিজ্ঞেস করা হয়।' }, BK.compare({
  a: 'স্ট্রোমা (Stroma)', b: 'স্টোম্যাটা (Stomata)',
  rows: [
    ['কী', 'ক্লোরোপ্লাস্টের ভেতরের বর্ণহীন তরল ধাত্র', 'পাতার ত্বকে রক্ষীকোষবেষ্টিত ছিদ্র (পত্ররন্ধ্র)'],
    ['অবস্থান', 'ক্লোরোপ্লাস্টের অভ্যন্তরে, থাইলাকয়েডের চারপাশে', 'পাতা ও কচি কাণ্ডের ত্বকে, সাধারণত পাতার নিচের পিঠে বেশি'],
    ['গঠন', 'এনজাইম (RuBisCO), DNA, 70S রাইবোজোম, শ্বেতসার কণা', 'দুটি বৃক্কাকার বা ডাম্বেলাকার রক্ষীকোষ, রন্ধ্র, সহকারী কোষ'],
    ['আকার', 'অতি-আণুবীক্ষণিক (কোষের অঙ্গাণুর অংশ)', 'আণুবীক্ষণিক — একাধিক কোষে গঠিত'],
    ['কাজ', 'আলোক নিরপেক্ষ পর্যায় (ক্যালভিন চক্র) — শর্করা তৈরি', 'গ্যাস বিনিময় (CO<sub>2</sub>, O<sub>2</sub>) ও প্রস্বেদন'],
    ['বহুবচন', 'স্ট্রোমা (একবচন-বহুবচন একই)', 'স্টোমা (একবচন), স্টোম্যাটা (বহুবচন)']
  ]
}));
V.cmpTranspEvap = Object.assign({ t: 'প্রস্বেদন বনাম বাষ্পীভবন', k: ['compare', 'int'], cap: 'দুটিতেই পানি বাষ্প হয়, কিন্তু প্রস্বেদন জীবিত উদ্ভিদের শারীরবৃত্তীয় প্রক্রিয়া।' }, BK.compare({
  a: 'প্রস্বেদন', b: 'বাষ্পীভবন',
  rows: [
    ['প্রকৃতি', 'জৈবিক (শারীরবৃত্তীয়) প্রক্রিয়া', 'ভৌত প্রক্রিয়া'],
    ['কোথায়', 'জীবিত উদ্ভিদের বায়বীয় অংশ থেকে', 'যেকোনো মুক্ত পানির পৃষ্ঠ বা ভেজা বস্তু থেকে'],
    ['নিয়ন্ত্রণ', 'রক্ষীকোষ দিয়ে উদ্ভিদ নিয়ন্ত্রণ করে', 'কোনো জৈবিক নিয়ন্ত্রণ নেই'],
    ['অতিক্রম', 'কোষপ্রাচীর, ঝিল্লি ও পত্ররন্ধ্র পেরিয়ে', 'সরাসরি পৃষ্ঠ থেকে'],
    ['প্রভাবক', 'ভৌত প্রভাবক ছাড়াও আলো, পাতার গঠন, ABA, K<sup>+</sup>', 'শুধু তাপ, আর্দ্রতা, বাতাস, পৃষ্ঠের ক্ষেত্রফল'],
    ['রাতে', 'রন্ধ্র বন্ধ — প্রায় বন্ধ', 'চলতে থাকে']
  ]
}));
})();
