/* ═══════════════════════════════════════════════════════════════════
   visuals0c — অধ্যায় ৫ (শ্বসন) এর শারীরস্থান-জ্যামিতি (B25 এ যোগ হয়)
   মাথা-গলার মধ্যচ্ছেদ (headSag), বক্ষের সম্মুখ দৃশ্যে ফুসফুস (thorax), শ্বাসনালি-বৃক্ষ (btree),
   অ্যালভিওলাস গুচ্ছ (alvCluster), পাঁজর (পাশ থেকে) — কয়েকটি চিত্রে একই জ্যামিতি ব্যবহার হয়।
   রঙ: ফুসফুস ফ্যাকাশে গোলাপি-স্পঞ্জি, তরুণাস্থি নীলাভ-সাদা, অস্থি হাতির দাঁত, শ্লেষ্মাস্তর গোলাপি।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, E = FK.el, BK = window.BK, T = BK.T, B = window.B25, PI = Math.PI;
const f1 = v => (+v).toFixed(1);
const sm = (p, c, k) => B.smooth(p, c, k);
B.f1 = f1; B.sm = sm;

/* ফুসফুসের রং */
const LUNG = { lt: '#fbe1df', c: '#eeb1ae', dk: '#b46a6c', sp: '#d98f8e' };
B.LUNG = LUNG;
const memo = (svg, key, mk) => { const m = svg._b25s || (svg._b25s = {}); return m[key] || (m[key] = mk()); };
const svgOf = g => g.ownerSVGElement || g;
let gid = 0;
const defs = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };
/* ফুসফুসের গ্রেডিয়েন্ট (একবার) */
B.lungG = g => { const svg = svgOf(g); return memo(svg, 'lungG', () => { const id = 'b25lg' + (++gid), gr = E('radialGradient', { id, cx: .42, cy: .35, r: .8 }, defs(svg));
  [[0, LUNG.lt], [.6, LUNG.c], [1, '#cf8c8c']].forEach(([o, c]) => E('stop', { offset: o, 'stop-color': c }, gr)); return `url(#${id})`; }); };
/* স্পঞ্জের মতো বুনট (ছোট বৃত্ত) */
B.lungPat = g => { const svg = svgOf(g); return memo(svg, 'lungP', () => { const id = 'b25lp' + (++gid), P = E('pattern', { id, patternUnits: 'userSpaceOnUse', width: 7, height: 7 }, defs(svg));
  E('circle', { cx: 2, cy: 2, r: 1.4, fill: 'none', stroke: FK.alpha(LUNG.dk, .28), 'stroke-width': .45 }, P); E('circle', { cx: 5.5, cy: 5, r: 1.1, fill: 'none', stroke: FK.alpha(LUNG.dk, .22), 'stroke-width': .4 }, P); return `url(#${id})`; }); };

/* ═══ মাথা-গলার মধ্যরেখা বরাবর ছেদ (বাঁ দিকে মুখ), স্থানীয় স্থানাঙ্ক ~ 0–190 × 0–210 ═══
   o = { lab: অংশের অবস্থান ফেরত, open: ০→১ গ্লটিস খোলা, swallow } */
const HEAD = {
  skin: [[112, 0], [86, 4], [66, 16], [55, 34], [51, 52], [53, 62], [49, 70], [41, 84], [32, 96], [27, 101], [31, 106], [40, 109], [45, 110], [42, 117], [41, 122], [45, 126], [42, 131], [43, 138], [49, 143], [46, 150], [46, 160], [52, 168], [66, 172], [80, 176], [86, 192], [88, 212], [140, 212], [140, 186], [146, 166], [160, 150], [172, 128], [180, 100], [181, 70], [172, 38], [152, 12], [132, 2]],
  /* নাসাগহ্বর (পার্শ্বপ্রাচীর) — নাসারন্ধ্র থেকে কোয়ানা */
  nasal: [[36, 104], [40, 94], [50, 80], [58, 68], [70, 64], [86, 68], [100, 76], [108, 86], [110, 100], [108, 110], [96, 112], [70, 112], [48, 111], [40, 109]],
  /* মুখগহ্বর + জিহ্বা */
  palate: [[44, 112], [70, 112], [96, 112], [100, 114], [96, 117], [70, 117], [46, 116]],
  soft: [[98, 114], [106, 116], [112, 122], [114, 130], [111, 132], [106, 124], [99, 119]],
  tongue: [[48, 128], [60, 120], [80, 118], [98, 122], [106, 132], [108, 146], [104, 156], [92, 160], [74, 156], [60, 146], [50, 138]],
  /* গলবিল — সামনের দিক (নাক → মুখ → জিহ্বার গোড়া) ও পেছনের প্রাচীর */
  phB: [[110, 80], [120, 86], [124, 100], [125, 118], [125, 140], [124, 162], [122, 180], [121, 212]],
  phF: [[110, 100], [111, 112], [114, 132], [109, 148], [108, 156]],
  epi: [[106, 152], [110, 146], [115, 144], [116, 148], [111, 156], [108, 162]],
  /* স্বরযন্ত্র (থাইরয়েড তরুণাস্থি ও ক্রিকয়েড), শ্বাসনালি, অন্ননালি */
  thy: [[84, 158], [96, 156], [104, 160], [106, 174], [100, 180], [88, 180], [84, 170]],
  cri: [[89, 182], [104, 181], [105, 188], [90, 189]],
  trF: [[90, 160], [90, 212]], trB: [[108, 162], [108, 212]],
  eso: [[110, 176], [120, 176], [120, 212], [110, 212]],
  /* সাইনাস */
  front: [[57, 42], [62, 37], [68, 40], [68, 50], [62, 54], [57, 51]],
  sphen: [[102, 68], [112, 66], [117, 72], [115, 80], [106, 81], [101, 75]],
  /* মস্তিষ্কের তল (করোটি গহ্বরের মেঝে) */
  cran: [[60, 30], [76, 22], [100, 20], [130, 24], [156, 40], [168, 70], [164, 96], [146, 98], [124, 84], [102, 60], [78, 56], [64, 50]]
};
B.HEAD = HEAD;
B.headSag = (g, C, o = {}) => {
  const sk = B.TS('skin'), mu = B.TS('muc'), bo = B.TS('bone'), ca = B.TS('cart');
  /* ত্বক ও দেহ */
  E('path', { d: sm(HEAD.skin, true, .45), fill: B.lin(g, 'skin', 0), stroke: sk.dk, 'stroke-width': .9 }, g);
  /* করোটি গহ্বর (মস্তিষ্ক) */
  E('path', { d: sm(HEAD.cran, true, .5), fill: '#efe2d8', stroke: '#c8ad9a', 'stroke-width': .7 }, g);
  E('path', { d: sm(HEAD.cran.slice(0, 7).map(([x, y]) => [x + 3, y + 5]), false, .5), stroke: '#d8c4b4', 'stroke-width': .6, fill: 'none' }, g);
  /* মেরুদণ্ডের কশেরুকা (গলার) */
  for (let i = 0; i < 7; i++) { const y = 96 + i * 16; E('path', { d: `M128 ${y}h16q4 7 0 13h-16q-3 -7 0 -13Z`, fill: bo.lt, stroke: bo.dk, 'stroke-width': .6 }, g); }
  /* গলবিল ও মুখগহ্বরের বাতাস-ভরা জায়গা (গাঢ় গোলাপি শ্লেষ্মাস্তর) */
  const air = sm([[110, 80], [120, 86], [124, 100], [125, 118], [125, 140], [124, 162], [122, 176], [110, 176], [108, 162], [109, 148], [114, 132], [111, 112], [110, 100]], true, .4);
  E('path', { d: air, fill: '#f7d5d0', stroke: mu.dk, 'stroke-width': .8 }, g);
  /* মুখগহ্বর */
  E('path', { d: sm([[44, 118], [70, 118], [98, 120], [108, 134], [108, 150], [100, 158], [70, 158], [50, 146], [44, 130]], true, .4), fill: '#f2c4bf', stroke: mu.dk, 'stroke-width': .6 }, g);
  /* নাসাগহ্বর */
  E('path', { d: sm(HEAD.nasal, true, .4), fill: '#f7d9d4', stroke: mu.dk, 'stroke-width': .8 }, g);
  /* নাসিকা শঙ্খ (কঞ্চা) — উপর, মধ্য, নিচ; প্রতিটির নিচে মিয়াটাস */
  const conch = (x0, x1, y, h) => sm([[x0, y], [x0 + (x1 - x0) * .25, y - h * .45], [x1 - 4, y - h * .2], [x1, y + h * .35], [x1 - 6, y + h * .7], [x0 + (x1 - x0) * .3, y + h * .55], [x0 + 2, y + h * .35]], true, .45);
  [[80, 102, 78, 6], [60, 104, 88, 8], [46, 106, 100, 8]].forEach(([a, b, y, h]) => E('path', { d: conch(a, b, y, h), fill: B.lin(g, 'muc', 90), stroke: mu.dk, 'stroke-width': .7 }, g));
  /* নাসারন্ধ্রের লোম */
  E('path', { d: 'M36 104l4 -4M38 106l5 -3M41 107l4 -4', stroke: '#6b4a3a', 'stroke-width': .6 }, g);
  /* শক্ত তালু (অস্থি) ও নরম তালু */
  E('path', { d: sm(HEAD.palate, true, .3), fill: bo.lt, stroke: bo.dk, 'stroke-width': .7 }, g);
  E('path', { d: sm(HEAD.soft, true, .45), fill: B.lin(g, 'muc', 90), stroke: mu.dk, 'stroke-width': .7 }, g);
  /* জিহ্বা */
  E('path', { d: sm(HEAD.tongue, true, .5), fill: B.vol(g, 'tng'), stroke: B.TS('tng').dk, 'stroke-width': .8 }, g);
  /* অ্যাডিনয়েড (গলবিল টনসিল) ও শ্রবণনলের মুখ */
  E('path', { d: sm([[112, 80], [120, 84], [122, 92], [116, 90]], true), fill: '#e7a7a6', stroke: mu.dk, 'stroke-width': .5 }, g);
  E('path', { d: B.ellD(113, 99, 3.2, 4.6, 10), fill: '#c97c80', stroke: mu.dk, 'stroke-width': .6 }, g);
  /* এপিগ্লটিস */
  const sw = o.swallow || 0, ep = HEAD.epi.map(([x, y], i) => i >= 2 && i <= 3 ? [x - sw * 8, y + sw * 10] : [x, y]);
  E('path', { d: sm(ep, true, .5), fill: ca.lt, stroke: ca.dk, 'stroke-width': .8 }, g);
  /* স্বরযন্ত্র, শ্বাসনালি ও অন্ননালি */
  E('path', { d: 'M90 176V212H108V176Z', fill: '#f8dcd7', stroke: mu.dk, 'stroke-width': .6 }, g);
  for (let y = 192; y < 212; y += 6) E('path', { d: `M89 ${y}h20v3.2h-20Z`, fill: ca.c, stroke: ca.dk, 'stroke-width': .5 }, g);
  E('path', { d: sm(HEAD.thy, true, .35), fill: B.lin(g, 'cart', 0), stroke: ca.dk, 'stroke-width': .8, opacity: .92 }, g);
  E('path', { d: sm(HEAD.cri, true, .3), fill: ca.c, stroke: ca.dk, 'stroke-width': .7 }, g);
  /* স্বররজ্জু (ভাঁজ) */
  const op = o.open != null ? o.open : 1; E('path', { d: `M88 ${f1(170)}L${f1(104 - op * 6)} 169M88 ${f1(164)}L${f1(102 - op * 4)} 163`, stroke: '#c46b6b', 'stroke-width': 2, 'stroke-linecap': 'round' }, g);
  E('path', { d: sm(HEAD.eso, true, .3), fill: '#efc0b4', stroke: B.TS('eso').dk, 'stroke-width': .6 }, g);
  E('path', { d: 'M115 178V212', stroke: B.TS('eso').dk, 'stroke-width': .5, 'stroke-dasharray': '2 2' }, g);
  /* সাইনাস */
  E('path', { d: sm(HEAD.front, true, .5), fill: '#e6eef6', stroke: '#8ea3b8', 'stroke-width': .7 }, g);
  E('path', { d: sm(HEAD.sphen, true, .5), fill: '#e6eef6', stroke: '#8ea3b8', 'stroke-width': .7 }, g);
  /* হাইয়য়েড অস্থি */
  E('path', { d: B.ellD(96, 152, 6, 2.2, -8), fill: bo.c, stroke: bo.dk, 'stroke-width': .6 }, g);
  return {
    nos: [36, 104], conS: [92, 79], conM: [84, 90], conI: [76, 102], palH: [70, 114], palS: [108, 124], tong: [76, 138], naso: [117, 96], oro: [119, 140], laryngo: [119, 166], epi: [112, 148], tube: [113, 99], ade: [118, 86], lar: [96, 170], vc: [97, 168], tr: [99, 200], eso: [115, 196], fr: [63, 46], sp: [109, 73], hy: [96, 152], thy: [92, 164]
  };
};

/* ═══ বক্ষের সম্মুখ দৃশ্য: ফুসফুস (দর্শকের বাঁয়ে দেহের ডান ফুসফুস), শ্বাসনালি, মধ্যচ্ছদা ═══
   স্থানীয় স্থানাঙ্ক ~ 0–200 × 0–200; o = { insp: ০→১ প্রশ্বাস, tree: শ্বাসনালি-বৃক্ষ, lobes, heart, ribs, fiss } */
const RL0 = [[70, 8], [86, 18], [90, 40], [88, 64], [84, 82], [88, 104], [90, 132], [92, 158], [90, 170], [74, 160], [52, 156], [32, 164], [16, 180], [12, 150], [12, 112], [16, 74], [28, 40], [48, 16]];
const LL0 = [[130, 10], [114, 20], [110, 42], [112, 66], [116, 84], [128, 100], [138, 120], [134, 142], [122, 158], [112, 176], [130, 168], [152, 166], [172, 172], [186, 188], [190, 156], [190, 116], [186, 78], [174, 42], [152, 18]];
B.FISS = { rml: 'M13 104L40 104L64 104L86 100L94 120L94 175L58 162L46 148L30 126Z', rll: 'M13 104L30 126L46 148L58 162L60 190L0 190L0 104Z', lll: 'M189 84L176 110L160 140L146 167L150 200L200 200L200 84Z' };
B.lungPts = (insp = 0) => { const sx = 1 + insp * .07, sy = 1 + insp * .1;
  const f = (P, cx) => P.map(([x, y]) => { const lat = Math.abs(x - cx) > 30 ? 1 : .5, base = y > 140 ? 1 : y / 140; return [cx + (x - cx) * (1 + (sx - 1) * lat), y + (sy - 1) * base * 40 * (y > 150 ? 1.2 : .6)]; });
  return { R: f(RL0, 90), L: f(LL0, 110) }; };
B.thorax = (g, C, o = {}) => {
  const ins = o.insp || 0, { R, L } = B.lungPts(ins), ca = B.TS('cart'), mu = B.TS('muc');
  const dR = sm(R, true, .5), dL = sm(L, true, .5);
  if (o.pleura) { [R, L].forEach((P, i) => E('path', { d: sm(B.offset(P.concat([P[0]]), i ? -3.2 : 3.2, 2), false, .5), fill: 'none', stroke: '#7fa7c9', 'stroke-width': 1.1, 'stroke-dasharray': '3 2' }, g)); }
  [dR, dL].forEach(d => { E('path', { d, fill: B.lungG(g), stroke: LUNG.dk, 'stroke-width': 1 }, g); E('path', { d, fill: B.lungPat(g), stroke: 'none' }, g); });
  /* খণ্ডের হালকা রং (কেবল স্থির ছবিতে) */
  if (o.tint) { const cR = B.clip(g, 'lobR', sm(R, true, .5)), cL = B.clip(g, 'lobL', sm(L, true, .5));
    E('path', { d: B.FISS.rml, fill: FK.alpha('#e0c25a', .28), 'clip-path': cR }, g); E('path', { d: B.FISS.rll, fill: FK.alpha('#6f8fd0', .22), 'clip-path': cR }, g); E('path', { d: B.FISS.lll, fill: FK.alpha('#6f8fd0', .22), 'clip-path': cL }, g); }
  /* বিভাজিকা (ফিশার): ডানে অনুভূমিক ও তির্যক, বামে তির্যক */
  if (o.fiss !== false) { const lc = FK.alpha('#8a4c50', .8), dy = ins * 8;
    E('path', { d: sm([[13, 104 + dy * .5], [40, 104 + dy * .5], [64, 104 + dy * .5], [86, 100]], false), stroke: lc, 'stroke-width': 1, fill: 'none' }, g);
    E('path', { d: sm([[13, 104 + dy * .5], [30, 126 + dy * .6], [46, 148 + dy * .8], [58, 162 + dy]], false), stroke: lc, 'stroke-width': 1, fill: 'none' }, g);
    E('path', { d: sm([[189, 84], [176, 110 + dy * .5], [160, 140 + dy * .7], [146, 167 + dy]], false), stroke: lc, 'stroke-width': 1, fill: 'none' }, g); }
  /* শ্বাসনালি-বৃক্ষ — ফুসফুসের ভেতরে সীমিত */
  if (o.tree) { const L0 = B.lungPts(.5), tg = E('g', { 'clip-path': B.clip(g, 'thxLung', sm(L0.R, true, .5) + sm(L0.L, true, .5)) }, g); B.btree(tg, C, o); }
  /* হৃৎপিণ্ড (মাঝে, বাঁ দিকে হেলানো) */
  if (o.heart !== false) E('path', { d: sm([[98, 114], [114, 108], [130, 116], [138, 134], [134, 152], [120, 164], [102, 166], [92, 152], [92, 128]], true, .5), fill: FK.alpha(B.TS('mus').c, .8), stroke: B.TS('mus').dk, 'stroke-width': .8 }, g);
  /* শ্বাসনালি ও প্রধান ব্রঙ্কাস */
  const trW = 10; E('path', { d: `M${100 - trW / 2} -10V44Q100 52 ${100 - trW / 2} 50Z`, fill: 'none' }, g);
  B.tube(g, 'M100 -12V48', trW, 'cart', { hl: false });
  B.tube(g, sm([[100, 46], [90, 58], [80, 74]]), 8, 'cart', { hl: false });
  B.tube(g, sm([[100, 46], [112, 56], [124, 70]]), 6.6, 'cart', { hl: false });
  let rings = ''; for (let y = -8; y < 44; y += 5) rings += `M${100 - trW / 2 - .6} ${y}h${trW + 1.2}`; E('path', { d: rings, stroke: ca.dk, 'stroke-width': .8, opacity: .55 }, g);
  /* মধ্যচ্ছদা */
  if (o.dia !== false) { const fl = ins * 12, DP = [[2, 196], [16, 184 + fl * .3], [34, 168 + fl], [54, 160 + fl], [76, 164 + fl], [100, 174 + fl * .6], [128, 172 + fl], [152, 170 + fl], [172, 176 + fl], [188, 192 + fl * .3], [198, 200]]; E('path', { d: sm(DP, false, .5), stroke: B.TS('mus').dk, 'stroke-width': 3.2, fill: 'none', 'stroke-linecap': 'round' }, g);
    E('path', { d: sm(DP, false, .5), stroke: B.TS('mus').c, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g); }
  return { R, L, carina: [100, 46], rb: [84, 68], lb: [120, 64], tr: [100, 14], rul: [44, 66], rml: [60, 130], rll: [28, 150], lul: [150, 80], lll: [176, 150], notch: [132, 120], dia: [40, 166 + ins * 12], apex: [70, 12] };
};
/* শ্বাসনালি-বৃক্ষ: প্রতিটি প্রজন্মের পুরুত্ব অনুযায়ী এক পথে — তাই সস্তা */
const TREE = {};
B.btree = (g, C, o = {}) => { const key = (o.gen || 6) + '|' + (o.insp || 0).toFixed(2); let L = TREE[key];
  if (!L) { L = []; const s = 1 + (o.insp || 0) * .06;
    const br = (x, y, a, len, w, d) => { if (d > (o.gen || 6)) return; const x1 = x + Math.cos(a) * len * s, y1 = y + Math.sin(a) * len * s; (L[d] || (L[d] = [])).push(`M${f1(x)} ${f1(y)}L${f1(x1)} ${f1(y1)}`);
      const sp = .42 + (d % 2) * .12; br(x1, y1, a - sp, len * .74, w * .72, d + 1); br(x1, y1, a + sp * .9, len * .7, w * .72, d + 1); };
    /* ডান: তিনটি লোবার ব্রঙ্কাস; বাম: দুটি */
    br(80, 74, -2.2, 22, 4.6, 1); br(80, 74, 2.9, 18, 4.2, 1); br(80, 74, 1.9, 30, 5, 1);
    br(124, 70, -.95, 24, 4.4, 1); br(124, 70, 1.3, 32, 4.6, 1);
    TREE[key] = L; }
  L.forEach((ds, d) => { if (!ds) return; const w = Math.max(.5, 4.4 * Math.pow(.66, d - 1)); E('path', { d: ds.join(''), stroke: d < 3 ? B.TS('cart').dk : '#c98c8c', 'stroke-width': w + .8, 'stroke-linecap': 'round', fill: 'none', opacity: .85 }, g); E('path', { d: ds.join(''), stroke: d < 3 ? B.TS('cart').c : '#f4d0cc', 'stroke-width': w, 'stroke-linecap': 'round', fill: 'none' }, g); }); };

/* ═══ অ্যালভিওলাস গুচ্ছ: x,y = শ্বাস-ব্রঙ্কিওলের প্রান্ত, r = প্রতিটি থলির ব্যাসার্ধ, n, a = দিক ═══ */
B.alvCluster = (g, x, y, r, o = {}) => { const n = o.n || 9, a0 = o.a != null ? o.a : -PI / 2, seed = o.seed || 2, pts = [];
  for (let i = 0; i < n; i++) { const ang = a0 + (i / (n - 1) - .5) * 2.6, rr = r * (1.4 + (i % 3) * .55); pts.push([x + Math.cos(ang) * rr * (1 + B.rnd(seed + i) * .3), y + Math.sin(ang) * rr * (1 + B.rnd(seed * 2 + i) * .3), r * (.78 + B.rnd(seed * 3 + i) * .3)]); }
  pts.push([x + Math.cos(a0) * r * 2.6, y + Math.sin(a0) * r * 2.6, r * .95]);
  const s = o.s || 1; let d = ''; pts.forEach(([px, py, pr]) => { d += B.ellD(px, py, pr * s, pr * s * .94, 0); });
  E('path', { d, fill: o.fill || B.lungG(g), stroke: LUNG.dk, 'stroke-width': .7 }, g);
  if (o.cap !== false) { let dc = '', dv = ''; pts.forEach(([px, py, pr], i) => { const k = pr * s; dc += `M${f1(px - k * .9)} ${f1(py - k * .2)}q${f1(k * .5)} ${f1(-k * .7)} ${f1(k)} ${f1(-k * .5)}t${f1(k * .7)} ${f1(k * .4)}`; dv += `M${f1(px - k * .7)} ${f1(py + k * .45)}q${f1(k * .6)} ${f1(k * .3)} ${f1(k * 1.3)} ${f1(-k * .2)}`; });
    E('path', { d: dc, stroke: B.TS('art').c, 'stroke-width': Math.max(.5, r * .09), fill: 'none', opacity: .9 }, g); E('path', { d: dv, stroke: B.TS('vein').c, 'stroke-width': Math.max(.5, r * .09), fill: 'none', opacity: .9 }, g); }
  return pts; };

/* ═══ পাঁজর ও স্টার্নাম (পাশ থেকে দেখা) — insp: ০→১ পাঁজর ওঠে, স্টার্নাম সামনে যায় (পাম্প-হাতল) ═══ */
B.ribSide = (g, C, xf, xb, y, h, ins = 0) => { const bo = B.TS('bone');
  /* মেরুদণ্ড (পেছনে) */ for (let i = 0; i < 12; i++) E('rect', { x: xb - 2, y: f1(y + i * h / 12), width: 14, height: f1(h / 12 - 2), rx: 2, fill: bo.lt, stroke: bo.dk, 'stroke-width': .6 }, g);
  let d = '', ends = []; for (let i = 0; i < 10; i++) { const ys = y + 6 + i * h / 11.5, drop = (30 + i * 2.6) * (1 - ins * .38), fx = xf - ins * 7 + i * 1.8, fy = ys + drop; ends.push([fx, fy]);
    d += `M${f1(xb)} ${f1(ys)}C${f1(xb - (xb - xf) * .35)} ${f1(ys - 10)} ${f1(fx + (xb - xf) * .25)} ${f1(fy - 8)} ${f1(fx)} ${f1(fy)}`; }
  E('path', { d, stroke: bo.dk, 'stroke-width': 3.6, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d, stroke: bo.lt, 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }, g);
  /* স্টার্নাম (সামনে) — প্রথম সাত পাঁজরের প্রান্ত যুক্ত */ const a = ends[0], b = ends[6]; E('path', { d: `M${f1(a[0] - 2)} ${f1(a[1] - 6)}L${f1(b[0] - 2)} ${f1(b[1] + 4)}`, stroke: bo.dk, 'stroke-width': 6.4, 'stroke-linecap': 'round' }, g); E('path', { d: `M${f1(a[0] - 2)} ${f1(a[1] - 6)}L${f1(b[0] - 2)} ${f1(b[1] + 4)}`, stroke: bo.lt, 'stroke-width': 4.4, 'stroke-linecap': 'round' }, g);
  return ends; };

/* বুদবুদ/গ্যাসের অণু (O<sub>2</sub> লাল, CO<sub>2</sub> নীল) */
B.gas = (g, x, y, k, r = 3) => { const c = k === 'o' ? ['#e8493c', '#9e2218'] : k === 'c' ? ['#4a78c8', '#1f3f80'] : k === 'n' ? ['#b9c0c8', '#6c7680'] : ['#9a7bc4', '#5a3d86'];
  E('circle', { cx: f1(x), cy: f1(y), r, fill: c[0], stroke: c[1], 'stroke-width': .6 }, g); };
})();
