/* ═══════════════════════════════════════════════════════════════════
   visuals4 — অ্যান্টিবডি: antibodyStructure, epitope, antibodyClasses, antibodyAction
   B.Yab(g, x, y, a, s, o) — শৃঙ্খলসহ ছোট অ্যান্টিবডি: (x,y) = Fc এর গোড়া, a = বাহুর দিক
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B210, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, sm2 = t => t * t * (3 - 2 * t);
const HC = '#3a5aa8', LC = '#8ab0e0', VC = '#e08a2a';
B.Yab = (g, x, y, a = -PI / 2, s = 1, o = {}) => { x = +x; y = +y; const L = 14 * s, A = 13 * s, hx = x + Math.cos(a) * L, hy = y + Math.sin(a) * L, w = 3.2 * s;
  E('path', { d: `M${f1(x)} ${f1(y)}L${f1(hx)} ${f1(hy)}`, stroke: o.hc || HC, 'stroke-width': w * 1.7, 'stroke-linecap': 'round' }, g);
  [-1, 1].forEach(sd => { const aa = a + sd * .62, ex = hx + Math.cos(aa) * A, ey = hy + Math.sin(aa) * A, ox = Math.cos(aa + sd * PI / 2) * w * .95, oy = Math.sin(aa + sd * PI / 2) * w * .95;
    E('path', { d: `M${f1(hx)} ${f1(hy)}L${f1(ex)} ${f1(ey)}`, stroke: o.hc || HC, 'stroke-width': w, 'stroke-linecap': 'round' }, g);
    E('path', { d: `M${f1(hx + Math.cos(aa) * A * .3 + ox)} ${f1(hy + Math.sin(aa) * A * .3 + oy)}L${f1(ex + ox)} ${f1(ey + oy)}`, stroke: o.lc || LC, 'stroke-width': w * .9, 'stroke-linecap': 'round' }, g);
    if (o.tip !== false) E('circle', { cx: f1(ex + ox * .5), cy: f1(ey + oy * .5), r: f1(w * .75), fill: o.vc || VC }, g); }); };

/* ═════════ অ্যান্টিবডির গঠন ═════════
   igDraw: ডোমেইন-ভিত্তিক IgG; বাহু স্থানীয় স্থানাঙ্কে আঁকা (y ঋণাত্মক = বাইরের দিকে, x ধনাত্মক = বাইরের পাশ = হালকা শৃঙ্খল) */
const TH = 38, THr = TH * PI / 180, Cc = Math.cos(THr), Ss = Math.sin(THr), HG = [180, 124];
const AW = (sd, lx, ly, hx = HG[0], hy = HG[1]) => [hx + sd * (14 + lx * Cc - ly * Ss), hy - 6 + lx * Ss + ly * Cc];
const VHc = '#d9822b', VLc = '#f3b766';
const igDraw = (P, hx, hy, mk) => { const dm = (gp, x, y, w, h, f, st) => E('rect', { x, y, width: w, height: h, rx: 7, fill: f, stroke: st, 'stroke-width': 1 }, gp);
  [-1, 1].forEach(sd => { const x = sd < 0 ? hx - 17 : hx + 1; dm(P('ch2'), x, hy + 22, 16, 38, HC, '#1e3a78'); dm(P('ch3'), x, hy + 62, 16, 38, HC, '#1e3a78');
    E('path', { d: `M${x + 3} ${hy + 41}h10M${x + 3} ${hy + 81}h10`, stroke: '#e0c020', 'stroke-width': 1.2, opacity: .8 }, P('ch2')); });
  [-1, 1].forEach(sd => { const [bx, by] = AW(sd, -9, -12, hx, hy); E('path', { d: `M${hx + sd * 9} ${hy + 24}C${hx + sd * 9} ${hy + 8} ${f1(bx)} ${f1(by + 14)} ${f1(bx)} ${f1(by)}`, stroke: HC, 'stroke-width': 7, fill: 'none' }, P('hinge')); });
  E('path', { d: `M${hx - 6} ${hy + 6}H${hx + 6}M${hx - 6} ${hy + 13}H${hx + 6}`, stroke: '#e0c020', 'stroke-width': 2.4 }, P('ss'));
  [-1, 1].forEach(sd => { const tr = `translate(${hx + sd * 14} ${hy - 6}) scale(${sd} 1) rotate(${TH})`, G = k => E('g', { transform: tr }, P(k));
    dm(G('ch1'), -17, -52, 16, 38, HC, '#1e3a78'); dm(G('vh'), -17, -92, 16, 38, VHc, '#8a4a10'); dm(G('cl'), 2, -52, 16, 38, LC, '#4a7ab0'); dm(G('vl'), 2, -92, 16, 38, VLc, '#9a5a10');
    E('path', { d: 'M-14 -33h10M-14 -73h10M5 -33h10M5 -73h10', stroke: '#e0c020', 'stroke-width': 1.2, opacity: .8 }, G('ss'));
    E('path', { d: 'M10 -14Q10 -3 -2 -3', stroke: LC, 'stroke-width': 5, fill: 'none', 'stroke-linecap': 'round' }, G('cl')); E('path', { d: 'M-2 -3h-6', stroke: '#e0c020', 'stroke-width': 2.4 }, G('ss'));
    E('path', { d: 'M-14 -91q2 -5 4 0q2 -5 4 0q2 -5 4 0M5 -91q2 -5 4 0q2 -5 4 0q2 -5 4 0', stroke: '#b03020', 'stroke-width': 1.6, fill: 'none' }, G('site'));
    if (sd < 0) E('path', { d: 'M30 -14V-94', stroke: '#777', 'stroke-width': 1, 'marker-start': mk, 'marker-end': mk }, G('fab')); });
  for (const sd of [-1, 1]) { const x = hx + sd * 3, y = hy + 34; E('path', { d: `M${x} ${y}l${sd * 5} 4l${sd * 4} -3M${x + sd * 5} ${y + 4}l0 6`, stroke: '#3a9a5a', 'stroke-width': 1.1, fill: 'none' }, P('cho')); [[5, 4], [9, 1], [5, 10]].forEach(([dx, dy]) => E('circle', { cx: x + sd * dx, cy: y + dy, r: 1.7, fill: '#3a9a5a' }, P('cho'))); }
  E('path', { d: `M${hx + 28} ${hy + 22}V${hy + 100}`, stroke: '#777', 'stroke-width': 1, 'marker-start': mk, 'marker-end': mk }, P('fc')); };
B.igG = (g, x, y, s) => { const mk = B.mk(g, '#777', 5), gg = E('g', { transform: `translate(${x} ${y}) scale(${s}) translate(${-HG[0]} ${-HG[1] - 50})` }, g); igDraw(() => gg, HG[0], HG[1], mk); };
V.antibodyStructure = Object.assign({ t: 'অ্যান্টিবডির গঠন', k: ['2d', 'anim', 'int', 'quiz'], cap: 'একটি IgG অণুর ডোমেইন চিত্র। দুটি অভিন্ন ভারী শৃঙ্খল (গাঢ় নীল, প্রতিটি প্রায় 450টি অ্যামিনো অ্যাসিড, 4টি ডোমেইন) ও দুটি অভিন্ন হালকা শৃঙ্খল (হালকা নীল, প্রায় 214টি, 2টি ডোমেইন) ডাইসালফাইড বন্ধনে (হলুদ) যুক্ত হয়ে Y আকৃতি গড়ে; আণবিক ভর প্রায় 150 কিলোডাল্টন। কমলা ডোমেইন পরিবর্তনশীল (V) অংশ — এর অগ্রভাগের লাল লুপগুলো (অতিপরিবর্তনশীল অঞ্চল) মিলে অ্যান্টিজেন বন্ধন স্থান। শৃঙ্খলের N প্রান্ত বাহুর মাথায়, ভারী শৃঙ্খলের C প্রান্ত কাণ্ডের নিচে। 1972 সালে এডেলম্যান ও পোর্টার এ গঠন উদ্ঘাটনের জন্য নোবেল পান।' },
  BK.diagram({ W: 360, H: 272, label: 'অ্যান্টিবডি', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)); igDraw(P, HG[0], HG[1], B.mk(g, '#777', 5));
      const [nx, ny] = AW(1, 20, -98), [cx, cy] = [HG[0] + 22, HG[1] + 106]; B.tx(P('term'), nx + 4, ny - 2, 'N', { fs: 9, w: 700, c: C.mu }); B.tx(P('term'), cx, cy, 'C', { fs: 9, w: 700, c: C.mu }); B.tx(P('term'), HG[0] - 28, HG[1] + 106, 'C', { fs: 9, w: 700, c: C.mu });
      hits(this.parts, part, 9); },
    idle(g, C, t) { const u = (t * .3) % 1, v = Math.min(1, u * 1.7), [x, y] = AW(1, 1, -104), d = 34 * (1 - v); E('path', { d: B.ellD(x + Ss * d, y - Cc * d, 8, 5, -52), fill: '#c8a050', stroke: '#8a6020', 'stroke-width': .7, opacity: f1(u < .9 ? 1 : (1 - u) * 10) }, g); },
    parts: [
      { id: 'vl', bn: 'হালকা শৃঙ্খলের পরিবর্তনশীল অংশ (VL)', lb: 'VL', en: 'Variable light', fn: 'হালকা শৃঙ্খলের N প্রান্তের ডোমেইন — VH এর সাথে মিলে অ্যান্টিজেন বন্ধন স্থান তৈরি করে; একেক অ্যান্টিবডিতে এর অ্যামিনো অ্যাসিড ক্রম একেক রকম।', a: AW(-1, 10, -73), l: [14, 36], an: 'start' },
      { id: 'vh', bn: 'ভারী শৃঙ্খলের পরিবর্তনশীল অংশ (VH)', lb: 'VH', en: 'Variable heavy', fn: 'ভারী শৃঙ্খলের N প্রান্তের ডোমেইন — VL এর সাথে নির্দিষ্ট অ্যান্টিজেন বাঁধার খাঁজ (প্যারাটোপ) গড়ে।', a: AW(-1, -9, -73), l: [14, 70], an: 'start' },
      { id: 'fab', bn: 'Fab অংশ (অ্যান্টিজেন বন্ধনকারী খণ্ড)', lb: 'Fab', en: 'Fragment antigen-binding', fn: 'প্যাপেইন এনজাইমে কাটলে দুটি Fab ও একটি Fc পাওয়া যায় — প্রতিটি Fab এ একটি সম্পূর্ণ হালকা শৃঙ্খল এবং ভারী শৃঙ্খলের VH ও CH1।', a: AW(-1, 30, -54), l: [14, 104], an: 'start' },
      { id: 'hinge', bn: 'কব্জা অঞ্চল', lb: 'কব্জা', en: 'Hinge region', fn: 'নমনীয় অংশ — বাহু দুটি কাছে-দূরে সরে ভিন্ন দূরত্বের দুটি এপিটোপ ধরতে পারে।', a: [HG[0] - 9, HG[1] + 2], l: [14, 140], an: 'start' },
      { id: 'ss', bn: 'ডাইসালফাইড বন্ধন', lb: 'ডাইসালফাইড বন্ধন', en: 'Disulfide bonds', fn: 'সিস্টিনের –S–S– বন্ধন (হলুদ): কব্জায় দুই ভারী শৃঙ্খলকে এবং প্রতিটি হালকা শৃঙ্খলকে তার ভারী শৃঙ্খলের সাথে যুক্ত রাখে; প্রতিটি ডোমেইনের ভেতরেও একটি করে বন্ধন ভাঁজ ধরে রাখে।', a: [HG[0], HG[1] + 10], l: [14, 168], an: 'start' },
      { id: 'ch2', bn: 'CH2 ডোমেইন', lb: 'CH2', en: 'Constant heavy 2', fn: 'কাণ্ডের ওপরের স্থির ডোমেইন — কমপ্লিমেন্টের C1q এখানে যুক্ত হয়; এখানেই শর্করা শৃঙ্খল লাগানো থাকে।', a: [HG[0] - 9, HG[1] + 46], l: [14, 200], an: 'start' },
      { id: 'ch3', bn: 'CH3 ডোমেইন', lb: 'CH3', en: 'Constant heavy 3', fn: 'কাণ্ডের নিচের স্থির ডোমেইন — ফ্যাগোসাইট ও NK কোষের Fc গ্রাহকে যুক্ত হয়; ভারী শৃঙ্খলের C প্রান্ত এখানে।', a: [HG[0] - 9, HG[1] + 84], l: [14, 236], an: 'start' },
      { id: 'site', bn: 'অ্যান্টিজেন বন্ধন স্থান (প্যারাটোপ)', lb: 'অ্যান্টিজেন বন্ধন স্থান', en: 'Antigen-binding site', fn: 'প্রতিটি বাহুর মাথায় একটি — VH ও VL এর তিনটি করে অতিপরিবর্তনশীল লুপ মিলে গড়ে। তাই IgG দ্বিযোজী: একসাথে দুটি অ্যান্টিজেন বাঁধতে পারে; তালা-চাবির মতো নির্দিষ্ট এপিটোপে বসে।', a: AW(1, 0, -94), l: [352, 24], an: 'end' },
      { id: 'cl', bn: 'হালকা শৃঙ্খলের স্থির অংশ (CL)', lb: 'CL', en: 'Constant light', fn: 'হালকা শৃঙ্খলের স্থির ডোমেইন — দুই ধরন: কাপ্পা (κ) ও ল্যাম্বডা (λ); C প্রান্ত ভারী শৃঙ্খলের সাথে ডাইসালফাইড বন্ধনে যুক্ত।', a: AW(1, 10, -33), l: [352, 70], an: 'end' },
      { id: 'ch1', bn: 'ভারী শৃঙ্খলের স্থির অংশ (CH1)', lb: 'CH1', en: 'Constant heavy 1', fn: 'বাহুর ভেতরের দিকের স্থির ডোমেইন — একই শ্রেণির সব অ্যান্টিবডিতে প্রায় একই।', a: AW(1, -9, -33), l: [352, 120], an: 'end' },
      { id: 'cho', bn: 'শর্করা শৃঙ্খল', lb: 'শর্করা', en: 'Carbohydrate', fn: 'CH2 তে যুক্ত অলিগোস্যাকারাইড — অণুকে স্থিতিশীল রাখে ও Fc গ্রাহকে যুক্ত হতে সাহায্য করে (তাই অ্যান্টিবডি একটি গ্লাইকোপ্রোটিন)।', a: [HG[0] + 6, HG[1] + 38], l: [352, 160], an: 'end' },
      { id: 'fc', bn: 'Fc অংশ (স্ফটিক-গঠনকারী খণ্ড)', lb: 'Fc', en: 'Fragment crystallizable', fn: 'অ্যান্টিবডির "লেজ" — কাজ নির্ধারণ করে: অমরা পার হওয়া (IgG), কমপ্লিমেন্ট সক্রিয়করণ, ফ্যাগোসাইটে সংযুক্তি, মাস্ট কোষে বসা (IgE)। ভারী শৃঙ্খলের এ অংশের ধরন দিয়েই শ্রেণি (IgG, IgA…) ঠিক হয়।', a: [HG[0] + 28, HG[1] + 61], l: [352, 214], an: 'end' },
      { id: 'term', bn: 'N ও C প্রান্ত', lb: 'N, C প্রান্ত', en: 'N- and C-termini', fn: 'প্রতিটি পলিপেপটাইড শৃঙ্খলের অ্যামিনো (N) প্রান্ত বাহুর মাথায় — সেখানেই পরিবর্তনশীল অংশ; ভারী শৃঙ্খলের কার্বক্সিল (C) প্রান্ত কাণ্ডের নিচে।', a: [HG[0] + 22, HG[1] + 103], l: [352, 252], an: 'end' }
    ]
  }));

/* ═════════ অ্যান্টিজেন ও এপিটোপ ═════════ */
const EP = [[120, 92, 'tri', '#c0392b'], [86, 190, 'sq', '#2a6ab0'], [210, 206, 'cir', '#3a9a5a']];
const abOn = (g, i, d) => { const [tx, ty, , col] = EP[i], a = Math.atan2(152 - ty, 142 - tx), s = 1.6, L = 14 * s, A = 13 * s, aa = a + .62; B.Yab(g, tx - Math.cos(aa) * A - Math.cos(a) * (L + d), ty - Math.sin(aa) * A - Math.sin(a) * (L + d), a, s, { vc: col }); };
const shapeD = (k, x, y, s = 1) => k === 'tri' ? `M${x - 7 * s} ${y + 5 * s}L${x} ${y - 7 * s}L${x + 7 * s} ${y + 5 * s}Z` : k === 'sq' ? `M${x - 6 * s} ${y - 6 * s}h${12 * s}v${12 * s}h${-12 * s}Z` : B.ellD(x, y, 6.5 * s, 6.5 * s, 0);
V.epitope = Object.assign({ t: 'অ্যান্টিজেন, এপিটোপ ও অ্যান্টিবডি', k: ['2d', 'anim', 'int', 'quiz'], cap: 'যে পদার্থ দেহে নির্দিষ্ট প্রতিরক্ষা সাড়া (অ্যান্টিবডি বা T কোষ) তৈরি করে, তাকে অ্যান্টিজেন বলে — সাধারণত বড় প্রোটিন বা পলিস্যাকারাইড (আণবিক ভর প্রায় 10 কিলোডাল্টনের বেশি), যেমন জীবাণুর প্রাচীর, ফ্ল্যাজেলা, টক্সিন, পরাগরেণু, অন্যের রক্তকণিকা। একটি অ্যান্টিজেনে কয়েকটি এপিটোপ থাকে, তাই এর বিরুদ্ধে কয়েক ধরনের অ্যান্টিবডি তৈরি হয়।' },
  BK.diagram({ W: 360, H: 290, label: 'এপিটোপ', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      B.organ(P('ag'), sm([[60, 120], [100, 70], [170, 66], [214, 110], [236, 176], [196, 236], [120, 236], [70, 200], [48, 160]], true, .5), 'bact', { sw: 1.2, gr: { cx: .4, cy: .35, r: .9 }, pat: 'dot', pa: .16 });
      EP.forEach(([x, y, k, col], i) => E('path', { d: shapeD(k, x, y), fill: col, stroke: '#333', 'stroke-width': .6 }, P('epi' + i)));
      /* অ্যান্টিবডি: একটি বাহুর মাথা এপিটোপে বসানো; প্যারাটোপের রং এপিটোপের পরিপূরক */ [1, 2].forEach(i => abOn(P('ab'), i, 0));
      /* পৃষ্ঠের অন্য প্রোটিন */ for (let i = 0; i < 9; i++) { const a = i / 9 * 2 * PI + .3, r = 86 + B.rnd(i) * 4; E('path', { d: B.ellD(142 + Math.cos(a) * r, 152 + Math.sin(a) * r * .97, 3.2, 2.2, a * 180 / PI), fill: '#6f8f3a', opacity: .55 }, P('ag')); }
      /* হ্যাপটেন */ E('path', { d: B.ellD(300, 96, 6, 6, 0), fill: '#a8601a' }, P('hap')); B.organ(P('hap'), sm([[280, 120], [320, 116], [330, 140], [300, 150], [276, 140]], true, .5), 'muc', { sw: .8 }); E('path', { d: B.ellD(300, 120, 6, 6, 0), fill: '#a8601a' }, P('hap'));
      hits(this.parts, part, 8); },
    idle(g, C, t) { const u = (t * .25) % 1, v = u < .55 ? u / .55 : 1; abOn(g, 0, 46 * (1 - sm2(v))); if (v >= 1) E('circle', { cx: EP[0][0], cy: EP[0][1], r: f1(9 + (u - .55) * 30), fill: 'none', stroke: '#c0392b', 'stroke-width': 1, opacity: f1(1 - (u - .55) * 2.2) }, g); },
    parts: [
      { id: 'ag', bn: 'অ্যান্টিজেন (যেমন ব্যাকটেরিয়ার প্রোটিন)', lb: 'অ্যান্টিজেন', en: 'Antigen', fn: 'দেহের কাছে "অপরিচিত" বড় অণু — অ্যান্টিবডি উৎপাদন ঘটায় (অ্যান্টিবডি জেনারেটর → অ্যান্টিজেন) এবং তার সাথেই নির্দিষ্টভাবে যুক্ত হয়।', a: [150, 160], l: [150, 276], an: 'middle' },
      { id: 'epi0', bn: 'এপিটোপ (অ্যান্টিজেনিক নির্ধারক)', lb: 'এপিটোপ', en: 'Epitope', fn: 'অ্যান্টিজেনের যে ছোট অংশ (প্রায় 5–15টি অ্যামিনো অ্যাসিড বা কয়েকটি শর্করা একক) অ্যান্টিবডি বা TCR সরাসরি চেনে — আকৃতি ও রাসায়নিক বৈশিষ্ট্যে নির্দিষ্ট।', a: [120, 92], l: [14, 60], an: 'start' },
      { id: 'epi1', bn: 'দ্বিতীয় এপিটোপ', lb: 'ভিন্ন এপিটোপ', en: 'Another epitope', fn: 'একই অ্যান্টিজেনের অন্য এপিটোপ — এর জন্য আলাদা B কোষ ক্লোন থেকে আলাদা অ্যান্টিবডি তৈরি হয় (পলিক্লোনাল সাড়া)।', a: [86, 190], l: [14, 230], an: 'start' },
      { id: 'epi2', bn: 'তৃতীয় এপিটোপ', lb: 'তৃতীয় এপিটোপ', en: 'Third epitope', fn: 'প্রতিটি এপিটোপ-অ্যান্টিবডির মিল তালা-চাবির মতো — হাইড্রোজেন, আয়নিক ও ভ্যান্ডার ওয়ালস বন্ধনে অস্থায়ীভাবে যুক্ত হয়।', a: [210, 206], l: [352, 250], an: 'end' },
      { id: 'ab', bn: 'অ্যান্টিবডি (প্যারাটোপসহ)', lb: 'অ্যান্টিবডি', en: 'Antibody', fn: 'প্লাজমা কোষের তৈরি গ্লাইকোপ্রোটিন (ইমিউনোগ্লোবিউলিন, Ig) — এর প্যারাটোপের আকার নির্দিষ্ট এপিটোপের পরিপূরক।', a: [214, 248], l: [352, 214], an: 'end' },
      { id: 'hap', bn: 'হ্যাপটেন ও বাহক প্রোটিন', lb: 'হ্যাপটেন', en: 'Hapten', fn: 'ছোট অণু (যেমন পেনিসিলিন) একা অ্যান্টিবডি তৈরি করাতে পারে না, কিন্তু দেহের প্রোটিনে যুক্ত হলে পারে — এভাবেই ওষুধে অ্যালার্জি হয়।', a: [300, 110], l: [352, 170], an: 'end' }
    ]
  }));

/* ═════════ অ্যান্টিবডির শ্রেণি ═════════ */
const IG = {
  igg: ['IgG', 'IgG — একক (মনোমার)', 'রক্তরসের মোট অ্যান্টিবডির প্রায় 75–80%; একমাত্র অ্যান্টিবডি যা অমরা পার হয়ে ভ্রূণকে জন্মের পর কয়েক মাস সুরক্ষা দেয়; দ্বিতীয়বার সংক্রমণে (গৌণ সাড়া) প্রধান অ্যান্টিবডি; অপসোনাইজেশন, কমপ্লিমেন্ট সক্রিয়করণ ও টক্সিন নিষ্ক্রিয় করে। অর্ধায়ু প্রায় 3 সপ্তাহ — সবচেয়ে বেশি।', ['75–80%', 'রক্ত, কলারস', 'অমরা পার হয়', '2']],
  iga: ['IgA', 'IgA — দ্বৈত (ডাইমার)', 'রক্তরসে প্রায় 10–15%, কিন্তু নিঃসরণে প্রধান: লালা, অশ্রু, শ্লেষ্মা, অন্ত্র ও শ্বাসনালির রস এবং বুকের দুধ (বিশেষত শালদুধ)। J শৃঙ্খল দুটি একককে জোড়ে, নিঃসরণ উপাদান (সিক্রেটরি কম্পোনেন্ট) পাচক এনজাইম থেকে রক্ষা করে। শ্লেষ্মা ঝিল্লিতে জীবাণুকে লেগে যেতে দেয় না — নবজাতকের অন্ত্রে মায়ের দুধের IgA ডায়রিয়া ঠেকায়।', ['10–15%', 'নিঃসরণ, দুধ', 'শ্লেষ্মা ঝিল্লির রক্ষী', '4']],
  igm: ['IgM', 'IgM — পঞ্চক (পেন্টামার)', 'রক্তরসে প্রায় 5–10%; সবচেয়ে বড় (প্রায় 900 কিলোডাল্টন), পাঁচটি একক J শৃঙ্খলে যুক্ত — 10টি বন্ধন স্থান। প্রথম সংক্রমণে (মুখ্য সাড়া) সবার আগে তৈরি হয় — রক্তে IgM বেশি মানে সাম্প্রতিক সংক্রমণ। অ্যাগ্লুটিনেশন ও কমপ্লিমেন্ট সক্রিয়করণে সবচেয়ে দক্ষ; রক্তের গ্রুপের অ্যান্টি-A ও অ্যান্টি-B মূলত IgM। আকারে বড় বলে অমরা পার হয় না।', ['5–10%', 'রক্ত', 'প্রথম সাড়া', '10']],
  igd: ['IgD', 'IgD — একক, B কোষের গায়ে', 'রক্তরসে 1% এর কম; মূলত পরিণত কিন্তু অ্যান্টিজেন না দেখা B কোষের গায়ে IgM এর সাথে গ্রাহক (BCR) হিসেবে থাকে — অ্যান্টিজেন চিনে B কোষ সক্রিয় করতে সাহায্য করে।', ['< 1%', 'B কোষের ঝিল্লি', 'B কোষ গ্রাহক', '2']],
  ige: ['IgE', 'IgE — একক, মাস্ট কোষে', 'রক্তরসে খুবই কম (প্রায় 0.002%), কিন্তু শক্তিশালী — Fc অংশ দিয়ে মাস্ট কোষ ও বেসোফিলের গায়ে বসে থাকে। অ্যালার্জেন (ধুলা, পরাগ, চিংড়ি) দুটি IgE কে জোড়া লাগালে মাস্ট কোষ হিস্টামিন ছাড়ে — হাঁচি, চুলকানি, হাঁপানি, এমনকি অ্যানাফাইল্যাক্সিস। কৃমির মতো পরজীবীর বিরুদ্ধে স্বাভাবিক প্রতিরক্ষায় কাজ করে।', ['≈ 0.002%', 'মাস্ট কোষ, বেসোফিল', 'অ্যালার্জি, কৃমি', '2']]
};
V.antibodyClasses = Object.assign({}, B.seg({
  id: 'igc', t: 'অ্যান্টিবডির পাঁচ শ্রেণি', H: 280, def: 'igg', types: Object.fromEntries(Object.entries(IG).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'মানুষের অ্যান্টিবডি বা ইমিউনোগ্লোবিউলিন পাঁচ শ্রেণির — ভারী শৃঙ্খলের স্থির অংশের ধরন (γ, α, μ, δ, ε) অনুযায়ী IgG, IgA, IgM, IgD ও IgE। সব শ্রেণির মূল একক একই Y আকৃতি। মনে রাখার কৌশল: "GAMED"। শতাংশ রক্তরসের মোট অ্যান্টিবডির আনুমানিক হিস্যা।',
  art(g, C, ty) { const cx = 104, cy = 140, inf = IG[ty][3];
    B.cacheG(g, 'igc' + Object.keys(IG).indexOf(ty), gg => {
      if (ty === 'igg') B.igG(gg, cx, cy + 8, .78);
      if (ty === 'iga') { B.Yab(gg, cx - 24, cy + 4, -PI / 2 - .5, 3); B.Yab(gg, cx + 24, cy + 4, -PI / 2 + .5, 3); E('path', { d: `M${cx - 24} ${cy + 4}Q${cx} ${cy + 22} ${cx + 24} ${cy + 4}`, stroke: '#c0392b', 'stroke-width': 3, fill: 'none' }, gg); E('path', { d: `M${cx - 34} ${cy + 16}Q${cx} ${cy + 44} ${cx + 34} ${cy + 16}`, stroke: '#8a6ac0', 'stroke-width': 5, fill: 'none', opacity: .7, 'stroke-linecap': 'round' }, gg); B.tx(gg, cx, cy + 34, 'J শৃঙ্খল', { fs: 9.6, a: 'middle', c: '#c0392b' }); B.tx(gg, cx, cy + 60, 'নিঃসরণ উপাদান', { fs: 9.6, a: 'middle', c: '#6a4aa0' }); }
      if (ty === 'igm') { for (let i = 0; i < 5; i++) { const a = -PI / 2 + i / 5 * 2 * PI; B.Yab(gg, cx + Math.cos(a) * 14, cy + Math.sin(a) * 14, a, 2.4); } E('path', { d: B.ellD(cx, cy, 14, 14, 0), fill: 'none', stroke: HC, 'stroke-width': 4 }, gg); E('circle', { cx: cx + 10, cy: cy + 10, r: 4, fill: '#c0392b' }, gg); B.tx(gg, cx + 30, cy + 34, 'J শৃঙ্খল', { fs: 9.6, c: '#c0392b' }); }
      if (ty === 'igd') { E('path', { d: `M14 ${cy + 60}Q${cx} ${cy + 40} 196 ${cy + 60}V280H14Z`, fill: B.TS('bcl').lt, stroke: B.TS('bcl').dk, 'stroke-width': 1 }, gg); E('path', { d: B.ellD(cx, cy + 100, 40, 26, 0), fill: '#3f2b7a' }, gg); [cx - 40, cx, cx + 40].forEach((x, i) => { B.Yab(gg, x, cy + 56, -PI / 2, 2.4, i === 1 ? {} : { hc: '#6a4a9a' }); E('path', { d: `M${x - 3} ${cy + 50}v14M${x + 3} ${cy + 50}v14`, stroke: i === 1 ? HC : '#6a4a9a', 'stroke-width': 2.4 }, gg); }); B.tx(gg, 22, cy + 76, 'B কোষ', { fs: 9.6, c: B.TS('bcl').dk }); B.tx(gg, cx - 40, cy - 2, 'IgM', { fs: 9.6, a: 'middle', c: '#6a4a9a' }); B.tx(gg, cx + 40, cy - 2, 'IgM', { fs: 9.6, a: 'middle', c: '#6a4a9a' }); B.tx(gg, cx, cy - 18, 'IgD', { fs: 10.4, a: 'middle', w: 700, c: HC }); }
      if (ty === 'ige') { B.organ(gg, B.ellD(cx, cy + 60, 70, 52, 0), 'neu', { sw: 1 }); let gd = ''; for (let i = 0; i < 40; i++) gd += B.ellD(cx - 50 + B.rnd(i) * 100, cy + 30 + B.rnd(i + 9) * 60, 2.6, 2.6, 0); E('path', { d: gd, fill: '#4a2a6a' }, gg); [cx - 30, cx + 30].forEach((x, i) => B.Yab(gg, x, cy + 12 - (i ? 2 : 0), -PI / 2 + (i ? .25 : -.25), 2.6)); E('path', { d: B.ellD(cx, cy - 34, 16, 9, 0), fill: '#e0c040', stroke: '#8a7010', 'stroke-width': .8 }, gg); B.tx(gg, cx, cy - 50, 'অ্যালার্জেন', { fs: 9.6, a: 'middle', c: '#8a7010' }); B.tx(gg, cx, cy + 128, 'মাস্ট কোষ', { fs: 9.6, a: 'middle', c: '#6a3a8a' }); }
      /* তথ্য সারণি */ const X = 214; [['রক্তরসে', inf[0]], ['কোথায়', inf[1]], ['বিশেষ কাজ', inf[2]], ['বন্ধন স্থান', inf[3]]].forEach(([k, v], i) => { const y = 54 + i * 50; E('rect', { x: X, y: y - 18, width: 140, height: 42, rx: 7, fill: FK.alpha(HC, .07), stroke: FK.alpha(HC, .3), 'stroke-width': .8 }, gg); B.tx(gg, X + 8, y - 2, k, { fs: 9.8, c: C.mu }); B.tx(gg, X + 8, y + 15, v, { fs: 11, w: 700, c: HC }); });
      B.tx(gg, 104, 24, IG[ty][0], { fs: 16, a: 'middle', w: 700, c: HC }); }); },
  anim(g, C, ty, t) { if (ty === 'ige') { for (let i = 0; i < 6; i++) { const u = (t * .4 + i / 6) % 1, a = -PI / 2 + (i - 2.5) * .5; E('circle', { cx: f1(104 + Math.cos(a) * (60 + u * 30)), cy: f1(200 + Math.sin(a) * (40 + u * 30)), r: 2.4, fill: '#4a2a6a', opacity: f1(1 - u) }, g); } }
    else { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx: 104, cy: 140, r: f1(72 + k * 4), fill: 'none', stroke: FK.alpha(HC, .4), 'stroke-width': 1, 'stroke-dasharray': '3 4', opacity: f1(.4 + k * .4) }, g); } }
}));

/* ═════════ অ্যান্টিবডির কাজের কৌশল ═════════ */
const AA = {
  neu: ['নিষ্ক্রিয়করণ', 'নিষ্ক্রিয়করণ (নিউট্রালাইজেশন)', 'অ্যান্টিবডি ভাইরাসের গায়ের প্রোটিন বা ব্যাকটেরিয়ার টক্সিনের সক্রিয় অংশ ঢেকে দেয় — ভাইরাস কোষে লাগতে পারে না, টক্সিন ক্ষতি করতে পারে না। ধনুষ্টংকার ও ডিপথেরিয়ার টিকা এ কারণেই কাজ করে (অ্যান্টিটক্সিন)।'],
  agg: ['অ্যাগ্লুটিনেশন', 'অ্যাগ্লুটিনেশন (দলা পাকানো)', 'একটি অ্যান্টিবডির দুই (IgM এর দশ) বাহু দুটি ভিন্ন জীবাণুর এপিটোপে লেগে অনেক জীবাণুকে একসাথে দলা পাকায় — জীবাণু চলতে ও ছড়াতে পারে না, ফ্যাগোসাইট একসাথে অনেকগুলো খেতে পারে। রক্তের গ্রুপ নির্ণয় এ বিক্রিয়ার ওপর ভিত্তি করে।'],
  pre: ['অধঃক্ষেপণ', 'অধঃক্ষেপণ (প্রেসিপিটেশন)', 'দ্রবণীয় অ্যান্টিজেন (যেমন টক্সিনের অণু) অ্যান্টিবডির সাথে জালের মতো জটিল গঠন করে অদ্রবণীয় হয়ে তলানি পড়ে — ফ্যাগোসাইট সহজে সরিয়ে ফেলে।'],
  ops: ['অপসোনাইজেশন', 'অপসোনাইজেশন', 'জীবাণুর গায়ে লেগে থাকা অ্যান্টিবডির Fc অংশ ফ্যাগোসাইটের Fc গ্রাহকে যুক্ত হয় — যেন জীবাণুর গায়ে "খাও" লেবেল; ফ্যাগোসাইটোসিস বহুগুণ দ্রুত হয়।'],
  cmp: ['কমপ্লিমেন্ট', 'কমপ্লিমেন্ট সক্রিয়করণ', 'জীবাণুতে লাগা IgM বা IgG এর Fc অংশে কমপ্লিমেন্টের C1 যুক্ত হয়ে প্রচলিত পথ চালু করে — শেষে ঝিল্লি আক্রমণ জটিল (MAC) জীবাণুর ঝিল্লিতে ছিদ্র করে ফাটিয়ে দেয়।']
};
V.antibodyAction = Object.assign({}, B.seg({
  id: 'aba', t: 'অ্যান্টিবডি কীভাবে জীবাণু ধ্বংসে সাহায্য করে', H: 260, def: 'agg', types: AA,
  cap: 'অ্যান্টিবডি নিজে সাধারণত জীবাণু মারে না — জীবাণুকে নিষ্ক্রিয়, দলাবদ্ধ বা চিহ্নিত করে, তারপর ফ্যাগোসাইট ও কমপ্লিমেন্ট ধ্বংস করে। তাই অ্যান্টিবডি (তৃতীয় স্তর) ও ফ্যাগোসাইট-কমপ্লিমেন্ট (দ্বিতীয় স্তর) একসাথে কাজ করে।',
  art(g, C, ty) { B.cacheG(g, 'abab' + Object.keys(AA).indexOf(ty), gg => {
    if (ty === 'neu') { /* ভাইরাস ও কোষ */ E('path', { d: 'M230 0V260', stroke: '#b0806c', 'stroke-width': 10 }, gg); E('path', { d: 'M236 0H360V260H236Z', fill: '#f8e6dc' }, gg); for (let i = 0; i < 6; i++) E('path', { d: `M230 ${30 + i * 40}h-8`, stroke: '#7a5a9a', 'stroke-width': 4 }, gg); B.tx(gg, 300, 140, 'পোষক কোষ', { fs: 10, a: 'middle', c: '#8a5a4a' });
      [[90, 80], [120, 180]].forEach(([x, y]) => { B.virus(gg, x, y, 16); for (let i = 0; i < 6; i++) { const a = i / 6 * 2 * PI + PI / 6; B.Yab(gg, x + Math.cos(a) * 46, y + Math.sin(a) * 46, a + PI, 1.6); } }); B.tx(gg, 104, 246, 'অ্যান্টিবডিতে ঢাকা ভাইরাস কোষে লাগতে পারে না', { fs: 10, a: 'middle', c: C.mu }); }
    if (ty === 'agg') { const P = [[80, 70], [150, 60], [200, 120], [110, 140], [170, 190], [70, 200], [250, 200]]; P.forEach(([x, y], i) => B.bact(gg, x, y, i * .9, { L: 26, w: 11, fl: i % 2 === 0, ph: i })); [[0, 1], [1, 2], [0, 3], [3, 4], [2, 4], [3, 5], [4, 6], [1, 3]].forEach(([a, b], j) => { const [x0, y0] = P[a], [x1, y1] = P[b], ang = Math.atan2(y1 - y0, x1 - x0), dd = Math.hypot(x1 - x0, y1 - y0), n = ang + (j % 2 ? 1 : -1) * PI / 2, hx = (x0 + x1) / 2 + Math.cos(n) * 8, hy = (y0 + y1) / 2 + Math.sin(n) * 8, t0 = [x0 + Math.cos(ang) * 12, y0 + Math.sin(ang) * 12], t1 = [x1 - Math.cos(ang) * 12, y1 - Math.sin(ang) * 12];
        E('path', { d: `M${f1(t0[0])} ${f1(t0[1])}L${f1(hx)} ${f1(hy)}L${f1(t1[0])} ${f1(t1[1])}M${f1(hx)} ${f1(hy)}l${f1(Math.cos(n) * 12)} ${f1(Math.sin(n) * 12)}`, stroke: HC, 'stroke-width': 3.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }, gg);
        [t0, t1].forEach(([tx, ty]) => { E('path', { d: `M${f1(lerp(tx, hx, .55) + Math.cos(n) * 3)} ${f1(lerp(ty, hy, .55) + Math.sin(n) * 3)}L${f1(tx + Math.cos(n) * 3)} ${f1(ty + Math.sin(n) * 3)}`, stroke: LC, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, gg); E('circle', { cx: f1(tx), cy: f1(ty), r: 2.4, fill: VC }, gg); }); });
      B.tx(gg, 300, 120, 'জীবাণুর দলা', { fs: 10.4, a: 'middle', w: 700, c: '#5e7a2a' }); }
    if (ty === 'pre') { E('path', { d: 'M70 30V220Q70 240 90 240H230Q250 240 250 220V30', fill: '#eef4f8', stroke: '#8aa0b0', 'stroke-width': 2 }, gg); for (let i = 0; i < 20; i++) { const x = 90 + B.rnd(i) * 140, y = 50 + B.rnd(i + 30) * 110; E('path', { d: B.ellD(x, y, 4, 3, 20), fill: '#e0a030' }, gg); } let lat = ''; for (let i = 0; i < 8; i++) for (let j = 0; j < 3; j++) { const x = 100 + i * 17, y = 200 + j * 12; lat += B.ellD(x, y, 4, 3, 0); } E('path', { d: lat, fill: '#c08020', stroke: '#7a5010', 'stroke-width': .5 }, gg); for (let i = 0; i < 7; i++) B.Yab(gg, 108 + i * 17, 210, -PI / 2, .7); B.tx(gg, 300, 210, 'তলানি (অ্যান্টিজেন-অ্যান্টিবডি জাল)', { fs: 10, a: 'end', c: '#7a5010' }); B.tx(gg, 300, 80, 'দ্রবণীয় অ্যান্টিজেন', { fs: 10, a: 'end', c: '#a06020' }); }
    if (ty === 'ops') { B.macro(gg, 104, 130, 60, { seed: 4, arms: [[0, 1.4], [.6, 1.3], [-.6, 1.3]] }); for (let i = 0; i < 5; i++) { const a = -1 + i * .5; E('path', { d: `M${f1(104 + Math.cos(a) * 70)} ${f1(130 + Math.sin(a) * 63)}l${f1(Math.cos(a) * 8)} ${f1(Math.sin(a) * 8)}`, stroke: '#6a4aa0', 'stroke-width': 4, 'stroke-linecap': 'round' }, gg); } B.tx(gg, 104, 236, 'ফ্যাগোসাইট (Fc গ্রাহকসহ)', { fs: 10, a: 'middle', c: '#5a4a90' }); }
    if (ty === 'cmp') { E('path', { d: 'M0 170H360V196H0Z', fill: '#f6eec8' }, gg); let lp = ''; for (let x = 0; x < 360; x += 7) lp += B.ellD(x, 170, 3, 3, 0) + B.ellD(x, 196, 3, 3, 0); E('path', { d: lp, fill: '#c8a050', stroke: '#8a6a20', 'stroke-width': .4 }, gg); [80, 280].forEach(x => B.Yab(gg, x, 120, PI / 2, 2.4)); [80, 280].forEach(x => { let st = ''; for (let i = 0; i < 6; i++) { const ex = x - 15 + i * 6; st += `M${x} 70V84Q${x} 90 ${ex} 110`; } E('path', { d: st, stroke: '#7a5ab8', 'stroke-width': 1.8, fill: 'none' }, gg); for (let i = 0; i < 6; i++) E('path', { d: B.ellD(x - 15 + i * 6, 114, 3, 4.2, 0), fill: '#9a7ad0', stroke: '#5a3a98', 'stroke-width': .6 }, gg); }); B.tx(gg, 80, 62, 'C1q', { fs: 10, a: 'middle', w: 700, c: '#7a5ab8' }); B.tx(gg, 280, 62, 'C1q', { fs: 10, a: 'middle', w: 700, c: '#7a5ab8' }); B.tx(gg, 352, 240, 'জীবাণুর কোষঝিল্লি', { fs: 10, a: 'end', c: '#8a6a20' }); } }); },
  anim(g, C, ty, t) { const u = (t * .3) % 1;
    if (ty === 'neu') { const v = u < .6 ? u / .6 : 1; B.virus(g, f1(lerp(140, 216, v)), 120, 10); if (v >= 1) E('path', { d: 'M222 108l-8 24', stroke: '#c0392b', 'stroke-width': 0 }, g); E('path', { d: B.ellD(lerp(140, 216, v) + 10, 120, 4, 4, 0), fill: 'none', stroke: '#c0392b', 'stroke-width': 1, opacity: f1(v) }, g); B.tx(g, 200, 100, v >= 1 ? 'অ্যান্টিবডিহীন ভাইরাস ঢুকে যায়' : '', { fs: 9.6, a: 'middle', c: '#c0392b' }); }
    if (ty === 'agg') { const k = .5 + .5 * Math.sin(t * 2); E('circle', { cx: 150, cy: 130, r: f1(110 + k * 4), fill: 'none', stroke: '#5e7a2a', 'stroke-width': 1, 'stroke-dasharray': '4 4', opacity: f1(.3 + k * .4) }, g); }
    if (ty === 'pre') for (let i = 0; i < 6; i++) { const v = (u + i / 6) % 1; E('path', { d: B.ellD(100 + i * 22, 70 + v * 120, 4, 3, 20), fill: '#c08020', opacity: f1(1 - v * .5) }, g); }
    if (ty === 'ops') { const x = lerp(300, 176, Math.min(1, u * 1.3)); B.bact(g, x, 130, 0, { L: 30, w: 12 }); [[0, -8, -PI / 2], [-6, 8, PI / 2], [8, 8, PI / 2]].forEach(([dx, dy, a]) => B.Yab(g, x + dx, 130 + dy * 1.6, a, 1.3, {})); }
    if (ty === 'cmp') { const n = Math.floor(u * 8); for (let i = 0; i < n; i++) E('rect', { x: 170 + (i % 4) * 5, y: 160, width: 4, height: 46, rx: 2, fill: i < 4 ? '#3a9a6a' : '#c04a6a', stroke: '#444', 'stroke-width': .3 }, g); if (n >= 7) for (let i = 0; i < 4; i++) E('circle', { cx: 180, cy: f1(150 + ((u * 3 + i / 4) % 1) * 80), r: 1.8, fill: '#2a6ab0' }, g); }
  }
}));
})();
