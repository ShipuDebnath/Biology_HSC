/* ═══════════════════════════════════════════════════════════════════
   visuals6 — স্মৃতি কোষ ও প্রতিরক্ষার ধরন: immuneResponse, memoryCells, immunityKinds, allergy
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B210, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t, cl = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

/* ═════════ মুখ্য ও গৌণ প্রতিরক্ষা সাড়া ═════════ */
/* দিন → লগ মাত্রা: শুরু o, চূড়ায় পৌঁছাতে r দিন, চূড়া p, পরে প্রতি দিনে k হারে কমে, নিম্নসীমা f */
const wave = (d, o, r, p, k, f = 0) => d < o ? 0 : d < o + r ? p * (1 - Math.cos((d - o) / r * PI)) / 2 : Math.max(f, p - (d - o - r) * k);
const IgMc = d => Math.max(wave(d, 5, 7, 1.5, .14), wave(d, 31.5, 4, 1.2, .16)), IgGc = d => d < 31 ? wave(d, 8, 10, 1.9, .03, 1.1) : Math.max(wave(30, 8, 10, 1.9, .03, 1.1), wave(d, 31, 6, 3.7, .022, 2.8));
const PX = d => 46 + d / 60 * 300, PY = L => 214 - L / 4 * 170;
const curveD = (fn, d1) => { let s = ''; for (let d = 0, i = 0; d <= d1 + 1e-6; d += .5, i++) s += (i ? 'L' : 'M') + f1(PX(d)) + ' ' + f1(PY(fn(d))); return s; };
const IR = {
  prim: ['মুখ্য সাড়া', 'মুখ্য (প্রাথমিক) প্রতিরক্ষা সাড়া', 'কোনো অ্যান্টিজেনের সাথে প্রথম সাক্ষাতে উপযুক্ত B কোষ খুঁজে পেয়ে বিভাজিত হতে সময় লাগে — বিলম্ব কাল প্রায় 5–10 দিন। প্রথমে IgM, পরে অল্প IgG তৈরি হয়; মাত্রা কম ও স্বল্পস্থায়ী। এ সময়ে রোগের লক্ষণ দেখা দিতে পারে। শেষে স্মৃতি কোষ তৈরি হয়ে থেকে যায়।'],
  sec: ['গৌণ সাড়া', 'গৌণ (দ্বিতীয়) প্রতিরক্ষা সাড়া', 'একই অ্যান্টিজেন আবার ঢুকলে স্মৃতি কোষ দ্রুত চিনে ফেলে — বিলম্ব কাল মাত্র 1–3 দিন। প্রধানত IgG তৈরি হয়, মাত্রা মুখ্য সাড়ার চেয়ে 10–100 গুণ বা আরও বেশি, স্থায়িত্বও অনেক বেশি; অ্যান্টিবডির বন্ধন-আসক্তিও (অ্যাফিনিটি) বেশি। তাই সাধারণত রোগ হয় না বা মৃদু হয় — টিকা ও বুস্টার ডোজ এ নীতিতে কাজ করে।'],
  both: ['তুলনা', 'মুখ্য বনাম গৌণ সাড়া', 'দ্বিতীয়বার একই অ্যান্টিজেন দিলে সাড়া দ্রুত, প্রবল ও দীর্ঘস্থায়ী — এটিই প্রতিরক্ষাতন্ত্রের "স্মৃতি"। সাড়া নির্দিষ্ট: একটি ভিন্ন অ্যান্টিজেন (B) একই সময়ে দিলে তার বিরুদ্ধে আবার মুখ্য সাড়াই হয়। y অক্ষ লগ স্কেলে — প্রতিটি ধাপ 10 গুণ।']
};
V.immuneResponse = Object.assign({}, B.seg({
  id: 'irs', t: 'মুখ্য ও গৌণ প্রতিরক্ষা সাড়া', H: 270, def: 'both', types: IR,
  cap: 'রক্তে অ্যান্টিবডির মাত্রা বনাম সময় (আদর্শায়িত লেখচিত্র)। 0 দিনে প্রথমবার এবং 30 দিনে দ্বিতীয়বার একই অ্যান্টিজেন (জীবাণু বা টিকা) দেহে প্রবেশ করে। বেগুনি = IgM, নীল = IgG।',
  art(g, C, ty) { B.cacheG(g, 'irsb' + Object.keys(IR).indexOf(ty), gg => {
    if (ty !== 'sec') E('rect', { x: PX(0), y: 40, width: PX(30) - PX(0), height: 174, fill: FK.alpha('#7a4aa8', ty === 'prim' ? .07 : .03) }, gg);
    if (ty !== 'prim') E('rect', { x: PX(30), y: 40, width: PX(60) - PX(30), height: 174, fill: FK.alpha('#2a6ab0', ty === 'sec' ? .08 : .035) }, gg);
    for (let L = 0; L <= 4; L++) { E('path', { d: `M${PX(0)} ${f1(PY(L))}H${PX(60)}`, stroke: FK.alpha(C.fg, .08), 'stroke-width': 1 }, gg); B.tx(gg, 40, PY(L) + 3.5, String(Math.pow(10, L + 1)), { fs: 8.6, a: 'end', c: C.mu }); }
    E('path', { d: `M${PX(0)} 36V${PY(0)}H${PX(60) + 4}`, stroke: FK.alpha(C.fg, .6), 'stroke-width': 1.2, fill: 'none' }, gg);
    [0, 10, 20, 30, 40, 50, 60].forEach(d => { E('path', { d: `M${f1(PX(d))} ${PY(0)}v4`, stroke: FK.alpha(C.fg, .6) }, gg); B.tx(gg, PX(d), PY(0) + 14, String(d), { fs: 8.6, a: 'middle', c: C.mu }); }); B.tx(gg, PX(60), PY(0) + 28, 'দিন', { fs: 9.4, a: 'end', c: C.mu }); B.tx(gg, 8, 24, 'অ্যান্টিবডির মাত্রা (লগ)', { fs: 9.4, c: C.mu });
    [[0, 'প্রথম সংস্পর্শ'], [30, 'দ্বিতীয় সংস্পর্শ']].forEach(([d, t]) => { E('path', { d: `M${PX(d)} 50V${PY(0) - 2}`, stroke: '#c0392b', 'stroke-width': 1.2, 'stroke-dasharray': '3 3' }, gg); E('path', { d: `M${PX(d)} 42l-4 -8h8Z`, fill: '#c0392b' }, gg); B.tx(gg, PX(d) + 4, 48, t, { fs: 9.4, c: '#a8201a', w: 700 }); });
    E('path', { d: curveD(IgMc, 60), stroke: FK.alpha('#7a4aa8', .25), 'stroke-width': 2, fill: 'none' }, gg); E('path', { d: curveD(IgGc, 60), stroke: FK.alpha('#2a6ab0', .25), 'stroke-width': 2, fill: 'none' }, gg);
    /* বিলম্ব কাল */ if (ty !== 'sec') { E('path', { d: `M${PX(0)} ${PY(0) - 10}H${PX(6)}`, stroke: '#7a4aa8', 'stroke-width': 1, 'marker-start': B.mk(gg, '#7a4aa8', 5), 'marker-end': B.mk(gg, '#7a4aa8', 5) }, gg); B.tx(gg, PX(3), PY(0) - 16, 'বিলম্ব 5–10 দিন', { fs: 8.8, a: 'start', c: '#5a3a88' }); }
    if (ty !== 'prim') { E('path', { d: `M${PX(30)} ${PY(0) - 10}H${PX(32)}`, stroke: '#2a6ab0', 'stroke-width': 1, 'marker-start': B.mk(gg, '#2a6ab0', 5), 'marker-end': B.mk(gg, '#2a6ab0', 5) }, gg); B.tx(gg, PX(32) + 3, PY(0) - 6, 'বিলম্ব 1–3 দিন', { fs: 8.8, c: '#2a5a90' }); }
    if (ty === 'both') { B.tx(gg, PX(15), PY(2.3), 'মুখ্য সাড়া', { fs: 10.4, a: 'middle', w: 700, c: '#5a3a88' }); B.tx(gg, PX(46), PY(3.95), 'গৌণ সাড়া', { fs: 10.4, a: 'middle', w: 700, c: '#2a5a90' }); }
    E('path', { d: `M262 ${PY(.4) - 4}h14`, stroke: '#7a4aa8', 'stroke-width': 2.4 }, gg); B.tx(gg, 280, PY(.4), 'IgM', { fs: 9.6, w: 700, c: '#7a4aa8' }); E('path', { d: `M308 ${PY(.4) - 4}h14`, stroke: '#2a6ab0', 'stroke-width': 2.4 }, gg); B.tx(gg, 326, PY(.4), 'IgG', { fs: 9.6, w: 700, c: '#2a6ab0' }); }); },
  anim(g, C, ty, t) { const d0 = ty === 'sec' ? 30 : 0, d1 = ty === 'prim' ? 30 : 60, D = d0 + ((t * 6) % (d1 - d0 + 6)), d = Math.min(d1, D), q = Math.round(d * 2) / 2;
    B.cacheG(g, 'irsc' + (Object.keys(IR).indexOf(ty) * 1000 + q * 2), gg => { const seg = fn => { let s = ''; for (let x = d0, i = 0; x <= q + 1e-6; x += .5, i++) s += (i ? 'L' : 'M') + f1(PX(x)) + ' ' + f1(PY(fn(x))); return s; };
      E('path', { d: seg(IgMc), stroke: '#7a4aa8', 'stroke-width': 2.6, fill: 'none', 'stroke-linejoin': 'round' }, gg); E('path', { d: seg(IgGc), stroke: '#2a6ab0', 'stroke-width': 2.6, fill: 'none', 'stroke-linejoin': 'round' }, gg);
      E('path', { d: `M${f1(PX(q))} 40V${PY(0)}`, stroke: FK.alpha(C.fg, .3), 'stroke-width': 1 }, gg); E('circle', { cx: f1(PX(q)), cy: f1(PY(IgGc(q))), r: 3.4, fill: '#2a6ab0' }, gg);
      const v = Math.pow(10, IgGc(q) + 1), p = Math.pow(10, Math.floor(Math.log10(v)) - 1), r = Math.round(v / p) * p; B.tx(gg, 46, 258, 'দিন ' + q.toFixed(0) + '  ·  IgG মাত্রা ≈ ' + r.toLocaleString('en-US') + ' (আপেক্ষিক একক)', { fs: 9.6, w: 700, c: '#2a5a90' });}); }
}));

/* ═════════ স্মৃতি কোষ: সম্প্রসারণ, সংকোচন, স্মৃতি ═════════ */
const MC = [
  { t: 'নাইভ কোষ', en: 'Naive lymphocytes', d: 'কোনো নির্দিষ্ট অ্যান্টিজেনকে চেনার মতো B বা T কোষ দেহে খুবই কম — আনুমানিক এক লাখে একটি। এরা এখনো অ্যান্টিজেন "দেখেনি" (নাইভ)।' },
  { t: 'ক্লোনাল সম্প্রসারণ', en: 'Clonal expansion', d: 'অ্যান্টিজেন পেয়ে বাছাই হওয়া কোষ প্রায় এক সপ্তাহ ধরে বারবার বিভাজিত হয়ে হাজার হাজার কার্যকরী কোষ (প্লাজমা কোষ, সাইটোটক্সিক T কোষ) তৈরি করে — এরা জীবাণু দমন করে।' },
  { t: 'সংকোচন', en: 'Contraction', d: 'জীবাণু নির্মূল হলে প্রায় 90–95% কার্যকরী কোষ পরিকল্পিত কোষমৃত্যুতে (অ্যাপোপটোসিস) মরে যায় — অপ্রয়োজনীয় সাড়া থামে।' },
  { t: 'দীর্ঘস্থায়ী স্মৃতি', en: 'Memory phase', d: 'বাকি 5–10% স্মৃতি B ও স্মৃতি T কোষ হয়ে অস্থিমজ্জা, লসিকাগ্রন্থি ও প্লীহায় বছরের পর বছর (কখনো আজীবন) বেঁচে থাকে — সংখ্যায় নাইভ কোষের চেয়ে অনেক বেশি।' },
  { t: 'পুনরায় সাক্ষাৎ', en: 'Recall response', d: 'একই জীবাণু আবার এলে বেশি সংখ্যক, দ্রুত সাড়া দিতে সক্ষম স্মৃতি কোষ কয়েক দিনেই বিশাল সম্প্রসারণ ঘটায় — গৌণ সাড়া; রোগ হওয়ার আগেই জীবাণু দমন।' }
];
/* কোষসংখ্যা (লগ) বনাম সময় t ∈ [0, 5] */
const MN = t => t < 1 ? .3 : t < 2 ? .3 + 3 * Math.sin((t - 1) * PI / 2) : t < 3 ? 3.3 - 1.8 * (t - 2) : t < 4 ? 1.5 - .2 * (t - 3) : 1.3 + 3.2 * Math.sin(Math.min(1, (t - 4) * 1.6) * PI / 2);
const MGX = t => 30 + t / 5 * 318, MGY = L => 236 - L / 4.6 * 88;
V.memoryCells = Object.assign({ t: 'স্মৃতি কোষ কীভাবে তৈরি হয় ও কাজ করে', k: ['2d', 'anim', 'steps'], cap: 'একটি নির্দিষ্ট অ্যান্টিজেনের বিরুদ্ধে লিম্ফোসাইটের সংখ্যা কীভাবে বাড়ে-কমে (নিচে লগ স্কেলে আদর্শায়িত লেখচিত্র)। স্মৃতি কোষের দুটি সুবিধা: সংখ্যায় বেশি এবং দ্রুত সক্রিয় হয় — তাই গৌণ সাড়া দ্রুত ও প্রবল। গুটিবসন্তের টিকার স্মৃতি B কোষ কয়েক দশক পরেও পাওয়া গেছে।' },
  BK.steps({ W: 360, H: 260, label: 'স্মৃতি কোষ', dur: 3, stages: MC,
    draw(g, C, s, u) { const tt = s + u;
      B.cacheG(g, 'mcg', gg => { E('rect', { x: 8, y: 140, width: 344, height: 112, rx: 8, fill: '#fafaf6', stroke: FK.alpha(C.fg, .15), 'stroke-width': .7 }, gg); E('path', { d: `M30 146V${MGY(0)}H350`, stroke: FK.alpha(C.fg, .5), 'stroke-width': 1, fill: 'none' }, gg); B.tx(gg, 34, 154, 'নির্দিষ্ট কোষের সংখ্যা (লগ)', { fs: 8.8, c: C.mu }); B.tx(gg, 348, 248, 'সময় →', { fs: 8.8, a: 'end', c: C.mu }); for (let i = 1; i < 5; i++) E('path', { d: `M${f1(MGX(i))} 146V${MGY(0)}`, stroke: FK.alpha(C.fg, .1), 'stroke-dasharray': '2 3' }, gg); E('path', { d: `M${MGX(1)} ${MGY(0) - 2}v-8M${MGX(4)} ${MGY(0) - 2}v-8`, stroke: '#c0392b', 'stroke-width': 2 }, gg); B.tx(gg, MGX(1) + 3, MGY(0) - 4, 'অ্যান্টিজেন', { fs: 8.4, c: '#a8201a' }); B.tx(gg, MGX(4) + 3, MGY(0) - 4, 'আবার', { fs: 8.4, c: '#a8201a' }); });
      const q = Math.round(tt * 20) / 20; B.cacheG(g, 'mcc' + Math.round(q * 20), gg => { let d = ''; for (let x = 0, i = 0; x <= q + 1e-6; x += .05, i++) d += (i ? 'L' : 'M') + f1(MGX(x)) + ' ' + f1(MGY(MN(x))); E('path', { d, stroke: '#2a6ab0', 'stroke-width': 2.4, fill: 'none' }, gg); E('circle', { cx: f1(MGX(q)), cy: f1(MGY(MN(q))), r: 3.4, fill: '#2a6ab0' }, gg); });
      /* ওপরে কোষের প্রতিচ্ছবি: সংখ্যা লেখচিত্র অনুযায়ী (প্রতীকী) */
      const key = s * 10 + Math.min(9, Math.floor(u * 10));
      B.cacheG(g, 'mcp' + key, gg => { const L = MN(tt), n = s === 2 ? 12 : Math.max(1, Math.min(30, Math.round(Math.pow(10, L / 4.6 * 1.5)))), mem = s === 2 ? 2 : s === 3 ? n : s === 4 ? Math.max(3, Math.round(n * .35)) : 0;
        for (let i = 0; i < n; i++) { const c = i % 10, r = Math.floor(i / 10), x = 30 + c * 32 + (r % 2) * 16, y = 44 + r * 30; if (i < mem) B.bcell(gg, x, y, 11, { rc: '#c08a20' }); else if (s === 2) { const ff = E('g', { opacity: f1(1 - u * .7) }, gg); E('path', { d: B.ellD(x, y, 10 * (1 - u * .3), 9 * (1 - u * .3), 0), fill: '#eee6e0', stroke: '#b0a090', 'stroke-width': .7, 'stroke-dasharray': '2 2' }, ff); for (let k = 0; k < 4; k++) E('circle', { cx: f1(x - 5 + B.rnd(i * 4 + k) * 10), cy: f1(y - 4 + B.rnd(i * 4 + k + 2) * 8), r: 1.4, fill: '#8a7a9a' }, ff); } else if (s === 0) B.bcell(gg, x, y, 11, { rc: '#2a6ab0', fill: '#eef2f6' }); else B.plasma(gg, x, y, 10); }
        B.tx(gg, 8, 18, MC[s].t, { fs: 11, w: 700, c: '#a8201a' }); const lg = s === 0 ? [['#2a6ab0', 'নাইভ কোষ']] : s === 2 ? [['#c08a20', 'স্মৃতি কোষ'], ['#8a7a9a', 'মরে যাচ্ছে (অ্যাপোপটোসিস)']] : s === 3 ? [['#c08a20', 'স্মৃতি কোষ']] : [['#2a6ab0', 'কার্যকরী কোষ'], ...(s === 4 ? [['#c08a20', 'স্মৃতি কোষ']] : [])]; lg.forEach(([c, t], i) => { E('circle', { cx: 196 + i * 0, cy: 14 + i * 14, r: 4, fill: c }, gg); B.tx(gg, 204, 18 + i * 14, t, { fs: 9.4, c: C.fg }); }); }); }
  }));

/* ═════════ প্রতিরক্ষার প্রকারভেদ: প্রাকৃতিক/কৃত্রিম × সক্রিয়/নিষ্ক্রিয় ═════════ */
const IK = {
  na: ['প্রাকৃতিক সক্রিয়', 'প্রাকৃতিকভাবে অর্জিত সক্রিয় প্রতিরক্ষা', 'রোগে আক্রান্ত হয়ে সেরে ওঠার পর দেহ নিজেই অ্যান্টিবডি ও স্মৃতি কোষ তৈরি করে — যেমন একবার হাম বা জলবসন্ত হলে সাধারণত আর হয় না। ধীরে তৈরি হয় (1–2 সপ্তাহ), কিন্তু দীর্ঘস্থায়ী, প্রায়ই আজীবন। ঝুঁকি: রোগের কষ্ট ও জটিলতা সহ্য করতে হয়।', 0, 0],
  np: ['প্রাকৃতিক নিষ্ক্রিয়', 'প্রাকৃতিকভাবে অর্জিত নিষ্ক্রিয় প্রতিরক্ষা', 'মায়ের তৈরি তৈরি অ্যান্টিবডি সন্তান পায় — গর্ভকালে অমরা পার হয়ে IgG এবং জন্মের পর শালদুধ ও বুকের দুধে IgA। নবজাতক তাৎক্ষণিক সুরক্ষা পায়, কিন্তু নিজের স্মৃতি কোষ তৈরি হয় না — কয়েক সপ্তাহ থেকে কয়েক মাসে (প্রায় 6 মাস) মিলিয়ে যায়। তাই শিশুকে সময়মতো টিকা দিতে হয়।', 1, 0],
  aa: ['কৃত্রিম সক্রিয়', 'কৃত্রিমভাবে অর্জিত সক্রিয় প্রতিরক্ষা', 'টিকা দিয়ে রোগ না ঘটিয়েই দেহকে নিজের অ্যান্টিবডি ও স্মৃতি কোষ তৈরি করানো হয় — যেমন BCG, পেন্টাভ্যালেন্ট, MR টিকা। তৈরি হতে 1–2 সপ্তাহ লাগে, দীর্ঘস্থায়ী (বছর থেকে আজীবন); প্রয়োজনে বুস্টার ডোজ।', 0, 1],
  ap: ['কৃত্রিম নিষ্ক্রিয়', 'কৃত্রিমভাবে অর্জিত নিষ্ক্রিয় প্রতিরক্ষা', 'অন্য মানুষ বা প্রাণীর (যেমন ঘোড়ার) দেহে তৈরি করা অ্যান্টিবডি সরাসরি ইনজেকশন দেওয়া হয় — যেমন সাপে কাটলে অ্যান্টিভেনম, ধনুষ্টংকারের আশঙ্কায় অ্যান্টি-টিটেনাস সিরাম বা ইমিউনোগ্লোবিউলিন, জলাতঙ্কের ইমিউনোগ্লোবিউলিন। তাৎক্ষণিক সুরক্ষা, কিন্তু স্বল্পস্থায়ী (কয়েক সপ্তাহ), স্মৃতি নেই; প্রাণীর সিরামে কখনো অ্যালার্জি হতে পারে।', 1, 1]
};
const CXk = [138, 284], CYk = [86, 182], CW = 140, CH = 90;
const cellIcon = (g, k, x, y, sel, t, mv) => { if (mv) { if (k === 'np') for (let i = 0; i < 3; i++) { const v = (t * .4 + i / 3) % 1; B.abY(g, x - 20 + v * 70, y - 10 + i * 10, -PI / 2, 1.1); } else { const q = .5 + .5 * Math.sin(t * 2.2); E('rect', { x: x - CW / 2 - 3, y: y - CH / 2 - 3, width: CW + 6, height: CH + 6, rx: 11, fill: 'none', stroke: '#c08a20', 'stroke-width': 1, opacity: f1(.2 + q * .5) }, g); } return; } /* x,y = ঘরের কেন্দ্র */
  if (k === 'na') { B.virus(g, x - 40, y - 8, 8); E('path', { d: `M${x - 28} ${y - 8}H${x - 14}`, stroke: '#888', 'stroke-width': 1.2, 'marker-end': B.mk(g, '#888', 5) }, g); B.bcell(g, x + 4, y - 6, 15, { rc: '#2a6ab0' }); [0, 1, 2].forEach(i => B.abY(g, x + 30 + i * 9, y - 14 + i * 9, -PI / 2 + .3, 1.1)); B.tx(g, x, y + 30, 'রোগে আক্রান্ত হয়ে', { fs: 9.2, a: 'middle', c: '#5a5a5a' }); }
  if (k === 'np') { E('path', { d: `M${x - 64} ${y - 30}H${x - 14}V${y + 18}H${x - 64}Z`, fill: '#f6d8d4', stroke: '#c08a80', 'stroke-width': .8 }, g); E('path', { d: `M${x - 14} ${y - 30}h12v48h-12Z`, fill: '#e0a090', opacity: .8 }, g); E('path', { d: `M${x - 2} ${y - 30}H${x + 62}V${y + 18}H${x - 2}Z`, fill: '#fbeae4', stroke: '#d0a8a0', 'stroke-width': .8 }, g); B.tx(g, x - 39, y - 34, 'মা', { fs: 9, a: 'middle', c: '#8a4a3a' }); B.tx(g, x - 8, y - 34, 'অমরা', { fs: 8.6, a: 'middle', c: '#8a4a3a' }); B.tx(g, x + 30, y - 34, 'ভ্রূণ / শিশু', { fs: 9, a: 'middle', c: '#8a4a3a' }); [[-52, -14], [-36, 2], [-28, -20]].forEach(([dx, dy]) => B.abY(g, x + dx, y + dy + 6, -PI / 2, 1.1)); if (!sel) for (let i = 0; i < 3; i++) B.abY(g, x - 20 + i / 3 * 70, y - 10 + i * 10, -PI / 2, 1.1); B.tx(g, x, y + 32, 'অমরা (IgG) ও মায়ের দুধ (IgA)', { fs: 9.2, a: 'middle', c: '#5a5a5a' }); }
  if (k === 'aa' || k === 'ap') { const sx = x - 56, sy = y - 6; E('path', { d: `M${sx} ${sy - 9}h56v18h-56Z`, fill: '#eef4fa', stroke: '#6a8aa8', 'stroke-width': 1 }, g); E('path', { d: `M${sx - 10} ${sy}h10M${sx - 10} ${sy - 9}v18M${sx + 56} ${sy}h16`, stroke: '#6a8aa8', 'stroke-width': 1.6 }, g); E('path', { d: `M${sx + 72} ${sy}h12`, stroke: '#888', 'stroke-width': 1 }, g);
    if (k === 'aa') { for (let i = 0; i < 3; i++) B.virus(g, sx + 12 + i * 16, sy, 4.6, {}); E('path', { d: `M${x + 30} ${sy}h8`, stroke: '#888', 'stroke-width': 1.2, 'marker-end': B.mk(g, '#888', 5) }, g); B.bcell(g, x + 52, sy, 12, { rc: '#c08a20' }); B.tx(g, x + 52, sy + 24, 'স্মৃতি', { fs: 8.6, a: 'middle', c: '#8a6010' }); B.tx(g, x, y + 30, 'টিকা (দুর্বল জীবাণু / অ্যান্টিজেন)', { fs: 9.2, a: 'middle', c: '#5a5a5a' }); }
    else { for (let i = 0; i < 4; i++) B.abY(g, sx + 10 + i * 12, sy + 5, -PI / 2, 1); B.tx(g, x + 52, sy + 4, 'সিরাম', { fs: 9, a: 'middle', c: '#2a5a90' }); B.tx(g, x, y + 30, 'তৈরি অ্যান্টিবডি (অ্যান্টিসিরাম)', { fs: 9.2, a: 'middle', c: '#5a5a5a' }); } } };
V.immunityKinds = Object.assign({}, B.seg({
  id: 'ikd', t: 'অর্জিত প্রতিরক্ষার প্রকারভেদ', H: 290, def: 'aa', types: Object.fromEntries(Object.entries(IK).map(([k, v]) => [k, v.slice(0, 3)])),
  cap: 'জন্মের পর নির্দিষ্ট জীবাণুর বিরুদ্ধে অর্জিত (অভিযোজিত) প্রতিরক্ষা চার রকম। সক্রিয়: দেহ নিজেই অ্যান্টিবডি ও স্মৃতি কোষ বানায় — ধীর কিন্তু দীর্ঘস্থায়ী। নিষ্ক্রিয়: তৈরি অ্যান্টিবডি বাইরে থেকে পায় — তাৎক্ষণিক কিন্তু স্বল্পস্থায়ী, স্মৃতি নেই।',
  art(g, C, ty) { B.cacheG(g, 'ikdb' + Object.keys(IK).indexOf(ty), gg => { const [cc, rr] = IK[ty].slice(3);
    B.tx(gg, CXk[0], 30, 'সক্রিয়', { fs: 11.4, a: 'middle', w: 700, c: '#2e6a3e' }); B.tx(gg, CXk[1], 30, 'নিষ্ক্রিয়', { fs: 11.4, a: 'middle', w: 700, c: '#8a5a20' }); B.tx(gg, CXk[0], 42, 'দেহ নিজে বানায়', { fs: 8.8, a: 'middle', c: C.mu }); B.tx(gg, CXk[1], 42, 'তৈরি অ্যান্টিবডি পায়', { fs: 8.8, a: 'middle', c: C.mu });
    ['প্রাকৃতিক', 'কৃত্রিম'].forEach((t, i) => B.tx(gg, 34, CYk[i] + 4, t, { fs: 11, a: 'middle', w: 700, c: '#2a5a90' }));
    Object.entries(IK).forEach(([k, v]) => { const x = CXk[v[3]], y = CYk[v[4]], on = k === ty; E('rect', { x: x - CW / 2, y: y - CH / 2, width: CW, height: CH, rx: 9, fill: on ? '#fffdf4' : FK.alpha(C.fg, .03), stroke: on ? '#c08a20' : FK.alpha(C.fg, .15), 'stroke-width': on ? 2 : .8 }, gg); if (!on) { const gi = E('g', { opacity: .45 }, gg); cellIcon(gi, k, x, y, false, 0); } });
    const act = cc === 0; E('rect', { x: 8, y: 238, width: 344, height: 44, rx: 8, fill: FK.alpha(act ? '#2e6a3e' : '#8a5a20', .07) }, gg);
    [['শুরু', act ? 'ধীরে (1–2 সপ্তাহ)' : 'তাৎক্ষণিক'], ['স্থায়িত্ব', act ? 'দীর্ঘ (বছর–আজীবন)' : 'স্বল্প (সপ্তাহ–মাস)'], ['স্মৃতি কোষ', act ? 'তৈরি হয়' : 'হয় না']].forEach(([a, b], i) => { B.tx(gg, 20 + i * 114, 254, a, { fs: 9, c: C.mu }); B.tx(gg, 20 + i * 114, 272, b, { fs: 10.2, w: 700, c: act ? '#2e6a3e' : '#8a5a20' }); }); }); },
  anim(g, C, ty, t) { const v = IK[ty], ki = Object.keys(IK).indexOf(ty); B.cacheG(g, 'ikdi' + ki, gg => cellIcon(gg, ty, CXk[v[3]], CYk[v[4]], true, 0)); cellIcon(g, ty, CXk[v[3]], CYk[v[4]], true, t, true); }
}));

/* ═════════ অ্যালার্জি (অতিসংবেদনশীলতা) ═════════ */
const AL = [
  { t: 'প্রথম সংস্পর্শ', en: 'Sensitisation', d: 'নিরীহ কোনো পদার্থ (অ্যালার্জেন — ধুলার মাইট, পরাগরেণু, চিংড়ি, কিছু ওষুধ) প্রথমবার ঢুকলে কিছু মানুষের দেহে T সহায়ক কোষের সংকেতে B কোষ IgE অ্যান্টিবডি তৈরি করে। এ সময় কোনো লক্ষণ হয় না।' },
  { t: 'মাস্ট কোষে IgE', en: 'IgE arms mast cells', d: 'IgE এর Fc অংশ টিস্যুর মাস্ট কোষ (ও রক্তের বেসোফিল) এর গ্রাহকে বসে যায় — মানুষটি এখন ওই অ্যালার্জেনে "সংবেদনশীল"।' },
  { t: 'আবার সংস্পর্শ', en: 'Re-exposure', d: 'একই অ্যালার্জেন আবার এলে তা পাশাপাশি দুটি IgE কে একসাথে জুড়ে দেয় (ক্রস-লিংক) — মাস্ট কোষ সক্রিয় হয়।' },
  { t: 'হিস্টামিন নিঃসরণ', en: 'Degranulation', d: 'কয়েক মিনিটের মধ্যে মাস্ট কোষের দানা ফেটে হিস্টামিন ও অন্যান্য রাসায়নিক বেরিয়ে আসে।' },
  { t: 'লক্ষণ', en: 'Symptoms', d: 'হিস্টামিনে রক্তনালি প্রসারিত ও ভেদ্য হয় (লাল হওয়া, ফোলা, চুলকানি, আমবাত), শ্বাসনালির পেশি সংকুচিত হয় (হাঁপানি), শ্লেষ্মা বাড়ে (হাঁচি, নাক দিয়ে পানি)। মারাত্মক রূপ অ্যানাফাইল্যাক্সিস — রক্তচাপ পড়ে যায়, জরুরি চিকিৎসা (অ্যাড্রেনালিন) লাগে। প্রতিকার: অ্যালার্জেন এড়ানো, অ্যান্টিহিস্টামিন ওষুধ — চিকিৎসকের পরামর্শে।' }
];
const HCc = '#3a5aa8';
const mast = (gg, x, y) => { B.organ(gg, B.ellD(x, y, 64, 46, 0), 'neu', { sw: 1 }); E('path', { d: B.ellD(x - 6, y + 6, 18, 14, 10), fill: '#7a5a9a', stroke: '#4a2a6a', 'stroke-width': .6 }, gg); let gd = ''; for (let i = 0; i < 46; i++) { const a = B.rnd(i) * 2 * PI, r = 18 + B.rnd(i + 50) * 38; gd += B.ellD(x + Math.cos(a) * r, y + Math.sin(a) * r * .68, 2.8, 2.8, 0); } E('path', { d: gd, fill: '#4a2a6a' }, gg); };
const pollen = (g, x, y, r = 9) => { E('path', { d: B.ellD(x, y, r, r, 0), fill: '#e8c040', stroke: '#9a7a10', 'stroke-width': .8 }, g); let sp = ''; for (let i = 0; i < 12; i++) { const a = i / 12 * 2 * PI; sp += `M${f1(x + Math.cos(a) * r)} ${f1(y + Math.sin(a) * r)}l${f1(Math.cos(a) * 3)} ${f1(Math.sin(a) * 3)}`; } E('path', { d: sp, stroke: '#9a7a10', 'stroke-width': 1.2 }, g); };
V.allergy = Object.assign({ t: 'অ্যালার্জি কীভাবে হয়', k: ['2d', 'anim', 'steps'], cap: 'অ্যালার্জি হলো নিরীহ পদার্থের বিরুদ্ধে প্রতিরক্ষাতন্ত্রের অতিরিক্ত (অতিসংবেদনশীল) সাড়া — এখানে IgE ও মাস্ট কোষ মূল ভূমিকা রাখে। প্রথম সংস্পর্শে কিছু হয় না; পরের সংস্পর্শে দ্রুত লক্ষণ দেখা দেয়।' },
  BK.steps({ W: 360, H: 260, label: 'অ্যালার্জি', dur: 3, stages: AL,
    draw(g, C, s, u) { const mx = 200, my = 160;
      if (s === 0) { B.cacheG(g, 'alb', gg => { B.bcell(gg, 230, 130, 26, { rc: '#8a4a9a' }); B.tcell(gg, 120, 150, 20, { lab: 'Th2' }); }); const x = lerp(30, 90, cl(u * 1.5)); pollen(g, x, 80); if (u > .4) for (let i = 0; i < 6; i++) { const v = ((u - .4) * 1.6 + i / 6) % 1; B.abY(g, 260 + v * 80, 110 + i * 10 - v * 20, -.3, 1.3); } if (u > .2) for (let i = 0; i < 5; i++) { const v = ((u - .2) * 2 + i / 5) % 1; E('circle', { cx: f1(lerp(142, 200, v)), cy: f1(144 - i * 3), r: 1.8, fill: '#3a9a5a' }, g); } }
      if (s >= 1) B.cacheG(g, 'alm', gg => mast(gg, mx, my));
      if (s >= 1) { const n = 8; for (let i = 0; i < n; i++) { const a = -PI + .35 + i * (PI - .7) / (n - 1), p = s === 1 ? cl(u * 1.6 - i * .08) : 1, r = lerp(110, 50, p); if (s >= 2 && (i === 3 || i === 4)) continue; B.abY(g, mx + Math.cos(a) * r * 1.26, my + Math.sin(a) * r * .94, a, 1.5); } }
      if (s >= 2) { const y = s === 2 ? lerp(20, 88, cl(u * 1.4)) : 88, x = mx; pollen(g, x, y, 10); if (s >= 3) { B.abY(g, mx - 14, my - 44, -PI / 2 + .35, 1.5); B.abY(g, mx + 14, my - 44, -PI / 2 - .35, 1.5); } else if (s === 2 && u > .7) { B.abY(g, mx - 14, my - 44, -PI / 2 + .35, 1.5); B.abY(g, mx + 14, my - 44, -PI / 2 - .35, 1.5); } else { B.abY(g, mx - 22, my - 44, -PI / 2, 1.5); B.abY(g, mx + 22, my - 44, -PI / 2, 1.5); } }
      if (s >= 3) { const n = s === 3 ? 22 : 30; for (let i = 0; i < n; i++) { const a = B.rnd(i + 7) * 2 * PI, v = s === 3 ? cl(u * 1.4 - B.rnd(i) * .4) : ((u * .6 + B.rnd(i)) % 1), r = 50 + v * 70; E('circle', { cx: f1(mx + Math.cos(a) * r * 1.2), cy: f1(my + Math.sin(a) * r * .8), r: f1(2.6 * (1 - v * .5)), fill: '#4a2a6a', opacity: f1(1 - v * .6) }, g); } }
      if (s === 4) B.cacheG(g, 'als', gg => { [['রক্তনালি প্রসারণ — লাল, ফোলা', 34], ['শ্বাসনালি সংকোচন — হাঁপানি', 52], ['শ্লেষ্মা — হাঁচি, সর্দি', 70]].forEach(([t, y]) => B.tx(gg, 8, y, t, { fs: 9.6, c: '#8a2a4a' })); });
      B.cacheG(g, 'all' + s, gl => { B.tx(gl, 8, 18, AL[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s >= 1) B.tx(gl, mx, 228, 'মাস্ট কোষ', { fs: 10, a: 'middle', w: 700, c: '#6a3a8a' }); if (s === 0) { B.tx(gl, 230, 176, 'B কোষ → IgE', { fs: 10, a: 'middle', c: '#6a3a8a' }); B.tx(gl, 60, 108, 'অ্যালার্জেন', { fs: 9.6, a: 'middle', c: '#8a6a10' }); } if (s >= 3) B.tx(gl, 352, 250, 'হিস্টামিন', { fs: 10, a: 'end', w: 700, c: '#4a2a6a' }); if (s === 1) B.tx(gl, 352, 250, 'IgE (Fc দিয়ে বসা)', { fs: 10, a: 'end', c: HCc }); }); }
  }));
})();
