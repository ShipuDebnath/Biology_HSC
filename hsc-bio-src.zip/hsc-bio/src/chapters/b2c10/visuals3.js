/* ═══════════════════════════════════════════════════════════════════
   visuals3 — তৃতীয় প্রতিরক্ষা স্তর: lymphOrgans, lymphNodeImm, antigenPresent, clonalSelection, humoralImmunity, cellImmunity
   কোষ-সহায়ক: B.bcell, B.tcell, B.plasma, B.abY (ছোট অ্যান্টিবডি চিহ্ন)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B210, PI = Math.PI;
const f1 = B.f1, sm = B.sm, hits = B.hits;
const lerp = (a, b, t) => a + (b - a) * t;

/* ছোট Y আকৃতির অ্যান্টিবডি; a = দিক (রেডিয়ান, Y এর বাহু যেদিকে) */
B.abY = (g, x, y, a = -PI / 2, s = 1, col) => { x = +x; y = +y; const c = col || B.TS('ab').dk, ca = Math.cos(a), sa = Math.sin(a), L = 5 * s, A = 4 * s;
  const mx = x + ca * L, my = y + sa * L; E('path', { d: `M${f1(x)} ${f1(y)}L${f1(mx)} ${f1(my)}M${f1(mx)} ${f1(my)}L${f1(mx + Math.cos(a - .6) * A)} ${f1(my + Math.sin(a - .6) * A)}M${f1(mx)} ${f1(my)}L${f1(mx + Math.cos(a + .6) * A)} ${f1(my + Math.sin(a + .6) * A)}`, stroke: c, 'stroke-width': 1.3 * s, fill: 'none', 'stroke-linecap': 'round' }, g); };
/* B কোষ: লিম্ফোসাইট + গায়ে অ্যান্টিবডি গ্রাহক (BCR) */
B.bcell = (g, x, y, r, o = {}) => { x = +x; y = +y; const t = B.TS('bcl'); E('path', { d: B.ellD(x, y, r, r * .95, 0), fill: o.fill || t.lt, stroke: t.dk, 'stroke-width': .8 }, g); E('path', { d: B.ellD(x - r * .06, y + r * .04, r * .74, r * .7, 15), fill: '#3f2b7a', stroke: '#24164e', 'stroke-width': .5 }, g); if (o.rec !== false) for (let i = 0; i < 8; i++) { const a = i / 8 * 2 * PI + .2; B.abY(g, x + Math.cos(a) * r, y + Math.sin(a) * r * .95, a, r / 14, o.rc); } };
/* T কোষ: লিম্ফোসাইট + গায়ে TCR (ছোট দণ্ড) */
B.tcell = (g, x, y, r, o = {}) => { x = +x; y = +y; const t = B.TS('tcl'); E('path', { d: B.ellD(x, y, r, r * .95, 0), fill: o.fill || t.lt, stroke: t.dk, 'stroke-width': .8 }, g); E('path', { d: B.ellD(x + r * .05, y, r * .72, r * .7, -20), fill: '#3f2b7a', stroke: '#24164e', 'stroke-width': .5 }, g); let d = ''; for (let i = 0; i < 9; i++) { const a = i / 9 * 2 * PI, px = x + Math.cos(a) * r, py = y + Math.sin(a) * r * .95; d += `M${f1(px)} ${f1(py)}l${f1(Math.cos(a) * r * .28)} ${f1(Math.sin(a) * r * .28)}m${f1(-Math.sin(a) * 1.6)} ${f1(Math.cos(a) * 1.6)}l${f1(Math.sin(a) * 3.2)} ${f1(-Math.cos(a) * 3.2)}`; } E('path', { d, stroke: o.tc || t.dk, 'stroke-width': 1.2, fill: 'none' }, g); if (o.lab) B.tx(g, x, y + 3.4, o.lab, { fs: Math.max(7, r * .55), a: 'middle', w: 700, c: '#fff' }); };
/* প্লাজমা কোষ: বড়, বাঁকা নিউক্লিয়াস (ঘড়ির কাঁটার মতো ক্রোমাটিন), প্রচুর ER */
B.plasma = (g, x, y, r) => { x = +x; y = +y; const t = B.TS('bcl'); E('path', { d: B.ellD(x, y, r * 1.2, r, 15), fill: '#d4e4f4', stroke: t.dk, 'stroke-width': .8 }, g); let er = ''; for (let i = 0; i < 5; i++) er += `M${f1(x - r * .1)} ${f1(y - r * .6 + i * r * .3)}q${f1(r * .4)} ${f1(-r * .1)} ${f1(r * .9)} 0`; E('path', { d: er, stroke: '#7aa0c8', 'stroke-width': .9, fill: 'none' }, g); const nx = x - r * .55, ny = y; E('circle', { cx: f1(nx), cy: f1(ny), r: f1(r * .45), fill: '#5a4a96', stroke: '#2e2264', 'stroke-width': .5 }, g); let cd = ''; for (let i = 0; i < 6; i++) { const a = i / 6 * 2 * PI; cd += B.ellD(nx + Math.cos(a) * r * .3, ny + Math.sin(a) * r * .3, r * .08, r * .08, 0); } E('path', { d: cd, fill: '#2e2264' }, g); };

/* ═════════ লসিকা অঙ্গসমূহ ═════════ */
const BC = 180, BY = 10, BH = 284, bs = BH / 440, by = v => BY + v * bs, bx = v => BC + v * bs;
V.lymphOrgans = Object.assign({ t: 'প্রতিরক্ষা ব্যবস্থার অঙ্গ (লসিকা অঙ্গ)', k: ['2d', 'anim', 'int', 'quiz'], cap: 'মুখ্য (প্রাথমিক) লসিকা অঙ্গে লিম্ফোসাইট তৈরি ও পরিণত হয় — অস্থিমজ্জায় B কোষ, থাইমাসে T কোষ। গৌণ লসিকা অঙ্গে (লসিকাগ্রন্থি, প্লীহা, টনসিল, পেয়ার্স প্যাচ, অ্যাপেন্ডিক্স) পরিণত লিম্ফোসাইট অ্যান্টিজেনের সংস্পর্শে এসে সক্রিয় হয়। দেহে প্রায় 500–700টি লসিকাগ্রন্থি থাকে; লসিকানালি এদের যুক্ত করে।' },
  BK.diagram({ W: 360, H: 300, label: 'লসিকা অঙ্গ', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k));
      B.cacheG(g, 'lob', gg => { B.body(gg, C, BC, BY, BH); /* লসিকানালির জাল */ let lv = `M${bx(0)} ${f1(by(76))}V${f1(by(200))}`; [[-30, 86, -50, 130], [30, 86, 50, 130], [-14, 210, -24, 300], [14, 210, 24, 300], [-24, 300, -22, 400], [24, 300, 22, 400], [-50, 130, -70, 230], [50, 130, 70, 230], [0, 200, -14, 210], [0, 200, 14, 210], [0, 76, -30, 86], [0, 76, 30, 86], [-8, 58, 0, 76], [8, 58, 0, 76]].forEach(([a, b, c, d]) => lv += `M${f1(bx(a))} ${f1(by(b))}L${f1(bx(c))} ${f1(by(d))}`); E('path', { d: lv, stroke: '#7ab070', 'stroke-width': 1.4, fill: 'none', opacity: .8 }, gg); });
      const node = (gg, x, y, r = 3.6) => { E('path', { d: B.ellD(bx(x), by(y), r, r * .7, 20), fill: B.TS('lymn').c, stroke: B.TS('lymn').dk, 'stroke-width': .7 }, gg); };
      [[-8, 58], [8, 58], [-12, 66], [12, 66]].forEach(([x, y]) => node(P('cerv'), x, y)); [[-38, 100], [-42, 106], [38, 100], [42, 106]].forEach(([x, y]) => node(P('axil'), x, y)); [[-20, 252], [-26, 258], [20, 252], [26, 258]].forEach(([x, y]) => node(P('ingu'), x, y)); [[-6, 190], [6, 192], [0, 182]].forEach(([x, y]) => node(P('mes'), x, y, 3));
      [-1, 1].forEach(sd => E('path', { d: B.ellD(bx(sd * 6), by(46), 3, 4, 0), fill: '#e87a7a', stroke: '#a03a3a', 'stroke-width': .6 }, P('tons')));
      B.organ(P('thy'), sm([[bx(-8), by(84)], [bx(0), by(80)], [bx(8), by(84)], [bx(10), by(104)], [bx(0), by(110)], [bx(-10), by(104)]], true, .5), 'thy', { sw: .7 });
      B.organ(P('spl'), B.ellD(bx(36), by(158), 7, 11, -25), 'art', { sw: .7, op: .85 });
      /* অস্থিমজ্জা: ঊরুর হাড় ও শ্রোণি */ [-1, 1].forEach(sd => { B.tube(P('bm'), `M${f1(bx(sd * 22))} ${f1(by(276))}L${f1(bx(sd * 24))} ${f1(by(350))}`, 6, 'bone', { sw: .6, hl: false }); E('path', { d: `M${f1(bx(sd * 22))} ${f1(by(282))}L${f1(bx(sd * 24))} ${f1(by(344))}`, stroke: '#c84a4a', 'stroke-width': 2.2, opacity: .8 }, P('bm')); }); B.organ(P('bm'), sm([[bx(-34), by(232)], [bx(0), by(244)], [bx(34), by(232)], [bx(30), by(258)], [bx(0), by(264)], [bx(-30), by(258)]], true, .5), 'bone', { sw: .6, op: .7 });
      B.tube(P('peyer'), `M${f1(bx(-14))} ${f1(by(210))}Q${f1(bx(0))} ${f1(by(224))} ${f1(bx(14))} ${f1(by(214))}`, 5, 'int', { sw: .5, hl: false }); [[-6, 216], [6, 216]].forEach(([x, y]) => E('path', { d: B.ellD(bx(x), by(y), 2.6, 1.6, 0), fill: '#f0e0a0', stroke: '#a08a40', 'stroke-width': .5 }, P('peyer'))); B.tube(P('app'), `M${f1(bx(-18))} ${f1(by(232))}q-4 6 -2 12`, 2.6, 'colon', { sw: .5, hl: false });
      hits(this.parts, part, 7); },
    idle(g, C, t) { const A = B.alongC([[bx(-22), by(400)], [bx(-24), by(300)], [bx(-14), by(210)], [bx(0), by(200)], [bx(0), by(76)], [bx(-30), by(86)]]); for (let i = 0; i < 6; i++) { const [x, y] = A(((t * .12) + i / 6) % 1); E('circle', { cx: f1(x), cy: f1(y), r: 1.8, fill: '#3a8a4a' }, g); } },
    parts: [
      { id: 'bm', bn: 'লাল অস্থিমজ্জা (মুখ্য)', lb: 'অস্থিমজ্জা', en: 'Bone marrow', fn: 'সব রক্তকণিকার জন্মস্থান; B লিম্ফোসাইট এখানেই পরিণত হয় ও নিজের দেহের অণুর প্রতি সহনশীল হতে শেখে। T কোষের আদি কোষও এখান থেকে থাইমাসে যায়। প্রাপ্তবয়স্কে মূলত শ্রোণি, বক্ষাস্থি, পাঁজর, কশেরুকা ও লম্বা হাড়ের প্রান্তে।', a: [bx(-24), by(320)], l: [14, 270], an: 'start' },
      { id: 'thy', bn: 'থাইমাস (মুখ্য)', lb: 'থাইমাস', en: 'Thymus', fn: 'বক্ষের ওপরে হৃৎপিণ্ডের সামনে — T কোষ এখানে পরিণত হয় ("T" নাম এখান থেকে)। যেসব T কোষ নিজের দেহের কোষকে আক্রমণ করতে পারে সেগুলো এখানেই নষ্ট হয়। শৈশবে বড়, বয়ঃসন্ধির পর ধীরে চর্বিতে পরিণত হয়।', a: [bx(0), by(94)], l: [352, 82], an: 'end' },
      { id: 'tons', bn: 'টনসিল', lb: 'টনসিল', en: 'Tonsils', fn: 'গলার দুই পাশে লসিকা কলা — মুখ ও নাক দিয়ে ঢোকা জীবাণুর সাথে প্রথম পরিচয় এখানে হয়।', a: [bx(6), by(46)], l: [352, 40], an: 'end' },
      { id: 'cerv', bn: 'গ্রীবার লসিকাগ্রন্থি', lb: 'গলার লসিকাগ্রন্থি', en: 'Cervical lymph nodes', fn: 'মাথা ও গলার লসিকা ছেঁকে নেয় — গলায় সংক্রমণ হলে এগুলো ফুলে ব্যথা করে।', a: [bx(-10), by(62)], l: [14, 48], an: 'start' },
      { id: 'axil', bn: 'বগলের লসিকাগ্রন্থি', lb: 'বগলের লসিকাগ্রন্থি', en: 'Axillary nodes', fn: 'হাত ও বুকের লসিকা ছেঁকে নেয়; হাতে টিকা দিলে এগুলোতেই প্রতিরোধ সাড়া গড়ে ওঠে।', a: [bx(-40), by(103)], l: [14, 104], an: 'start' },
      { id: 'spl', bn: 'প্লীহা', lb: 'প্লীহা', en: 'Spleen', fn: 'দেহের সবচেয়ে বড় লসিকা অঙ্গ — রক্ত ছেঁকে জীবাণু ও পুরনো লোহিত কণিকা সরায়; সাদা পাল্পে B ও T কোষ রক্তবাহিত অ্যান্টিজেনের বিরুদ্ধে সাড়া দেয়।', a: [bx(36), by(158)], l: [352, 150], an: 'end' },
      { id: 'mes', bn: 'অন্ত্রের মেসেন্টারিক লসিকাগ্রন্থি', lb: 'মেসেন্টারিক গ্রন্থি', en: 'Mesenteric nodes', fn: 'অন্ত্রের লসিকা ছেঁকে নেয়।', a: [bx(0), by(186)], l: [14, 176], an: 'start' },
      { id: 'peyer', bn: 'পেয়ার্স প্যাচ', lb: 'পেয়ার্স প্যাচ', en: "Peyer's patches", fn: 'ক্ষুদ্রান্ত্রের প্রাচীরের লসিকা গুচ্ছ — অন্ত্রের জীবাণুর নমুনা নিয়ে IgA তৈরিতে সাহায্য করে।', a: [bx(6), by(216)], l: [352, 206], an: 'end' },
      { id: 'app', bn: 'অ্যাপেন্ডিক্স', lb: 'অ্যাপেন্ডিক্স', en: 'Appendix', fn: 'লসিকা কলাসমৃদ্ধ — উপকারী অন্ত্রজীবাণুর "ভাণ্ডার" ও প্রতিরক্ষায় ভূমিকা রাখে বলে মনে করা হয়।', a: [bx(-20), by(240)], l: [14, 222], an: 'start' },
      { id: 'ingu', bn: 'কুঁচকির লসিকাগ্রন্থি', lb: 'কুঁচকির গ্রন্থি', en: 'Inguinal nodes', fn: 'পা ও শ্রোণির লসিকা ছেঁকে নেয়।', a: [bx(24), by(256)], l: [352, 250], an: 'end' }
    ]
  }));

/* ═════════ লসিকাগ্রন্থির গঠন ═════════ */
const LN = [180, 150];
V.lymphNodeImm = Object.assign({ t: 'লসিকাগ্রন্থির গঠন ও প্রতিরক্ষা', k: ['2d', 'anim', 'int', 'quiz'], cap: 'লসিকাগ্রন্থির লম্বচ্ছেদ (সরলীকৃত) — শিমবীচির মতো, সাধারণত 2–20 মিলিমিটার। অ্যাফারেন্ট লসিকানালি দিয়ে লসিকা ঢুকে সাইনাস দিয়ে ছেঁকে যাওয়ার সময় ম্যাক্রোফেজ জীবাণু ধরে এবং লিম্ফোসাইট অ্যান্টিজেনের সংস্পর্শে আসে; ইফারেন্ট নালি দিয়ে বের হয়। সংক্রমণে জনন কেন্দ্রে B কোষের সংখ্যাবৃদ্ধিতে গ্রন্থি ফুলে ওঠে।' },
  BK.diagram({ W: 360, H: 300, label: 'লসিকাগ্রন্থি', idle: true,
    art(g, C, part) { const G = {}, P = k => G[k] || (G[k] = part(k)), [cx, cy] = LN;
      const outline = sm([[cx - 120, cy - 30], [cx - 90, cy - 92], [cx, cy - 112], [cx + 90, cy - 92], [cx + 122, cy - 20], [cx + 96, cy + 70], [cx + 30, cy + 104], [cx + 6, cy + 60], [cx - 20, cy + 104], [cx - 96, cy + 76]], true, .5);
      B.organ(P('cap'), outline, 'lymn', { sw: 2.4, gr: { cx: .4, cy: .3, r: .9 } });
      /* সাবক্যাপসুলার সাইনাস */ E('path', { d: outline, fill: 'none', stroke: '#f6efe4', 'stroke-width': 5, transform: `translate(${cx} ${cy}) scale(.94) translate(${-cx} ${-cy})` }, P('sin'));
      /* প্যারাকর্টেক্স (T অঞ্চল) */ B.organ(P('para'), sm([[cx - 92, cy - 20], [cx - 60, cy - 70], [cx, cy - 82], [cx + 60, cy - 70], [cx + 94, cy - 14], [cx + 70, cy + 30], [cx, cy + 20], [cx - 70, cy + 30]], true, .5), 'tcl', { sw: .5, op: .55 });
      /* মেডালা */ B.organ(P('med'), sm([[cx - 56, cy + 10], [cx, cy - 8], [cx + 56, cy + 10], [cx + 30, cy + 60], [cx, cy + 48], [cx - 30, cy + 60]], true, .5), 'lymn', { sw: .5, op: .9 }); let mc = ''; for (let i = 0; i < 5; i++) mc += `M${cx - 40 + i * 20} ${cy + 14}q${i % 2 ? 6 : -6} 18 0 34`; E('path', { d: mc, stroke: B.TS('lymn').dk, 'stroke-width': 4, fill: 'none', opacity: .5 }, P('med')); [[cx - 30, cy + 22], [cx + 20, cy + 30], [cx + 2, cy + 18]].forEach(([x, y]) => B.plasma(P('med'), x, y, 6));
      /* ফলিকল ও জনন কেন্দ্র */ [[cx - 82, cy - 46], [cx - 38, cy - 86], [cx + 20, cy - 92], [cx + 70, cy - 64], [cx + 92, cy - 4]].forEach(([x, y], i) => { const gg = i === 2 ? P('gc') : P('fol'); E('path', { d: B.ellD(x, y, 20, 15, Math.atan2(y - cy, x - cx) * 57 + 90), fill: B.TS('bcl').c, stroke: B.TS('bcl').dk, 'stroke-width': .7 }, gg); E('path', { d: B.ellD(x, y, 10, 7, Math.atan2(y - cy, x - cx) * 57 + 90), fill: B.TS('bcl').lt, stroke: 'none' }, gg); let dd = ''; for (let j = 0; j < 14; j++) dd += B.ellD(x + (B.rnd(i * 20 + j) - .5) * 30, y + (B.rnd(i * 20 + j + 7) - .5) * 20, 1.6, 1.6, 0); E('path', { d: dd, fill: '#3f2b7a', opacity: .8 }, gg); });
      /* T কোষের বিন্দু */ let td = ''; for (let j = 0; j < 40; j++) { const a = B.rnd(j) * 2 * PI, r = 40 + B.rnd(j + 50) * 30; td += B.ellD(cx + Math.cos(a) * r, cy - 20 + Math.sin(a) * r * .6, 1.5, 1.5, 0); } E('path', { d: td, fill: '#3e7d4c', opacity: .7 }, P('para'));
      /* অ্যাফারেন্ট নালি ও ভালভ */ [[cx - 120, cy - 90, cx - 96, cy - 72], [cx + 10, cy - 150, cx + 4, cy - 110], [cx + 130, cy - 100, cx + 100, cy - 80], [cx - 150, cy + 20, cx - 116, cy + 4]].forEach(([x0, y0, x1, y1]) => { B.tube(P('aff'), `M${x0} ${y0}L${x1} ${y1}`, 6, 'lym', { sw: .6, hl: false }); E('path', { d: `M${f1(lerp(x0, x1, .4) - 3)} ${f1(lerp(y0, y1, .4))}l3 3l3 -3`, stroke: '#4a7a40', 'stroke-width': .8, fill: 'none' }, P('aff')); });
      /* হাইলাম: ইফারেন্ট নালি, ধমনি, শিরা */ B.tube(P('eff'), `M${cx + 6} ${cy + 60}L${cx + 6} ${cy + 140}`, 7, 'lym', { sw: .6, hl: false }); B.tube(P('bv'), `M${cx - 6} ${cy + 64}L${cx - 14} ${cy + 140}`, 4, 'art', { sw: .5, hl: false }); B.tube(P('bv'), `M${cx + 16} ${cy + 64}L${cx + 24} ${cy + 140}`, 5, 'vein', { sw: .5, hl: false });
      B.macro(P('macn'), cx - 96, cy - 8, 7, { seed: 6 });
      hits(this.parts, part, 8); },
    idle(g, C, t) { const [cx, cy] = LN; [[cx - 120, cy - 90, cx - 96, cy - 72], [cx + 10, cy - 150, cx + 4, cy - 110], [cx + 130, cy - 100, cx + 100, cy - 80]].forEach(([x0, y0, x1, y1], i) => { const u = (t * .4 + i / 3) % 1; E('circle', { cx: f1(lerp(x0, x1, u)), cy: f1(lerp(y0, y1, u)), r: 1.6, fill: '#3a8a4a' }, g); B.bact(g, f1(lerp(x0, x1, (u + .5) % 1)), f1(lerp(y0, y1, (u + .5) % 1)), 1, { L: 6, w: 2.4 }); }); const u = (t * .35) % 1; for (let i = 0; i < 3; i++) B.abY(g, cx + 6, cy + 70 + ((u + i / 3) % 1) * 70, PI / 2, .9); },
    parts: [
      { id: 'cap', bn: 'ক্যাপসুল', lb: 'ক্যাপসুল', en: 'Capsule', fn: 'ঘন যোজক কলার বাইরের আবরণ; ভেতরে ট্রাবেকুলা বিভাজন দেয়।', a: [cx(-120), 120], l: [14, 120], an: 'start' },
      { id: 'aff', bn: 'অ্যাফারেন্ট (অন্তর্বাহী) লসিকানালি', lb: 'অ্যাফারেন্ট নালি', en: 'Afferent lymphatic', fn: 'কলা থেকে জীবাণু ও অ্যান্টিজেনবাহী লসিকা আনে — কয়েকটি নালি উত্তল দিক দিয়ে ঢোকে; ভালভ উল্টো প্রবাহ ঠেকায়।', a: [72, 70], l: [14, 34], an: 'start' },
      { id: 'sin', bn: 'সাবক্যাপসুলার সাইনাস', lb: 'সাইনাস', en: 'Subcapsular sinus', fn: 'ক্যাপসুলের নিচের ফাঁক — লসিকা ধীরে চলে, ম্যাক্রোফেজ জীবাণু ছেঁকে নেয়।', a: [cx(-30), 46], l: [130, 22], an: 'middle' },
      { id: 'fol', bn: 'লসিকা ফলিকল (B কোষ অঞ্চল)', lb: 'ফলিকল (B কোষ)', en: 'Lymphoid follicle', fn: 'কর্টেক্সের গোল গুচ্ছ — মূলত B লিম্ফোসাইট।', a: [cx(-82), 104], l: [14, 74], an: 'start' },
      { id: 'gc', bn: 'জনন কেন্দ্র', lb: 'জনন কেন্দ্র', en: 'Germinal centre', fn: 'সক্রিয় B কোষ এখানে দ্রুত বিভাজিত হয় এবং আরও শক্তভাবে অ্যান্টিজেন বাঁধতে পারে এমন কোষ বাছাই হয় — প্লাজমা ও স্মৃতি B কোষ তৈরি।', a: [cx(20), 58], l: [250, 22], an: 'start' },
      { id: 'para', bn: 'প্যারাকর্টেক্স (T কোষ অঞ্চল)', lb: 'প্যারাকর্টেক্স (T কোষ)', en: 'Paracortex', fn: 'গভীর কর্টেক্স — T কোষ ও ডেনড্রাইটিক কোষ; এখানে অ্যান্টিজেন উপস্থাপনে T কোষ সক্রিয় হয়।', a: [cx(60), 118], l: [352, 84], an: 'end' },
      { id: 'med', bn: 'মেডালা (প্লাজমা কোষ)', lb: 'মেডালা (প্লাজমা কোষ)', en: 'Medulla', fn: 'মেডালারি কর্ড ও সাইনাস — প্লাজমা কোষ এখান থেকে অ্যান্টিবডি লসিকায় ছাড়ে; ম্যাক্রোফেজ শেষবারের মতো ছাঁকে।', a: [cx(20), 182], l: [352, 186], an: 'end' },
      { id: 'macn', bn: 'ম্যাক্রোফেজ', lb: 'ম্যাক্রোফেজ', en: 'Macrophage', fn: 'সাইনাসে ভেসে আসা জীবাণু ভক্ষণ করে ও অ্যান্টিজেন উপস্থাপন করে।', a: [cx(-96), 142], l: [14, 186], an: 'start' },
      { id: 'eff', bn: 'ইফারেন্ট (বহির্বাহী) লসিকানালি', lb: 'ইফারেন্ট নালি', en: 'Efferent lymphatic', fn: 'হাইলাম দিয়ে একটি নালি বের হয় — ছাঁকা লসিকা, নতুন লিম্ফোসাইট ও অ্যান্টিবডি নিয়ে যায়।', a: [cx(6), 270], l: [352, 266], an: 'end' },
      { id: 'bv', bn: 'রক্তনালি (হাইলামে)', lb: 'ধমনি ও শিরা', en: 'Blood vessels', fn: 'রক্ত থেকে লিম্ফোসাইট বিশেষ শিরিকা (HEV) দিয়ে গ্রন্থিতে ঢোকে।', a: [cx(-10), 260], l: [14, 270], an: 'start' }
    ]
  }));
function cx(d) { return LN[0] + d; }

/* ═════════ অ্যান্টিজেন উপস্থাপন ═════════ */
const AP = [
  { t: 'জীবাণু ভক্ষণ', en: 'Uptake', d: 'অ্যান্টিজেন উপস্থাপক কোষ (APC — ডেনড্রাইটিক কোষ, ম্যাক্রোফেজ, B কোষ) জীবাণু ফ্যাগোসাইটোসিসে ভেতরে নেয়।' },
  { t: 'প্রক্রিয়াকরণ', en: 'Processing', d: 'ফ্যাগোলাইসোসোমে জীবাণুর প্রোটিন ছোট পেপটাইড টুকরোয় (অ্যান্টিজেনিক নির্ধারক) ভাঙা হয়।' },
  { t: 'MHC-II তে স্থাপন', en: 'Loading on MHC-II', d: 'পেপটাইড টুকরো MHC-II প্রোটিনের খাঁজে বসে কোষঝিল্লিতে উঠে আসে — যেন জীবাণুর "ছবি" টাঙানো।' },
  { t: 'T সহায়ক কোষের চেনা', en: 'Recognition', d: 'যে T সহায়ক (CD4) কোষের TCR ঠিক ওই পেপটাইড-MHC জোড় চেনে, সেটি যুক্ত হয়; সাথে সহ-উদ্দীপক সংকেত লাগে — ভুল সক্রিয়করণ ঠেকাতে "দুই চাবি" ব্যবস্থা।' },
  { t: 'T সহায়ক কোষ সক্রিয়', en: 'Activation', d: 'সক্রিয় T সহায়ক কোষ ইন্টারলিউকিন (সাইটোকাইন) ছেড়ে বিভাজিত হয় এবং B কোষ, সাইটোটক্সিক T কোষ ও ম্যাক্রোফেজকে সক্রিয় করে — পুরো নির্দিষ্ট প্রতিরক্ষার "সেনাপতি"। HIV এ কোষটিই ধ্বংস হয়।' }
];
V.antigenPresent = Object.assign({ t: 'অ্যান্টিজেন উপস্থাপন', k: ['2d', 'anim', 'steps'], cap: 'সহজাত ও অর্জিত প্রতিরক্ষার সংযোগ: APC জীবাণুর টুকরো MHC-II এ সাজিয়ে T সহায়ক কোষকে দেখায়। দেহের প্রায় সব কোষ MHC-I এ নিজের ভেতরের প্রোটিনের টুকরো দেখায় — ভাইরাস আক্রান্ত হলে সাইটোটক্সিক (CD8) T কোষ তা চেনে। চিত্রে আকার আপেক্ষিক।' },
  BK.steps({ W: 360, H: 260, label: 'অ্যান্টিজেন উপস্থাপন', dur: 3, stages: AP,
    draw(g, C, s, u) { const ax = 120, ay = 140;
      B.cacheG(g, 'apb', gg => { B.macro(gg, ax, ay, 62, { seed: 4, arms: [[.2, 1.2], [2.4, 1.3], [4.2, 1.25], [5.4, 1.15]] }); B.tx(gg, ax - 20, ay + 86, 'APC (ম্যাক্রোফেজ / ডেনড্রাইটিক কোষ)', { fs: 9.8, a: 'middle', c: '#5a4a90' }); });
      if (s === 0) { const x = lerp(250, 168, u); B.bact(g, x, 120, .3, { L: 18, w: 7, fl: true, ph: u * 20 }); }
      if (s >= 0 && s <= 1) { E('circle', { cx: 140, cy: 132, r: 16, fill: '#fbe4cc', stroke: '#b07040', 'stroke-width': .8, opacity: s === 0 ? u : 1 }, g); if (s === 1) { for (let i = 0; i < 6; i++) { const a = i * 1.05 + u * 3; E('rect', { x: f1(140 + Math.cos(a) * 6 * u - 3), y: f1(132 + Math.sin(a) * 6 * u - 1.4), width: 6, height: 2.8, rx: 1, fill: '#c0392b' }, g); } } }
      if (s >= 2) { const n = 5; for (let i = 0; i < n; i++) { const a = -1.3 + i * .55, rr = 62 + (i % 2 ? 6 : 0), x = ax + Math.cos(a) * rr, y = ay + Math.sin(a) * rr * .9, p = s === 2 ? Math.min(1, u * 1.5 - i * .1) : 1; if (p <= 0) continue; E('path', { d: `M${f1(x)} ${f1(y)}l${f1(Math.cos(a) * 8)} ${f1(Math.sin(a) * 8)}`, stroke: '#3a6aa8', 'stroke-width': 4, 'stroke-linecap': 'round', opacity: f1(p) }, g); E('rect', { x: f1(x + Math.cos(a) * 9 - 3), y: f1(y + Math.sin(a) * 9 - 1.4), width: 6, height: 2.8, rx: 1, fill: '#c0392b', opacity: f1(p) }, g); } }
      if (s >= 3) { const x = s === 3 ? lerp(320, 232, Math.min(1, u * 1.4)) : 232; B.tcell(g, x, 116, 24, { lab: 'Th' }); }
      if (s === 4) { for (let i = 0; i < 8; i++) { const v = (u + i / 8) % 1, a = -1 + i * .3; E('circle', { cx: f1(232 + Math.cos(a) * (26 + v * 80)), cy: f1(116 + Math.sin(a) * (26 + v * 60)), r: 1.8, fill: '#3a9a5a', opacity: f1(1 - v) }, g); } if (u > .5) { B.tcell(g, 300, 196, 14, { lab: 'Th' }); B.tcell(g, 326, 160, 14, { lab: 'Th' }); } }
      B.cacheG(g, 'apl' + s, gl => { B.tx(gl, 8, 18, AP[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s >= 2) B.tx(gl, 8, 40, 'MHC-II + পেপটাইড', { fs: 10, w: 700, c: '#3a6aa8' }); if (s >= 3) B.tx(gl, 352, 40, 'T সহায়ক (CD4) কোষ — TCR', { fs: 10, a: 'end', w: 700, c: '#3e7d4c' }); if (s === 4) B.tx(gl, 352, 240, 'সাইটোকাইন → বিভাজন', { fs: 10, a: 'end', c: '#3a9a5a' }); }); }
  }));

/* ═════════ ক্লোনাল সিলেকশন ═════════ */
const CS = [
  { t: 'বৈচিত্র্যময় লিম্ফোসাইট', en: 'Diverse repertoire', d: 'অস্থিমজ্জা ও থাইমাসে জিনের পুনর্বিন্যাসে কোটি কোটি ভিন্ন লিম্ফোসাইট তৈরি হয় — প্রতিটির গ্রাহক মাত্র একটি নির্দিষ্ট অ্যান্টিজেন চেনে (রঙের আকারে দেখানো)। অ্যান্টিজেন আসার আগেই এরা প্রস্তুত থাকে।' },
  { t: 'অ্যান্টিজেনের বাছাই', en: 'Selection', d: 'অ্যান্টিজেন শুধু সেই লিম্ফোসাইটের গ্রাহকে বসে যার আকার মিলে যায় — বাকিরা প্রভাবিত হয় না। অ্যান্টিজেনই উপযুক্ত কোষকে "বাছাই" করে।' },
  { t: 'ক্লোনাল সম্প্রসারণ', en: 'Clonal expansion', d: 'বাছাই হওয়া কোষ (T সহায়ক কোষের সাহায্যে) কয়েক দিনে বারবার বিভাজিত হয়ে হাজারো অভিন্ন কোষ (ক্লোন) তৈরি করে।' },
  { t: 'কার্যকর ও স্মৃতি কোষ', en: 'Effector and memory', d: 'ক্লোনের বেশিরভাগ কার্যকর কোষ হয় — B কোষ থেকে প্লাজমা কোষ (সেকেন্ডে প্রায় 2,000 অ্যান্টিবডি অণু ছাড়ে), T কোষ থেকে সাইটোটক্সিক বা সহায়ক কোষ; কিছু দীর্ঘজীবী স্মৃতি কোষ হিসেবে থেকে যায়।' }
];
const CSC = ['#c0392b', '#2a6ab0', '#e08a2a', '#3a9a5a', '#8a4ab0', '#a8801a'];
V.clonalSelection = Object.assign({ t: 'ক্লোনাল সিলেকশন', k: ['2d', 'anim', 'steps'], cap: 'ম্যাকফারলেন বার্নেটের ক্লোনাল সিলেকশন তত্ত্ব (1957; নোবেল 1960) নির্দিষ্ট প্রতিরক্ষার মূল নীতি — অ্যান্টিজেন নতুন অ্যান্টিবডি "শেখায়" না, বরং আগে থেকে থাকা উপযুক্ত লিম্ফোসাইটকে বাছাই করে বহুগুণ করে। এ কারণেই প্রথম সংক্রমণে কয়েক দিন দেরি হয়, আর স্মৃতি কোষ থাকায় পরেরবার দ্রুত।' },
  BK.steps({ W: 360, H: 260, label: 'ক্লোনাল সিলেকশন', dur: 3, stages: CS,
    draw(g, C, s, u) { const row = [40, 96, 152, 208, 264, 320], sel = 2;
      B.cacheG(g, 'csb' + Math.min(s, 1), gg => { row.forEach((x, i) => { if (s >= 1 && i !== sel) { B.bcell(gg, x, 70, 16, { rc: CSC[i], fill: '#eef2f6' }); return; } B.bcell(gg, x, 70, 16, { rc: CSC[i] }); }); });
      if (s === 1) { const y = lerp(16, 46, u); E('path', { d: `M${row[sel] - 7} ${f1(y)}h14l-3 6h-8Z`, fill: CSC[sel], stroke: '#444', 'stroke-width': .5 }, g); }
      if (s >= 2) { const n = s === 2 ? Math.min(12, 1 + Math.floor(u * 12)) : 12; for (let i = 0; i < n; i++) { const x = 60 + (i % 6) * 48, y = 136 + Math.floor(i / 6) * 40; if (s === 3 && i < 9) B.plasma(g, x, y, 11); else B.bcell(g, x, y, 12, { rc: CSC[sel] }); } E('path', { d: `M${row[sel]} 92L${row[sel]} 112`, stroke: FK.alpha(C.fg, .4), 'stroke-width': 1.2, 'marker-end': B.mk(g, FK.alpha(C.fg, .5), 6) }, g); }
      if (s === 3) for (let i = 0; i < 10; i++) { const v = (u + i / 10) % 1; B.abY(g, 60 + (i % 9) * 48 + v * 10, 150 - v * 30 + (i % 2) * 40, -PI / 2 + Math.sin(i) * .5, 1, CSC[sel]); }
      B.cacheG(g, 'csl' + s, gl => { B.tx(gl, 8, 18, CS[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s >= 1) B.tx(gl, row[sel], 102, 'বাছাই', { fs: 9.8, a: 'middle', w: 700, c: CSC[sel] }); if (s === 2) B.tx(gl, 352, 236, 'একই ধরনের কোষের ক্লোন', { fs: 10, a: 'end', c: C.mu }); if (s === 3) { B.tx(gl, 8, 236, 'প্লাজমা কোষ → অ্যান্টিবডি', { fs: 10, w: 700, c: '#2a5a90' }); B.tx(gl, 352, 236, 'স্মৃতি কোষ', { fs: 10, a: 'end', w: 700, c: '#2a5a90' }); } }); }
  }));

/* ═════════ হিউমোরাল ইমিউনিটি ═════════ */
const HU = [
  { t: 'অ্যান্টিজেন শনাক্ত', en: 'Antigen binding', d: 'নির্দিষ্ট B কোষের গায়ের অ্যান্টিবডি-গ্রাহক (BCR) রক্ত বা লসিকায় থাকা অ্যান্টিজেনকে সরাসরি চিনে বাঁধে এবং কোষে টেনে নিয়ে MHC-II তে উপস্থাপন করে।' },
  { t: 'T সহায়ক কোষের সাহায্য', en: 'Help from Th', d: 'একই অ্যান্টিজেনে আগেই সক্রিয় T সহায়ক কোষ B কোষে যুক্ত হয়ে সাইটোকাইন (ইন্টারলিউকিন) দেয় — B কোষ পূর্ণ সক্রিয় হয়।' },
  { t: 'বিভাজন ও প্লাজমা কোষ', en: 'Plasma cells', d: 'B কোষ বিভাজিত হয়ে ক্লোন গড়ে; বেশিরভাগ প্লাজমা কোষে পরিণত হয় — প্রচুর অমসৃণ ER যুক্ত "অ্যান্টিবডি কারখানা"; কিছু স্মৃতি B কোষ।' },
  { t: 'অ্যান্টিবডি নিঃসরণ', en: 'Antibody secretion', d: 'প্লাজমা কোষ রক্ত ও লসিকায় অ্যান্টিবডি ছাড়ে — রক্তরস বা "হিউমার" এর মাধ্যমে কাজ করে বলে নাম হিউমোরাল ইমিউনিটি।' },
  { t: 'জীবাণু নিষ্ক্রিয়', en: 'Neutralization', d: 'অ্যান্টিবডি জীবাণু ও বিষ (টক্সিন) এর সাথে যুক্ত হয়ে নিষ্ক্রিয় করে, দলা পাকায় (অ্যাগ্লুটিনেশন), ফ্যাগোসাইটের খাদ্য বানায় ও কমপ্লিমেন্ট সক্রিয় করে — কোষের বাইরে থাকা জীবাণু ও টক্সিনের বিরুদ্ধে কার্যকর।' }
];
V.humoralImmunity = Object.assign({ t: 'হিউমোরাল (অ্যান্টিবডিনির্ভর) ইমিউনিটি', k: ['2d', 'anim', 'steps'], cap: 'B লিম্ফোসাইট ও অ্যান্টিবডির মাধ্যমে কোষের বাইরে থাকা জীবাণু (ব্যাকটেরিয়া, রক্তে ভাসমান ভাইরাস) ও টক্সিনের বিরুদ্ধে নির্দিষ্ট প্রতিরক্ষা। প্রথম সংক্রমণে অ্যান্টিবডির মাত্রা শীর্ষে উঠতে প্রায় 1–2 সপ্তাহ লাগে।' },
  BK.steps({ W: 360, H: 260, label: 'হিউমোরাল ইমিউনিটি', dur: 3, stages: HU,
    draw(g, C, s, u) {
      if (s <= 1) { B.cacheG(g, 'hub', gg => B.bcell(gg, 130, 130, 30, { rc: '#2a6ab0' })); for (let i = 0; i < 3; i++) { const p = s === 0 ? Math.min(1, u * 1.4 - i * .15) : 1, a = -.9 + i * .9, x0 = 130 + Math.cos(a) * 110, y0 = 130 + Math.sin(a) * 90, x1 = 130 + Math.cos(a) * 40, y1 = 130 + Math.sin(a) * 38; if (p > 0) E('path', { d: B.ellD(lerp(x0, x1, p), lerp(y0, y1, p), 5, 3.4, a * 57), fill: '#e8a040', stroke: '#9a6010', 'stroke-width': .6 }, g); } }
      if (s === 1) { const x = lerp(320, 210, Math.min(1, u * 1.4)); B.tcell(g, x, 110, 22, { lab: 'Th' }); if (u > .6) for (let i = 0; i < 6; i++) { const v = ((u - .6) * 2.5 + i / 6) % 1; E('circle', { cx: f1(lerp(190, 160, v)), cy: f1(110 + i * 4 + v * 10), r: 1.8, fill: '#3a9a5a' }, g); } }
      if (s === 2) { const n = Math.min(7, 1 + Math.floor(u * 8)); for (let i = 0; i < n; i++) { const x = 60 + (i % 4) * 76, y = 90 + Math.floor(i / 4) * 80; if (i < 5) B.plasma(g, x, y, 18); else B.bcell(g, x, y, 16, { rc: '#2a6ab0' }); } }
      if (s >= 3) { B.cacheG(g, 'hup', gp => { B.plasma(gp, 80, 130, 26); }); for (let i = 0; i < 14; i++) { const v = (u * (s === 3 ? 1 : .4) + i / 14) % 1, a = -1.2 + (i % 7) * .4; B.abY(g, 110 + v * 200 * Math.cos(a * .5), 130 + v * 90 * Math.sin(a), a * .5, 1.2); } }
      if (s === 4) { for (let i = 0; i < 4; i++) { const x = 250 + (i % 2) * 34, y = 100 + Math.floor(i / 2) * 50; B.bact(g, x, y, i, { L: 16, w: 6, fill: '#b8c890' }); [0, 1.6, 3.2, 4.8].forEach(a => B.abY(g, x + Math.cos(a) * 10, y + Math.sin(a) * 7, a + PI, 1)); } }
      B.cacheG(g, 'hul' + s, gl => { B.tx(gl, 8, 18, HU[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s <= 1) B.tx(gl, 130, 186, 'B কোষ (BCR সহ)', { fs: 10, a: 'middle', c: '#2a5a90' }); if (s === 0) B.tx(gl, 300, 230, 'অ্যান্টিজেন', { fs: 10, a: 'middle', c: '#9a6010' }); if (s === 2) B.tx(gl, 8, 240, 'প্লাজমা কোষ (ও কিছু স্মৃতি B কোষ)', { fs: 10, c: '#2a5a90' }); if (s >= 3) B.tx(gl, 80, 172, 'প্লাজমা কোষ', { fs: 10, a: 'middle', c: '#2a5a90' }); if (s === 4) B.tx(gl, 352, 240, 'অ্যান্টিবডিতে ঢাকা জীবাণু', { fs: 10, a: 'end', c: '#5e7a2a' }); }); }
  }));

/* ═════════ কোষীয় ইমিউনিটি ═════════ */
const CM = [
  { t: 'আক্রান্ত কোষের সংকেত', en: 'Infected cell shows antigen', d: 'ভাইরাস-আক্রান্ত (বা ক্যান্সার) কোষ নিজের ভেতরে তৈরি ভাইরাস প্রোটিনের টুকরো MHC-I এ সাজিয়ে ঝিল্লিতে দেখায়।' },
  { t: 'সাইটোটক্সিক T কোষের চেনা', en: 'Tc recognition', d: 'নির্দিষ্ট সাইটোটক্সিক T (CD8, Tc) কোষের TCR ওই পেপটাইড-MHC-I চেনে; T সহায়ক কোষের সাইটোকাইনে Tc কোষ সক্রিয় ও বহুগুণ হয়।' },
  { t: 'পারফোরিন ও গ্র্যানজাইম', en: 'Perforin, granzyme', d: 'Tc কোষ আক্রান্ত কোষে লেগে পারফোরিন ছাড়ে — ঝিল্লিতে ছিদ্র; সেই পথে গ্র্যানজাইম ঢুকে কোষের আত্মহনন (অ্যাপোপটোসিস) চালু করে।' },
  { t: 'আক্রান্ত কোষ ধ্বংস', en: 'Apoptosis', d: 'আক্রান্ত কোষ টুকরো টুকরো হয়ে ভেতরের ভাইরাসসহ নষ্ট হয়; ম্যাক্রোফেজ টুকরোগুলো খেয়ে ফেলে। Tc কোষ নিজে অক্ষত থেকে পরের কোষের দিকে যায়।' },
  { t: 'ম্যাক্রোফেজ সক্রিয়করণ', en: 'Macrophage activation', d: 'T সহায়ক কোষের ইন্টারফেরন-গামা ম্যাক্রোফেজকে আরও শক্তিশালী ভক্ষক বানায় — যক্ষ্মার জীবাণুর মতো কোষের ভেতরে টিকে থাকা ব্যাকটেরিয়া ধ্বংসে জরুরি।' }
];
V.cellImmunity = Object.assign({ t: 'কোষীয় (কোষনির্ভর) ইমিউনিটি', k: ['2d', 'anim', 'steps'], cap: 'T লিম্ফোসাইটের মাধ্যমে কোষের ভেতরে লুকানো জীবাণু (ভাইরাস, যক্ষ্মার জীবাণু), ক্যান্সার কোষ ও প্রতিস্থাপিত অঙ্গের বিরুদ্ধে প্রতিরক্ষা — অ্যান্টিবডি কোষের ভেতরে ঢুকতে পারে না বলে এ পথ অপরিহার্য। অঙ্গ প্রতিস্থাপনের পর প্রত্যাখ্যান ঠেকাতে এ কারণে প্রতিরোধ-দমনকারী ওষুধ দেওয়া হয়।' },
  BK.steps({ W: 360, H: 260, label: 'কোষীয় ইমিউনিটি', dur: 3, stages: CM,
    draw(g, C, s, u) { const ix = 240, iy = 132;
      if (s <= 2) B.cacheG(g, 'cmc', gg => { E('path', { d: B.ellD(ix, iy, 58, 50, 0), fill: '#f6d8d4', stroke: '#a84a4a', 'stroke-width': 1.1 }, gg); E('path', { d: B.ellD(ix + 10, iy + 4, 20, 16, 0), fill: '#c8a0c8', stroke: '#8a5a8a', 'stroke-width': .6 }, gg); for (let i = 0; i < 6; i++) B.virus(gg, ix - 26 + (i % 3) * 14, iy - 22 + Math.floor(i / 3) * 40, 4.4); for (let i = 0; i < 5; i++) { const a = PI - .9 + i * .45, x = ix + Math.cos(a) * 58, y = iy + Math.sin(a) * 50; E('path', { d: `M${f1(x)} ${f1(y)}l${f1(Math.cos(a) * 7)} ${f1(Math.sin(a) * 7)}`, stroke: '#a85a2a', 'stroke-width': 3.4, 'stroke-linecap': 'round' }, gg); E('rect', { x: f1(x + Math.cos(a) * 8 - 3), y: f1(y + Math.sin(a) * 8 - 1.4), width: 6, height: 2.8, rx: 1, fill: '#c0392b' }, gg); } });
      if (s === 0) { const k = .5 + .5 * Math.sin(u * PI * 6); E('path', { d: B.ellD(ix, iy, 64 + k * 3, 56 + k * 3, 0), fill: 'none', stroke: '#c0392b', 'stroke-width': 1, opacity: f1(.6 - k * .3) }, g); }
      if (s >= 1 && s <= 3) { const x = s === 1 ? lerp(20, 140, Math.min(1, u * 1.3)) : 140; B.tcell(g, x, 132, 30, { lab: 'Tc', tc: '#2e6a3e' }); }
      if (s === 2) { for (let i = 0; i < 10; i++) { const v = (u * 1.5 + i / 10) % 1; E('circle', { cx: f1(lerp(172, 188, v)), cy: f1(110 + i * 5), r: 1.8, fill: i % 2 ? '#c03050' : '#7a3aa8', opacity: f1(1 - v * .3) }, g); } [118, 136, 152].forEach(y => E('circle', { cx: 184, cy: y, r: f1(2 + u * 2), fill: '#fff', stroke: '#a84a4a', 'stroke-width': .8 }, g)); }
      if (s === 3) { const p = u; for (let i = 0; i < 7; i++) { const a = i / 7 * 2 * PI, r = 20 + p * 40; E('path', { d: B.ellD(ix + Math.cos(a) * r, iy + Math.sin(a) * r * .8, 14 * (1 - p * .4), 12 * (1 - p * .4), a * 57), fill: '#f6d8d4', stroke: '#a84a4a', 'stroke-width': .7, opacity: f1(1 - p * .4) }, g); } if (p > .5) B.macro(g, ix + 60, iy + 70, 18, { seed: 3 }); }
      if (s === 4) { B.cacheG(g, 'cmm', gm => { B.macro(gm, 230, 132, 46, { seed: 7 }); for (let i = 0; i < 4; i++) B.bact(gm, 214 + (i % 2) * 24, 120 + Math.floor(i / 2) * 22, i, { L: 10, w: 3.6, fill: '#c8b060' }); }); B.tcell(g, 92, 132, 26, { lab: 'Th' }); for (let i = 0; i < 8; i++) { const v = (u + i / 8) % 1; E('circle', { cx: f1(lerp(120, 186, v)), cy: f1(118 + (i % 4) * 9), r: 1.8, fill: '#3a9a5a' }, g); } const k = .5 + .5 * Math.sin(u * PI * 6); E('circle', { cx: 230, cy: 132, r: f1(54 + k * 4), fill: 'none', stroke: '#5a4a90', 'stroke-width': 1.2, opacity: f1(.6 - k * .3) }, g); }
      B.cacheG(g, 'cml' + s, gl => { B.tx(gl, 8, 18, CM[s].t, { fs: 11, w: 700, c: '#a8201a' }); if (s <= 2) { B.tx(gl, ix, 204, 'ভাইরাস-আক্রান্ত কোষ', { fs: 10, a: 'middle', c: '#a84a4a' }); B.tx(gl, 352, 44, 'MHC-I + ভাইরাস পেপটাইড', { fs: 10, a: 'end', w: 700, c: '#a85a2a' }); } if (s >= 1 && s <= 3) B.tx(gl, 140, 186, 'সাইটোটক্সিক T (CD8)', { fs: 10, a: 'middle', c: '#2e6a3e' }); if (s === 2) B.tx(gl, 180, 236, 'পারফোরিন (ছিদ্র) + গ্র্যানজাইম', { fs: 10, a: 'middle', w: 700, c: '#c03050' }); if (s === 4) { B.tx(gl, 92, 180, 'T সহায়ক', { fs: 10, a: 'middle', c: '#2e6a3e' }); B.tx(gl, 150, 100, 'IFN-γ', { fs: 10, w: 700, c: '#3a9a5a' }); B.tx(gl, 230, 200, 'সক্রিয় ম্যাক্রোফেজ', { fs: 10, a: 'middle', c: '#5a4a90' }); } }); }
  }));
})();
