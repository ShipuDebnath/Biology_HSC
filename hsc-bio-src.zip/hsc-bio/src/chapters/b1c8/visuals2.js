/* ═══════════════════════════════════════════════════════════════════
   visuals2 — §৮.২ টিস্যুতন্ত্র, পত্ররন্ধ্র, ভাস্কুলার বান্ডল, জাইলেম-ফ্লোয়েম
   B8 অঙ্গসংস্থান-আঁকিয়ে (visuals3 ও ব্যবহার করে):
     B8.dStem / mStem / dRoot / mRoot (g, C, cx, cy, R, hl) — দ্বিবীজপত্রী কাণ্ড (সূর্যমুখী), একবীজপত্রী কাণ্ড (ভুট্টা),
     দ্বিবীজপত্রী মূল (ছোলা), একবীজপত্রী মূল (ভুট্টা) এর প্রস্থচ্ছেদ; hl = উজ্জ্বল রাখার অঞ্চলের তালিকা (বাকিগুলো ধূসর)
     B8.zoneOf(kind, dx, dy, R) → অঞ্চলের নাম (চাপ দিলে তথ্য দেখাতে)
   tissueSystems : তিন টিস্যুতন্ত্র (সূর্যমুখী কাণ্ডে)      stomata : পত্ররন্ধ্র খোলা-বন্ধ (বৃক্কাকার ও ডাম্বেল)
   hydathode     : পানি-পত্ররন্ধ্র ও গাটেশন                 epidermis : কিউটিকল, ট্রাইকোম, মূলরোম, বুলিফর্ম কোষ
   vbTypes       : ভাস্কুলার বান্ডলের ছয় ধরন                 xpFlow : জাইলেম ও ফ্লোয়েমে পরিবহনের দিক
   cmpStomaHyd, cmpXP : তুলনা
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX, B8 = window.B8, rnd = B8.rnd;
const PI = Math.PI;

/* অঞ্চলের রং — অধ্যায়ের নিয়ম মেনে */
const ZC = { epi: [0, .38], hypo: [5, .32], hypoScl: [4, .45], cortex: [11, .16], endo: [3, .5], peri: [2, .38], cap: [4, .5], phl: [10, .5], cam: [6, .85], xyl: [4, .5], ray: [11, .1], pith: [11, .1], gnd: [11, .14], sheath: [4, .6], conj: [11, .12], conjScl: [4, .2], hair: [0, .6] };
const zf = (C, hl) => z => { const [i, a] = ZC[z] || [9, .2], R = BK.ramp(i); if (hl && !hl.includes(z)) return { f: FK.alpha(C.fg, .05), s: FK.alpha(C.fg, .2), d: FK.alpha(C.fg, .3) }; return { f: FK.alpha(R.c, a), s: R.dk, d: R.dk }; };
B8.zf = zf;
const sector = (g, cx, cy, r0, r1, a0, a1, at) => { const c = Math.cos, s = Math.sin, lg = a1 - a0 > PI ? 1 : 0; return E('path', Object.assign({ d: `M${(cx + r0 * c(a0)).toFixed(1)} ${(cy + r0 * s(a0)).toFixed(1)}A${r0} ${r0} 0 ${lg} 1 ${(cx + r0 * c(a1)).toFixed(1)} ${(cy + r0 * s(a1)).toFixed(1)}L${(cx + r1 * c(a1)).toFixed(1)} ${(cy + r1 * s(a1)).toFixed(1)}A${r1} ${r1} 0 ${lg} 0 ${(cx + r1 * c(a0)).toFixed(1)} ${(cy + r1 * s(a0)).toFixed(1)}Z` }, at), g); };
B8.sector = sector;
const ring = (g, cx, cy, r0, r1, at) => E('path', Object.assign({ d: `M${cx - r1} ${cy}a${r1} ${r1} 0 1 0 ${2 * r1} 0a${r1} ${r1} 0 1 0 ${-2 * r1} 0ZM${cx - r0} ${cy}a${r0} ${r0} 0 1 1 ${2 * r0} 0a${r0} ${r0} 0 1 1 ${-2 * r0} 0Z`, 'fill-rule': 'evenodd' }, at), g);
const pol = (cx, cy, r, a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];

/* ── দ্বিবীজপত্রী কাণ্ড (সূর্যমুখী) ── */
const DS = { epi: .955, hypo: .84, cortex: .64, endo: .615, peri: .58, phl: .50, cam: .485, xyl: .33, nb: 10, half: .17 };
B8.dStem = (g, C, cx, cy, R, hl) => {
  const Z = zf(C, hl), nb = DS.nb;
  E('circle', { cx, cy, r: R, fill: Z('cortex').f }, g);
  ring(g, cx, cy, R * DS.xyl, R * DS.endo, { fill: Z('ray').f }); E('circle', { cx, cy, r: R * DS.xyl, fill: Z('pith').f }, g);
  B8.ringBlobs(g, cx, cy, R * .06, R * DS.xyl, 3, { fill: 'none', stroke: Z('pith').s, sw: .5, seed: 11 });
  ring(g, cx, cy, R * DS.peri, R * DS.endo, { fill: Z('peri').f });
  for (let k = 0; k < nb; k++) {
    const a = k * 2 * PI / nb + .1, h = DS.half;
    sector(g, cx, cy, R * DS.peri, R * DS.endo, a - h * .85, a + h * .85, { fill: Z('cap').f, stroke: Z('cap').s, 'stroke-width': .7 });
    sector(g, cx, cy, R * DS.phl, R * DS.peri, a - h * .8, a + h * .8, { fill: Z('phl').f, stroke: Z('phl').s, 'stroke-width': .7 });
    sector(g, cx, cy, R * DS.cam, R * DS.phl, a - h * .9, a + h * .9, { fill: Z('cam').f, stroke: Z('cam').s, 'stroke-width': .5 });
    const [x1, y1] = pol(cx, cy, R * DS.cam, a - h * .78), [x2, y2] = pol(cx, cy, R * DS.cam, a + h * .78), [x3, y3] = pol(cx, cy, R * (DS.xyl + .01), a + h * .3), [x4, y4] = pol(cx, cy, R * (DS.xyl + .01), a - h * .3);
    E('path', { d: `M${x1.toFixed(1)} ${y1.toFixed(1)}L${x2.toFixed(1)} ${y2.toFixed(1)}L${x3.toFixed(1)} ${y3.toFixed(1)}L${x4.toFixed(1)} ${y4.toFixed(1)}Z`, fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': .7 }, g);
    [[.44, -.42, .032], [.44, .42, .03], [.445, 0, .036], [.39, -.2, .022], [.39, .2, .022], [.355, 0, .014]].forEach(([r, f, s]) => { const [x, y] = pol(cx, cy, R * r, a + h * f * (r / .45)); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: (R * s).toFixed(1), fill: hl && !hl.includes('xyl') ? 'none' : C.sf, stroke: Z('xyl').d, 'stroke-width': .9 }, g); });
  }
  B8.ringCells(g, cx, cy, R * DS.endo, R * DS.cortex, Math.round(2 * PI * R * .63 / 6), { fill: Z('endo').f, stroke: Z('endo').s, sw: .6 });
  B8.ringBlobs(g, cx, cy, R * DS.cortex, R * DS.hypo, 3, { fill: 'none', stroke: Z('cortex').s, sw: .5, seed: 41 });
  B8.ringBlobs(g, cx, cy, R * DS.hypo, R * DS.epi, 2, { fill: Z('hypo').f, stroke: Z('hypo').s, sw: .6, seed: 71, sc: .86 });
  B8.ringCells(g, cx, cy, R * DS.epi, R, Math.round(2 * PI * R / 6), { fill: Z('epi').f, stroke: Z('epi').s, sw: .6 });
  for (let k = 0; k < 7; k++) { const a = k * 2 * PI / 7 + .4, [x0, y0] = pol(cx, cy, R, a); let d = `M${x0.toFixed(1)} ${y0.toFixed(1)}`; for (let j = 1; j <= 3; j++) { const [x, y] = pol(cx, cy, R + j * R * .045, a + j * .015); d += `L${x.toFixed(1)} ${y.toFixed(1)}`; } E('path', { d, stroke: Z('epi').s, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g); }
};
/* ── একবীজপত্রী কাণ্ড (ভুট্টা) ── */
const MB = (() => { const L = []; [[.83, 18, .042], [.69, 13, .052], [.53, 9, .06], [.35, 6, .066], [.14, 2, .066]].forEach(([r, n, s], j) => { for (let i = 0; i < n; i++) { const a = (i + .5 * (j % 2)) * 2 * PI / n + (rnd(j * 40 + i) - .5) * .25, rr = r + (rnd(j * 70 + i) - .5) * .06; L.push([rr, a, s]); } }); return L; })();
B8.MB = MB;
B8.mStem = (g, C, cx, cy, R, hl) => {
  const Z = zf(C, hl);
  E('circle', { cx, cy, r: R, fill: Z('gnd').f }, g);
  const sp = R * .078; let k = 0;
  for (let y = -R; y <= R; y += sp * .87) { for (let x = -R; x <= R; x += sp) { const xx = x + ((Math.round((y + R) / (sp * .87)) % 2) ? sp / 2 : 0), rf = Math.hypot(xx, y) / R; if (rf > .89) continue; if (MB.some(([r, a, s]) => Math.hypot(xx - R * r * Math.cos(a), y - R * r * Math.sin(a)) < R * s * 1.25)) continue; B8.blob(g, cx + xx, cy + y, sp * .46, { fill: 'none', stroke: Z('gnd').s, sw: .45, seed: k++, n: 6 }); } }
  B8.ringCells(g, cx, cy, R * .9, R * .93, Math.round(2 * PI * R * .9 / 5), { fill: Z('hypoScl').f, stroke: Z('hypoScl').s, sw: .5 });
  B8.ringCells(g, cx, cy, R * .93, R * .965, Math.round(2 * PI * R * .93 / 5), { fill: Z('hypoScl').f, stroke: Z('hypoScl').s, sw: .5 });
  B8.ringCells(g, cx, cy, R * .965, R, Math.round(2 * PI * R / 5), { fill: Z('epi').f, stroke: Z('epi').s, sw: .5 });
  MB.forEach(([r, a, s]) => B8.mBundle(g, C, cx + R * r * Math.cos(a), cy + R * r * Math.sin(a), R * s, a, hl));
};
/* একটি বদ্ধ সমপার্শ্বীয় বান্ডল (একবীজপত্রী) — (x,y) কেন্দ্র, আকার s, বাইরের দিকের কোণ a */
B8.mBundle = (g, C, x, y, s, a, hl, big) => {
  const Z = zf(C, hl), u = [Math.cos(a), Math.sin(a)], v = [-Math.sin(a), Math.cos(a)], P = (du, dv) => [x + s * (du * u[0] + dv * v[0]), y + s * (du * u[1] + dv * v[1])], deg = a * 180 / PI;
  E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: (s * 1.1).toFixed(1), ry: (s * .9).toFixed(1), transform: `rotate(${deg.toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})`, fill: Z('sheath').f, stroke: Z('sheath').s, 'stroke-width': big ? 1.2 : .6 }, g);
  E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: (s * .92).toFixed(1), ry: (s * .74).toFixed(1), transform: `rotate(${deg.toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})`, fill: C.sf }, g);
  const [px, py] = P(.45, 0); E('ellipse', { cx: px.toFixed(1), cy: py.toFixed(1), rx: (s * .36).toFixed(1), ry: (s * .46).toFixed(1), transform: `rotate(${deg.toFixed(1)} ${px.toFixed(1)} ${py.toFixed(1)})`, fill: Z('phl').f, stroke: Z('phl').s, 'stroke-width': .5 }, g);
  [[-.05, -.45, .22], [-.05, .45, .22], [-.42, 0, .1]].forEach(([du, dv, r]) => { const [qx, qy] = P(du, dv); E('circle', { cx: qx.toFixed(1), cy: qy.toFixed(1), r: (s * r).toFixed(1), fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': big ? 1.4 : .7 }, g); });
  const [lx, ly] = P(-.66, 0); E('circle', { cx: lx.toFixed(1), cy: ly.toFixed(1), r: (s * .17).toFixed(1), fill: C.sf, stroke: Z('xyl').s, 'stroke-width': .5, 'stroke-dasharray': big ? '2 1.5' : null }, g);
};
/* ── দ্বিবীজপত্রী মূল (ছোলা) ── */
const DR = { epi: .965, cortex: .42, endo: .39, peri: .36, arms: 4 };
B8.dRoot = (g, C, cx, cy, R, hl) => {
  const Z = zf(C, hl), arms = DR.arms;
  E('circle', { cx, cy, r: R, fill: Z('cortex').f }, g);
  B8.ringBlobs(g, cx, cy, R * DR.cortex, R * DR.epi, 5, { fill: 'none', stroke: Z('cortex').s, sw: .5, seed: 23, sc: .95 });
  E('circle', { cx, cy, r: R * DR.peri, fill: Z('conj').f }, g);
  const ne = Math.round(2 * PI * R * .4 / 6);
  B8.ringCells(g, cx, cy, R * DR.endo, R * DR.cortex, ne, { fill: i => { const a = (i + .5) / ne * 2 * PI; return (hl && !hl.includes('endo')) ? Z('endo').f : (Array.from({ length: arms }, (_, k) => k * 2 * PI / arms).some(b => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b))) < .1) ? FK.alpha(BK.ramp(3).c, .15) : Z('endo').f); }, stroke: Z('endo').s, sw: .6 });
  for (let i = 0; i < ne; i++) { const a = i / ne * 2 * PI, [x, y] = pol(cx, cy, R * (DR.endo + DR.cortex) / 2, a); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: Math.max(.8, R * .009).toFixed(1), fill: Z('endo').d }, g); }
  B8.ringCells(g, cx, cy, R * DR.peri, R * DR.endo, Math.round(2 * PI * R * .37 / 6), { fill: Z('peri').f, stroke: Z('peri').s, sw: .5 });
  for (let k = 0; k < arms; k++) {
    const a = k * 2 * PI / arms; [[.31, .022], [.25, .03], [.18, .04], [.1, .05]].forEach(([r, s]) => { const [x, y] = pol(cx, cy, R * r, a); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: (R * s).toFixed(1), fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': .8 }, g); });
    const [px, py] = pol(cx, cy, R * .25, a + PI / arms); E('ellipse', { cx: px.toFixed(1), cy: py.toFixed(1), rx: (R * .065).toFixed(1), ry: (R * .05).toFixed(1), transform: `rotate(${((a + PI / arms) * 180 / PI + 90).toFixed(0)} ${px.toFixed(1)} ${py.toFixed(1)})`, fill: Z('phl').f, stroke: Z('phl').s, 'stroke-width': .7 }, g);
  }
  E('circle', { cx, cy, r: R * .05, fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': .8 }, g);
  B8.ringCells(g, cx, cy, R * DR.epi, R, Math.round(2 * PI * R / 6), { fill: Z('epi').f, stroke: Z('epi').s, sw: .6 });
  for (let k = 0; k < 6; k++) { const a = k * 2 * PI / 6 + .3, [x0, y0] = pol(cx, cy, R, a), [x1, y1] = pol(cx, cy, R * 1.12, a + .06), [x2, y2] = pol(cx, cy, R * 1.2, a + .02); E('path', { d: `M${x0.toFixed(1)} ${y0.toFixed(1)}Q${x1.toFixed(1)} ${y1.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}`, stroke: Z('hair').s, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g); }
};
/* ── একবীজপত্রী মূল (ভুট্টা) ── */
const MR = { epi: .965, cortex: .55, endo: .52, peri: .495, pith: .32, n: 12 };
B8.mRoot = (g, C, cx, cy, R, hl) => {
  const Z = zf(C, hl), n = MR.n;
  E('circle', { cx, cy, r: R, fill: Z('cortex').f }, g);
  B8.ringBlobs(g, cx, cy, R * MR.cortex, R * MR.epi, 4, { fill: 'none', stroke: Z('cortex').s, sw: .5, seed: 33, sc: .95 });
  E('circle', { cx, cy, r: R * MR.peri, fill: Z('conjScl').f }, g); E('circle', { cx, cy, r: R * MR.pith, fill: Z('pith').f }, g);
  B8.ringBlobs(g, cx, cy, R * .04, R * MR.pith, 3, { fill: 'none', stroke: Z('pith').s, sw: .5, seed: 5 });
  const ne = Math.round(2 * PI * R * .53 / 5);
  B8.ringCells(g, cx, cy, R * MR.endo, R * MR.cortex, ne, { fill: i => { const a = (i + .5) / ne * 2 * PI; return (hl && !hl.includes('endo')) ? Z('endo').f : (Array.from({ length: n }, (_, k) => k * 2 * PI / n).some(b => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b))) < .05) ? FK.alpha(BK.ramp(3).c, .15) : Z('endo').f); }, stroke: Z('endo').s, sw: .6 });
  B8.ringCells(g, cx, cy, R * MR.peri, R * MR.endo, Math.round(2 * PI * R * .5 / 5), { fill: Z('peri').f, stroke: Z('peri').s, sw: .5 });
  for (let k = 0; k < n; k++) {
    const a = k * 2 * PI / n, [x1, y1] = pol(cx, cy, R * .45, a), [x2, y2] = pol(cx, cy, R * .37, a), [px, py] = pol(cx, cy, R * .44, a + PI / n);
    E('circle', { cx: x1.toFixed(1), cy: y1.toFixed(1), r: (R * .02).toFixed(1), fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': .7 }, g);
    E('circle', { cx: x2.toFixed(1), cy: y2.toFixed(1), r: (R * .045).toFixed(1), fill: Z('xyl').f, stroke: Z('xyl').s, 'stroke-width': 1 }, g);
    E('circle', { cx: px.toFixed(1), cy: py.toFixed(1), r: (R * .03).toFixed(1), fill: Z('phl').f, stroke: Z('phl').s, 'stroke-width': .6 }, g);
  }
  B8.ringCells(g, cx, cy, R * MR.epi, R, Math.round(2 * PI * R / 6), { fill: Z('epi').f, stroke: Z('epi').s, sw: .6 });
  for (let k = 0; k < 5; k++) { const a = k * 2 * PI / 5 + .9, [x0, y0] = pol(cx, cy, R, a), [x1, y1] = pol(cx, cy, R * 1.12, a + .06), [x2, y2] = pol(cx, cy, R * 1.2, a + .02); E('path', { d: `M${x0.toFixed(1)} ${y0.toFixed(1)}Q${x1.toFixed(1)} ${y1.toFixed(1)} ${x2.toFixed(1)} ${y2.toFixed(1)}`, stroke: Z('hair').s, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g); }
};
/* চাপ দেওয়া বিন্দুর অঞ্চল */
const angNear = (a, n, off = 0) => { const st = 2 * PI / n, d = ((a - off) % st + st) % st; return Math.min(d, st - d); };
B8.zoneOf = (kind, dx, dy, R) => {
  const rf = Math.hypot(dx, dy) / R, a = Math.atan2(dy, dx);
  if (rf > 1.02) return kind.endsWith('Root') ? 'hair' : null;
  if (kind === 'dStem') { if (rf > DS.epi) return 'epi'; if (rf > DS.hypo) return 'hypo'; if (rf > DS.cortex) return 'cortex'; if (rf > DS.endo) return 'endo'; const inB = angNear(a, DS.nb, .1) < DS.half * .8; if (rf > DS.peri) return inB ? 'cap' : 'peri'; if (rf > DS.xyl) { if (!inB) return 'ray'; return rf > DS.phl ? 'phl' : rf > DS.cam ? 'cam' : 'xyl'; } return 'pith'; }
  if (kind === 'mStem') { if (rf > .965) return 'epi'; if (rf > .9) return 'hypoScl'; for (const [r, b, s] of MB) { const bx = r * Math.cos(b), by = r * Math.sin(b), d = Math.hypot(dx / R - bx, dy / R - by); if (d < s * 1.15) { const du = ((dx / R - bx) * Math.cos(b) + (dy / R - by) * Math.sin(b)) / s; return d > s * .85 ? 'sheath' : du > .15 ? 'phl' : 'xyl'; } } return 'gnd'; }
  if (kind === 'dRoot') { if (rf > DR.epi) return 'epi'; if (rf > DR.cortex) return 'cortex'; if (rf > DR.endo) return 'endo'; if (rf > DR.peri) return 'peri'; return angNear(a, DR.arms) < .3 || rf < .08 ? 'xyl' : rf > .15 ? 'phl' : 'conj'; }
  if (kind === 'mRoot') { if (rf > MR.epi) return 'epi'; if (rf > MR.cortex) return 'cortex'; if (rf > MR.endo) return 'endo'; if (rf > MR.peri) return 'peri'; if (rf > MR.pith) return angNear(a, MR.n) < .12 ? 'xyl' : angNear(a, MR.n, PI / MR.n) < .1 ? 'phl' : 'conjScl'; return 'pith'; }
  return null;
};

/* ───────── তিন টিস্যুতন্ত্র ───────── */
const TS3 = { epi: ['epi'], gnd: ['hypo', 'cortex', 'endo', 'peri', 'cap', 'ray', 'pith'], vas: ['phl', 'cam', 'xyl'] };
const TSX = 140, TSY = 138, TSR = 112;
V.tissueSystems = B8.seg({
  id: 'ts', t: 'তিনটি টিস্যুতন্ত্র (সূর্যমুখীর কাণ্ডে)', H: 280,
  cap: 'স্যাক্স (1875) উদ্ভিদদেহের টিস্যুগুলোকে তিনটি তন্ত্রে ভাগ করেন — ত্বক, মৌলিক (গ্রাউন্ড) ও ভাস্কুলার টিস্যুতন্ত্র। একটি তন্ত্র বেছে নাও — শুধু সেটি রঙিন থাকবে; প্রস্থচ্ছেদে যেকোনো অংশে চাপ দিলে তার নাম ও তন্ত্র দেখাবে। চালু করলে বেছে নেওয়া তন্ত্রটি জ্বলে-নেভে।',
  types: {
    epi: ['ত্বক', 'ত্বক টিস্যুতন্ত্র (এপিডার্মাল)', 'সবচেয়ে বাইরের আবরণ — ত্বক (এপিডার্মিস), কিউটিকল, পত্ররন্ধ্র, ট্রাইকোম (রোম), মূলে মূলরোমযুক্ত এপিব্লেমা। কাজ: রক্ষা, পানি হ্রাস রোধ, গ্যাস বিনিময়, শোষণ (মূলরোম)।'],
    gnd: ['মৌলিক', 'মৌলিক (গ্রাউন্ড) টিস্যুতন্ত্র', 'ত্বক ও ভাস্কুলার বান্ডল বাদে বাকি সব — হাইপোডার্মিস, সাধারণ কর্টেক্স, এন্ডোডার্মিস, পেরিসাইকল, মজ্জারশ্মি ও মজ্জা (পাতায় মেসোফিল)। কাজ: খাদ্য তৈরি ও সঞ্চয়, দৃঢ়তা, পার্শ্বমূল সৃষ্টি (পেরিসাইকল)।'],
    vas: ['ভাস্কুলার', 'ভাস্কুলার টিস্যুতন্ত্র', 'ভাস্কুলার বান্ডল — জাইলেম, ফ্লোয়েম ও (দ্বিবীজপত্রীতে) ক্যাম্বিয়াম। কাজ: পানি-খনিজ (জাইলেম) ও খাদ্য (ফ্লোয়েম) পরিবহন; দৃঢ়তা; ক্যাম্বিয়াম থেকে গৌণ বৃদ্ধি।']
  },
  def: 'gnd',
  art(g, C, ty) {
    B8.dStem(g, C, TSX, TSY, TSR, TS3[ty]);
    const L = [['epi', 'ত্বক', 0], ['gnd', 'মৌলিক', 11], ['vas', 'ভাস্কুলার', 4]];
    L.forEach(([k, s, ri], i) => { const R = BK.ramp(ri), y = 40 + i * 30, on = k === ty; E('rect', { x: 272, y: y - 12, width: 16, height: 16, rx: 4, fill: on ? FK.alpha(R.c, .6) : FK.alpha(C.fg, .08), stroke: on ? R.dk : C.ln }, g); T(g, 294, y + 1, s, { fs: 12, w: on ? 700 : 500, c: on ? R.ink : C.mu }); });
    T(g, 272, 250, 'চাপ দাও', { fs: 10.5, c: C.mu }); T(g, 272, 264, 'যেকোনো অংশে', { fs: 10.5, c: C.mu });
  },
  tap(x, y) { const z = B8.zoneOf('dStem', x - TSX, y - TSY, TSR); return z ? B8.zoneInfo(z, 'dStem') : null; },
  anim(g, C, ty, t) { const k = ty, R = BK.ramp(6); E('circle', { cx: TSX, cy: TSY, r: k === 'epi' ? TSR - 2 : k === 'gnd' ? TSR * .75 : TSR * .5, fill: 'none', stroke: FK.alpha(R.c, .5 + .5 * Math.sin(t * 5)), 'stroke-width': k === 'vas' ? TSR * .27 : 3 }, g); T(g, TSX, 274, { epi: 'ত্বক টিস্যুতন্ত্র — সবচেয়ে বাইরে', gnd: 'মৌলিক টিস্যুতন্ত্র — মাঝের সব', vas: 'ভাস্কুলার টিস্যুতন্ত্র — বান্ডলের বলয়' }[k], { fs: 11, a: 'middle', w: 650, c: R.ink }); }
});
/* অঞ্চলের নাম ও বিবরণ — visuals3 ও ব্যবহার করে */
B8.ZI = {
  epi: ['ত্বক (এপিডার্মিস)', 'ত্বক', 'এক সারি চ্যাপ্টা, ঘনসন্নিবিষ্ট কোষ; বাইরে কিউটিকল; কাণ্ডে বহুকোষী রোম ও পত্ররন্ধ্র। মূলে একে এপিব্লেমা বা রাইজোডার্মিস বলে — কিউটিকল ও পত্ররন্ধ্র নেই, এককোষী মূলরোম আছে।'],
  hair: ['মূলরোম', 'ত্বক', 'এপিব্লেমার কোষের নলাকার এককোষী প্রসারণ — মাটি থেকে পানি ও খনিজ শোষণ করে।'],
  hypo: ['হাইপোডার্মিস (কোলেনকাইমা)', 'মৌলিক', 'ত্বকের নিচে কয়েক স্তর কোলেনকাইমা — দ্বিবীজপত্রী কাণ্ডে নমনীয় দৃঢ়তা দেয়।'],
  hypoScl: ['হাইপোডার্মিস (স্ক্লেরেনকাইমা)', 'মৌলিক', 'ত্বকের নিচে 2–3 স্তর স্ক্লেরেনকাইমা — একবীজপত্রী কাণ্ডে দৃঢ়তা দেয়।'],
  cortex: ['কর্টেক্স (প্যারেনকাইমা)', 'মৌলিক', 'আন্তঃকোষীয় ফাঁকযুক্ত পাতলা প্রাচীরের প্যারেনকাইমা — খাদ্য সঞ্চয়; মূলে কর্টেক্স খুব চওড়া, পানি ভেতরে পৌঁছে দেয়।'],
  endo: ['এন্ডোডার্মিস', 'মৌলিক', 'কর্টেক্সের সবচেয়ে ভেতরের এক স্তর, পিপার মতো ঘন কোষ। মূলে কোষের অরীয় ও অনুপ্রস্থ প্রাচীরে সুবেরিন-লিগনিনের ক্যাসপেরিয়ান ফিতা — পানিকে কোষের ভেতর দিয়ে যেতে বাধ্য করে; প্রোটোজাইলেমের সামনের পাতলা প্রাচীরের কোষ = প্যাসেজ কোষ। কাণ্ডে প্রায়ই শ্বেতসারপূর্ণ — শ্বেতসার আবরণী।'],
  peri: ['পেরিসাইকল', 'মৌলিক', 'এন্ডোডার্মিসের ঠিক ভেতরের স্তর। মূলে এক স্তর প্যারেনকাইমা — এখান থেকে পার্শ্বমূল তৈরি হয় (অন্তর্জাত) এবং গৌণ বৃদ্ধিতে ক্যাম্বিয়ামের অংশ গড়ে। সূর্যমুখী কাণ্ডে বান্ডলের বাইরে স্ক্লেরেনকাইমা ক্যাপ ও মাঝে প্যারেনকাইমা।'],
  cap: ['বান্ডল ক্যাপ (হার্ড বাস্ট)', 'মৌলিক', 'প্রতিটি বান্ডলের বাইরে অর্ধচন্দ্রাকার স্ক্লেরেনকাইমা — পেরিসাইকলের অংশ; ফ্লোয়েমকে রক্ষা ও দৃঢ়তা দেয়।'],
  ray: ['মজ্জারশ্মি', 'মৌলিক', 'দুটি বান্ডলের মাঝের প্যারেনকাইমা — মজ্জা ও কর্টেক্সের মধ্যে পার্শ্বীয় পরিবহন। একবীজপত্রী কাণ্ডে নেই।'],
  pith: ['মজ্জা (পিথ)', 'মৌলিক', 'কেন্দ্রের বড় বড় প্যারেনকাইমা কোষ — খাদ্য ও পানি সঞ্চয়। দ্বিবীজপত্রী মূলে মজ্জা প্রায় থাকে না; একবীজপত্রী মূলে বড় মজ্জা।'],
  gnd: ['মৌলিক টিস্যু (ভিত্তি টিস্যু)', 'মৌলিক', 'একবীজপত্রী কাণ্ডে হাইপোডার্মিসের ভেতরের সব প্যারেনকাইমা — কর্টেক্স, এন্ডোডার্মিস, পেরিসাইকল, মজ্জা আলাদা করা যায় না; এর মধ্যেই বান্ডল ছড়ানো।'],
  phl: ['ফ্লোয়েম', 'ভাস্কুলার', 'সিভনল, সঙ্গীকোষ, ফ্লোয়েম প্যারেনকাইমা ও ফাইবার — খাদ্য পরিবহন। কাণ্ডে বান্ডলের বাইরের দিকে; মূলে জাইলেমের বাহুর মাঝে মাঝে (অরীয়)। একবীজপত্রীতে ফ্লোয়েম প্যারেনকাইমা নেই।'],
  cam: ['অন্তঃপূলীয় ক্যাম্বিয়াম', 'ভাস্কুলার', 'জাইলেম ও ফ্লোয়েমের মাঝে কয়েক সারি আয়তাকার ভাজক কোষ — বান্ডলকে "মুক্ত" করে; গৌণ বৃদ্ধিতে গৌণ জাইলেম ও ফ্লোয়েম তৈরি করে।'],
  xyl: ['জাইলেম', 'ভাস্কুলার', 'ভেসেল, ট্র্যাকিড, ফাইবার ও প্যারেনকাইমা — পানি ও খনিজ পরিবহন। কাণ্ডে প্রোটোজাইলেম কেন্দ্রের দিকে (এন্ডার্ক); মূলে প্রোটোজাইলেম বাইরের দিকে (এক্সার্ক)। একবীজপত্রী কাণ্ডের বান্ডলে প্রোটোজাইলেমের নিচে লাইসিজেনাস গহ্বর।'],
  sheath: ['বান্ডল আবরণী', 'মৌলিক', 'একবীজপত্রী কাণ্ডে প্রতিটি বান্ডলকে ঘিরে স্ক্লেরেনকাইমার আবরণ — দৃঢ়তা দেয়।'],
  conj: ['সংযোগী টিস্যু', 'মৌলিক', 'মূলে জাইলেম ও ফ্লোয়েমের মাঝের প্যারেনকাইমা — দ্বিবীজপত্রী মূলে এখান থেকে ক্যাম্বিয়াম তৈরি হয়ে গৌণ বৃদ্ধি ঘটে।'],
  conjScl: ['সংযোগী টিস্যু (স্ক্লেরেনকাইমা)', 'মৌলিক', 'ভুট্টা ও অনেক একবীজপত্রী মূলে জাইলেম-ফ্লোয়েমের মাঝের টিস্যু স্ক্লেরেনকাইমাময় — দৃঢ়তা দেয়।']
};
B8.zoneInfo = (z) => { const i = B8.ZI[z]; return i ? `<b>${i[0]}</b> <span class="chip">${i[1]} টিস্যুতন্ত্র</span><div class="small">${i[2]}</div>` : null; };

/* ───────── পত্ররন্ধ্র ───────── */
V.stomata = B8.seg({
  id: 'st', t: 'পত্ররন্ধ্র: গঠন ও খোলা-বন্ধ হওয়া', H: 250,
  cap: 'দুটি রক্ষীকোষ ঘেরা ছিদ্র। আলোতে রক্ষীকোষে K<sup>+</sup> আয়ন ঢোকে → দ্রবের ঘনত্ব বাড়ে → অভিস্রবণে পানি ঢোকে → রক্ষীকোষ ফুলে বাঁকে → ছিদ্র খোলে। অন্ধকারে বা পানির অভাবে (অ্যাবসিসিক অ্যাসিড) উল্টোটা — ছিদ্র বন্ধ। চালু করো।',
  types: {
    kid: ['বৃক্কাকার', 'বৃক্কাকার রক্ষীকোষ — দ্বিবীজপত্রী', 'দুটি শিমবীজ (কিডনি) আকৃতির রক্ষীকোষ; ছিদ্রের দিকের প্রাচীর পুরু ও অস্থিতিস্থাপক, বাইরের দিক পাতলা — ফুললে বাইরের দিকে বেঁকে ছিদ্র খোলে। রক্ষীকোষে ক্লোরোপ্লাস্ট থাকে (অন্য ত্বককোষে থাকে না)।', 'জবা, আম — সাধারণত পাতার নিচের তলে বেশি'],
    dumb: ['ডাম্বেল', 'ডাম্বেল আকৃতির রক্ষীকোষ — ঘাস (Poaceae)', 'রক্ষীকোষ মাঝে সরু ও পুরু প্রাচীরের, দুই প্রান্ত ফোলা ও পাতলা প্রাচীরের; দুই পাশে দুটি সহকারী কোষ। প্রান্ত ফুললে মাঝের সরু অংশ দুটি আলাদা হয়ে ছিদ্র খোলে — খুব দ্রুত সাড়া দেয়।', 'ধান, গম, ভুট্টা — পাতার দুই তলে প্রায় সমান']
  },
  def: 'kid',
  art(g, C, ty) {
    const Ep = BK.ramp(0);
    for (let r = 0; r < 4; r++) for (let c = 0; c < 6; c++) { const x = 8 + c * 60 + (r % 2) * 30, y = 10 + r * 52; if (Math.abs(x + 28 - 180) < 70 && Math.abs(y + 24 - 118) < 70) continue; E('path', { d: `M${x} ${y}q14 -6 28 0t28 0v24q-6 14 0 28h-28q-14 6 -28 0q6 -14 0 -28Z`, fill: FK.alpha(Ep.c, .1), stroke: FK.alpha(Ep.dk, .6), 'stroke-width': .9 }, g); }
    if (ty === 'dumb') [-1, 1].forEach(s => E('path', { d: `M${180 + s * 30} 56q${s * 34} 8 ${s * 34} 62q0 54 ${-s * 34} 62`, fill: FK.alpha(Ep.c, .2), stroke: Ep.dk, 'stroke-width': 1 }, g));
    T(g, 180, 242, ty === 'kid' ? 'উপর থেকে দেখা (ত্বকের তল)' : 'সহকারী কোষসহ ঘাসের পত্ররন্ধ্র', { fs: 10.5, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t) {
    const o = .5 - .5 * Math.cos(t * 1.1), cx = 180, cy = 118, Gc = BK.ramp(10), Wl = BK.ramp(11), K = BK.ramp(3), Wt = BK.ramp(5);
    if (ty === 'kid') {
      const prx = 2 + 11 * o, pry = 32 + 4 * o, orx = 36 + 4 * o, ory = 50;
      [-1, 1].forEach(s => {
        E('path', { d: `M${cx} ${cy - ory}A${orx} ${ory} 0 0 ${s > 0 ? 1 : 0} ${cx} ${cy + ory}L${cx} ${cy + pry}A${prx} ${pry} 0 0 ${s > 0 ? 0 : 1} ${cx} ${cy - pry}Z`, fill: FK.alpha(Gc.c, .3), stroke: Wl.dk, 'stroke-width': 1.2 }, g);
        E('path', { d: `M${cx} ${cy + pry}A${prx} ${pry} 0 0 ${s > 0 ? 0 : 1} ${cx} ${cy - pry}`, stroke: Wl.dk, 'stroke-width': 3.2, fill: 'none' }, g);
        for (let k = 0; k < 5; k++) { const yy = cy - 30 + k * 15, xx = cx + s * (prx + (orx - prx) * .55 * Math.cos((yy - cy) / ory)); E('ellipse', { cx: xx.toFixed(1), cy: yy, rx: 3.4, ry: 2.2, fill: Gc.dk }, g); }
      });
      E('ellipse', { cx, cy, rx: Math.max(.5, prx - 1.5), ry: pry - 1, fill: FK.alpha(C.fg, .55) }, g);
    } else {
      const bulb = 12 + 5 * o, gap = 1 + 6 * o;
      [-1, 1].forEach(s => {
        const x = cx + s * (gap + 6);
        E('path', { d: `M${x - 5} ${cy - 40}V${cy + 40}M${x + 5} ${cy - 40}V${cy + 40}`, stroke: Wl.dk, 'stroke-width': 1.2 }, g);
        E('rect', { x: x - 5, y: cy - 40, width: 10, height: 80, fill: FK.alpha(Gc.c, .3) }, g);
        [-1, 1].forEach(e => E('circle', { cx: x + s * 2, cy: cy + e * 46, r: bulb, fill: FK.alpha(Gc.c, .3), stroke: Wl.dk, 'stroke-width': 1.2 }, g));
        E('path', { d: `M${x - s * 5} ${cy - 34}V${cy + 34}`, stroke: Wl.dk, 'stroke-width': 3.4 }, g);
        [-1, 1].forEach(e => E('ellipse', { cx: x + s * 3, cy: cy + e * 46, rx: 3, ry: 2.2, fill: Gc.dk }, g));
      });
      E('rect', { x: cx - gap, y: cy - 34, width: Math.max(.5, gap * 2), height: 68, fill: FK.alpha(C.fg, .55) }, g);
    }
    const open = Math.sin(t * 1.1) > 0;
    for (let k = 0; k < 4; k++) { const f = (t * .9 + k / 4) % 1, s = k % 2 ? 1 : -1, x0 = cx + s * 120, x1 = cx + s * 34, x = open ? x0 + (x1 - x0) * f : x1 + (x0 - x1) * f, y = cy - 40 + k * 26; E('circle', { cx: x.toFixed(1), cy: y, r: 5, fill: FK.alpha(K.c, .8) }, g); T(g, x, y + 3, 'K', { fs: 7, a: 'middle', w: 700, c: '#fff', st: 'stroke:none' }); }
    T(g, 180, 22, o > .5 ? 'রক্ষীকোষ ফুলেছে — ছিদ্র খোলা' : 'রক্ষীকোষ শিথিল — ছিদ্র বন্ধ হচ্ছে', { fs: 12, a: 'middle', w: 650, c: o > .5 ? Gc.ink : K.ink });
    T(g, cx + (open ? 92 : -92), 228, open ? 'K আয়ন ও পানি ভেতরে' : 'K আয়ন ও পানি বাইরে', { fs: 10, a: 'middle', c: Wt.ink, w: 600 });
  }
});

/* ───────── পানি-পত্ররন্ধ্র ───────── */
V.hydathode = {
  t: 'পানি-পত্ররন্ধ্র (হাইডাথোড) ও গাটেশন', k: ['2d', 'anim', 'int'],
  cap: 'পাতার কিনারা বা অগ্রভাগে শিরার শেষ প্রান্তে থাকে। নিচে আলগা প্যারেনকাইমার এপিথেম, উপরে সবসময় খোলা ছিদ্র (রক্ষীকোষ কাজ করে না)। রাতে বা ভোরে মূলচাপে জাইলেম থেকে আসা পানি তরল ফোঁটা হয়ে বের হয় — গাটেশন। চালু করো।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"><b>পানি-পত্ররন্ধ্র</b> — জাইলেমের ট্র্যাকিড এপিথেমে শেষ; ছিদ্র সবসময় খোলা; তরল পানি (খনিজ লবণসহ) বের হয়। উদাহরণ: কচু, টমেটো, ধান ও ঘাসের পাতার আগা, পাথরকুচি।</div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 250; let C, svg, gd, tt = 0;
    const Lf = () => BK.ramp(10), L = () => BK.ramp(4);
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'পানি-পত্ররন্ধ্র' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg);
      const g = E('g', {}, svg), G = Lf(), R = L(), Ep = BK.ramp(0);
      E('path', { d: 'M14 70L250 70Q300 72 318 120Q300 168 250 170L14 170Z', fill: FK.alpha(G.c, .14), stroke: Ep.dk, 'stroke-width': 1.4 }, g);
      for (let x = 20; x < 230; x += 16) { E('rect', { x, y: 72, width: 15, height: 10, fill: FK.alpha(Ep.c, .3), stroke: Ep.dk, 'stroke-width': .5 }, g); E('rect', { x, y: 158, width: 15, height: 10, fill: FK.alpha(Ep.c, .3), stroke: Ep.dk, 'stroke-width': .5 }, g); }
      for (let x = 22; x < 190; x += 12) for (let y = 86; y < 154; y += 12) { if (Math.abs(y - 120) < 12) continue; B8.blob(g, x + ((y / 12) % 2 ? 6 : 0), y, 5, { fill: FK.alpha(G.c, .35), stroke: G.dk, sw: .5, seed: x * 3 + y }); }
      E('rect', { x: 14, y: 113, width: 200, height: 14, fill: FK.alpha(R.c, .25), stroke: R.dk, 'stroke-width': 1 }, g);
      for (let x = 18; x < 212; x += 6) E('path', { d: `M${x} 114l3 12`, stroke: R.dk, 'stroke-width': .8 }, g);
      for (let k = 0; k < 22; k++) B8.blob(g, 222 + (k % 6) * 13, 100 + Math.floor(k / 6) * 12 + (k % 2) * 3, 4.2, { fill: FK.alpha(BK.ramp(11).c, .2), stroke: BK.ramp(11).dk, sw: .6, seed: k + 90 });
      [-1, 1].forEach(s => E('ellipse', { cx: 316, cy: 120 + s * 9, rx: 4, ry: 6, fill: FK.alpha(G.c, .3), stroke: Ep.dk, 'stroke-width': 1 }, g));
      B8.lab(g, 120, 120, 120, 40, 'শিরা (ট্র্যাকিড)', C, { a: 'middle' }); B8.lab(g, 250, 112, 250, 40, 'এপিথেম', C, { a: 'middle' }); B8.lab(g, 318, 128, 330, 210, 'পানি-ছিদ্র', C, { a: 'end' }); B8.lab(g, 60, 92, 60, 204, 'মেসোফিল', C, { a: 'middle' });
      gd = E('g', { style: 'pointer-events:none' }, svg); frame();
    };
    const frame = () => {
      gd.innerHTML = ''; const Wt = BK.ramp(5); if (!tt) return;
      for (let k = 0; k < 8; k++) { const f = (tt * .3 + k / 8) % 1; let x, y; if (f < .6) { x = 16 + f / .6 * 200; y = 120; } else { const u = (f - .6) / .4; x = 216 + u * 100; y = 120 + Math.sin(u * 9 + k) * 12 * (1 - u); } E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 2.6, fill: Wt.c }, gd); }
      const ph = (tt % 4) / 4, r = 4 + 12 * Math.min(1, ph / .8), drop = ph > .8 ? (ph - .8) / .2 : 0;
      E('path', { d: `M${322} ${120 - r}q${r * 1.3} ${r} 0 ${2 * r}q${-r * .4} ${-r} 0 ${-2 * r}Z`, transform: `translate(${(r * .6).toFixed(1)} ${(drop * 90).toFixed(1)})`, fill: FK.alpha(Wt.c, .75), stroke: Wt.dk, 'stroke-width': 1 }, gd);
      T(gd, 180, 236, 'রাত বা ভোর · মূলচাপ → তরল পানির ফোঁটা (গাটেশন)', { fs: 11, a: 'middle', c: Wt.ink, w: 600 });
    };
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};
V.cmpStomaHyd = Object.assign({ t: 'পত্ররন্ধ্র ও পানি-পত্ররন্ধ্রের পার্থক্য', k: ['compare', 'int', 'game'], cap: 'অবস্থান, রক্ষীকোষ, ছিদ্রের অবস্থা, নিচের টিস্যু ও কাজের পার্থক্য।' }, BK.compare({
  a: 'পত্ররন্ধ্র (স্টোমা)', b: 'পানি-পত্ররন্ধ্র (হাইডাথোড)',
  rows: [
    ['অবস্থান', 'পাতার ত্বকে (সাধারণত নিচের তলে বেশি), কচি কাণ্ডে', 'পাতার কিনারা বা অগ্রভাগে, শিরার শেষ প্রান্তে'],
    ['রক্ষীকোষ', 'সক্রিয় — ফুলে-চুপসে ছিদ্র খোলে-বন্ধ করে', 'নিষ্ক্রিয় বা অনুপস্থিত'],
    ['ছিদ্র', 'খোলে ও বন্ধ হয়', 'সবসময় খোলা'],
    ['ছিদ্রের নিচে', 'উপপত্ররন্ধ্রীয় গহ্বর ও মেসোফিল', 'এপিথেম টিস্যু ও শিরার ট্র্যাকিড'],
    ['শিরার সাথে সংযোগ', 'সরাসরি নেই', 'সরাসরি আছে'],
    ['কী বের হয়', 'জলীয় বাষ্প (প্রস্বেদন); O<sub>2</sub> ও CO<sub>2</sub> বিনিময়', 'তরল পানি ও দ্রবীভূত খনিজ (গাটেশন)'],
    ['কখন সক্রিয়', 'সাধারণত দিনে', 'রাতে বা ভোরে — মাটি ভেজা ও বাতাস আর্দ্র থাকলে'],
    ['চালিকা শক্তি', 'প্রস্বেদন টান', 'মূলচাপ'],
    ['সংখ্যা', 'অসংখ্য', 'কম, নির্দিষ্ট স্থানে'],
    ['উদাহরণ', 'প্রায় সব স্থলজ উদ্ভিদের পাতা', 'কচু, টমেটো, ধান ও ঘাস, পাথরকুচি']
  ]
}));

/* ───────── ত্বকের বৈশিষ্ট্য ───────── */
V.epidermis = B8.seg({
  id: 'ep', t: 'ত্বক টিস্যুতন্ত্রের উপাদান', H: 240,
  types: {
    cut: ['কিউটিকল', 'ত্বক ও কিউটিকল', 'ত্বক এক স্তর ঘনসন্নিবিষ্ট কোষ, কোষের মাঝে ফাঁক নেই, সাধারণত ক্লোরোপ্লাস্ট নেই (রক্ষীকোষ বাদে); বাইরে মোমজাতীয় কিউটিন এর আবরণ — কিউটিকল — পানি হ্রাস ও রোগজীবাণু রোধ করে। পানি ও গ্যাস বিনিময় হয় পত্ররন্ধ্র দিয়ে।', 'মরু উদ্ভিদে কিউটিকল খুব পুরু'],
    tri: ['ট্রাইকোম', 'ট্রাইকোম (রোম)', 'ত্বকের কোষ থেকে বের হওয়া এককোষী বা বহুকোষী রোম; কিছু গ্রন্থিযুক্ত — তেল, আঠা বা বিষ ক্ষরণ করে। কাজ: পানি হ্রাস কমানো, তাপ ও পোকামাকড় থেকে রক্ষা।', 'সূর্যমুখীর কাণ্ডে বহুকোষী রোম, তুলসী ও তামাকে গ্রন্থিরোম, বিছুটির হুল'],
    hair: ['মূলরোম', 'মূলরোম ও এপিব্লেমা', 'মূলের ত্বক (এপিব্লেমা) এর কোষ থেকে নলাকার এককোষী প্রসারণ; কিউটিকল নেই, পাতলা প্রাচীর — মাটির কণার ফাঁক থেকে পানি ও খনিজ শোষণ করে; শোষণ তল কয়েকগুণ বাড়ায়।', 'মূলের রোমাঞ্চল (অগ্রভাগের কিছুটা পেছনে)'],
    bulli: ['বুলিফর্ম', 'বুলিফর্ম (মোটর) কোষ', 'ঘাসের পাতার উপরের ত্বকে বড়, পাতলা প্রাচীরের, পানিপূর্ণ কোষের গুচ্ছ। পানির অভাবে চুপসে গেলে পাতা গুটিয়ে যায় — প্রস্বেদন কমে; পানি পেলে আবার মেলে।', 'ধান, গম, ভুট্টা, বাঁশ']
  },
  def: 'cut',
  art(g, C, ty, ctx) {
    const Ep = BK.ramp(0), G = BK.ramp(10), Y = BK.ramp(6), Wl = BK.ramp(11);
    if (ty === 'cut') {
      E('rect', { x: 14, y: 52, width: 332, height: 10, rx: 3, fill: FK.alpha(Y.c, .55), stroke: Y.dk }, g);
      for (let x = 14; x < 346; x += 30) { if (Math.abs(x + 15 - 180) < 26) continue; E('rect', { x, y: 62, width: 30, height: 26, fill: FK.alpha(Ep.c, .18), stroke: Ep.dk, 'stroke-width': 1 }, g); }
      [-1, 1].forEach(s => E('ellipse', { cx: 180 + s * 12, cy: 75, rx: 9, ry: 12, fill: FK.alpha(G.c, .4), stroke: Wl.dk }, g));
      E('ellipse', { cx: 180, cy: 104, rx: 26, ry: 14, fill: FK.alpha(C.fg, .06), stroke: FK.alpha(C.fg, .2), 'stroke-dasharray': '2 2' }, g);
      for (let x = 20; x < 346; x += 22) for (let y = 98; y < 220; y += 24) { if (Math.abs(x - 180) < 34 && y < 124) continue; B8.blob(g, x + ((y / 24) % 2 ? 11 : 0), y + 6, 10, { fill: FK.alpha(G.c, .25), stroke: G.dk, sw: .6, seed: x + y }); }
      B8.lab(g, 60, 56, 40, 30, 'কিউটিকল', C, { a: 'start' }); B8.lab(g, 100, 76, 110, 30, 'ত্বক', C, { a: 'start' }); B8.lab(g, 192, 76, 250, 30, 'রক্ষীকোষ', C, { a: 'start' }); B8.lab(g, 200, 106, 270, 230, 'উপপত্ররন্ধ্রীয় গহ্বর', C, { a: 'middle' });
    }
    if (ty === 'tri') {
      for (let x = 10; x < 350; x += 28) E('rect', { x, y: 170, width: 28, height: 22, fill: FK.alpha(Ep.c, .18), stroke: Ep.dk }, g);
      E('rect', { x: 10, y: 166, width: 340, height: 4, fill: FK.alpha(Y.c, .5) }, g);
      E('path', { d: 'M66 170Q60 110 80 70', stroke: Ep.dk, 'stroke-width': 9, 'stroke-linecap': 'round', fill: 'none' }, g); E('path', { d: 'M66 170Q60 110 80 70', stroke: FK.alpha(Ep.c, .3), 'stroke-width': 7, 'stroke-linecap': 'round', fill: 'none' }, g);
      for (let k = 0; k < 4; k++) E('rect', { x: 172, y: 166 - (k + 1) * 26, width: 16 - k * 2 + 0, height: 26, rx: 4, transform: `translate(${k} 0)`, fill: FK.alpha(Ep.c, .25), stroke: Ep.dk }, g);
      E('rect', { x: 284, y: 120, width: 8, height: 48, fill: FK.alpha(Ep.c, .25), stroke: Ep.dk }, g); E('circle', { cx: 288, cy: 108, r: 15, fill: FK.alpha(Y.c, .45), stroke: Y.dk }, g);
      T(g, 72, 220, 'এককোষী', { fs: 11, a: 'middle', w: 600 }); T(g, 180, 220, 'বহুকোষী', { fs: 11, a: 'middle', w: 600 }); T(g, 288, 220, 'গ্রন্থিরোম', { fs: 11, a: 'middle', w: 600 });
    }
    if (ty === 'hair') {
      E('rect', { x: 0, y: 0, width: 360, height: 240, rx: 12, fill: FK.alpha('#8a6b3a', .1) }, g);
      ctx.soil = []; for (let k = 0; k < 26; k++) { const x = 140 + rnd(k) * 210, y = 14 + rnd(k + 50) * 200; if (Math.abs(y - 150) < 20 && x < 300) continue; ctx.soil.push([x, y]); B8.blob(g, x, y, 9 + rnd(k + 9) * 8, { fill: FK.alpha('#a68a5b', .45), stroke: '#8a6b3a', sw: .8, seed: k }); }
      for (let y = 16; y < 230; y += 24) { E('rect', { x: 20, y, width: 46, height: 24, fill: FK.alpha(BK.ramp(11).c, .15), stroke: Wl.dk, 'stroke-width': .7 }, g); E('rect', { x: 66, y, width: 24, height: 24, fill: FK.alpha(Ep.c, .25), stroke: Ep.dk, 'stroke-width': .9 }, g); }
      T(g, 43, 236, 'কর্টেক্স', { fs: 10, a: 'middle', c: C.mu }); T(g, 78, 236, 'এপিব্লেমা', { fs: 10, a: 'middle', c: Ep.ink, w: 600 });
    }
    if (ty === 'bulli') T(g, 180, 228, 'ঘাসের পাতার প্রস্থচ্ছেদ (উপরে বুলিফর্ম কোষ)', { fs: 10.5, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) {
    const Wt = BK.ramp(5), Ep = BK.ramp(0), Y = BK.ramp(6), G = BK.ramp(10);
    if (ty === 'cut') { for (let k = 0; k < 5; k++) { const f = (t * .4 + k / 5) % 1, x = 180 + Math.sin(k * 3 + f * 6) * 10 * f, y = 104 - f * 90; E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 2 + f * 2, fill: FK.alpha(Wt.c, 1 - f) }, g); } T(g, 300, 120, 'জলীয় বাষ্প বের হয়', { fs: 10, a: 'middle', c: Wt.ink, w: 600 }); T(g, 300, 134, 'কেবল ছিদ্র দিয়ে', { fs: 10, a: 'middle', c: Wt.ink }); }
    if (ty === 'tri') { const f = (t % 3) / 3, r = 2 + 6 * Math.min(1, f / .7), dy = f > .7 ? (f - .7) / .3 * 40 : 0; E('circle', { cx: 300, cy: 100 + dy, r, fill: FK.alpha(Y.c, .8), stroke: Y.dk }, g); T(g, 300, 66, 'ক্ষরণ', { fs: 10, a: 'middle', c: Y.ink, w: 600 }); }
    if (ty === 'hair') { const L = 140 + 60 * (.5 + .5 * Math.sin(t * .5)); E('path', { d: `M90 152H${90 + L}q8 0 8 -6t-8 -6H90`, fill: FK.alpha(Ep.c, .3), stroke: Ep.dk, 'stroke-width': 1.2 }, g); E('ellipse', { cx: 100, cy: 146, rx: 5, ry: 4, fill: FK.alpha(BK.ramp(3).c, .7) }, g); for (let k = 0; k < 6; k++) { const f = (t * .35 + k / 6) % 1, x = 90 + L + 20 - f * (L + 20), y = 146 + (f < .2 ? (k % 2 ? -1 : 1) * 30 * (1 - f / .2) : 0); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 2.5, fill: Wt.c }, g); } T(g, 250, 200, 'পানি ও খনিজ শোষণ', { fs: 10.5, a: 'middle', c: Wt.ink, w: 600 }); }
    if (ty === 'bulli') {
      const d = .5 + .5 * Math.sin(t * .9), Rc = 900 - 780 * (1 - d), cx = 180, cy = 170, span = 300 / Rc, th = 26, P = (r, a) => [cx + r * Math.sin(a), cy - Rc + r * Math.cos(a)];
      let path = ''; for (let i = 0; i <= 30; i++) { const [x, y] = P(Rc, -span / 2 + span * i / 30); path += (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } for (let i = 30; i >= 0; i--) { const [x, y] = P(Rc - th, -span / 2 + span * i / 30); path += 'L' + x.toFixed(1) + ' ' + y.toFixed(1); }
      E('path', { d: path + 'Z', fill: FK.alpha(G.c, .25), stroke: G.dk, 'stroke-width': 1 }, g);
      [-2, -1, 0, 1, 2].forEach(k => { const [x, y] = P(Rc - th / 2, k * span / 5); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 4.5, fill: FK.alpha(BK.ramp(4).c, .6), stroke: BK.ramp(4).dk, 'stroke-width': .6 }, g); });
      [-1.5, -.5, .5, 1.5].forEach(k => { const sc = .4 + .6 * d; for (let j = -1; j <= 1; j++) { const aa = k * span / 5 + j * 9 / Rc, [x, y] = P(Rc - th + 1 + 6 * sc, aa); E('ellipse', { cx: x.toFixed(1), cy: y.toFixed(1), rx: 4.4, ry: 7 * sc, transform: `rotate(${(-aa * 180 / PI).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})`, fill: FK.alpha(Wt.c, .55), stroke: Wt.dk, 'stroke-width': .7 }, g); } });
      T(g, 180, 24, d > .5 ? 'পানি আছে — বুলিফর্ম কোষ স্ফীত, পাতা মেলা' : 'পানির অভাব — কোষ চুপসে পাতা গুটিয়ে যাচ্ছে', { fs: 11.5, a: 'middle', w: 650, c: d > .5 ? G.ink : BK.ramp(2).ink });
    }
  }
});

/* ───────── ভাস্কুলার বান্ডলের ধরন ───────── */
const VB = {
  radial: ['অরীয়', 'অরীয় (রেডিয়াল) বান্ডল', 'জাইলেম ও ফ্লোয়েম আলাদা আলাদা গুচ্ছে, ভিন্ন ভিন্ন ব্যাসার্ধে পালাক্রমে সাজানো; জাইলেম এক্সার্ক (প্রোটোজাইলেম বাইরে)।', 'সব মূল — দ্বিবীজপত্রী মূলে 2–6, একবীজপত্রী মূলে অনেক জাইলেম গুচ্ছ'],
  open: ['সমপার্শ্বীয় মুক্ত', 'সংযুক্ত সমপার্শ্বীয় মুক্ত বান্ডল', 'একই ব্যাসার্ধে বাইরে ফ্লোয়েম, ভেতরে জাইলেম, মাঝে ক্যাম্বিয়াম — তাই "মুক্ত" (গৌণ বৃদ্ধি সম্ভব); জাইলেম এন্ডার্ক।', 'দ্বিবীজপত্রী কাণ্ড (সূর্যমুখী, ছোলা) ও নগ্নবীজী কাণ্ড'],
  closed: ['সমপার্শ্বীয় বদ্ধ', 'সংযুক্ত সমপার্শ্বীয় বদ্ধ বান্ডল', 'বাইরে ফ্লোয়েম, ভেতরে জাইলেম, কিন্তু মাঝে ক্যাম্বিয়াম নেই — "বদ্ধ"; চারপাশে স্ক্লেরেনকাইমা আবরণী; গৌণ বৃদ্ধি হয় না।', 'একবীজপত্রী কাণ্ড — ভুট্টা, ধান, বাঁশ'],
  bicol: ['দ্বিপার্শ্বীয়', 'সংযুক্ত দ্বিপার্শ্বীয় বান্ডল', 'জাইলেমের বাইরে ও ভেতরে — দুই পাশেই ফ্লোয়েম এবং দুই পাশেই ক্যাম্বিয়াম (বাইরের ফ্লোয়েম-বাইরের ক্যাম্বিয়াম-জাইলেম-ভেতরের ক্যাম্বিয়াম-ভেতরের ফ্লোয়েম)।', 'Cucurbitaceae — লাউ, কুমড়া, শসা'],
  amphic: ['কেন্দ্রিক (জাইলেম কেন্দ্রে)', 'কেন্দ্রিক — অ্যাম্ফিক্রিবাল (হ্যাড্রোসেন্ট্রিক)', 'জাইলেম কেন্দ্রে, চারপাশে ফ্লোয়েম ঘিরে থাকে।', 'ফার্ন (Pteris), Selaginella'],
  amphiv: ['কেন্দ্রিক (ফ্লোয়েম কেন্দ্রে)', 'কেন্দ্রিক — অ্যাম্ফিভেসাল (লেপ্টোসেন্ট্রিক)', 'ফ্লোয়েম কেন্দ্রে, চারপাশে জাইলেম ঘিরে থাকে।', 'Dracaena, Yucca, Acorus এর রাইজোম']
};
V.vbTypes = B8.seg({
  id: 'vb', t: 'ভাস্কুলার বান্ডলের প্রকারভেদ', H: 260, types: VB, def: 'open',
  cap: 'জাইলেম (লাল) ও ফ্লোয়েমের (সবুজ) পারস্পরিক অবস্থান অনুযায়ী বান্ডল অরীয়, সংযুক্ত (সমপার্শ্বীয় ও দ্বিপার্শ্বীয়) ও কেন্দ্রিক। ক্যাম্বিয়াম (হলুদ) থাকলে মুক্ত, না থাকলে বদ্ধ। চালু করলে ক্যাম্বিয়ামের বিভাজন দেখায়।',
  art(g, C, ty, ctx) {
    const X1 = BK.ramp(4), P = BK.ramp(10), Cm = BK.ramp(6), S = BK.ramp(4), cx = 180;
    const phl = (x, y, rx, ry, sd) => { E('ellipse', { cx: x, cy: y, rx, ry, fill: FK.alpha(P.c, .35), stroke: P.dk, 'stroke-width': 1 }, g); for (let i = 0; i < Math.round(rx * ry / 40); i++) { const a = rnd(sd + i) * 2 * PI, r = Math.sqrt(rnd(sd + i + 5)) * .9; E('rect', { x: (x + rx * r * Math.cos(a) - 2.5).toFixed(1), y: (y + ry * r * Math.sin(a) - 2.5).toFixed(1), width: 5, height: 5, fill: 'none', stroke: P.dk, 'stroke-width': .5 }, g); } };
    const xyl = (x, y, rx, ry, sd, inward) => { E('ellipse', { cx: x, cy: y, rx, ry, fill: FK.alpha(X1.c, .18), stroke: X1.dk, 'stroke-width': 1 }, g); [[-.5, -.2, .3], [.5, -.2, .3], [0, -.25, .34], [-.25, .35, .17], [.25, .35, .17], [0, .7, .1]].forEach(([u, v, s]) => E('circle', { cx: (x + u * rx).toFixed(1), cy: (y + v * ry * inward).toFixed(1), r: (s * Math.min(rx, ry)).toFixed(1), fill: C.sf, stroke: X1.dk, 'stroke-width': 1.3 }, g)); };
    const cam = (x, y, w, sd) => { E('rect', { x: x - w / 2, y: y - 6, width: w, height: 12, fill: FK.alpha(Cm.c, .5), stroke: Cm.dk, 'stroke-width': .8 }, g); for (let k = 1; k < 9; k++) E('path', { d: `M${x - w / 2 + k * w / 9} ${y - 6}v12`, stroke: Cm.dk, 'stroke-width': .6 }, g); };
    ctx.cam = [];
    if (ty === 'radial') {
      E('circle', { cx, cy: 122, r: 92, fill: FK.alpha(BK.ramp(11).c, .1), stroke: BK.ramp(2).dk, 'stroke-width': 1 }, g);
      for (let k = 0; k < 4; k++) { const a = k * PI / 2; [[78, 7], [62, 10], [44, 13], [24, 16]].forEach(([r, s]) => E('circle', { cx: (cx + r * Math.cos(a)).toFixed(1), cy: (122 + r * Math.sin(a)).toFixed(1), r: s, fill: FK.alpha(X1.c, .25), stroke: X1.dk, 'stroke-width': 1.2 }, g)); const b = a + PI / 4; phl(+(cx + 58 * Math.cos(b)).toFixed(1), +(122 + 58 * Math.sin(b)).toFixed(1), 18, 14, k * 20); }
      B8.lab(g, cx + 78, 122, 300, 40, 'প্রোটোজাইলেম (বাইরে)', C, { a: 'middle' }); B8.lab(g, cx + 41, 81, 80, 30, 'ফ্লোয়েম', C, { a: 'middle' }); B8.lab(g, cx + 24, 122, 300, 230, 'মেটাজাইলেম', C, { a: 'middle' });
    }
    if (ty === 'open' || ty === 'closed') {
      if (ty === 'closed') E('ellipse', { cx, cy: 128, rx: 92, ry: 106, fill: FK.alpha(S.c, .3), stroke: S.dk, 'stroke-width': 1.2 }, g);
      phl(cx, 62, 70, 34, 3); if (ty === 'open') { cam(cx, 106, 150); ctx.cam.push([cx, 106, 150]); } xyl(cx, 158, 64, 52, 9, 1);
      E('path', { d: 'M310 60V210', stroke: C.mu, 'stroke-width': 1 }, g); BK.arrow(g, 310, 196, 310, 214, C.mu, 1.2); T(g, 318, 236, 'কেন্দ্রের দিকে', { fs: 10, a: 'end', c: C.mu }); T(g, 318, 50, 'বাইরের দিকে', { fs: 10, a: 'end', c: C.mu });
      B8.lab(g, cx - 60, 62, 30, 40, 'ফ্লোয়েম', C, { a: 'start' }); if (ty === 'open') B8.lab(g, cx - 74, 106, 30, 106, 'ক্যাম্বিয়াম', C, { a: 'start' }); else B8.lab(g, cx - 88, 120, 30, 120, 'বান্ডল আবরণী', C, { a: 'start' });
      B8.lab(g, cx - 32, 154, 30, 170, 'মেটাজাইলেম', C, { a: 'start' }); B8.lab(g, cx, 194, 30, 220, 'প্রোটোজাইলেম (ভেতরে)', C, { a: 'start' });
    }
    if (ty === 'bicol') {
      phl(cx, 40, 64, 24, 3); cam(cx, 72, 140); xyl(cx, 128, 64, 44, 9, 1); cam(cx, 184, 120); phl(cx, 214, 56, 22, 13); ctx.cam.push([cx, 72, 140], [cx, 184, 120]);
      B8.lab(g, cx - 56, 40, 24, 30, 'বাইরের ফ্লোয়েম', C, { a: 'start' }); B8.lab(g, cx - 70, 72, 24, 76, 'বাইরের ক্যাম্বিয়াম', C, { a: 'start' }); B8.lab(g, cx - 40, 128, 24, 128, 'জাইলেম', C, { a: 'start' }); B8.lab(g, cx - 60, 184, 24, 184, 'ভেতরের ক্যাম্বিয়াম', C, { a: 'start' }); B8.lab(g, cx - 48, 214, 24, 236, 'ভেতরের ফ্লোয়েম', C, { a: 'start' });
    }
    if (ty === 'amphic') { phl(cx, 124, 104, 96, 5); xyl(cx, 124, 56, 50, 11, 1); B8.lab(g, cx + 90, 124, 330, 40, 'ফ্লোয়েম (চারপাশে)', C, { a: 'end' }); B8.lab(g, cx + 20, 112, 330, 230, 'জাইলেম (কেন্দ্রে)', C, { a: 'end' }); }
    if (ty === 'amphiv') { E('ellipse', { cx, cy: 124, rx: 104, ry: 96, fill: FK.alpha(X1.c, .18), stroke: X1.dk, 'stroke-width': 1 }, g); for (let k = 0; k < 14; k++) { const a = k * 2 * PI / 14, r = 74 + (k % 2) * 8; E('circle', { cx: (cx + r * 1.08 * Math.cos(a)).toFixed(1), cy: (124 + r * Math.sin(a)).toFixed(1), r: 9 + (k % 3) * 2, fill: C.sf, stroke: X1.dk, 'stroke-width': 1.3 }, g); } phl(cx, 124, 50, 44, 5); B8.lab(g, cx + 90, 100, 330, 40, 'জাইলেম (চারপাশে)', C, { a: 'end' }); B8.lab(g, cx + 20, 124, 330, 230, 'ফ্লোয়েম (কেন্দ্রে)', C, { a: 'end' }); }
  },
  anim(g, C, ty, t, ctx) {
    const Cm = BK.ramp(6), X1 = BK.ramp(4);
    ctx.cam.forEach(([x, y, w], j) => { const k = Math.floor(t * 2 + j * 3) % 9, xx = x - w / 2 + k * w / 9 + w / 18; E('rect', { x: (xx - w / 18).toFixed(1), y: y - 6, width: (w / 9).toFixed(1), height: 12, fill: FK.alpha(Cm.dk, .5) }, g); E('path', { d: `M${xx.toFixed(1)} ${y - 6}v12`, stroke: '#fff', 'stroke-width': 1.4 }, g); });
    if (ctx.cam.length) T(g, 180, 254, 'ক্যাম্বিয়াম বিভাজিত হয়ে নতুন জাইলেম-ফ্লোয়েম যোগ করে', { fs: 10.5, a: 'middle', c: Cm.ink, w: 600 });
    else T(g, 180, 254, ty === 'closed' ? 'ক্যাম্বিয়াম নেই — গৌণ বৃদ্ধি হয় না' : ty === 'radial' ? 'জাইলেম ও ফ্লোয়েম ভিন্ন ব্যাসার্ধে' : 'একটি টিস্যু অন্যটিকে ঘিরে', { fs: 10.5, a: 'middle', c: X1.ink, w: 600 });
  }
});

/* ───────── পরিবহনের দিক ───────── */
const XPpath = { xy: [[150, 290], [150, 200], [150, 120], [150, 70], [190, 58], [232, 50]], phUp: [[232, 50], [190, 58], [150, 70], [150, 40], [122, 28]], phDn: [[232, 50], [190, 58], [150, 70], [150, 200], [150, 290]] };
const along = (P, f) => { const L = []; let tot = 0; for (let i = 1; i < P.length; i++) { const d = Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); L.push(d); tot += d; } let s = f * tot; for (let i = 0; i < L.length; i++) { if (s <= L[i]) { const u = s / L[i]; return [P[i][0] + (P[i + 1][0] - P[i][0]) * u, P[i][1] + (P[i + 1][1] - P[i][1]) * u]; } s -= L[i]; } return P[P.length - 1]; };
V.xpFlow = B8.seg({
  id: 'xp', t: 'জাইলেম ও ফ্লোয়েমে পরিবহনের দিক', H: 320,
  cap: 'জাইলেম পানি ও খনিজ লবণ মূল থেকে কেবল উপরের দিকে (পাতায়) নেয় — প্রস্বেদন টানে, মৃত নলের মধ্য দিয়ে। ফ্লোয়েম পাতায় তৈরি খাদ্য (প্রধানত সুক্রোজ) যেখানে দরকার সেখানে নেয় — উপরে কচি পাতা-ফলে, নিচে মূলে — জীবিত সিভনলের মধ্য দিয়ে, দুই দিকে।',
  types: { xy: ['জাইলেম', 'জাইলেম — একমুখী, উপরের দিকে', 'মূলরোম → কর্টেক্স → জাইলেম → কাণ্ড → পাতা। চালিকা শক্তি: প্রস্বেদন টান (সংসক্তি-আসঞ্জন), মূলচাপ।'], ph: ['ফ্লোয়েম', 'ফ্লোয়েম — দ্বিমুখী, উৎস থেকে ভোক্তায়', 'উৎস (পরিণত পাতা) → সিভনল → ভোক্তা (ফল, কচি পাতা, মূল, সঞ্চয়ী অঙ্গ)। চালিকা শক্তি: চাপ-প্রবাহ (মুঞ্চ মতবাদ)।'], both: ['দুটোই', 'একসাথে দুই পরিবহন', 'একই ভাস্কুলার বান্ডলে পাশাপাশি — জাইলেম পানি উপরে নেয়; ফ্লোয়েম খাদ্য উপরে-নিচে নেয়; ফ্লোয়েমের চাপ তৈরিতে জাইলেম থেকে পানি আসে।'] },
  def: 'both',
  art(g, C, ty) {
    const G = BK.ramp(10), Wd = BK.ramp(11), soil = FK.alpha('#8a6b3a', .18);
    E('rect', { x: 8, y: 250, width: 344, height: 64, rx: 8, fill: soil }, g);
    E('path', { d: 'M150 250V30', stroke: FK.alpha(Wd.c, .55), 'stroke-width': 14, 'stroke-linecap': 'round' }, g);
    E('path', { d: 'M150 250v40M150 262l-34 30M150 266l30 28M150 256l-20 10', stroke: '#a68a5b', 'stroke-width': 3, fill: 'none', 'stroke-linecap': 'round' }, g);
    E('path', { d: 'M150 70Q200 30 262 46Q210 74 150 70Z', fill: FK.alpha(G.c, .7), stroke: G.dk }, g); E('path', { d: 'M150 120Q100 96 54 108Q100 136 150 120Z', fill: FK.alpha(G.c, .6), stroke: G.dk }, g);
    E('path', { d: 'M150 30Q130 18 116 24Q132 40 150 30Z', fill: FK.alpha(G.lt, .9), stroke: G.dk }, g);
    E('circle', { cx: 196, cy: 168, r: 18, fill: FK.alpha(BK.ramp(4).c, .6), stroke: BK.ramp(4).dk }, g); E('path', { d: 'M150 160Q172 156 184 158', stroke: Wd.dk, 'stroke-width': 2, fill: 'none' }, g);
    T(g, 270, 40, 'পরিণত পাতা (উৎস)', { fs: 10.5, c: G.ink, w: 600 }); T(g, 100, 18, 'কচি পাতা (ভোক্তা)', { fs: 10.5, a: 'middle', c: C.mu }); T(g, 220, 172, 'ফল (ভোক্তা)', { fs: 10.5, c: C.mu }); T(g, 200, 300, 'মূল (পানি শোষণ ও খাদ্যের ভোক্তা)', { fs: 10.5, c: C.mu });
  },
  anim(g, C, ty, t) {
    const Wt = BK.ramp(5), S = BK.ramp(6);
    if (ty !== 'ph') for (let k = 0; k < 10; k++) { const [x, y] = along(XPpath.xy, (t * .15 + k / 10) % 1); E('circle', { cx: (x - 3).toFixed(1), cy: y.toFixed(1), r: 3, fill: Wt.c }, g); }
    if (ty !== 'xy') { for (let k = 0; k < 5; k++) { const [x, y] = along(XPpath.phUp, (t * .2 + k / 5) % 1); E('rect', { x: (x + 1).toFixed(1), y: (y - 3).toFixed(1), width: 6, height: 6, rx: 1.5, fill: S.c, stroke: S.dk, 'stroke-width': .6 }, g); } for (let k = 0; k < 8; k++) { const [x, y] = along(XPpath.phDn, (t * .12 + k / 8) % 1); E('rect', { x: (x + 1).toFixed(1), y: (y - 3).toFixed(1), width: 6, height: 6, rx: 1.5, fill: S.c, stroke: S.dk, 'stroke-width': .6 }, g); } const f = (t * .3) % 1; E('rect', { x: (154 + f * 26).toFixed(1), y: (158 + f * 6).toFixed(1), width: 6, height: 6, rx: 1.5, fill: S.c, stroke: S.dk, 'stroke-width': .6 }, g); }
    if (ty !== 'ph') { E('circle', { cx: 24, cy: 214, r: 5, fill: Wt.c }, g); T(g, 34, 218, 'পানি (জাইলেম)', { fs: 10.5, c: Wt.ink, w: 600 }); }
    if (ty !== 'xy') { E('rect', { x: 19, y: 228, width: 10, height: 10, rx: 2, fill: S.c }, g); T(g, 34, 237, 'খাদ্য (ফ্লোয়েম)', { fs: 10.5, c: S.ink, w: 600 }); }
  }
});
V.cmpXP = Object.assign({ t: 'জাইলেম ও ফ্লোয়েমের পার্থক্য', k: ['compare', 'int', 'game'], cap: 'দুটিই জটিল পরিবহন টিস্যু — কিন্তু উপাদান, জীবিত-মৃত অবস্থা, পরিবাহিত বস্তু ও দিকে পার্থক্য।' }, BK.compare({
  a: 'জাইলেম', b: 'ফ্লোয়েম',
  rows: [
    ['উপাদান', 'ট্র্যাকিড, ভেসেল, জাইলেম ফাইবার, জাইলেম প্যারেনকাইমা', 'সিভনল, সঙ্গীকোষ, ফ্লোয়েম প্যারেনকাইমা, ফ্লোয়েম ফাইবার'],
    ['জীবিত না মৃত', 'অধিকাংশ মৃত — কেবল প্যারেনকাইমা জীবিত', 'অধিকাংশ জীবিত — কেবল ফাইবার মৃত'],
    ['পরিবাহিত বস্তু', 'পানি ও খনিজ লবণ', 'জৈব খাদ্য (প্রধানত সুক্রোজ), অ্যামিনো অ্যাসিড, হরমোন'],
    ['পরিবহনের দিক', 'একমুখী — মূল থেকে উপরে', 'দ্বিমুখী — উৎস থেকে ভোক্তায়, উপরে-নিচে'],
    ['প্রাচীর', 'লিগনিনযুক্ত, পুরু', 'প্রধানত সেলুলোজের, পাতলা (ফাইবার বাদে)'],
    ['বিশেষ গঠন', 'ভেসেলে ছিদ্রপ্লেট, প্রাচীরে নানা স্থূলীকরণ', 'সিভ প্লেট, ক্যালোজ'],
    ['চালিকা শক্তি', 'প্রস্বেদন টান, মূলচাপ', 'চাপ-প্রবাহ (সক্রিয় লোডিং)'],
    ['বান্ডলে অবস্থান (কাণ্ড)', 'ভেতরের দিকে', 'বাইরের দিকে'],
    ['যান্ত্রিক কাজ', 'প্রধান — কাঠ গড়ে, দৃঢ়তা দেয়', 'সামান্য (বাস্ট ফাইবার)'],
    ['বয়স্ক বৃক্ষে', 'গৌণ জাইলেম জমে কাঠ হয়', 'পুরোনো ফ্লোয়েম চাপা পড়ে নষ্ট হয়']
  ]
}));
})();
