/* ═══════════════════════════════════════════════════════════════════
   visuals1 — §৮.১ টিস্যু ও ভাজক টিস্যু
   B8 সহায়ক: seg (ধরন বদলানো চিত্র: স্থির স্তর + অ্যানিমেশন স্তর + চাপ দিলে তথ্য), rnd, hexCells, cube
   tissueTypes : টিস্যুর শ্রেণিবিভাগ (গাছ)         meriCell : ভাজক বনাম স্থায়ী কোষ (বিভাজন অ্যানিমেশন)
   meriPosition: শীর্ষস্থ, নিবেশিত ও পার্শ্বীয় ভাজক টিস্যুর অবস্থান ও বৃদ্ধি
   apexLS      : কাণ্ডের শীর্ষ (টিউনিকা-কর্পাস) ও মূলের শীর্ষ (হিস্টোজেন, নিষ্ক্রিয় কেন্দ্র)
   divPlane    : বিভাজন তল — পুঞ্জ, পাত, সারি ভাজক টিস্যু (ত্রিমাত্রিক ঘনক)
   simpleTissue: প্যারেনকাইমা, অ্যারেনকাইমা, কোলেনকাইমা, ফাইবার, স্ক্লেরাইড
   xylemEl     : জাইলেমের চার উপাদান ও পানি চলাচল      wallThick : প্রাচীরের স্থূলীকরণ
   phloemEl    : ফ্লোয়েমের উপাদান, খাদ্য পরিবহন ও সিভ প্লেট
   cmpMeriPerm, cmpSimpleComplex : তুলনা
   রঙের নিয়ম (পুরো অধ্যায়ে এক): লিগনিনযুক্ত (জাইলেম, স্ক্লেরেনকাইমা) = ৪ লাল (স্যাফ্রানিনের মতো),
   ফ্লোয়েম = ১০ সবুজ, ক্যাম্বিয়াম/ভাজক = ৬ অ্যাম্বার, এন্ডোডার্মিস = ৩ বেগুনি, পেরিসাইকল = ২ কমলা,
   ত্বক = ০ টিল, কোলেনকাইমা = ৫ আকাশি, প্যারেনকাইমা = ১১ জলপাই (হালকা)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, X = window.VX;
const B8 = window.B8 = {};
const bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
B8.bn = bn;
B8.rnd = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
const rnd = B8.rnd;
/* রঙ: অধ্যায়ের নিয়ম */
B8.col = { lig: () => BK.ramp(4), phl: () => BK.ramp(10), cam: () => BK.ramp(6), endo: () => BK.ramp(3), peri: () => BK.ramp(2), epi: () => BK.ramp(0), col: () => BK.ramp(5), par: () => BK.ramp(11) };

/* ধরন বদলানো চিত্র — o: { id, t, k?, cap, W?, H?, types:{key:[বোতাম, শিরোনাম, বর্ণনা, উদাহরণ?]}, def, art(g,C,ty,ctx), anim?(g,C,ty,t,ctx), tap?(x,y,ty,ctx) → html } */
B8.seg = o => ({
  t: o.t, k: o.k || ['2d', 'anim', 'int'], cap: o.cap,
  html: () => `<div class="fk-row">${X.seg(o.id, Object.keys(o.types).map(k => [k, o.types[k][0]]), o.def)}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button>${o.extraBtn || ''}</div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = o.W || 360, H = o.H || 260;
    let ty = o.def, C, svg, ga, gd, tt = 0, ctx = {};
    const defInfo = () => { const a = o.types[ty]; return `<b>${a[1] || a[0]}</b> — ${a[2]}${a[3] ? `<div class="small">উদাহরণ: ${a[3]}</div>` : ''}`; };
    const frame = () => { gd.innerHTML = ''; if (o.anim) o.anim(gd, C, ty, tt, ctx); };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; const h = typeof H === 'function' ? H(ty) : H;
      svg = E('svg', { viewBox: `0 0 ${W} ${h}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': o.types[ty][1] || o.types[ty][0] }, $('st'));
      E('rect', { x: 0, y: 0, width: W, height: h, rx: 12, fill: C.sf }, svg);
      ga = E('g', {}, svg); gd = E('g', { style: 'pointer-events:none' }, svg); ctx = { root };
      o.art(ga, C, ty, ctx); $('info').innerHTML = defInfo(); frame();
    };
    ctx.info = h => { $('info').innerHTML = h; };
    root.addEventListener('click', e => {
      if (!o.tap || !svg || !svg.contains(e.target)) return;
      const m = svg.getScreenCTM(); if (!m) return; const p = svg.createSVGPoint(); p.x = e.clientX; p.y = e.clientY; const q = p.matrixTransform(m.inverse());
      const h = o.tap(q.x, q.y, ty, ctx); $('info').innerHTML = h || defInfo(); if (ctx.redraw) ctx.redraw();
    });
    const A = X.anim(root, dt => { tt += dt; frame(); }, { paused: true }); X.pp(root, A);
    X.onSeg(root, o.id, v => { ty = v; tt = 0; base(); });
    if (o.onMount) o.onMount(root, () => ty, base);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* ষড়ভুজের মতো কোষজাল — বিন্দুগুলো সামান্য এলোমেলো, প্রতিটি কোষ গোলাকার বহুভুজ */
B8.blob = (g, x, y, r, o = {}) => {
  const n = o.n || 7, sd = o.seed || 1; let d = '';
  for (let i = 0; i <= n; i++) { const a = i / n * Math.PI * 2 + (o.rot || 0), rr = r * (1 + (rnd(sd * 31 + (i % n)) - .5) * (o.j != null ? o.j : .16)); d += (i ? 'L' : 'M') + (x + rr * Math.cos(a)).toFixed(1) + ' ' + (y + rr * Math.sin(a)).toFixed(1); }
  return E('path', { d: d + 'Z', fill: o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || 1, 'stroke-linejoin': 'round' }, g);
};
/* বৃত্তাকার বলয়ে কোষ (প্রস্থচ্ছেদের স্তর) — r0..r1, n টি কোষ */
B8.ringCells = (g, cx, cy, r0, r1, n, o = {}) => {
  const a0 = o.a0 != null ? o.a0 : 0, a1 = o.a1 != null ? o.a1 : Math.PI * 2, span = (a1 - a0) / n;
  for (let i = 0; i < n; i++) {
    const s = a0 + i * span + (o.gap || .004), e = a0 + (i + 1) * span - (o.gap || .004), c = Math.cos, sn = Math.sin, big = 0;
    const d = `M${(cx + r0 * c(s)).toFixed(1)} ${(cy + r0 * sn(s)).toFixed(1)}A${r0} ${r0} 0 ${big} 1 ${(cx + r0 * c(e)).toFixed(1)} ${(cy + r0 * sn(e)).toFixed(1)}L${(cx + r1 * c(e)).toFixed(1)} ${(cy + r1 * sn(e)).toFixed(1)}A${r1} ${r1} 0 ${big} 0 ${(cx + r1 * c(s)).toFixed(1)} ${(cy + r1 * sn(s)).toFixed(1)}Z`;
    E('path', { d, fill: typeof o.fill === 'function' ? o.fill(i) : o.fill || 'none', stroke: o.stroke || 'none', 'stroke-width': o.sw || .8, 'stroke-linejoin': 'round' }, g);
  }
};
/* বলয় জুড়ে গোল কোষ (কর্টেক্স) — সারি সংখ্যা rows */
B8.ringBlobs = (g, cx, cy, r0, r1, rows, o = {}) => {
  const dr = (r1 - r0) / rows, a0 = o.a0 != null ? o.a0 : 0, a1 = o.a1 != null ? o.a1 : Math.PI * 2; let k = o.seed || 3;
  for (let j = 0; j < rows; j++) {
    const r = r0 + dr * (j + .5), n = Math.max(3, Math.round((a1 - a0) * r / (dr * 1.05)));
    for (let i = 0; i < n; i++) { const a = a0 + (i + .5 + (j % 2) * .5) * (a1 - a0) / n; if (a > a1) continue; B8.blob(g, cx + r * Math.cos(a), cy + r * Math.sin(a), dr * .5 * (o.sc || .92), { fill: o.fill, stroke: o.stroke, sw: o.sw || .7, seed: k++, j: .22, n: 6, rot: a }); }
  }
};
/* সমমাত্রিক ঘনক (বিভাজন তলের চিত্রে) */
B8.cube = (g, x, y, s, R, hi) => {
  const h = s * .5, w = s * .866;
  E('path', { d: `M${x} ${y}l${w} ${-h}l${w} ${h}l${-w} ${h}Z`, fill: hi ? R.lt : FK.alpha(R.c, .55), stroke: R.dk, 'stroke-width': .9 }, g);
  E('path', { d: `M${x} ${y}l${w} ${h}v${s}l${-w} ${-h}Z`, fill: hi ? FK.alpha(R.c, .7) : FK.alpha(R.c, .8), stroke: R.dk, 'stroke-width': .9 }, g);
  E('path', { d: `M${x + w} ${y + h}l${w} ${-h}v${s}l${-w} ${h}Z`, fill: hi ? R.c : R.dk, stroke: R.dk, 'stroke-width': .9 }, g);
};
/* তীর */
B8.arr = (g, x1, y1, x2, y2, c, w = 1.6) => BK.arrow(g, x1, y1, x2, y2, c, w);
/* লেবেল রেখা ও লেখা */
B8.lab = (g, ax, ay, lx, ly, s, C, o = {}) => {
  E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': .9, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2, fill: C.fg }, g);
  const an = o.a || (lx < ax ? 'end' : 'start'); T(g, lx + (an === 'end' ? -3 : an === 'start' ? 3 : 0), ly + 4, s, { fs: o.fs || 11.5, a: an, w: 560, c: o.c || C.fg });
};

/* ───────── টিস্যুর শ্রেণিবিভাগ ───────── */
V.tissueTypes = Object.assign({ t: 'উদ্ভিদ টিস্যুর শ্রেণিবিভাগ', k: ['tree', 'int'], cap: 'কোষের বিভাজন ক্ষমতার ভিত্তিতে টিস্যু দুই প্রকার — ভাজক ও স্থায়ী। ভাজক টিস্যুকে অবস্থান, উৎপত্তি, কাজ ও বিভাজন তলের ভিত্তিতে এবং স্থায়ী টিস্যুকে গঠনের ভিত্তিতে ভাগ করা হয়। শাখায় চাপ দিলে খোলে।' }, BK.tree({
  t: 'উদ্ভিদ টিস্যু', d: 'একই উৎস থেকে সৃষ্ট, একই রকম গঠনের ও একই কাজে নিয়োজিত কোষগুচ্ছ।',
  c: [
    { t: 'ভাজক টিস্যু', d: 'বিভাজনক্ষম অপরিণত কোষের টিস্যু — মেরিস্টেম।', c: [
      { t: 'অবস্থান অনুযায়ী', d: 'কোথায় থাকে।', c: [{ t: 'শীর্ষস্থ', d: 'মূল ও কাণ্ডের অগ্রভাগে — দৈর্ঘ্য বৃদ্ধি।' }, { t: 'নিবেশিত', d: 'পর্বমধ্যের গোড়ায় বা পাতার গোড়ায় — ঘাসে দৈর্ঘ্য বৃদ্ধি।' }, { t: 'পার্শ্বীয়', d: 'অক্ষের পাশ বরাবর — ক্যাম্বিয়াম ও কর্ক ক্যাম্বিয়াম; প্রস্থে বৃদ্ধি।' }] },
      { t: 'উৎপত্তি অনুযায়ী', d: 'কোথা থেকে এসেছে।', c: [{ t: 'প্রোমেরিস্টেম', d: 'ভ্রূণের সবচেয়ে আদি ভাজক কোষ।' }, { t: 'প্রাথমিক', d: 'প্রোমেরিস্টেম থেকে — শীর্ষস্থ, নিবেশিত, অন্তঃপূলীয় ক্যাম্বিয়াম।' }, { t: 'সেকেন্ডারি', d: 'স্থায়ী টিস্যু আবার বিভাজনক্ষম হয়ে — আন্তঃপূলীয় ক্যাম্বিয়াম, কর্ক ক্যাম্বিয়াম।' }] },
      { t: 'কাজ অনুযায়ী', d: 'হ্যাবারল্যান্ড্ট এর তিন ভাগ।', c: [{ t: 'প্রোটোডার্ম', d: 'ত্বক টিস্যুতন্ত্র গড়ে।' }, { t: 'প্রোক্যাম্বিয়াম', d: 'প্রাথমিক জাইলেম, ফ্লোয়েম ও ক্যাম্বিয়াম গড়ে।' }, { t: 'গ্রাউন্ড মেরিস্টেম', d: 'কর্টেক্স, পেরিসাইকল, মজ্জা ইত্যাদি মৌলিক টিস্যু গড়ে।' }] },
      { t: 'বিভাজন তল অনুযায়ী', d: 'কোন তলে বিভাজন।', c: [{ t: 'পুঞ্জ', d: 'সব তলে — কোষপিণ্ড; সস্য, ভ্রূণ।' }, { t: 'পাত', d: 'দুই তলে — চ্যাপ্টা স্তর; পাতার ফলক, ত্বক।' }, { t: 'সারি', d: 'এক তলে — কোষের সারি; কর্টেক্স ও মজ্জা।' }] }
    ] },
    { t: 'স্থায়ী টিস্যু', d: 'বিভাজন ক্ষমতা হারানো পরিণত কোষের টিস্যু।', c: [
      { t: 'সরল টিস্যু', d: 'একই রকম কোষে গঠিত।', c: [{ t: 'প্যারেনকাইমা', d: 'জীবিত, পাতলা প্রাচীর — খাদ্য তৈরি ও সঞ্চয়।' }, { t: 'কোলেনকাইমা', d: 'জীবিত, কোণে পুরু প্রাচীর — নমনীয় দৃঢ়তা।' }, { t: 'স্ক্লেরেনকাইমা', d: 'মৃত, লিগনিনযুক্ত পুরু প্রাচীর — ফাইবার ও স্ক্লেরাইড।' }] },
      { t: 'জটিল টিস্যু', d: 'একাধিক রকম কোষে গঠিত, একসাথে একই কাজ।', c: [{ t: 'জাইলেম', d: 'ট্র্যাকিড, ভেসেল, জাইলেম ফাইবার, জাইলেম প্যারেনকাইমা — পানি ও খনিজ পরিবহন।' }, { t: 'ফ্লোয়েম', d: 'সিভনল, সঙ্গীকোষ, ফ্লোয়েম প্যারেনকাইমা, ফ্লোয়েম ফাইবার — খাদ্য পরিবহন।' }] },
      { t: 'ক্ষরণকারী টিস্যু', d: 'বিশেষ টিস্যু।', c: [{ t: 'তরুক্ষীর টিস্যু', d: 'দুধের মতো তরুক্ষীর — আকন্দ, রাবার।' }, { t: 'গ্রন্থি টিস্যু', d: 'মধুগ্রন্থি, তেলগ্রন্থি, গ্রন্থিরোম।' }] }
    ] }
  ]
}, { colW: 112 }));

/* ───────── ভাজক বনাম স্থায়ী কোষ ───────── */
const MC = { x0: 34, y0: 18, cw: 42, chh: 38, cols: 7, rows: 3 };
V.meriCell = B8.seg({
  id: 'mc', t: 'ভাজক কোষ ও স্থায়ী কোষ', H: 250,
  cap: 'ভাজক কোষ ছোট, ঘন সাইটোপ্লাজম ও বড় নিউক্লিয়াসযুক্ত, কোষগহ্বর প্রায় নেই, কোষের মাঝে ফাঁক নেই — চালু করলে একটি কোষ মাইটোসিসে দুটি হয়। স্থায়ী (প্যারেনকাইমা) কোষ বড়, মাঝে বিশাল কোষগহ্বর, সাইটোপ্লাজম প্রান্তে — চালু করলে সাইটোপ্লাজমের প্রবাহ দেখা যায়।',
  types: {
    meri: ['ভাজক কোষ', 'ভাজক (মেরিস্টেম্যাটিক) কোষ', 'ছোট, প্রায় সমব্যাসীয়; পাতলা সেলুলোজ প্রাচীর; ঘন সাইটোপ্লাজম; বড় নিউক্লিয়াস; কোষগহ্বর অনুপস্থিত বা খুব ছোট; আন্তঃকোষীয় ফাঁক নেই; সঞ্চিত খাদ্য নেই; বারবার বিভাজিত হয়।', 'মূল ও কাণ্ডের অগ্রভাগ, ক্যাম্বিয়াম'],
    perm: ['স্থায়ী কোষ', 'স্থায়ী কোষ (প্যারেনকাইমা)', 'বড়, নানা আকারের; প্রাচীর পাতলা বা পুরু; বিশাল কেন্দ্রীয় কোষগহ্বর, সাইটোপ্লাজম ও নিউক্লিয়াস প্রান্তে; আন্তঃকোষীয় ফাঁক থাকে; খাদ্য সঞ্চয় করে; সাধারণত বিভাজিত হয় না।', 'কর্টেক্স, মজ্জা, পাতার মেসোফিল']
  },
  def: 'meri',
  art(g, C, ty) {
    if (ty === 'meri') {
      const R = BK.ramp(6), N = BK.ramp(3);
      for (let r = 0; r < MC.rows; r++) for (let c = 0; c < MC.cols; c++) {
        const x = MC.x0 + c * MC.cw, y = MC.y0 + r * MC.chh, i = r * MC.cols + c;
        E('rect', { x, y, width: MC.cw, height: MC.chh, fill: FK.alpha(R.c, .2), stroke: R.dk, 'stroke-width': 1 }, g);
        for (let k = 0; k < 4; k++) E('circle', { cx: x + 5 + rnd(i * 7 + k) * (MC.cw - 10), cy: y + 5 + rnd(i * 11 + k) * (MC.chh - 10), r: 1.1, fill: FK.alpha(R.dk, .55) }, g);
        if (i !== 10) { E('circle', { cx: x + MC.cw / 2, cy: y + MC.chh / 2, r: 10, fill: FK.alpha(N.c, .55), stroke: N.dk, 'stroke-width': 1 }, g); E('circle', { cx: x + MC.cw / 2 + 2, cy: y + MC.chh / 2 - 1, r: 3, fill: N.dk }, g); }
      }
      const yb = MC.y0 + MC.rows * MC.chh;
      B8.lab(g, MC.x0 + MC.cw * 2, MC.y0 + MC.chh * 2, 30, yb + 26, 'পাতলা প্রাচীর', C, { a: 'start' });
      B8.lab(g, MC.x0 + MC.cw * 4.5, MC.y0 + MC.chh * 2.5, 190, yb + 26, 'বড় নিউক্লিয়াস', C, { a: 'start' });
      B8.lab(g, MC.x0 + MC.cw * 1.2, MC.y0 + MC.chh * 2.7, 30, yb + 52, 'ঘন সাইটোপ্লাজম', C, { a: 'start' });
      B8.lab(g, MC.x0 + MC.cw * 6, MC.y0 + MC.chh * 3, 190, yb + 52, 'ফাঁক নেই, গহ্বর নেই', C, { a: 'start' });
      T(g, 180, yb + 84, 'চালু করো: মাঝের সারির একটি কোষ বিভাজিত হচ্ছে', { fs: 11, a: 'middle', c: C.mu });
    } else {
      const P = BK.ramp(10), Vv = BK.ramp(5), N = BK.ramp(3), Wl = BK.ramp(11);
      for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) {
        const x = 26 + c * 78 + (r % 2) * 10, y = 16 + r * 74, w = 68, h = 64;
        E('rect', { x, y, width: w, height: h, rx: 18, fill: FK.alpha(P.c, .2), stroke: Wl.dk, 'stroke-width': 1.6 }, g);
        E('rect', { x: x + 7, y: y + 7, width: w - 14, height: h - 14, rx: 13, fill: FK.alpha(Vv.c, .2), stroke: FK.alpha(Vv.dk, .6), 'stroke-width': .8 }, g);
        const nx = x + (c % 2 ? w - 9 : 9), ny = y + h / 2; E('circle', { cx: nx, cy: ny, r: 5, fill: FK.alpha(N.c, .7), stroke: N.dk, 'stroke-width': .8 }, g);
      }
      [[98, 82], [176, 82], [254, 82], [104, 12], [182, 12], [260, 12]].forEach(([x, y]) => E('path', { d: `M${x} ${y}l4 -3l4 3l-4 3Z`, fill: FK.alpha(C.fg, .25) }, g));
      B8.lab(g, 60, 48, 40, 186, 'বিশাল কোষগহ্বর', C, { a: 'start' });
      B8.lab(g, 113, 122, 190, 186, 'নিউক্লিয়াস প্রান্তে', C, { a: 'start' });
      B8.lab(g, 180, 84, 40, 212, 'আন্তঃকোষীয় ফাঁক', C, { a: 'start' });
      B8.lab(g, 290, 140, 190, 212, 'প্রান্তীয় সাইটোপ্লাজম', C, { a: 'start' });
      T(g, 180, 240, 'চালু করো: সাইটোপ্লাজমের প্রবাহ (সাইক্লোসিস)', { fs: 11, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t) {
    if (ty === 'meri') {
      const x = MC.x0 + 3 * MC.cw, y = MC.y0 + MC.chh, cx = x + MC.cw / 2, cy = y + MC.chh / 2, N = BK.ramp(3), R = BK.ramp(6), ph = (t % 4.8) / 1.2, st = Math.floor(ph), u = ph - st;
      E('rect', { x: x + 1, y: y + 1, width: MC.cw - 2, height: MC.chh - 2, fill: 'none', stroke: R.c, 'stroke-width': 2 }, g);
      if (st === 0) { E('circle', { cx, cy, r: 10, fill: FK.alpha(N.c, .55), stroke: N.dk }, g); E('circle', { cx: cx + 2, cy: cy - 1, r: 3, fill: N.dk }, g); T(g, cx, y - 4, 'ইন্টারফেজ', { fs: 10, a: 'middle', c: N.ink, w: 600 }); }
      else if (st === 1) { for (let k = -2; k <= 2; k++) E('path', { d: `M${cx - 1 + k * .4} ${cy - 9 + Math.abs(k) * 2}l2 ${3}`, stroke: N.dk, 'stroke-width': 2.2 }, g); [-1, 0, 1].forEach(k => E('path', { d: `M${cx - 4} ${cy + k * 4}h8`, stroke: N.dk, 'stroke-width': 2.4, 'stroke-linecap': 'round' }, g)); T(g, cx, y - 4, 'মেটাফেজ', { fs: 10, a: 'middle', c: N.ink, w: 600 }); }
      else if (st === 2) { const d = 3 + u * 11; [-1, 1].forEach(s => [-1, 0, 1].forEach(k => E('path', { d: `M${cx + s * d - 1} ${cy + k * 4 - 1}l2 2`, stroke: N.dk, 'stroke-width': 2.6, 'stroke-linecap': 'round' }, g))); T(g, cx, y - 4, 'অ্যানাফেজ', { fs: 10, a: 'middle', c: N.ink, w: 600 }); }
      else { [-1, 1].forEach(s => E('circle', { cx: cx + s * 11, cy, r: 6, fill: FK.alpha(N.c, .55), stroke: N.dk }, g)); const L = (MC.chh - 2) * Math.min(1, u * 1.4); E('path', { d: `M${cx} ${cy - L / 2}V${cy + L / 2}`, stroke: R.dk, 'stroke-width': 2 }, g); T(g, cx, y - 4, 'কোষপ্লেট', { fs: 10, a: 'middle', c: N.ink, w: 600 }); }
    } else {
      const P = BK.ramp(10);
      for (let r = 0; r < 2; r++) for (let c = 0; c < 4; c++) {
        const x = 26 + c * 78 + (r % 2) * 10, y = 16 + r * 74, w = 68, h = 64, per = 2 * (w + h - 28), ins = 3.5;
        for (let k = 0; k < 4; k++) {
          let s = ((t * 22 + k * per / 4 + (r * 4 + c) * 13) % per + per) % per; const ww = w - 2 * ins, hh = h - 2 * ins; let px, py;
          if (s < ww) { px = x + ins + s; py = y + ins; } else if ((s -= ww) < hh) { px = x + w - ins; py = y + ins + s; } else if ((s -= hh) < ww) { px = x + w - ins - s; py = y + h - ins; } else { s -= ww; px = x + ins; py = y + h - ins - s; }
          E('circle', { cx: px.toFixed(1), cy: py.toFixed(1), r: 2.2, fill: P.dk }, g);
        }
      }
    }
  }
});

/* ───────── ভাজক টিস্যুর অবস্থান ───────── */
const MPt = {
  apical: ['শীর্ষস্থ', 'শীর্ষস্থ (অগ্রস্থ) ভাজক টিস্যু', 'মূল ও কাণ্ডের অগ্রভাগে (এবং শাখার অগ্রে) থাকে; বিভাজনে উদ্ভিদ লম্বা হয় — প্রাথমিক বৃদ্ধি। প্রাথমিক ভাজক টিস্যু।', 'কাণ্ডের শীর্ষমুকুল, মূলের অগ্রভাগ (মূলত্রের পেছনে)'],
  inter: ['নিবেশিত', 'নিবেশিত (ইন্টারক্যালারি) ভাজক টিস্যু', 'দুটি স্থায়ী টিস্যুর মাঝে — সাধারণত পর্বমধ্যের গোড়ায় (পর্বের ঠিক উপরে) বা পাতার গোড়ায়; শীর্ষস্থ ভাজক টিস্যুর বিচ্ছিন্ন অংশ; দৈর্ঘ্য বৃদ্ধি ঘটায়, পরে স্থায়ী টিস্যুতে পরিণত হয়। ঘাস কাটার পরও আবার বাড়ে এর জন্য।', 'ধান, বাঁশ, আখের পর্বমধ্যের গোড়া; পুদিনা'],
  lat: ['পার্শ্বীয়', 'পার্শ্বীয় ভাজক টিস্যু', 'মূল ও কাণ্ডের পার্শ্ব বরাবর অক্ষের সমান্তরালে বলয়ের মতো থাকে; পরিধি বা প্রস্থে বৃদ্ধি (গৌণ বৃদ্ধি) ঘটায়। ভাস্কুলার ক্যাম্বিয়াম গৌণ জাইলেম-ফ্লোয়েম এবং কর্ক ক্যাম্বিয়াম (ফেলোজেন) কর্ক তৈরি করে।', 'দ্বিবীজপত্রী ও নগ্নবীজী বৃক্ষের কাণ্ড ও মূল']
};
const LPx = 100, GPx = 292;
V.meriPosition = B8.seg({
  id: 'mp', t: 'ভাজক টিস্যুর অবস্থান: শীর্ষস্থ, নিবেশিত ও পার্শ্বীয়', H: 300, types: MPt, def: 'apical',
  cap: 'বামে একটি দ্বিবীজপত্রী গাছ (শীর্ষস্থ ও পার্শ্বীয় ভাজক টিস্যু), ডানে একটি ঘাসের কালম (নিবেশিত ভাজক টিস্যু), মাঝে কাণ্ডের প্রস্থচ্ছেদ (ক্যাম্বিয়াম বলয়)। ধরন বেছে চালু করো — কোন দিকে বৃদ্ধি হয় তীর দিয়ে দেখাবে।',
  art(g, C, ty) {
    const Gr = BK.ramp(10), Wd = BK.ramp(11), M = BK.ramp(6), soil = FK.alpha('#8a6b3a', .18), on = k => ty === k;
    E('rect', { x: 8, y: 250, width: 344, height: 44, rx: 8, fill: soil }, g);
    /* দ্বিবীজপত্রী গাছ */
    E('path', { d: `M${LPx} 250V58`, stroke: Wd.dk, 'stroke-width': 6, 'stroke-linecap': 'round' }, g);
    [[205, 1], [160, -1], [115, 1]].forEach(([y, s]) => { E('path', { d: `M${LPx} ${y}q${s * 20} -18 ${s * 44} -10q${-s * 20} 12 ${-s * 44} 10Z`, fill: FK.alpha(Gr.c, .75), stroke: Gr.dk, 'stroke-width': .8 }, g); E('path', { d: `M${LPx} ${y}q${-s * 18} -12 ${-s * 34} -6q${s * 16} 10 ${s * 34} 6Z`, fill: FK.alpha(Gr.c, .6), stroke: Gr.dk, 'stroke-width': .8 }, g); });
    E('path', { d: `M${LPx} 250v36M${LPx} 262l-22 18M${LPx} 270l20 16M${LPx} 258l-14 8`, stroke: '#a68a5b', 'stroke-width': 2.2, fill: 'none', 'stroke-linecap': 'round' }, g);
    E('ellipse', { cx: LPx, cy: 54, rx: 7, ry: 10, fill: on('apical') ? M.c : FK.alpha(Gr.c, .8), stroke: on('apical') ? M.dk : Gr.dk, 'stroke-width': 1.2 }, g);
    E('ellipse', { cx: LPx, cy: 287, rx: 4, ry: 6, fill: on('apical') ? M.c : '#a68a5b', stroke: on('apical') ? M.dk : 'none' }, g);
    if (on('apical')) { B8.lab(g, LPx + 6, 52, 150, 40, 'কাণ্ডের শীর্ষ', C, { a: 'start', c: M.ink }); B8.lab(g, LPx + 4, 288, 150, 284, 'মূলের অগ্রভাগ', C, { a: 'start', c: M.ink }); }
    /* প্রস্থচ্ছেদ */
    const cx = 196, cy = 196;
    E('path', { d: `M${LPx + 3} 196L${cx - 38} ${cy}`, stroke: C.mu, 'stroke-width': .9, 'stroke-dasharray': '3 3' }, g);
    E('circle', { cx, cy, r: 38, fill: FK.alpha(Gr.c, .18), stroke: Gr.dk, 'stroke-width': 1 }, g);
    E('circle', { cx, cy, r: 33, fill: 'none', stroke: on('lat') ? M.c : FK.alpha(M.c, .35), 'stroke-width': on('lat') ? 2.6 : 1.2, 'stroke-dasharray': '3 2' }, g);
    E('circle', { cx, cy, r: 22, fill: FK.alpha(BK.ramp(4).c, .22), stroke: on('lat') ? M.c : FK.alpha(M.c, .4), 'stroke-width': on('lat') ? 3 : 1.4 }, g);
    E('circle', { cx, cy, r: 9, fill: FK.alpha(Wd.c, .25) }, g);
    T(g, cx, cy + 56, 'কাণ্ডের প্রস্থচ্ছেদ', { fs: 10.5, a: 'middle', c: C.mu });
    if (on('lat')) { B8.lab(g, cx + 22, cy - 2, 258, 120, 'ভাস্কুলার ক্যাম্বিয়াম', C, { a: 'middle', c: M.ink }); B8.lab(g, cx - 30, cy - 18, 160, 112, 'কর্ক ক্যাম্বিয়াম', C, { a: 'middle', c: M.ink }); }
    /* ঘাসের কালম */
    const nodes = [236, 186, 136, 86];
    E('path', { d: `M${GPx} 250V40`, stroke: FK.alpha(Gr.c, .9), 'stroke-width': 8, 'stroke-linecap': 'round' }, g);
    nodes.forEach((y, i) => { E('rect', { x: GPx - 6, y: y - 3, width: 12, height: 6, rx: 2, fill: Gr.dk }, g); E('rect', { x: GPx - 5, y: y - 15, width: 10, height: 11, fill: on('inter') ? M.c : FK.alpha(M.c, .25) }, g); const s = i % 2 ? -1 : 1; E('path', { d: `M${GPx} ${y}q${s * 30} -40 ${s * 52} -48q${-s * 22} 14 ${-s * 48} 44Z`, fill: FK.alpha(Gr.c, .6), stroke: Gr.dk, 'stroke-width': .7 }, g); });
    E('path', { d: `M${GPx} 250v30M${GPx} 254l-16 20M${GPx} 254l16 20M${GPx} 254l-8 26M${GPx} 254l8 26`, stroke: '#a68a5b', 'stroke-width': 1.4, fill: 'none' }, g);
    T(g, GPx + 14, 24, 'ঘাসের কালম', { fs: 10.5, a: 'start', c: C.mu }); T(g, LPx - 16, 30, 'দ্বিবীজপত্রী গাছ', { fs: 10.5, a: 'end', c: C.mu });
    if (on('inter')) B8.lab(g, GPx - 5, 177, 232, 210, 'পর্বমধ্যের গোড়া', C, { a: 'end', c: M.ink });
  },
  anim(g, C, ty, t) {
    const M = BK.ramp(6), p = .5 + .5 * Math.sin(t * 4), f = (t % 1.6) / 1.6;
    if (ty === 'apical') {
      E('ellipse', { cx: LPx, cy: 54, rx: 10 + 4 * p, ry: 13 + 4 * p, fill: 'none', stroke: FK.alpha(M.c, .7), 'stroke-width': 2 }, g);
      E('ellipse', { cx: LPx, cy: 287, rx: 7 + 3 * p, ry: 9 + 3 * p, fill: 'none', stroke: FK.alpha(M.c, .7), 'stroke-width': 2 }, g);
      B8.arr(g, LPx, 40 - 10 * f, LPx, 26 - 10 * f, M.dk, 2.2); B8.arr(g, LPx + 12, 278 + 6 * f, LPx + 12, 292 + 6 * f, M.dk, 2);
    } else if (ty === 'inter') {
      [236, 186, 136, 86].forEach(y => { E('rect', { x: GPx - 8, y: y - 17, width: 16, height: 15, rx: 3, fill: 'none', stroke: FK.alpha(M.dk, .4 + .6 * p), 'stroke-width': 1.6 }, g); B8.arr(g, GPx + 12, y - 8 - 6 * f, GPx + 12, y - 20 - 6 * f, M.dk, 1.6); });
    } else {
      const cx = 196, cy = 196, k = (t * .25) % 1; E('circle', { cx, cy, r: 22 + 6 * k, fill: 'none', stroke: FK.alpha(BK.ramp(4).dk, 1 - k), 'stroke-width': 1.2 }, g);
      E('circle', { cx, cy, r: 33, fill: 'none', stroke: FK.alpha(M.c, .4 + .6 * p), 'stroke-width': 3 }, g);
      for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 + .2, r0 = 40 + 6 * f, r1 = 50 + 6 * f; B8.arr(g, (cx + r0 * Math.cos(a)).toFixed(1), (cy + r0 * Math.sin(a)).toFixed(1), (cx + r1 * Math.cos(a)).toFixed(1), (cy + r1 * Math.sin(a)).toFixed(1), M.dk, 1.4); }
    }
  }
});

/* ───────── শীর্ষ ভাজক টিস্যু: কাণ্ড ও মূল ───────── */
const AXc = 180, AYc = 158, AR = 84;
const CORP = []; for (let r = 0, y = AYc - 58; y < AYc + 6; y += 12, r++) for (let x = AXc - 60; x <= AXc + 66; x += 13) { const xx = x + (r % 2 ? 6 : 0); if (Math.hypot(xx - AXc, y - AYc) < AR - 22) CORP.push([xx, y]); }
const tunicaCells = (L, n) => { const r0 = AR - L * 8, r1 = r0 - 8, out = []; for (let i = 0; i < n; i++) { const a0 = Math.PI + .5 + i * (Math.PI - 1) / n, a1 = a0 + (Math.PI - 1) / n; out.push([r0, r1, a0, a1]); } return out; };
V.apexLS = B8.seg({
  id: 'ax', t: 'শীর্ষস্থ ভাজক টিস্যুর গঠন', H: 300,
  cap: 'কাণ্ডের শীর্ষে টিউনিকা-কর্পাস (শ্মিট, 1924): বাইরের এক-দুই স্তর টিউনিকা কেবল অ্যান্টিক্লাইনাল বিভাজনে পৃষ্ঠ বাড়ায়, ভেতরের কর্পাস সব তলে বিভাজিত হয়ে আয়তন বাড়ায়। মূলের শীর্ষে হ্যানস্টাইনের (1868) হিস্টোজেন — ডার্মাটোজেন, পেরিব্লেম, প্লেরোম ও ক্যালিপট্রোজেন; মাঝে নিষ্ক্রিয় কেন্দ্র। চাপ দিলে অঞ্চলের নাম দেখাবে।',
  types: {
    shoot: ['কাণ্ডের শীর্ষ', 'কাণ্ডের শীর্ষ — টিউনিকা-কর্পাস মতবাদ', 'গম্বুজের মতো শীর্ষে বাইরের 1–2 স্তর টিউনিকা (অ্যান্টিক্লাইনাল বিভাজন, ফলে স্তর অটুট থেকে পৃষ্ঠ বাড়ে; L1 থেকে ত্বক), ভেতরে কর্পাস (সব তলে বিভাজন, আয়তন বৃদ্ধি)। দুই পাশে পত্রপ্রিমর্ডিয়াম; নিচে প্রোক্যাম্বিয়াম ও রিব মেরিস্টেম।'],
    root: ['মূলের শীর্ষ', 'মূলের শীর্ষ — হিস্টোজেন মতবাদ', 'ডার্মাটোজেন → ত্বক (এপিব্লেমা); পেরিব্লেম → কর্টেক্স; প্লেরোম → স্টিলি (ভাস্কুলার সিলিন্ডার); ক্যালিপট্রোজেন → মূলত্র (রুট ক্যাপ)। প্লেরোম ও মূলত্রের মাঝে ধীরে বিভাজিত কোষের নিষ্ক্রিয় কেন্দ্র (ক্লোজ, 1956) — ক্ষতিগ্রস্ত হলে নতুন কোষ জোগায়।']
  },
  def: 'shoot',
  art(g, C, ty, ctx) {
    const M = BK.ramp(6), Gr = BK.ramp(10), Ep = BK.ramp(0), Pv = BK.ramp(3);
    if (ty === 'shoot') {
      /* পত্রপ্রিমর্ডিয়াম */
      [-1, 1].forEach(s => E('path', { d: `M${AXc + s * 70} ${AYc - 20}q${s * 30} -6 ${s * 46} 30q${-s * 14} 10 ${-s * 30} 26Z`, fill: FK.alpha(Gr.c, .35), stroke: Gr.dk, 'stroke-width': 1 }, g));
      E('path', { d: `M${AXc - AR} ${AYc}A${AR} ${AR} 0 0 1 ${AXc + AR} ${AYc}L${AXc + AR - 10} 290H${AXc - AR + 10}Z`, fill: FK.alpha(M.c, .1), stroke: M.dk, 'stroke-width': 1.2 }, g);
      tunicaCells(0, 16).forEach(c => B8.ringCells(g, AXc, AYc, c[1], c[0], 1, { a0: c[2], a1: c[3], fill: FK.alpha(Ep.c, .45), stroke: Ep.dk, sw: .8 }));
      tunicaCells(1, 14).forEach(c => B8.ringCells(g, AXc, AYc, c[1], c[0], 1, { a0: c[2], a1: c[3], fill: FK.alpha(Ep.c, .22), stroke: Ep.dk, sw: .8 }));
      CORP.forEach(([x, y], i) => B8.blob(g, x, y, 6.8, { fill: FK.alpha(M.c, .3), stroke: M.dk, sw: .7, seed: i, j: .25 }));
      [-1, 1].forEach(s => { for (let k = 0; k < 6; k++) E('rect', { x: AXc + s * 40 - 5, y: AYc + 8 + k * 21, width: 10, height: 19, rx: 2, fill: FK.alpha(Gr.c, .45), stroke: Gr.dk, 'stroke-width': .7 }, g); });
      for (let k = 0; k < 6; k++) for (let j = -1; j <= 1; j++) E('rect', { x: AXc + j * 14 - 6, y: AYc + 10 + k * 21, width: 12, height: 19, rx: 2, fill: FK.alpha(BK.ramp(11).c, .2), stroke: BK.ramp(11).dk, 'stroke-width': .6 }, g);
      B8.lab(g, AXc - 24, AYc - AR + 4, 60, 40, 'টিউনিকা L1', C); B8.lab(g, AXc + 26, AYc - AR + 13, 300, 40, 'টিউনিকা L2', C);
      B8.lab(g, AXc + 18, AYc - 30, 300, 110, 'কর্পাস', C); B8.lab(g, AXc - 100, AYc + 10, 30, 120, 'পত্রপ্রিমর্ডিয়াম', C, { a: 'start' });
      B8.lab(g, AXc - 40, AYc + 70, 30, 240, 'প্রোক্যাম্বিয়াম', C, { a: 'start' }); B8.lab(g, AXc + 14, AYc + 90, 300, 260, 'রিব মেরিস্টেম', C);
    } else {
      const top = 14, bot = 222, w = 64;
      E('path', { d: `M${AXc - w} ${top}V${bot}Q${AXc - w} ${bot + 52} ${AXc} ${bot + 56}Q${AXc + w} ${bot + 52} ${AXc + w} ${bot}V${top}Z`, fill: FK.alpha(M.c, .06), stroke: M.dk, 'stroke-width': 1 }, g);
      for (let y = top; y < bot - 12; y += 14) { E('rect', { x: AXc - w, y, width: 8, height: 14, fill: FK.alpha(Ep.c, .45), stroke: Ep.dk, 'stroke-width': .6 }, g); E('rect', { x: AXc + w - 8, y, width: 8, height: 14, fill: FK.alpha(Ep.c, .45), stroke: Ep.dk, 'stroke-width': .6 }, g); }
      for (let y = top; y < bot - 26; y += 13) for (let j = 0; j < 3; j++) { [-1, 1].forEach(s => E('rect', { x: s < 0 ? AXc - w + 8 + j * 10 : AXc + w - 18 - j * 10, y, width: 10, height: 13, fill: FK.alpha(Pv.c, .28), stroke: Pv.dk, 'stroke-width': .6 }, g)); }
      for (let y = top; y < bot - 34; y += 12) for (let j = -2; j < 2; j++) E('rect', { x: AXc + j * 13, y, width: 13, height: 12, fill: FK.alpha(Gr.c, .32), stroke: Gr.dk, 'stroke-width': .6 }, g);
      E('rect', { x: AXc - 24, y: bot - 32, width: 48, height: 16, rx: 6, fill: FK.alpha(C.fg, .14), stroke: C.mu, 'stroke-width': .8, 'stroke-dasharray': '2 2' }, g);
      for (let j = -3; j < 3; j++) E('rect', { x: AXc + j * 16, y: bot - 14, width: 16, height: 10, fill: FK.alpha(M.c, .5), stroke: M.dk, 'stroke-width': .6 }, g);
      for (let L = 0; L < 4; L++) { const y = bot - 2 + L * 12, hw = w - 6 - L * L * 4; for (let x = AXc - hw; x < AXc + hw - 4; x += 16) E('rect', { x, y, width: Math.min(16, AXc + hw - x), height: 12, rx: 3, fill: FK.alpha(BK.ramp(2).c, .3 - L * .04), stroke: BK.ramp(2).dk, 'stroke-width': .6 }, g); }
      B8.lab(g, AXc - w + 4, 60, 40, 46, 'ডার্মাটোজেন', C, { a: 'end' }); B8.lab(g, AXc - w + 20, 110, 40, 104, 'পেরিব্লেম', C, { a: 'end' });
      B8.lab(g, AXc + 10, 80, 300, 70, 'প্লেরোম', C); B8.lab(g, AXc + 20, bot - 24, 300, 160, 'নিষ্ক্রিয় কেন্দ্র', C);
      B8.lab(g, AXc - 30, bot - 9, 40, 214, 'ক্যালিপট্রোজেন', C, { a: 'end' }); B8.lab(g, AXc + 30, bot + 24, 300, 252, 'মূলত্র', C);
    }
  },
  tap(x, y, ty) {
    if (ty === 'shoot') { const r = Math.hypot(x - AXc, y - AYc); if (y < AYc && r < AR && r > AR - 8) return '<b>টিউনিকা L1</b> — সবচেয়ে বাইরের স্তর; কেবল অ্যান্টিক্লাইনাল (পৃষ্ঠের সাথে লম্ব) বিভাজন; এ থেকে ত্বক (এপিডার্মিস) তৈরি হয়।'; if (y < AYc && r <= AR - 8 && r > AR - 16) return '<b>টিউনিকা L2</b> — দ্বিতীয় স্তর; অ্যান্টিক্লাইনাল বিভাজন; পাতার মেসোফিল ও জননকোষের উৎস।'; if (y < AYc + 6 && r < AR - 16) return '<b>কর্পাস (L3)</b> — ভেতরের কোষপিণ্ড; সব তলে বিভাজন; আয়তন বাড়ায়; ভাস্কুলার টিস্যু ও মজ্জার উৎস।'; if (Math.abs(Math.abs(x - AXc) - 40) < 8 && y > AYc) return '<b>প্রোক্যাম্বিয়াম</b> — লম্বা সরু কোষের সারি; প্রাথমিক জাইলেম ও ফ্লোয়েম তৈরি করে।'; if (Math.abs(x - AXc) < 24 && y > AYc) return '<b>রিব মেরিস্টেম</b> — কোষের লম্বা সারি; মজ্জা (পিথ) তৈরি করে।'; if (Math.abs(x - AXc) > 66 && y < AYc + 40) return '<b>পত্রপ্রিমর্ডিয়াম</b> — শীর্ষের পাশ থেকে বের হওয়া কচি পাতার সূচনা।'; return null; }
    if (Math.abs(x - AXc) > 54 && y < 210) return '<b>ডার্মাটোজেন</b> — সবচেয়ে বাইরের এক স্তর; মূলের ত্বক (এপিব্লেমা বা রাইজোডার্মিস) তৈরি করে।';
    if (Math.abs(x - AXc) > 26 && y < 190) return '<b>পেরিব্লেম</b> — মাঝের বহুস্তর; কর্টেক্স তৈরি করে (এন্ডোডার্মিসও এর অংশ)।';
    if (y < 188) return '<b>প্লেরোম</b> — কেন্দ্রীয় স্তম্ভ; স্টিলি — পেরিসাইকল, জাইলেম, ফ্লোয়েম, মজ্জা — তৈরি করে।';
    if (y < 208) return '<b>নিষ্ক্রিয় কেন্দ্র</b> — ধীরে বিভাজিত কোষের অঞ্চল; চারপাশের ভাজক কোষ নষ্ট হলে নতুন কোষ জোগায় (ক্লোজ, 1956)।';
    if (y < 222) return '<b>ক্যালিপট্রোজেন</b> — মূলত্র তৈরির ভাজক স্তর (একবীজপত্রীতে স্পষ্ট)।';
    return '<b>মূলত্র (রুট ক্যাপ)</b> — অগ্রভাগকে রক্ষা করে; বাইরের কোষ ঝরে পড়ে, পিচ্ছিল মিউসিলেজ মাটিতে চলতে সাহায্য করে; স্ট্যাটোলিথ দিয়ে অভিকর্ষ অনুভব করে।';
  },
  anim(g, C, ty, t) {
    const M = BK.ramp(6);
    if (ty === 'shoot') {
      const c = tunicaCells(0, 16)[Math.floor(t * 1.5) % 16], am = (c[2] + c[3]) / 2; E('path', { d: `M${(AXc + c[1] * Math.cos(am)).toFixed(1)} ${(AYc + c[1] * Math.sin(am)).toFixed(1)}L${(AXc + c[0] * Math.cos(am)).toFixed(1)} ${(AYc + c[0] * Math.sin(am)).toFixed(1)}`, stroke: M.dk, 'stroke-width': 2.2 }, g);
      const i = Math.floor(t * 1.5 * 7) % CORP.length, [x, y] = CORP[i], o = rnd(i + 7) * Math.PI;
      E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 8, fill: 'none', stroke: M.c, 'stroke-width': 2 }, g); E('path', { d: `M${(x - 7 * Math.cos(o)).toFixed(1)} ${(y - 7 * Math.sin(o)).toFixed(1)}L${(x + 7 * Math.cos(o)).toFixed(1)} ${(y + 7 * Math.sin(o)).toFixed(1)}`, stroke: M.dk, 'stroke-width': 2 }, g);
      T(g, 180, 16, 'টিউনিকা: অ্যান্টিক্লাইনাল · কর্পাস: যেকোনো তলে', { fs: 10.5, a: 'middle', c: M.ink, w: 600 });
    } else {
      const f = (t % 3) / 3, R = BK.ramp(2), y = 266 + f * 22; [-1, 1].forEach(s => E('rect', { x: AXc + s * 20 - 8, y, width: 16, height: 10, rx: 3, fill: FK.alpha(R.c, .5 * (1 - f)), stroke: FK.alpha(R.dk, 1 - f), 'stroke-width': .7 }, g));
      B8.arr(g, AXc + 84, 230 + f * 18, AXc + 84, 250 + f * 18, M.dk, 2); T(g, AXc + 90, 286, 'বৃদ্ধি', { fs: 10, c: M.ink, w: 600 });
      const k = Math.floor(t * 2) % 4; E('rect', { x: AXc - 26 + k * 13, y: 186, width: 13, height: 12, fill: 'none', stroke: M.dk, 'stroke-width': 2 }, g);
    }
  }
});

/* ───────── বিভাজন তল ───────── */
const DPdims = { mass: [[1, 1, 1], [2, 1, 1], [2, 2, 1], [2, 2, 2], [3, 2, 2]], plate: [[1, 1, 1], [2, 1, 1], [2, 2, 1], [3, 2, 1], [3, 3, 1]], rib: [[1, 1, 1], [2, 1, 1], [3, 1, 1], [4, 1, 1], [6, 1, 1]] };
V.divPlane = B8.seg({
  id: 'dp', t: 'বিভাজন তল অনুযায়ী ভাজক টিস্যু', H: 240,
  types: {
    mass: ['পুঞ্জ', 'পুঞ্জ ভাজক টিস্যু (মাস মেরিস্টেম)', 'কোষ সব তলে বিভাজিত হয় — তিন দিকেই আয়তন বাড়ে, গোল বা ঘন কোষপিণ্ড তৈরি হয়।', 'সস্য, বিকাশমান ভ্রূণ, রেণুস্থলী (স্পোরাঞ্জিয়াম) গঠনের সময়'],
    plate: ['পাত', 'পাত ভাজক টিস্যু (প্লেট মেরিস্টেম)', 'কোষ কেবল দুই তলে (অ্যান্টিক্লাইনাল) বিভাজিত হয় — পুরুত্ব না বেড়ে দৈর্ঘ্য-প্রস্থে চ্যাপ্টা স্তর বাড়ে।', 'পাতার ফলক, ত্বক (এপিডার্মিস)'],
    rib: ['সারি', 'সারি ভাজক টিস্যু (রিব বা ফাইল মেরিস্টেম)', 'কোষ কেবল এক তলে (অক্ষের সাথে লম্বভাবে) বিভাজিত হয় — এক সারি কোষ লম্বা হয়।', 'মূল ও কাণ্ডের কর্টেক্স ও মজ্জার কোষসারি']
  },
  def: 'mass',
  art(g, C, ty) { T(g, 180, 222, ty === 'mass' ? 'তিন দিকে বৃদ্ধি' : ty === 'plate' ? 'দুই দিকে বৃদ্ধি — পুরুত্ব এক কোষ' : 'এক দিকে বৃদ্ধি — এক সারি', { fs: 12, a: 'middle', w: 600, c: C.mu }); },
  anim(g, C, ty, t) {
    const R = BK.ramp(6), gen = Math.floor(t / 1.4) % 5, [a, b, c] = DPdims[ty][gen], prev = DPdims[ty][Math.max(0, gen - 1)], s = ty === 'rib' ? 24 : 26, w = s * .866, h = s * .5;
    const ox = 180 - (a - b) * w / 2, oy = 110 - c * s / 2 - (a + b) * h / 2 + 30;
    const L = []; for (let k = 0; k < c; k++) for (let j = 0; j < b; j++) for (let i = 0; i < a; i++) L.push([i, j, k]);
    L.sort((p, q) => (p[0] + p[1] + p[2]) - (q[0] + q[1] + q[2]) || p[2] - q[2]);
    L.forEach(([i, j, k]) => { const x = ox + (i - j) * w, y = oy + (i + j) * h + (c - 1 - k) * s; const nw = gen > 0 && (i >= prev[0] || j >= prev[1] || k >= prev[2]); B8.cube(g, x - w, y, s, R, nw); });
    T(g, 180, 26, `বিভাজনের পর: ${bn(a * b * c)} টি কোষ`, { fs: 12, a: 'middle', w: 650, c: R.ink });
    if (gen === 0 && t > .5) T(g, 180, 44, '(শুরু: একটি কোষ)', { fs: 10.5, a: 'middle', c: C.mu });
  }
});

/* ───────── সরল স্থায়ী টিস্যু ───────── */
const ST = {
  paren: ['প্যারেনকাইমা', 'প্যারেনকাইমা', 'জীবিত; পাতলা সেলুলোজ প্রাচীর; প্রায় সমব্যাসীয় বা ডিম্বাকার; আন্তঃকোষীয় ফাঁক থাকে; কাজ — খাদ্য তৈরি (ক্লোরেনকাইমা), খাদ্য ও পানি সঞ্চয়, প্রয়োজনে আবার ভাজক হতে পারে (ক্ষত সারানো, কর্ক ক্যাম্বিয়াম)।', 'কর্টেক্স, মজ্জা, পাতার মেসোফিল, ফলের শাঁস'],
  aeren: ['অ্যারেনকাইমা', 'অ্যারেনকাইমা (বায়ুকুঠুরিযুক্ত প্যারেনকাইমা)', 'বড় বায়ুকুঠুরি ঘিরে প্যারেনকাইমা কোষ — জলজ উদ্ভিদকে ভাসতে ও নিমজ্জিত অংশে অক্সিজেন পৌঁছাতে সাহায্য করে।', 'শাপলা ও পদ্মের বৃন্ত, কচুরিপানার ফোলা বৃন্ত, ধানের মূল'],
  colen: ['কোলেনকাইমা', 'কোলেনকাইমা', 'জীবিত; কোষের কোণে কোণে সেলুলোজ ও পেকটিন জমে প্রাচীর পুরু; লম্বাটে; ফাঁক কম; কাজ — নমনীয় দৃঢ়তা (বাতাসে বাঁকে কিন্তু ভাঙে না), কখনো সালোকসংশ্লেষণ। ধরন: কৌণিক, স্তরীভূত (ল্যামেলার), ফাঁকযুক্ত (ল্যাকুনার)।', 'দ্বিবীজপত্রী বীরুৎ কাণ্ডের হাইপোডার্মিস (সূর্যমুখী, কুমড়া), পত্রবৃন্ত; একবীজপত্রী ও মূলে সাধারণত থাকে না'],
  fibre: ['ফাইবার', 'স্ক্লেরেনকাইমা — ফাইবার (তন্তু)', 'মৃত; লিগনিনযুক্ত খুব পুরু প্রাচীর, সরু লুমেন; দুই প্রান্ত সূচালো, লম্বা; সরল কূপ; কাজ — যান্ত্রিক শক্তি ও দৃঢ়তা।', 'পাট, শণ, নারিকেলের ছোবড়া; কাণ্ডের বান্ডল ক্যাপ'],
  scler: ['স্ক্লেরাইড', 'স্ক্লেরেনকাইমা — স্ক্লেরাইড (পাথর কোষ)', 'মৃত; প্রায় সমব্যাসীয় বা অনিয়মিত; স্তরে স্তরে লিগনিন জমে খুব পুরু প্রাচীর, শাখান্বিত কূপনালি; কাজ — শক্ত আবরণ।', 'নাশপাতি ও পেয়ারার দানাদার শাঁস, নারিকেলের মালা, বীজত্বক']
};
V.simpleTissue = B8.seg({
  id: 'sm', t: 'সরল স্থায়ী টিস্যু', H: 250, types: ST, def: 'paren',
  cap: 'একই রকম কোষে গঠিত স্থায়ী টিস্যু। বামে প্রস্থচ্ছেদ, ডানে লম্বচ্ছেদ। লাল রং = লিগনিনযুক্ত মৃত প্রাচীর (স্যাফ্রানিনে লাল হয়)। চালু করলে প্রতিটির বিশেষ বৈশিষ্ট্য অ্যানিমেশনে দেখায়।',
  art(g, C, ty, ctx) {
    const Pp = BK.ramp(10), Wl = BK.ramp(11), L = BK.ramp(4), Co = BK.ramp(5), N = BK.ramp(3);
    T(g, 96, 20, 'প্রস্থচ্ছেদ', { fs: 11, a: 'middle', c: C.mu, w: 600 }); T(g, 268, 20, 'লম্বচ্ছেদ', { fs: 11, a: 'middle', c: C.mu, w: 600 });
    E('path', { d: 'M184 28V232', stroke: C.ln, 'stroke-width': 1, 'stroke-dasharray': '3 3' }, g);
    ctx.cells = [];
    if (ty === 'paren' || ty === 'colen' || ty === 'fibre') {
      for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
        const x = 30 + c * 33 + (r % 2) * 16, y = 46 + r * 34, rr = ty === 'paren' ? 15 : 17.5, seed = r * 7 + c;
        if (x > 176) continue;
        if (ty === 'paren') { B8.blob(g, x, y, rr, { fill: FK.alpha(Pp.c, .18), stroke: Wl.dk, sw: 1.1, seed, n: 7, j: .14 }); E('circle', { cx: x + 6, cy: y - 5, r: 3, fill: FK.alpha(N.c, .7) }, g); ctx.cells.push([x, y]); }
        else if (ty === 'colen') { B8.blob(g, x, y, rr, { fill: FK.alpha(Co.c, .14), stroke: Co.dk, sw: 1, seed, n: 6, j: .1, rot: .5 }); for (let k = 0; k < 6; k++) { const a = .5 + k * Math.PI / 3; E('circle', { cx: (x + rr * Math.cos(a)).toFixed(1), cy: (y + rr * Math.sin(a)).toFixed(1), r: 4.2, fill: FK.alpha(Co.c, .75) }, g); } E('circle', { cx: x, cy: y, r: 3, fill: FK.alpha(N.c, .7) }, g); }
        else { B8.blob(g, x, y, rr - 2, { fill: FK.alpha(L.c, .55), stroke: L.dk, sw: 1, seed, n: 6, j: .12, rot: .5 }); B8.blob(g, x, y, 3.5, { fill: C.sf, stroke: L.dk, sw: .6, seed: seed + 9, n: 5 }); }
      }
    }
    if (ty === 'aeren') {
      [[74, 84, 30], [134, 150, 28], [62, 182, 22]].forEach(([x, y, r], i) => { E('circle', { cx: x, cy: y, r, fill: FK.alpha(BK.ramp(5).c, .1) }, g); const n = Math.round(2 * Math.PI * (r + 8) / 15); for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2; B8.blob(g, x + (r + 7) * Math.cos(a), y + (r + 7) * Math.sin(a), 7.5, { fill: FK.alpha(Pp.c, .28), stroke: Wl.dk, sw: .8, seed: i * 50 + k, n: 6 }); } });
      ctx.air = [[74, 84, 30], [134, 150, 28], [62, 182, 22]];
      T(g, 96, 230, 'বড় বায়ুকুঠুরি', { fs: 11, a: 'middle', c: BK.ramp(5).ink, w: 600 });
    }
    if (ty === 'scler') {
      for (let k = 0; k < 4; k++) { const x = 58 + (k % 2) * 72, y = 82 + Math.floor(k / 2) * 84; for (let l = 0; l < 5; l++) B8.blob(g, x, y, 32 - l * 4.6, { fill: l === 0 ? FK.alpha(L.c, .25) : 'none', stroke: L.dk, sw: l === 0 ? 1.4 : .6, seed: k * 9 + l, n: 8, j: .08 }); E('circle', { cx: x, cy: y, r: 6, fill: C.sf, stroke: L.dk }, g); for (let m = 0; m < 7; m++) { const a = m / 7 * Math.PI * 2 + k; E('path', { d: `M${(x + 6 * Math.cos(a)).toFixed(1)} ${(y + 6 * Math.sin(a)).toFixed(1)}L${(x + 18 * Math.cos(a)).toFixed(1)} ${(y + 18 * Math.sin(a)).toFixed(1)}l${(5 * Math.cos(a + .6)).toFixed(1)} ${(5 * Math.sin(a + .6)).toFixed(1)}M${(x + 18 * Math.cos(a)).toFixed(1)} ${(y + 18 * Math.sin(a)).toFixed(1)}L${(x + 27 * Math.cos(a - .1)).toFixed(1)} ${(y + 27 * Math.sin(a - .1)).toFixed(1)}`, stroke: C.sf, 'stroke-width': 1.6, fill: 'none' }, g); } }
      ctx.scl = true;
    }
    /* লম্বচ্ছেদ */
    if (ty === 'paren' || ty === 'aeren') { for (let r = 0; r < 5; r++) for (let c = 0; c < 4; c++) { const x = 198 + c * 38 + (r % 2) * 8, y = 34 + r * 38; if (x + 34 > 352) continue; E('rect', { x, y, width: 34, height: 34, rx: 9, fill: FK.alpha(Pp.c, .18), stroke: Wl.dk, 'stroke-width': 1 }, g); E('circle', { cx: x + 26, cy: y + 9, r: 3, fill: FK.alpha(N.c, .7) }, g); } }
    if (ty === 'colen') { ctx.colLS = true; }
    if (ty === 'fibre') { for (let k = 0; k < 6; k++) { const x = 204 + k * 24, y0 = 34 + (k % 2) * 30; E('path', { d: `M${x} ${y0}Q${x + 10} ${y0 + 90} ${x} ${y0 + 180}Q${x - 10} ${y0 + 90} ${x} ${y0}Z`, fill: FK.alpha(L.c, .5), stroke: L.dk, 'stroke-width': 1 }, g); E('path', { d: `M${x} ${y0 + 14}V${y0 + 166}`, stroke: C.sf, 'stroke-width': 1.4 }, g); for (let p = 0; p < 6; p++) E('path', { d: `M${x - 4} ${y0 + 30 + p * 24}l3 -3`, stroke: L.dk, 'stroke-width': .9 }, g); } }
    if (ty === 'scler') { for (let k = 0; k < 6; k++) { const x = 216 + (k % 3) * 44, y = 62 + Math.floor(k / 3) * 90; B8.blob(g, x, y, 22, { fill: FK.alpha(L.c, .35), stroke: L.dk, sw: 1.2, seed: k + 30, n: 7, j: .3 }); E('circle', { cx: x, cy: y, r: 4, fill: C.sf, stroke: L.dk }, g); for (let m = 0; m < 5; m++) { const a = m / 5 * Math.PI * 2 + k; E('path', { d: `M${(x + 4 * Math.cos(a)).toFixed(1)} ${(y + 4 * Math.sin(a)).toFixed(1)}L${(x + 19 * Math.cos(a)).toFixed(1)} ${(y + 19 * Math.sin(a)).toFixed(1)}`, stroke: C.sf, 'stroke-width': 1.3 }, g); } } T(g, 268, 230, 'পাথর কোষ (ব্র্যাকিস্ক্লেরাইড)', { fs: 10.5, a: 'middle', c: L.ink, w: 600 }); }
  },
  anim(g, C, ty, t, ctx) {
    const Pp = BK.ramp(10), Co = BK.ramp(5), L = BK.ramp(4), N = BK.ramp(3);
    if (ty === 'paren') ctx.cells.forEach(([x, y], i) => { const a = t * 1.6 + i; E('circle', { cx: (x + 10 * Math.cos(a)).toFixed(1), cy: (y + 10 * Math.sin(a)).toFixed(1), r: 1.8, fill: Pp.dk }, g); });
    if (ty === 'aeren') ctx.air.forEach(([x, y, r], i) => { for (let k = 0; k < 3; k++) { const f = ((t * .35 + k / 3 + i * .2) % 1), yy = y + r * .8 - f * r * 1.6, xx = x + Math.sin(f * 9 + k) * r * .35; E('circle', { cx: xx.toFixed(1), cy: yy.toFixed(1), r: 2.5 + k, fill: 'none', stroke: FK.alpha(Co.dk, 1 - Math.abs(f - .5)), 'stroke-width': 1 }, g); } });
    if (ty === 'colen') { const sw = 10 * Math.sin(t * 2); for (let k = 0; k < 5; k++) { const x = 204 + k * 28, d = `M${x} 34Q${x + sw} 130 ${x + sw * 1.6} 226`; E('path', { d, stroke: FK.alpha(Co.c, .2), 'stroke-width': 26, fill: 'none' }, g); E('path', { d: `M${x - 12} 34Q${x - 12 + sw} 130 ${x - 12 + sw * 1.6} 226M${x + 12} 34Q${x + 12 + sw} 130 ${x + 12 + sw * 1.6} 226`, stroke: Co.dk, 'stroke-width': 3, fill: 'none' }, g); for (let j = 0; j < 4; j++) { const y = 60 + j * 46, xo = sw * ((y - 34) / 192) * (1 + .6 * (y - 34) / 192) * .7; E('path', { d: `M${(x - 12 + xo).toFixed(1)} ${y}h24`, stroke: Co.dk, 'stroke-width': .8 }, g); E('circle', { cx: (x + xo).toFixed(1), cy: y + 20, r: 2.6, fill: FK.alpha(N.c, .7) }, g); } } T(g, 268, 242, 'বাতাসে বাঁকে, ভাঙে না', { fs: 10.5, a: 'middle', c: Co.ink, w: 600 }); }
    if (ty === 'fibre') { const y = 34 + ((t * 60) % 210); E('rect', { x: 192, y: y - 6, width: 156, height: 12, fill: FK.alpha('#fff', .35) }, g); }
    if (ty === 'scler') { const k = Math.floor(t) % 4, x = 58 + (k % 2) * 72, y = 82 + Math.floor(k / 2) * 84, l = Math.floor(t * 5) % 5; B8.blob(g, x, y, 32 - l * 4.6, { stroke: L.dk, sw: 2.4, seed: k * 9 + l, n: 8, j: .08 }); T(g, 96, 240, 'স্তরে স্তরে লিগনিন জমা', { fs: 10.5, a: 'middle', c: L.ink, w: 600 }); }
  }
});

/* ───────── জাইলেমের উপাদান ───────── */
const XE = {
  trach: ['ট্র্যাকিড', 'ট্র্যাকিড', 'মৃত, লম্বা, দুই প্রান্ত সরু ও তির্যক; প্রাচীর লিগনিনযুক্ত; প্রান্তপ্রাচীরে ছিদ্র নেই — পানি এক ট্র্যাকিড থেকে আরেকটিতে যায় পাড়যুক্ত কূপ (বর্ডারড পিট) দিয়ে। সব ভাস্কুলার উদ্ভিদে থাকে; নগ্নবীজী ও টেরিডোফাইটে প্রধান পরিবাহী উপাদান।', 'Pinus এর কাঠ'],
  vessel: ['ভেসেল', 'ভেসেল (ট্রাকিয়া)', 'মৃত; ছোট-চওড়া ভেসেল সদস্য একটির উপর আরেকটি বসে লম্বা নল; মাঝের প্রান্তপ্রাচীর গলে ছিদ্রপ্লেট (পারফোরেশন প্লেট) — তাই পানি অবিরাম স্তম্ভে দ্রুত ওঠে। আবৃতবীজীর বৈশিষ্ট্য (নগ্নবীজীর মধ্যে কেবল Gnetales এ)।', 'আম, জবা, ধান'],
  xfib: ['জাইলেম ফাইবার', 'জাইলেম ফাইবার', 'মৃত, লম্বা, সূচালো প্রান্ত, খুব পুরু লিগনিনযুক্ত প্রাচীর ও সরু লুমেন; কাজ — যান্ত্রিক শক্তি।', 'কাঠের দৃঢ়তা'],
  xpar: ['জাইলেম প্যারেনকাইমা', 'জাইলেম প্যারেনকাইমা', 'জাইলেমের একমাত্র জীবিত উপাদান; পাতলা প্রাচীর; শ্বেতসার, চর্বি, ট্যানিন সঞ্চয় করে; মজ্জারশ্মিতে পানি পার্শ্বীয়ভাবে পরিবহন করে।', 'কাঠের মজ্জারশ্মি']
};
V.xylemEl = B8.seg({
  id: 'xe', t: 'জাইলেমের উপাদান ও পানি পরিবহন', H: 260, types: XE, def: 'vessel',
  cap: 'জাইলেম একটি জটিল টিস্যু — চার ধরনের কোষ। লাল = লিগনিনযুক্ত মৃত প্রাচীর। চালু করলে পানির কণা (নীল) চলাচল দেখায়: ট্র্যাকিডে কূপ দিয়ে এঁকেবেঁকে, ভেসেলে ছিদ্রপ্লেট দিয়ে সোজা উপরে।',
  art(g, C, ty, ctx) {
    const L = BK.ramp(4), N = BK.ramp(3), P = BK.ramp(11);
    if (ty === 'trach') { ctx.tr = []; for (let k = 0; k < 4; k++) { const x = 80 + k * 52, y0 = 40 + (k % 2) * 56, y1 = y0 + 150; E('path', { d: `M${x} ${y0}L${x + 22} ${y0 + 26}V${y1}L${x} ${y1 + 26}L${x - 22} ${y1}V${y0 + 26}Z`, fill: FK.alpha(L.c, .12), stroke: L.dk, 'stroke-width': 2 }, g); for (let p = 0; p < 7; p++) { [-1, 1].forEach(s => { const yy = y0 + 40 + p * 18; E('ellipse', { cx: x + s * 15, cy: yy, rx: 4, ry: 6, fill: 'none', stroke: L.dk, 'stroke-width': .9 }, g); E('circle', { cx: x + s * 15, cy: yy, r: 1.3, fill: L.dk }, g); }); } ctx.tr.push([x, y0, y1]); } T(g, 180, 250, 'তির্যক সরু প্রান্ত · পাড়যুক্ত কূপ', { fs: 11, a: 'middle', c: L.ink, w: 600 }); }
    if (ty === 'vessel') { for (let k = 0; k < 4; k++) { const y = 26 + k * 52; E('path', { d: `M140 ${y}Q132 ${y + 26} 140 ${y + 52}H220Q228 ${y + 26} 220 ${y}Z`, fill: FK.alpha(L.c, .1), stroke: L.dk, 'stroke-width': 2 }, g); for (let s = 0; s < 4; s++) E('path', { d: `M${140 + s * 0} ${y + 8 + s * 12}Q180 ${y + 2 + s * 12} 220 ${y + 8 + s * 12}`, stroke: FK.alpha(L.dk, .6), 'stroke-width': 1.6, fill: 'none' }, g); if (k) { E('path', { d: `M140 ${y}h18M202 ${y}h18`, stroke: L.dk, 'stroke-width': 3 }, g); } } B8.lab(g, 158, 78, 262, 70, 'ছিদ্রপ্লেট', C); B8.lab(g, 222, 140, 262, 150, 'সর্পিল স্থূলীকরণ', C); B8.lab(g, 138, 170, 70, 180, 'ভেসেল সদস্য', C); T(g, 180, 250, 'প্রান্তপ্রাচীর নেই — অবিচ্ছিন্ন নল', { fs: 11, a: 'middle', c: L.ink, w: 600 }); }
    if (ty === 'xfib') { for (let k = 0; k < 6; k++) { const x = 100 + k * 32, y0 = 30 + (k % 2) * 24; E('path', { d: `M${x} ${y0}Q${x + 12} ${y0 + 95} ${x} ${y0 + 190}Q${x - 12} ${y0 + 95} ${x} ${y0}Z`, fill: FK.alpha(L.c, .55), stroke: L.dk, 'stroke-width': 1 }, g); E('path', { d: `M${x} ${y0 + 20}V${y0 + 170}`, stroke: C.sf, 'stroke-width': 1.4 }, g); } T(g, 180, 250, 'খুব পুরু প্রাচীর, সরু লুমেন', { fs: 11, a: 'middle', c: L.ink, w: 600 }); }
    if (ty === 'xpar') { ctx.st = []; for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) { const x = 72 + c * 56, y = 36 + r * 62; E('rect', { x, y, width: 52, height: 56, rx: 4, fill: FK.alpha(P.c, .2), stroke: P.dk, 'stroke-width': 1.2 }, g); E('circle', { cx: x + 12, cy: y + 14, r: 5, fill: FK.alpha(N.c, .7), stroke: N.dk }, g); ctx.st.push([x, y]); } E('rect', { x: 44, y: 36, width: 22, height: 180, fill: FK.alpha(L.c, .15), stroke: L.dk, 'stroke-width': 2 }, g); T(g, 55, 230, 'ভেসেল', { fs: 10, a: 'middle', c: L.ink }); T(g, 210, 238, 'জীবিত — শ্বেতসার কণা সঞ্চয়', { fs: 11, a: 'middle', c: P.ink, w: 600 }); }
  },
  anim(g, C, ty, t, ctx) {
    const W = BK.ramp(5);
    if (ty === 'vessel') for (let k = 0; k < 14; k++) { const y = 230 - ((t * 60 + k * 15) % 210), x = 180 + 22 * Math.sin(k * 2.1); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 3, fill: W.c }, g); }
    if (ty === 'trach') ctx.tr.forEach(([x, y0, y1], k) => { for (let j = 0; j < 4; j++) { const f = ((t * .4 + j / 4 + k * .13) % 1); const y = y1 + 10 - f * (y1 - y0); const zig = Math.sin(f * 30) > 0 ? 1 : -1; E('circle', { cx: (x + zig * 9 * Math.min(1, f * 4)).toFixed(1), cy: y.toFixed(1), r: 2.8, fill: W.c }, g); } if (k < 3) { const f = (t * .8 + k * .3) % 1; E('circle', { cx: (x + 15 + f * 22).toFixed(1), cy: (y0 + 80 + (k % 2 ? -1 : 1) * 10).toFixed(1), r: 2.4, fill: W.dk }, g); } });
    if (ty === 'xfib') { const y = 30 + ((t * 60) % 220); E('rect', { x: 80, y: y - 6, width: 200, height: 12, fill: FK.alpha('#fff', .35) }, g); }
    if (ty === 'xpar') { ctx.st.forEach(([x, y], i) => { for (let k = 0; k < 3; k++) E('ellipse', { cx: (x + 28 + 10 * Math.cos(t + i + k * 2)).toFixed(1), cy: (y + 34 + 8 * Math.sin(t * .8 + k * 2 + i)).toFixed(1), rx: 4, ry: 3, fill: FK.alpha(BK.ramp(6).c, .8), stroke: BK.ramp(6).dk, 'stroke-width': .6 }, g); }); const f = (t * .5) % 1; B8.arr(g, 70 + f * 200, 132, 90 + f * 200, 132, W.dk, 2); T(g, 210, 24, 'পার্শ্বীয় পরিবহন →', { fs: 10.5, a: 'middle', c: W.ink, w: 600 }); }
  }
});

/* ───────── প্রাচীরের স্থূলীকরণ ───────── */
const WT = [['বলয়াকার', 'annular', 'আংটির মতো আলাদা আলাদা বলয় — প্রোটোজাইলেমে; অঙ্গ লম্বা হলে বলয় ফাঁক হয়ে প্রসারিত হতে পারে।'], ['সর্পিল', 'spiral', 'স্প্রিংয়ের মতো প্যাঁচানো — প্রোটোজাইলেমে; প্রসারণযোগ্য।'], ['সোপানাকার', 'scalariform', 'মইয়ের ধাপের মতো আড়াআড়ি স্থূলীকরণ — মেটাজাইলেমে।'], ['জালিকাকার', 'reticulate', 'জালের মতো — মেটাজাইলেমে।'], ['কূপযুক্ত', 'pitted', 'প্রায় পুরো প্রাচীর পুরু, মাঝে মাঝে পাতলা অংশ (কূপ) — মেটাজাইলেম; সবচেয়ে শক্ত।']];
V.wallThick = {
  t: 'জাইলেম প্রাচীরের স্থূলীকরণ', k: ['2d', 'anim', 'int'],
  cap: 'ট্র্যাকিড ও ভেসেলের প্রাচীরে লিগনিন পাঁচ নকশায় জমে। প্রথমে তৈরি প্রোটোজাইলেমে বলয়াকার ও সর্পিল (অঙ্গ লম্বা হলেও টেনে লম্বা হতে পারে); পরে তৈরি মেটাজাইলেমে সোপানাকার, জালিকাকার ও কূপযুক্ত। চালু করলে লিগনিন জমা ও অঙ্গের প্রসারণ দেখায়; নলে চাপ দাও।',
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button></div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = 360, H = 262;
    let C, svg, gd, sel = 1, tt = 0;
    const draw = () => {
      gd.innerHTML = ''; const L = BK.ramp(4), ph = tt % 8, dep = tt === 0 ? 1 : Math.min(1, ph / 3), st = ph > 4 ? Math.min(1, (ph - 4) / 2) * (ph < 7 ? 1 : (8 - ph)) : 0;
      WT.forEach((w, i) => {
        const x = 22 + i * 68, wd = 42, stretch = i < 2 ? 1 + .3 * st : 1, y0 = 30, h = 140 * (i < 2 ? stretch : 1), on = i === sel;
        const g = E('g', { 'data-i': i, style: 'cursor:pointer' }, gd);
        E('rect', { x: x - 4, y: y0 - 6, width: wd + 8, height: h + 12, rx: 8, fill: on ? FK.alpha(L.c, .12) : 'transparent', stroke: on ? L.c : 'none' }, g);
        E('path', { d: `M${x} ${y0}V${y0 + h}M${x + wd} ${y0}V${y0 + h}`, stroke: FK.alpha(L.dk, .5), 'stroke-width': 1 }, g);
        const top = y0, bot = y0 + h, lim = top + (bot - top) * dep, sw = 2.4;
        if (i === 0) for (let k = 0; k < 7; k++) { const y = top + 12 + k * 24 * stretch; if (y < lim && y < bot) E('ellipse', { cx: x + wd / 2, cy: y, rx: wd / 2, ry: 4, fill: 'none', stroke: L.dk, 'stroke-width': sw }, g); }
        if (i === 1) { let d = ''; for (let y = top; y < Math.min(lim, bot); y += 2) { const ph2 = (y - top) / (14 * stretch) * Math.PI * 2; d += (d ? 'L' : 'M') + (x + wd / 2 + wd / 2 * Math.sin(ph2)).toFixed(1) + ' ' + y.toFixed(1); } if (d) E('path', { d, stroke: L.dk, 'stroke-width': sw, fill: 'none' }, g); }
        if (i === 2) for (let y = top + 6; y < Math.min(lim, bot); y += 10) E('path', { d: `M${x + 3} ${y}h${wd - 6}`, stroke: L.dk, 'stroke-width': sw }, g);
        if (i === 3) { let d = ''; for (let y = top + 6; y < Math.min(lim, bot) - 10; y += 16) { d += `M${x + 2} ${y}L${x + wd / 2} ${y + 10}L${x + wd - 2} ${y}M${x + 2} ${y + 10}L${x + wd / 2} ${y}L${x + wd - 2} ${y + 10}`; } if (d) E('path', { d, stroke: L.dk, 'stroke-width': 1.8, fill: 'none' }, g); }
        if (i === 4) { E('rect', { x, y: top, width: wd, height: Math.max(0, Math.min(lim, bot) - top), fill: FK.alpha(L.c, .55) }, g); for (let y = top + 10; y < Math.min(lim, bot) - 4; y += 15) for (let j = 0; j < 3; j++) E('ellipse', { cx: x + 8 + j * 13, cy: y + (j % 2) * 6, rx: 3.4, ry: 2.4, fill: C.sf }, g); }
        T(g, x + wd / 2, 252, w[0], { fs: 11, a: 'middle', w: on ? 700 : 550, c: on ? L.ink : C.fg });
      });
      E('path', { d: 'M18 222H148', stroke: BK.ramp(6).c, 'stroke-width': 2 }, gd); E('path', { d: 'M154 222H352', stroke: BK.ramp(3).c, 'stroke-width': 2 }, gd);
      T(gd, 83, 235, 'প্রোটোজাইলেম', { fs: 10, a: 'middle', c: BK.ramp(6).ink, w: 600 }); T(gd, 253, 235, 'মেটাজাইলেম', { fs: 10, a: 'middle', c: BK.ramp(3).ink, w: 600 });
      if (st > .05) T(gd, 83, 18, 'অঙ্গ লম্বা হচ্ছে →', { fs: 10.5, a: 'middle', c: BK.ramp(6).ink, w: 600 });
    };
    const info = () => { const w = WT[sel]; $('info').innerHTML = `<b>${w[0]}</b> <i class="muted">(${w[1]})</i> — ${w[2]}`; };
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': 'জাইলেম প্রাচীরের স্থূলীকরণ' }, $('st')); E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: C.sf }, svg); gd = E('g', {}, svg); draw(); info(); };
    root.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g && svg && svg.contains(g)) { sel = +g.dataset.i; draw(); info(); } });
    const A = X.anim(root, dt => { tt += dt; draw(); }, { paused: true }); X.pp(root, A);
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
};

/* ───────── ফ্লোয়েমের উপাদান ───────── */
V.phloemEl = B8.seg({
  id: 'pe', t: 'ফ্লোয়েমের উপাদান ও খাদ্য পরিবহন', H: 268,
  types: {
    ls: ['লম্বচ্ছেদ', 'ফ্লোয়েম — লম্বচ্ছেদ', 'সিভনল (জীবিত, পরিণত অবস্থায় নিউক্লিয়াস নেই; সিভ প্লেট দিয়ে সদস্যগুলো যুক্ত), সঙ্গীকোষ (ঘন সাইটোপ্লাজম ও বড় নিউক্লিয়াস — সিভনলকে নিয়ন্ত্রণ করে ও খাদ্য তুলে দেয়; কেবল আবৃতবীজীতে), ফ্লোয়েম প্যারেনকাইমা (জীবিত; অধিকাংশ একবীজপত্রীতে নেই) ও ফ্লোয়েম ফাইবার বা বাস্ট (মৃত, একমাত্র মৃত উপাদান)। খাদ্য উৎস (পাতা) থেকে ভোক্তা (মূল, ফল) এর দিকে — উপরে-নিচে দুই দিকেই চলে।'],
    plate: ['সিভ প্লেট', 'সিভ প্লেট — উপর থেকে', 'সিভনল সদস্যের প্রান্তপ্রাচীর চালুনির মতো ছিদ্রময়; ছিদ্র দিয়ে সাইটোপ্লাজম অবিচ্ছিন্ন। আঘাত বা শীতে ছিদ্রের চারপাশে ক্যালোজ (একটি পলিস্যাকারাইড) জমে ছিদ্র বন্ধ হয় — খাদ্য ক্ষরণ রোধ। নগ্নবীজীতে সিভনলের বদলে সিভকোষ ও সঙ্গীকোষের বদলে অ্যালবুমিনাস কোষ।']
  },
  def: 'ls',
  art(g, C, ty, ctx) {
    const Gp = BK.ramp(10), N = BK.ramp(3), L = BK.ramp(4), P = BK.ramp(11);
    if (ty === 'ls') {
      const y0 = 40;
      for (let k = 0; k < 3; k++) { const y = y0 + k * 72; E('rect', { x: 120, y, width: 64, height: 72, fill: FK.alpha(Gp.c, .14), stroke: Gp.dk, 'stroke-width': 1.6 }, g); for (let s = 0; s < 3; s++) E('path', { d: `M${132 + s * 18} ${y + 10}q6 30 -2 54`, stroke: FK.alpha(Gp.dk, .35), 'stroke-width': .8, fill: 'none' }, g); if (k) { E('path', { d: `M120 ${y}H184`, stroke: Gp.dk, 'stroke-width': 3.2, 'stroke-dasharray': '6 4' }, g); } }
      for (let k = 0; k < 5; k++) { const y = y0 + k * 43.2; E('rect', { x: 186, y, width: 22, height: 43.2, rx: 3, fill: FK.alpha(Gp.c, .45), stroke: Gp.dk, 'stroke-width': 1 }, g); E('ellipse', { cx: 197, cy: y + 21, rx: 6, ry: 9, fill: FK.alpha(N.c, .75), stroke: N.dk, 'stroke-width': .8 }, g); }
      for (let k = 0; k < 4; k++) { const y = y0 + k * 54; E('rect', { x: 62, y, width: 56, height: 54, rx: 6, fill: FK.alpha(P.c, .2), stroke: P.dk, 'stroke-width': 1 }, g); E('circle', { cx: 80, cy: y + 20, r: 4.5, fill: FK.alpha(N.c, .7) }, g); }
      E('path', { d: `M232 ${y0}Q244 148 232 256Q220 148 232 ${y0}Z`, fill: FK.alpha(L.c, .55), stroke: L.dk }, g); E('path', { d: `M256 ${y0 + 10}Q266 150 256 250Q246 150 256 ${y0 + 10}Z`, fill: FK.alpha(L.c, .55), stroke: L.dk }, g);
      T(g, 90, 18, 'প্যারেনকাইমা', { fs: 10.5, a: 'middle', w: 600, c: P.ink }); T(g, 200, 18, 'সঙ্গীকোষ', { fs: 10.5, a: 'middle', w: 600, c: Gp.ink }); T(g, 152, 33, 'সিভনল', { fs: 10.5, a: 'middle', w: 600, c: Gp.ink }); T(g, 246, 33, 'ফাইবার', { fs: 10.5, a: 'middle', w: 600, c: L.ink });
      E('path', { d: 'M90 22V38M200 22V38M246 37V44', stroke: C.mu, 'stroke-width': .8 }, g);
      T(g, 152, 126, 'সিভ প্লেট', { fs: 9.5, a: 'middle', w: 600, c: Gp.ink }); T(g, 152, 198, 'সিভ প্লেট', { fs: 9.5, a: 'middle', w: 600, c: Gp.ink });
      T(g, 320, 74, 'উৎস (পাতা)', { fs: 10, a: 'middle', c: Gp.ink, w: 600 }); T(g, 320, 252, 'ভোক্তা (মূল, ফল)', { fs: 10, a: 'middle', c: Gp.ink, w: 600 });
    } else {
      E('circle', { cx: 180, cy: 132, r: 96, fill: FK.alpha(Gp.c, .16), stroke: Gp.dk, 'stroke-width': 2 }, g);
      ctx.pores = []; for (let r = 0; r < 7; r++) for (let c = 0; c < 7; c++) { const x = 180 + (c - 3) * 24 + (r % 2) * 12 - 6, y = 132 + (r - 3) * 22; if (Math.hypot(x - 180, y - 132) < 80) ctx.pores.push([x, y]); }
      ctx.pores.forEach(([x, y]) => E('circle', { cx: x, cy: y, r: 7.5, fill: C.sf, stroke: Gp.dk, 'stroke-width': .9 }, g));
      T(g, 180, 254, 'ছিদ্র · ক্যালোজ (হলুদ) জমে বন্ধ হয়', { fs: 11, a: 'middle', c: C.mu });
    }
  },
  anim(g, C, ty, t, ctx) {
    const Gp = BK.ramp(10), S = BK.ramp(6);
    if (ty === 'ls') {
      for (let k = 0; k < 10; k++) { const f = (t * .18 + k / 10) % 1, y = 46 + f * 204, x = 152 + 14 * Math.sin(k * 2.3 + f * 4); E('rect', { x: (x - 3).toFixed(1), y: (y - 3).toFixed(1), width: 6, height: 6, rx: 1.5, fill: S.c, stroke: S.dk, 'stroke-width': .6 }, g); }
      const f = (t * .9) % 1; E('rect', { x: (204 - f * 22).toFixed(1), y: 80, width: 6, height: 6, rx: 1.5, fill: S.c, stroke: S.dk, 'stroke-width': .6 }, g);
      B8.arr(g, 320, 86, 320, 232, Gp.dk, 2);
    } else {
      const cyc = (t % 6) / 6, k = cyc < .5 ? cyc * 2 : (1 - cyc) * 2;
      ctx.pores.forEach(([x, y]) => E('circle', { cx: x, cy: y, r: Math.max(.5, 7.5 * k), fill: FK.alpha(S.c, .85), stroke: S.dk, 'stroke-width': .6 }, g));
      T(g, 180, 22, k > .6 ? 'ক্যালোজে ছিদ্র বন্ধ (আঘাত বা শীতে)' : 'ছিদ্র খোলা — খাদ্য চলাচল', { fs: 11.5, a: 'middle', c: S.ink, w: 650 });
    }
  }
});

/* ───────── তুলনা ───────── */
V.cmpMeriPerm = Object.assign({ t: 'ভাজক টিস্যু ও স্থায়ী টিস্যুর পার্থক্য', k: ['compare', 'int', 'game'], cap: 'বিভাজন ক্ষমতা, কোষের আকার, কোষগহ্বর, আন্তঃকোষীয় ফাঁক ও কাজের পার্থক্য। "যাচাই খেলা" দিয়ে নিজেকে পরীক্ষা করো।' }, BK.compare({
  a: 'ভাজক টিস্যু', b: 'স্থায়ী টিস্যু',
  rows: [
    ['বিভাজন ক্ষমতা', 'আছে — বারবার বিভাজিত হয়', 'সাধারণত নেই'],
    ['কোষের আকার', 'ছোট, প্রায় সমব্যাসীয়', 'বড়, নানা আকৃতির'],
    ['কোষপ্রাচীর', 'পাতলা, সেলুলোজের', 'পাতলা বা পুরু; লিগনিন, সুবেরিন থাকতে পারে'],
    ['সাইটোপ্লাজম', 'ঘন', 'পাতলা, প্রান্তে'],
    ['নিউক্লিয়াস', 'বড়, কেন্দ্রে', 'তুলনায় ছোট, প্রান্তে'],
    ['কোষগহ্বর', 'নেই বা খুব ছোট', 'বড়'],
    ['আন্তঃকোষীয় ফাঁক', 'নেই', 'সাধারণত থাকে'],
    ['সঞ্চিত খাদ্য', 'নেই', 'থাকতে পারে'],
    ['জীবিত না মৃত', 'সবসময় জীবিত', 'জীবিত বা মৃত'],
    ['কাজ', 'নতুন কোষ তৈরি ও বৃদ্ধি', 'খাদ্য তৈরি ও সঞ্চয়, দৃঢ়তা, পরিবহন']
  ]
}));
V.cmpSimpleComplex = Object.assign({ t: 'সরল টিস্যু ও জটিল টিস্যুর পার্থক্য', k: ['compare', 'int', 'game'], cap: 'সরল টিস্যু এক রকম কোষে, জটিল টিস্যু একাধিক রকম কোষে গঠিত।' }, BK.compare({
  a: 'সরল টিস্যু', b: 'জটিল টিস্যু',
  rows: [
    ['কোষের ধরন', 'একই রকম কোষ', 'একাধিক রকম কোষ'],
    ['উদাহরণ', 'প্যারেনকাইমা, কোলেনকাইমা, স্ক্লেরেনকাইমা', 'জাইলেম, ফ্লোয়েম'],
    ['প্রধান কাজ', 'খাদ্য তৈরি ও সঞ্চয়, দৃঢ়তা', 'পানি-খনিজ ও খাদ্য পরিবহন'],
    ['জীবিত না মৃত', 'কোনোটি জীবিত (প্যারেনকাইমা, কোলেনকাইমা), কোনোটি মৃত (স্ক্লেরেনকাইমা)', 'জীবিত ও মৃত উভয় কোষ একসাথে'],
    ['অবস্থান', 'দেহের প্রায় সব অংশে', 'কেবল ভাস্কুলার বান্ডলে'],
    ['উৎপত্তি', 'গ্রাউন্ড মেরিস্টেম, প্রোটোডার্ম ইত্যাদি থেকে', 'প্রোক্যাম্বিয়াম বা ভাস্কুলার ক্যাম্বিয়াম থেকে'],
    ['বিস্তার', 'সব উদ্ভিদে (শৈবাল-ব্রায়োফাইট সদৃশ কলাতেও)', 'কেবল ভাস্কুলার উদ্ভিদে']
  ]
}));
})();
