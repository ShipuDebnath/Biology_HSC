/* ═══════════════════════════════════════════════════════════════════
   visuals4 — ক্ষুদ্রান্ত্র: foldVilli, pancEnz, bileEmuls
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
const sm = (p, c, k) => B.smooth(p, c, k);
const badge = (g, C, x, y, s, sub) => { E('rect', { x: x - 54, y: y - 15, width: 108, height: sub ? 38 : 26, rx: 8, fill: FK.alpha('#f3c94a', .18), stroke: '#c98500', 'stroke-width': 1 }, g); T(g, x, y + 2, s, { fs: 12.5, a: 'middle', w: 650, c: '#8a5a00' }); if (sub) T(g, x, y + 17, sub, { fs: 9, a: 'middle', c: C.mu }); };

/* ═════════ শোষণতল বাড়ানোর চার ধাপ ═════════ */
V.foldVilli = Object.assign({}, B.seg({
  id: 'fvl', t: 'ক্ষুদ্রান্ত্রের শোষণতল: ভাঁজ → ভিলাই → মাইক্রোভিলাই', H: 270, def: 'tube',
  cap: 'ক্ষুদ্রান্ত্রের ভেতরের তল তিন ধাপে বাড়ে — বৃত্তাকার ভাঁজ (প্লিকি সার্কুলারিস) প্রায় 3 গুণ, ভিলাই প্রায় 10 গুণ এবং মাইক্রোভিলাই প্রায় 20 গুণ। সব মিলিয়ে সমান ব্যাসের মসৃণ নলের তুলনায় শত শত গুণ। আধুনিক পরিমাপে প্রাপ্তবয়স্কের পুরো পৌষ্টিকনালির মিউকোসার তল প্রায় 30–40 বর্গমিটার, যার বেশিরভাগ ক্ষুদ্রান্ত্রে (পুরোনো বইয়ের 200–300 বর্গমিটার অনুমান বেশি ছিল)। ধাপ বেছে নাও।',
  types: { tube: ['১. নল', 'খোলা ক্ষুদ্রান্ত্র — বৃত্তাকার ভাঁজ', 'মিউকোসা ও সাবমিউকোসা মিলে স্থায়ী আড়াআড়ি ভাঁজ (প্লিকি সার্কুলারিস বা কার্করিংয়ের ভাঁজ), 8–10 মিমি পর্যন্ত উঁচু — জেজুনামে সবচেয়ে বেশি, ইলিয়ামের শেষে প্রায় নেই। কাইম প্যাঁচানো পথে ধীরে চলে।'], fold: ['২. ভাঁজ', 'একটি ভাঁজের ওপর ভিলাই', 'প্রতিটি ভাঁজের গায়ে প্রতি বর্গমিলিমিটারে 10–40টি ভিলাস; প্রতিটি 0.5–1 মিমি উঁচু।'], vil: ['৩. ভিলাস', 'একটি ভিলাসের আবরণী', 'ভিলাসের গা ঢাকা স্তম্ভাকার এন্টেরোসাইট ও গবলেট কোষ; মাঝে কৈশিকজালিকা ও ল্যাকটিয়াল।'], mv: ['৪. মাইক্রোভিলাই', 'এন্টেরোসাইটের ব্রাশ বর্ডার', 'প্রতিটি কোষের শীর্ষে কয়েক হাজার মাইক্রোভিলাস (প্রায় 1 মাইক্রোমিটার লম্বা) — এদের ঝিল্লিতে আটকানো ব্রাশ-বর্ডার এনজাইম (মল্টেজ, সুক্রেজ, ল্যাকটেজ, পেপটাইডেজ) শেষ ধাপের পরিপাক করে।'] },
  art(g, C, ty) {
    const it = B.TS('int'), mu = B.TS('mus'), ar = B.TS('art');
    if (ty === 'tube') {
      /* খোলা নল — পেছনের দেয়ালে ভাঁজ, সামনে কাটা কিনারা */
      E('path', { d: 'M40 60Q180 30 320 60L320 200Q180 230 40 200Z', fill: B.lin(g, 'int', 90), stroke: it.dk, 'stroke-width': 1 }, g);
      E('path', { d: 'M40 60Q180 30 320 60L320 200Q180 230 40 200Z', fill: B.pat(g, 'dot', FK.alpha(it.dk, .35), { s: 3, w: .5 }) }, g);
      for (let i = 0; i < 13; i++) { const x = 50 + i * 21.5 + (B.rnd(i) - .5) * 5, w = 7 + B.rnd(i + 9) * 3, top = 58 - Math.sin((x - 40) / 280 * PI) * 22 + 6 + B.rnd(i + 3) * (i % 3 ? 26 : 4), bot = 200 + Math.sin((x - 40) / 280 * PI) * 22 - 6 - B.rnd(i + 5) * (i % 4 ? 30 : 4), d = `M${x} ${top.toFixed(1)}C${x + 7} ${(top + 40).toFixed(1)} ${x - 5} ${(bot - 40).toFixed(1)} ${x + 2} ${bot.toFixed(1)}`;
        E('path', { d, stroke: FK.alpha(it.dk, .9), 'stroke-width': w + 1.6, fill: 'none', 'stroke-linecap': 'round', transform: 'translate(1.5 2)' }, g); E('path', { d, stroke: it.c, 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round' }, g); E('path', { d, stroke: it.lt, 'stroke-width': w * .3, fill: 'none', 'stroke-linecap': 'round', transform: 'translate(-1.4 0)', opacity: .9 }, g); E('path', { d, stroke: B.pat(g, 'dot', FK.alpha(it.dk, .45), { s: 2.6, w: .45 }), 'stroke-width': w, fill: 'none', 'stroke-linecap': 'round' }, g); }
      E('path', { d: 'M40 200Q180 230 320 200L320 214Q180 246 40 214Z', fill: mu.c, stroke: mu.dk, 'stroke-width': .8 }, g); E('path', { d: 'M40 214Q180 246 320 214L320 220Q180 252 40 220Z', fill: B.TS('ser').c, stroke: B.TS('ser').dk, 'stroke-width': .6 }, g);
      E('rect', { x: 150, y: 108, width: 44, height: 40, fill: 'none', stroke: '#c98500', 'stroke-width': 1.6, 'stroke-dasharray': '4 3' }, g);
      badge(g, C, 180, 252 - 4, 'তল ≈ ×3', 'বৃত্তাকার ভাঁজ'); B.scale(g, C, 40, 24, 50, '1 সেমি');
    } else if (ty === 'fold') {
      E('path', { d: 'M20 230Q180 200 340 230L340 262H20Z', fill: B.TS('sub').c, stroke: B.TS('sub').dk }, g);
      E('path', { d: sm([[20, 236], [100, 210], [150, 120], [180, 90], [210, 120], [260, 210], [340, 236]]), stroke: 'none', fill: 'none' }, g);
      const base = B.dense([[20, 236], [90, 214], [140, 140], [180, 104], [220, 140], [270, 214], [340, 236]], 10), S = B.resample(base, 13);
      E('path', { d: sm([[20, 236], [90, 214], [140, 140], [180, 104], [220, 140], [270, 214], [340, 236]]) + 'L340 262L20 262Z', fill: B.TS('sub').c, stroke: B.TS('sub').dk }, g);
      S.forEach(([x, y, nx, ny], i) => { const h = 26 + B.rnd(i) * 6, w = 9, tx = -ny, ty2 = nx; const pts = [[x - tx * w / 2, y - ty2 * w / 2], [x - tx * w * .4 - nx * h * .7, y - ty2 * w * .4 - ny * h * .7], [x - nx * h, y - ny * h], [x + tx * w * .4 - nx * h * .7, y + ty2 * w * .4 - ny * h * .7], [x + tx * w / 2, y + ty2 * w / 2]]; E('path', { d: sm(pts, false, .5), fill: B.lin(g, 'int', 90), stroke: it.dk, 'stroke-width': .7 }, g); E('path', { d: `M${x - nx * 4} ${y - ny * 4}L${x - nx * h * .8} ${y - ny * h * .8}`, stroke: ar.c, 'stroke-width': .8 }, g); });
      E('circle', { cx: 180, cy: 78, r: 16, fill: 'none', stroke: '#c98500', 'stroke-width': 1.6, 'stroke-dasharray': '4 3' }, g);
      badge(g, C, 70, 40, 'তল ≈ ×10', 'ভিলাই'); B.scale(g, C, 270, 30, 40, '1 মিমি');
    } else if (ty === 'vil') {
      const out = [[110, 262], [112, 200], [118, 110], [134, 52], [180, 34], [226, 52], [242, 110], [248, 200], [250, 262]];
      E('path', { d: sm(out, false, .5) + 'Z', fill: B.TS('sub').c, stroke: 'none' }, g);
      E('path', { d: 'M150 262V90Q180 62 210 90V262', stroke: ar.c, 'stroke-width': 2, fill: 'none' }, g); for (let y = 110; y < 262; y += 22) E('path', { d: `M150 ${y}Q180 ${y - 6} 210 ${y}`, stroke: FK.alpha(ar.c, .7), 'stroke-width': 1, fill: 'none' }, g);
      B.tube(g, 'M180 262V92', 9, 'lym', { sw: .6 });
      const basal = B.offset(out, -16, 8); B.colEpi(g, basal, 16, { cw: 9, out: 1, gob: 5, bb: true, seed: 5 });
      E('rect', { x: 170, y: 26, width: 30, height: 28, fill: 'none', stroke: '#c98500', 'stroke-width': 1.6, 'stroke-dasharray': '4 3' }, g);
      badge(g, C, 300, 60, 'কোষে কোষে', 'ব্রাশ বর্ডার'); B.scale(g, C, 280, 240, 50, '100 মাইক্রোমিটার');
      B.lead(g, C, 230, 70, 300, 108, 'গবলেট কোষ', { fs: 10 }); B.lead(g, C, 180, 160, 300, 160, 'ল্যাকটিয়াল', { fs: 10 }); B.lead(g, C, 150, 200, 60, 200, 'কৈশিকনালি', { fs: 10 }); B.lead(g, C, 116, 120, 60, 110, 'এন্টেরোসাইট', { fs: 10 });
    } else {
      /* দুটি কোষের শীর্ষ — মাইক্রোভিলাই, গ্লাইকোক্যালিক্স, ব্রাশ-বর্ডার এনজাইম */
      const cy = B.TS('cyt');
      [[88, 208], [208, 328]].forEach(([a, b]) => { E('path', { d: `M${a + 2} 262V130H${b - 2}V262`, fill: FK.alpha(cy.c, .55), stroke: cy.dk, 'stroke-width': 1 }, g); B.nuc(g, (a + b) / 2, 236, 22, 14, 0, {}); E('path', { d: `M${a + 4} 140H${b - 4}`, stroke: FK.alpha(cy.dk, .5), 'stroke-width': 3, 'stroke-dasharray': '1 3' }, g); });
      E('path', { d: 'M208 130V262', stroke: cy.dk, 'stroke-width': 1.4 }, g); E('rect', { x: 202, y: 132, width: 12, height: 10, fill: '#7d6aa6', opacity: .7 }, g);
      for (let x = 94; x < 324; x += 8.5) { if (Math.abs(x + 3 - 208) < 5) continue; E('path', { d: `M${x} 131V72Q${x + 3.2} 66 ${x + 6.4} 72V131`, fill: FK.alpha(cy.c, .8), stroke: cy.dk, 'stroke-width': .8 }, g); E('path', { d: `M${x + 3.2} 76V138`, stroke: FK.alpha('#6b4f2a', .6), 'stroke-width': .8 }, g); }
      E('path', { d: 'M88 62Q208 54 328 62', stroke: FK.alpha('#7fb56a', .55), 'stroke-width': 10, fill: 'none' }, g);
      B.tx(g, 208, 48, 'গ্লাইকোক্যালিক্স (শর্করার আবরণ)', { fs: 9.5, a: 'middle', c: C.mu });
      B.lead(g, C, 98, 100, 80, 100, 'মাইক্রোভিলাস', { fs: 10 }); B.lead(g, C, 208, 137, 238, 164, 'টাইট জাংশন', { fs: 10 }); B.lead(g, C, 96, 141, 80, 160, 'টার্মিনাল ওয়েব', { fs: 10 }); B.lead(g, C, 148, 236, 80, 236, 'নিউক্লিয়াস', { fs: 10 });
      badge(g, C, 270, 196, 'তল ≈ ×20', 'মাইক্রোভিলাই'); B.scale(g, C, 88, 24, 60, '1 মাইক্রোমিটার');
    }
  },
  anim(g, C, ty, t) {
    if (ty === 'mv') { const names = ['মল্টেজ', 'সুক্রেজ', 'ল্যাকটেজ', 'পেপটাইডেজ'], cols = ['#5f8fd6', '#3fa66a', '#d8a12a', '#c55a8a']; for (let i = 0; i < 4; i++) { const x = 110 + i * 62, on = Math.floor(t * .8) % 4 === i; E('circle', { cx: x, cy: 70, r: on ? 5.5 : 4, fill: cols[i], stroke: '#fff', 'stroke-width': 1 }, g); if (on) B.tx(g, x, 88, names[i], { fs: 10, a: 'middle', w: 650, c: cols[i] }); } }
    else if (ty === 'tube') { for (let k = 0; k < 6; k++) { const u = ((t * .08 + k / 6) % 1), x = 44 + u * 272, y = 130 + Math.sin(u * 30 + k) * 34; E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 3.2, fill: B.TS('food').c, stroke: B.TS('food').dk, 'stroke-width': .6, opacity: .9 }, g); } }
    else if (ty === 'vil') { for (let k = 0; k < 4; k++) { const u = ((t * .2 + k / 4) % 1); E('circle', { cx: 180, cy: (100 + u * 160).toFixed(1), r: 2.2, fill: '#fff', stroke: B.TS('lym').dk, 'stroke-width': .6 }, g); B.rbc(g, 150, 262 - u * 160, 2); B.rbc(g, 210, 100 + u * 160, 2); } }
  }
}));

/* ═════════ অগ্ন্যাশয় রসের এনজাইম সক্রিয় হওয়ার ধারা ═════════ */
V.pancEnz = Object.assign({ t: 'অগ্ন্যাশয় রসের এনজাইম ও তাদের সক্রিয়তা', k: ['2d', 'anim', 'steps'], cap: 'অগ্ন্যাশয় আমিষ-পরিপাকী এনজাইমগুলো নিষ্ক্রিয় অবস্থায় (প্রো-এনজাইম) ঝরায় — নইলে নিজেকেই হজম করত (তীব্র প্যানক্রিয়াটাইটিস)। ডিওডেনামের ব্রাশ বর্ডারের এন্টেরোপেপটাইডেজ (এন্টেরোকাইনেজ) প্রথম ট্রিপসিনোজেনকে ট্রিপসিনে পরিণত করে; তারপর ট্রিপসিন বাকিদের সক্রিয় করে। ধাপে চাপ দাও।' }, BK.steps({
  W: 360, H: 260, label: 'অগ্ন্যাশয় রস', dur: 3.4,
  stages: [
    { t: 'অগ্ন্যাশয় রস ডিওডেনামে', en: 'Pancreatic juice', d: 'দিনে প্রায় 1.2–1.5 লিটার, pH প্রায় 8 (ক্ষারীয়) — HCO<sub>3</sub><sup>−</sup> পাকস্থলীর অম্লীয় কাইমকে প্রশমিত করে এনজাইমের উপযোগী pH তৈরি করে। এতে ট্রিপসিনোজেন, কাইমোট্রিপসিনোজেন, প্রোকার্বক্সিপেপটাইডেজ, অ্যামাইলেজ, লাইপেজ ও নিউক্লিয়েজ থাকে।' },
    { t: 'এন্টেরোপেপটাইডেজ', en: 'Enteropeptidase', d: 'ব্রাশ বর্ডারের এন্টেরোপেপটাইডেজ ট্রিপসিনোজেনের একটি ছোট অংশ (হেক্সাপেপটাইড) কেটে সক্রিয় ট্রিপসিন তৈরি করে।' },
    { t: 'ট্রিপসিনের ধারা', en: 'Trypsin cascade', d: 'ট্রিপসিন কাইমোট্রিপসিনোজেন → কাইমোট্রিপসিন, প্রোকার্বক্সিপেপটাইডেজ → কার্বক্সিপেপটাইডেজ এবং আরও ট্রিপসিনোজেন → ট্রিপসিন করে (স্বয়ংসক্রিয়তা)।' },
    { t: 'পরিপাক', en: 'Digestion', d: 'ট্রিপসিন ও কাইমোট্রিপসিন (এন্ডোপেপটাইডেজ) আমিষ ও পলিপেপটাইডকে ছোট পেপটাইডে, কার্বক্সিপেপটাইডেজ শিকলের শেষ থেকে অ্যামাইনো অ্যাসিডে ভাঙে; অ্যামাইলেজ শ্বেতসার → মল্টোজ; লাইপেজ (কোলাইপেজের সাহায্যে) চর্বি → মনোগ্লিসারাইড + ফ্যাটি অ্যাসিড; নিউক্লিয়েজ DNA ও RNA → নিউক্লিওটাইড।' }
  ],
  draw(g, C, s, u) {
    const Z = [['ট্রিপসিনোজেন', 'ট্রিপসিন', 3], ['কাইমোট্রিপসিনোজেন', 'কাইমোট্রিপসিন', 6], ['প্রোকার্বক্সিপেপটাইডেজ', 'কার্বক্সিপেপটাইডেজ', 2]];
    /* ডিওডেনামের ব্রাশ বর্ডার */
    E('rect', { x: 10, y: 214, width: 340, height: 36, rx: 6, fill: FK.alpha(B.TS('cyt').c, .6), stroke: B.TS('cyt').dk }, g); for (let x = 16; x < 346; x += 6) E('path', { d: `M${x} 214v-7`, stroke: B.TS('cyt').dk, 'stroke-width': 1 }, g); B.tx(g, 180, 238, 'ডিওডেনামের আবরণী (ব্রাশ বর্ডার)', { fs: 9.5, a: 'middle', c: C.mu });
    const ek = s >= 1; B.enz(g, 60, 196, 13, '#3fa66a', -90, ek ? .3 + .2 * Math.sin(u * 6) : .3, ''); B.tx(g, 60, 176, 'এন্টেরোপেপটাইডেজ', { fs: 8.5, a: 'middle', w: 600, c: '#2a7a4a' });
    Z.forEach(([a, b, ri], i) => {
      const y = 40 + i * 44, act = i === 0 ? s >= 1 && (s > 1 || u > .5) : s >= 2 && (s > 2 || u > .3 + i * .2), R = BK.ramp(ri);
      B.enz(g, 120, y + 10, 13, act ? R.c : FK.alpha(R.c, .45), 0, act ? .45 : .22, '');
      if (!act) E('path', { d: `M126 ${y + 4}q10 6 0 12q-4 -6 0 -12Z`, fill: '#9aa0a6', stroke: C.fg, 'stroke-width': .6 }, g);
      B.tx(g, 142, y + 14, act ? b : a, { fs: 10.5, w: act ? 650 : 500, c: act ? R.ink : C.mu });
      if (i === 0 && s === 1) B.carrow(g, `M68 186Q90 ${y + 40} 108 ${y + 16}`, '#3fa66a', { w: 1.4 });
      if (i > 0 && s === 2) B.carrow(g, `M106 54Q90 ${(54 + y) / 2} 106 ${y + 6}`, BK.ramp(3).dk, { w: 1.3 });
    });
    if (s === 2) B.tx(g, 200, 180, 'ট্রিপসিন বাকিদের সক্রিয় করে', { fs: 10, a: 'middle', w: 600, c: BK.ramp(3).ink });
    if (s === 3) {
      const rows = [['আমিষ → পেপটাইড → অ্যামাইনো অ্যাসিড', BK.ramp(4).dk], ['শ্বেতসার → মল্টোজ (অ্যামাইলেজ)', BK.ramp(5).dk], ['চর্বি → মনোগ্লিসারাইড + ফ্যাটি অ্যাসিড (লাইপেজ)', '#b8860b'], ['নিউক্লিক অ্যাসিড → নিউক্লিওটাইড (নিউক্লিয়েজ)', BK.ramp(7).dk]];
      E('rect', { x: 186, y: 26, width: 168, height: 140, rx: 8, fill: C.sf, stroke: C.ln }, g);
      rows.forEach(([r, c], i) => { const on = u * 4 > i; T(g, 194, 46 + i * 32, r.split(' (')[0], { fs: 9.2, c: on ? c : C.mu, w: on ? 600 : 400 }); if (r.includes('(')) T(g, 194, 58 + i * 32, '(' + r.split(' (')[1], { fs: 8.5, c: C.mu }); });
    }
  }
}));

/* ═════════ পিত্তলবণে চর্বির ইমালসিফিকেশন ও মাইসেল ═════════ */
const bs = (g, x, y, a, s = 1) => { const c = Math.cos(a), sn = Math.sin(a); E('path', { d: `M${(x).toFixed(1)} ${(y).toFixed(1)}L${(x + c * 7 * s).toFixed(1)} ${(y + sn * 7 * s).toFixed(1)}`, stroke: '#94ac3e', 'stroke-width': 3, 'stroke-linecap': 'round' }, g); E('circle', { cx: (x - c * 1.5).toFixed(1), cy: (y - sn * 1.5).toFixed(1), r: 2.2, fill: '#5b6e1d' }, g); };
V.bileEmuls = Object.assign({}, B.seg({
  id: 'ble', t: 'পিত্তলবণ: ইমালসিফিকেশন ও মাইসেল', H: 260, def: 'emu',
  cap: 'পিত্তরসে কোনো এনজাইম নেই। পিত্তলবণ (সোডিয়াম গ্লাইকোকোলেট ও টরোকোলেট) একপাশে পানিপ্রিয়, অন্যপাশে চর্বিপ্রিয় (অ্যাম্ফিপ্যাথিক) — বড় চর্বির ফোঁটার গায়ে লেগে পেরিস্ট্যালসিসের নাড়ায় তাকে অসংখ্য ক্ষুদ্র ফোঁটায় ভাঙে (ইমালসিফিকেশন), ফলে লাইপেজের কাজের তল বহুগুণ বাড়ে। পরে ভাঙা চর্বি (মনোগ্লিসারাইড ও ফ্যাটি অ্যাসিড) পিত্তলবণের সাথে ক্ষুদ্র মাইসেল গঠন করে ব্রাশ বর্ডারে পৌঁছায়। ধরন বেছে চালাও চাপো।',
  types: { emu: ['ইমালসিফিকেশন', 'বড় ফোঁটা → ক্ষুদ্র ফোঁটা', 'একই আয়তনের চর্বি 10 ভাগ ছোট ব্যাসের ফোঁটায় ভাঙলে মোট তল 10 গুণ হয় — লাইপেজ কেবল ফোঁটার তলে কাজ করতে পারে।'], mic: ['মাইসেল', 'মাইসেল ও শোষণ', 'মাইসেল (প্রায় 4–8 ন্যানোমিটার) মনোগ্লিসারাইড, ফ্যাটি অ্যাসিড, কোলেস্টেরল ও চর্বিতে দ্রবণীয় ভিটামিন (A, D, E, K) বহন করে ব্রাশ বর্ডারের পাশে এনে ছেড়ে দেয়; পিত্তলবণ ইলিয়ামে প্রায় 95% পুনঃশোষিত হয়ে যকৃতে ফেরে (এন্টেরোহেপাটিক সঞ্চালন)।'] },
  art(g, C, ty) {
    const ft = B.TS('fat');
    B.tx(g, 180, 20, ty === 'emu' ? 'ডিওডেনামের কাইম (জলীয় মাধ্যম)' : 'ব্রাশ বর্ডারের পাশে', { fs: 10, a: 'middle', c: C.mu });
    /* পিত্তলবণ অণুর লেজেন্ড */
    bs(g, 22, 244, 0, 1.2); B.tx(g, 36, 248, 'পিত্তলবণ (মাথা পানিপ্রিয়, লেজ চর্বিপ্রিয়)', { fs: 9, c: C.fg });
    if (ty === 'mic') { E('rect', { x: 250, y: 30, width: 104, height: 200, rx: 8, fill: FK.alpha(B.TS('cyt').c, .6), stroke: B.TS('cyt').dk }, g); for (let y = 36; y < 226; y += 7) E('path', { d: `M250 ${y}h-8`, stroke: B.TS('cyt').dk, 'stroke-width': 1.2 }, g); B.tx(g, 302, 130, 'এন্টেরোসাইট', { fs: 10, a: 'middle', w: 600 }); B.nuc(g, 312, 180, 16, 11, 0, {}); }
  },
  anim(g, C, ty, t) {
    const ft = B.TS('fat');
    if (ty === 'emu') {
      const u = (t * .12) % 1, k = Math.min(1, u * 1.4), n = Math.round(1 + k * 18), R0 = 46, r = R0 / Math.cbrt(n);
      for (let i = 0; i < n; i++) { const a = i * 2.39996, d = n === 1 ? 0 : Math.sqrt(i + .5) / Math.sqrt(n) * 92 * k, x = 140 + Math.cos(a) * d * 1.3, y = 128 + Math.sin(a) * d * .85;
        E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: r.toFixed(1), fill: B.vol(g, 'fat'), stroke: ft.dk, 'stroke-width': .8 }, g);
        E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: (r + 3.5).toFixed(1), fill: 'none', stroke: '#94ac3e', 'stroke-width': 4, 'stroke-dasharray': '1.6 3.2' }, g); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: (r + 6).toFixed(1), fill: 'none', stroke: '#5b6e1d', 'stroke-width': 2.2, 'stroke-dasharray': '1.6 3.2' }, g); }
      const area = Math.cbrt(n); E('rect', { x: 268, y: 60, width: 84, height: 80, rx: 8, fill: C.sf, stroke: C.ln }, g); T(g, 310, 80, 'ফোঁটা: ' + n, { fs: 10, a: 'middle' }); T(g, 310, 100, 'মোট তল', { fs: 9.5, a: 'middle', c: C.mu }); T(g, 310, 122, '× ' + area.toFixed(1), { fs: 15, a: 'middle', w: 700, c: '#8a5a00' });
      if (k > .5) { const lx = 150 + Math.cos(t * 1.3) * 60, ly = 128 + Math.sin(t * 1.7) * 50; B.enz(g, lx, ly, 8, '#c98500', t * 60 % 360, .35, ''); B.tx(g, lx, ly - 12, 'লাইপেজ', { fs: 8.5, a: 'middle', w: 650, c: '#8a5a00' }); }
    } else {
      for (let i = 0; i < 5; i++) { const u = ((t * .1 + i / 5) % 1), x = 30 + u * 200, y = 60 + i * 34 + Math.sin(u * 8 + i) * 6, rr = 11;
        if (u < .92) { E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: rr - 3, fill: FK.alpha(ft.c, .9) }, g); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: rr - 1, fill: 'none', stroke: '#94ac3e', 'stroke-width': 4, 'stroke-dasharray': '1.6 3' }, g); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: rr + 1.6, fill: 'none', stroke: '#5b6e1d', 'stroke-width': 2.2, 'stroke-dasharray': '1.6 3' }, g); }
        else { const v = (u - .92) / .08; for (let j = 0; j < 3; j++) E('circle', { cx: (238 + v * 30 + j * 3).toFixed(1), cy: (y + (j - 1) * 5).toFixed(1), r: 2.2, fill: ft.c, stroke: ft.dk, 'stroke-width': .5 }, g); } }
      B.tx(g, 130, 226, 'মাইসেল ভেঙে মনোগ্লিসারাইড ও ফ্যাটি অ্যাসিড ঝিল্লি ভেদ করে কোষে ঢোকে', { fs: 8.8, a: 'middle', c: C.fg });
    }
  }
}));
})();
