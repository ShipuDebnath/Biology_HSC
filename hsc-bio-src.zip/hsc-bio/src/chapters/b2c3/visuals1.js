/* ═══════════════════════════════════════════════════════════════════
   visuals1 — পরিপাকতন্ত্রের সাধারণ গঠন ও মুখগহ্বর: giTract, giWall
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;

/* ═════════ ১. মানব পরিপাকতন্ত্র (সামনে থেকে) ═════════
   শারীরস্থানের প্রথা: চিত্রের বাঁ দিক = দেহের ডান দিক (যকৃৎ চিত্রের বাঁয়ে, পাকস্থলী ডানে) */
const GT = {
  eso: [[180, 98], [181, 130], [183, 165], [190, 196], [203, 214], [214, 225]],
  sto: [[214, 226], [222, 216], [238, 209], [254, 214], [263, 232], [265, 256], [258, 280], [242, 297], [220, 305], [200, 301], [189, 294], [184, 289], [190, 284], [203, 287], [218, 285], [230, 273], [234, 254], [229, 238], [221, 230]],
  stoC: [[214, 226], [236, 224], [248, 246], [246, 270], [232, 288], [210, 294], [192, 290], [184, 289]],
  duo: [[184, 289], [168, 291], [158, 300], [154, 318], [158, 336], [174, 344], [196, 343], [208, 335], [214, 326]],
  si: [[214, 326], [236, 330], [246, 342], [230, 352], [200, 348], [168, 352], [146, 360], [150, 372], [178, 370], [208, 366], [238, 364], [248, 378], [228, 390], [196, 384], [166, 388], [148, 398], [160, 410], [190, 404], [220, 402], [236, 414], [214, 424], [176, 420], [150, 416], [136, 402], [130, 388]],
  col: [[128, 392], [120, 380], [117, 350], [117, 318], [124, 302], [146, 318], [176, 336], [206, 332], [232, 318], [252, 300], [262, 296], [264, 322], [263, 352], [261, 382], [252, 404], [226, 414], [204, 412], [190, 420]],
  rec: [[190, 420], [184, 432], [181, 444], [180, 452]],
  liv: [[90, 236], [96, 214], [124, 203], [162, 202], [198, 206], [224, 212], [240, 218], [226, 232], [204, 244], [184, 250], [170, 256], [150, 270], [124, 284], [102, 286], [91, 266]],
  gb: [[143, 262], [156, 260], [163, 276], [159, 291], [149, 293], [142, 281]],
  pan: [[160, 309], [176, 303], [204, 301], [234, 295], [258, 285], [270, 290], [262, 301], [234, 310], [206, 316], [190, 332], [174, 338], [160, 330]],
  app: [[118, 402], [110, 414], [111, 427], [119, 432]],
  cbd: [[150, 262], [160, 266], [166, 286], [165, 304], [158, 318]]
};
/* খাদ্যের পথ (অ্যানিমেশন) */
const PATH = B.dense([].concat(GT.eso, GT.stoC.slice(1), GT.duo.slice(1), GT.si.slice(1), [[124, 392]], GT.col.slice(2), GT.rec.slice(1)), 5);
const SEG_U = (() => { let L = 0; const acc = [0]; for (let i = 1; i < PATH.length; i++) { L += Math.hypot(PATH[i][0] - PATH[i - 1][0], PATH[i][1] - PATH[i - 1][1]); acc.push(L); } return acc.map(a => a / L); })();
const atU = u => { let i = 1; while (i < SEG_U.length && SEG_U[i] < u) i++; i = Math.min(i, SEG_U.length - 1); const k = (u - SEG_U[i - 1]) / ((SEG_U[i] - SEG_U[i - 1]) || 1); return [PATH[i - 1][0] + (PATH[i][0] - PATH[i - 1][0]) * k, PATH[i - 1][1] + (PATH[i][1] - PATH[i - 1][1]) * k]; };
/* কোন অংশে কত সময় (আনুমানিক, অনুপাতে): মুখ-অন্ননালি দ্রুত, পাকস্থলী 2–4 ঘণ্টা, ক্ষুদ্রান্ত্র 3–5, বৃহদন্ত্র 12–36 */
const travel = t => { const c = (t * .045) % 1; return c; };

V.giTract = Object.assign({ t: 'মানব পরিপাকতন্ত্র', k: ['2d', 'anim', 'int', 'quiz'], cap: 'সামনে থেকে দেখা মানব পরিপাকতন্ত্র — পৌষ্টিকনালি (মুখ থেকে পায়ু, প্রাপ্তবয়স্কে প্রায় 8–9 মিটার — মৃতদেহে মাপা; জীবিত দেহে পেশির টানে খাটো থাকে) ও পরিপাক গ্রন্থি (লালাগ্রন্থি, যকৃৎ, অগ্ন্যাশয়)। শারীরস্থানের প্রথা মেনে চিত্রের বাঁ দিক দেহের ডান দিক — তাই যকৃৎ বাঁয়ে, পাকস্থলী ডানে। খাদ্যকণাটি পৌষ্টিকনালি ধরে এগোচ্ছে। কোনো অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 470, label: 'মানব পরিপাকতন্ত্র', idle: true,
  art(g, C, part) {
    const sk = B.TS('skin');
    /* দেহরেখা */
    const body = 'M180 8C206 8 216 30 215 52C214 76 206 92 198 100L198 112C226 116 262 122 274 140C282 170 278 210 270 236C264 262 266 300 270 330C276 372 278 410 266 452L94 452C82 410 84 372 90 330C94 300 96 262 90 236C82 210 78 170 86 140C98 122 134 116 162 112L162 100C154 92 146 76 145 52C144 30 154 8 180 8Z';
    E('path', { d: body, fill: FK.alpha(sk.c, C.dark ? .12 : .16), stroke: FK.alpha(sk.dk, .55), 'stroke-width': 1 }, g);
    E('path', { d: 'M145 50c-6 -2 -8 10 -2 14M215 50c6 -2 8 10 2 14', stroke: FK.alpha(sk.dk, .5), 'stroke-width': 1, fill: 'none' }, g);   /* কান */
    /* মধ্যচ্ছদা */
    E('path', { d: 'M88 240C96 214 128 196 166 206C176 210 184 210 194 206C230 194 262 212 272 240', fill: 'none', stroke: FK.alpha(B.TS('mus').c, .55), 'stroke-width': 3.2 }, g);
    /* লালাগ্রন্থি */
    const sal = part('sal');
    [[150, 62, -1], [210, 62, 1]].forEach(([x, y, s]) => {
      B.organ(sal, B.smooth([[x - 6 * s, y - 13], [x + 5 * s, y - 10], [x + 7 * s, y + 2], [x + 3 * s, y + 13], [x - 5 * s, y + 10], [x - 8 * s, y]], true), 'pan', { pat: 'fat', pa: .35, po: { s: 4, w: .5 } });   /* প্যারোটিড */
      E('path', { d: `M${x + 6 * s} ${y + 2}Q${x + 14 * s} ${y + 6} ${180 - 9 * s} ${74}`, stroke: B.TS('pan').dk, 'stroke-width': 1.2, fill: 'none' }, sal);
      B.organ(sal, B.smooth([[x + 4 * s, 88], [x + 14 * s, 86], [x + 18 * s, 94], [x + 10 * s, 100], [x + 2 * s, 96]], true), 'pan', { pat: 'fat', pa: .35, po: { s: 4, w: .5 } });   /* অধোচোয়াল */
      B.organ(sal, B.smooth([[180 - 13 * s, 83], [180 - 5 * s, 82], [180 - 4 * s, 87], [180 - 12 * s, 88]], true), 'pan', {});   /* অধোজিহ্বা */
    });
    /* মুখ */
    const mo = part('mouth'), tg = B.TS('tng');
    E('path', { d: 'M164 76Q180 70 196 76Q180 88 164 76Z', fill: B.vol(mo, 'tng'), stroke: tg.dk, 'stroke-width': 1 }, mo);
    E('path', { d: 'M168 76.5Q180 73 192 76.5', stroke: '#fbfaf5', 'stroke-width': 2, fill: 'none' }, mo);
    const cae = part('caecum');
    B.organ(cae, B.smooth([[110, 384], [128, 384], [132, 398], [124, 408], [110, 406], [106, 394]], true), 'colon', {});
    B.tube(cae, B.smooth(GT.app), 4.2, 'colon', { sw: .8 });
    /* অগ্ন্যাশয় */
    const pa = part('pan'); B.organ(pa, B.smooth(GT.pan, true), 'pan', { pat: 'dot', pa: .5, po: { s: 3.4, w: .5 } });
    /* পিত্তনালি (ডিওডেনামের পেছনে) */
    const bd = part('bile'); B.tube(bd, B.smooth(GT.cbd), 2.6, 'bile', { sw: .6 });
    /* ডিওডেনাম */
    const du = part('duo'); B.tube(du, B.smooth(GT.duo), 11, 'int', { sw: .9 });
    /* বৃহদন্ত্র (অনুপ্রস্থ কোলন ডিওডেনাম ও অগ্ন্যাশয়ের সামনে দিয়ে যায়) */
    const co = part('colon'), cd = B.smooth(GT.col);
    B.tube(co, cd, 15, 'colon');
    B.resample(B.dense(GT.col, 6), 9).forEach(([x, y, nx, ny], i) => { if (i < 1) return; E('path', { d: `M${(x + nx * 7).toFixed(1)} ${(y + ny * 7).toFixed(1)}Q${(x + nx * 1.5 + ny * 2).toFixed(1)} ${(y + ny * 1.5 - nx * 2).toFixed(1)} ${(x - nx * 7).toFixed(1)} ${(y - ny * 7).toFixed(1)}`, stroke: FK.alpha(B.TS('colon').dk, .55), 'stroke-width': .8, fill: 'none' }, co); });   /* হস্ট্রা */
    E('path', { d: cd, stroke: FK.alpha('#fff', .35), 'stroke-width': 1.6, fill: 'none', 'stroke-dasharray': '1 0' }, co);   /* টিনিয়া কোলাই */
    /* মলাশয় ও পায়ু */
    const re = part('rectum'); B.tube(re, B.smooth(GT.rec.slice(0, 3)), 14, 'colon');
    const an = part('anus'); B.tube(an, `M181 443L180 453`, 6, 'colon', { sw: .8 }); E('ellipse', { cx: 180, cy: 453.5, rx: 4.6, ry: 1.8, fill: B.TS('mus').c, stroke: B.TS('mus').dk, 'stroke-width': .8 }, an);
    /* ক্ষুদ্রান্ত্র — প্যাঁচানো নল */
    const si = part('si'), ti = B.TS('int');
    E('path', { d: B.smooth([[140, 346], [196, 344], [244, 336], [252, 360], [248, 392], [236, 410], [190, 412], [150, 410], [136, 392], [136, 360]], true), fill: FK.alpha(ti.dk, .55), stroke: 'none' }, si);   /* মেসেন্টারি ও পেছনের কুণ্ডলী */
    /* কুণ্ডলী — পেছন থেকে সামনে, প্রতিটি একটি U বা S বাঁক */
    const loops = []; [354, 377, 399].forEach((y, r) => [150, 173, 197, 221, 243].forEach((x, c) => { const k = r * 5 + c; loops.push([x + (B.rnd(k + 11) - .5) * 8, y + (B.rnd(k + 23) - .5) * 6, B.rnd(k + 37) * 360]); }));
    loops.sort((p, q) => B.rnd(p[2]) - B.rnd(q[2]));
    loops.forEach(([x, y, a], i) => {
      const r = a * PI / 180, L = 15 + B.rnd(i * 3 + 1) * 6, Wd = 9.5 + B.rnd(i * 5 + 2) * 3;
      const pts = [[-L, -Wd], [L * .25, -Wd * 1.05], [L * .8, -Wd * .55], [L, Wd * .15], [L * .7, Wd * .85], [0, Wd * 1.1], [-L * .9, Wd * .95]].map(([u, v]) => [x + u * Math.cos(r) - v * Math.sin(r), y + u * Math.sin(r) + v * Math.cos(r)]);
      B.tube(si, B.smooth(pts, false, .7), 9.5, 'int', { sw: .9 });
    });
    B.tube(si, B.smooth([[156, 404], [142, 402], [131, 394]]), 9, 'int', { sw: .9 });   /* প্রান্তীয় ইলিয়াম → সিকাম */
    /* অন্ননালি */
    const es = part('eso'); B.tube(es, B.smooth(GT.eso), 7.5, 'eso', { sw: .9 });
    const ph = part('phar'); B.tube(ph, 'M180 82L180 100', 9, 'eso', { sw: .9 });
    /* পাকস্থলী */
    const st = part('sto'), sdp = B.smooth(GT.sto, true, .5);
    B.organ(st, sdp, 'stom', { gr: { cx: .4, cy: .3 } });
    E('path', { d: 'M228 232Q246 246 244 266M236 226Q256 240 256 262M220 292Q236 286 246 276', stroke: FK.alpha(B.TS('stom').dk, .45), 'stroke-width': .8, fill: 'none' }, st);   /* তির্যক পেশির আভাস */
    E('path', { d: 'M186 286.5L190 292', stroke: B.TS('mus').dk, 'stroke-width': 3 }, st);   /* পাইলোরিক স্ফিংক্টার */
    /* যকৃৎ */
    const lv = part('liv'), ld = B.smooth(GT.liv, true, .5);
    B.organ(lv, ld, 'liv', { gr: { cx: .3, cy: .25, r: .95 }, hl: 'M104 222C130 210 168 208 196 212' });
    E('path', { d: 'M178 206C182 222 180 238 176 252', stroke: FK.alpha(B.TS('liv').dk, .8), 'stroke-width': .9, fill: 'none' }, lv);   /* ফ্যালসিফর্ম লিগামেন্ট */
    /* পিত্তথলি */
    const gb = part('gb'); B.organ(gb, B.smooth(GT.gb, true), 'gb', { hl: 'M147 268Q152 266 156 274' });
    T(g, 180, 466, 'চিত্রের বাঁ দিক = দেহের ডান দিক', { fs: 9, a: 'middle', c: C.mu });
  },
  idle(g, C, t) {
    const u = travel(t), [x, y] = atU(u), fd = B.TS('food');
    E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 4.6, fill: fd.c, stroke: fd.dk, 'stroke-width': .9 }, g);
    const [x2, y2] = atU(Math.min(1, u + .006));
    E('circle', { cx: x2.toFixed(1), cy: y2.toFixed(1), r: 7.5, fill: 'none', stroke: FK.alpha(B.TS('mus').dk, .55), 'stroke-width': 1.6 }, g);   /* পেরিস্ট্যালসিসের সংকোচন বলয় */
  },
  parts: [
    { id: 'mouth', bn: 'মুখগহ্বর', en: 'Buccal cavity', fn: 'দাঁতে খাদ্য চিবানো (যান্ত্রিক পরিপাক), লালার টায়ালিন (লালা অ্যামাইলেজ) দিয়ে শ্বেতসারের রাসায়নিক পরিপাক শুরু; জিহ্বা খাদ্যকে বোলাসে পরিণত করে গলবিলে ঠেলে দেয়।', a: [180, 78], l: [76, 70] },
    { id: 'sal', bn: 'লালাগ্রন্থি (তিন জোড়া)', lb: 'লালাগ্রন্থি', en: 'Salivary glands', fn: 'প্যারোটিড, সাবম্যান্ডিবুলার ও সাবলিঙ্গুয়াল — দিনে প্রায় 1–1.5 লিটার লালা ঝরায়; লালায় অ্যামাইলেজ, লাইসোজাইম ও মিউসিন থাকে।', a: [210, 62], l: [282, 46] },
    { id: 'phar', bn: 'গলবিল', en: 'Pharynx', fn: 'খাদ্য ও বায়ুর মিলিত পথ; গলাধঃকরণের সময় এপিগ্লটিস (উপজিহ্বা) স্বরযন্ত্রের মুখ ঢেকে দেয়, তাই খাদ্য অন্ননালিতে যায়।', a: [180, 92], l: [282, 92] },
    { id: 'eso', bn: 'অন্ননালি', en: 'Oesophagus', fn: 'প্রায় 25 সেমি লম্বা পেশিময় নল; কোনো পরিপাক হয় না, পেরিস্ট্যালসিসে বোলাসকে প্রায় 8–10 সেকেন্ডে পাকস্থলীতে পৌঁছায়; শেষ প্রান্তে কার্ডিয়াক স্ফিংক্টার।', a: [182, 150], l: [76, 150] },
    { id: 'liv', bn: 'যকৃৎ', en: 'Liver', fn: 'দেহের সবচেয়ে বড় গ্রন্থি (প্রায় 1.5 কেজি); পিত্তরস তৈরি করে, গ্লাইকোজেন, ভিটামিন ও লৌহ জমা রাখে, বিষাক্ত পদার্থ নিষ্ক্রিয় করে ও ইউরিয়া তৈরি করে।', a: [128, 236], l: [76, 196] },
    { id: 'gb', bn: 'পিত্তথলি', en: 'Gallbladder', fn: 'যকৃতের নিচের তলে নাশপাতি আকৃতির থলি; পিত্তরস জমা রাখে ও পানি শোষণ করে 5–10 গুণ ঘন করে; চর্বিযুক্ত খাদ্য ডিওডেনামে এলে CCK হরমোনের প্রভাবে সংকুচিত হয়।', a: [152, 282], l: [76, 262] },
    { id: 'bile', bn: 'সাধারণ পিত্তনালি', lb: 'পিত্তনালি', en: 'Common bile duct', fn: 'যকৃৎ ও পিত্তথলির নালি মিলে তৈরি; অগ্ন্যাশয় নালির সাথে মিলে হেপাটো-প্যানক্রিয়াটিক অ্যাম্পুলা হয়ে ডিওডেনামে খোলে (ওড্ডির স্ফিংক্টার)।', a: [166, 292], l: [76, 296] },
    { id: 'sto', bn: 'পাকস্থলী', en: 'Stomach', fn: 'J আকৃতির থলি, খালি অবস্থায় প্রায় 50 মিলি, ভরা অবস্থায় 1–1.5 লিটার (সর্বোচ্চ প্রায় 4 লিটার) ধরে; HCl ও পেপসিনে আমিষের পরিপাক শুরু, খাদ্য মিশে কাইমে পরিণত হয়।', a: [246, 252], l: [284, 214] },
    { id: 'pan', bn: 'অগ্ন্যাশয়', en: 'Pancreas', fn: 'পাকস্থলীর পেছনে 12–15 সেমি লম্বা মিশ্র গ্রন্থি: বহিঃক্ষরা অংশ দিনে 1.2–1.5 লিটার অগ্ন্যাশয় রস (ট্রিপসিনোজেন, অ্যামাইলেজ, লাইপেজ, HCO<sub>3</sub><sup>−</sup>) এবং অন্তঃক্ষরা আইলেট ইনসুলিন ও গ্লুকাগন দেয়।', a: [214, 307], l: [284, 286] },
    { id: 'duo', bn: 'ডিওডেনাম', en: 'Duodenum', fn: 'ক্ষুদ্রান্ত্রের প্রথম, C আকৃতির অংশ (প্রায় 25 সেমি) — অগ্ন্যাশয়ের মাথা ঘিরে থাকে; পিত্তরস ও অগ্ন্যাশয় রস এখানে এসে পরিপাকের বড় অংশ সম্পন্ন করে।', a: [157, 306], l: [76, 330] },
    { id: 'si', bn: 'ক্ষুদ্রান্ত্র (জেজুনাম ও ইলিয়াম)', lb: 'জেজুনাম ও ইলিয়াম', en: 'Jejunum & ileum', fn: 'প্রায় 6 মিটার লম্বা ক্ষুদ্রান্ত্রের বাকি অংশ — জেজুনাম প্রায় 2.5 মিটার, ইলিয়াম প্রায় 3.5 মিটার; ভিলাইয়ে পরিপাক সম্পন্ন হয় ও প্রায় সব পুষ্টি শোষিত হয়।', a: [222, 386], l: [284, 352] },
    { id: 'colon', bn: 'কোলন', en: 'Colon', fn: 'ঊর্ধ্বগামী, অনুপ্রস্থ, নিম্নগামী ও সিগময়েড কোলন — পানি ও লবণ শোষণ, অণুজীবে ভিটামিন K ও কিছু B তৈরি এবং মল গঠন; গায়ে থলির মতো হস্ট্রা ও তিনটি টিনিয়া কোলাই।', a: [262, 340], l: [284, 320] },
    { id: 'caecum', bn: 'সিকাম ও অ্যাপেন্ডিক্স', lb: 'সিকাম, অ্যাপেন্ডিক্স', en: 'Caecum & appendix', fn: 'বৃহদন্ত্রের শুরুর থলি; ইলিয়াম এর পাশে ইলিওসিকাল কপাটিকা দিয়ে খোলে। নিচে সরু, প্রায় 9 সেমি লম্বা ভার্মিফর্ম অ্যাপেন্ডিক্স — মানুষে লসিকা টিস্যুসমৃদ্ধ, পরিপাকে ভূমিকা নেই।', a: [114, 420], l: [76, 410] },
    { id: 'rectum', bn: 'মলাশয়', en: 'Rectum', fn: 'প্রায় 12–15 সেমি; মল জমা থাকে, ভরে গেলে মলত্যাগের প্রতিবর্ত শুরু হয়।', a: [184, 432], l: [284, 428] },
    { id: 'anus', bn: 'পায়ু', en: 'Anus', fn: 'পায়ুনালির শেষ ছিদ্র; অনৈচ্ছিক অন্তঃস্থ ও ঐচ্ছিক বহিঃস্থ স্ফিংক্টার পেশি মলত্যাগ নিয়ন্ত্রণ করে।', a: [180, 452], l: [76, 450] }
  ]
}));

})();

/* ═════════ ২. পৌষ্টিকনালির প্রাচীরের স্তর (ক্ষুদ্রান্ত্রের প্রস্থচ্ছেদের একটি খণ্ড) ═════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
const X0 = 118, X1 = 296, DX = 34, DY = -22, YS = 104;           /* সামনের তল, পাশের তল, ভিলাইয়ের গোড়া */
const LY = { lp: 140, mm: 145, sub: 188, circ: 226, auer: 232, lon: 254, ser: 262 };
const VX = [134, 165, 196, 227, 258, 285];
const vil = (cx, top, w, lean = 0) => [[cx - w / 2, YS], [cx - w / 2 + .8 + lean * .2, YS - 24], [cx - w * .4 + lean * .6, top + 12], [cx - w * .22 + lean, top + 2], [cx + lean, top], [cx + w * .22 + lean, top + 2], [cx + w * .4 + lean * .6, top + 12], [cx + w / 2 - .8 + lean * .2, YS - 24], [cx + w / 2, YS]];
const surf = () => { let pts = []; VX.forEach((cx, i) => { const v = vil(cx, 44 + (i % 3) * 4, 21, (i % 2 ? 1.5 : -1.5)); if (i === 0) pts.push([X0, YS]); pts = pts.concat(v.slice(i === 0 ? 0 : 0)); const nx = VX[i + 1]; if (nx) { const m = (cx + nx) / 2; pts.push([m - 4.2, YS + 2], [m - 4.4, YS + 14], [m - 3.6, YS + 26], [m, YS + 30], [m + 3.6, YS + 26], [m + 4.4, YS + 14], [m + 4.2, YS + 2]); } }); pts.push([X1, YS]); return pts; };
V.giWall = Object.assign({ t: 'পৌষ্টিকনালির প্রাচীরের স্তর', k: ['2d', 'anim', 'int', 'quiz'], cap: 'ক্ষুদ্রান্ত্রের প্রাচীরের একটি খণ্ড (প্রস্থচ্ছেদ) — ভেতর থেকে বাইরে চারটি প্রধান স্তর: মিউকোসা, সাবমিউকোসা, মাসকুলারিস এক্সটার্না ও সেরোসা। অন্ননালি থেকে মলাশয় পর্যন্ত এ বিন্যাস একই, শুধু অংশভেদে মিউকোসা বদলায় (যেমন ভিলাই কেবল ক্ষুদ্রান্ত্রে)। কৈশিকনালিতে রক্তকণিকা চলছে। স্তরে চাপ দাও।' }, BK.diagram({
  W: 360, H: 300, label: 'পৌষ্টিকনালির প্রাচীর', idle: true,
  art(g, C, part) {
    const lp = B.TS('sub'), ar = B.TS('art'), vn = B.TS('vein'), ly = B.TS('lym'), nv = B.TS('nrv');
    /* পেছনের সারির ভিলাই (গভীরতা বোঝাতে) */
    VX.forEach((cx, i) => { if (i === 5) return; const v = vil(cx + 15, 36 + (i % 2) * 5, 18, 0).map(([x, y]) => [x, y - 12]); E('path', { d: B.smooth(v, false, .5) + 'Z', fill: B.lin(g, 'int', 90), stroke: B.TS('int').dk, 'stroke-width': .6, opacity: .55 }, g); });
    /* পাশের তল (ডানে, ঢালু) */
    const side = (ya, yb, k, pat) => { const d = `M${X1} ${ya}L${X1 + DX} ${ya + DY}L${X1 + DX} ${yb + DY}L${X1} ${yb}Z`, t = B.TS(k); E('path', { d, fill: t.c, stroke: t.dk, 'stroke-width': .6 }, g); E('path', { d, fill: FK.alpha('#000', .14) }, g); if (pat) E('path', { d, fill: pat, stroke: 'none' }, g); };
    side(YS, LY.lp, 'sub'); side(LY.lp, LY.mm, 'mus'); side(LY.mm, LY.sub, 'sub', B.pat(g, 'wave', FK.alpha(lp.dk, .5), { s: 6, w: .5 }));
    side(LY.sub, LY.circ, 'mus', B.pat(g, 'dot', FK.alpha(B.TS('mus').dk, .6), { s: 3.6, w: .6 })); side(LY.circ, LY.auer, 'sub'); side(LY.auer, LY.lon, 'mus', B.pat(g, 'line', FK.alpha(B.TS('mus').dk, .5), { s: 3, a: -33, w: .5 })); side(LY.lon, LY.ser, 'ser');
    E('path', { d: `M${X1} ${YS}L${X1 + DX} ${YS + DY}`, stroke: B.TS('int').dk, 'stroke-width': .8 }, g);
    /* মিউকোসা — ল্যামিনা প্রোপ্রিয়া (ভিলাস ও গ্রন্থির ফাঁকা স্থান) */
    const S = surf(), sd = B.smooth(S, false, .4), mu = part('lp');
    E('path', { d: sd + `L${X1} ${LY.lp}L${X0} ${LY.lp}Z`, fill: lp.c, stroke: 'none' }, mu);
    let dDot = ''; for (let k = 0; k < 170; k++) { const x = X0 + 4 + B.rnd(k * 3 + 1) * (X1 - X0 - 8), y = 48 + B.rnd(k * 5 + 2) * (LY.lp - 50); dDot += B.ellD(x, y, .7, .7); } E('path', { d: dDot, fill: FK.alpha(B.TS('nuc').c, .5), 'clip-path': B.clip(g, 'lpc', sd + `L${X1} ${LY.lp}L${X0} ${LY.lp}Z`) }, mu);
    /* ভিলাসের ভেতর — কৈশিকজালিকা ও ল্যাকটিয়াল */
    const lc = part('lac'), cp = part('cap');
    VX.forEach((cx, i) => { const top = 44 + (i % 3) * 4, le = i % 2 ? 1.5 : -1.5;
      E('path', { d: `M${cx - 5.5} ${YS + 12}L${cx - 5 + le * .3} ${top + 16}Q${cx + le} ${top + 6} ${cx + 5 + le * .3} ${top + 16}L${cx + 5.5} ${YS + 12}`, stroke: ar.c, 'stroke-width': 1.1, fill: 'none' }, cp);
      E('path', { d: `M${cx - 5} ${top + 30}h10M${cx - 5} ${top + 44}h10`, stroke: FK.alpha(ar.c, .7), 'stroke-width': .7 }, cp);
      B.tube(lc, `M${cx + le * .5} ${YS + 14}L${cx + le * .8} ${top + 18}`, 3.2, 'lym', { sw: .5, hl: false }); });
    /* আবরণী (সরল স্তম্ভাকার, গবলেট কোষ ও ব্রাশ বর্ডারসহ) */
    const ep = part('epi'), basal = B.offset(S, -6.2, 5);
    B.colEpi(ep, basal, 6.2, { cw: 3.4, out: 1, gob: 6, bb: true, seed: 3 });
    /* আন্ত্রিক গ্রন্থি (লিবারকুনের ক্রিপ্ট) চিহ্নের জন্য আলাদা অংশ (অদৃশ্য আবরণ) */
    const cr = part('crypt'); VX.slice(0, 5).forEach((cx, i) => { const m = (cx + VX[i + 1]) / 2; E('rect', { x: m - 6, y: YS + 2, width: 12, height: 30, fill: 'transparent' }, cr); });
    const vi = part('vil'); VX.forEach((cx, i) => E('rect', { x: cx - 10, y: 44, width: 20, height: 56, fill: 'transparent' }, vi));
    /* মাসকুলারিস মিউকোসি */
    const mm = part('mm'); E('rect', { x: X0, y: LY.lp, width: X1 - X0, height: LY.mm - LY.lp, fill: B.TS('mus').c, stroke: B.TS('mus').dk, 'stroke-width': .5 }, mm);
    /* সাবমিউকোসা */
    const sb = part('sub'), sbd = `M${X0} ${LY.mm}H${X1}V${LY.sub}H${X0}Z`;
    E('path', { d: sbd, fill: lp.lt, stroke: lp.dk, 'stroke-width': .5 }, sb); E('path', { d: sbd, fill: B.pat(g, 'wave', FK.alpha(lp.dk, .55), { s: 6, w: .5 }) }, sb);
    const vs = part('ves');
    E('circle', { cx: 152, cy: 167, r: 6, fill: ar.c, stroke: ar.dk, 'stroke-width': 1.4 }, vs); E('circle', { cx: 152, cy: 167, r: 3, fill: lp.lt }, vs); B.rbc(vs, 152, 167, 1.6);
    E('path', { d: B.smooth([[168, 160], [180, 158], [186, 166], [182, 176], [170, 177], [165, 168]], true), fill: FK.alpha(vn.lt, .6), stroke: vn.dk, 'stroke-width': .9 }, vs); B.rbc(vs, 174, 170, 1.7); B.rbc(vs, 179, 165, 1.6);
    E('path', { d: B.smooth([[206, 162], [216, 160], [219, 168], [212, 173], [204, 170]], true), fill: ly.lt, stroke: ly.dk, 'stroke-width': .8 }, vs);
    E('path', { d: `M152 161V${LY.mm}M152 ${LY.mm}Q150 128 146 ${YS + 16}`, stroke: ar.c, 'stroke-width': 1, fill: 'none' }, vs);
    const ms = part('meis'); [[244, 166], [250, 170], [246, 175], [253, 164]].forEach(([x, y]) => { E('circle', { cx: x, cy: y, r: 3.2, fill: nv.c, stroke: nv.dk, 'stroke-width': .6 }, ms); B.nuc(ms, x, y, 1.1, 1.1, 0, { chr: false }); });
    E('path', { d: 'M236 170L244 167M253 170L266 176M250 162L262 156', stroke: nv.dk, 'stroke-width': .8, fill: 'none' }, ms);
    /* বৃত্তাকার ও অনুদৈর্ঘ্য পেশি, মাঝে আওয়ারবাখের জালক */
    const ci = part('circ'); B.musLayer(ci, `M${X0} ${LY.sub}H${X1}V${LY.circ}H${X0}Z`, 'wc', 'circ', { s: 3.2 });
    for (let x = X0 + 6; x < X1; x += 11) B.nuc(ci, x + (B.rnd(x) - .5) * 4, LY.sub + 6 + B.rnd(x + 3) * 28, 2.4, .7, 0, { chr: false, op: .8 });
    const au = part('auer'); E('rect', { x: X0, y: LY.circ, width: X1 - X0, height: LY.auer - LY.circ, fill: lp.lt, stroke: 'none' }, au);
    E('path', { d: `M${X0} ${LY.circ + 3}H${X1}`, stroke: nv.dk, 'stroke-width': .8 }, au);
    [140, 186, 232, 276].forEach(x => { E('ellipse', { cx: x, cy: LY.circ + 3, rx: 8, ry: 3.4, fill: nv.c, stroke: nv.dk, 'stroke-width': .6 }, au); [-4, 0, 4].forEach(d => B.nuc(au, x + d, LY.circ + 3, 1, 1, 0, { chr: false })); });
    const lo = part('lon'); B.musLayer(lo, `M${X0} ${LY.auer}H${X1}V${LY.lon}H${X0}Z`, 'wl', 'long', { s: 3.6 });
    /* সেরোসা */
    const se = part('ser'); E('rect', { x: X0, y: LY.lon, width: X1 - X0, height: LY.ser - LY.lon, fill: B.TS('ser').c, stroke: B.TS('ser').dk, 'stroke-width': .5 }, se);
    for (let x = X0 + 3; x < X1; x += 9) E('ellipse', { cx: x, cy: LY.ser - 1.2, rx: 3.6, ry: .9, fill: B.TS('nuc').c, opacity: .7 }, se);
    /* প্রধান চার স্তরের বন্ধনী */
    const bx = X1 + DX + 6;
    [[44, LY.mm, 'মিউকোসা'], [LY.mm, LY.sub, 'সাবমিউকোসা'], [LY.sub, LY.lon, 'পেশিস্তর'], [LY.lon - 1, LY.ser + 6, 'সেরোসা']].forEach(([a, b, s], i) => {
      const ya = (i ? a + DY : a), yb = b + DY; E('path', { d: `M${bx - 3} ${ya + 1}h3V${yb - 1}h-3`, stroke: C.mu, 'stroke-width': 1, fill: 'none' }, g);
      const t = B.tx(g, 0, 0, s, { fs: i === 3 ? 8.5 : 10, a: 'middle', w: 600, c: C.fg }); t.setAttribute('transform', `translate(${bx + 9} ${(ya + yb) / 2}) rotate(-90)`); });
    B.tx(g, (X0 + X1) / 2, 24, 'গহ্বর (লুমেন)', { fs: 9.5, a: 'middle', c: C.mu });
  },
  idle(g, C, t) {
    [1, 3, 4].forEach(i => { const cx = VX[i], top = 44 + (i % 3) * 4, le = i % 2 ? 1.5 : -1.5, L = (YS + 12 - top - 16) * 2 + 16;
      for (let k = 0; k < 3; k++) { const u = ((t * 22 + k * L / 3) % L); let x, y; if (u < YS + 12 - top - 16) { x = cx - 5.3; y = YS + 12 - u; } else if (u < YS + 12 - top - 16 + 16) { const a = (u - (YS - 4 - top)) / 16 * PI; x = cx - 5 * Math.cos(a) + le * .5; y = top + 16 - 8 * Math.sin(a); } else { x = cx + 5.3; y = top + 16 + (u - (YS - top)); } B.rbc(g, x, y, 1.5); } });
  },
  parts: [
    { id: 'vil', bn: 'ভিলাস (বহুবচনে ভিলাই)', lb: 'ভিলাস', en: 'Villus', fn: 'মিউকোসার আঙুলের মতো প্রায় 0.5–1 মিমি উঁচু অভিক্ষেপ — শোষণতল বহুগুণ বাড়ায়; প্রতিটির ভেতরে কৈশিকজালিকা ও একটি ল্যাকটিয়াল। কেবল ক্ষুদ্রান্ত্রে থাকে।', a: [194, 58], l: [104, 40] },
    { id: 'epi', bn: 'সরল স্তম্ভাকার আবরণী', lb: 'আবরণী', en: 'Columnar epithelium', fn: 'এক সারি লম্বা কোষ (এন্টেরোসাইট) — মুক্ত তলে মাইক্রোভিলাইয়ের ব্রাশ বর্ডার; মাঝে মাঝে শ্লেষ্মা ঝরানো গবলেট কোষ (ফিকে নীল)।', a: [161, 74], l: [104, 62] },
    { id: 'lac', bn: 'ল্যাকটিয়াল (কেন্দ্রীয় লসিকানালি)', lb: 'ল্যাকটিয়াল', en: 'Lacteal', fn: 'ভিলাসের মাঝের অন্ধ-প্রান্ত লসিকানালি — চর্বি কাইলোমাইক্রন রূপে এতে শোষিত হয়, তাই চর্বিযুক্ত খাবারের পর দুধসাদা (কাইল) দেখায়।', a: [224, 76], l: [104, 84] },
    { id: 'cap', bn: 'কৈশিকজালিকা', en: 'Capillary network', fn: 'ভিলাসের ভেতরের রক্তজালিকা — গ্লুকোজ, অ্যামাইনো অ্যাসিড, পানি ও খনিজ শোষিত হয়ে যকৃৎ পোর্টাল শিরায় যায়।', a: [129, 70], l: [104, 106] },
    { id: 'crypt', bn: 'আন্ত্রিক গ্রন্থি (লিবারকুনের ক্রিপ্ট)', lb: 'আন্ত্রিক গ্রন্থি', en: 'Crypt of Lieberkühn', fn: 'ভিলাইয়ের গোড়ার নলাকার গ্রন্থি — আন্ত্রিক রস ঝরায়; তলদেশের স্টেম কোষ থেকে নতুন আবরণী কোষ তৈরি হয়ে 3–5 দিনে ভিলাসের চূড়ায় উঠে খসে পড়ে।', a: [209, 124], l: [104, 128] },
    { id: 'lp', bn: 'ল্যামিনা প্রোপ্রিয়া', en: 'Lamina propria', fn: 'আবরণীর নিচের শিথিল যোজক টিস্যু — রক্তনালি, লসিকানালি ও প্রতিরক্ষা কোষ (লসিকাকোষ, প্লাজমা কোষ) থাকে।', a: [128, 132], l: [104, 148] },
    { id: 'mm', bn: 'মাসকুলারিস মিউকোসি', lb: 'মাসকুলারিস মিউকোসি', en: 'Muscularis mucosae', fn: 'মিউকোসার সবচেয়ে বাইরের পাতলা মসৃণ পেশিস্তর — ভিলাই ও ভাঁজ নড়িয়ে শোষণে সাহায্য করে।', a: [140, 142.5], l: [104, 166] },
    { id: 'sub', bn: 'সাবমিউকোসা', en: 'Submucosa', fn: 'ঘন যোজক টিস্যুর স্তর — বড় রক্তনালি, লসিকানালি ও মাইসনারের স্নায়ুজালক থাকে; ডিওডেনামে এখানে ব্রুনারের গ্রন্থি ক্ষারীয় শ্লেষ্মা ঝরায়।', a: [228, 178], l: [104, 184] },
    { id: 'ves', bn: 'ধমনি, শিরা ও লসিকানালি', lb: 'রক্ত ও লসিকানালি', en: 'Blood & lymph vessels', fn: 'পুরু প্রাচীরের গোল ধমনি (লাল), পাতলা প্রাচীরের চওড়া শিরা (নীল) ও ফিকে লসিকানালি — মিউকোসায় শাখা পাঠায়।', a: [174, 168], l: [104, 202] },
    { id: 'meis', bn: 'মাইসনারের স্নায়ুজালক (সাবমিউকোসাল)', lb: 'মাইসনার জালক', en: "Meissner's plexus", fn: 'সাবমিউকোসার স্নায়ুকোষগুচ্ছ — গ্রন্থির ক্ষরণ ও মিউকোসার রক্তপ্রবাহ নিয়ন্ত্রণ করে; আন্ত্রিক স্নায়ুতন্ত্রের অংশ।', a: [248, 169], l: [104, 220] },
    { id: 'circ', bn: 'অন্তঃস্থ বৃত্তাকার পেশি', lb: 'বৃত্তাকার পেশি', en: 'Inner circular muscle', fn: 'সংকোচনে নালির ব্যাস কমায় — পেরিস্ট্যালসিস ও খণ্ডায়ন (সেগমেন্টেশন) চলনে মূল ভূমিকা; কয়েক জায়গায় পুরু হয়ে স্ফিংক্টার গঠন করে।', a: [210, 207], l: [104, 238] },
    { id: 'auer', bn: 'আওয়ারবাখের স্নায়ুজালক (মায়েন্টেরিক)', lb: 'আওয়ারবাখ জালক', en: "Auerbach's plexus", fn: 'দুই পেশিস্তরের মাঝের স্নায়ুগুচ্ছ — পেশির সংকোচনের ছন্দ ও পেরিস্ট্যালসিস নিয়ন্ত্রণ করে।', a: [186, 229], l: [104, 254] },
    { id: 'lon', bn: 'বহিঃস্থ অনুদৈর্ঘ্য পেশি', lb: 'অনুদৈর্ঘ্য পেশি', en: 'Outer longitudinal muscle', fn: 'সংকোচনে নালি খাটো হয় — বৃত্তাকার পেশির সাথে মিলে খাদ্য সামনে ঠেলে। এ প্রস্থচ্ছেদে তন্তুগুলো আড়াআড়ি কাটা, তাই বিন্দুর মতো দেখায়।', a: [214, 243], l: [104, 272] },
    { id: 'ser', bn: 'সেরোসা', en: 'Serosa', fn: 'সবচেয়ে বাইরের পাতলা যোজক টিস্যু ও চ্যাপ্টা মেসোথেলিয়াম (ভিসেরাল পেরিটোনিয়াম) — পিচ্ছিল রস ঝরিয়ে ঘর্ষণ কমায়। অন্ননালিতে এর বদলে অ্যাডভেন্টিশিয়া।', a: [240, 258], l: [104, 290] }
  ]
}));
})();
