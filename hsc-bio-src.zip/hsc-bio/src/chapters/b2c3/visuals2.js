/* ═══════════════════════════════════════════════════════════════════
   visuals2 — মুখগহ্বর, দাঁত, লালাগ্রন্থি, গলাধঃকরণ: oralCavity, toothLS, dentition, salivaryGl, amylaseAct, swallow
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
const sm = (p, c, k) => B.smooth(p, c, k);

/* মাথা ও গলার মধ্যচ্ছেদ (সাজিটাল) — মুখ বাঁ দিকে */
const H = {
  skin: [[150, 8], [118, 22], [104, 50], [98, 74], [90, 96], [100, 106], [106, 110], [104, 118], [98, 127], [103, 135], [99, 142], [104, 152], [106, 166], [116, 180], [138, 190], [156, 198], [164, 240], [168, 330], [316, 330], [312, 240], [318, 160], [322, 90], [310, 40], [270, 12], [210, 4]],
  nasal: [[108, 104], [120, 80], [150, 66], [196, 66], [220, 80], [224, 104], [212, 113], [112, 113]],
  palate: [[109, 116], [150, 114], [198, 115], [198, 121], [150, 120], [112, 121]],
  soft: [[198, 115], [212, 118], [224, 128], [231, 142], [229, 150], [224, 147], [217, 135], [206, 125], [198, 121]],
  oral: [[110, 124], [150, 121], [198, 122], [214, 127], [226, 140], [224, 152], [214, 141], [190, 129], [160, 125], [130, 129], [112, 134]],
  tongue: [[111, 139], [130, 130], [160, 126], [190, 130], [212, 142], [222, 160], [222, 178], [219, 191], [196, 193], [170, 187], [142, 177], [124, 165], [116, 151]],
  phar: [[222, 82], [238, 86], [245, 120], [247, 170], [245, 220], [240, 262], [228, 264], [225, 236], [224, 206], [224, 186], [224, 160], [232, 148], [232, 132], [226, 118], [224, 104]],
  lar: [[203, 199], [219, 197], [222, 236], [222, 270], [204, 270], [200, 236]],
  mand: [[103, 147], [112, 143], [119, 153], [121, 170], [115, 181], [106, 177], [102, 161]]
};
V.oralCavity = Object.assign({ t: 'মুখগহ্বর ও গলবিল (মধ্যচ্ছেদ)', k: ['2d', 'anim', 'int', 'quiz'], cap: 'মাথা ও গলার মাঝ বরাবর লম্বচ্ছেদ (সাজিটাল সেকশন), মুখ বাঁ দিকে। গলবিল হলো খাদ্য ও বায়ুর মিলনস্থল — কমলা ড্যাশ খাদ্যের পথ (মুখ → গলবিল → অন্ননালি), নীল ড্যাশ বায়ুর পথ (নাক → গলবিল → স্বরযন্ত্র → শ্বাসনালি)। শ্বাসনালি সামনে, অন্ননালি তার পেছনে। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 330, label: 'মুখগহ্বর ও গলবিলের মধ্যচ্ছেদ', idle: true,
  art(g, C, part) {
    const fl = B.TS('sub'), bo = B.TS('bone'), mu = B.TS('muc'), lum = C.dark ? FK.alpha('#fff', .06) : '#fbfdff';
    /* মাথার টিস্যু (কাটা তল) */
    E('path', { d: sm(H.skin, true, .45), fill: FK.alpha(fl.c, .75), stroke: B.TS('skin').dk, 'stroke-width': 1.2 }, g);
    E('path', { d: sm(H.skin, true, .45), fill: B.pat(g, 'dot', FK.alpha(fl.dk, .25), { s: 6, w: .6 }) }, g);
    /* করোটির তলদেশ */
    E('path', { d: sm([[160, 40], [200, 30], [262, 40], [300, 64], [292, 92], [252, 86], [222, 70], [196, 60], [150, 58]], true), fill: B.lin(g, 'bone', 80), stroke: bo.dk, 'stroke-width': .8 }, g);
    /* কশেরুকা ও সুষুম্নাকাণ্ড */
    const vt = part('vert');
    for (let i = 0; i < 9; i++) { const y = 98 + i * 26; E('rect', { x: 258, y, width: 30, height: 21, rx: 4, fill: B.lin(vt, 'bone', 0), stroke: bo.dk, 'stroke-width': .8 }, vt); E('rect', { x: 260, y: y + 21, width: 26, height: 5, fill: B.TS('cart').c, stroke: B.TS('cart').dk, 'stroke-width': .4 }, vt); E('path', { d: `M302 ${y + 4}l14 6l-2 8l-12 -4Z`, fill: bo.c, stroke: bo.dk, 'stroke-width': .6 }, vt); }
    E('rect', { x: 290, y: 92, width: 10, height: 238, fill: B.TS('nrv').c, stroke: B.TS('nrv').dk, 'stroke-width': .6 }, g);
    /* গলবিলের পেছনের পেশি */
    E('path', { d: sm([[238, 84], [246, 120], [248, 170], [246, 220], [242, 262], [244, 330], [256, 330], [256, 220], [256, 120], [252, 86]], true), fill: B.lin(g, 'mus', 0), stroke: B.TS('mus').dk, 'stroke-width': .6 }, g);
    /* নাসাগহ্বর ও কঙ্কা */
    const na = part('nasal'); E('path', { d: sm(H.nasal, true, .5), fill: lum, stroke: mu.dk, 'stroke-width': 1 }, na);
    [[150, 78, 34], [160, 92, 40], [168, 105, 34]].forEach(([x, y, w]) => E('path', { d: `M${x - w / 2} ${y}q${w / 2} ${-7} ${w} 0q-${w * .3} 5 -${w} 1Z`, fill: B.lin(na, 'muc', 90), stroke: mu.dk, 'stroke-width': .7 }, na));
    /* গলবিল */
    const ph = part('phar'); E('path', { d: sm(H.phar, true, .45), fill: lum, stroke: mu.dk, 'stroke-width': 1 }, ph);
    /* মুখগহ্বর */
    const oc = part('oral'); E('path', { d: sm(H.oral, true, .5), fill: lum, stroke: mu.dk, 'stroke-width': .9 }, oc);
    /* শক্ত তালু ও নরম তালু */
    const hp = part('hard'); E('path', { d: sm(H.palate, true, .3), fill: B.lin(hp, 'bone', 90), stroke: bo.dk, 'stroke-width': .9 }, hp);
    const sp = part('soft'); E('path', { d: sm(H.soft, true, .5), fill: B.vol(sp, 'muc'), stroke: mu.dk, 'stroke-width': .9 }, sp);
    const uv = part('uvula'); E('ellipse', { cx: 229, cy: 147, rx: 3.6, ry: 4.6, fill: B.vol(uv, 'muc'), stroke: mu.dk, 'stroke-width': .8 }, uv);
    /* চোয়াল ও দাঁত */
    const md = part('mand'); E('path', { d: sm(H.mand, true, .45), fill: B.lin(md, 'bone', 0), stroke: bo.dk, 'stroke-width': .9 }, md); E('path', { d: sm(H.mand.map(([x, y]) => [x * .8 + 112 * .2, y * .8 + 162 * .2]), true), fill: FK.alpha(bo.dk, .18), stroke: 'none' }, md);
    const th = part('teeth'), en = B.TS('ena');
    E('path', { d: 'M104 116C109 116 110 121 109 128L107 135C105 136 103 135 102 132L101 120C101 117 102 116 104 116Z', fill: B.lin(th, 'ena', 0), stroke: en.dk, 'stroke-width': .8 }, th);
    E('path', { d: 'M103 137C106 136 108 138 108 141L109 152C108 154 104 154 103 152L101 142C101 139 101 137 103 137Z', fill: B.lin(th, 'ena', 0), stroke: en.dk, 'stroke-width': .8 }, th);
    /* ঠোঁট */
    const li = part('lips'); E('path', { d: 'M98 127C95 130 97 134 103 135C101 131 101 128 104 124Z', fill: B.TS('gum').c, stroke: B.TS('gum').dk, 'stroke-width': .7 }, li); E('path', { d: 'M99 142C96 139 98 136 103 136C102 139 102 142 104 146Z', fill: B.TS('gum').c, stroke: B.TS('gum').dk, 'stroke-width': .7 }, li);
    /* জিহ্বা — পেশির তন্তু পাখার মতো চোয়াল থেকে */
    const tg = part('tongue'), td = sm(H.tongue, true, .5); E('path', { d: td, fill: B.vol(tg, 'tng', { cx: .4, cy: .2 }), stroke: B.TS('tng').dk, 'stroke-width': 1 }, tg);
    const cp = B.clip(tg, 'tong', td), tf = E('g', { 'clip-path': cp }, tg); let dd = ''; for (let i = 0; i < 12; i++) { const a = -150 + i * 11, r = a * PI / 180; dd += `M120 172L${(120 + 120 * Math.cos(r)).toFixed(1)} ${(172 + 120 * Math.sin(r)).toFixed(1)}`; } E('path', { d: dd, stroke: FK.alpha(B.TS('tng').dk, .35), 'stroke-width': .7 }, tf);
    E('path', { d: 'M126 138Q160 130 196 138', stroke: FK.alpha('#fff', .4), 'stroke-width': 1.5, fill: 'none' }, tg);
    /* অধোজিহ্বা লালাগ্রন্থি */
    const sl = part('subl'); B.organ(sl, sm([[124, 170], [138, 172], [140, 180], [128, 182], [120, 178]], true), 'pan', { pat: 'fat', pa: .4, po: { s: 3.4, w: .45 } });
    /* হাইঅয়েড ও এপিগ্লটিস */
    E('ellipse', { cx: 196, cy: 204, rx: 6, ry: 3.4, fill: B.lin(g, 'bone', 0), stroke: bo.dk, 'stroke-width': .8 }, g);
    const ep = part('epi'); E('path', { d: 'M214 200C216 190 222 180 230 175C232 179 228 188 222 198C220 202 216 203 214 200Z', fill: B.lin(ep, 'cart', 0), stroke: B.TS('cart').dk, 'stroke-width': .9 }, ep);
    /* স্বরযন্ত্র ও শ্বাসনালি */
    const lx = part('lar'); E('path', { d: sm(H.lar, true, .4), fill: lum, stroke: mu.dk, 'stroke-width': .9 }, lx);
    E('path', { d: 'M190 214L196 214L200 252L194 254Z', fill: B.lin(lx, 'cart', 0), stroke: B.TS('cart').dk, 'stroke-width': .8 }, lx);
    E('path', { d: 'M201 234l8 3l-8 3ZM222 234l-6 3l6 3Z', fill: mu.c, stroke: mu.dk, 'stroke-width': .6 }, lx);
    const tr = part('trach'); E('rect', { x: 204, y: 270, width: 18, height: 60, fill: lum, stroke: mu.dk, 'stroke-width': .9 }, tr);
    for (let y = 274; y < 330; y += 9) E('path', { d: `M204 ${y}h-6v5h6`, fill: B.TS('cart').c, stroke: B.TS('cart').dk, 'stroke-width': .7 }, tr);
    /* অন্ননালি — বন্ধ অবস্থায় চ্যাপ্টা নল */
    const es = part('eso'); E('path', { d: 'M226 264L242 263L244 330L230 330Z', fill: B.lin(es, 'eso', 0), stroke: B.TS('eso').dk, 'stroke-width': .9 }, es); E('path', { d: 'M234 266L237 330', stroke: B.TS('eso').dk, 'stroke-width': .9, 'stroke-dasharray': '3 2' }, es);
    B.tx(g, 236, 98, 'নাসাগলবিল', { fs: 8, a: 'middle', c: C.mu }); B.tx(g, 236, 176, 'মুখগলবিল', { fs: 8, a: 'middle', c: C.mu }); B.tx(g, 233, 252, 'স্বরগলবিল', { fs: 8, a: 'middle', c: C.mu });
  },
  idle(g, C, t) {
    const off = (-t * 22).toFixed(1);
    E('path', { d: sm([[106, 129], [150, 124], [200, 126], [232, 158], [236, 200], [234, 240], [235, 268], [237, 326]]), stroke: '#e07b12', 'stroke-width': 2, fill: 'none', 'stroke-dasharray': '6 5', 'stroke-dashoffset': off, opacity: .9 }, g);
    E('path', { d: sm([[100, 108], [150, 94], [210, 92], [236, 110], [238, 150], [228, 180], [212, 212], [212, 250], [213, 326]]), stroke: '#2f6fd6', 'stroke-width': 2, fill: 'none', 'stroke-dasharray': '6 5', 'stroke-dashoffset': off, opacity: .85 }, g);
  },
  parts: [
    { id: 'nasal', bn: 'নাসাগহ্বর', en: 'Nasal cavity', fn: 'বায়ু প্রবেশের পথ; কঙ্কা (টার্বিনেট) বায়ুকে গরম, আর্দ্র ও পরিষ্কার করে। শক্ত তালু একে মুখগহ্বর থেকে আলাদা রাখে — তাই চিবানোর সময়ও শ্বাস নেওয়া যায়।', a: [160, 86], l: [80, 70] },
    { id: 'lips', bn: 'ঠোঁট', en: 'Lips', fn: 'মুখছিদ্র ঘিরে পেশিময় ভাঁজ (অরবিকুলারিস অরিস পেশি) — খাদ্য গ্রহণ ও মুখে ধরে রাখা।', a: [99, 132], l: [80, 104] },
    { id: 'teeth', bn: 'দাঁত (কর্তন দাঁত)', lb: 'দাঁত', en: 'Teeth', fn: 'খাদ্য কাটা, ছেঁড়া ও চিবানো — যান্ত্রিক পরিপাক, যা খাদ্যের তলের ক্ষেত্রফল বাড়িয়ে এনজাইমের কাজ সহজ করে।', a: [104, 125], l: [80, 128] },
    { id: 'mand', bn: 'নিম্নচোয়াল (ম্যান্ডিবল)', lb: 'নিম্নচোয়াল', en: 'Mandible', fn: 'চলনক্ষম একমাত্র মুখাস্থি; নিচের দাঁত বহন করে এবং চর্বণ পেশির টানে ওঠানামা করে।', a: [112, 166], l: [80, 156] },
    { id: 'subl', bn: 'অধোজিহ্বা লালাগ্রন্থি', lb: 'অধোজিহ্বা গ্রন্থি', en: 'Sublingual gland', fn: 'জিহ্বার নিচে মুখের মেঝেতে সবচেয়ে ছোট লালাগ্রন্থি — প্রধানত শ্লেষ্মাযুক্ত (মিউকাস) লালা; একাধিক ছোট নালি দিয়ে খোলে।', a: [130, 177], l: [80, 182] },
    { id: 'oral', bn: 'মুখগহ্বর', en: 'Oral cavity', fn: 'ঠোঁট থেকে গলবিল পর্যন্ত গহ্বর — চর্বণ, লালার সাথে মিশ্রণ ও শ্বেতসার পরিপাকের শুরু এখানে।', a: [160, 123], l: [80, 206] },
    { id: 'hard', bn: 'শক্ত তালু', en: 'Hard palate', fn: 'ম্যাক্সিলা ও প্যালাটাইন অস্থিতে গঠিত মুখগহ্বরের ছাদ — জিহ্বা এর গায়ে খাদ্য চেপে বোলাস তৈরি করে।', a: [150, 117], l: [80, 230] },
    { id: 'tongue', bn: 'জিহ্বা', en: 'Tongue', fn: 'ঐচ্ছিক কঙ্কাল পেশির অঙ্গ — খাদ্য নাড়াচাড়া, লালার সাথে মেশানো, বোলাস তৈরি ও গলবিলে ঠেলে দেওয়া; স্বাদকোরকে স্বাদ গ্রহণ ও কথা বলা।', a: [168, 152], l: [80, 254] },
    { id: 'soft', bn: 'নরম তালু', en: 'Soft palate', fn: 'শক্ত তালুর পেছনের পেশিময় অংশ — গলাধঃকরণের সময় ওপরে উঠে নাসাগলবিলের পথ বন্ধ করে, তাই খাদ্য নাকে যায় না।', a: [214, 126], l: [292, 132] },
    { id: 'uvula', bn: 'আলজিভ (ইউভিউলা)', lb: 'আলজিভ', en: 'Uvula', fn: 'নরম তালুর পেছন থেকে ঝুলে থাকা ক্ষুদ্র মাংসল অংশ — নরম তালুর সাথে নাসাপথ বন্ধে সাহায্য করে।', a: [229, 149], l: [292, 154] },
    { id: 'phar', bn: 'গলবিল (ফ্যারিংস)', lb: 'গলবিল', en: 'Pharynx', fn: 'প্রায় 12–14 সেমি লম্বা পেশিময় নালি — নাসাগলবিল, মুখগলবিল ও স্বরগলবিল তিন অংশে বিভক্ত; খাদ্য ও বায়ুর মিলিত পথ।', a: [240, 200], l: [292, 186] },
    { id: 'epi', bn: 'এপিগ্লটিস (উপজিহ্বা)', lb: 'এপিগ্লটিস', en: 'Epiglottis', fn: 'জিহ্বার গোড়ার পেছনে পাতার মতো স্থিতিস্থাপক তরুণাস্থি — গলাধঃকরণে স্বরযন্ত্র ওপরে ওঠে ও এপিগ্লটিস নিচে নেমে স্বরযন্ত্রের মুখ ঢেকে দেয়।', a: [224, 186], l: [292, 214] },
    { id: 'lar', bn: 'স্বরযন্ত্র (ল্যারিংস)', lb: 'স্বরযন্ত্র', en: 'Larynx', fn: 'তরুণাস্থির কাঠামো (থাইরয়েড, ক্রিকয়েড ইত্যাদি) ও স্বররজ্জু — শুধু বায়ুর পথ।', a: [196, 236], l: [80, 278] },
    { id: 'trach', bn: 'শ্বাসনালি (ট্রাকিয়া)', lb: 'শ্বাসনালি', en: 'Trachea', fn: 'C আকৃতির তরুণাস্থির বলয়ে খোলা থাকা বায়ুনালি — অন্ননালির ঠিক সামনে।', a: [208, 300], l: [80, 304] },
    { id: 'eso', bn: 'অন্ননালি', en: 'Oesophagus', fn: 'শ্বাসনালির পেছনে; খাদ্য না থাকলে চ্যাপ্টা হয়ে বন্ধ থাকে, বোলাস এলে প্রসারিত হয়।', a: [236, 300], l: [292, 300] },
    { id: 'vert', bn: 'গ্রীবা কশেরুকা', lb: 'কশেরুকা', en: 'Cervical vertebrae', fn: 'গলবিল ও অন্ননালির পেছনে মেরুদণ্ডের গ্রীবা অংশ (C1–C7); পেছনে সুষুম্নাকাণ্ড (হলুদ)।', a: [272, 262], l: [292, 274] }
  ]
}));

/* ═════════ দাঁতের লম্বচ্ছেদ (পেষণ দাঁত) ═════════ */
V.toothLS = Object.assign({ t: 'দাঁতের লম্বচ্ছেদ', k: ['2d', 'anim', 'int', 'quiz'], cap: 'মাড়ি ও চোয়ালের অস্থিসহ একটি পেষণ দাঁতের (মোলার) লম্বচ্ছেদ — মুকুট (ক্রাউন), গ্রীবা (নেক) ও মূল (রুট)। এনামেল দেহের সবচেয়ে শক্ত পদার্থ (প্রায় 96% খনিজ — হাইড্রক্সিঅ্যাপাটাইট); নিচে ডেন্টিন, মাঝে রক্তনালি ও স্নায়ুযুক্ত পাল্প। পাল্পের রক্তনালিতে রক্ত চলছে। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 330, label: 'দাঁতের লম্বচ্ছেদ', idle: true,
  art(g, C, part) {
    const en = B.TS('ena'), de = B.TS('den'), pu = B.TS('pulp'), ce = B.TS('cem'), gu = B.TS('gum'), bo = B.TS('bone');
    /* চোয়ালের অস্থি (স্পঞ্জি) */
    const bn = part('bone'); const bd = sm([[96, 176], [130, 168], [150, 172], [210, 172], [230, 168], [264, 176], [272, 250], [268, 318], [92, 318], [88, 250]], true);
    E('path', { d: bd, fill: B.lin(bn, 'bone', 90), stroke: bo.dk, 'stroke-width': 1 }, bn); E('path', { d: bd, fill: B.pat(bn, 'fat', FK.alpha(bo.dk, .45), { s: 7, w: .7 }) }, bn);
    /* মাড়ি */
    const gm = part('gum'); E('path', { d: sm([[84, 186], [98, 160], [120, 150], [136, 146], [140, 160], [134, 180], [96, 186]], true), fill: B.vol(gm, 'gum'), stroke: gu.dk, 'stroke-width': .9 }, gm);
    E('path', { d: sm([[276, 186], [262, 160], [240, 150], [224, 146], [220, 160], [226, 180], [264, 186]], true), fill: B.vol(gm, 'gum'), stroke: gu.dk, 'stroke-width': .9 }, gm);
    /* দাঁতের বাইরের রেখা (দুই মূলসহ) */
    const outer = [[134, 60], [150, 44], [166, 54], [180, 46], [194, 54], [210, 44], [226, 60], [230, 100], [226, 140], [222, 160], [224, 200], [218, 250], [206, 296], [196, 300], [190, 250], [184, 214], [180, 210], [176, 214], [170, 250], [164, 300], [154, 296], [142, 250], [136, 200], [138, 160], [134, 140], [130, 100]];
    const pdm = part('pdl'); E('path', { d: sm(outer.slice(9, 24).map(([x, y]) => [x + (x > 180 ? 4 : -4), y + 2]), false, .4), fill: 'none', stroke: FK.alpha(B.TS('mus').c, .7), 'stroke-width': 5, 'stroke-linecap': 'round' }, pdm);
    const cm = part('cem'); E('path', { d: sm(outer, true, .4), fill: B.lin(cm, 'cem', 0), stroke: ce.dk, 'stroke-width': 1 }, cm);
    /* ডেন্টিন */
    const inner1 = outer.map(([x, y]) => [180 + (x - 180) * .93, 170 + (y - 170) * .95]);
    const dn = part('den'); E('path', { d: sm(inner1, true, .4), fill: B.lin(dn, 'den', 90), stroke: de.dk, 'stroke-width': .7 }, dn);
    const dcp = B.clip(dn, 'dent', sm(inner1, true, .4)), dg = E('g', { 'clip-path': dcp }, dn); let tub = ''; for (let i = 0; i < 26; i++) { const x = 138 + i * 3.4; tub += `M${x} 70Q${180 + (x - 180) * .6} 150 ${x + (x - 180) * .05} 230`; } E('path', { d: tub, stroke: FK.alpha(de.dk, .25), 'stroke-width': .5, fill: 'none' }, dg);   /* ডেন্টিনের নালিকা */
    /* এনামেল (কেবল মুকুটে) */
    const enP = [[130, 100], [134, 60], [150, 44], [166, 54], [180, 46], [194, 54], [210, 44], [226, 60], [230, 100], [227, 136], [216, 134], [216, 102], [212, 66], [204, 58], [194, 64], [180, 58], [166, 64], [156, 58], [148, 66], [144, 102], [144, 134], [133, 136]];
    const em = part('ena'); E('path', { d: sm(enP, true, .35), fill: B.lin(em, 'ena', 0), stroke: en.dk, 'stroke-width': 1 }, em);
    E('path', { d: 'M150 50Q156 46 162 52M198 52Q204 46 208 50', stroke: '#fff', 'stroke-width': 2, fill: 'none', opacity: .8 }, em);
    /* পাল্প গহ্বর ও মূলনালি */
    const pulp = [[160, 96], [166, 82], [174, 92], [186, 92], [194, 82], [200, 96], [202, 140], [198, 170], [204, 210], [200, 260], [198, 288], [194, 290], [190, 250], [188, 214], [180, 206], [172, 214], [170, 250], [166, 290], [162, 288], [160, 260], [156, 210], [162, 170], [158, 140]];
    const pl = part('pulp'); E('path', { d: sm(pulp, true, .4), fill: B.vol(pl, 'pulp', { cx: .5, cy: .3 }), stroke: pu.dk, 'stroke-width': .8 }, pl);
    const rc = part('canal'); E('rect', { x: 158, y: 230, width: 12, height: 60, fill: 'transparent' }, rc); E('rect', { x: 190, y: 230, width: 12, height: 60, fill: 'transparent' }, rc);
    /* রক্তনালি ও স্নায়ু (অ্যাপেক্সের ছিদ্র দিয়ে) */
    const nv = part('nv');
    [[-3, 'art'], [0, 'nrv'], [3, 'vein']].forEach(([dx, k]) => { const t = B.TS(k); E('path', { d: sm([[164 + dx, 316], [164 + dx * .6, 290], [166 + dx * .5, 250], [168 + dx * .4, 210], [176 + dx, 150], [174 + dx, 100]]) + sm([[196 + dx, 316], [196 + dx * .6, 290], [194 + dx * .5, 250], [192 + dx * .4, 210], [184 + dx, 150], [186 + dx, 100]]).replace('M', 'M'), stroke: t.c, 'stroke-width': 1.2, fill: 'none' }, nv); });
    /* সীমারেখা ও বন্ধনী */
    E('path', { d: 'M108 136H128M232 136H252', stroke: C.mu, 'stroke-width': .8, 'stroke-dasharray': '3 2' }, g); E('path', { d: 'M108 168H128M232 168H252', stroke: C.mu, 'stroke-width': .8, 'stroke-dasharray': '3 2' }, g);
    [[42, 136, 'মুকুট'], [136, 168, 'গ্রীবা'], [168, 302, 'মূল']].forEach(([a, b, s]) => { E('path', { d: `M60 ${a + 1}h-4V${b - 1}h4`, stroke: C.mu, 'stroke-width': 1, fill: 'none' }, g); const t = B.tx(g, 0, 0, s, { fs: 10, a: 'middle', w: 600 }); t.setAttribute('transform', `translate(48 ${(a + b) / 2}) rotate(-90)`); });
  },
  idle(g, C, t) { [0, 1].forEach(s => { for (let k = 0; k < 3; k++) { const u = ((t * .25 + k / 3) % 1), y = 316 - u * 210, x = s ? 196 - u * 8 - (u > .55 ? (u - .55) * 22 : 0) + 3 : 164 + u * 8 + (u > .55 ? (u - .55) * 22 : 0) - 3; B.rbc(g, x, y, 1.7, .9); } }); },
  parts: [
    { id: 'ena', bn: 'এনামেল', en: 'Enamel', fn: 'মুকুটের বাইরের আবরণ — দেহের সবচেয়ে শক্ত পদার্থ, প্রায় 96% খনিজ (ক্যালসিয়াম হাইড্রক্সিঅ্যাপাটাইট); কোষহীন, তাই ক্ষয় হলে আর তৈরি হয় না। অ্যামেলোব্লাস্ট কোষ দাঁত ওঠার আগেই এটি তৈরি করে।', a: [222, 84], l: [296, 64] },
    { id: 'den', bn: 'ডেন্টিন', en: 'Dentine', fn: 'দাঁতের মূল উপাদান — প্রায় 70% খনিজ; অসংখ্য সূক্ষ্ম ডেন্টিনাল নালিকায় ওডোন্টোব্লাস্ট কোষের প্রবর্ধন থাকে, তাই ডেন্টিন উন্মুক্ত হলে দাঁত শিরশির করে।', a: [210, 150], l: [296, 92] },
    { id: 'pulp', bn: 'পাল্প গহ্বর', lb: 'পাল্প', en: 'Pulp cavity', fn: 'দাঁতের কেন্দ্রের নরম যোজক টিস্যু — রক্তনালি, স্নায়ু ও ওডোন্টোব্লাস্ট কোষ থাকে; দাঁতকে পুষ্টি ও সংবেদন দেয়।', a: [190, 120], l: [296, 120] },
    { id: 'gum', bn: 'মাড়ি (জিঞ্জিভা)', lb: 'মাড়ি', en: 'Gum (gingiva)', fn: 'গ্রীবার চারপাশের মিউকাস ঝিল্লি ও যোজক টিস্যু — দাঁতের গোড়া ঢেকে রাখে।', a: [248, 164], l: [296, 148] },
    { id: 'canal', bn: 'মূলনালি', en: 'Root canal', fn: 'মূলের ভেতর দিয়ে পাল্প গহ্বরের সরু অংশ — মূলের অগ্রভাগের ছিদ্র (অ্যাপিক্যাল ফোরামেন) দিয়ে রক্তনালি ও স্নায়ু ঢোকে।', a: [196, 262], l: [296, 242] },
    { id: 'nv', bn: 'রক্তনালি ও স্নায়ু', lb: 'রক্তনালি ও স্নায়ু', en: 'Blood vessels & nerve', fn: 'ধমনি (লাল), শিরা (নীল) ও স্নায়ু (হলুদ) অ্যাপিক্যাল ফোরামেন দিয়ে পাল্পে ঢুকে দাঁতকে জীবিত রাখে।', a: [198, 312], l: [296, 304] },
    { id: 'cem', bn: 'সিমেন্টাম', en: 'Cementum', fn: 'মূলের ডেন্টিন ঢাকা পাতলা অস্থিসদৃশ স্তর — পেরিওডন্টাল লিগামেন্টের তন্তুগুলো এতে আটকে থাকে।', a: [219, 238], l: [296, 210] },
    { id: 'pdl', bn: 'পেরিওডন্টাল লিগামেন্ট', lb: 'পেরিওডন্টাল', en: 'Periodontal ligament', fn: 'সিমেন্টাম ও চোয়ালের অস্থির মাঝের তন্তুময় স্তর — দাঁতকে কোটরে (সকেট) আটকে রাখে ও চিবানোর ধাক্কা শোষণ করে।', a: [227, 196], l: [296, 180] },
    { id: 'bone', bn: 'চোয়ালের অস্থি (অ্যালভিওলার অস্থি)', lb: 'চোয়ালের অস্থি', en: 'Alveolar bone', fn: 'দাঁতের কোটর গঠনকারী অস্থি — দাঁত এতে গমফোসিস ধরনের সন্ধিতে বসানো থাকে।', a: [250, 286], l: [296, 274] }
  ]
}));
})();

/* ═════════ দাঁতের বিন্যাস (ওপরের চোয়াল, চর্বণ তল থেকে দেখা) ═════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
/* মেসিওডিস্টাল প্রস্থ (মিমি) — ঊর্ধ্বচোয়াল */
const SET = {
  perm: { teeth: [['I', 8.5], ['I', 6.5], ['C', 7.5], ['P', 7], ['P', 6.5], ['M', 10], ['M', 9], ['M', 8.5]], k: 2.9, f: '2 1 2 3', n: 32 },
  milk: { teeth: [['I', 6.5], ['I', 5.2], ['C', 7], ['M', 7.3], ['M', 8.2]], k: 2.9, f: '2 1 0 2', n: 20 }
};
const INFO = {
  perm: { I: ['কর্তন দাঁত (ইনসিসর)', 'প্রতি চোয়ালের প্রতি পাশে 2টি, মোট 8টি', 'বাটালির মতো ধারালো কিনারা — খাদ্য কাটা', 'ওঠে 7–9 বছরে'], C: ['ছেদন দাঁত (ক্যানাইন)', 'প্রতি পাশে 1টি, মোট 4টি', 'একটি সূচালো চূড়া, দীর্ঘতম মূল — খাদ্য ছেঁড়া', 'ওঠে 11–12 বছরে'], P: ['অগ্রপেষণ দাঁত (প্রিমোলার)', 'প্রতি পাশে 2টি, মোট 8টি; দুধদাঁতে নেই', 'দুটি চূড়া (বাইকাসপিড) — খাদ্য ছেঁচা ও পেষা', 'ওঠে 10–12 বছরে'], M: ['পেষণ দাঁত (মোলার)', 'প্রতি পাশে 3টি, মোট 12টি', 'চওড়া তল, 4–5টি চূড়া — খাদ্য পিষে মিহি করা; তৃতীয়টি "আক্কেল দাঁত"', 'প্রথম মোলার 6–7, দ্বিতীয় 12–13, তৃতীয় 17–21 বছরে'] },
  milk: { I: ['দুধের কর্তন দাঁত', 'প্রতি পাশে 2টি, মোট 8টি', 'খাদ্য কাটা', 'ওঠে 6–13 মাসে — সাধারণত প্রথম দাঁত'], C: ['দুধের ছেদন দাঁত', 'প্রতি পাশে 1টি, মোট 4টি', 'খাদ্য ছেঁড়া', 'ওঠে 16–22 মাসে'], M: ['দুধের পেষণ দাঁত', 'প্রতি পাশে 2টি, মোট 8টি', 'খাদ্য পেষা; পরে এদের জায়গায় স্থায়ী প্রিমোলার ওঠে', 'ওঠে 13–33 মাসে'] }
};
const ARCH = [[180, 44], [154, 49], [133, 61], [117, 80], [106, 104], [99, 132], [95, 160], [93, 186], [93, 200]];
const LAYOUT = {}; ['perm', 'milk'].forEach(ty => {
  const S = SET[ty], D = B.dense(ARCH, 10), cum = [0]; for (let i = 1; i < D.length; i++) cum.push(cum[i - 1] + Math.hypot(D[i][0] - D[i - 1][0], D[i][1] - D[i - 1][1]));
  const at = L => { let i = 1; while (i < cum.length - 1 && cum[i] < L) i++; const k = (L - cum[i - 1]) / (cum[i] - cum[i - 1] || 1), x = D[i - 1][0] + (D[i][0] - D[i - 1][0]) * k, y = D[i - 1][1] + (D[i][1] - D[i - 1][1]) * k; return [x, y, Math.atan2(D[i][1] - D[i - 1][1], D[i][0] - D[i - 1][0])]; };
  let L = 1; const out = []; S.teeth.forEach(([t, w], i) => { const ww = w * S.k * (ty === 'milk' ? .92 : 1), [x, y, a] = at(L + ww / 2); out.push({ t, i, x, y, a, w: ww }); L += ww + .2; });
  LAYOUT[ty] = out;
});
const crown = (g, t, x, y, a, w, on) => {
  const en = B.TS('ena'), ang = a * 180 / PI, gg = E('g', { transform: `translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${ang.toFixed(1)})` }, g), h = t === 'I' ? w * .78 : t === 'C' ? w * 1.02 : t === 'P' ? w * 1.35 : w * 1.12;
  const fill = on ? '#fff6c8' : B.vol(g, 'ena', { cx: .4, cy: .35 }), st = on ? '#d39a00' : en.dk, sw = on ? 1.6 : .9;
  if (t === 'I') { E('path', { d: `M${-w / 2} ${-h * .15}Q${-w / 2} ${-h / 2} 0 ${-h / 2}Q${w / 2} ${-h / 2} ${w / 2} ${-h * .15}L${w * .3} ${h / 2}Q0 ${h * .62} ${-w * .3} ${h / 2}Z`, fill, stroke: st, 'stroke-width': sw }, gg); E('path', { d: `M${-w * .4} ${-h * .3}Q0 ${-h * .42} ${w * .4} ${-h * .3}`, stroke: FK.alpha(en.dk, .7), 'stroke-width': .7, fill: 'none' }, gg); }
  else if (t === 'C') { E('path', { d: `M0 ${-h / 2}L${w / 2} ${-h * .05}Q${w * .3} ${h / 2} 0 ${h / 2}Q${-w * .3} ${h / 2} ${-w / 2} ${-h * .05}Z`, fill, stroke: st, 'stroke-width': sw, 'stroke-linejoin': 'round' }, gg); E('path', { d: `M0 ${-h * .32}L0 ${h * .2}M${-w * .32} 0L0 ${-h * .1}L${w * .32} 0`, stroke: FK.alpha(en.dk, .6), 'stroke-width': .7, fill: 'none' }, gg); }
  else if (t === 'P') { E('ellipse', { cx: 0, cy: 0, rx: w / 2, ry: h / 2, fill, stroke: st, 'stroke-width': sw }, gg); E('path', { d: `M${-w * .38} 0Q0 ${h * .06} ${w * .38} 0`, stroke: FK.alpha(en.dk, .75), 'stroke-width': .8, fill: 'none' }, gg); [[-1], [1]].forEach(([s]) => E('circle', { cx: 0, cy: s * h * .24, r: w * .16, fill: FK.alpha(en.dk, .12) }, gg)); }
  else { E('path', { d: B.smooth([[-w / 2, -h * .4], [w * .45, -h / 2], [w / 2, h * .38], [-w * .42, h / 2]], true, .9), fill, stroke: st, 'stroke-width': sw }, gg); E('path', { d: `M${-w * .1} ${-h * .42}L${w * .05} ${h * .44}M${-w * .42} ${-h * .02}L${w * .42} ${h * .06}`, stroke: FK.alpha(en.dk, .75), 'stroke-width': .8, fill: 'none' }, gg); [[-.22, -.22], [.22, -.24], [.22, .22], [-.2, .24]].forEach(([u, v]) => E('circle', { cx: u * w, cy: v * h, r: w * .14, fill: FK.alpha(en.dk, .13) }, gg)); }
};
V.dentition = Object.assign({}, B.seg({
  id: 'dnt', t: 'দাঁতের প্রকার ও দন্তসংকেত', H: 300, def: 'perm',
  cap: 'ওপরের চোয়ালের দাঁত চর্বণ তল থেকে দেখা (নিচের চোয়ালেও একই সংখ্যা)। মানুষের দাঁত হেটারোডন্ট (চার প্রকার), থিকোডন্ট (কোটরে বসানো) ও ডাইফিওডন্ট (জীবনে দুবার ওঠে)। দাঁতের প্রস্থ বাস্তব মাপের (মিমি) অনুপাতে। যেকোনো দাঁতে চাপ দাও; চালাও চাপলে প্রকারগুলো একে একে জ্বলবে।',
  types: { perm: ['স্থায়ী দাঁত (32)', 'স্থায়ী দাঁত — 32টি', 'দন্তসংকেত: I 2/2, C 1/1, PM 2/2, M 3/3 = প্রতি অর্ধচোয়ালে 8টি × 4 = 32টি।'], milk: ['দুধদাঁত (20)', 'দুধদাঁত — 20টি', 'দন্তসংকেত: i 2/2, c 1/1, m 2/2 = প্রতি অর্ধচোয়ালে 5টি × 4 = 20টি; প্রিমোলার ও তৃতীয় মোলার নেই। প্রায় 6 মাস থেকে 3 বছর বয়সে ওঠে, 6–12 বছরে পড়ে যায়।'] },
  art(g, C, ty, ctx) {
    const gu = B.TS('gum'), pl = B.TS('muc');
    /* তালু ও মাড়ি */
    E('path', { d: B.smooth([[180, 58], [140, 70], [118, 100], [110, 140], [110, 210], [250, 210], [250, 140], [242, 100], [220, 70]], true, .5), fill: B.vol(g, 'muc', { cx: .5, cy: .3 }), stroke: pl.dk, 'stroke-width': .8 }, g);
    let rg = ''; for (let i = 0; i < 4; i++) rg += `M${152 - i * 4} ${84 + i * 14}Q${166} ${80 + i * 14} ${176} ${88 + i * 14}M${208 + i * 4} ${84 + i * 14}Q${194} ${80 + i * 14} ${184} ${88 + i * 14}`;
    E('path', { d: rg + 'M180 70V200', stroke: FK.alpha(pl.dk, .45), 'stroke-width': .9, fill: 'none' }, g);   /* তালুর ভাঁজ (রুগি) ও মধ্যরেখা */
    E('path', { d: B.smooth(ARCH.map(([x, y]) => [x, y]).concat(ARCH.slice().reverse().map(([x, y]) => [360 - x, y])), false, .5), stroke: gu.c, 'stroke-width': 30, fill: 'none', 'stroke-linecap': 'round', opacity: .9 }, g);
    const L = LAYOUT[ty], sel = ctx.sel, hiT = ctx.hi;
    ctx.H = [];
    [-1, 1].forEach(s => L.forEach(o => { const x = s < 0 ? o.x : 360 - o.x, a = s < 0 ? o.a : PI - o.a; const on = (sel && sel.t === o.t) || hiT === o.t; crown(g, o.t, x, o.y, a, o.w, on); ctx.H.push([x, o.y, o]); }));
    /* দন্তসংকেত */
    const S = SET[ty], f = S.f.split(' '), lb = ty === 'perm' ? ['I', 'C', 'PM', 'M'] : ['i', 'c', '', 'm'];
    const y0 = 246; B.tx(g, 180, y0 - 12, 'দন্তসংকেত (এক পাশ)', { fs: 10, a: 'middle', c: C.mu });
    let x = 112; f.forEach((n, i) => { if (ty === 'milk' && i === 2) return; const on = (sel && (sel.t === ['I', 'C', 'P', 'M'][i])) || hiT === ['I', 'C', 'P', 'M'][i]; T(g, x, y0 + 6, lb[i], { fs: 12, a: 'middle', w: 650, c: on ? '#c98500' : C.fg }); T(g, x + 16, y0 - 1, n, { fs: 12, a: 'middle', c: on ? '#c98500' : C.fg }); E('path', { d: `M${x + 10} ${y0 + 3}h12`, stroke: C.fg, 'stroke-width': 1 }, g); T(g, x + 16, y0 + 15, ty === 'milk' && i === 2 ? '0' : n, { fs: 12, a: 'middle', c: on ? '#c98500' : C.fg }); x += 42; });
    T(g, 180, y0 + 40, `${f.reduce((a, b) => a + +b, 0)}/${f.reduce((a, b) => a + +b, 0)} × 2 = ${S.n}টি`, { fs: 13, a: 'middle', w: 650 });
    B.tx(g, 180, 30, 'সামনে (ঠোঁটের দিক)', { fs: 9, a: 'middle', c: C.mu }); B.tx(g, 58, 214, 'বাঁ', { fs: 9, a: 'middle', c: C.mu }); B.tx(g, 302, 214, 'ডান', { fs: 9, a: 'middle', c: C.mu });
  },
  anim(g, C, ty, t, ctx) {
    const types = ty === 'perm' ? ['I', 'C', 'P', 'M'] : ['I', 'C', 'M'], cur = types[Math.floor(t / 1.6) % types.length];
    if (ctx.hi !== cur) { ctx.hi = cur; ctx.sel = null; ctx.redraw(); const a = INFO[ty][cur]; ctx.info(`<b>${a[0]}</b> — ${a[1]}<div class="small">${a[2]}; ${a[3]}।</div>`); }
  },
  tap(x, y, ty, ctx) { const h = B.hot(ctx.H || [], x, y, 16); if (!h) return null; const o = h[2]; ctx.sel = o; ctx.hi = null; const a = INFO[ty][o.t]; return `<b>${a[0]}</b> — ${a[1]}<div class="small">${a[2]}; ${a[3]}। প্রস্থ প্রায় ${SET[ty].teeth[o.i][1]} মিমি।</div>`; }
}));

/* ═════════ লালাগ্রন্থি (পাশ থেকে) ═════════ */
V.salivaryGl = Object.assign({ t: 'তিন জোড়া লালাগ্রন্থি', k: ['2d', 'anim', 'int', 'quiz'], cap: 'মুখমণ্ডলের পাশ থেকে দেখা তিন জোড়া প্রধান লালাগ্রন্থি ও তাদের নালি (চোয়ালের অস্থি আংশিক স্বচ্ছ দেখানো)। দিনে প্রায় 1–1.5 লিটার লালা ঝরে; বিশ্রামে প্রায় 70% আসে সাবম্যান্ডিবুলার থেকে, খাবার খাওয়ার সময় প্যারোটিডের অংশ বেড়ে প্রায় অর্ধেক হয়। নালি দিয়ে লালা ঝরছে। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 300, label: 'লালাগ্রন্থি', idle: true,
  art(g, C, part) {
    const sk = B.TS('skin'), bo = B.TS('bone'), mu = B.TS('mus');
    E('path', { d: B.smooth([[150, 10], [112, 26], [96, 60], [90, 92], [76, 118], [88, 126], [88, 140], [82, 150], [90, 160], [86, 172], [92, 186], [98, 206], [122, 222], [160, 230], [190, 250], [196, 300], [330, 300], [326, 220], [320, 150], [312, 70], [280, 24], [210, 6]], true, .45), fill: FK.alpha(sk.c, .3), stroke: sk.dk, 'stroke-width': 1.1 }, g);
    /* কান */
    E('path', { d: B.smooth([[262, 104], [276, 98], [284, 116], [282, 142], [272, 156], [262, 150], [266, 132]], true), fill: FK.alpha(sk.c, .55), stroke: sk.dk, 'stroke-width': 1 }, g);
    /* চোয়াল (অস্থি, আধা স্বচ্ছ) ও ম্যাসেটার পেশি */
    E('path', { d: B.smooth([[100, 186], [120, 196], [170, 198], [208, 196], [236, 186], [246, 150], [250, 118], [240, 116], [234, 150], [224, 176], [200, 184], [160, 186], [118, 182], [102, 176]], true, .4), fill: FK.alpha(bo.c, .5), stroke: bo.dk, 'stroke-width': 1 }, g);
    E('path', { d: B.smooth([[196, 126], [232, 122], [238, 160], [226, 186], [200, 186], [190, 152]], true), fill: FK.alpha(mu.c, .35), stroke: FK.alpha(mu.dk, .6), 'stroke-width': .8 }, g);
    let mf = ''; for (let i = 0; i < 6; i++) mf += `M${198 + i * 6} 128L${194 + i * 6} 184`; E('path', { d: mf, stroke: FK.alpha(mu.dk, .3), 'stroke-width': .6 }, g);
    /* ঠোঁট ও দাঁতের সারি (ভেতরের দিকে, আভাস) */
    /* প্যারোটিড */
    const pa = part('par'), pd = B.smooth([[238, 104], [258, 100], [264, 120], [262, 150], [256, 176], [244, 186], [234, 172], [228, 148], [226, 124]], true);
    B.organ(pa, pd, 'pan', { pat: 'fat', pa: .4, po: { s: 5, w: .55 } });
    const pdu = part('pduct'); B.tube(pdu, B.smooth([[230, 136], [210, 138], [182, 140], [158, 146], [150, 154]]), 3.2, 'pan', { sw: .7 });
    /* সাবম্যান্ডিবুলার */
    const sm2 = part('smd'), sd = B.smooth([[166, 200], [192, 196], [214, 202], [218, 220], [200, 232], [174, 228], [160, 216]], true);
    B.organ(sm2, sd, 'pan', { pat: 'fat', pa: .4, po: { s: 5, w: .55 } });
    const sdu = part('sduct'); B.tube(sdu, B.smooth([[172, 206], [150, 196], [128, 190], [114, 186]]), 2.8, 'pan', { sw: .7 });
    /* সাবলিঙ্গুয়াল */
    const sl = part('sl'), sld = B.smooth([[118, 176], [146, 172], [160, 178], [150, 186], [124, 186]], true);
    B.organ(sl, sld, 'pan', { pat: 'fat', pa: .4, po: { s: 4, w: .5 } });
    [130, 140, 150].forEach(x => E('path', { d: `M${x} 174l-3 -5`, stroke: B.TS('pan').dk, 'stroke-width': .9 }, sl));
  },
  idle(g, C, t) {
    const dot = (pts, k) => { const u = ((t * .35 + k) % 1), D = B.dense(pts, 6), [x, y] = B.along(D, u); E('circle', { cx: x.toFixed(1), cy: y.toFixed(1), r: 1.8, fill: '#5fa8d9', opacity: .9 }, g); };
    [0, .33, .66].forEach(k => { dot([[230, 136], [210, 138], [182, 140], [158, 146], [150, 154]], k); dot([[172, 206], [150, 196], [128, 190], [114, 186]], k); });
  },
  parts: [
    { id: 'par', bn: 'প্যারোটিড গ্রন্থি', lb: 'প্যারোটিড', en: 'Parotid gland', fn: 'সবচেয়ে বড় লালাগ্রন্থি (প্রায় 15–30 গ্রাম), কানের সামনে ও নিচে। পাতলা, পানিমতো সেরাস লালা — অ্যামাইলেজে সমৃদ্ধ। মাম্পস ভাইরাস এ গ্রন্থিকে ফুলিয়ে দেয়।', a: [248, 140], l: [300, 70] },
    { id: 'pduct', bn: 'প্যারোটিড নালি (স্টেনসনের নালি)', lb: 'স্টেনসনের নালি', en: "Stensen's duct", fn: 'প্রায় 5 সেমি লম্বা; ম্যাসেটার পেশির ওপর দিয়ে সামনে এসে গালের পেশি ভেদ করে ওপরের দ্বিতীয় মোলারের বিপরীতে মুখগহ্বরে খোলে।', a: [184, 140], l: [300, 110] },
    { id: 'smd', bn: 'সাবম্যান্ডিবুলার গ্রন্থি', lb: 'সাবম্যান্ডিবুলার', en: 'Submandibular gland', fn: 'নিম্নচোয়ালের নিচে, আখরোটের মতো আকার (প্রায় 10–15 গ্রাম)। মিশ্র (প্রধানত সেরাস) লালা; বিশ্রাম অবস্থায় মোট লালার প্রায় 70% দেয়।', a: [196, 216], l: [300, 236] },
    { id: 'sduct', bn: 'সাবম্যান্ডিবুলার নালি (হোয়ার্টনের নালি)', lb: 'হোয়ার্টনের নালি', en: "Wharton's duct", fn: 'প্রায় 5 সেমি; জিহ্বার নিচে ফ্রেনুলামের দুই পাশে ছোট উঁচু স্থানে খোলে। লালা ঘন ও ক্যালসিয়ামসমৃদ্ধ বলে এ নালিতে পাথর (সায়ালোলিথ) বেশি হয়।', a: [138, 192], l: [62, 230], an: 'end' },
    { id: 'sl', bn: 'সাবলিঙ্গুয়াল গ্রন্থি', lb: 'সাবলিঙ্গুয়াল', en: 'Sublingual gland', fn: 'সবচেয়ে ছোট (প্রায় 2–4 গ্রাম), জিহ্বার নিচে মুখের মেঝেতে; প্রধানত শ্লেষ্মাযুক্ত (মিউকাস) লালা — 8–20টি ছোট নালি দিয়ে খোলে।', a: [140, 180], l: [62, 150], an: 'end' }
  ]
}));
})();

/* ═════════ লালা অ্যামাইলেজের কাজ ═════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
const fpH = p => Math.max(0, Math.exp(-Math.pow((p - 6.8) / 1.15, 2)) - (p < 4 ? 1 : 0)) * (p < 4 ? 0 : 1);
const fT = c => c <= 0 ? 0 : c <= 37 ? Math.pow(c / 37, 1.6) * (1 - .0 * c) : c < 60 ? Math.max(0, 1 - Math.pow((c - 37) / 23, 1.5)) : 0;
const rate = v => fpH(v.ph) * fT(v.tc);
const N = 18, X0 = 30, DXU = 17.5, Y0 = 92;
V.amylaseAct = Object.assign({}, B.seg({
  id: 'amy', t: 'লালা অ্যামাইলেজ (টায়ালিন) শ্বেতসার ভাঙে', H: 250, def: 'act',
  sl: [{ k: 'ph', l: 'pH', min: 2, max: 10, step: .1, val: 6.8, d: 1 }, { k: 'tc', l: 'তাপমাত্রা', min: 0, max: 70, step: 1, val: 37, unit: '°C' }],
  cap: 'লালার অ্যামাইলেজ শ্বেতসারের α-1,4 গ্লাইকোসাইডিক বন্ধন ভেঙে মল্টোজ (দুটি গ্লুকোজ), মল্টোট্রায়োজ ও ডেক্সট্রিন তৈরি করে; শাখার α-1,6 বন্ধন ভাঙতে পারে না। সর্বোত্তম pH প্রায় 6.8 ও তাপমাত্রা 37°C; Cl<sup>−</sup> আয়ন একে সক্রিয় করে। পাকস্থলীর অম্লে (pH 4 এর নিচে) এটি নিষ্ক্রিয় হয়। স্লাইডার বদলে চালাও চাপো।',
  types: { act: ['ক্রিয়া', 'শ্বেতসারের শিকল কাটা', 'এনজাইমের সক্রিয় স্থানে শিকলের দুটি গ্লুকোজের মাঝের বন্ধন বসে ও পানি যোগে ভাঙে (আর্দ্রবিশ্লেষণ)।'], cond: ['শর্ত', 'pH ও তাপমাত্রার প্রভাব', 'বক্ররেখায় দেখো — pH 6.8 ও 37°C এ সক্রিয়তা সর্বোচ্চ; বেশি তাপে প্রোটিনটির ত্রিমাত্রিক গঠন নষ্ট হয় (ডিন্যাচার)।'] },
  art(g, C, ty, ctx) {
    const v = ctx.v, r = rate(v), sc = B.TS('vein');
    if (ty === 'cond') {
      [[0, 'pH', 2, 10, x => fpH(x), v.ph, [2, 4, 6, 8, 10]], [1, 'তাপমাত্রা (°C)', 0, 70, x => fT(x), v.tc, [0, 20, 37, 50, 70]]].forEach(([i, lb, a, b, f, cur, ticks]) => {
        const bx = 34 + i * 170, by = 40, bw = 130, bh = 120, P = (x, y) => [bx + (x - a) / (b - a) * bw, by + bh - y * bh];
        E('path', { d: `M${bx} ${by}V${by + bh}H${bx + bw}`, stroke: C.fg, 'stroke-width': 1, fill: 'none' }, g);
        let d = ''; for (let k = 0; k <= 80; k++) { const x = a + (b - a) * k / 80, [px, py] = P(x, f(x)); d += (k ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1); }
        E('path', { d: d + `L${bx + bw} ${by + bh}L${bx} ${by + bh}Z`, fill: FK.alpha(BK.ramp(i ? 4 : 5).c, .15) }, g); E('path', { d, stroke: BK.ramp(i ? 4 : 5).dk, 'stroke-width': 2, fill: 'none' }, g);
        ticks.forEach(tk => { const [px] = P(tk, 0); T(g, px, by + bh + 13, String(tk), { fs: 9, a: 'middle', c: C.mu }); });
        const [cx, cy] = P(cur, f(cur)); E('path', { d: `M${cx} ${by + bh}V${cy}`, stroke: C.mu, 'stroke-dasharray': '3 2' }, g); E('circle', { cx, cy, r: 4.5, fill: BK.ramp(i ? 4 : 5).dk }, g);
        T(g, bx + bw / 2, by + bh + 28, lb, { fs: 10.5, a: 'middle', c: C.fg }); T(g, bx - 4, by - 8, 'সক্রিয়তা', { fs: 9.5, c: C.mu });
      });
      T(g, 180, 222, `বর্তমান শর্তে আপেক্ষিক সক্রিয়তা ≈ ${Math.round(r * 100)}%`, { fs: 12, a: 'middle', w: 650 });
      ctx.cut = null; return;
    }
    /* শ্বেতসারের শিকল (অ্যামাইলোপেকটিনের অংশ, একটি শাখাসহ) */
    ctx.r = r;
    B.tx(g, 180, 22, 'শ্বেতসার (অ্যামাইলোপেকটিনের অংশ)', { fs: 10.5, a: 'middle', c: C.mu });
    for (let i = 0; i < 4; i++) { const x = X0 + DXU * 8, y = Y0 - 18 - i * 15; if (i) E('path', { d: `M${x} ${y}V${y + 15}`, stroke: sc.dk, 'stroke-width': 1.2 }, g); }
    E('path', { d: `M${X0 + DXU * 8} ${Y0}V${Y0 - 18}`, stroke: '#c98500', 'stroke-width': 2 }, g); B.tx(g, X0 + DXU * 8 + 6, Y0 - 6, 'α-1,6', { fs: 8, c: '#c98500' });
    ctx.chainY = Y0;
    T(g, 180, 220, 'মল্টোজ', { fs: 10, a: 'middle', c: C.mu });
    T(g, 180, 238, r < .02 ? 'এ শর্তে এনজাইম নিষ্ক্রিয় — শিকল ভাঙছে না' : `কাটার গতি ≈ সর্বোচ্চের ${Math.round(r * 100)}%`, { fs: 11, a: 'middle', w: 600, c: r < .02 ? C.bad : C.fg });
  },
  anim(g, C, ty, t, ctx) {
    if (ty !== 'act') return;
    const r = ctx.r || 0, sc = B.TS('vein'), mal = B.TS('food');
    const ph = (t * (.25 + .9 * r)) % 1, cutsDone = Math.floor(ph * 8), Lp = (ph * 8) % 1;
    /* অবশিষ্ট শিকল: শেষ থেকে জোড়ায় জোড়ায় মল্টোজ কাটা হয় */
    const left = N - cutsDone * 2;
    E('path', { d: `M${X0} ${Y0}H${X0 + DXU * (Math.max(left, 9) - 1)}`, stroke: sc.dk, 'stroke-width': 1.2 }, g);
    for (let i = 0; i < N; i++) { const x = X0 + DXU * i; if (i >= left && i !== 8) continue; B.hexU(g, x, Y0, 7.5, sc.dk, { fill: FK.alpha(sc.c, .3) }); }
    for (let i = 0; i < 4; i++) B.hexU(g, X0 + DXU * 8, Y0 - 18 - i * 15, 7, sc.dk, { fill: FK.alpha(sc.c, .3) });
    /* এনজাইম */
    if (r > .02 && left > 9) { const ex = X0 + DXU * (left - 2.5), wob = Math.sin(Lp * PI) * 3; B.enz(g, ex, Y0 + 2 + wob, 15, BK.ramp(3).c, -90, .35 + .25 * Math.sin(Lp * PI), 'অ্যামাইলেজ'); }
    /* মুক্ত মল্টোজ নিচে জমছে */
    for (let k = 0; k < cutsDone; k++) { const x = 70 + (k % 8) * 30, y = 170 + (k > 7 ? 18 : 0); B.hexU(g, x - 7, y, 6.5, mal.dk, { fill: FK.alpha(mal.c, .45) }); B.hexU(g, x + 6, y, 6.5, mal.dk, { fill: FK.alpha(mal.c, .45) }); }
    if (cutsDone < 8 && r > .02 && left > 9) { const x0 = X0 + DXU * (left - 1.5), y = Y0 + 10 + Lp * 70; B.hexU(g, x0 - 7, y, 6.5, mal.dk, { fill: FK.alpha(mal.c, .45), op: Lp }); B.hexU(g, x0 + 6, y, 6.5, mal.dk, { fill: FK.alpha(mal.c, .45), op: Lp }); }
    if (left <= 9) B.tx(g, X0 + DXU * 8 + 40, Y0 - 50, 'শাখাসহ অংশ = লিমিট ডেক্সট্রিন', { fs: 9, c: '#c98500' });
  }
}));

/* ═════════ গলাধঃকরণ ═════════ */
const SW = { soft: [[198, 115], [212, 118], [224, 128], [231, 142], [229, 150], [224, 147], [217, 135], [206, 125], [198, 121]] };
const lerp = (a, b, u) => a + (b - a) * u;
V.swallow = Object.assign({ t: 'গলাধঃকরণ (ডিগ্লুটিশন)', k: ['2d', 'anim', 'steps'], cap: 'বোলাস মুখ থেকে পাকস্থলীতে যাওয়ার তিন দশা। প্রথম দশা ঐচ্ছিক; গলবিলীয় দশা মস্তিষ্কের মেডুলার গলাধঃকরণ কেন্দ্রের প্রতিবর্ত — এ সময় প্রায় 1 সেকেন্ড শ্বাস বন্ধ থাকে (ডিগ্লুটিশন অ্যাপনিয়া)। ধাপে চাপ দাও।' }, BK.steps({
  W: 360, H: 300, label: 'গলাধঃকরণ', dur: 3.2,
  stages: [
    { t: 'মুখীয় দশা', en: 'Oral (voluntary)', d: 'জিহ্বার অগ্রভাগ শক্ত তালুতে চেপে ওপরে-পেছনে ওঠে এবং চর্বিত, লালামিশ্রিত বোলাসকে মুখগলবিলে ঠেলে দেয় — ঐচ্ছিক।' },
    { t: 'গলবিলীয় দশা', en: 'Pharyngeal (reflex)', d: 'নরম তালু ও আলজিভ ওপরে উঠে নাসাগলবিল বন্ধ করে; স্বরযন্ত্র ওপরে-সামনে ওঠে, এপিগ্লটিস নেমে স্বরযন্ত্রের মুখ ঢাকে; স্বররজ্জু বন্ধ হয় — শ্বাস প্রায় 1 সেকেন্ড বন্ধ।' },
    { t: 'অন্ননালিতে প্রবেশ', en: 'UOS opens', d: 'গলবিলের সংকোচক পেশির সংকোচন বোলাসকে নিচে ঠেলে; ঊর্ধ্ব অন্ননালীয় স্ফিংক্টার শিথিল হয়ে বোলাস অন্ননালিতে ঢোকে। এরপর সব আগের অবস্থায় ফেরে, শ্বাস আবার চালু।' },
    { t: 'অন্ননালীয় দশা', en: 'Oesophageal peristalsis', d: 'প্রাথমিক পেরিস্ট্যালসিস তরঙ্গ — বোলাসের পেছনের বৃত্তাকার পেশি সংকুচিত ও সামনেরটি শিথিল; প্রায় 8–10 সেকেন্ডে বোলাস নিম্ন অন্ননালীয় (কার্ডিয়াক) স্ফিংক্টার পেরিয়ে পাকস্থলীতে পৌঁছায়।' }
  ],
  draw(g, C, s, u) {
    const fl = B.TS('sub'), bo = B.TS('bone'), mu = B.TS('muc'), lum = C.dark ? FK.alpha('#fff', .06) : '#fbfdff', fd = B.TS('food');
    const up = s === 1 ? u : s === 2 ? 1 - u : 0;            /* স্বরযন্ত্র ওঠা, তালু ওঠা */
    E('path', { d: B.smooth([[150, 8], [118, 22], [104, 50], [98, 74], [90, 96], [100, 106], [106, 110], [104, 118], [98, 127], [103, 135], [99, 142], [104, 152], [106, 166], [116, 180], [138, 190], [156, 198], [164, 240], [168, 300], [316, 300], [312, 240], [318, 160], [322, 90], [310, 40], [270, 12], [210, 4]], true, .45), fill: FK.alpha(fl.c, .7), stroke: B.TS('skin').dk, 'stroke-width': 1.1 }, g);
    for (let i = 0; i < 8; i++) E('rect', { x: 258, y: 98 + i * 26, width: 30, height: 21, rx: 4, fill: B.lin(g, 'bone', 0), stroke: bo.dk, 'stroke-width': .7 }, g);
    E('path', { d: B.smooth([[108, 104], [120, 80], [150, 66], [196, 66], [220, 80], [224, 104], [212, 113], [112, 113]], true), fill: lum, stroke: mu.dk, 'stroke-width': .9 }, g);
    E('path', { d: B.smooth([[222, 82], [238, 86], [245, 120], [247, 170], [245, 220], [240, 262], [228, 264], [225, 236], [224, 206], [224, 186], [224, 160], [232, 148], [232, 132], [226, 118], [224, 104]], true, .45), fill: lum, stroke: mu.dk, 'stroke-width': .9 }, g);
    E('path', { d: B.smooth([[109, 116], [150, 114], [198, 115], [198, 121], [150, 120], [112, 121]], true, .3), fill: B.lin(g, 'bone', 90), stroke: bo.dk, 'stroke-width': .8 }, g);
    /* নরম তালু — ওপরে ঘোরে */
    const gs = E('g', { transform: `rotate(${(-38 * up).toFixed(1)} 198 118)` }, g); E('path', { d: B.smooth(SW.soft, true, .5), fill: B.vol(g, 'muc'), stroke: mu.dk, 'stroke-width': .9 }, gs);
    /* জিহ্বা — মুখীয় দশায় সামনে থেকে পেছনে চাপে */
    const tl = s === 0 ? u : s === 1 ? 1 : s === 2 ? 1 - u * .8 : .2;
    const tongue = [[111, 139], [130, 130 - 8 * tl], [160, 126 - 6 * tl], [190, 130 - 2 * tl], [212, 142 + 2 * tl], [222, 160], [222, 178], [219, 191], [196, 193], [170, 187], [142, 177], [124, 165], [116, 151]];
    E('path', { d: B.smooth(tongue, true, .5), fill: B.vol(g, 'tng', { cx: .4, cy: .2 }), stroke: B.TS('tng').dk, 'stroke-width': 1 }, g);
    /* স্বরযন্ত্র ও এপিগ্লটিস — ওপরে ওঠে, এপিগ্লটিস নামে */
    const ly = -12 * up, gl = E('g', { transform: `translate(${(4 * up).toFixed(1)} ${ly.toFixed(1)})` }, g);
    E('path', { d: B.smooth([[203, 199], [219, 197], [222, 236], [222, 300], [204, 300], [200, 236]], true, .4), fill: lum, stroke: mu.dk, 'stroke-width': .9 }, gl);
    E('path', { d: 'M190 214L196 214L200 252L194 254Z', fill: B.lin(g, 'cart', 0), stroke: B.TS('cart').dk, 'stroke-width': .8 }, gl);
    E('path', { d: `M201 234l${(8 + 3 * up).toFixed(1)} 3l${(-(8 + 3 * up)).toFixed(1)} 3ZM222 234l${(-(6 + 3 * up)).toFixed(1)} 3l${(6 + 3 * up).toFixed(1)} 3Z`, fill: mu.c, stroke: mu.dk, 'stroke-width': .6 }, gl);
    const ge = E('g', { transform: `rotate(${(118 * up).toFixed(1)} 215 200)` }, gl); E('path', { d: 'M214 200C216 190 222 180 230 175C232 179 228 188 222 198C220 202 216 203 214 200Z', fill: B.lin(g, 'cart', 0), stroke: B.TS('cart').dk, 'stroke-width': .9 }, ge);
    /* অন্ননালি */
    const ow = s === 2 ? 5 * Math.sin(u * PI) + 2 : s === 3 ? 4 : 1.5;
    E('path', { d: `M${232 - ow} 262L${242 + ow} 262L${244 + ow} 300L${230 - ow} 300Z`, fill: B.lin(g, 'eso', 0), stroke: B.TS('eso').dk, 'stroke-width': .9 }, g);
    /* বোলাস */
    let bx, by; if (s === 0) { bx = lerp(150, 214, u); by = lerp(126, 150, u); } else if (s === 1) { bx = lerp(214, 236, u); by = lerp(150, 214, u); } else if (s === 2) { bx = lerp(236, 237, u); by = lerp(214, 286, u); } else { bx = 237; by = 286 + u * 40; }
    if (by < 300) E('ellipse', { cx: bx.toFixed(1), cy: by.toFixed(1), rx: 8.5, ry: 6.5, fill: B.vol(g, 'food'), stroke: fd.dk, 'stroke-width': .9 }, g);
    /* অন্ননালীয় দশার পেরিস্ট্যালসিস (ছোট চিত্র ডানে) */
    if (s === 3) {
      const x = 60, y0 = 160, L = 120; E('rect', { x: x - 26, y: y0 - 20, width: 52, height: L + 40, rx: 8, fill: C.sf, stroke: C.ln }, g); B.tx(g, x, y0 - 26, 'অন্ননালি', { fs: 9.5, a: 'middle', c: C.mu });
      const bp = y0 + u * L; let dl = '', dr = ''; for (let k = 0; k <= 30; k++) { const yy = y0 + k * L / 30, dd = yy - bp, w = 7 + (dd > -16 && dd < 0 ? 4 * Math.sin((dd + 16) / 16 * PI) * 1.4 : 0) - (dd >= -26 && dd < -16 ? 3 : 0); dl += (k ? 'L' : 'M') + (x - w) + ' ' + yy.toFixed(1); dr += (k ? 'L' : 'M') + (x + w) + ' ' + yy.toFixed(1); }
      E('path', { d: dl, stroke: B.TS('eso').dk, 'stroke-width': 3, fill: 'none' }, g); E('path', { d: dr, stroke: B.TS('eso').dk, 'stroke-width': 3, fill: 'none' }, g);
      E('ellipse', { cx: x, cy: (bp - 8).toFixed(1), rx: 9, ry: 7, fill: B.vol(g, 'food'), stroke: fd.dk }, g);
      B.carrow(g, `M${x + 16} ${(bp - 24).toFixed(1)}v12`, C.bad, { w: 1.6 }); B.tx(g, x + 19, bp - 26, 'সংকোচন', { fs: 8, c: C.bad }); B.tx(g, x + 19, bp + 4, 'শিথিল', { fs: 8, c: C.ok });
    }
    if (up > .3) B.tx(g, 300, 60, 'শ্বাস বন্ধ', { fs: 11, a: 'middle', w: 650, c: C.bad });
    B.tx(g, 236, 98, 'নাসাগলবিল', { fs: 8, a: 'middle', c: C.mu });
  }
}));
})();
