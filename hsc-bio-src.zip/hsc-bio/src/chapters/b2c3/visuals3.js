/* ═══════════════════════════════════════════════════════════════════
   visuals3 — পাকস্থলী: stomachAnat, gastricGland, parietalHCl, pepsinAct
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, V = window.VIS, E = FK.el, BK = window.BK, T = BK.T, B = window.B23, PI = Math.PI;
const sm = (p, c, k) => B.smooth(p, c, k);

/* ═════════ পাকস্থলীর গঠন (সামনে থেকে, সামনের প্রাচীরের জানালা কাটা) ═════════ */
const ST = [[176, 96], [188, 70], [214, 50], [244, 52], [272, 74], [288, 112], [290, 160], [276, 210], [246, 248], [200, 266], [150, 264], [112, 250], [86, 236], [70, 231], [67, 212], [90, 206], [124, 206], [148, 196], [164, 170], [172, 136], [174, 108]];
const WIN = [[192, 102], [244, 92], [268, 132], [262, 192], [226, 228], [168, 238], [128, 228], [146, 200], [170, 164], [182, 126]];
const GCURVE = B.dense([[214, 50], [244, 52], [272, 74], [288, 112], [290, 160], [276, 210], [246, 248], [200, 266], [150, 264], [112, 250], [86, 236]], 8);
V.stomachAnat = Object.assign({ t: 'পাকস্থলীর গঠন', k: ['2d', 'anim', 'int', 'quiz'], cap: 'সামনে থেকে দেখা পাকস্থলী — সামনের প্রাচীরের একটি জানালা কেটে ভেতরের ভাঁজ (রুগি) দেখানো হয়েছে, আর ফান্ডাসে পেশির তিন স্তর ধাপে ধাপে খোলা। পাকস্থলীর পেশিস্তর অনন্য: বাইরে অনুদৈর্ঘ্য, মাঝে বৃত্তাকার, ভেতরে তির্যক। মিশ্রণ তরঙ্গ (প্রতি মিনিটে প্রায় 3টি) দেহ থেকে পাইলোরাসের দিকে চলছে। অংশে চাপ দাও।' }, BK.diagram({
  W: 360, H: 300, label: 'পাকস্থলীর গঠন', idle: true,
  art(g, C, part) {
    const sk = B.TS('stom'), mu = B.TS('mus'), se = B.TS('ser');
    /* অন্ননালি ও ডিওডেনাম */
    const es = part('eso'); B.tube(es, sm([[164, 6], [168, 40], [172, 74], [176, 100]]), 17, 'eso');
    const du = part('duo'); B.tube(du, sm([[70, 221], [44, 226], [26, 240], [18, 262]]), 20, 'int');
    /* বহিঃস্থ দেহ */
    const od = sm(ST, true, .5), bd = part('body');
    B.organ(bd, od, 'stom', { gr: { cx: .55, cy: .35, r: .9 } });
    E('path', { d: 'M196 70Q230 60 262 82', stroke: '#fff', 'stroke-width': 2.4, opacity: .3, fill: 'none' }, bd);
    /* সামনের প্রাচীরের জানালা: কাটা কিনারা (প্রাচীরের পুরুত্ব) ও ভেতরের রুগি */
    const wd = sm(WIN, true, .5), rg = part('rugae');
    E('path', { d: sm(WIN.map(([x, y]) => [x + 3, y + 4]), true, .5), fill: mu.c, stroke: mu.dk, 'stroke-width': .7 }, rg);
    E('path', { d: wd, fill: B.vol(rg, 'muc', { cx: .5, cy: .5, r: .8 }), stroke: sk.dk, 'stroke-width': .8 }, rg);
    const cp = B.clip(rg, 'win', wd), gr = E('g', { 'clip-path': cp }, rg);
    for (let i = 0; i < 9; i++) { const o = i * 13 - 50, pts = [[212 + o * .5, 94 + o * .2], [222 + o * .45 + 6 * Math.sin(i), 140 + o * .3], [210 + o * .3, 190 + o * .35], [170 + o * .2, 224 + o * .2], [130, 236 + o * .05]];
      B.tube(gr, sm(pts, false, .6), 6.5, 'muc', { sw: .6 }); }
    /* ফান্ডাসে পেশির স্তর — ধাপে ধাপে খোলা */
    const ml = part('mlong'), mc = part('mcirc'), mo = part('mobl');
    const P1 = [[202, 64], [228, 54], [256, 60], [276, 84], [282, 112], [258, 106], [236, 92], [214, 86]], P2 = [[214, 70], [236, 62], [258, 70], [272, 92], [276, 112], [254, 104], [232, 92]], P3 = [[226, 76], [246, 72], [262, 84], [270, 106], [252, 100], [236, 90]];
    B.musLayer(ml, sm(P1, true, .5), 'm1', 'circ', { a: 58, s: 3 });
    B.musLayer(mc, sm(P2, true, .5), 'm2', 'circ', { a: -32, s: 3 });
    B.musLayer(mo, sm(P3, true, .5), 'm3', 'circ', { a: 12, s: 3 });
    /* পাইলোরিক স্ফিংক্টার (কাটা অংশে পুরু বৃত্তাকার পেশি) */
    const py = part('pys'); E('path', { d: 'M62 210C72 212 74 232 64 234C58 232 56 214 62 210Z', fill: B.vol(py, 'mus'), stroke: mu.dk, 'stroke-width': .9 }, py);
    E('ellipse', { cx: 64, cy: 222, rx: 3, ry: 5, fill: C.dark ? '#2a2a2a' : '#fff', stroke: mu.dk, 'stroke-width': .6 }, py);
    const ls = part('los'); E('path', { d: 'M165 88C170 84 182 84 186 90L184 98C178 94 170 94 166 98Z', fill: B.vol(ls, 'mus'), stroke: mu.dk, 'stroke-width': .8 }, ls);
    /* অঞ্চলের সীমা (ড্যাশ) */
    E('path', { d: 'M186 84L208 104M150 196L172 248M108 208L120 248', stroke: FK.alpha(C.fg, .4), 'stroke-width': .8, 'stroke-dasharray': '3 3', fill: 'none' }, g);
    /* বক্রতা চিহ্ন (অদৃশ্য অংশ) */
    const lc = part('lesser'); E('path', { d: sm([[90, 206], [124, 206], [148, 196], [164, 170], [172, 136], [174, 108]]), stroke: 'transparent', 'stroke-width': 10, fill: 'none' }, lc);
    const gc = part('greater'); E('path', { d: sm([[288, 130], [290, 160], [276, 210], [246, 248]]), stroke: 'transparent', 'stroke-width': 10, fill: 'none' }, gc);
    ['cardia', 'fundus', 'corpus', 'antrum'].forEach(k => part(k));
    E('circle', { cx: 190, cy: 100, r: 8, fill: 'transparent' }, part('cardia2'));
  },
  idle(g, C, t) {
    const n = GCURVE.length, u = (t * .05) % 1, i = Math.min(n - 2, Math.floor(u * (n - 1))), [x, y] = GCURVE[i], [x2, y2] = GCURVE[i + 1], a = Math.atan2(y2 - y, x2 - x), nx = -Math.sin(a), ny = Math.cos(a);
    E('path', { d: `M${(x - nx * 3).toFixed(1)} ${(y - ny * 3).toFixed(1)}l${(nx * 10).toFixed(1)} ${(ny * 10).toFixed(1)}`, stroke: B.TS('mus').dk, 'stroke-width': 4, 'stroke-linecap': 'round', opacity: .75 }, g);
    for (let k = 0; k < 6; k++) { const a2 = t * .6 + k, r = 18 + 8 * Math.sin(k * 2), cx = 200 + Math.cos(a2) * r * 1.2, cy = 170 + Math.sin(a2) * r; E('circle', { cx: cx.toFixed(1), cy: cy.toFixed(1), r: 2.4, fill: B.TS('food').c, stroke: B.TS('food').dk, 'stroke-width': .5, opacity: .85 }, g); }
  },
  parts: [
    { id: 'eso', bn: 'অন্ননালি', en: 'Oesophagus', fn: 'বোলাস পেরিস্ট্যালসিসে পাকস্থলীতে আসে।', a: [168, 30], l: [120, 22] },
    { id: 'los', bn: 'কার্ডিয়াক (নিম্ন অন্ননালীয়) স্ফিংক্টার', lb: 'কার্ডিয়াক স্ফিংক্টার', en: 'Lower oesophageal sphincter', fn: 'অন্ননালির শেষে কার্যকর (শারীরবৃত্তীয়) স্ফিংক্টার — খাদ্য ঢুকলে শিথিল হয়, পরে বন্ধ হয়ে অম্লীয় কাইমকে অন্ননালিতে ফিরতে দেয় না; দুর্বল হলে বুক জ্বালা (অ্যাসিড রিফ্লাক্স)।', a: [176, 90], l: [120, 64] },
    { id: 'cardia2', bn: 'কার্ডিয়া (হৃদপ্রান্ত)', lb: 'কার্ডিয়া', en: 'Cardia', fn: 'অন্ননালির প্রবেশমুখের চারপাশের অংশ — এখানকার গ্রন্থি প্রধানত শ্লেষ্মা ঝরায়।', a: [190, 100], l: [120, 104] },
    { id: 'lesser', bn: 'ক্ষুদ্র বক্রতা', en: 'Lesser curvature', fn: 'পাকস্থলীর ডান দিকের ছোট, অবতল কিনারা (চিত্রে বাঁয়ে) — যকৃতের দিকে মুখ করা; কোণার খাঁজকে অ্যাঙ্গুলার নচ বলে।', a: [158, 186], l: [120, 150] },
    { id: 'duo', bn: 'ডিওডেনাম', en: 'Duodenum', fn: 'পাইলোরাস পেরিয়ে কাইম ক্ষুদ্রান্ত্রের প্রথম অংশে যায়।', a: [30, 236], l: [20, 286], an: 'start' },
    { id: 'pys', bn: 'পাইলোরিক স্ফিংক্টার', lb: 'পাইলোরিক স্ফিংক্টার', en: 'Pyloric sphincter', fn: 'বৃত্তাকার পেশির পুরু বলয় — অল্প অল্প করে (প্রায় 2–3 মিলি করে) কাইম ডিওডেনামে ছাড়ে এবং পিত্তরসকে পাকস্থলীতে ফিরতে দেয় না।', a: [64, 214], l: [56, 184], an: 'middle' },
    { id: 'antrum', bn: 'পাইলোরিক অংশ (অ্যান্ট্রাম ও পাইলোরিক নালি)', lb: 'পাইলোরিক অংশ', en: 'Pyloric part', fn: 'দেহের পরের সরু অংশ — শক্তিশালী পেশি সংকোচনে খাদ্য পিষে কাইম তৈরি করে; এখানকার G কোষ গ্যাস্ট্রিন হরমোন ঝরায়।', a: [100, 232], l: [120, 290] },
    { id: 'fundus', bn: 'ফান্ডাস', en: 'Fundus', fn: 'কার্ডিয়ার বাঁ দিকের (চিত্রে ডানে) গম্বুজাকার ওপরের অংশ — প্রায়ই গ্যাস জমে থাকে; দেহের মতো এখানেও অক্সিনটিক গ্রন্থি।', a: [244, 64], l: [292, 30] },
    { id: 'mlong', bn: 'বহিঃস্থ অনুদৈর্ঘ্য পেশি', lb: 'অনুদৈর্ঘ্য পেশি', en: 'Longitudinal muscle', fn: 'সবচেয়ে বাইরের পেশিস্তর — বক্রতা বরাবর তন্তু।', a: [276, 98], l: [296, 58] },
    { id: 'mcirc', bn: 'মধ্য বৃত্তাকার পেশি', lb: 'বৃত্তাকার পেশি', en: 'Circular muscle', fn: 'মাঝের স্তর — পাইলোরাসে পুরু হয়ে স্ফিংক্টার গঠন করে।', a: [260, 92], l: [296, 82] },
    { id: 'mobl', bn: 'অন্তঃস্থ তির্যক পেশি', lb: 'তির্যক পেশি', en: 'Inner oblique muscle', fn: 'কেবল পাকস্থলীতে থাকা অতিরিক্ত পেশিস্তর — খাদ্য মেশানো ও পেষায় বাড়তি শক্তি দেয়।', a: [252, 92], l: [296, 106] },
    { id: 'corpus', bn: 'দেহ (বডি)', lb: 'দেহ', en: 'Body', fn: 'সবচেয়ে বড় অংশ — গ্যাস্ট্রিক গ্রন্থির প্যারাইটাল কোষ HCl ও চিফ কোষ পেপসিনোজেন ঝরায়।', a: [232, 200], l: [296, 140] },
    { id: 'rugae', bn: 'রুগি (মিউকোসার ভাঁজ)', lb: 'রুগি', en: 'Rugae', fn: 'খালি পাকস্থলীর ভেতরের লম্বা ভাঁজ — খাদ্য ঢুকলে মিলিয়ে গিয়ে পাকস্থলীকে প্রসারিত হতে দেয়।', a: [206, 150], l: [296, 172] },
    { id: 'greater', bn: 'বৃহৎ বক্রতা', en: 'Greater curvature', fn: 'বাঁ দিকের লম্বা, উত্তল কিনারা (চিত্রে ডানে) — এখান থেকে বৃহৎ ওমেন্টাম ঝুলে থাকে।', a: [284, 186], l: [296, 214] }
  ]
}));

/* ═════════ গ্যাস্ট্রিক (অক্সিনটিক) গ্রন্থি ═════════ */
const GX = 180, LW = 4, DEP = 26, YT = 46, YB = 296;
V.gastricGland = Object.assign({ t: 'গ্যাস্ট্রিক গ্রন্থির কোষ', k: ['2d', 'anim', 'int', 'quiz'], cap: 'পাকস্থলীর দেহ ও ফান্ডাসের একটি গ্যাস্ট্রিক গ্রন্থি (H&E রঞ্জনের রঙে) — ওপরে গ্যাস্ট্রিক পিট, মাঝে গ্রীবা, নিচে দেহ ও তলদেশ। প্রতি বর্গমিলিমিটারে প্রায় 100টি পিট; প্রতি পিটে 3–7টি গ্রন্থি খোলে। কোষগুলোর ক্ষরণ লুমেন বেয়ে ওপরে উঠছে। কোষে চাপ দাও।' }, BK.diagram({
  W: 360, H: 330, label: 'গ্যাস্ট্রিক গ্রন্থি', idle: true,
  art(g, C, part) {
    const lp = B.TS('sub'), cy = B.TS('cyt'), mc = B.TS('muco'), zy = B.TS('zym'), nu = B.TS('nuc');
    /* ল্যামিনা প্রোপ্রিয়া ও পাশের গ্রন্থির আভাস */
    const L = part('lp'); E('rect', { x: 92, y: YT, width: 176, height: YB - YT + 8, fill: lp.c }, L); E('rect', { x: 92, y: YT, width: 176, height: YB - YT + 8, fill: B.pat(L, 'dot', FK.alpha(nu.c, .4), { s: 5, w: .55 }) }, L);
    [100, 260].forEach(x => E('rect', { x: x - 8, y: YT, width: 16, height: YB - YT, rx: 8, fill: FK.alpha(cy.c, .45), stroke: FK.alpha(cy.dk, .4), 'stroke-width': .6 }, L));
    const cap = part('cap'); [[132, 'art'], [228, 'vein']].forEach(([x, k]) => { const t = B.TS(k); E('path', { d: `M${x} ${YB}C${x - 6} 240 ${x + 6} 180 ${x - 2} 120S${x + 4} 70 ${x} ${YT + 4}`, stroke: t.c, 'stroke-width': 2.4, fill: 'none' }, cap); });
    /* মাসকুলারিস মিউকোসি */
    const mm = part('mm'); B.musLayer(mm, `M92 ${YB + 8}H268V${YB + 20}H92Z`, 'gmm', 'circ', { s: 3 });
    /* উপরিতল — পৃষ্ঠীয় শ্লেষ্মা কোষ (গ্রন্থির দুই পাশে অনুভূমিক) */
    const sf = part('surf');
    [-1, 1].forEach(s => { for (let i = 0; i < 6; i++) { const x0 = GX + s * (LW + 4 + i * 11), x1 = x0 + s * 11; E('path', { d: `M${x0} ${YT}L${x1} ${YT}L${x1} ${YT + 26}L${x0} ${YT + 26}Z`, fill: mc.lt, stroke: cy.dk, 'stroke-width': .5 }, sf); E('rect', { x: Math.min(x0, x1) + 1.5, y: YT + 1.5, width: 8, height: 11, rx: 3, fill: mc.c }, sf); B.nuc(sf, (x0 + x1) / 2, YT + 20, 2.6, 3.2, 0, {}); } });
    E('path', { d: `M92 ${YT}H${GX - LW - 4}M${GX + LW + 4} ${YT}H268`, stroke: FK.alpha(mc.dk, .8), 'stroke-width': 1.6 }, sf);
    /* গ্রন্থির দুই প্রাচীরের কোষ — গভীরতা অনুযায়ী ধরন */
    const grp = { pit: part('pit'), neck: part('neck'), stem: part('stem'), par: part('par'), chief: part('chief'), ee: part('ee') };
    const kind = (y, i, s) => { if (y < YT + 56) return 'pit'; if (y < YT + 70) return i % 2 ? 'stem' : 'neck'; if (y < YT + 110) return (i + (s > 0 ? 1 : 0)) % 3 === 0 ? 'par' : 'neck'; if (y < YT + 190) return (i + (s > 0 ? 1 : 0)) % 2 === 0 ? 'par' : 'chief'; return (i + (s > 0 ? 0 : 1)) % 4 === 0 ? (i % 8 === 0 ? 'ee' : 'par') : 'chief'; };
    [-1, 1].forEach(s => { let y = YT + 2, i = 0; while (y < YB - 4) {
      const k = kind(y, i, s), hh = k === 'par' ? 17 : k === 'pit' ? 11 : 12, x0 = GX + s * LW, x1 = GX + s * (LW + DEP + (k === 'par' ? 6 : 0)), y1 = y + hh, gg = grp[k];
      if (k === 'par') { E('path', { d: `M${x0} ${y + 3}L${x0} ${y1 - 3}Q${x1 - s * 4} ${y1 + 3} ${x1} ${(y + y1) / 2}Q${x1 - s * 4} ${y - 3} ${x0} ${y + 3}Z`, fill: B.vol(gg, 'cyt', { cx: .5, cy: .5 }), stroke: cy.dk, 'stroke-width': .6 }, gg); B.nuc(gg, (x0 + x1) / 2 + s * 2, (y + y1) / 2, 3.2, 3.2, 0, {}); E('path', { d: `M${x0 + s * 1} ${(y + y1) / 2}q${s * 4} -3 ${s * 7} 0`, stroke: FK.alpha('#fff', .9), 'stroke-width': 1, fill: 'none' }, gg); }
      else if (k === 'chief') { E('path', { d: `M${x0} ${y}L${x1} ${y + 1}L${x1} ${y1 - 1}L${x0} ${y1}Z`, fill: FK.alpha(nu.lt, .65), stroke: cy.dk, 'stroke-width': .5 }, gg); for (let j = 0; j < 4; j++) E('circle', { cx: x0 + s * (3 + j * 2.6), cy: y + 3 + (j % 2) * 5, r: 1.2, fill: zy.c, stroke: zy.dk, 'stroke-width': .3 }, gg); B.nuc(gg, x1 - s * 6, (y + y1) / 2, 2.6, 3.2, 0, {}); }
      else if (k === 'ee') { E('path', { d: `M${x0} ${y + 2}L${x1} ${y}L${x1} ${y1}L${x0} ${y1 - 2}Z`, fill: '#f3efe4', stroke: cy.dk, 'stroke-width': .5 }, gg); for (let j = 0; j < 5; j++) E('circle', { cx: x1 - s * (2 + j * 2.4), cy: y + 3 + (j % 2) * 6, r: 1, fill: '#8a5a1f' }, gg); B.nuc(gg, (x0 + x1) / 2, (y + y1) / 2, 2.4, 2.8, 0, {}); }
      else { const muc = k !== 'stem'; E('path', { d: `M${x0} ${y}L${x1} ${y}L${x1} ${y1}L${x0} ${y1}Z`, fill: muc ? mc.lt : FK.alpha(cy.c, .6), stroke: cy.dk, 'stroke-width': .5 }, gg); if (muc) E('rect', { x: Math.min(x0, x0 + s * (k === 'pit' ? 13 : 8)), y: y + 1.5, width: k === 'pit' ? 13 : 8, height: hh - 3, rx: 3, fill: mc.c }, gg); B.nuc(gg, x1 - s * 6, (y + y1) / 2, k === 'stem' ? 3 : 2.4, k === 'stem' ? 3.4 : 2.6, 0, {}); }
      y = y1; i++; } });
    /* লুমেন ও ভিত্তিপর্দা */
    E('path', { d: `M${GX - LW} ${YT}V${YB - 6}Q${GX} ${YB + 2} ${GX + LW} ${YB - 6}V${YT}`, fill: C.dark ? '#26262a' : '#fffefb', stroke: FK.alpha(cy.dk, .6), 'stroke-width': .6 }, g);
    E('path', { d: `M${GX - LW - DEP - 2} ${YT + 26}V${YB}Q${GX} ${YB + 14} ${GX + LW + DEP + 2} ${YB}V${YT + 26}`, stroke: FK.alpha(cy.dk, .5), 'stroke-width': .7, fill: 'none', 'stroke-dasharray': '2 2' }, g);
    /* অঞ্চল বন্ধনী */
    [[YT, YT + 56, 'পিট'], [YT + 56, YT + 110, 'গ্রীবা'], [YT + 110, YT + 190, 'দেহ'], [YT + 190, YB, 'তলদেশ']].forEach(([a, b, s]) => { E('path', { d: `M272 ${a + 2}h4V${b - 2}h-4`, stroke: C.mu, 'stroke-width': .8, fill: 'none' }, g); B.tx(g, 279, (a + b) / 2 + 3, s, { fs: 8.5, c: C.mu }); });
    B.tx(g, 180, YT - 8, 'পাকস্থলীর গহ্বর', { fs: 9.5, a: 'middle', c: C.mu });
  },
  idle(g, C, t) {
    for (let k = 0; k < 7; k++) { const u = ((t * .12 + k / 7) % 1), y = YB - 8 - u * (YB - YT - 4), c = k % 3 === 0 ? '#d6a21c' : k % 3 === 1 ? '#7a62b8' : '#9fb5de'; E('circle', { cx: GX + Math.sin(k * 3 + t) * 1.5, cy: y.toFixed(1), r: 1.5, fill: c, opacity: .9 }, g); }
  },
  parts: [
    { id: 'surf', bn: 'পৃষ্ঠীয় শ্লেষ্মা কোষ', lb: 'পৃষ্ঠীয় শ্লেষ্মা কোষ', en: 'Surface mucous cells', fn: 'পুরো মিউকোসার উপরিতল ঢাকা স্তম্ভাকার কোষ — ঘন, ক্ষারীয় (HCO<sub>3</sub><sup>−</sup>-যুক্ত) শ্লেষ্মার স্তর তৈরি করে, যা প্রাচীরকে HCl ও পেপসিন থেকে রক্ষা করে।', a: [140, 60], l: [86, 40] },
    { id: 'pit', bn: 'গ্যাস্ট্রিক পিট', en: 'Gastric pit', fn: 'উপরিতলের খাঁজ — নিচের গ্রন্থিগুলো এতে খোলে; আস্তরণ পৃষ্ঠীয় শ্লেষ্মা কোষে।', a: [176, 84], l: [86, 74] },
    { id: 'neck', bn: 'গ্রীবা শ্লেষ্মা কোষ', lb: 'গ্রীবা শ্লেষ্মা কোষ', en: 'Mucous neck cells', fn: 'গ্রন্থির গ্রীবায় ছোট কোষ — অম্লীয় (পাতলা) শ্লেষ্মা ঝরায়।', a: [196, 128], l: [86, 102] },
    { id: 'stem', bn: 'স্টেম কোষ', en: 'Stem cells', fn: 'ইস্থমাস ও গ্রীবায় অবিভেদিত কোষ — বিভাজনে সব ধরনের কোষ তৈরি করে; পৃষ্ঠীয় কোষ প্রতি 3–5 দিনে নতুন হয়।', a: [162, 112], l: [86, 130] },
    { id: 'par', bn: 'প্যারাইটাল (অক্সিনটিক) কোষ', lb: 'প্যারাইটাল কোষ', en: 'Parietal (oxyntic) cell', fn: 'বড়, গোলাপি (ইওসিনোফিলিক), ত্রিকোণাকার কোষ, মাঝে গোল নিউক্লিয়াস ও প্রচুর মাইটোকন্ড্রিয়া — HCl ও ইনট্রিনসিক ফ্যাক্টর (ভিটামিন B<sub>12</sub> শোষণের জন্য জরুরি) ঝরায়।', a: [150, 186], l: [86, 170] },
    { id: 'chief', bn: 'চিফ (পেপটিক বা জাইমোজেনিক) কোষ', lb: 'চিফ কোষ', en: 'Chief (zymogenic) cell', fn: 'তলদেশে বেগুনি (বেসোফিলিক) কোষ, শীর্ষে জাইমোজেন দানা — পেপসিনোজেন ও গ্যাস্ট্রিক লাইপেজ (শিশুদের ক্ষেত্রে রেনিনও বলা হয়) ঝরায়।', a: [204, 260], l: [86, 222] },
    { id: 'ee', bn: 'এন্টেরোএন্ডোক্রাইন কোষ', lb: 'এন্ডোক্রাইন কোষ', en: 'Enteroendocrine cell', fn: 'ছোট, ফিকে কোষ, দানা তলদেশে — রক্তে হরমোন ছাড়ে: ECL কোষ হিস্টামিন, D কোষ সোমাটোস্ট্যাটিন; অ্যান্ট্রামের গ্রন্থিতে G কোষ গ্যাস্ট্রিন।', a: [160, 252], l: [86, 252] },
    { id: 'cap', bn: 'কৈশিকনালি', en: 'Capillaries', fn: 'গ্রন্থির পাশ দিয়ে চলে — প্যারাইটাল কোষ রক্ত থেকে Cl<sup>−</sup> ও CO<sub>2</sub> নেয় এবং HCO<sub>3</sub><sup>−</sup> রক্তে ফেরত দেয় (খাওয়ার পর "অ্যালকালাইন টাইড")।', a: [228, 150], l: [296, 140] },
    { id: 'lp', bn: 'ল্যামিনা প্রোপ্রিয়া', en: 'Lamina propria', fn: 'গ্রন্থিগুলোর মাঝের শিথিল যোজক টিস্যু ও প্রতিরক্ষা কোষ।', a: [250, 220], l: [296, 220] },
    { id: 'mm', bn: 'মাসকুলারিস মিউকোসি', lb: 'মাস. মিউকোসি', en: 'Muscularis mucosae', fn: 'পাতলা পেশিস্তর — সংকোচনে গ্রন্থির ক্ষরণ চেপে বের করে।', a: [240, 310], l: [296, 312] }
  ]
}));

/* ═════════ প্যারাইটাল কোষে HCl তৈরি ═════════ */
const PX0 = 74, PX1 = 286;
const ROUTES = {
  co2: [[18, 70], [80, 82], [150, 112]], h: [[160, 116], [240, 100], [286, 96], [330, 96]], k: [[330, 112], [286, 104], [240, 116], [270, 140], [286, 140], [330, 146]],
  hco3: [[150, 124], [110, 160], [74, 170], [20, 176]], cl: [[20, 196], [74, 190], [160, 196], [250, 196], [286, 196], [330, 196]]
};
const ION = { co2: ['CO_2', 9], h: ['H^+', 4], k: ['K^+', 3], hco3: ['HCO_3^-', 5], cl: ['Cl^-', 7] };
V.parietalHCl = Object.assign({}, B.seg({
  id: 'phc', t: 'প্যারাইটাল কোষে হাইড্রোক্লোরিক অ্যাসিড তৈরি', H: 250, def: 'mech',
  cap: 'কোষের ভেতরে কার্বনিক অ্যানহাইড্রেজ CO<sub>2</sub> ও পানি থেকে H<sup>+</sup> ও HCO<sub>3</sub><sup>−</sup> তৈরি করে। শীর্ষ ঝিল্লির H<sup>+</sup>/K<sup>+</sup>-ATPase (প্রোটন পাম্প) ATP খরচ করে H<sup>+</sup> বাইরে পাঠায় ও K<sup>+</sup> ভেতরে আনে; Cl<sup>−</sup> রক্ত থেকে HCO<sub>3</sub><sup>−</sup> এর বিনিময়ে ঢুকে চ্যানেল দিয়ে বেরোয়। লুমেনে H<sup>+</sup> + Cl<sup>−</sup> = HCl (pH প্রায় 1–2)। ধরন বেছে চালাও চাপো।',
  types: { mech: ['স্বাভাবিক', 'HCl তৈরির কৌশল', 'হিস্টামিন (H<sub>2</sub> রিসেপ্টর), গ্যাস্ট্রিন ও অ্যাসিটাইলকোলিন (ভেগাস স্নায়ু) কোষকে উদ্দীপিত করে; তখন পাম্পযুক্ত থলিগুলো শীর্ষ ঝিল্লিতে মিশে যায় ও ক্ষরণ বহুগুণ বাড়ে।'], ppi: ['ওমিপ্রাজল', 'প্রোটন পাম্প ইনহিবিটর', 'ওমিপ্রাজল জাতীয় ওষুধ (PPI) H<sup>+</sup>/K<sup>+</sup>-ATPase কে স্থায়ীভাবে বন্ধ করে — H<sup>+</sup> বের হয় না, তাই অম্ল ক্ষরণ প্রায় 90% পর্যন্ত কমে; আলসার ও অ্যাসিড রিফ্লাক্সের চিকিৎসায় ব্যবহৃত। রেনিটিডিন জাতীয় ওষুধ H<sub>2</sub> রিসেপ্টর বন্ধ করে।'] },
  art(g, C, ty) {
    const cy = B.TS('cyt'), ar = B.TS('art');
    /* রক্তের দিক ও লুমেন */
    E('rect', { x: 6, y: 30, width: 50, height: 196, rx: 10, fill: FK.alpha(ar.c, .14), stroke: FK.alpha(ar.c, .5) }, g); B.tx(g, 31, 22, 'রক্ত (কৈশিক)', { fs: 9, a: 'middle', c: ar.dk });
    for (let i = 0; i < 5; i++) B.rbc(g, 20 + (i % 2) * 18, 50 + i * 40, 4);
    E('rect', { x: 300, y: 30, width: 54, height: 196, rx: 10, fill: FK.alpha('#f3c94a', .12), stroke: FK.alpha('#c98500', .45) }, g); B.tx(g, 327, 22, 'লুমেন', { fs: 9, a: 'middle', c: '#a26b00' }); B.tx(g, 327, 216, 'pH ≈ 1–2', { fs: 9, a: 'middle', w: 600, c: '#a26b00' });
    /* কোষ */
    E('rect', { x: PX0, y: 34, width: PX1 - PX0, height: 188, rx: 16, fill: FK.alpha(cy.c, .45), stroke: cy.dk, 'stroke-width': 1.2 }, g);
    B.vmem(g, PX0, 40, 216, { gaps: [[160, 180]] }); B.vmem(g, PX1, 40, 216, { gaps: [[86, 112], [130, 150], [186, 206]] });
    B.nuc(g, 120, 68, 20, 16, 0, {}); for (let i = 0; i < 4; i++) E('ellipse', { cx: 112 + i * 26, cy: 190 + (i % 2) * 8, rx: 9, ry: 4.5, fill: FK.alpha(BK.org('mito').c, .55), stroke: BK.org('mito').dk, 'stroke-width': .6, transform: `rotate(${i * 35} ${112 + i * 26} ${190 + (i % 2) * 8})` }, g);
    B.tx(g, 150, 214, 'মাইটোকন্ড্রিয়া (ATP যোগায়)', { fs: 8, a: 'middle', c: C.mu });
    /* কার্বনিক অ্যানহাইড্রেজ */
    B.enz(g, 156, 120, 13, BK.ramp(3).c, 0, .3, 'CA'); B.tx(g, 156, 100, 'কার্বনিক অ্যানহাইড্রেজ', { fs: 8.5, a: 'middle', w: 600 });
    B.tx(g, 156, 146, B.ch('CO_2 + H_2O → H_2CO_3 → H^+ + HCO_3^-'), { fs: 8.6, a: 'middle', c: C.fg });
    /* বাহক */
    const blocked = ty === 'ppi';
    B.carrier(g, PX1, 99, blocked ? '#9aa0a6' : '#e07b12', 'H+/K+ পাম্প', {});
    if (blocked) { E('path', { d: `M${PX1 - 10} 89l20 20M${PX1 + 10} 89l-20 20`, stroke: C.bad, 'stroke-width': 2.6 }, g); B.tx(g, PX1 - 8, 126, 'ওমিপ্রাজল', { fs: 8, a: 'end', w: 650, c: C.bad }); }
    B.tx(g, PX1 - 30, 80, 'ATP → ADP', { fs: 7.5, a: 'middle', c: C.mu });
    B.carrier(g, PX1, 140, '#8f7ed6', 'K+ চ্যানেল', { w: 12, h: 18 });
    B.carrier(g, PX1, 196, '#3fa66a', 'Cl− চ্যানেল', { w: 12, h: 18 });
    B.carrier(g, PX0, 172, '#5f8fd6', '', { w: 14, h: 24 }); B.tx(g, PX0 + 12, 210, B.ch('Cl^-/HCO_3^- বিনিময়ক'), { fs: 8, c: C.fg });
    B.tx(g, 180, 240, blocked ? 'পাম্প বন্ধ → লুমেনে H<sup>+</sup> আসছে না → অম্লতা কম' : 'লুমেনে H<sup>+</sup> + Cl<sup>−</sup> → HCl', { fs: 11, a: 'middle', w: 650, c: blocked ? C.bad : C.fg });
  },
  anim(g, C, ty, t) {
    const blocked = ty === 'ppi';
    Object.keys(ROUTES).forEach(k => { const [s, R] = ION[k], D = B.dense(ROUTES[k], 6); for (let j = 0; j < 2; j++) { let u = ((t * .16 + j * .5 + (k.length * .13)) % 1); if (blocked && (k === 'h' || k === 'k')) { if (k === 'h') u = Math.min(u, .55); else continue; } const [x, y] = B.along(D, u); B.ion(g, x, y, s, BK.ramp(R), s.length > 4 ? 12 : 9, { fs: 7.2 }); } });
  }
}));

/* ═════════ পেপসিনোজেন থেকে পেপসিন ও আমিষ পরিপাক ═════════ */
const blobP = (g, x, y, r, col, seed, op = 1) => B.blob(g, x, y, r, { n: 9, seed, j: .22, fill: FK.alpha(col, .55 * op), stroke: col, sw: 1.1 });
V.pepsinAct = Object.assign({ t: 'পেপসিনোজেন সক্রিয় হওয়া ও আমিষ পরিপাক', k: ['2d', 'anim', 'steps'], cap: 'চিফ কোষ নিষ্ক্রিয় পেপসিনোজেন (জাইমোজেন) ঝরায় — যাতে নিজের কোষ পরিপাক না হয়। HCl এর অম্লে এটি নিজেই একটি অংশ কেটে পেপসিনে পরিণত হয়, আর পেপসিন আরও পেপসিনোজেনকে সক্রিয় করে (স্বয়ংসক্রিয়তা)। পেপসিন একটি এন্ডোপেপটাইডেজ — আমিষের শিকলের ভেতরের বন্ধন (বিশেষত অ্যারোমেটিক অ্যামাইনো অ্যাসিডের পাশে) কেটে পলিপেপটাইড তৈরি করে। ধাপে চাপ দাও।' }, BK.steps({
  W: 360, H: 240, label: 'পেপসিন', dur: 3.2,
  stages: [
    { t: 'পেপসিনোজেন ক্ষরণ', en: 'Zymogen secretion', d: 'চিফ কোষের জাইমোজেন দানা থেকে নিষ্ক্রিয় পেপসিনোজেন লুমেনে আসে; এর সক্রিয় স্থান একটি ছোট প্রো-পেপটাইড অংশে (প্রায় 44টি অ্যামাইনো অ্যাসিড) ঢাকা।' },
    { t: 'HCl এ সক্রিয় হওয়া', en: 'Acid activation', d: 'pH 5 এর নিচে অণুটির ভাঁজ খোলে ও এটি নিজেই প্রো-পেপটাইড কেটে ফেলে — সক্রিয় পেপসিন তৈরি হয়।' },
    { t: 'স্বয়ংসক্রিয়তা', en: 'Autocatalysis', d: 'তৈরি হওয়া পেপসিন আশপাশের পেপসিনোজেনকেও কেটে সক্রিয় করে — শৃঙ্খল বিক্রিয়ার মতো দ্রুত পেপসিন বাড়ে।' },
    { t: 'আমিষ পরিপাক', en: 'Proteolysis', d: 'পেপসিন (সর্বোত্তম pH প্রায় 2) আমিষকে ভেঙে পলিপেপটাইড ও পেপটোনে পরিণত করে — আমিষের প্রায় 10–20% এখানে পরিপাক হয়; বাকিটা ক্ষুদ্রান্ত্রে। কোলাজেন ভেঙে মাংসের টিস্যু আলগা করা পেপসিনের বিশেষ কাজ।' }
  ],
  draw(g, C, s, u) {
    const en = BK.ramp(3).c, pro = BK.ramp(6).c, pr = BK.ramp(4).dk, ac = '#c98500';
    E('rect', { x: 8, y: 30, width: 344, height: 170, rx: 12, fill: FK.alpha('#f3c94a', s ? .12 : .04), stroke: C.ln }, g);
    B.tx(g, 180, 22, s ? 'পাকস্থলীর লুমেন — HCl উপস্থিত (pH ≈ 2)' : 'চিফ কোষের পাশে লুমেন', { fs: 10, a: 'middle', c: C.mu });
    if (s >= 1) for (let i = 0; i < 10; i++) B.tx(g, 30 + i * 33, 192, i % 2 ? 'H+' : 'Cl−', { fs: 8, a: 'middle', c: i % 2 ? '#c55' : '#3a8' });
    const pepsinogen = (x, y, cut, k) => { B.enz(g, x, y, 22, en, 0, cut ? .45 : .32, 'পেপসিন'); if (!cut || k < 1) { const dx = cut ? k * 18 : 0, dy = cut ? -k * 10 : 0; E('path', { d: `M${x + 6 + dx} ${y - 8 + dy}q14 8 0 16q-6 -8 0 -16Z`, fill: FK.alpha(pro, .9), stroke: C.fg, 'stroke-width': .7, opacity: cut ? 1 - k * .8 : 1 }, g); } };
    if (s === 0) { pepsinogen(120 + u * 40, 110, false); B.tx(g, 140 + u * 40, 152, 'পেপসিনোজেন (নিষ্ক্রিয়)', { fs: 10, a: 'middle', w: 600 }); E('path', { d: 'M24 110h40', stroke: C.mu, 'marker-end': B.mk(g, C.mu) }, g); B.tx(g, 22, 100, 'চিফ কোষ', { fs: 9, c: C.mu }); }
    else if (s === 1) { pepsinogen(160, 110, true, u); B.tx(g, 160, 152, u < .6 ? 'অম্লে ভাঁজ খুলছে…' : 'পেপসিন (সক্রিয়) + প্রো-পেপটাইড', { fs: 10, a: 'middle', w: 600 }); }
    else if (s === 2) { pepsinogen(100, 110, true, 1); [[200, 80], [260, 120], [210, 150]].forEach(([x, y], i) => { const k = Math.max(0, Math.min(1, u * 3 - i)); pepsinogen(x, y, k > 0, k); }); B.carrow(g, 'M126 100Q160 80 180 84', ac, { w: 1.4 }); B.tx(g, 180, 190, 'এক পেপসিন → অনেক পেপসিন', { fs: 10, a: 'middle', w: 600 }); }
    else { B.enz(g, 80, 110, 22, en, 0, .3 + .25 * Math.abs(Math.sin(u * 8)), 'পেপসিন'); const n = 12, cut = Math.floor(u * 4); for (let i = 0; i < n; i++) { const grp = Math.floor(i / 3), sep = grp < cut ? grp * 10 : cut * 10, x = 120 + i * 17 + sep, y = 110 + (grp < cut ? Math.sin(i) * 8 : 0); if (i && Math.floor((i - 1) / 3) === grp) E('path', { d: `M${x - 17} ${110 + (grp < cut ? Math.sin(i - 1) * 8 : 0)}L${x} ${y}`, stroke: pr, 'stroke-width': 1.4 }, g); B.bead(g, x, y, 6.2, [pr, '#7a62b8', '#2f8f6a', '#c98500'][i % 4]); } B.tx(g, 220, 160, 'আমিষ → পলিপেপটাইড (পেপটোন)', { fs: 10, a: 'middle', w: 600 }); }
  }
}));
})();
