/* ═══════════════════════════════════════════════════════════════════
   BK — জীববিজ্ঞানের চিত্র-কিট (FK এর ওপর তৈরি, কোনো বাইরের লাইব্রেরি নেই, সস্তা ফোনেও মসৃণ)
   প্রতিটি নির্মাতা {html(), mount(root)} ফেরত দেয়; অধ্যায়ের চিত্রে এভাবে:
     V.key = Object.assign({ t, k, cap }, BK.diagram({...}));
   ১. BK.diagram  — লেবেলযুক্ত চিত্র: বাংলা/ইংরেজি/দুটোই/লুকাও, অংশে চাপলে কাজ, লেবেল-কুইজ, জুম ও প্যান
   ২. BK.steps    — ধাপে ধাপে প্রক্রিয়া (মাইটোসিস, প্রোটিন সংশ্লেষণ…): টাইমলাইন, চালাও/থামাও, গতি
   ৩. BK.cycle    — চক্র (ক্রেবস, ক্যালভিন, কোষচক্র, জীবনচক্র): ঘুরন্ত বিন্দু, ঢোকা-বেরোনো পদার্থ
   ৪. BK.tree     — শ্রেণিবিন্যাস বা ভাগের গাছ, ভাঁজ করা যায়
   ৫. BK.mind     — মাইন্ড ম্যাপ (রঙিন শাখা), পাতায় চাপলে পাঠ খোলে
   ৬. BK.compare  — পার্থক্য: সারণি ও "কোনটির বৈশিষ্ট্য?" যাচাই খেলা
   ৭. BK.bars / BK.donut / BK.line — লেখচিত্র: স্তম্ভ, শতাংশের বৃত্ত, রেখা (চাপলে মান)
   ═══════════════════════════════════════════════════════════════════ */
(function () {
const FK = window.FK, X = window.VX, E = FK.el;
const BK = window.BK = {};
const LS = 'hsc-bk-lang';
BK.lang = (() => { try { return localStorage.getItem(LS) || 'bn'; } catch (e) { return 'bn'; } })();
BK.setLang = l => { BK.lang = l; try { localStorage.setItem(LS, l); } catch (e) { } document.dispatchEvent(new CustomEvent('bk-lang')); };
/* ═══ রং: প্রতিটি রঙের চারটি স্তর — lt (হালকা ভরাট), c (মূল ভরাট), dk (কিনারা), ink (লেখা)
   দুই থিমের জন্য আলাদা, আর ink সবসময় পটভূমির সাথে ৪.৮:১ এর বেশি কনট্রাস্ট রাখে ═══ */
const RAMP = [
  { lt: '#99f6e4', c: '#14b8a6', dk: '#0f766e', ink: '#0f766e', Dlt: '#115e59', Dc: '#2dd4bf', Ddk: '#5eead4', Dink: '#5eead4' },
  { lt: '#c7d2fe', c: '#6366f1', dk: '#4338ca', ink: '#4338ca', Dlt: '#312e81', Dc: '#818cf8', Ddk: '#a5b4fc', Dink: '#a5b4fc' },
  { lt: '#fed7aa', c: '#f97316', dk: '#c2410c', ink: '#c2410c', Dlt: '#7c2d12', Dc: '#fb923c', Ddk: '#fdba74', Dink: '#fdba74' },
  { lt: '#ddd6fe', c: '#8b5cf6', dk: '#6d28d9', ink: '#6d28d9', Dlt: '#4c1d95', Dc: '#a78bfa', Ddk: '#c4b5fd', Dink: '#c4b5fd' },
  { lt: '#fecdd3', c: '#f43f5e', dk: '#be123c', ink: '#be123c', Dlt: '#881337', Dc: '#fb7185', Ddk: '#fda4af', Dink: '#fda4af' },
  { lt: '#bae6fd', c: '#0ea5e9', dk: '#0369a1', ink: '#0369a1', Dlt: '#0c4a6e', Dc: '#38bdf8', Ddk: '#7dd3fc', Dink: '#7dd3fc' },
  { lt: '#fde68a', c: '#f59e0b', dk: '#a16207', ink: '#a16207', Dlt: '#78350f', Dc: '#fbbf24', Ddk: '#fcd34d', Dink: '#fcd34d' },
  { lt: '#d9f99d', c: '#84cc16', dk: '#4d7c0f', ink: '#4d7c0f', Dlt: '#365314', Dc: '#a3e635', Ddk: '#bef264', Dink: '#bef264' },
  { lt: '#fbcfe8', c: '#ec4899', dk: '#be185d', ink: '#be185d', Dlt: '#831843', Dc: '#f472b6', Ddk: '#f9a8d4', Dink: '#f9a8d4' },
  { lt: '#cbd5e1', c: '#64748b', dk: '#334155', ink: '#334155', Dlt: '#1e293b', Dc: '#94a3b8', Ddk: '#cbd5e1', Dink: '#cbd5e1' },
  /* ১০ = পান্না সবুজ (ক্লোরোপ্লাস্ট, সালোকসংশ্লেষণ), ১১ = জলপাই (কোষপ্রাচীর, উদ্ভিদদেহ) */
  { lt: '#a7f3d0', c: '#10b981', dk: '#047857', ink: '#047857', Dlt: '#064e3b', Dc: '#34d399', Ddk: '#6ee7b7', Dink: '#6ee7b7' },
  { lt: '#dce8b4', c: '#8aa34a', dk: '#5b6b2f', ink: '#5b6b2f', Dlt: '#3b4420', Dc: '#a8bf6a', Ddk: '#c3d98a', Dink: '#c3d98a' }
];
/* FK.dark() প্রতিবার getComputedStyle ডাকে — অ্যানিমেশনের প্রতি ফ্রেমে বহুবার ডাকলে ফোন ধীর হয়ে যায়।
   তাই থিম বদলানো পর্যন্ত উত্তরটি ও তৈরি স্তরগুলো জমা থাকে। */
let _dk = null, _cache = [];
const isDark = () => { if (_dk === null) _dk = FK.dark(); return _dk; };
try { new MutationObserver(() => { _dk = null; _cache = []; }).observe(document.documentElement, { attributes: true, attributeFilter: ['data-skin', 'data-theme', 'data-glass'] }); } catch (e) { }
const pick = r => isDark() ? { lt: r.Dlt, c: r.Dc, dk: r.Ddk, ink: r.Dink } : { lt: r.lt, c: r.c, dk: r.dk, ink: r.ink };
BK.ramp = i => { const k = ((i % RAMP.length) + RAMP.length) % RAMP.length; return _cache[k] || (_cache[k] = pick(RAMP[k])); };
BK.pal = i => BK.ramp(i).c;       /* ভরাটের রং */
BK.ink = i => BK.ramp(i).ink;     /* ঐ রঙের লেখা — পটভূমিতে পড়া যায় */
/* জীববিজ্ঞানের নির্দিষ্ট অর্থ (সব অধ্যায়ে এক): অঙ্গাণু, রক্ত, ক্ষারক */
const ORG = {
  nucleus: 3, nucleolus: 3, chromatin: 3, mito: 2, chloro: 10, plastid: 10, er: 1, ribo: 9,
  golgi: 6, vacuole: 5, lyso: 4, wall: 11, mem: 2, cyto: 6, cyto2: 9, peroxi: 0, cytoskel: 9,
  oxy: 4, deoxy: 1, lymph: 7, nerve: 6, bone: 9, muscle: 4, plant: 11, leaf: 10
};
BK.org = k => { const r = BK.ramp(ORG[k] != null ? ORG[k] : 9); return r; };
/* ক্ষারক: A সবুজ, T লাল, G ধূসর-নীল, C নীল (বইয়ের নিয়ম) */
BK.base = b => ({ A: BK.ramp(7), T: BK.ramp(4), G: BK.ramp(9), C: BK.ramp(5), U: BK.ramp(2) }[b] || BK.ramp(9));

/* ═══ গ্রেডিয়েন্ট ও কোমল ছায়া — ফিল্টার নয়, তাই দুর্বল GPU-তেও সস্তা ═══ */
let _gid = 0;
const defsOf = svg => { let d = svg.querySelector('defs'); if (!d) { d = E('defs', {}, svg); svg.insertBefore(d, svg.firstChild); } return d; };
/* রৈখিক গ্রেডিয়েন্ট: BK.lg(svg, '#aaa', '#333') → 'url(#bkg1)'; o.a = কোণ (ডিগ্রি), o.op = শেষ স্বচ্ছতা */
/* একই svg-তে একই রঙের গ্রেডিয়েন্ট বারবার না বানিয়ে আগেরটিই ফেরত দেয় —
   অ্যানিমেশনের প্রতি ফ্রেমে নতুন <linearGradient> তৈরি হলে defs ফুলে ওঠে ও ফোন ধীর হয় */
const memo = (svg, key, make) => { const m = svg._bkg || (svg._bkg = {}); return m[key] || (m[key] = make()); };
BK.lg = (svg, c1, c2, o = {}) => memo(svg, 'l|' + c1 + '|' + c2 + '|' + (o.a || '') + '|' + (o.mid || '') + '|' + (o.op || ''), () => {
  const id = 'bkg' + (++_gid), a = (o.a != null ? o.a : 115) * Math.PI / 180;
  const g = E('linearGradient', { id, x1: (.5 - Math.cos(a) / 2).toFixed(3), y1: (.5 - Math.sin(a) / 2).toFixed(3), x2: (.5 + Math.cos(a) / 2).toFixed(3), y2: (.5 + Math.sin(a) / 2).toFixed(3) }, defsOf(svg));
  E('stop', { offset: 0, 'stop-color': c1 }, g); if (o.mid) E('stop', { offset: .5, 'stop-color': o.mid }, g);
  E('stop', { offset: 1, 'stop-color': c2, 'stop-opacity': o.op != null ? o.op : 1 }, g);
  return `url(#${id})`;
});
/* গোলাকার গ্রেডিয়েন্ট (আয়তন বোঝাতে): আলো ওপর-বাঁ দিক থেকে */
BK.rg = (svg, c1, c2, o = {}) => memo(svg, 'r|' + c1 + '|' + c2 + '|' + (o.cx || '') + '|' + (o.cy || '') + '|' + (o.r || ''), () => {
  const id = 'bkr' + (++_gid);
  const g = E('radialGradient', { id, cx: o.cx != null ? o.cx : .34, cy: o.cy != null ? o.cy : .3, r: o.r != null ? o.r : .78 }, defsOf(svg));
  E('stop', { offset: 0, 'stop-color': c1 }, g); E('stop', { offset: 1, 'stop-color': c2 }, g);
  return `url(#${id})`;
});
/* একটি রঙের "আয়তনওয়ালা" ভরাট: হালকা থেকে মূল রঙে */
BK.fill = (svg, r, o = {}) => BK.rg(svg, o.hi || r.lt, r.c, o);
/* লেখা: CSS .fk-t ফন্ট-আকার বেঁধে দেয়, তাই style এ আকার ও রং */
const T = BK.T = (g, x, y, s, o = {}) => {
  const C = FK.P(), at = { x, y, class: 'fk-t' + (o.cls ? ' ' + o.cls : ''), style: `font-size:${o.fs || 12}px;fill:${o.c || C.fg}${o.st ? ';' + o.st : ''}` };
  if (o.a) at['text-anchor'] = o.a; if (o.w) at['font-weight'] = o.w;
  const t = E('text', at, g); t.innerHTML = typeof s === 'string' && s.indexOf('<su') >= 0 ? s.replace(/<sub>(.*?)<\/sub>/g, '<tspan baseline-shift="sub" font-size="75%">$1</tspan>').replace(/<sup>(.*?)<\/sup>/g, '<tspan baseline-shift="super" font-size="75%">$1</tspan>') : s; return t;
};
BK.sub = (b, s) => `${b}<tspan dy="3" font-size="9">${s}</tspan><tspan dy="-3"> </tspan>`;
const svgOf = (host, W, H, label) => E('svg', { viewBox: `0 0 ${W} ${H}`, class: 'fk-svg bk-svg', role: 'img', 'aria-label': label || 'চিত্র' }, host);
const bg = (svg, W, H) => E('rect', { x: 0, y: 0, width: W, height: H, rx: 12, fill: FK.P().sf, class: 'bk-bg' }, svg);
const pathOf = pts => pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
const arrowHead = (g, x, y, ang, c, s = 6) => E('path', { d: `M${x} ${y}l${(-s * Math.cos(ang - .45)).toFixed(1)} ${(-s * Math.sin(ang - .45)).toFixed(1)}M${x} ${y}l${(-s * Math.cos(ang + .45)).toFixed(1)} ${(-s * Math.sin(ang + .45)).toFixed(1)}`, stroke: c, 'stroke-width': 1.6, fill: 'none', 'stroke-linecap': 'round' }, g);
BK.arrow = (g, x1, y1, x2, y2, c, w = 1.6, dash) => { E('path', { d: `M${x1} ${y1}L${x2} ${y2}`, stroke: c, 'stroke-width': w, fill: 'none', 'stroke-dasharray': dash || null }, g); arrowHead(g, x2, y2, Math.atan2(y2 - y1, x2 - x1), c); };
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* ───────────── জুম ও প্যান (দুই আঙুলে চিমটি, এক আঙুলে টানা, বোতাম) ───────────── */
BK.zoom = (svg, W, H, root) => {
  let vb = { x: 0, y: 0, w: W, h: H }; const P = new Map(); let d0 = 0, v0 = null, c0 = null;
  const set = () => { vb.w = Math.max(W / 5, Math.min(W, vb.w)); vb.h = vb.w * H / W; vb.x = Math.max(0, Math.min(W - vb.w, vb.x)); vb.y = Math.max(0, Math.min(H - vb.h, vb.y)); svg.setAttribute('viewBox', `${vb.x.toFixed(1)} ${vb.y.toFixed(1)} ${vb.w.toFixed(1)} ${vb.h.toFixed(1)}`); svg.classList.toggle('bk-zoomed', vb.w < W - .5); };
  const toSvg = (cx, cy) => { const r = svg.getBoundingClientRect(); return [vb.x + (cx - r.left) / r.width * vb.w, vb.y + (cy - r.top) / r.height * vb.h]; };
  const zoomAt = (k, px, py) => { const nw = Math.max(W / 5, Math.min(W, vb.w / k)); const fx = (px - vb.x) / vb.w, fy = (py - vb.y) / vb.h; vb.x = px - fx * nw; vb.y = py - fy * nw * H / W; vb.w = nw; set(); };
  svg.addEventListener('pointerdown', e => { P.set(e.pointerId, [e.clientX, e.clientY]); if (P.size === 2) { const [a, b] = [...P.values()]; d0 = Math.hypot(a[0] - b[0], a[1] - b[1]); v0 = Object.assign({}, vb); c0 = toSvg((a[0] + b[0]) / 2, (a[1] + b[1]) / 2); } });
  svg.addEventListener('pointermove', e => {
    if (!P.has(e.pointerId)) return; const prev = P.get(e.pointerId); P.set(e.pointerId, [e.clientX, e.clientY]);
    if (P.size === 2 && v0) { const [a, b] = [...P.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]); vb = Object.assign({}, v0); zoomAt(d / d0, c0[0], c0[1]); e.preventDefault(); }
    else if (P.size === 1 && vb.w < W - .5) { const r = svg.getBoundingClientRect(); vb.x -= (e.clientX - prev[0]) / r.width * vb.w; vb.y -= (e.clientY - prev[1]) / r.height * vb.h; set(); e.preventDefault(); }
  });
  const up = e => { P.delete(e.pointerId); if (P.size < 2) v0 = null; };
  svg.addEventListener('pointerup', up); svg.addEventListener('pointercancel', up); svg.addEventListener('pointerleave', up);
  svg.style.touchAction = 'pan-y';
  const api = { in() { zoomAt(1.5, vb.x + vb.w / 2, vb.y + vb.h / 2); svg.style.touchAction = 'none'; }, out() { zoomAt(1 / 1.5, vb.x + vb.w / 2, vb.y + vb.h / 2); if (vb.w >= W - .5) svg.style.touchAction = 'pan-y'; }, reset() { vb = { x: 0, y: 0, w: W, h: H }; set(); svg.style.touchAction = 'pan-y'; }, focus(x, y, k = 2) { vb.w = W / k; vb.h = H / k; vb.x = x - vb.w / 2; vb.y = y - vb.h / 2; set(); svg.style.touchAction = 'none'; } };
  if (root) { FK.on(root, 'zin', api.in); FK.on(root, 'zout', api.out); FK.on(root, 'zr', api.reset); }
  return api;
};
const zoomBtns = () => `<span class="bk-zoom"><button type="button" class="btn sm" data-fk="zout" aria-label="ছোট করো">−</button><button type="button" class="btn sm" data-fk="zin" aria-label="বড় করো">+</button><button type="button" class="btn sm" data-fk="zr">পুরো</button></span>`;
const langSeg = () => X.seg('bklang', [['bn', 'বাংলা'], ['en', 'English'], ['both', 'দুটোই'], ['off', 'লেবেল লুকাও']], BK.lang);

/* ═════════ ১. লেবেলযুক্ত চিত্র ═════════
   spec: { W, H, label, art(g, C, part), parts: [{ id, bn, en, fn, a:[x,y], l:[x,y], an? }], extra?(g, C) }
   art এর ভেতরে part(id) ডাকলে সেই অংশের <g> পাওয়া যায় — সেটি চাপলে বা লেবেলে চাপলে অংশটি উজ্জ্বল হয় */
BK.diagram = spec => ({
  html: () => `<div class="fk-row">${langSeg()}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row bk-tools">${spec.idle ? `<button type="button" class="btn sm" data-pp></button>` : ''}${FK.btn('quiz', 'লেবেল-কুইজ', 'spark')}${zoomBtns()}</div><div class="bk-info" data-k="info" aria-live="polite"><span class="muted small">যেকোনো অংশ বা লেবেলে চাপ দাও — নাম ও কাজ এখানে দেখাবে। দুই আঙুলে বড় করা যায়।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = spec.W || 360, H = spec.H || 300;
    let C, svg, gArt, gIdle, gLab, sel = null, quiz = null, Z, A = null, tt = 0;
    const groups = {};
    const part = id => { const g = E('g', { class: 'bk-part', 'data-part': id }, gArt); groups[id] = g; return g; };
    const info = p => { if (!p) { $('info').innerHTML = '<span class="muted small">যেকোনো অংশ বা লেবেলে চাপ দাও।</span>'; return; } $('info').innerHTML = `<b>${p.bn}</b>${p.en ? ` <i class="muted">(${p.en})</i>` : ''}${p.fn ? `<div class="small">${p.fn}</div>` : ''}`; };
    const select = id => { sel = id; svg.classList.toggle('bk-sel', !!id); Object.entries(groups).forEach(([k, g]) => g.classList.toggle('bk-on', k === id)); gLab.querySelectorAll('[data-lab]').forEach(x => x.classList.toggle('bk-on', x.dataset.lab === id)); info(spec.parts.find(p => p.id === id)); };
    const labels = () => {
      gLab.innerHTML = ''; const L = BK.lang; if (L === 'off' && !quiz) return;
      spec.parts.forEach((p, i) => {
        const g = E('g', { 'data-lab': p.id, class: 'bk-lab' }, gLab), [ax, ay] = p.a, [lx, ly] = p.l, an = p.an || (lx < ax - 4 ? 'end' : lx > ax + 4 ? 'start' : 'middle');
        if (quiz) { E('circle', { cx: ax, cy: ay, r: 9, class: 'bk-qdot', fill: quiz.done[p.id] === 1 ? C.ok : quiz.done[p.id] === -1 ? C.bad : C.acc, stroke: C.sf, 'stroke-width': 1.5 }, g); T(g, ax, ay + 4, String(i + 1).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]), { fs: 10, a: 'middle', w: 650, c: '#fff', st: 'stroke:none' }); E('circle', { cx: ax, cy: ay, r: 16, fill: 'transparent' }, g); return; }
        E('path', { d: `M${ax} ${ay}L${lx} ${ly}`, stroke: C.mu, 'stroke-width': 1, fill: 'none' }, g); E('circle', { cx: ax, cy: ay, r: 2.4, fill: C.fg }, g);
        const tx = lx + (an === 'start' ? 3 : an === 'end' ? -3 : 0), ty = ly + (an === 'middle' ? (ly < ay ? -4 : 12) : 4);
        const lb = p.lb || p.bn, le = p.le || p.en || '';  /* lb/le: চিত্রে দেখানোর ছোট নাম (পুরো নাম তথ্য-ঘরে) */
        if (L === 'both') { T(g, tx, ty - 3, lb, { fs: 13, a: an, w: 560 }); T(g, tx, ty + 11, le, { fs: 11, a: an, c: C.mu, st: 'font-style:italic' }); }
        else T(g, tx, ty, L === 'en' ? (le || lb) : lb, { fs: 13, a: an, w: 560 });
      });
      if (sel) select(sel);
    };
    const draw = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = svgOf($('st'), W, H, spec.label); bg(svg, W, H);
      gArt = E('g', {}, svg); for (const k in groups) delete groups[k]; spec.art(gArt, C, part); gIdle = E('g', { style: 'pointer-events:none' }, svg); gLab = E('g', {}, svg); if (spec.extra) spec.extra(svg, C); if (spec.idle) spec.idle(gIdle, C, tt);
      labels(); Z = BK.zoom(svg, W, H, null);
      svg.addEventListener('click', e => { const l = e.target.closest('[data-lab]'), g = e.target.closest('[data-part]'), id = l ? l.dataset.lab : g ? g.dataset.part : null; if (quiz) { if (id) answer(id); return; } select(id && id !== sel ? id : null); });
    };
    /* লেবেল-কুইজ: নাম দেখাবে, ঠিক অংশটি চাপতে হবে */
    const ask = () => { const id = quiz.order[quiz.i]; if (!id) { const ok = Object.values(quiz.done).filter(v => v === 1).length; $('info').innerHTML = `<b>কুইজ শেষ!</b> ${FK.bn(ok)}/${FK.bn(spec.parts.length)} টি ঠিক। <button type="button" class="btn sm" data-bk="again">আবার</button> <button type="button" class="btn sm" data-bk="stop">লেবেল দেখাও</button>`; return; } const p = spec.parts.find(x => x.id === id); $('info').innerHTML = `<span class="chip acc">প্রশ্ন ${FK.bn(quiz.i + 1)}/${FK.bn(spec.parts.length)}</span> চাপ দাও: <b>${BK.lang === 'en' ? p.en || p.bn : p.bn}</b>${BK.lang === 'both' && p.en ? ` <i class="muted">(${p.en})</i>` : ''} <button type="button" class="btn sm" data-bk="stop">বন্ধ</button>`; };
    const answer = id => { const want = quiz.order[quiz.i]; if (!want) return; if (id === want) { if (quiz.done[want] == null) quiz.done[want] = 1; quiz.i++; labels(); ask(); } else { quiz.done[want] = -1; const g = gLab.querySelector(`[data-lab="${id}"] circle`); if (g) { g.setAttribute('fill', C.bad); setTimeout(labels, 450); } } };
    const startQuiz = () => { quiz = { order: shuffle(spec.parts.map(p => p.id)), i: 0, done: {} }; select(null); labels(); ask(); };
    $('info').addEventListener('click', e => { const b = e.target.closest('[data-bk]'); if (!b) return; if (b.dataset.bk === 'again') startQuiz(); else { quiz = null; labels(); info(null); } });
    FK.on(root, 'quiz', startQuiz);
    FK.on(root, 'zin', () => Z.in()); FK.on(root, 'zout', () => Z.out()); FK.on(root, 'zr', () => Z.reset());
    X.onSeg(root, 'bklang', l => { BK.setLang(l); });
    const onL = () => { root.querySelectorAll('[data-seg="bklang"] button').forEach(b => b.classList.toggle('on', b.dataset.k === BK.lang)); labels(); if (quiz) ask(); };
    document.addEventListener('bk-lang', onL);
    const unT = FK.onTheme(draw); draw();
    if (spec.idle) { A = X.anim(root, dt => { tt += dt; gIdle.innerHTML = ''; spec.idle(gIdle, C, tt); }, { paused: false }); X.pp(root, A); }
    return () => { unT(); if (A) A.stop(); document.removeEventListener('bk-lang', onL); };
  }
});

/* ═════════ ২. ধাপে ধাপে প্রক্রিয়া ═════════
   spec: { W, H, label, stages:[{ t, en?, d }], draw(g, C, s, u) — s = ধাপের ক্রম, u = ০→১ অগ্রগতি, dur?: সেকেন্ড/ধাপ } */
BK.steps = spec => ({
  html: () => `<div class="bk-chips" data-k="chips">${spec.stages.map((s, i) => `<button type="button" data-i="${i}">${FK.bn(i + 1)}. ${s.t}</button>`).join('')}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button>${X.seg('spd', [['.5', '0.5×'], ['1', '1×'], ['2', '2×']], '1')}</div><div class="fk-row"><input type="range" class="bk-scrub" data-k="scrub" min="0" max="${spec.stages.length}" step="0.001" value="0" aria-label="সময়রেখা"></div><div class="bk-info" data-k="cap" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = spec.W || 360, H = spec.H || 280, N = spec.stages.length, dur = spec.dur || 3;
    let C, svg, g, t = 0, spd = 1, last = -1;
    const base = () => { C = FK.P(); $('st').innerHTML = ''; svg = svgOf($('st'), W, H, spec.label); bg(svg, W, H); g = E('g', {}, svg); last = -1; paint(); };
    const paint = () => {
      const s = Math.min(N - 1, Math.floor(t)), u = Math.min(1, t - s); g.innerHTML = ''; spec.draw(g, C, s, FK.ease(Math.min(1, u * 1.25)), u);
      $('scrub').value = t;
      if (s !== last) { last = s; const st = spec.stages[s]; $('cap').innerHTML = `<b>${FK.bn(s + 1)}. ${st.t}</b>${st.en ? ` <i class="muted">(${st.en})</i>` : ''}<div class="small">${st.d || ''}</div>`; $('chips').querySelectorAll('button').forEach((b, i) => b.classList.toggle('on', i === s)); const b = $('chips').children[s]; if (b && b.scrollIntoView && A && !A.paused) b.parentNode.scrollLeft = b.offsetLeft - 40; }
    };
    const A = X.anim(root, dt => { t += dt * spd / dur; if (t >= N) t = 0; paint(); }, { paused: true });
    X.pp(root, A);
    $('scrub').addEventListener('input', e => { t = Math.min(N - .001, +e.target.value); paint(); });
    $('chips').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; t = +b.dataset.i + .999; paint(); });
    X.onSeg(root, 'spd', v => spd = +v);
    const unT = FK.onTheme(base); t = spec.start != null ? spec.start : .999; base();
    return () => { A.stop(); unT(); };
  }
});

/* ═════════ ৩. চক্র ═════════
   spec: { W, H, label, center, sub?, nodes:[{ t, en?, d, io?:[[text, 'in'|'out']] }], rx?, ry? } */
BK.cycle = spec => ({
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row"><button type="button" class="btn sm" data-pp></button>${FK.btn('nx', 'পরের ধাপ', 'next')}</div><div class="bk-info" data-k="info" aria-live="polite"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), W = spec.W || 360, H = spec.H || 340, N = spec.nodes.length, cx = W / 2, cy = H / 2, rx = spec.rx || 112, ry = spec.ry || 118;
    let C, svg, tok, cur = 0, ph = 0, nodesG = [];
    const P = i => { const a = -Math.PI / 2 + 2 * Math.PI * i / N; return [cx + rx * Math.cos(a), cy + ry * Math.sin(a), a]; };
    const show = i => { cur = (i + N) % N; const n = spec.nodes[cur]; nodesG.forEach((g, k) => g.classList.toggle('bk-on', k === cur)); $('info').innerHTML = `<span class="chip acc">${FK.bn(cur + 1)}/${FK.bn(N)}</span> <b>${n.t}</b>${n.en ? ` <i class="muted">(${n.en})</i>` : ''}<div class="small">${n.d || ''}</div>`; };
    const base = () => {
      C = FK.P(); $('st').innerHTML = ''; svg = svgOf($('st'), W, H, spec.label); bg(svg, W, H); nodesG = [];
      const RA = BK.ramp(0), RB = BK.ramp(1);
      E('ellipse', { cx, cy, rx, ry, fill: 'none', stroke: BK.lg(svg, FK.alpha(RA.c, .55), FK.alpha(RB.c, .55), { a: 45, mid: FK.alpha(BK.ramp(3).c, .5) }), 'stroke-width': 12 }, svg);
      E('ellipse', { cx, cy, rx, ry, fill: 'none', stroke: FK.alpha(C.sf, .5), 'stroke-width': 3 }, svg);
      for (let i = 0; i < N; i++) { const a0 = -Math.PI / 2 + 2 * Math.PI * (i + .5) / N, x = cx + rx * Math.cos(a0), y = cy + ry * Math.sin(a0), tang = Math.atan2(ry * Math.cos(a0), -rx * Math.sin(a0)); arrowHead(svg, x, y, tang, BK.ramp(i).dk, 9); }
      T(svg, cx, cy - 2, spec.center, { fs: 15, a: 'middle', w: 650, c: RA.ink }); if (spec.sub) T(svg, cx, cy + 16, spec.sub, { fs: 10.5, a: 'middle', c: C.mu });
      spec.nodes.forEach((n, i) => {
        const [x, y, a] = P(i), g = E('g', { class: 'bk-node', 'data-i': i, style: 'cursor:pointer' }, svg); nodesG.push(g);
        const w = Math.max(56, n.t.length * 6.6 + 18), Rn = BK.ramp(i);
        E('rect', { x: x - w / 2, y: y - 14, width: w, height: 28, rx: 14, fill: BK.lg(svg, Rn.lt, FK.alpha(Rn.c, .55), { a: 20 }), stroke: FK.alpha(Rn.c, .85), 'stroke-width': 1.5, class: 'bk-pill' }, g);
        T(g, x, y + 4.5, n.t, { fs: 12, a: 'middle', w: 560, c: Rn.ink });
        /* ঢোকা (সবুজ) ও বেরোনো (লাল) পদার্থ: পাশের নোডে রিংয়ের বাইরের দিকে নিচে, ওপর/নিচের নোডে বাইরের দিকে — কখনো পিলের সাথে মেশে না */
        (n.io || []).forEach(([t, dir], k) => { const ox = Math.cos(a), oy = Math.sin(a), side = Math.abs(ox) > .3, up = !side && oy < 0, an = side ? (ox > 0 ? 'start' : 'end') : 'middle', bx = side ? x + Math.sign(ox) * 8 : x, by = up ? y - 22 - k * 14 : y + 30 + k * 14, col = dir === 'in' ? C.ok : C.bad;
          T(g, bx, by, (dir === 'in' ? '+ ' : '') + t, { fs: 11, a: an, w: 650, c: col }); });
      });
      if (spec.nodes.some(n => n.io && n.io.length)) T(svg, 10, H - 22, '+ সবুজ: চক্রে ঢোকে', { fs: 10, c: C.ok, w: 560 }); if (spec.nodes.some(n => n.io && n.io.length)) T(svg, 10, H - 8, 'লাল: চক্র থেকে বেরোয়', { fs: 10, c: C.bad, w: 560 });
      tok = E('circle', { r: 6.5, fill: BK.ramp(4).c, stroke: C.sf, 'stroke-width': 2.5 }, svg);
      svg.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (g) { show(+g.dataset.i); ph = +g.dataset.i; } });
      show(cur);
    };
    const A = X.anim(root, dt => { ph += dt * .35; const i = Math.floor(ph) % N; if (i !== cur) show(i); const f = ph - Math.floor(ph), a = -Math.PI / 2 + 2 * Math.PI * (Math.floor(ph) % N + f) / N; FK.at(tok, { cx: cx + rx * Math.cos(a), cy: cy + ry * Math.sin(a) }); }, { paused: false });
    X.pp(root, A); FK.on(root, 'nx', () => { ph = Math.floor(ph) + 1; show(Math.floor(ph) % N); });
    const unT = FK.onTheme(base); base();
    return () => { A.stop(); unT(); };
  }
});

/* ═════════ ৪ ও ৫. গাছ ও মাইন্ড ম্যাপ ═════════
   data: { t, en?, d?, id?(পাঠ), c:[…] } — বাঁ থেকে ডানে সাজানো; শাখায় চাপলে ভাঁজ খোলে/বন্ধ হয়, id থাকলে পাঠে যাওয়ার বোতাম */
const layoutTree = (root, colW, rowH) => {
  let leaf = 0; const nodes = [], links = [];
  const walk = (n, d, par, col) => { const kids = n.open !== false ? (n.c || []) : []; const me = { n, d, col }; nodes.push(me); if (par) links.push([par, me]); if (kids.length) { kids.forEach((k, i) => walk(k, d + 1, me, d === 0 ? i : col)); me.y = (me.f = nodes.filter(x => x.d === d + 1 && links.some(l => l[0] === me && l[1] === x))).reduce((a, x) => a + x.y, 0) / me.f.length; } else me.y = leaf++ * rowH; me.x = d * colW; return me; };
  walk(root, 0, null, 0); return { nodes, links, H: leaf * rowH };
};
const wrapTxt = (s, n) => { const w = String(s).split(' '), L = []; let cur = ''; w.forEach(x => { if ((cur + ' ' + x).trim().length > n && cur) { L.push(cur); cur = x; } else cur = (cur + ' ' + x).trim(); }); if (cur) L.push(cur); return L.slice(0, 3); };
const treeVis = (data, mind, opt = {}) => ({
  html: () => `${opt.top || ''}<div class="bk-scroll" data-k="sc"><div data-k="st"></div></div><div class="fk-row">${FK.btn('all', 'সব খোলো', '')}${FK.btn('none', 'শুধু প্রধান শাখা', '')}</div><div class="bk-info" data-k="info" aria-live="polite"><span class="muted small">শাখায় চাপ দিলে ভেতরের বিষয় খোলে বা বন্ধ হয়।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), colW = opt.colW || (mind ? 150 : 128), rowH = opt.rowH || 40;
    const setAll = (n, v, d = 0) => { if (n.c && n.c.length) { n.open = d === 0 ? true : v; n.c.forEach(k => setAll(k, v, d + 1)); } };
    if (opt.collapse !== false) setAll(data, false);
    let tw = null, gk = 1;
    const draw = () => {
      const C = FK.P(), { nodes, links, H } = layoutTree(data, colW, rowH), depth = Math.max(...nodes.map(x => x.d)), W = Math.max(340, (depth + 1) * colW + 20), HH = Math.max(H, rowH) + 20;
      $('st').innerHTML = ''; const svg = E('svg', { width: W, height: HH, viewBox: `0 0 ${W} ${HH}`, class: 'fk-svg bk-svg bk-tree', role: 'img', 'aria-label': data.t }, $('st'));
      const g = E('g', { transform: 'translate(10,10)' }, svg), vis = o => Math.max(0, Math.min(1, gk * (depth + 1) - o.d));
      links.forEach(([a, b]) => { const col = mind ? BK.pal(b.col) : C.mu, x1 = a.x + (a.d === 0 ? (mind ? 112 : 106) : colW - 26), y1 = a.y + 12, x2 = b.x, y2 = b.y + 12; E('path', { d: `M${x1} ${y1}C${(x1 + x2) / 2} ${y1} ${(x1 + x2) / 2} ${y2} ${x2} ${y2}`, stroke: col, 'stroke-width': mind ? Math.max(1.4, 4 - b.d) : 1.4, fill: 'none', opacity: .85 * vis(b) }, g); });
      nodes.forEach(o => {
        const n = o.n, has = n.c && n.c.length, Rt = BK.ramp(o.col), col = Rt.c, bw = o.d === 0 ? (mind ? 112 : 106) : colW - 26, lines = wrapTxt(n.t, o.d === 0 ? 15 : 17);
        const vo = vis(o); if (vo <= 0) return;
        const gg = E('g', { class: 'bk-tn', 'data-p': nodes.indexOf(o), style: `cursor:pointer;opacity:${vo.toFixed(2)}` }, g), hh = Math.max(24, lines.length * 13 + 8);
        E('rect', { x: o.x, y: o.y + 12 - hh / 2, width: bw, height: hh, rx: mind ? hh / 2 : 8, fill: o.d === 0 ? BK.lg(svg, BK.ramp(0).c, BK.ramp(1).c, { a: 20 }) : mind ? Rt.lt : FK.alpha(Rt.lt, isDark() ? .3 : .42), stroke: o.d === 0 ? 'none' : FK.alpha(col, .8), 'stroke-width': o.d <= 1 ? 1.6 : 1.1 }, gg);
        lines.forEach((ln, i) => T(gg, o.x + 8, o.y + 12 + 4 + (i - (lines.length - 1) / 2) * 13, ln, { fs: o.d === 0 ? 12 : 11, w: o.d <= 1 ? 800 : 600, c: o.d === 0 ? '#fff' : o.d === 1 ? Rt.ink : C.fg, st: o.d === 0 ? 'stroke:none' : '' }));
        if (has) { const op = n.open !== false; E('circle', { cx: o.x + bw, cy: o.y + 12, r: 7, fill: C.sf, stroke: col, 'stroke-width': 1.4 }, gg); T(gg, o.x + bw, o.y + 16, op ? '−' : '+', { fs: 12, a: 'middle', w: 650, c: col }); }
        o.el = gg;
      });
      svg.addEventListener('click', e => { const gg = e.target.closest('[data-p]'); if (!gg) return; const o = nodes[+gg.dataset.p], n = o.n; if (n.c && n.c.length && o.d > 0) { n.open = n.open === false; play(); } $('info').innerHTML = `<b>${n.t}</b>${n.en ? ` <i class="muted">(${n.en})</i>` : ''}${n.d ? `<div class="small">${n.d}</div>` : ''}${n.id ? `<div style="margin-top:6px"><button type="button" class="btn sm primary" data-act="${n.sec ? 'sec' : 'lesson'}" data-id="${n.id}">পাঠে যাও</button></div>` : ''}`; });
    };
    const play = () => { if (tw) tw.stop(); tw = FK.tween(700, k => { gk = k; draw(); }); };
    FK.on(root, 'all', () => { setAll(data, true); play(); }); FK.on(root, 'none', () => { setAll(data, false); play(); });
    const unT = FK.onTheme(draw); play();
    return () => { unT(); if (tw) tw.stop(); };
  }
});
BK.tree = (data, opt) => treeVis(data, false, opt);
BK.mind = (data, opt) => treeVis(data, true, opt);

/* ═════════ ৬. পার্থক্য: সারণি ও যাচাই খেলা ═════════
   spec: { a, b, rows:[[বিষয়, a এর বৈশিষ্ট্য, b এর বৈশিষ্ট্য]] } */
BK.compare = spec => ({
  html: () => `<div class="fk-row">${X.seg('m', [['t', 'সারণি'], ['q', 'যাচাই খেলা']], 't')}</div><div data-k="box"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`); let m = 't', q = null;
    const table = () => `<div class="table-wrap"><table class="t bk-cmp"><thead><tr><th>বিষয়</th><th>${spec.a}</th><th>${spec.b}</th></tr></thead><tbody>${spec.rows.map((r, i) => `<tr data-r="${i}"><td><b>${r[0]}</b></td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('')}</tbody></table></div><p class="small muted">সারিতে চাপ দিলে সেটি চিহ্নিত হয় — নিজে বলতে পারো কিনা দেখো।</p>`;
    const nextQ = () => { if (q.i >= q.list.length) { $('box').innerHTML = `<div class="bk-info"><b>শেষ!</b> ${FK.bn(q.ok)}/${FK.bn(q.list.length)} টি ঠিক। <button type="button" class="btn sm" data-bk="re">আবার খেলো</button></div>`; return; } const [r, side] = q.list[q.i], row = spec.rows[r]; $('box').innerHTML = `<div class="bk-q"><span class="chip acc">${FK.bn(q.i + 1)}/${FK.bn(q.list.length)}</span> <span class="muted small">${row[0]}</span><div class="bk-q-t">“${row[side]}”</div><div class="small muted">এটি কোনটির বৈশিষ্ট্য?</div><div class="fk-row"><button type="button" class="btn" data-ans="1">${spec.a}</button><button type="button" class="btn" data-ans="2">${spec.b}</button></div><div data-k="fb" class="small"></div></div>`; };
    const startQ = () => { q = { list: shuffle(spec.rows.flatMap((r, i) => [[i, 1], [i, 2]])).slice(0, Math.min(10, spec.rows.length * 2)), i: 0, ok: 0 }; nextQ(); };
    const show = () => { if (m === 't') $('box').innerHTML = table(); else startQ(); };
    $('box').addEventListener('click', e => {
      const tr = e.target.closest('tr[data-r]'); if (tr) { tr.classList.toggle('bk-on'); return; }
      const b = e.target.closest('[data-ans]'); if (b && q) { const side = q.list[q.i][1], ok = +b.dataset.ans === side; if (ok) q.ok++; b.classList.add(ok ? 'ok' : 'no'); root.querySelectorAll('[data-ans]').forEach(x => x.disabled = true); const fb = $('fb'); if (fb) fb.innerHTML = ok ? '<b class="fk-ok">ঠিক!</b>' : `<b class="fk-no">হয়নি।</b> এটি ${side === 1 ? spec.a : spec.b} এর।`; setTimeout(() => { q.i++; nextQ(); }, ok ? 650 : 1400); return; }
      if (e.target.closest('[data-bk="re"]')) startQ();
    });
    X.onSeg(root, 'm', v => { m = v; show(); }); show();
  }
});

/* ═════════ ৭. লেখচিত্র ═════════ */
/* স্তম্ভ: spec { W?, H?, title?, unit?, items:[[নাম, মান, রং?]], max? } */
BK.bars = spec => ({
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row">${FK.btn('replay', 'আবার চালাও', 'reset')}</div><div class="bk-info" data-k="info"><span class="muted small">স্তম্ভে চাপ দিলে মান ও ব্যাখ্যা দেখাবে।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), it = spec.items, W = spec.W || 360, rowH = 32, H = spec.H || (it.length * rowH + 46), L = spec.labW || 112;
    let on = -1, tw = null;
    const draw = (k = 1) => {
      const C = FK.P(); $('st').innerHTML = ''; const svg = svgOf($('st'), W, H, spec.title); bg(svg, W, H); const mx = spec.max || Math.max(...it.map(x => x[1])) * 1.1;
      if (spec.title) T(svg, 12, 20, spec.title, { fs: 12.5, w: 560, c: C.mu, st: 'letter-spacing:.2px' });
      it.forEach(([n, v, c], i) => {
        const R0 = BK.ramp(i), col = c || R0.c, ink = c ? col : R0.ink, u = Math.max(0, Math.min(1, k * it.length - i * .55)), y = 32 + i * rowH, full = (W - L - 56) * v / mx, w = full * FK.ease(u), bh = rowH - 11, g = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg);
        T(g, L - 10, y + 16, n, { fs: 11.5, a: 'end', w: i === on ? 800 : 600, c: i === on ? ink : C.fg });
        E('rect', { x: L, y: y + 3, width: (W - L - 56), height: bh, rx: bh / 2, fill: FK.alpha(col, .11) }, g);
        E('rect', { x: L, y: y + 3, width: Math.max(bh, w), height: bh, rx: bh / 2, fill: BK.lg(svg, c ? col : R0.c, c ? col : R0.dk, { a: 20 }), stroke: i === on ? ink : 'none', 'stroke-width': 1.6 }, g);
        if (u > .55) T(g, L + Math.max(bh, w) + 8, y + 16, FK.n(v * u, spec.d != null ? spec.d : 1) + (spec.unit || ''), { fs: 11.5, w: 560, c: ink });
      });
      svg.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (!g) return; on = +g.dataset.i; const r = it[on]; $('info').innerHTML = `<b>${r[0]}</b>: ${FK.n(r[1], spec.d != null ? spec.d : 2)}${spec.unit || ''}${r[3] ? `<div class="small">${r[3]}</div>` : ''}`; draw(); });
    };
    const play = () => { if (tw) tw.stop(); tw = FK.tween(260 * it.length, k => draw(k)); };
    FK.on(root, 'replay', play);
    const unT = FK.onTheme(() => draw()); play();
    return () => { unT(); if (tw) tw.stop(); };
  }
});
/* শতাংশের বৃত্ত (ডোনাট): spec { title, center?, items:[[নাম, মান, রং?, ব্যাখ্যা?]] } */
BK.donut = spec => ({
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row">${FK.btn('replay', 'আবার চালাও', 'reset')}</div><div class="bk-info" data-k="info"><span class="muted small">অংশে চাপ দিলে বিস্তারিত দেখাবে।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), it = spec.items, W = 360, H = Math.max(240, 50 + it.length * 24), cx = 112, cy = H / 2 + 6, R = 82, r = 50, tot = it.reduce((a, x) => a + x[1], 0);
    let on = -1, tw = null;
    const draw = (k = 1) => {
      const C = FK.P(); $('st').innerHTML = ''; const svg = svgOf($('st'), W, H, spec.title); bg(svg, W, H); let a0 = -Math.PI / 2; const sw = FK.ease(Math.min(1, k)) * 2 * Math.PI;
      if (spec.title) T(svg, 12, 20, spec.title, { fs: 12.5, w: 560, c: C.mu, st: 'letter-spacing:.2px' });
      E('circle', { cx, cy, r: (R + r) / 2, fill: 'none', stroke: FK.alpha(C.mu, .18), 'stroke-width': R - r }, svg);
      it.forEach(([n, v, c], i) => {
        const span = 2 * Math.PI * v / tot, a1 = Math.min(a0 + span, -Math.PI / 2 + sw); if (a1 <= a0 + 1e-4) { a0 += span; return; }
        const big = a1 - a0 > Math.PI ? 1 : 0, kk = i === on ? 6 : 0, m = (a0 + a1) / 2, ox = kk * Math.cos(m), oy = kk * Math.sin(m), P = (rr, a) => [cx + ox + rr * Math.cos(a), cy + oy + rr * Math.sin(a)], [x1, y1] = P(R, a0), [x2, y2] = P(R, a1), [x3, y3] = P(r, a1), [x4, y4] = P(r, a0);
        const R0 = BK.ramp(i);
        E('path', { d: `M${x1} ${y1}A${R} ${R} 0 ${big} 1 ${x2} ${y2}L${x3} ${y3}A${r} ${r} 0 ${big} 0 ${x4} ${y4}Z`, fill: c || BK.lg(svg, R0.c, R0.dk, { a: (m * 180 / Math.PI) + 90 }), stroke: C.sf, 'stroke-width': 2.5, 'data-i': i, style: 'cursor:pointer' }, svg); a0 += span;
      });
      if (spec.center) T(svg, cx, cy + 5, spec.center, { fs: 13, a: 'middle', w: 650 });
      it.forEach(([n, v, c], i) => { const y = cy - it.length * 12 + i * 24 + 8, g = E('g', { 'data-i': i, style: 'cursor:pointer' }, svg); E('rect', { x: 212, y: y - 10, width: 13, height: 13, rx: 4, fill: c || BK.pal(i), opacity: k * it.length > i ? 1 : .25 }, g); T(g, 231, y + 1, `${n} ${FK.n(100 * v / tot, 1)}%`, { fs: 11.5, w: i === on ? 800 : 500, c: i === on ? BK.ink(i) : C.fg }); });
      svg.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (!g) return; on = +g.dataset.i; const x = it[on]; $('info').innerHTML = `<b>${x[0]}</b>: ${FK.n(100 * x[1] / tot, 1)}%${x[3] ? `<div class="small">${x[3]}</div>` : ''}`; draw(); });
    };
    const play = () => { if (tw) tw.stop(); tw = FK.tween(1100, k => draw(k)); };
    FK.on(root, 'replay', play);
    const unT = FK.onTheme(() => draw()); play();
    return () => { unT(); if (tw) tw.stop(); };
  }
});
/* রেখা: spec { title, x:[a,b], y:[a,b], lx, ly, series:[{ n, f(x) | pts, c? }], slider?:{ key, label, min, max, step, val, unit, mark(x)->text } } — FK.graph ব্যবহার করে */
BK.line = spec => ({
  html: () => `<div class="fk-stage" data-k="st"></div>${spec.slider ? `<div class="fk-row">${FK.sl('x', spec.slider.label, spec.slider.min, spec.slider.max, spec.slider.step, spec.slider.val, spec.slider.unit || '')}</div>` : ''}<div class="bk-info" data-k="info"></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`); let xv = spec.slider ? spec.slider.val : null;
    const G = FK.graph($('st'), { w: 360, h: spec.h || 250, x: spec.x, y: spec.y, lx: spec.lx, ly: spec.ly, dx: spec.dx, dy: spec.dy, label: spec.title, pad: { l: 40, b: 28, t: 16, r: 14 } });
    const paths = spec.series.map(() => G.path()), tags = spec.series.map(() => G.text({ anchor: 'end' })), dot = spec.slider ? spec.series.map(() => G.dot()) : [], vl = spec.slider ? G.path() : null;
    let drawK = 0, tw = null;
    const show = () => { const C = FK.P();
      spec.series.forEach((s, i) => { const full = s.pts || G.sample(s.f, spec.x[0], spec.x[1], 120), pts = full.slice(0, Math.max(2, Math.round(full.length * Math.max(.02, drawK)))); paths[i].set(pts, { stroke: s.c || BK.pal(i), width: 2.6 }); const lp = full[Math.floor(full.length * (s.tagAt || .85))]; tags[i].set(lp, drawK > .9 ? s.n : '', { dy: -7, color: s.c || BK.pal(i) }); FK.at(tags[i].e, { style: `font-size:11px;font-weight:800;fill:${s.c || BK.pal(i)}` }); if (xv != null && s.f) dot[i].set([xv, s.f(xv)], { color: s.c || BK.pal(i), r: 5, hide: drawK < .99 }); });
      if (xv != null) { vl.set([[xv, spec.y[0]], [xv, spec.y[1]]], { stroke: C.mu, width: 1, dash: '3 3', hide: drawK < .99 }); $('info').innerHTML = spec.slider.mark ? spec.slider.mark(xv) : ''; } };
    if (spec.slider) FK.bindSl(root, 'x', v => { xv = v; show(); }, spec.slider.unit || '', spec.slider.d != null ? spec.slider.d : 0);
    const unT = FK.onTheme(() => { G.axes && G.axes(); show(); });
    tw = FK.tween(900, k => { drawK = k; show(); });
    return () => { unT(); if (tw) tw.stop(); };
  }
});

/* ═════════ ৮. ধাপ-সিঁড়ি (শ্রেণিবিন্যাসের একক, স্তরক্রম) ═════════
   spec: { title, rows:[{ t, en?, ex?, d? }] } — ওপরে বড় থেকে নিচে ছোট; চাপলে ব্যাখ্যা; প্রথমবার ধীরে নেমে আসে */
BK.ladder = spec => ({
  html: () => `<div class="fk-stage bk-stage" data-k="st"></div><div class="bk-info" data-k="info"><span class="muted small">যেকোনো ধাপে চাপ দাও।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`), R = spec.rows, N = R.length, W = 360, rh = 34, H = N * rh + 40; let on = -1, tw = null;
    const draw = (k = 1) => {
      const C = FK.P(); $('st').innerHTML = ''; const svg = svgOf($('st'), W, H, spec.title); bg(svg, W, H);
      if (spec.title) T(svg, W / 2, 20, spec.title, { fs: 12, a: 'middle', w: 650, c: C.mu });
      R.forEach((r, i) => { const vis = Math.max(0, Math.min(1, k * N - i)); if (!vis) return; const w = W - 24 - i * (W - 150) / Math.max(1, N - 1), x = (W - w) / 2, y = 30 + i * rh, g = E('g', { 'data-i': i, style: `cursor:pointer;opacity:${vis.toFixed(2)}` }, svg);
        const Ri = BK.ramp(i);
        E('rect', { x, y: y + 2 - (1 - vis) * 8, width: w, height: rh - 6, rx: (rh - 6) / 2, fill: i === on ? BK.lg(svg, Ri.c, Ri.dk, { a: 20 }) : BK.lg(svg, Ri.lt, FK.alpha(Ri.c, .5), { a: 20 }), stroke: i === on ? 'none' : FK.alpha(Ri.c, .7), 'stroke-width': 1.3 }, g);
        T(g, W / 2, y + 17 - (1 - vis) * 8, `${r.t}${r.ex ? ' · ' + r.ex : ''}`, { fs: 12, a: 'middle', w: i === on ? 800 : 700, c: i === on ? '#fff' : Ri.ink, st: i === on ? 'stroke:none' : '' }); });
      svg.addEventListener('click', e => { const g = e.target.closest('[data-i]'); if (!g) return; on = +g.dataset.i; const r = R[on]; $('info').innerHTML = `<b>${r.t}</b>${r.en ? ` <i class="muted">(${r.en})</i>` : ''}${r.ex ? ` — উদাহরণ: <b>${r.ex}</b>` : ''}${r.d ? `<div class="small">${r.d}</div>` : ''}`; draw(); });
    };
    const unT = FK.onTheme(() => draw()); tw = FK.tween(1400, k => draw(k));
    return () => { unT(); tw && tw.stop(); };
  }
});


/* ═════════ ৯. ত্রিমাত্রিক মডেল ═════════
   দুটি ইঞ্জিন এক API-তে:
     • FK.s3 — ক্যানভাসে নিজেদের ইঞ্জিন (সব ফোনে চলে, দুর্বল ফোনে নিজে মান কমায়)। ডিফল্ট।
     • Three.js — build.py যদি vendor/three.min.js পায়, সেটি পাতায় <script type="text/plain"> হয়ে বসে;
       প্রথম ৩D চিত্র খুললে তখনই চালু হয় (পাতা খোলার সময় নয়) — তাই ৬০০ KB কখনো বিনা কারণে পার্স হয় না।
   spec.three(THREE, ctx) থাকলে ও Three.js পাওয়া গেলে সেটিই চলে, নইলে spec.draw(S) (FK.s3)। */
let _three = undefined;   /* undefined = চেষ্টা হয়নি, null = নেই */
BK.boot3d = () => {
  if (_three !== undefined) return Promise.resolve(_three);
  const el = document.getElementById('bk-three-src');
  if (!el || !el.textContent.trim()) { _three = null; return Promise.resolve(null); }
  try { const f = new Function(el.textContent + '\n;return (typeof THREE !== "undefined") ? THREE : (typeof exports !== "undefined" ? exports : null);'); _three = f() || null; }
  catch (e) { console.warn('three boot failed', e); _three = null; }
  return Promise.resolve(_three);
};
/* spec: { label, parts:[{id,bn,en,fn}], draw(S, ctx), three?(THREE, ctx), yaw, pitch, dist, h } */
BK.model3d = spec => ({
  html: () => `<div class="fk-row">${langSeg()}</div><div class="fk-stage bk-stage" data-k="st"></div><div class="fk-row bk-tools"><button type="button" class="btn sm" data-pp></button>${FK.btn('rs', 'সোজা করো', 'reset')}${spec.parts && spec.parts.length ? FK.btn('nx', 'পরের অংশ', 'next') : ''}</div>${spec.ctrl ? `<div class="fk-row">${spec.ctrl}</div>` : ''}<div class="bk-info" data-k="info" aria-live="polite"><span class="muted small">আঙুল দিয়ে ঘুরিয়ে দেখো; অংশে চাপ দিলে নাম ও কাজ দেখাবে।</span></div>`,
  mount(root) {
    const $ = k => root.querySelector(`[data-k="${k}"]`);
    const ctx = { sel: null, t: 0, lang: () => BK.lang, spin: true };
    const info = id => { const p = (spec.parts || []).find(x => x.id === id); if (!p) { $('info').innerHTML = '<span class="muted small">আঙুল দিয়ে ঘুরিয়ে দেখো; অংশে চাপ দিলে নাম ও কাজ দেখাবে।</span>'; return; } $('info').innerHTML = `<b>${p.bn}</b>${p.en ? ` <i class="muted">(${p.en})</i>` : ''}${p.fn ? `<div class="small">${p.fn}</div>` : ''}`; };
    const S = FK.s3($('st'), { label: spec.label, yaw: spec.yaw, pitch: spec.pitch, dist: spec.dist, h: spec.h, fov: spec.fov });
    S.draw = s => spec.draw(s, ctx);
    S.onTap = (x, y) => { const h = S.hit(x, y); const id = h && h.id; ctx.sel = (id && id !== ctx.sel) ? id : null; info(ctx.sel); S.frame(); };
    const A = X.anim(root, dt => { if (!ctx.spin) return; ctx.t += dt; S.yaw += dt * .28; S.frame(); }, { paused: false });
    X.pp(root, A);
    FK.on(root, 'rs', () => { S.reset(); });
    FK.on(root, 'nx', () => { const P = spec.parts || []; if (!P.length) return; const i = P.findIndex(p => p.id === ctx.sel); ctx.sel = P[(i + 1) % P.length].id; info(ctx.sel); S.frame(); });
    X.onSeg(root, 'bklang', l => BK.setLang(l));
    if (spec.wire) spec.wire(root, ctx, S);
    const onL = () => { root.querySelectorAll('[data-seg="bklang"] button').forEach(b => b.classList.toggle('on', b.dataset.k === BK.lang)); S.frame(); if (ctx.sel) info(ctx.sel); };
    document.addEventListener('bk-lang', onL);
    /* Three.js থাকলে ও spec.three দেওয়া থাকলে সেটি দিয়ে বদলে দাও */
    if (spec.three) BK.boot3d().then(TH => { if (TH) try { spec.three(TH, { host: $('st'), ctx, info, stop: () => { A.stop(); S.wrap && S.wrap.remove(); } }); } catch (e) { console.warn(e); } });
    return () => { A.stop(); document.removeEventListener('bk-lang', onL); };
  }
});

/* অধ্যায়ের মাইন্ড ম্যাপ: অধ্যায়ের অংশ → পাঠ থেকে আপনা-আপনি */
BK.chapterTree = (ch, secs) => ({ t: ch.t, c: secs.filter(s => s.cat !== 'E').map(s => ({ t: s.st || s.t, d: s.t, id: s.id, sec: 1, c: (s.L || []).map(l => ({ t: l.t, id: l.id })) })) });
})();
