/* ═══════════════════════════════════════════════════════════════════
   CORE · FK — ফিগার-কিট (পদার্থবিজ্ঞানের সব চিত্রের সাধারণ ভিত্তি)
   ───────────────────────────────────────────────────────────────────
   FK.P()            থিম-সচেতন অর্থবাহী রং (সরণ, বেগ, বল … , A/B/R, x/y/z অক্ষ)
   FK.n(x, d)        গাণিতিক সংখ্যা (ইংরেজি অঙ্ক), প্রকৃত বিয়োগ চিহ্ন (−), অপ্রয়োজনীয় শূন্য বাদ
   FK.plane(host,o)  ২D SVG তল: গ্রিড, অক্ষ, তীর, টানা-যায় হ্যান্ডেল, কোণ-চাপ, লেখা
   FK.cam(o)         ৩D প্রজেকশন (z উপরে), FK.orbit() আঙুলে ঘোরানো
   FK.sl(...)        স্লাইডার মার্কআপ;  FK.bindSl(root, key, fn)
   FK.look(t)        "কী লক্ষ করবে" নোট;  FK.chk(...) নিজে যাচাই প্রশ্ন (স্বয়ংক্রিয়)
   FK.steps(...)     ধাপে ধাপে চিত্রের বোতাম-বার
   নিয়ম: শুধু transform/opacity/attr বদলাও, rAF দিয়ে ড্র্যাগ থ্রটল, স্ক্রিনের বাইরে থামাও।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const X = window.VX, FK = window.FK = window.FK || {};
const NS = 'http://www.w3.org/2000/svg';
const BND = '০১২৩৪৫৬৭৮৯';
FK.D = Math.PI / 180;

/* ---------- numbers ---------- */
FK.n = (x, d = 2) => {
  if (x == null || isNaN(x)) return '—';
  if (!isFinite(x)) return '∞';
  let s = (+x).toFixed(d);
  if (s.indexOf('.') >= 0) s = s.replace(/0+$/, '').replace(/\.$/, '');
  if (s === '-0') s = '0';
  return s.replace('-', '−');   /* গাণিতিক মান: ইংরেজি অঙ্ক (বাংলা অঙ্ক কেবল FK.bn দিয়ে — গণনা/ক্রমিক) */
};
FK.bn = s => String(s).replace(/\d/g, c => BND[c]).replace(/-(?=\d|০|১|২|৩|৪|৫|৬|৭|৮|৯)/g, '−');
/* signed term for expressions like "3î − 2ĵ" */
FK.term = (v, u, first, d = 2) => { const a = Math.abs(v); const s = (a === 1 && u ? '' : FK.n(a, d)) + u; if (first) return (v < 0 ? '−' : '') + s; return (v < 0 ? ' − ' : ' + ') + s; };
FK.vecStr = (x, y, z, d = 2) => { const t = [[x, 'î'], [y, 'ĵ'], [z, 'k̂']].filter(p => p[0] != null && Math.abs(p[0]) > 1e-9); if (!t.length) return '0'; return t.map((p, i) => FK.term(p[0], p[1], i === 0, d)).join(''); };

/* ---------- colour ---------- */
const hex = c => { c = (c || '').trim(); let m;
  if ((m = c.match(/^#([0-9a-f]{3})$/i))) return m[1].split('').map(h => parseInt(h + h, 16));
  if ((m = c.match(/^#([0-9a-f]{6})/i))) return [0, 2, 4].map(i => parseInt(m[1].substr(i, 2), 16));
  if ((m = c.match(/rgba?\(([^)]+)\)/))) return m[1].split(',').slice(0, 3).map(v => +v);
  return [255, 255, 255]; };
const lum = c => { const [r, g, b] = hex(c).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * r + .7152 * g + .0722 * b; };
FK.dark = () => { const C = X.C(); return lum(C.bg || C.sf) < .2; };
FK.P = () => {
  const C = X.C(), dk = FK.dark();
  const p = dk ? {
    A: '#6FA8FF', B: '#FF9A5C', R: '#C4A1FF', D: '#4FD1C5',
    disp: '#B69CFF', vel: '#6FA8FF', acc: '#5ED68F', force: '#FF7B72', mom: '#FFB454', tq: '#F78FD6',
    x: '#FF7B72', y: '#5ED68F', z: '#6FA8FF', hl: '#FFD866', soft: 'rgba(255,255,255,.07)'
  } : {
    A: '#1D5FD1', B: '#D9480F', R: '#7048E8', D: '#0C8599',
    disp: '#7048E8', vel: '#1D5FD1', acc: '#2B8A3E', force: '#E03131', mom: '#E8590C', tq: '#C2255C',
    x: '#E03131', y: '#2B8A3E', z: '#1D5FD1', hl: '#F59F00', soft: 'rgba(0,0,0,.045)'
  };
  return Object.assign(p, { fg: C.fg, mu: C.mu, ln: C.ln, line: C.line, sf: C.sf, s2: C.s2, s3: C.s3, ok: C.ok, bad: C.bad, acc2: C.acc, font: C.font, mono: C.mono, dark: dk });
};
FK.alpha = (c, a) => { const [r, g, b] = hex(c); return `rgba(${r},${g},${b},${a})`; };

/* ---------- tiny DOM helpers ---------- */
FK.el = (tag, at, parent) => { const e = document.createElementNS(NS, tag); if (at) FK.at(e, at); if (parent) parent.appendChild(e); return e; };
FK.at = (e, at) => { for (const k in at) { const v = at[k]; if (v == null || v === false) e.removeAttribute(k); else e.setAttribute(k, v); } return e; };
const r1 = v => Math.round(v * 10) / 10;

/* ═════════════ 2D PLANE ═════════════ */
FK.plane = (host, o = {}) => {
  const w = o.w || 360, h = o.h || 260;
  const P = { w, h, s: o.scale || 30, ox: o.ox != null ? o.ox : w / 2, oy: o.oy != null ? o.oy : h / 2, yUp: o.yUp !== false };
  const svg = FK.el('svg', { viewBox: `0 0 ${w} ${h}`, class: 'fk-svg', role: 'img', 'aria-label': o.label || '' });
  if (o.maxW) svg.style.maxWidth = o.maxW + 'px';
  host.appendChild(svg);
  P.svg = svg;
  P.gGrid = FK.el('g', { class: 'fk-grid' }, svg);
  P.g = FK.el('g', {}, svg);
  P.gTop = FK.el('g', {}, svg);
  P.S = (x, y) => [P.ox + x * P.s, P.yUp ? P.oy - y * P.s : P.oy + y * P.s];
  P.W = (sx, sy) => [(sx - P.ox) / P.s, P.yUp ? (P.oy - sy) / P.s : (sy - P.oy) / P.s];
  P.client = (cx, cy) => { const m = svg.getScreenCTM(); if (!m) return [0, 0]; const pt = svg.createSVGPoint(); pt.x = cx; pt.y = cy; const q = pt.matrixTransform(m.inverse()); return [q.x, q.y]; };
  P.grid = (opt = {}) => {
    const C = FK.P(); P.gGrid.innerHTML = '';
    const step = opt.step || 1;
    if (opt.grid !== false) {
      const x0 = Math.ceil(-P.ox / P.s / step) * step, x1 = (w - P.ox) / P.s, y0 = Math.ceil(-(h - P.oy) / P.s / step) * step, y1 = P.oy / P.s;
      let d = '';
      for (let x = x0; x <= x1; x += step) { const sx = r1(P.ox + x * P.s); d += `M${sx} 0V${h}`; }
      for (let y = y0; y <= y1; y += step) { const sy = r1(P.oy - y * P.s); d += `M0 ${sy}H${w}`; }
      FK.el('path', { d, stroke: C.line, 'stroke-width': 1, fill: 'none', opacity: .7 }, P.gGrid);
    }
    if (opt.axes !== false) {
      const ax = C.ln;
      FK.el('path', { d: `M4 ${r1(P.oy)}H${w - 6}M${r1(P.ox)} ${h - 4}V6`, stroke: ax, 'stroke-width': 1.3, fill: 'none' }, P.gGrid);
      FK.el('path', { d: `M${w - 6} ${P.oy}l-7 -3.5v7z`, fill: ax }, P.gGrid);
      FK.el('path', { d: `M${P.ox} 6l-3.5 7h7z`, fill: ax }, P.gGrid);
      const lx = opt.lx || 'x', ly = opt.ly || 'y';
      FK.el('text', { x: w - 10, y: P.oy - 8, 'text-anchor': 'end', class: 'fk-t fk-ax' }, P.gGrid).textContent = lx;
      FK.el('text', { x: P.ox + 8, y: 16, class: 'fk-t fk-ax' }, P.gGrid).textContent = ly;
      if (opt.ticks) {
        for (let x = Math.ceil(-P.ox / P.s); x <= (w - P.ox) / P.s - .5; x++) { if (!x) continue; const sx = P.ox + x * P.s; FK.el('text', { x: sx, y: P.oy + 14, 'text-anchor': 'middle', class: 'fk-t fk-tick' }, P.gGrid).textContent = FK.n(x); }
        for (let y = Math.ceil(-(h - P.oy) / P.s); y <= P.oy / P.s - .5; y++) { if (!y) continue; const sy = P.oy - y * P.s; FK.el('text', { x: P.ox - 6, y: sy + 4, 'text-anchor': 'end', class: 'fk-t fk-tick' }, P.gGrid).textContent = FK.n(y); }
        FK.el('text', { x: P.ox - 6, y: P.oy + 14, 'text-anchor': 'end', class: 'fk-t fk-tick' }, P.gGrid).textContent = 'O';
      }
    }
  };
  /* arrow in WORLD coords; returns {set(a,b,opt), g} */
  P.arrow = (opt = {}) => {
    const g = FK.el('g', { class: 'fk-vec' }, opt.top ? P.gTop : P.g);
    const ln = FK.el('line', { 'stroke-linecap': 'round' }, g);
    const hd = FK.el('path', {}, g);
    const tx = FK.el('text', { class: 'fk-t fk-vl', 'text-anchor': 'middle' }, g);
    const A = { g, opt };
    A.set = (a, b, o2 = {}) => {
      const op = Object.assign({}, opt, o2);
      const [x1, y1] = P.S(a[0], a[1]), [x2, y2] = P.S(b[0], b[1]);
      const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy), wd = op.width || 3;
      const col = op.color || FK.P().A;
      g.style.display = op.hide ? 'none' : '';
      if (L < 0.5) { ln.setAttribute('x1', x1); ln.setAttribute('x2', x1); ln.setAttribute('y1', y1); ln.setAttribute('y2', y1); hd.setAttribute('d', ''); FK.at(tx, { x: x1, y: y1 - 10 }); tx.textContent = op.label || ''; tx.setAttribute('fill', col); return A; }
      const ux = dx / L, uy = dy / L, hl = Math.min(op.head || (8 + wd * 2), L * 0.55), hw = hl * 0.55;
      const bx = x2 - ux * hl, by = y2 - uy * hl;
      FK.at(ln, { x1: r1(x1), y1: r1(y1), x2: r1(bx + ux * 1), y2: r1(by + uy * 1), stroke: col, 'stroke-width': wd, 'stroke-dasharray': op.dash || null, opacity: op.op != null ? op.op : null });
      FK.at(hd, { d: `M${r1(x2)} ${r1(y2)}L${r1(bx - uy * hw)} ${r1(by + ux * hw)}L${r1(bx + uy * hw)} ${r1(by - ux * hw)}Z`, fill: col, opacity: op.op != null ? op.op : null });
      if (op.label) {
        const side = op.side || 1, off = op.loff || 14, t = op.lt != null ? op.lt : 0.55;
        const mx = x1 + dx * t - uy * off * side, my = y1 + dy * t + ux * off * side;
        FK.at(tx, { x: r1(mx), y: r1(my + 4), fill: col }); tx.innerHTML = op.label;
      } else tx.textContent = '';
      return A;
    };
    return A;
  };
  P.line = (opt = {}) => { const e = FK.el('line', { 'stroke-linecap': 'round' }, opt.top ? P.gTop : P.g); return { e, set(a, b, o2 = {}) { const op = Object.assign({}, opt, o2); const [x1, y1] = P.S(a[0], a[1]), [x2, y2] = P.S(b[0], b[1]); FK.at(e, { x1: r1(x1), y1: r1(y1), x2: r1(x2), y2: r1(y2), stroke: op.color || FK.P().mu, 'stroke-width': op.width || 1.5, 'stroke-dasharray': op.dash || null, opacity: op.op != null ? op.op : null }); e.style.display = op.hide ? 'none' : ''; } }; };
  P.poly = (opt = {}) => { const e = FK.el('path', {}, opt.top ? P.gTop : P.g); return { e, set(pts, o2 = {}) { const op = Object.assign({}, opt, o2); const d = pts.map((p, i) => { const [x, y] = P.S(p[0], p[1]); return (i ? 'L' : 'M') + r1(x) + ' ' + r1(y); }).join('') + (op.open ? '' : 'Z'); FK.at(e, { d, fill: op.fill || 'none', stroke: op.stroke || 'none', 'stroke-width': op.width || 1.5, 'stroke-dasharray': op.dash || null, opacity: op.op != null ? op.op : null }); e.style.display = op.hide ? 'none' : ''; } }; };
  P.text = (opt = {}) => { const e = FK.el('text', { class: 'fk-t ' + (opt.cls || ''), 'text-anchor': opt.anchor || 'middle' }, opt.top === false ? P.g : P.gTop); return { e, set(p, txt, o2 = {}) { const op = Object.assign({}, opt, o2); const [x, y] = op.screen ? p : P.S(p[0], p[1]); FK.at(e, { x: r1(x + (op.dx || 0)), y: r1(y + (op.dy || 0)), fill: op.color || FK.P().fg }); if (txt != null) e.innerHTML = txt; e.style.display = op.hide ? 'none' : ''; } }; };
  P.dot = (opt = {}) => { const e = FK.el('circle', {}, opt.top ? P.gTop : P.g); return { e, set(p, o2 = {}) { const op = Object.assign({}, opt, o2); const [x, y] = P.S(p[0], p[1]); FK.at(e, { cx: r1(x), cy: r1(y), r: op.r || 4, fill: op.color || FK.P().fg, stroke: op.stroke || null, 'stroke-width': op.sw || null }); e.style.display = op.hide ? 'none' : ''; } }; };
  /* angle arc at centre c (world), from angle a0 to a1 (radians, math direction), radius in px */
  P.arc = (opt = {}) => {
    const g = FK.el('g', {}, P.g), pa = FK.el('path', { fill: 'none' }, g), fl = FK.el('path', {}, g), tx = FK.el('text', { class: 'fk-t fk-al', 'text-anchor': 'middle' }, g);
    return { g, set(c, a0, a1, o2 = {}) {
      const op = Object.assign({}, opt, o2), r = op.r || 26, [cx, cy] = P.S(c[0], c[1]), col = op.color || FK.P().hl;
      let da = a1 - a0; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
      if (op.full) { da = a1 - a0; }
      g.style.display = op.hide || Math.abs(da) < 0.01 ? 'none' : '';
      const sg = P.yUp ? -1 : 1;
      const p0 = [cx + r * Math.cos(a0), cy + sg * r * Math.sin(a0)], p1 = [cx + r * Math.cos(a0 + da), cy + sg * r * Math.sin(a0 + da)];
      const large = Math.abs(da) > Math.PI ? 1 : 0, sweep = (da > 0) === (sg < 0) ? 0 : 1;
      const arcD = `M${r1(p0[0])} ${r1(p0[1])}A${r} ${r} 0 ${large} ${sweep} ${r1(p1[0])} ${r1(p1[1])}`;
      FK.at(pa, { d: arcD, stroke: col, 'stroke-width': op.width || 2 });
      FK.at(fl, { d: `M${r1(cx)} ${r1(cy)}L${r1(p0[0])} ${r1(p0[1])}` + arcD.replace(/^M[^A]+/, '') + 'Z', fill: FK.alpha(col, .14) });
      const am = a0 + da / 2, lr = r + (op.lr || 12);
      FK.at(tx, { x: r1(cx + lr * Math.cos(am)), y: r1(cy + sg * lr * Math.sin(am) + 4), fill: col }); tx.innerHTML = op.label || '';
    } };
  };
  /* right-angle marker at corner p between directions u and v (world unit vectors) */
  P.rt = (opt = {}) => { const e = FK.el('path', { fill: 'none' }, P.g); return { e, set(p, u, v, o2 = {}) { const op = Object.assign({}, opt, o2), k = (op.size || 9) / P.s; const a = [p[0] + u[0] * k, p[1] + u[1] * k], b = [a[0] + v[0] * k, a[1] + v[1] * k], c = [p[0] + v[0] * k, p[1] + v[1] * k]; const [x1, y1] = P.S(a[0], a[1]), [x2, y2] = P.S(b[0], b[1]), [x3, y3] = P.S(c[0], c[1]); FK.at(e, { d: `M${r1(x1)} ${r1(y1)}L${r1(x2)} ${r1(y2)}L${r1(x3)} ${r1(y3)}`, stroke: op.color || FK.P().mu, 'stroke-width': 1.3 }); e.style.display = op.hide ? 'none' : ''; } }; };
  /* draggable handle: get() -> [x,y] world, set([x,y]) ; opts {color, snap, bound:[x0,y0,x1,y1], label} */
  P.handle = (get, set, opt = {}) => {
    const g = FK.el('g', { class: 'fk-h', tabindex: 0, role: 'slider', 'aria-label': opt.aria || 'টেনে সরাও' }, P.gTop);
    const hit = FK.el('circle', { r: 22, fill: 'transparent' }, g);
    const ring = FK.el('circle', { r: 9, 'stroke-width': 2.5 }, g);
    const core = FK.el('circle', { r: 3.2 }, g);
    const H = { g, opt };
    const paint = () => { const [x, y] = P.S(...get()); const col = opt.color || FK.P().A; FK.at(g, { transform: `translate(${r1(x)} ${r1(y)})` }); FK.at(ring, { fill: FK.alpha(col, .18), stroke: col }); FK.at(core, { fill: col }); };
    H.paint = paint;
    const clampP = p => { let [x, y] = p; const sn = opt.snap; if (sn) { x = Math.round(x / sn) * sn; y = Math.round(y / sn) * sn; } const b = opt.bound || [(-P.ox + 8) / P.s, -(h - P.oy - 8) / P.s, (w - P.ox - 8) / P.s, (P.oy - 8) / P.s]; x = Math.max(b[0], Math.min(b[2], x)); y = Math.max(b[1], Math.min(b[3], y)); if (opt.filter) [x, y] = opt.filter([x, y]); return [x, y]; };
    let down = false, raf = 0, pend = null, off = [0, 0];
    const flush = () => { raf = 0; if (!pend) return; const [sx, sy] = P.client(pend[0], pend[1]); const wp = P.W(sx, sy); set(clampP([wp[0] + off[0], wp[1] + off[1]])); pend = null; paint(); if (opt.onMove) opt.onMove(); };
    g.addEventListener('pointerdown', e => { down = true; g.classList.add('on'); try { g.setPointerCapture(e.pointerId); } catch (_) { } const [sx, sy] = P.client(e.clientX, e.clientY); const wp = P.W(sx, sy), cur = get(); off = [cur[0] - wp[0], cur[1] - wp[1]]; e.preventDefault(); if (opt.onStart) opt.onStart(); });
    g.addEventListener('pointermove', e => { if (!down) return; pend = [e.clientX, e.clientY]; if (!raf) raf = requestAnimationFrame(flush); });
    const up = () => { if (!down) return; down = false; g.classList.remove('on'); if (opt.onEnd) opt.onEnd(); };
    g.addEventListener('pointerup', up); g.addEventListener('pointercancel', up); g.addEventListener('lostpointercapture', up);
    g.addEventListener('touchstart', e => e.preventDefault(), { passive: false });
    g.addEventListener('keydown', e => { const st = opt.snap || 0.25; const k = { ArrowLeft: [-st, 0], ArrowRight: [st, 0], ArrowUp: [0, st], ArrowDown: [0, -st] }[e.key]; if (!k) return; e.preventDefault(); const c = get(); set(clampP([c[0] + k[0], c[1] + k[1]])); paint(); if (opt.onMove) opt.onMove(); if (opt.onEnd) opt.onEnd(); });
    paint(); return H;
  };
  P.clear = () => { P.g.innerHTML = ''; P.gTop.innerHTML = ''; };
  return P;
};


/* ═════════════ GRAPH (separate x/y scales) ═════════════
   FK.graph(host, {w, h, x:[x0,x1], y:[y0,y1], pad:{l,r,t,b}, lx, ly, ux, uy, dx, dy})
   G.S(x,y) → screen; G.path(pts, opt) → element; G.set({x,y}) changes ranges and redraws axes */
FK.graph = (host, o = {}) => {
  const w = o.w || 360, h = o.h || 150, pad = Object.assign({ l: 40, r: 14, t: 12, b: 26 }, o.pad || {});
  const svg = FK.el('svg', { viewBox: `0 0 ${w} ${h}`, class: 'fk-svg fk-graph', role: 'img', 'aria-label': o.label || '' }, host);
  const G = { svg, w, h, pad, x: (o.x || [0, 10]).slice(), y: (o.y || [0, 10]).slice() }; const NF = o.en ? (v, d) => FK.ne(v, d) : FK.n;
  G.gAx = FK.el('g', {}, svg); G.g = FK.el('g', {}, svg); G.gTop = FK.el('g', {}, svg);
  const nice = span => { const raw = span / 5, p = Math.pow(10, Math.floor(Math.log10(raw || 1))), m = raw / p; return (m < 1.5 ? 1 : m < 3 ? 2 : m < 7 ? 5 : 10) * p; };
  G.S = (x, y) => [pad.l + (x - G.x[0]) / (G.x[1] - G.x[0]) * (w - pad.l - pad.r), h - pad.b - (y - G.y[0]) / (G.y[1] - G.y[0]) * (h - pad.t - pad.b)];
  G.axes = () => {
    const C = FK.P(); G.gAx.innerHTML = '';
    const dx = o.dx || nice(G.x[1] - G.x[0]), dy = o.dy || nice(G.y[1] - G.y[0]);
    let d = '';
    for (let x = Math.ceil(G.x[0] / dx) * dx; x <= G.x[1] + 1e-9; x += dx) { const [sx] = G.S(x, 0); d += `M${sx.toFixed(1)} ${pad.t}V${h - pad.b}`; FK.el('text', { x: sx, y: h - pad.b + 14, 'text-anchor': 'middle', class: 'fk-t fk-tick' }, G.gAx).textContent = NF(x, 2); }
    for (let y = Math.ceil(G.y[0] / dy) * dy; y <= G.y[1] + 1e-9; y += dy) { const [, sy] = G.S(0, y); d += `M${pad.l} ${sy.toFixed(1)}H${w - pad.r}`; FK.el('text', { x: pad.l - 5, y: sy + 4, 'text-anchor': 'end', class: 'fk-t fk-tick' }, G.gAx).textContent = NF(y, 2); }
    FK.el('path', { d, stroke: C.line, 'stroke-width': 1, fill: 'none', opacity: .8 }, G.gAx);
    const y0 = Math.max(G.y[0], Math.min(G.y[1], 0)), x0 = Math.max(G.x[0], Math.min(G.x[1], 0));
    const [, sy0] = G.S(0, y0), [sx0] = G.S(x0, 0);
    FK.el('path', { d: `M${pad.l} ${sy0.toFixed(1)}H${w - pad.r + 4}M${sx0.toFixed(1)} ${h - pad.b}V${pad.t - 4}`, stroke: C.ln, 'stroke-width': 1.4, fill: 'none' }, G.gAx);
    FK.el('path', { d: `M${w - pad.r + 6} ${sy0}l-7 -3.5v7z`, fill: C.ln }, G.gAx);
    FK.el('path', { d: `M${sx0} ${pad.t - 6}l-3.5 7h7z`, fill: C.ln }, G.gAx);
    if (o.lx) FK.el('text', { x: w - pad.r, y: sy0 - 6, 'text-anchor': 'end', class: 'fk-t fk-ax' }, G.gAx).innerHTML = o.lx;
    if (o.ly) FK.el('text', { x: sx0 + 6, y: pad.t + 4, class: 'fk-t fk-ax' }, G.gAx).innerHTML = o.ly;
  };
  G.set = r => { if (r.x) G.x = r.x.slice(); if (r.y) G.y = r.y.slice(); G.axes(); };
  G.path = (opt = {}) => { const e = FK.el('path', { fill: 'none', 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, opt.top ? G.gTop : G.g); return { e, set(pts, o2 = {}) { const op = Object.assign({}, opt, o2); if (!pts.length) { e.setAttribute('d', ''); return; } let d = pts.map((p, i) => { const [x, y] = G.S(p[0], p[1]); return (i ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); }).join(''); if (op.fillTo != null) { const [xa, ya] = G.S(pts[pts.length - 1][0], op.fillTo), [xb] = G.S(pts[0][0], op.fillTo); d += `L${xa.toFixed(1)} ${ya.toFixed(1)}L${xb.toFixed(1)} ${ya.toFixed(1)}Z`; } FK.at(e, { d, stroke: op.stroke || 'none', fill: op.fill || 'none', 'stroke-width': op.width || 2.4, 'stroke-dasharray': op.dash || null, opacity: op.op != null ? op.op : null }); e.style.display = op.hide ? 'none' : ''; } }; };
  G.dot = (opt = {}) => { const e = FK.el('circle', {}, G.gTop); return { e, set(p, o2 = {}) { const op = Object.assign({}, opt, o2); const [x, y] = G.S(p[0], p[1]); FK.at(e, { cx: x.toFixed(1), cy: y.toFixed(1), r: op.r || 4.5, fill: op.color || FK.P().fg, stroke: FK.P().sf, 'stroke-width': 1.5 }); e.style.display = op.hide ? 'none' : ''; } }; };
  G.vline = (opt = {}) => { const e = FK.el('line', {}, G.gTop); return { e, set(x, o2 = {}) { const op = Object.assign({}, opt, o2); const [sx] = G.S(x, 0); FK.at(e, { x1: sx.toFixed(1), x2: sx.toFixed(1), y1: pad.t, y2: h - pad.b, stroke: op.color || FK.P().mu, 'stroke-width': 1.2, 'stroke-dasharray': '4 4' }); e.style.display = op.hide ? 'none' : ''; } }; };
  G.text = (opt = {}) => { const e = FK.el('text', { class: 'fk-t ' + (opt.cls || ''), 'text-anchor': opt.anchor || 'middle' }, G.gTop); return { e, set(p, txt, o2 = {}) { const op = Object.assign({}, opt, o2); const [x, y] = op.screen ? p : G.S(p[0], p[1]); FK.at(e, { x: (x + (op.dx || 0)).toFixed(1), y: (y + (op.dy || 0)).toFixed(1), fill: op.color || FK.P().fg }); if (txt != null) e.innerHTML = txt; e.style.display = op.hide ? 'none' : ''; } }; };
  G.sample = (f, a, b, N = 80) => { const out = []; for (let i = 0; i <= N; i++) { const x = a + (b - a) * i / N; out.push([x, f(x)]); } return out; };
  G.axes();
  return G;
};

/* ═════════════ 3D CAMERA (z up, right-handed) ═════════════ */
FK.cam = (o = {}) => {
  const C = { yaw: o.yaw != null ? o.yaw : -0.65, pitch: o.pitch != null ? o.pitch : 0.42, s: o.scale || 40, cx: o.cx || 180, cy: o.cy || 150 };
  C.P = p => {
    const [x, y, z] = p, cy = Math.cos(C.yaw), sy = Math.sin(C.yaw), cp = Math.cos(C.pitch), sp = Math.sin(C.pitch);
    const X1 = x * cy - y * sy, Y1 = x * sy + y * cy; /* rotate about z (Y1 = into the screen) */
    const up = z * cp + Y1 * sp, depth = Y1 * cp - z * sp; /* camera above, looking down by pitch */
    return [C.cx + X1 * C.s, C.cy - up * C.s, depth];
  };
  return C;
};
/* horizontal drag on el rotates yaw; returns cleanup. onUser fires on first interaction */
FK.orbit = (el, cam, redraw, opt = {}) => {
  let down = false, lx = 0, ly = 0, raf = 0, dx = 0, dy = 0;
  const flush = () => { raf = 0; cam.yaw += dx * 0.011; if (opt.pitch !== false) cam.pitch = Math.max(-0.2, Math.min(1.35, cam.pitch + dy * 0.008)); dx = dy = 0; redraw(); };
  const pd = e => { if (e.target.closest && e.target.closest('.fk-h')) return; down = true; lx = e.clientX; ly = e.clientY; try { el.setPointerCapture(e.pointerId); } catch (_) { } if (opt.onUser) opt.onUser(); };
  const pm = e => { if (!down) return; dx += e.clientX - lx; dy += e.pointerType === 'touch' ? 0 : e.clientY - ly; lx = e.clientX; ly = e.clientY; if (!raf) raf = requestAnimationFrame(flush); };
  const pu = () => { down = false; };
  el.addEventListener('pointerdown', pd); el.addEventListener('pointermove', pm); el.addEventListener('pointerup', pu); el.addEventListener('pointercancel', pu);
  el.classList.add('fk-orbit');
  return () => { el.removeEventListener('pointerdown', pd); el.removeEventListener('pointermove', pm); };
};
/* 3D arrow drawing helper on an svg group using cam; returns element group updated each frame */
FK.arrow3 = (parent) => {
  const g = FK.el('g', {}, parent), ln = FK.el('line', { 'stroke-linecap': 'round' }, g), hd = FK.el('path', {}, g), tx = FK.el('text', { class: 'fk-t fk-vl', 'text-anchor': 'middle' }, g);
  return { g, set(cam, a, b, op = {}) {
    const A = cam.P(a), B = cam.P(b), col = op.color || FK.P().A, wd = op.width || 3;
    g.style.display = op.hide ? 'none' : '';
    const dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy);
    if (L < 1) { FK.at(ln, { x1: A[0], y1: A[1], x2: A[0], y2: A[1] }); hd.setAttribute('d', ''); tx.textContent = ''; return; }
    const ux = dx / L, uy = dy / L, hl = Math.min(op.head || 8 + wd * 2, L * .5), hw = hl * .55, bx = B[0] - ux * hl, by = B[1] - uy * hl;
    FK.at(ln, { x1: r1(A[0]), y1: r1(A[1]), x2: r1(bx + ux), y2: r1(by + uy), stroke: col, 'stroke-width': wd, 'stroke-dasharray': op.dash || null, opacity: op.op != null ? op.op : null });
    FK.at(hd, { d: `M${r1(B[0])} ${r1(B[1])}L${r1(bx - uy * hw)} ${r1(by + ux * hw)}L${r1(bx + uy * hw)} ${r1(by - ux * hw)}Z`, fill: col, opacity: op.op != null ? op.op : null });
    if (op.label) { const t = op.lt != null ? op.lt : 1, off = op.loff != null ? op.loff : 12; FK.at(tx, { x: r1(A[0] + dx * t + ux * off - uy * (op.side || 0) * 10), y: r1(A[1] + dy * t + uy * off + 4 + ux * (op.side || 0) * 10), fill: col }); tx.innerHTML = op.label; } else tx.textContent = '';
    g._z = -(A[2] + B[2]) / 2; /* larger = nearer; zsort draws far first */
  } };
};
/* sort children of a group by _z (far first) */
FK.zsort = g => { const k = Array.from(g.children).sort((a, b) => (a._z || 0) - (b._z || 0)); k.forEach(c => g.appendChild(c)); };
/* draw 3D axes (x,y,z) with labels into group */
FK.axes3 = (parent, cam, L = 3, opt = {}) => {
  const C = FK.P(); parent.innerHTML = '';
  const ax = [['x', [L, 0, 0], C.x], ['y', [0, L, 0], C.y], ['z', [0, 0, L], C.z]];
  if (opt.neg !== false) ax.forEach(([, p]) => { const a = cam.P([0, 0, 0]), b = cam.P(p.map(v => -v * 0.55)); FK.el('line', { x1: a[0], y1: a[1], x2: b[0], y2: b[1], stroke: C.ln, 'stroke-width': 1, 'stroke-dasharray': '3 4' }, parent); });
  ax.forEach(([n, p, col]) => { const a = FK.arrow3(parent); a.set(cam, [0, 0, 0], p, { color: FK.alpha(col, .75), width: 1.6, head: 8, label: opt.unit ? { x: 'î', y: 'ĵ', z: 'k̂' }[n] : n, loff: 12 }); });
};

/* ═════════════ CONTROLS ═════════════ */
FK.sl = (key, label, min, max, step, val, unit = '') => `<label class="fk-sl"><span class="fk-sl-l">${label}</span><input type="range" min="${min}" max="${max}" step="${step}" value="${val}" data-sl="${key}" aria-label="${label.replace(/<[^>]+>/g, '')}"><output data-slo="${key}">${FK.n(val, 2)}${unit}</output></label>`;
FK.bindSl = (root, key, fn, unit = '', d = 2) => { const i = root.querySelector(`[data-sl="${key}"]`), o = root.querySelector(`[data-slo="${key}"]`); if (!i) return { get: () => 0, set() { } }; const N = i.dataset.en ? FK.ne : FK.n; let raf = 0; const f = () => { raf = 0; const v = +i.value; if (o) o.textContent = N(v, d) + unit; fn(v); }; i.addEventListener('input', () => { if (!raf) raf = requestAnimationFrame(f); }); return { get: () => +i.value, set(v, silent) { i.value = v; if (o) o.textContent = N(+i.value, d) + unit; if (!silent) fn(+i.value); } }; };
/* একই HTML বারবার বসালে লেআউট খরচ হয় — বদলালে তবেই বসাও */
FK.setH = (el, h) => { if (el && el._h !== h) { el._h = h; el.innerHTML = h; } };
/* লেখা-বাক্সের লেআউট খরচ কমানো: একই HTML হলে বাদ, বদলালে সর্বোচ্চ ~১১ বার/সেকেন্ড */
FK.guardOut = root => {
  const D = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML'); if (!D || !root) return;
  root.querySelectorAll('[data-k="out"],[data-k="look"],[data-k="vb"],[data-k="bars"],[data-k="fb"],[data-k="det"],[data-k="sc"],[data-k="ph"]').forEach(el => {
    if (el._g) return; el._g = 1; let last = null, t0 = 0, pend = null, tm = 0;
    const put = h => { last = h; t0 = performance.now(); D.set.call(el, h); };
    Object.defineProperty(el, 'innerHTML', { configurable: true, get() { return D.get.call(el); }, set(h) { h = String(h); if (h === last && pend == null) return; const dt = performance.now() - t0; if (dt >= 90) { pend = null; put(h); return; } pend = h; if (!tm) tm = setTimeout(() => { tm = 0; if (pend != null && pend !== last) put(pend); pend = null; }, 90 - dt); } });
  });
};
FK.btn = (act, label, icon, cls = '') => `<button type="button" class="btn sm ${cls}" data-fk="${act}">${icon ? X.ico(icon) : ''}${label}</button>`;
FK.on = (root, act, fn) => root.querySelectorAll(`[data-fk="${act}"]`).forEach(b => b.addEventListener('click', e => fn(b, e)));
FK.look = t => `<div class="fk-look"><b>কী লক্ষ করবে:</b> ${t}</div>`;
FK.chk = (q, opts, ans, expl) => `<div class="fk-chk" data-ans="${ans}"><div class="fk-chk-q"><span class="chip acc">নিজে যাচাই</span> ${q}</div><div class="fk-chk-o">${opts.map((o, i) => `<button type="button" data-i="${i}">${o}</button>`).join('')}</div><div class="fk-chk-x" hidden>${expl}</div></div>`;
FK.wireChk = root => root.querySelectorAll('.fk-chk').forEach(c => { if (c._w) return; c._w = 1; const a = +c.dataset.ans; c.addEventListener('click', e => { const b = e.target.closest('button[data-i]'); if (!b || c.dataset.done) return; c.dataset.done = 1; const i = +b.dataset.i; c.querySelectorAll('button[data-i]').forEach((x, k) => { x.disabled = true; if (k === a) x.classList.add('ok'); }); if (i !== a) b.classList.add('no'); const xp = c.querySelector('.fk-chk-x'); xp.hidden = false; xp.insertAdjacentHTML('afterbegin', i === a ? '<b class="fk-ok">ঠিক! </b>' : '<b class="fk-no">হয়নি। </b>'); }); });
/* step bar: n steps, labels optional; render(i) */
FK.stepsHTML = () => `<div class="fk-steps"><button type="button" class="btn sm" data-st="-1" aria-label="আগের ধাপ">${X.ico('prev') || '‹'}</button><div class="fk-st-dots"></div><button type="button" class="btn sm" data-st="play">${X.ico('play')}চালাও</button><button type="button" class="btn sm primary" data-st="1" aria-label="পরের ধাপ">পরের${X.ico('next') || '›'}</button></div><div class="fk-st-cap" aria-live="polite"></div>`;
FK.steps = (root, caps, render, opt = {}) => {
  const n = caps.length, dots = root.querySelector('.fk-st-dots'), cap = root.querySelector('.fk-st-cap'); let i = opt.start || 0, timer = 0;
  dots.innerHTML = caps.map((_, k) => `<i data-k="${k}"></i>`).join('');
  const show = k => { i = Math.max(0, Math.min(n - 1, k)); dots.querySelectorAll('i').forEach((d, j) => { d.classList.toggle('on', j <= i); d.classList.toggle('cur', j === i); }); cap.innerHTML = `<b>ধাপ ${FK.bn(i + 1)}/${FK.bn(n)}:</b> ${caps[i]}`; render(i); root.querySelector('[data-st="-1"]').disabled = i === 0; root.querySelector('[data-st="1"]').disabled = i === n - 1; };
  const pb = root.querySelector('[data-st="play"]');
  const stop = () => { clearInterval(timer); timer = 0; pb.innerHTML = X.ico('play') + 'চালাও'; };
  root.querySelector('[data-st="-1"]').onclick = () => { stop(); show(i - 1); };
  root.querySelector('[data-st="1"]').onclick = () => { stop(); show(i + 1); };
  dots.onclick = e => { const d = e.target.closest('i'); if (d) { stop(); show(+d.dataset.k); } };
  pb.onclick = () => { if (timer) { stop(); return; } if (i >= n - 1) show(0); pb.innerHTML = X.ico('pause') + 'থামাও'; timer = setInterval(() => { if (i >= n - 1) { stop(); return; } show(i + 1); }, opt.ms || 1900); };
  show(i);
  return { show, stop, get i() { return i; } };
};
/* ease helper */
FK.ease = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
FK.lerp = (a, b, t) => a + (b - a) * t;
FK.lerp2 = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
/* tween runner (one at a time per figure) honoring reduced motion */
FK.tween = (ms, step, done) => { if (X.rm()) { step(1); if (done) done(); return { stop() { } }; } let raf = 0, t0 = 0, alive = true; const f = t => { if (!alive) return; if (!t0) t0 = t; const k = Math.min(1, (t - t0) / ms); step(FK.ease(k)); if (k < 1) raf = requestAnimationFrame(f); else if (done) done(); }; raf = requestAnimationFrame(f); return { stop() { alive = false; cancelAnimationFrame(raf); } }; };
/* re-render on theme change */
FK.onTheme = fn => { const mo = new MutationObserver(() => fn()); mo.observe(document.documentElement, { attributes: true, attributeFilter: ['data-skin', 'data-theme', 'data-glass'] }); return () => mo.disconnect(); };
})();
