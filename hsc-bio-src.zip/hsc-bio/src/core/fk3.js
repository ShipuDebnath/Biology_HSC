/* ═══════════════════════════════════════════════════════════════════
   CORE · FK3 — হালকা ত্রিমাত্রিক ইঞ্জিন (canvas 2D, পার্সপেক্টিভ, ছায়া-আলো)
   ───────────────────────────────────────────────────────────────────
   const S = FK.s3(host, { h, yaw, pitch, dist, tgt, fov, spin, label })
   S.draw = S => { S.ground(); S.box(...); S.arrow(...); }   প্রতি ফ্রেমে দৃশ্য বানাও
   S.frame()           একবার আঁকো (ঘোরালে/থিম বদলালে নিজেই আঁকে)
   বস্তু: box, cyl, cone, disc, sphere, torus, arrow, line, path, ring, text, ground, shadow, face
   ঘূর্ণন: FK.M3.rx/ry/rz/axis/mul/ap — যেকোনো বস্তুতে {R, o} দিয়ে ঘোরানো যায়
   z উপরের দিকে; ডান-হাতি স্থানাঙ্ক। ক্যামেরা লক্ষ্যবিন্দু ঘিরে ঘোরে।
   নিয়ম: স্ক্রিনের বাইরে আঁকা থামে (X.anim), DPR ≤ 2, কম শক্তির ফোনে কম ভাগ।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const X = window.VX, FK = window.FK;

/* ---------- ইংরেজি অঙ্কে সংখ্যা (গাণিতিক মানের জন্য) ---------- */
FK.ne = (x, d = 2) => {
  if (x == null || isNaN(x)) return '—';
  if (!isFinite(x)) return '∞';
  let s = (+x).toFixed(d);
  if (s.indexOf('.') >= 0) s = s.replace(/0+$/, '').replace(/\.$/, '');
  if (s === '-0') s = '0';
  return s.replace('-', '−');
};
FK.sle = (key, label, min, max, step, val, unit = '') => FK.sl(key, label, min, max, step, val, unit).replace('data-sl=', 'data-en="1" data-sl=').replace(/(<output[^>]*>)[^<]*/, (m, a) => a + FK.ne(val, 2) + unit);

/* ---------- ভেক্টর ও ম্যাট্রিক্স ---------- */
const v3 = FK.v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: a => Math.hypot(a[0], a[1], a[2]),
  norm: a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  lerp: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]
};
const M3 = FK.M3 = {
  I: () => [1, 0, 0, 0, 1, 0, 0, 0, 1],
  rx: a => { const c = Math.cos(a), s = Math.sin(a); return [1, 0, 0, 0, c, -s, 0, s, c]; },
  ry: a => { const c = Math.cos(a), s = Math.sin(a); return [c, 0, s, 0, 1, 0, -s, 0, c]; },
  rz: a => { const c = Math.cos(a), s = Math.sin(a); return [c, -s, 0, s, c, 0, 0, 0, 1]; },
  axis: (u, a) => { const [x, y, z] = v3.norm(u), c = Math.cos(a), s = Math.sin(a), t = 1 - c; return [t * x * x + c, t * x * y - s * z, t * x * z + s * y, t * x * y + s * z, t * y * y + c, t * y * z - s * x, t * x * z - s * y, t * y * z + s * x, t * z * z + c]; },
  mul: (A, B) => { const R = []; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) R.push(A[i * 3] * B[j] + A[i * 3 + 1] * B[3 + j] + A[i * 3 + 2] * B[6 + j]); return R; },
  ap: (M, p) => [M[0] * p[0] + M[1] * p[1] + M[2] * p[2], M[3] * p[0] + M[4] * p[1] + M[5] * p[2], M[6] * p[0] + M[7] * p[1] + M[8] * p[2]]
};
/* স্থানীয় বিন্দু → বিশ্ব বিন্দু */
const tf = (op, p) => { let q = op.R ? M3.ap(op.R, p) : p; return op.o ? v3.add(op.o, q) : q; };
const perp = a => { const u = v3.norm(a), t = Math.abs(u[2]) < .9 ? [0, 0, 1] : [1, 0, 0], e1 = v3.norm(v3.cross(u, t)); return [e1, v3.cross(u, e1)]; };

/* ---------- রং ---------- */
const CC = new Map();
const rgb = c => {
  if (CC.has(c)) return CC.get(c); let m, r = [128, 128, 128];
  const s = (c || '').trim();
  if ((m = s.match(/^#([0-9a-f]{3})$/i))) r = m[1].split('').map(h => parseInt(h + h, 16));
  else if ((m = s.match(/^#([0-9a-f]{6})/i))) r = [0, 2, 4].map(i => parseInt(m[1].substr(i, 2), 16));
  else if ((m = s.match(/rgba?\(([^)]+)\)/))) r = m[1].split(',').slice(0, 3).map(v => +v);
  if (CC.size > 400) CC.clear(); CC.set(c, r); return r;
};
const SC = new Map();
const shadeC = (c, k, sp, a) => { const key = c + '|' + Math.round(k * 40) + '|' + Math.round(sp * 20) + '|' + (a == null ? 1 : a); let v = SC.get(key); if (v) return v; if (SC.size > 3000) SC.clear(); v = shadeRaw(c, Math.round(k * 40) / 40, Math.round(sp * 20) / 20, a); SC.set(key, v); return v; };
const shadeRaw = (c, k, sp, a) => { const [r, g, b] = rgb(c), f = 0.42 + 0.7 * k, w = sp * 120; const q = v => Math.max(0, Math.min(255, Math.round(v * f + w))); return a != null && a < 1 ? `rgba(${q(r)},${q(g)},${q(b)},${a})` : `rgb(${q(r)},${q(g)},${q(b)})`; };
FK.mix = (c1, c2, t) => { const a = rgb(c1), b = rgb(c2); return `rgb(${a.map((v, i) => Math.round(v + (b[i] - v) * t)).join(',')})`; };

const NAV = typeof navigator !== 'undefined' ? navigator : {}, LOW = (NAV.hardwareConcurrency || 4) <= 4 || (NAV.deviceMemory || 4) <= 2;

/* ═════════════ দৃশ্য ═════════════ */
FK.s3 = (host, o = {}) => {
  host.insertAdjacentHTML('beforeend', `<div class="fk3"><canvas role="img" aria-label="${o.label || 'ত্রিমাত্রিক চিত্র'}"></canvas>${o.orbit === false ? '' : '<span class="fk3-hint" aria-hidden="true">⟲ টেনে ঘোরাও</span>'}</div>`);
  const wrap = host.lastElementChild, cv = wrap.querySelector('canvas'), hint = wrap.querySelector('.fk3-hint');
  const S = { cv, wrap, yaw: o.yaw != null ? o.yaw : -0.55, pitch: o.pitch != null ? o.pitch : 0.38, dist: o.dist || 12, tgt: (o.tgt || [0, 0, 0]).slice(), fov: o.fov || 0.7, seg: LOW ? 14 : 22, low: LOW, C: FK.P(), en: true, ox: 0, oy: 0 };
  S.home = { yaw: S.yaw, pitch: S.pitch, dist: S.dist };
  const hf = typeof o.h === 'function' ? o.h : W => o.h || Math.round(Math.min(360, Math.max(230, W * 0.7)));
  let L = [], BG = [], TOP = [], GND = []; const GR = new Map();
  S.rs = 1; let cost = 0, slowN = 0, lastDraw = 0, ivA = 16, slowF = 0;
  S.resize = () => { const r = X.fit(cv, hf); S.W = r.W; S.H = r.H; S.g = r.g; const d = cv.width / S.W, q = d * S.rs; if (S.rs < 1) { cv.width = Math.round(S.W * q); cv.height = Math.round(S.H * q); S.g.setTransform(q, 0, 0, q, 0, 0); } S.F = 0.5 * Math.min(S.W, S.H * 1.3) / Math.tan(S.fov / 2); GC = null; };
  S.basis = () => {
    const cp = Math.cos(S.pitch), sp = Math.sin(S.pitch);
    S.eye = v3.add(S.tgt, v3.mul([cp * Math.sin(S.yaw), -cp * Math.cos(S.yaw), sp], S.dist));
    S.f = v3.norm(v3.sub(S.tgt, S.eye)); S.r = v3.norm(v3.cross(S.f, [0, 0, 1])); S.u = v3.cross(S.r, S.f);
    S.Lt = v3.norm(v3.add(v3.add(v3.mul(S.r, -0.45), v3.mul(S.u, 0.8)), v3.mul(S.f, -0.5)));
  };
  /* প্রজেকশন: [sx, sy, গভীরতা, স্কেল] */
  S.P = p => { const d = v3.sub(p, S.eye), z = v3.dot(d, S.f); if (z < 0.05) return null; const k = S.F / z; return [S.W / 2 + S.ox + v3.dot(d, S.r) * k, S.H / 2 + S.oy - v3.dot(d, S.u) * k, z, k]; };
  const lightK = n => { const k = Math.max(0, v3.dot(n, S.Lt)); const h = v3.norm(v3.sub(S.Lt, S.f)); const s = Math.pow(Math.max(0, v3.dot(n, h)), 24); return [k, s]; };

  /* একটি বহুভুজ তল (বিশ্ব বিন্দু) */
  S.face = (pts, col, op = {}) => {
    let n = v3.norm(v3.cross(v3.sub(pts[1], pts[0]), v3.sub(pts[2], pts[0])));
    const c = pts.reduce((a, p) => v3.add(a, p), [0, 0, 0]).map(v => v / pts.length);
    const toEye = v3.sub(S.eye, c);
    if (v3.dot(n, toEye) < 0) { if (!op.two) return; n = v3.mul(n, -1); }
    const P2 = []; let z = 0;
    for (const p of pts) { const q = S.P(p); if (!q) return; P2.push(q); z += q[2]; }
    const [k, s] = op.flat ? [0.6, 0] : lightK(n);
    const item = { z: z / pts.length + (op.bias || 0), t: 0, p: P2, fill: shadeC(col, k, op.gloss === false ? 0 : s * (op.gloss || .6), op.a), line: op.line, lw: op.lw, id: op.id };
    (op.bg ? BG : L).push(item);
  };
  /* বাক্স: কেন্দ্র c, মাপ s=[x,y,z] */
  S.box = (c, s, col, op = {}) => {
    const h = s.map(v => v / 2), loc = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]].map(q => [q[0] * h[0], q[1] * h[1], q[2] * h[2]]);
    const W = loc.map(p => tf({ R: op.R, o: c }, p));
    const F = [[0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4], [2, 3, 7, 6], [1, 2, 6, 5], [3, 0, 4, 7]];
    const cols = op.cols || [];
    F.forEach((f, i) => S.face(f.map(j => W[j]), cols[i] || col, op));
  };
  /* সিলিন্ডার/ফ্রাস্টাম: a থেকে b, ব্যাসার্ধ r (শেষে r2) */
  S.cyl = (a, b, r, col, op = {}) => {
    const ax = v3.sub(b, a); if (v3.len(ax) < 1e-6) return;
    const [e1, e2] = perp(ax), n = op.seg || S.seg, r2 = op.r2 != null ? op.r2 : r, ph = op.ph || 0;
    const A = [], B = [];
    for (let i = 0; i < n; i++) { const t = ph + i / n * Math.PI * 2, d = v3.add(v3.mul(e1, Math.cos(t)), v3.mul(e2, Math.sin(t))); A.push(v3.add(a, v3.mul(d, r))); B.push(v3.add(b, v3.mul(d, r2))); }
    const cols = op.stripe ? i => (i % 2 ? col : op.stripe) : () => col;
    for (let i = 0; i < n; i++) { const j = (i + 1) % n; if (r2 > 1e-6) S.face([A[i], A[j], B[j], B[i]], cols(i), op); else S.face([A[i], A[j], b], cols(i), op); }
    if (op.caps !== false) { S.face(A.slice().reverse(), op.cap || col, op); if (r2 > 1e-6) S.face(B, op.cap2 || op.cap || col, op); }
  };
  S.cone = (a, b, r, col, op = {}) => S.cyl(a, b, r, col, Object.assign({ r2: 0 }, op));
  S.disc = (c, nrm, r, th, col, op = {}) => { const u = v3.mul(v3.norm(nrm), th / 2); S.cyl(v3.sub(c, u), v3.add(c, u), r, col, op); };
  /* টরাস (রিং): কেন্দ্র c, অক্ষ nrm, বড় ব্যাসার্ধ R, নল r */
  S.torus = (c, nrm, R, r, col, op = {}) => {
    const [e1, e2] = perp(nrm), u = v3.norm(nrm), n = op.seg || (LOW ? 18 : 28), m = op.tube || (LOW ? 6 : 8), ph = op.ph || 0;
    const P = (i, j) => { const t = ph + i / n * Math.PI * 2, s = j / m * Math.PI * 2, d = v3.add(v3.mul(e1, Math.cos(t)), v3.mul(e2, Math.sin(t))); return v3.add(c, v3.add(v3.mul(d, R + r * Math.cos(s)), v3.mul(u, r * Math.sin(s)))); };
    for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) S.face([P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)], op.stripe && i % 4 === 0 ? op.stripe : col, op);
  };
  /* গোলক — প্রজেক্টেড বৃত্ত, আলো-ছায়ার গ্রেডিয়েন্ট */
  S.sphere = (c, r, col, op = {}) => {
    const q = S.P(c); if (!q) return;
    L.push({ z: q[2] - r * 0.5 + (op.bias || 0), t: 1, x: q[0], y: q[1], r: r * q[3], col, a: op.a, id: op.id, ring: op.ring });
  };
  /* 3D তীর: দণ্ড + মাথা */
  S.arrow = (a, b, col, op = {}) => {
    const d = v3.sub(b, a), l = v3.len(d); if (l < 1e-4) return;
    const u = v3.mul(d, 1 / l), rr = op.r || 0.05, hl = Math.min(op.head || rr * 5.5, l * 0.6), m = v3.sub(b, v3.mul(u, hl));
    const sg = { seg: LOW ? 8 : 10, gloss: .4 };
    if (l - hl > 1e-3) S.cyl(a, m, rr, col, Object.assign({ caps: false }, sg));
    S.cone(m, b, rr * 2.4, col, sg);
    if (op.label) S.text(v3.add(b, v3.mul(u, op.lo != null ? op.lo : 0.35)), op.label, op.lc || col, { size: op.size || 13, bold: true, halo: true });
  };
  S.line = (a, b, col, op = {}) => { const A = S.P(a), B = S.P(b); if (!A || !B) return; (op.bg ? BG : L).push({ z: (A[2] + B[2]) / 2 + (op.bias || 0), t: 2, p: [A, B], col, w: op.w || 1.5, dash: op.dash, a: op.a }); };
  S.path = (pts, col, op = {}) => { const P2 = []; let z = 0; for (const p of pts) { const q = S.P(p); if (!q) return; P2.push(q); z += q[2]; } if (P2.length < 2) return; (op.bg ? BG : op.top ? TOP : L).push({ z: z / P2.length + (op.bias || 0), t: 2, p: P2, col, w: op.w || 2, dash: op.dash, a: op.a, fill: op.fill, close: op.close }); };
  /* বৃত্ত-রেখা: কেন্দ্র, অক্ষ, ব্যাসার্ধ, (শুরু, শেষ কোণ) */
  S.ring = (c, nrm, R, col, op = {}) => { const [e1, e2] = perp(nrm), n = op.n || 48, a0 = op.a0 || 0, a1 = op.a1 != null ? op.a1 : Math.PI * 2, pts = []; for (let i = 0; i <= n; i++) { const t = a0 + (a1 - a0) * i / n; pts.push(v3.add(c, v3.add(v3.mul(e1, R * Math.cos(t)), v3.mul(e2, R * Math.sin(t))))); } S.path(pts, col, op); return { e1, e2 }; };
  /* লেখা (সবসময় উপরে, ইচ্ছে হলে গভীরতা অনুযায়ী) */
  S.text = (p, str, col, op = {}) => { const q = S.P(p); if (!q) return; const it = { z: op.depth ? q[2] : -1e9, t: 3, x: q[0] + (op.dx || 0), y: q[1] + (op.dy || 0), s: str, col: col || S.C.fg, size: op.size || 12, bold: op.bold, anchor: op.anchor || 'center', halo: op.halo !== false }; (op.depth ? L : TOP).push(it); };
  /* মেঝে: z = h তলে একটি বড় বর্গ ও গ্রিড */
  S.ground = (op = {}) => {
    const s = op.size || 6, z = op.z || 0, c = op.c || [0, 0], C = S.C, col = op.col || (C.dark ? '#2a3140' : '#e9edf3');
    const nb = BG.length;
    S.face([[c[0] - s, c[1] - s, z], [c[0] + s, c[1] - s, z], [c[0] + s, c[1] + s, z], [c[0] - s, c[1] + s, z]], col, { bg: true, two: true, gloss: false, flat: !!op.flat });
    if (op.grid !== false) { const st = op.step || 1; for (let x = -s; x <= s + 1e-9; x += st) { S.line([c[0] + x, c[1] - s, z], [c[0] + x, c[1] + s, z], C.dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.07)', { bg: true, w: 1 }); S.line([c[0] - s, c[1] + x, z], [c[0] + s, c[1] + x, z], C.dark ? 'rgba(255,255,255,.07)' : 'rgba(0,0,0,.07)', { bg: true, w: 1 }); } }
    GND.push(...BG.splice(nb));
  };
  /* মেঝেতে নরম ছায়া */
  S.shadow = (c, rx, ry, op = {}) => { const z = op.z || 0, pts = []; for (let i = 0; i < 18; i++) { const t = i / 18 * Math.PI * 2; pts.push([c[0] + rx * Math.cos(t), c[1] + (ry || rx) * Math.sin(t), z + 0.002]); } const P2 = []; for (const p of pts) { const q = S.P(p); if (!q) return; P2.push(q); } BG.push({ z: 0, t: 4, p: P2, a: op.a || (S.C.dark ? .35 : .16) }); };

  /* ---------- আঁকা ---------- */
  const font = (sz, b) => `${b ? 700 : 500} ${sz}px ${S.C.font || 'sans-serif'}`;
  const drawItem = (g, it) => {
    if (it.t === 0) { const p = it.p; g.beginPath(); g.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]); g.closePath(); g.fillStyle = it.fill; g.fill(); g.lineWidth = it.lw || 0.7; g.strokeStyle = it.line || it.fill; g.stroke(); if (it.id) it.path = new Path2D(), p.forEach((q, i) => i ? it.path.lineTo(q[0], q[1]) : it.path.moveTo(q[0], q[1])); }
    else if (it.t === 1) {
      const r = Math.max(0.5, it.r), A = it.a != null ? it.a : 1, key = it.col + '|' + A;
      let gr = GR.get(key);
      if (!gr) { const [r0, g0, b0] = rgb(it.col), hx = v3.dot(S.Lt, S.r) * 0.45, hy = -v3.dot(S.Lt, S.u) * 0.45, cl = (k, w) => `rgba(${[r0, g0, b0].map(v => Math.min(255, Math.round(v * k + w))).join(',')},${A})`; gr = g.createRadialGradient(hx, hy, 0.08, 0, 0, 1); gr.addColorStop(0, cl(1.05, 90)); gr.addColorStop(0.35, cl(1, 10)); gr.addColorStop(1, cl(0.45, 0)); GR.set(key, gr); }
      g.save(); g.translate(it.x, it.y); g.scale(r, r); g.beginPath(); g.arc(0, 0, 1, 0, Math.PI * 2); g.fillStyle = gr; g.fill(); g.restore();
      if (it.ring) { g.beginPath(); g.arc(it.x, it.y, r, 0, Math.PI * 2); g.lineWidth = 2; g.strokeStyle = it.ring; g.stroke(); }
      if (it.id) { it.path = new Path2D(); it.path.arc(it.x, it.y, r, 0, Math.PI * 2); }
    }
    else if (it.t === 2) { const p = it.p; g.beginPath(); g.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]); if (it.close) g.closePath(); if (it.fill) { g.fillStyle = it.fill; g.fill(); } g.globalAlpha = it.a != null ? it.a : 1; g.strokeStyle = it.col; g.lineWidth = it.w; g.lineCap = 'round'; g.lineJoin = 'round'; g.setLineDash(it.dash || []); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; }
    else if (it.t === 3) { g.font = font(it.size, it.bold); g.textAlign = it.anchor; g.textBaseline = 'middle'; if (it.halo) { g.lineWidth = 3.5; g.strokeStyle = S.C.dark ? 'rgba(15,18,26,.85)' : 'rgba(255,255,255,.9)'; g.lineJoin = 'round'; g.strokeText(it.s, it.x, it.y); } g.fillStyle = it.col; g.fillText(it.s, it.x, it.y); }
    else if (it.t === 4) { const p = it.p; g.beginPath(); g.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]); g.closePath(); g.fillStyle = `rgba(0,0,0,${it.a})`; g.fill(); }
  };
  let drawn = [];
  /* স্থির পটভূমি (মেঝে, গ্রিড) ক্যামেরা না বদলালে অফস্ক্রিন ক্যানভাসে জমা থাকে */
  let GC = null, GK = '';
  S.frame = () => {
    if (!S.g) return;
    const now = performance.now();
    if (S.cap && now - lastDraw < 25) return;
    /* প্রকৃত ফ্রেম-ব্যবধান দেখে মান নিয়ন্ত্রণ (ধীর ফোনে স্থির ৩০ fps) */
    const iv = now - lastDraw; if (iv < 120) { ivA = ivA * 0.92 + iv * 0.08; if (ivA > 23 && ++slowF > 40) { slowF = 0; if (!S.cap) { S.cap = true; ivA = 30; } else if (ivA > 40 && S.rs > 0.84) { S.rs = 0.85; S.resize(); } } else if (ivA <= 23) slowF = 0; }
    lastDraw = now;
    S.basis(); L = []; BG = []; TOP = []; GND = [];
    if (S.draw) S.draw(S);
    const g = S.g; g.clearRect(0, 0, S.W, S.H);
    if (GND.length) {
      const key = [S.yaw, S.pitch, S.dist, S.tgt.join(','), S.W, S.H, S.rs, S.C.dark, GND.length].join('|');
      if (key !== GK || !GC) {
        GK = key; GC = GC || document.createElement('canvas'); GC.width = cv.width; GC.height = cv.height;
        const gg = GC.getContext('2d'); const q = cv.width / S.W; gg.setTransform(q, 0, 0, q, 0, 0); gg.clearRect(0, 0, S.W, S.H); GND.forEach(it => drawItem(gg, it));
      }
      g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(GC, 0, 0); g.restore();
    }
    L.sort((a, b) => b.z - a.z);
    BG.forEach(it => drawItem(g, it)); L.forEach(it => drawItem(g, it)); TOP.forEach(it => drawItem(g, it));
    drawn = L.filter(it => it.id);
    /* স্বয়ংক্রিয় মান-নিয়ন্ত্রণ: ধীর ফোনে রেজোলিউশন ও ভাগ কমানো, ৩০ fps এ সীমা */
    const c = performance.now() - now; cost = cost ? cost * 0.9 + c * 0.1 : c;
    if (cost > 14) { if (++slowN > 30) { slowN = 0; if (S.seg > 10) S.seg -= 4; S.cap = true; cost = 0; } } else slowN = 0;
  };
  /* ট্যাপ করা বস্তুর id (উপরেরটি আগে) */
  S.hit = (x, y) => { const g = S.g; for (let i = drawn.length - 1; i >= 0; i--) { const it = drawn[i]; if (it.path && g.isPointInPath(it.path, x * (cv.width / S.W), y * (cv.height / S.H))) return it.id; } return null; };

  /* ---------- আঙুলে ঘোরানো ---------- */
  let down = false, moved = 0, lx = 0, ly = 0, raf = 0, dx = 0, dy = 0, user = false;
  const flush = () => { raf = 0; S.yaw += dx * 0.01; if (o.pitchLock !== true) S.pitch = Math.max(o.pmin != null ? o.pmin : -0.15, Math.min(o.pmax || 1.45, S.pitch + dy * 0.008)); dx = dy = 0; S.frame(); };
  const pd = e => { down = true; moved = 0; lx = e.clientX; ly = e.clientY; try { cv.setPointerCapture(e.pointerId); } catch (_) { } };
  const pm = e => { if (!down || o.orbit === false) return; const ddx = e.clientX - lx, ddy = e.clientY - ly; moved += Math.abs(ddx) + Math.abs(ddy); dx += ddx; dy += e.pointerType === 'touch' ? 0 : ddy; lx = e.clientX; ly = e.clientY; if (moved > 4 && !user) { user = true; if (hint) hint.style.opacity = 0; if (o.onUser) o.onUser(); } if (!raf) raf = requestAnimationFrame(flush); };
  const pu = e => { if (down && moved < 6 && S.onTap) { const r = cv.getBoundingClientRect(); S.onTap(e.clientX - r.left, e.clientY - r.top); } down = false; };
  cv.addEventListener('pointerdown', pd); cv.addEventListener('pointermove', pm); cv.addEventListener('pointerup', pu); cv.addEventListener('pointercancel', () => { down = false; });
  /* চলমান বস্তুর পেছনে ক্যামেরা — ব্যবহারকারীর ঘোরানো অফসেট রেখে */
  S.chase = (yawT, tgt) => { S._off = (S._off || 0) + (S._last != null ? S.yaw - S._last : 0); S.yaw = yawT + S._off; S._last = S.yaw; if (tgt) S.tgt = tgt; };
  S.stat = () => ({ iv: +ivA.toFixed(1), cost: +cost.toFixed(2), rs: S.rs, seg: S.seg, cap: !!S.cap, items: L.length + BG.length + GND.length });
  (FK._sc = FK._sc || []).push(S); if (FK._sc.length > 8) FK._sc.shift();
  S.reset = () => { Object.assign(S, S.home); S.frame(); };
  S.spin = o.spin || 0; S.user = () => user;
  /* স্বয়ংক্রিয় ধীর ঘূর্ণন — ব্যবহারকারী ছুঁলে থামে */
  S.tick = dt => { if (S.spin && !user && dt) S.yaw += S.spin * dt; };
  S.resize();
  const unR = X.onResize(wrap, () => { S.resize(); S.frame(); });
  const unT = FK.onTheme(() => { S.C = FK.P(); S.frame(); });
  S.destroy = () => { unR(); unT(); };
  return S;
};

/* সাধারণ রঙের সেট (থিম-সচেতন) — ৩D বস্তুর জন্য */
FK.mat = () => { const C = FK.P(); return C.dark ? { metal: '#9aa7ba', wood: '#b9875a', red: '#ef6b62', blue: '#5b95f0', green: '#53c27f', gold: '#f2b63c', plum: '#b08cf0', teal: '#3fc1b4', skin: '#e9b48e', dark: '#4a5263', glass: '#8fd3ff', white: '#e8ecf3' } : { metal: '#8592a6', wood: '#c08a55', red: '#e5534b', blue: '#3c78d8', green: '#38a169', gold: '#e9a21b', plum: '#8f67d9', teal: '#159a8c', skin: '#e3a77f', dark: '#3b4352', glass: '#7cc6f2', white: '#f4f6fa' }; };
})();
