"""Build the single-file HSC Biology app (sister of the HSC Chemistry app).

Source layout
  src/core/style.css      shared styles + themes
  src/core/registry.js    HSC.chapter / SEC / VIS / CMPT registries
  src/core/vx.js          shared visual toolkit (window.VX)
  src/core/app.js         app engine (boots on DOMContentLoaded)
  src/core/template.html  commented chapter template appended at the very end
  src/chapters/<id>/chapter.js, content/*.js, visuals*.js   one folder per chapter

Output
  dist/index.html         fragment published as the artifact page: core inline + <script src="ch/…"> per chapter
  dist/ch/<id>.js, dist/ch/<id>-vis.js   each chapter's content and visuals (published with the page via `files`)
  dist/hsc-biology.html standalone file, everything inline (core → chapters → "add new chapters here")
  docs/index.html         same standalone file, for GitHub Pages
"""
import glob, os, re
ROOT = os.path.dirname(os.path.abspath(__file__))
rd = lambda *p: open(os.path.join(ROOT, *p), encoding='utf-8').read()

css = rd('src', 'core', 'style.css') + '\n' + rd('src', 'vendor', 'katex.css')
core = [('রেজিস্ট্রি', rd('src', 'core', 'registry.js')), ('ভিজ্যুয়াল টুলকিট', rd('src', 'core', 'vx.js')), ('ফিগার-কিট', rd('src', 'core', 'fk.js') + '\n' + rd('src', 'core', 'fk3.js') + '\n' + rd('src', 'core', 'bk.js')), ('KaTeX', rd('src', 'vendor', 'katex.min.js')), ('mhchem', rd('src', 'vendor', 'mhchem.min.js')), ('TeX ম্যাপ', rd('src', 'core', 'texmap.js')), ('টাইপসেটিং', rd('src', 'core', 'tex.js')), ('অ্যাপ ইঞ্জিন', rd('src', 'core', 'app.js').replace('/*@@PLUS@@*/', rd('src', 'core', 'plus.js') + '\n' + rd('src', 'core', 'plus2.js')))]
template = rd('src', 'core', 'template.html')
for part in template.split('<!--')[1:]:
    body_ = part.split('-->')[0]
    assert '--' not in body_, 'template comment must not contain "--"'


# অ্যান্ড্রয়েডের অনেক ফন্টে U+20D7 (r⃗ এর তীর) ও লম্বা তীর দেখা যায় না, ভাঙা বাক্স আসে — বিল্ডের সময় বদলে দিই
def vfix(t):
    t = t.translate({0x27F6: 0x2192, 0x27F9: 0x21D2, 0x27F5: 0x2190, 0x27F7: 0x2194, 0x27F3: 0x21BB, 0x27F2: 0x21BA})  # লম্বা তীর ফোনে নেই — সাধারণ তীর
    t = re.sub(r'(?<![A-Za-z])([A-Z]{2})\u20d7', r'<span class=vc>\1</span>', t)
    return re.sub(r'([^\s<>"\'`])\u20d7', r'<span class=vc>\1</span>', t)
BAR = '═' * 70
chapters = []
files = []
for d in sorted(glob.glob(os.path.join(ROOT, 'src', 'chapters', '*'))):
    meta = rd(d, 'chapter.js')
    content = vfix(''.join(open(f, encoding='utf-8').read().rstrip() + '\n\n' for f in sorted(glob.glob(os.path.join(d, 'content', '*.js')))))
    vis = vfix(''.join(open(f, encoding='utf-8').read().rstrip() + '\n\n' for f in sorted(glob.glob(os.path.join(d, 'visuals*.js')))))
    cid = os.path.basename(d)
    title = next((re.match(r"\s*t:\s*'([^']*)'", ln).group(1) for ln in meta.splitlines() if re.match(r"\s*t:\s*'", ln)), cid)
    no = next((ln.split("no:", 1)[1].strip().strip("',") for ln in meta.splitlines() if ln.strip().startswith('no:')), '')
    block = (f'\n<!-- ╔{BAR}╗\n     ║  অধ্যায় {no} · {title}  (id: {cid})\n     ║  ১ম স্ক্রিপ্ট: অধ্যায় পরিচিতি + অংশ ও প্রশ্ন   ২য় স্ক্রিপ্ট: চিত্র ও সিমুলেশন\n     ╚{BAR}╝ -->\n'
             f'<script>\n{meta.rstrip()}\n\n{content}</script>\n<script>\n{vis}</script>\n'
             f'<!-- ═══ অধ্যায় {no} শেষ ═══ -->\n')
    chapters.append(block)
    files.append((cid, no, title, f'{meta.rstrip()}\n\n{content}', vis))

# ── Three.js স্লট: vendor/three.min.js থাকলে পাতায় বসে, কিন্তু type="text/plain" বলে
#    ব্রাউজার সেটি পার্স করে না — প্রথম ৩D চিত্র খুললে BK.boot3d() তখন চালু করে।
_three_path = os.path.join(ROOT, 'vendor', 'three.min.js')
if os.path.exists(_three_path):
    _ts = open(_three_path, encoding='utf-8').read()
    three_html = ('<!-- Three.js (ঐচ্ছিক ৩D ইঞ্জিন) — পাতা খোলার সময় পার্স হয় না; BK.boot3d() চালু করে -->\n'
                  '<script type="text/plain" id="bk-three-src">\n' + _ts.replace('</script>', '<\\/script>') + '\n</script>\n')
    print(f'  + Three.js যোগ হলো ({len(_ts)//1024} KB, লেজি)')
else:
    three_html = ''

core_html = (f'<!-- ╔{BAR}╗\n     ║  CORE — সব অধ্যায়ের জন্য সাধারণ কোড (সাধারণত এখানে হাত দেওয়ার দরকার নেই)\n'
             f'     ║  ১. রেজিস্ট্রি  ২. ভিজ্যুয়াল টুলকিট  ৩. অ্যাপ ইঞ্জিন\n     ╚{BAR}╝ -->\n'
             + ''.join(f'<script>\n{vfix(js.rstrip())}\n</script>\n' for _, js in core) + three_html)

head = '''<title>HSC জীববিজ্ঞান সহায়িকা</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="theme-color" content="#FFFDF8">
<meta name="description" content="HSC জীববিজ্ঞান — অধ্যায়ভিত্তিক ইন্টারঅ্যাকটিভ স্টাডি অ্যাপ (১ম ও ২য় পত্র)">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400..700&family=Source+Serif+4:opsz,wght@8..60,400..600&family=Anek+Bangla:wght@300..700&family=Tiro+Bangla&family=JetBrains+Mono:wght@400;600&family=Noto+Sans+Math&family=Noto+Sans+Symbols+2&display=swap">
'''
shell = '''<div id="app" lang="bn"></div>
<noscript><p style="padding:16px">এই অ্যাপ চালাতে জাভাস্ক্রিপ্ট চালু করো।</p></noscript>
'''
body = core_html + ''.join(chapters)

os.makedirs(os.path.join(ROOT, 'dist', 'ch'), exist_ok=True)
for f in glob.glob(os.path.join(ROOT, 'dist', 'ch', '*.js')): os.remove(f)
tags = ''
for cid, no, title, cjs, vjs in files:
    open(os.path.join(ROOT, 'dist', 'ch', cid + '.js'), 'w', encoding='utf-8').write(f'/* অধ্যায় {no} · {title} — অংশ ও প্রশ্ন */\n{cjs}')
    open(os.path.join(ROOT, 'dist', 'ch', cid + '-vis.js'), 'w', encoding='utf-8').write(f'/* অধ্যায় {no} · {title} — চিত্র ও সিমুলেশন */\n{vjs}')
    tags += f'<script src="ch/{cid}.js"></script>\n<script src="ch/{cid}-vis.js"></script>\n'
frag = head + f'<style>{css}</style>\n' + shell + core_html + tags
open(os.path.join(ROOT, 'dist', 'index.html'), 'w', encoding='utf-8').write(frag)

reset = ':root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui,sans-serif}img{max-width:100%}[hidden]{display:none!important}'
full = f'''<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<style>{reset}</style>
{head}<style>
{css}
</style>
</head>
<body>
{shell}
{body}
{template.rstrip()}

</body>
</html>
'''
open(os.path.join(ROOT, 'dist', 'hsc-biology.html'), 'w', encoding='utf-8').write(full)
# GitHub Pages: docs/index.html = the standalone app (Settings → Pages → branch main, folder /docs)
os.makedirs(os.path.join(ROOT, 'docs'), exist_ok=True)
open(os.path.join(ROOT, 'docs', 'index.html'), 'w', encoding='utf-8').write(full)
open(os.path.join(ROOT, 'docs', '.nojekyll'), 'w').write('')
print('built', len(frag.encode()) // 1024, 'KB page +', sum(os.path.getsize(f) for f in glob.glob(os.path.join(ROOT, 'dist', 'ch', '*.js'))) // 1024, 'KB chapter files,', len(full.encode()) // 1024, 'KB standalone,', len(chapters), 'chapter(s)')
