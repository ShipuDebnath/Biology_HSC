# HANDOFF — notes for the next developer (or the next Claude session)

Read this first. It explains how the project is built, the content/visual conventions, how to check work,
and the planned-but-not-built features (optional login + teacher dashboard).

## 0. Status of this sister app (read first)

- Interface and every feature are identical to the chemistry app (core files copied 1:1, branding and the
  localStorage key changed to `hsc-bio-state-v1`, so both apps can live on the same GitHub Pages domain).
- Content so far = the **table of contents only**: `docs/toc.txt` (12 chapters: 1st paper ch 1–3, 2nd paper ch 1–9).
  The end-of-chapter revision section is configured by the `%` lines at the top of `docs/toc.txt`.
- `python3 tools/gen_toc.py` turns `docs/toc.txt` into `src/chapters/<id>/chapter.js` (with the book outline) and
  placeholder sections/lessons (`content/sNN.js`, first line `/* AUTO-TOC … */`, lessons carry `todo: true`).
  Writing real content: replace a placeholder file with hand-written `SEC.push({...})` (same ids), delete the AUTO-TOC
  line, then `python3 build.py`. The generator never overwrites a chapter that has hand-written files.
- Section/lesson numbers (e.g. ২.৩.১) are generated in book order; the source TOC had no numbers.
- Biology visuals, tricks (`TRICKS` in plus2.js is empty), MCQs, CQs, flashcards and formulas are still to be written.
- New in this app: Tools → "সম্পূর্ণ সূচিপত্র" (`VIEWS.toc`, searchable TOC of all chapters) and Tools →
  "মাইন্ড ম্যাপ" (`VIEWS.mind`, auto-built from the chapter's sections/lessons, leaves link to the lesson).
- **Nov 2026 — engine brought up to the physics app's level**: `style.css`, `fk.js`, `fk3.js`, `tex.js`, `app.js`,
  `plus.js`, `plus2.js` re-copied from `hsc-phy` (bio branding/key kept); all 8 themes; every figure now has a
  fullscreen button (`ACT.figMax`, Esc closes). Previous core is kept in `docs/core_prev/` — nothing deleted.
- **`src/core/bk.js` (BK kit, new)**: the biology figure kit, built on FK. No third-party chart library is used; a
  Three.js slot exists but is lazy and optional (see §4 and `docs/FIGURE_PLAN.md` appendix ক).
- **Docs split (Nov 15, 2026)**: `docs/FIGURE_PLAN.md` is now **biology only**; physics lives in
  `hsc-phy/docs/FIGURE_PLAN.md` (previous combined file kept as `hsc-phy/docs/FIGURE_PLAN_prev.md`). The engine
  conventions — BK kit, colour ramps, perf rules — are written once, in the biology file's **appendix ক**, and the
  physics file points at it. When you change the kit, update appendix ক, not both files.
- **Typography (Nov 15, 2026)**: Bengali conjuncts render heavy, so `font-synthesis:none` is set and the "bold"
  weight is **550**, not 700 (`b,strong` in style.css). Figure labels moved from 700/800 to 560/650. Body is
  16.5px/1.72. Don't reintroduce 700-weight Bengali text.
- **Content progress**: chapter `b1c1` is **complete** — §১.১–§১.১২ (77 lessons, `content/s01–s12.js`) are **written** — use them as the
  quality bar. Each lesson carries the full block set `ov → dp → sc → fx → ap → cm → tr → sn → mh → mf → cf → ho`
  plus `xm` (lesson MCQs) and `xs` (short answers); each section carries `Q.mcq`, `Q.cq`, `Q.wp` (5 items, 2/3/5/7/10
  marks — `tools/check.js` requires all five of 2/3/5/7/10 to appear), `F` (flashcards) and `CMPT` entries. Chapter 1 final: 612 MCQ (ক/খ/গ/ঘ = 150/157/152/153), 89 short, 24 CQ, 67 written, 297 flashcards, 34 figures used, every lesson has ≥1 figure, `check.js b1c1` → no problems. Chapter 2 (`b1c2`, কোষ বিভাজন) is also **complete** — §২.১–§২.৫ (25 lessons): 166 MCQ (43/43/40/40), 25 short, 10 CQ, 25 written, 75 flashcards, 16 figures; `check.js b1c2` → no problems. Chapter 3 (`b1c3`, কোষ রসায়ন) is also **complete** (Nov 22, 2026) — §৩.১–§৩.৫ (41 lessons): 243 MCQ (61/59/61/62 after `balance.js`), 41 short, 14 CQ, 25 written, 113 flashcards, 47 figure keys used, 27 CMPT tables; `check.js b1c3` → no problems. Chapter 4 (`b1c4`, অণুজীব) is also **complete** (Nov 22, 2026) — §৪.১–§৪.৪ (40 lessons): 218 MCQ (67/50/48/53 after `balance.js`), 40 short, 11 CQ, 20 written, 108 flashcards, 35 figure keys used, 31 CMPT tables; `check.js b1c4` → no problems. Chapter 5 (`b1c5`, শৈবাল ও ছত্রাক) is also **complete** (Nov 22, 2026) — §৫.১–§৫.৫ (31 lessons): 198 MCQ (63/45/42/48 after `balance.js`), 31 short, 12 CQ, 25 written, 112 flashcards, 32 figure keys used, 35 CMPT tables; `check.js b1c5` → no problems. Chapter 6 (`b1c6`, ব্রায়োফাইটা ও টেরিডোফাইটা) is also **complete** (Nov 22, 2026) — §৬.১–§৬.৪ (13 lessons): 116 MCQ (43/22/28/23 after `balance.js`), 13 short, 9 CQ, 20 written, 70 flashcards, 22 figure keys used, 14 CMPT tables; `check.js b1c6` → no problems. Chapter 7 (`b1c7`, নগ্নবীজী ও আবৃতবীজী উদ্ভিদ) is also **complete** (Nov 23, 2026) — §৭.১–§৭.৫ (35 lessons): 206 MCQ (52/56/50/48 after `balance.js`), 35 short, 12 CQ, 25 written, 114 flashcards, 37 figure keys used, 35 CMPT tables; `check.js b1c7` → no problems. Chapter 8 (`b1c8`, টিস্যু ও টিস্যুতন্ত্র) is also **complete** (Nov 23, 2026) — §৮.১–§৮.৪ (21 lessons): 125 MCQ (33/36/34/22 after `balance.js`), 21 short, 9 CQ, 20 written, 67 flashcards, 29 figure keys used, 22 CMPT tables; `check.js b1c8` → no problems. Chapter 9 (`b1c9`, উদ্ভিদ শারীরতত্ত্ব) is also **complete** (Nov 23, 2026) — §৯.১–§৯.৯ (76 lessons): 522 MCQ (140/136/129/117 after statement rotation + `balance.js`), 76 short, 18 CQ, 43 written, 158 flashcards, 71 figure keys used, 34 CMPT tables; `check.js b1c9` → no problems. Chapter 10 (`b1c10`, উদ্ভিদ প্রজনন) is also **complete** (Nov 23, 2026) — §১০.১–§১০.৫ (24 lessons): 171 MCQ (46/44/44/37 after statement rotation + `balance.js`), 24 short, 10 CQ, 23 written, 68 flashcards, 34 figure keys used, 20 CMPT tables; `check.js b1c10` → no problems. Chapter 11 (`b1c11`, জীবপ্রযুক্তি) is also **complete** (Nov 23, 2026) — §১১.১–§১১.৫ (33 lessons): 268 MCQ (63/66/66/73 after statement rotation + `balance.js`), 33 short, 11 CQ, 25 written, 107 flashcards, 52 figure keys used, 20 CMPT tables; `check.js b1c11` → no problems. Chapter 12 (`b1c12`, জীবের পরিবেশ, বিস্তার ও সংরক্ষণ) is also **complete** (Nov 23, 2026) — §১২.১–§১২.৬ (52 lessons): 401 MCQ (104/109/95/93 after statement rotation + `balance.js`), 52 short, 17 CQ, 30 written, 130 flashcards, 55 figure keys used (all defined keys used), 43 CMPT tables; `check.js b1c12` → no problems. With this, all twelve 1st-paper chapters `b1c1`–`b1c12` are written. 2nd-paper Chapter 1 (`b2c1`, প্রাণীর বিভিন্নতা ও শ্রেণিবিন্যাস) is also **complete** (Nov 23, 2026) — §১.১–§১.৩ + সার (29 lessons): 256 MCQ (67/63/63/63 after statement rotation + `balance.js` + lesson-`xm` rebalance), 29 short, 11 CQ, 20 written, 75 flashcards, 52 figure keys used (all defined keys used), 27 CMPT tables; `check.js b2c1` → no problems. 2nd-paper Chapter 2 (`b2c2`, প্রাণীর পরিচিতি — হাইড্রা, ঘাসফড়িং, রুই মাছ) is also **complete** (Nov 23, 2026) — §২.১–§২.৩ + সার (36 lessons; §২.৩ renumbered ২.৩.১–২.৩.১০): 251 MCQ (74/59/59/59 after statement rotation + `balance.js` + `tools/xmbal.js`), 36 short, 11 CQ, 20 written, 68 flashcards, 48 figure keys used (all defined keys used), 34 CMPT tables; `check.js b2c2` → no problems. 2nd-paper Chapter 3 (`b2c3`, মানব শারীরতত্ত্ব: পরিপাক ও শোষণ) is also **complete** (Nov 23, 2026) — §৩.১–§৩.৫ (6 lessons), §৩.৬–§৩.৯ (4 lessons) + সার (4 lessons): 140 MCQ (41/33/33/33 after statement rotation + `balance.js` + `tools/xmbal.js`), 14 short, 8 CQ, 15 written, 54 flashcards, 38 figure keys used (all defined keys used), 15 CMPT tables; `check.js b2c3` → no problems. 2nd-paper Chapter 4 (`b2c4`, মানব শারীরতত্ত্ব: রক্ত সংবহন) is also **complete** (Nov 23, 2026) — §৪.১–§৪.৩ (6 lessons), §৪.৪–§৪.৬ (8 lessons), §৪.৭–§৪.৮ (9 lessons) + সার (4 lessons): 247 MCQ (66/61/60/60 after statement rotation + `balance.js` + `tools/xmbal.js`), 27 short, 12 CQ, 20 written, 65 flashcards, 52 figure keys used (all defined keys used), 31 CMPT tables; `check.js b2c4` → no problems. 2nd-paper Chapter 5 (`b2c5`, মানব শারীরতত্ত্ব: শ্বসন ও শ্বাসক্রিয়া) is also **complete** (Nov 23, 2026) — §৫–§৫.৫ (6 lessons), §৫.৬–§৫.৮ (5 lessons) + সার (4 lessons): 184 MCQ (49/45/45/45 after statement rotation + `balance.js` + `tools/xmbal.js`), 15 short, 8 CQ, 15 written, 41 flashcards, 44 figure keys used (all defined keys used), 14 CMPT tables + 10 comparison figures; `check.js b2c5` → no problems. 2nd-paper Chapter 6 (`b2c6`, মানব শারীরতত্ত্ব: বর্জ্য ও নিষ্কাশন) is also **complete** (Nov 23, 2026) — §৬–§৬.৩ (4 lessons), §৬.৪–§৬.৬ (8 lessons) + সার (4 lessons): 175 MCQ (46/43/43/43 after `balance.js` + `tools/xmbal.js`), 16 short, 9 CQ, 15 written, 44 flashcards, 48 figure keys used (all defined keys used), 16 CMPT tables + 11 comparison figures; `check.js b2c6` → no problems. 2nd-paper Chapter 7 (`b2c7`, মানব শারীরতত্ত্ব: চলন ও অঙ্গচালনা) is also **complete** (Nov 23, 2026) — §৭.১–§৭.২ (5 lessons), §৭.৩–§৭.৯ (7 lessons) + সার (4 lessons): 168 MCQ (45/41/41/41 after `balance.js` + `tools/xmbal.js`), 16 short, 9 CQ, 15 written, 41 flashcards, 51 figure keys used (all defined keys used), 15 CMPT tables + 14 comparison figures; `check.js b2c7` → no problems. 2nd-paper Chapter 8 (`b2c8`, মানব শারীরতত্ত্ব: সমন্বয় ও নিয়ন্ত্রণ) is also **complete** (Nov 24, 2026) — §৮.১ (5 lessons), §৮.২ (5 lessons), §৮.৩–৮.৫ (5 lessons) + সার (4 lessons): 227 MCQ (57/57/57/56 after `balance.js` + `tools/xmbal.js`), 19 short, 12 CQ, 20 written, 55 flashcards, 59 figure keys used (all defined keys used), 19 CMPT tables + 17 comparison figures; `check.js b2c8` → no problems. 2nd-paper Chapter 9 (`b2c9`, মানব জীবনের ধারাবাহিকতা) is also **complete** (Nov 24, 2026) — §৯.১–৯.২ (2 lessons), §৯.৩ (5 lessons), §৯.৪–৯.৮ (11 lessons) + সার (4 lessons): 265 MCQ (67/66/66/66 after `balance.js` + `tools/xmbal.js`), 28 short, 12 CQ, 20 written, 55 flashcards, 49 figure keys used (all defined keys used), 33 CMPT tables + 18 comparison figures; `check.js b2c9` → no problems. 2nd-paper Chapter 10 (`b2c10`, মানবদেহের প্রতিরক্ষা) is also **complete** (Nov 24, 2026) — §১০.১–১০.৪ (6 lessons), §১০.৫–১০.৭ (3 lessons) + সার (4 lessons): 237 MCQ (60/59/59/59 after `balance.js` + `tools/xmbal.js`), 13 short, 9 CQ, 15 written, 41 flashcards, 42 figure keys used (all defined keys used), 19 CMPT tables + 11 comparison figures; `check.js b2c10` → no problems. 2nd-paper Chapter 11 (`b2c11`, জিনতত্ত্ব ও বিবর্তন) is also **complete** (Nov 24, 2026) — §১১–১১.১ (4 lessons), §১১.২–১১.৩ (7 lessons), §১১.৪–১১.৫ (7 lessons), §১১.৬ (3 lessons), §১১.৭–১১.৯ (6 lessons) + সার (4 lessons): 375 MCQ (99/92/92/92 after `divers.js` + `balance.js` + `tools/xmbal.js`), 31 short, 18 CQ, 30 written, 86 flashcards, 55 figure keys used (all defined keys used), 56 CMPT tables + 16 comparison figures; `check.js b2c11` → no problems. 2nd-paper Chapter 12 (`b2c12`, প্রাণীর আচরণ) is also **complete** (Nov 24, 2026) — §১২.১–১২.২ (7 lessons), §১২.৩ (4 lessons), §১২.৪–১২.৬ (7 lessons + unnumbered জৈবিক ছন্দ `s3h`) + সার (4 lessons): 243 MCQ (66/59/59/59 after `divers.js` + `balance.js` + `tools/xmbal.js`), 23 short, 12 CQ, 20 written, 60 flashcards, 50 figure keys used (all defined keys used), 26 CMPT tables + 10 comparison figures; `check.js b2c12` → no problems. With this, every 2nd-paper chapter is written. 1st-paper Chapter 0 (`b1c0`, উদ্ভিদ শ্রেণিবিন্যাস — ভূমিকা) is also **complete** (Nov 24, 2026) — §০.১ (5 lessons), §০.২ (4 lessons), §০.৩ (4 lessons), §০.৪ সার (4 lessons): 215 MCQ (58/53/52/52 after `divers.js` + `balance.js` + `tools/xmbal.js`), 17 short, 12 CQ, 20 written, 60 flashcards, 35 figure keys used (all defined keys used), 18 CMPT tables + 10 comparison figures; `check.js b1c0` → no problems. **Every chapter in the app is now written; no placeholders remain.** For any new chapter give it its own `visuals0.js` helper namespace (b2c1 `B21`, b2c2 `B22`, b2c3 `B23`, b2c4 `B24`, b2c5 `B25`, b2c6 `B26`, b2c7 `B27`, b2c8 `B28`, b2c9 `B29`, b2c10 `B210`, b2c11 `B211`, b2c12 `B212`, b1c0 `B100`) and reuse the realistic anatomy library in `b2c4/visuals0a.js` + body/heart helpers in `b2c4/visuals0b.js` (see b2c3 and b2c4 notes) — the user asked for textbook-like, not cartoon, figures. `mf` is written for MCQ/admission focus and `cf` for CQ focus, so the
  app serves HSC board, university and medical admission from the same content. Everything else is AUTO-TOC placeholder.
- **§১.৫ figures** (`src/chapters/b1c1/visuals4.js`): `nucleus3d` (3D cut-model — double envelope, pores with
  a pore complex, nucleolus, chromatin, mRNA beads exported through the pores; slider = pore count; 31 fps @ CPU 8×,
  cost 6.78, 81 items), `cmpChroma` (euchromatin vs heterochromatin), `centri9` (9+0 vs 9+2 cross-sections, dynein
  ripple idle), `cytoskel` (the three filaments to scale, kinesin walking a microtubule), `peroxi` (oxidase →
  H₂O₂ → catalase loop, particles circulating), `glyoxPath` (6-stage fat → sugar route), `vacuole` (tonoplast,
  cell sap, turgor arrows, water entering). All ≥ 31 fps at CPU 8× throttle.
- **§১.৬ figures** (`src/chapters/b1c1/visuals5.js`): `chromo3d` (3D metaphase chromosome — two chromatids,
  centromere, kinetochores, pulsing spindle, satellite; slider moves the centromere and the type name V/L/J/I
  updates live; 28 fps @ CPU 8×, cost 6.97), `chromoParts` (the labelled figure the board asks for, with
  label-quiz), `chromoTypes` (4-stage V→L→J→I), `nucleosome` (6-stage packing ladder 2→11→30→300→700→1400 nm).
- **§১.৭ figures** (`src/chapters/b1c1/visuals6.js`): `nucleotide` (build-a-nucleotide — pick the base, switch
  the sugar, add/remove the phosphate; the name and the নিউক্লিওসাইড/নিউক্লিওটাইড chip update live, and picking
  T+ribose or U+deoxyribose shows a warning), `baseTypes` (purine vs pyrimidine + A–T/G–C pairs with flickering
  H-bonds). Hand-written `html()`/`mount()` rather than a BK builder, since the state is a 3-way picker.
- **Animate only what moves.** `nucleotide` first repainted the whole SVG each frame (28 fps); moving the pulse
  into its own `<g>` and repainting just that took it to 48 fps. Never rebuild a whole figure from `X.anim`.
- **`FK.btn` label swapping:** don't write to the button's `lastChild` — after the first write the text node
  splits and labels concatenate. Pass the label wrapped in a span (`FK.btn('k', '<span data-lbl>…</span>', …)`)
  and set that span's `textContent`.
- **FK.s3 axis convention:** in `BK.model3d`, **z is screen-vertical** and x/y are the rotating horizontal plane.
  Build a tall object along z (not y) or it renders lying down. Centre a lopsided object by adding an offset
  (`zc`) to every z, since the camera has no target offset. `S.line` ignores `op.id`, so lines are not tappable —
  give such a part a sphere or disc too if it must be selectable.
- **Label-collision rule:** in `BK.diagram`, the label anchor is derived from `l` vs `a` (`lx < ax-4` → `end`), so a
  label placed at the left edge is drawn **leftwards** and gets clipped — pass `an: 'start'` explicitly there.
  Don't repeat a part's name as static `T()` text in `art()`; put it in `lb` and let the label layer draw it once.
- **Two workflow gotchas learned the hard way:** (1) `tools/balance.js` only sees MCQ arrays that sit on their **own
  line** — write `xm:`/`mcq:` entries one per line or the answer distribution stays skewed (mine was 78% খ until
  reformatted). Always run `node tools/balance.js b1c1 && python3 build.py` after writing MCQs. (2) `gen_toc.py` does
  not touch hand-written files, so a `= figKey` line in `docs/toc.txt` has no effect there — add `v: ['figKey'],` to
  the lesson object by hand instead.

- **§১.৮–১.১১ figures**: `visuals7.js` — `dnaDims` (helix with 20 Å/34 Å/3.4 Å brackets; slider bp → length/turns/
  nucleotides, English digits; only 2 layers repainted per frame, 38 fps), `tRNAleaf` (BK.diagram cloverleaf, 47 fps).
  `visuals8.js` — `meselson`, `replFork`, `transcribe`, `translate` (BK.steps; translate uses a clean position model
  `P=[0,0,e,1+e,3][s]`, RX=M0+(P−1)*W). `visuals9.js` — `codonTable` (full 64-codon table built from the AA1 string;
  tap a codon; mutation seg silent/missense/nonsense/frameshift), `lacOperon` (5 stages). All 51–58 fps.
- **§১.১/১.৩ gap-fill figures** (`visuals10.js`): `cellScale` (log ruler 1 Å–1 m, slider picks an object, unit
  conversions + which instrument can see it), `ribosome` (diagram: 60S/40S, E-P-A sites, mRNA), `erTypes` (RER vs
  SER diagram), `golgiFlow` (ER → Golgi → exocytosis, 5 stages), `lysoCycle` (primary → phagosome → secondary →
  residual body → autophagy). 41–56 fps.
- **Colour ramp reminder**: BK.ramp(0) is teal, 2 orange, 3 purple, 4 red, 5 blue, 6 amber, 8 pink, 9 slate, 10 green.
  In BK.steps, use fs ≥ 12 for labels — smaller is unreadable at 360 px.
- **§১.১২** is the chapter review section: summary table, skills checklist + formula sheet, top-12 differences and
  must-draw figure list, mixed exercise (20 MCQ, 2 CQ, wp 2/3/5/7/10).

- **Chapter 2 figures**: `b1c2/visuals1.js` — `amitosis` (steps), `checkpoints` (cycle ring + cyclin E/B curves; seg normal / DNA damage (stops at G1) / p53 off (mutations pile up)), `dnaAmount` (slider through the cycle → C value, chromatid count). `visuals2.js` — `cytokinesis` (animal furrow vs plant cell plate side by side), `tumorGrowth` (seg normal / benign capsule / malignant crossing basement membrane + metastasis; elements created once, only attributes updated per frame), `apoptosis` (necrosis vs apoptosis side by side). `visuals3.js` — `meiosis` (8 stages, 2n = 4, crossing-over recolours tips, four distinct gametes A–D), `prophase1` (5 substages on one bivalent), `assortment` (slider n → 2ⁿ gametes, 4ⁿ zygotes via BigInt; shuffle button flips pairs). `visuals4.js` — `crossingOver` (A/a B/b labelled), `linkageMap` (Haldane: r = 50(1 − e^(−2d/100)); 100 dots), `chromoGene` (unlinked vs linked AaBb). All 48–60 fps at CPU 8×.
- **Cross-chapter figures don't load**: a lesson's `v:` can only use figure keys from its own chapter's visuals files.
- **Figure test clicks**: segmented buttons are `[data-seg="name"] button[data-k="value"]`.

## 1. What this is

A Bengali-medium HSC Biology study app — the sister of the HSC Chemistry app (same engine, features, themes and settings; only the content differs). Pure static HTML/CSS/JS, no framework, no server.
`python3 build.py` concatenates everything into:

- `dist/hsc-biology.html` — the whole app in one file (≈ 11.7 MB, works offline from `file://`).
- `docs/index.html` — the same file, for GitHub Pages (`/docs` folder). `docs/.nojekyll` is written too.
- `dist/index.html` + `dist/ch/<id>.js` + `dist/ch/<id>-vis.js` — a split version: core inline, one script per
  chapter. (Used when the app was hosted as a claude.ai artifact; fine for any static host too.)

All user-facing text is Bengali, using Bengali digits (`X.bn()` / `bn()` convert). Keep it that way.

## 2. Source layout

```
src/core/registry.js   window.HSC registry: HSC.chapter({...}), SEC (sections), VIS (visuals), CMPT (comparison tables)
src/core/vx.js         window.VX visual toolkit (X.fit, X.anim, X.onResize, X.C() theme colours, X.seg, X.svg,
                       periodic-table data X.PT / X.PTCAT / X.PTBLK, electron configs X.occZ / X.cfgZ / X.EXC …)
src/core/texmap.js, tex.js   TeX rendering (KaTeX + mhchem), lazy typesetting via MutationObserver
src/core/app.js        app engine: state S (localStorage), views (VIEWS.*), actions (ACT.*, data-act="…" delegation),
                       render(), go(name,args), lessons, quizzes, bank, library, settings, themes (THEMES / GLASSY)
src/core/plus.js       home sections (HSEC / HS.*), XP & levels, badges, flashcards SRS, mistakes, tests, games
src/core/plus2.js      saves (S.sv) + library, tricks, goals sheet, scoped tools (chapter/subject/all), minimal home,
                       "read" marks with verification quiz (S.done = mastered, S.self = self-marked),
                       home-arrange sheet, 48-hour delayed progress reset, global micro-interactions (enterFx, ripple, tilt)
src/core/style.css     all styles + 14 themes (glass themes need html[data-glass] + --aurora/--glass-* vars)
src/core/template.html commented template appended to the standalone file ("add new chapters here")
src/chapters/<id>/chapter.js        chapter metadata + optional book outline
src/chapters/<id>/content/sNN.js    sections: SEC.push({...}) and CMPT.push({...})
src/chapters/<id>/visuals*.js       visuals: V.key = {...}; files load in name order (visuals1…9, then visualsa)
```

`app.js` contains the marker `/*@@PLUS@@*/`; build.py replaces it with plus.js + plus2.js, so those run inside
the same BOOT closure and can use S, VIEWS, ACT, render, go, LMAP, SMAP, MCQ, CHAPTERS, CH, SECS, etc.

## 3. Content schema (one section)

```js
SEC.push({ id, no, sym, cat, w, t, st, intro, exam,
  L: [ /* lessons */ { id, no, t, ov, dp, sc, fx, ap, cm, tr, sn, mh, mf, cf, ho, xm, xs, v } ],
  Q: { mcq, sq, cq, bq, aq, nq, hq, wp },   // question bank
  F,  // flashcards  [front, back]
  FM  // formulas     [name, tex, note]
});
CMPT.push({ g, t, l, k });   // comparison table: k must equal an <h4> text in lesson l, followed by a .table-wrap
```

- Lesson exercise MCQ ids become `lessonId + 'x' + i`; bank MCQ ids `sectionId + 'm' + i`.
  MCQ objects: `{ id, sid, q, o:[4 options], a, d:'e'|'m'|'h', x: explanation, l: lessonId }`.
- `wp` (written practice) = 5 items `[marks, question, modelAnswer, scheme, commonMistake]`, marks 2/3/5/7/10
  (except sections with `cat: 'E'`). The UI groups them into the board's four levels
  (জ্ঞানমূলক, অনুধাবনমূলক, প্রয়োগমূলক, উচ্চতর দক্ষতামূলক) — see `wpLevel()` in app.js.
- `w` = exam weight; the section page shows it as 1–5 stars (`starN()` clamps; some 2nd-paper chapters use up to 12).
- Inline maths/chemistry in content strings: `{m|…}` inline TeX, `{M|…}` display TeX, `{ce|…}` / `{CE|…}` mhchem.
  Outside those blocks never write raw `X_y`; use `X<sub>y</sub>` (`tools/qa/subfix.py --apply` converts).

## 4. Visual API

```js
V.key = { t: 'title', k: ['2d'|'3d'|'anim'|'int'|'calc'|'info'], cap: 'caption',
          html: () => '<markup>', mount(el) { /* … */ return () => cleanup(); } };
```

Use `X.C()` / `FK.P()` for theme colours (never hard-code light-only colours), `X.anim(el, step)` for animation
loops (pauses off-screen and in reduced-motion mode), `X.onResize`. Keep labels short on phones (test at 360 px).

### BK kit — biology figures (`src/core/bk.js`)

Eight builders, each returning `{html(), mount(root)}`, so a figure is one line:

```js
V.cellPlant = Object.assign({ t: 'আদর্শ উদ্ভিদকোষ', k: ['2d','int','game'], cap: '…' }, BK.diagram({ … }));
```

| builder | what it gives |
| --- | --- |
| `BK.diagram({W,H,art(g,C,part),parts:[{id,bn,en,fn,a,l,lb?,le?}]})` | labelled figure: বাংলা/English/দুটোই/লুকাও toggle, tap a part or label for name+function, label-quiz, pinch/button zoom+pan. `art` calls `part(id)` to get a `<g>` per part; `lb`/`le` are short labels when the full name is long |
| `BK.steps({stages:[{t,en,d}],draw(g,C,s,u)})` | stage chips, scrubbable timeline, play/pause, 0.5×/1×/2× speed. `s` = stage index, `u` = 0→1 eased progress |
| `BK.cycle({center,sub,nodes:[{t,en,d,io:[[txt,'in'\|'out']]}],rx,ry})` | ring with a moving token; green `+` inputs, red outputs |
| `BK.tree(data)` / `BK.mind(data)` | collapsible tree / coloured mind map; node `{t,en,d,c:[…],id}` — `id` adds a "পাঠে যাও" button |
| `BK.ladder({rows:[{t,en,ex,d}]})` | tapering step ladder (taxonomic ranks, trophic levels), animates in |
| `BK.compare({a,b,rows:[[topic,aSide,bSide]]})` | difference table **plus** a "which one?" quiz mode |
| `BK.model3d({draw(S,ctx), parts, ctrl?, wire?, three?})` | 3D viewer: drag to rotate, auto-spin (pausable), tap a part for name+function, reset, optional extra controls. Renders with `FK.s3` (canvas, self-degrading); if `three` is given **and** Three.js is present it takes over |
| `BK.bars` / `BK.donut` / `BK.line` | bar chart, percentage donut, line graph (optional slider + readout, wraps `FK.graph`). All animate in and expose a replay button |

Helpers: `BK.T(g,x,y,s,{fs,c,a,w})` (text — must set `style` font-size/fill because the `.fk-t` CSS rule overrides
attributes), `BK.sub('CO','2')` (Android-safe subscript), `BK.arrow`, `BK.pal(i)`, `BK.zoom`, `BK.chapterTree`.

### Three.js (optional, lazy)

`build.py` looks for `vendor/three.min.js`. If present it is embedded as
`<script type="text/plain" id="bk-three-src">` — the browser does **not** parse it at page load, so startup cost is
zero. `BK.boot3d()` evaluates it once, on the first 3D figure that asks for it, and resolves `null` when the file was
never added. Every 3D figure must therefore work without it: write `draw(S, ctx)` (FK.s3) as the baseline and add
`three(THREE, ctx)` only as an upgrade. The file is not in the repo — drop it in `vendor/` and rebuild, nothing else
changes.

**Every figure must animate and be interactive** — see `docs/FIGURE_PLAN.md` §ক.২খ for the four required properties
(motion, touch, self-check, a readable paused state). `BK.diagram` takes an optional `idle(g, C, t)` layer for gentle
continuous motion (e.g. cyclosis in `cellPlant`).

**Colour — never hard-code a hex.** `BK.ramp(i)` returns a four-step ramp `{lt, c, dk, ink}` (12 hues, separate
light/dark sets, `ink` always ≥4.8:1 against the page). `BK.pal(i)` = fill, `BK.ink(i)` = text on that fill.
Biology meanings are fixed in `BK.org('nucleus'|'mito'|'chloro'|'er'|'golgi'|'vacuole'|'wall'|…)` and `BK.base('A')`.
Gradients: `BK.lg(svg, c1, c2, {a, mid, op})`, `BK.rg(svg, c1, c2)`, `BK.fill(svg, ramp)` — memoised per `<svg>`, so
calling them inside a redraw is safe.

**Two measured perf traps:** (1) `FK.dark()` / `FK.P()` call `getComputedStyle`; calling `BK.ramp`/`BK.base` *inside*
an animation loop halved dnaHelix's frame rate. Take colours once at the top of `draw()`. `BK.ramp` now caches until
the theme changes. (2) Creating a gradient per frame grows `<defs>` without bound — hence the memo; in `idle()`
layers prefer flat fills.

**Keep 3D cheap:** backbones and tubes as `S.path` + `S.sphere` (1 item each) rather than `S.cyl` (14 faces each);
pass `seg: 4`–`12` where a cylinder or `S.disc` is really needed. For a hollow organelle, draw a **wireframe shell**
(meridian `S.path` curves) rather than a faceted surface — `visuals3.js` has a reusable `shell()` helper, and both
cut-models come in at 106 and 171 items. Put 3D labels **above and below** the body (z offset, small lateral radius
times `cos/sin(S.yaw)`), never out to the side: side labels clip at the canvas edge once the model fills the frame. Check with `node tools/qa/perf.js '["key"]'` — keep the reported
`cost` under 14.

**Attaching a figure to a lesson:** add a `= key1, key2` line under the lesson in `docs/toc.txt`, then
`python3 tools/gen_toc.py && python3 build.py`. `node tools/check.js` reports any `= key` that is not registered.
Figures per lesson are open-ended — add more while writing a chapter; nothing else has to change.
Example of a large, polished visual: `src/chapters/c3/visuals7.js` (Figure 3.1, interactive periodic table —
property heat-maps, cursor "dock" magnification, touch-drag magnifier, Bohr model, orbital boxes).

## 5. Checks (run before publishing)

```bash
python3 build.py
node tools/check.js <chapterId>      # structure, ids, CMPT keys, wp marks, answer distribution
node tools/balance.js <chapterId>    # rebalance MCQ answer positions, then rebuild
python3 tools/qa/subfix.py [--apply] # find/fix raw underscores outside TeX blocks
# browser checks (need Node + Playwright: npm i playwright && npx playwright install chromium)
node tools/qa/allles.js <chapterId>  # opens every lesson, reports runtime errors
node tools/qa/txcheck.js <chapterId> # TeX render errors
node tools/qa/ovf.js                 # horizontal overflow at 360 px
node tools/qa/txtcheck.js            # raw underscores in rendered text
node tools/qa/crawl.js               # opens every section page, bank tab, quiz and tool view in all chapters
node tools/qa/figshot.js '["c3_ptable"]' 375 glass 2500   # screenshot one visual (width, theme, wait ms)
```

All six chapters currently pass: no structural problems, 0 runtime errors, no 360 px overflow.

## 6. Conventions worth keeping

- Phone first: everything must work at 360 px; tables scroll inside a box; touch targets ≥ 44 px.
- Cheap phones: animate only transform/opacity, throttle pointer work with requestAnimationFrame, stop loops
  off-screen, respect `html[data-motion="reduce"]` and `prefers-reduced-motion`.
- Default theme: Glass Aurora (`glass`). All themes unlocked.
- Progress honesty: `S.done[id]` = mastered (passed a 3-question check or read long enough), `S.self[id]` = self-marked.
  XP, progress % and badges count only mastered lessons.
- Everything is stored in localStorage (`S`). The app also looks for an optional `window.claude` runtime
  (artifact hosting) for cloud saving; on GitHub Pages it is simply absent and the app runs locally.

## 7. Planned, not built: optional login + teacher dashboard

Goal: students may optionally sign in so their progress is saved; the owner sees all students in a dashboard.

Suggested design (GitHub Pages + Firebase, free tier):

1. Firebase project → Authentication (Google provider) → Firestore. Add `<user>.github.io` to authorised domains.
   The web config object is public by design; security comes from Firestore rules.
2. Student app: a "লগইন করে অগ্রগতি সংরক্ষণ করো" button (optional; the app must keep working without it).
   On sign-in, write ONE summary document per student, debounced (on lesson done / every few minutes), e.g.
   `students/{uid}` = `{ nick, batch, updatedAt, progressPct, mastered, self, mcqAcc, streak, xp,
   chapters: {c2: pct, …}, weekMinutes: [7], weakTopics: {sid: wrongCount} }`. Do not store phone numbers or addresses.
3. Rules: a student can read/write only `students/{own uid}`; only the admin uid can read the collection.
4. `docs/admin.html`: sign in with the owner's Google account; KPIs (total, active today/week, average progress,
   accuracy, mastered lessons), daily-active chart, comparison table (sortable, searchable, row → detail),
   chapter heat-map, most-missed topics, weekly awards, CSV export.
   A visual mock-up of this dashboard was made earlier (sample data only).
5. Privacy (many users are under 18): login optional, say clearly what is stored and why, nickname on
   leaderboards, a "delete my data" button, parental consent where appropriate.


## Chapter 3 (`b1c3`) figure notes — Nov 22, 2026
- Files: `visuals0.js` (enzT, enzPH — kept), `visuals1.js` (§৩.১: cellElements, cellCompounds, carbClass, carbDeriv, carbRoles, energyBars, cmpRiboDeoxy, cmpGluFru, cmpStarchCell, sugarForms/pentoses, glycosidic, polysac/celluloseFib/glycogenModel, glycogenFlow), `visuals2.js` (§৩.২: aminoAcid, aaClass, proteinClass, cmpFibGlob, proteinRoles, proteinFood, peptideBond, proteinLevels/proteinDenature), `visuals3.js` (§৩.৩: fattyAcid/fatMelt, lipidClass, cmpFatOil, oxyBars, lipidRoles, triglyceride, phospholipid, lipidProfile, steroidRing), `visuals4.js` (§৩.৪: activationEnergy, enzMech, holoenzyme, cofactorTree, enzClass, enzUses, cmpEnzCoenz, cmpEnzCat, enzKinetics), `visuals5.js` (§৩.৫: bioTests virtual lab, b1c3map).
- **Factory pattern for "same figure, different start"**: `sugarVis('glu'|'rib')`, `polyVis('amy'|'cel'|'gly')`, `faVis('one'|'pack')`, `lvl(.999|4.999)` — register one VIS key per starting state so a lesson opens on the relevant view.
- **sugarForms**: Fischer → Haworth morph; atoms interpolate between chain and ring coordinates; rule "Fischer right → Haworth down" is encoded in the sub-group table. The H of the ring-forming –OH visibly moves to the anomeric O.
- **Perf rule learned**: Bengali `<text>` shaping is the main per-frame cost. Never recreate Bengali labels in an animation frame — create once and only update `textContent`/x/y (see `setT` in glycosidic, `hT1..3` in sugarForms), or hang static labels on `g.ownerSVGElement` inside `BK.steps.draw` (`svg._leg`, `svg._gl`). Use English abbreviations (Gly/Ala/Ser) for small moving labels.
- perf.js at CPU 8×: most figures 30–57 fps; glycosidic/peptideBond ≈ 26–31 — same range as `mitosis` (29) measured in the same run (machine was slower than in earlier sessions).
- Numbers verified with Python: element % sum = 100, pI values (Gly 5.97 … Glu 3.22), masses (sucrose 342.3, tripalmitin 807.3, O% 11.9), Friedewald examples, 20⁵, 150-aa peptide mass.
- Activation-energy values for H₂O₂ (75 / 49 / 23 kJ/mol) are labelled "approximate, source-dependent" on purpose.
- Step-chip rows (`.bk-chips`) are reported by `ovl360.js` as BUTTON overflow — this is by design (horizontal scroll).

## Chapter 4 (`b1c4`) figure notes — Nov 22, 2026
- Files: `visuals1.js` (§৪.১ ভাইরাস: phageT2, tmvModel, virusShapes, lyticCycle/lysogenicCycle via factory `cyc(mode)`, virusClass, subviral, cmpDnaRna, cmpLyticLyso, cmpViroidPrion, virusEcon, virusDiseases, virusCancer), `visuals2.js` (§৪.২ ব্যাকটেরিয়া: bacCell, bacShapes, gramStain, binaryFission, conjugation, bacClass, cmpGram, cmpFlagPili, cmpVirBac, bacUses, bacHarm, bacDiseases), `visuals3.js` (§৪.৩ ম্যালেরিয়া: plasmoCycle, liverStage, rbcCycle, sporogony, feverChart, cmpHumanMosq, cmpVivaxFalci, malariaControl), `visuals4.js` (§৪.৪: b1c4map mind map, microScale log-size scale).
- `figshot.js` acts argument is an **object keyed by figure key**: `'{"microScale":["[data-k=chips] [data-i=\"0\"]"]}'` (a bare array is silently ignored).
- microScale: rows one per organism (no label collisions), labels offset 15 px so the pulsing ring never covers text; red dashed line = light-microscope limit 200 nm.
- Accuracy choices: mesosome = artifact; "এক্সো-এরিথ্রোসাইটিক সাইজোগনি" kept as textbook term with note that relapse = hypnozoite; সুপ্তাবস্থা treated as incubation period (+ hypnozoite dormancy); Plasmodium chromosomes n = 14; meiosis in oocyst; vivax treatment CQ 3 d + PQ 14 d, falciparum ACT + single low-dose PQ (Bangladesh guideline); WHO burden given as rounded "25 কোটির বেশি, প্রায় 6 লক্ষ" to avoid stale exact figures.
- Numbers verified with Python: 2^21 = 2,097,152; 2^72 ≈ 4.72e21 (≈ 4,700 t at 1 pg/cell); 100 × 2^10 = 102,400; 2^18 = 262,144; E. coli DNA ≈ 1.56 mm ≈ 780 × cell length.
- perf.js CPU 8×: 35–60 fps for all animated b1c4 figures (binaryFission 35, liverStage 39 lowest).

## Chapter 5 (`b1c5`) figure notes — Nov 22, 2026
- `visuals1.js` defines a shared helper `window.B5`: `B5.grid(o)` (selectable grid figure: `{t,cap,cols,ch,ramp(i),items:[[key,name,desc,example]],draw(gg,key,R,C)}` — `draw` may return `u(t,isSel)` for idle animation) and `B5.swimmer(g,x,y,r,nf,R,t,ang)` (flagellate cell). `visuals2–4.js` read `window.B5`, so keep visuals1 loading first (build globs alphabetically).
- Colour semantics fixed for this chapter: green algae/chloroplast = `BK.ramp(10)`, wall/plant = 11, nucleus = 3, eyespot/red = 4. Do not use ramp 3 for green tissue (it renders violet).
- Figures: algaeForms, algaeCell, chloroShapes, algaeClass, algaeRepro, gameteTypes, ulothrixFil, ulothrixCycle, algaeEcon (visuals1); fungiForms, hyphaTypes, fungalCell, fungiClass, fungiRepro, sexPhases, fungiEcon, agaricusBody, gillTS, basidiocarpDev, cmpAlgaeFungi (visuals2); fungalDis, blightLeaf, blightCycle, blightWeather (sliders, risk = 10–25 °C and RH ≥ 90%), ringworm, cmpBlightRing (visuals3); lichenSection, lichenTypes, lichenExchange, lichenSO2 (approximate thresholds: fruticose 35, foliose 70, crustose 150 µg/m³ — labelled approximate), lichenUses, b1c5map (visuals4). All ≥ 42 fps at CPU 8× (perf.js with `[data-pp]`).
- Gender labels are Bengali text (no ♀/♂ glyphs). Right-side labels in fungalCell/lichenSection were moved inward to fit 360 px.
- Accuracy decisions: Phytophthora infestans is taught as a fungal disease but flagged as an oomycete (cellulose wall, diploid); Agaricus has no volva; A. bisporus 2 spores/basidium (A. campestris 4); Ulothrix is haplontic, heterothallic isogamous — zoospores 4 flagella (2–32/cell), gametes 2 flagella (8–64/cell), zygote 4 flagella, meiosis in zygote giving 4–16 spores; steroid-combination creams worsen tinea (T. indotineae); lichen mycobiont ~98% ascomycete, photobiont ~90% green alga; SO₂ sensitivity fruticose > foliose > crustose.

## Chapter 6 (`b1c6`) figure notes — Nov 22, 2026
- `visuals1.js` defines `window.B6`: `B6.grid(o)` (same API as B5.grid; chapter visual files load per chapter, so each chapter keeps its own helper) and `B6.sperm(g,x,y,R,t,ang,multi)` — biflagellate (bryophyte) or coiled multiflagellate (fern) sperm. A local `dich()`/`drawThallus()` builds dichotomous thalli from stroked segments.
- Figures: bryoGroups, bryoClass, bryoTraits, altGen (seg Ulothrix/Riccia/Funaria/Pteris/angiosperm; n:2n ring, approximate proportions), ricciaThallus, ricciaTS, ricciaSex, ricciaSporo, ricciaCycle (visuals1); pteridoClass, pteridoTraits, pterisPlant (idle crozier unrolls), pterisSorus, sporangium (BK.steps; upper capsule rotates about the annulus hinge, catapult in stage 5), rhizomeTS, rachisTS (U meristele drawn as one path stroked at decreasing widths), prothallus, pterisCycle, cmpBryoPterido (visuals2); pterisPractical, rachisStain (raw/safranin/double stain, 10x/40x, uses clipPath id `stnclip`), b1c6map (visuals3). All ≥ 36 fps at CPU 8×.
- Accuracy decisions: Riccia sporophyte = capsule only (no foot, seta, elaters; nurse cells present); Riccia archegonium neck 6 rows, 4 neck canal cells; fern archegonium neck 4 rows, one binucleate neck canal cell; calyptra is n; Pteris rhizome stele described as dictyostele with the caveat that species/age vary (solenostele in some); rachis has a single horseshoe meristele; sporangium 16 SMC → 64 spores, annulus vertical incomplete, spore launch ~10 m/s (cavitation catapult); fern sperm attracted by malic acid; prothallus "a few mm"; Pteris vittata arsenic up to ~2% frond dry weight; Pteris cretica apogamous.

## Chapter 7 (`b1c7`) figure notes — Nov 23, 2026
- Helper `window.B7` (visuals1.js): `grid(...)` card grids, `pinnate(g,x,y,a,L,n,R,bend,lw)` for Cycas-like leaves; `B7.sym(g,k,x,y,s,col)` (visuals3.js) draws floral-formula symbols in SVG — k = act | zyg | bi | male | female. Never use the Unicode circle-plus / gender glyphs (missing on many Android fonts).
- Content-side symbols: `window.FS7` is defined at the top of `content/s03.js` (content files load alphabetically, so s04/s05 can use it). Inline SVG for act/bi/male/female, `%` for zygomorphic, `sup(n)` / `inf(n)` = G with under/over line, `adh(html)` = arc over adnate whorls, `box(...tokens)` = wrapped formula chip (each token nowrap). Ready formulas: `FS7.jaba, dhan, sarisha, motor, dhutura, shosha`. Tables holding formula chips use `class="t sm"` (no 420px min-width) so they fit at 360px.
- `tallTrees` data from Wikipedia "List of tallest trees" (Hyperion 116.07 m; Cupressus austrotibetica 102.3 m; Picea sitchensis 100.2 m; Menara Shorea 97.58 m is the tallest angiosperm). Textbook trio (Sequoia sempervirens, Sequoiadendron giganteum, Eucalyptus regnans) is mentioned with a caveat in s1b.
- Accuracy choices: angiosperm endosperm 3n vs gymnosperm n; embryo sac 7 cells/8 nuclei (Polygonum type); Nawaschin 1898; rice A3+3 with 2 lodicules, basal placentation, caryopsis; Malvaceae monothecous reniform anthers, spiny pollen, axile placentation; APG broad Malvaceae includes jute, Bombax, cacao, Heritiera fomes; Abelmoschus (not Hibiscus) esculentus; mustard placentation parietal with replum; Amaryllidaceae (not Liliaceae) for onion.
- `ovl360` flags `BUTTON` overflow inside BK.steps figures (cycasCycle, doubleFert, malvaPractical) without page scroll (sw = 360) — same as earlier chapters, acceptable. Perf at CPU 8×: all animated figures 33–60 fps (tallTrees lowest at 33).

## Chapter 8 (`b1c8`) figure notes — Nov 23, 2026
- Helper `window.B8` (visuals1.js): `B8.seg(o)` = switchable figure with a static layer (`art(g,C,ty,ctx)`), a per-frame layer (`anim(g,C,ty,t,ctx)`, pointer-events none) and optional tap → info (`tap(x,y,ty,ctx)` returns HTML; svg-coordinates computed via getScreenCTM). Also `B8.blob`, `B8.ringCells`, `B8.ringBlobs` (cell textures for cross-sections), `B8.cube` (isometric cubes for planes of division), `B8.lab` (leader-line label), `B8.rnd` (deterministic noise).
- Anatomy drawers (visuals2.js, reused by visuals3): `B8.dStem` (sunflower), `B8.mStem` (maize; bundle list `B8.MB`, bundle drawer `B8.mBundle`), `B8.dRoot` (gram, tetrarch), `B8.mRoot` (maize, 12-arch) — all `(g, C, cx, cy, R, hl)`; `hl` = list of zone keys to keep coloured (others grey). `B8.zoneOf(kind, dx, dy, R)` → zone key; `B8.ZI` / `B8.zoneInfo(z)` give the zone name, tissue system and description.
- Colour rule for the whole chapter: lignified (xylem, sclerenchyma) = ramp 4 red (safranin), phloem = 10 green, cambium/meristem = 6 amber, endodermis = 3 violet, pericycle = 2 orange, epidermis = 0 teal, collenchyma = 5 sky, parenchyma = 11 olive (light).
- Accuracy choices: tissue — Grew 1682; meristem — Nägeli 1858; histogen — Hanstein 1868; tunica-corpus — Schmidt 1924; quiescent centre — Clowes 1956; tissue systems — Sachs 1875; Casparian strip — Caspary 1865; cohesion-tension — Dixon & Joly 1894; pressure flow — Münch 1930; intrafascicular cambium primary, interfascicular & cork cambium secondary; dicot root 2–6 xylem arches, monocot root polyarch (>6) with large pith; monocot stem bundles closed, sheathed, Y-shaped xylem, lysigenous cavity, no phloem parenchyma; bicollateral = Cucurbitaceae; amphicribral = ferns, amphivasal = Dracaena/Yucca/Acorus; stomatal types (anomo-, aniso-, para-, diacytic, gramineous).
- Section 3 symbol changed from the placeholder circled-ring symbol (not reliable on Android) to `Ana`. Perf at CPU 8×: all animated figures 39–59 fps. `ovl360` flags only the BK.steps BUTTON in `sectionSteps` (sw = 360, no page scroll) — same as earlier chapters.

## Chapter 9 (`b1c9`) figure notes — Nov 23, 2026
- Helper `window.B9` (visuals1.js): `bn`, `rnd`, `cl`, `ch(s)` (SVG tspans from `NO_3^-`, `^{18}O`, `_{12}` — never type Unicode sub/superscripts in figure text), `chH` (same for HTML), `seg(o)` (switchable figure: `types`, `sl` sliders → `ctx.v`, `art`/`anim`/`tap`/`more`), `gseg(o)` (graph-type figure: per-type curve `f`, x-range, marks, reading text), `axes`, `curve`, `area`, `along`, `poly`, `ion`, `dot`, `blob`, `lab`, `chip`, `mem` (bilayer), `node` (defined in visuals2). Old keys `krebs`, `calvin`, `atpTally` (visuals0, BK.cycle/BK.bars) are kept and reused.
- Files: visuals1 = mineral nutrition + transpiration (nutrients, soilPH, ionExch, uptake, carrierSteps, waterPath, ascent, upFactors, transpTypes, stomaMech, transpFactors, potometer, stomaPeel, transpImp + compares); visuals2 = light reactions + Calvin/C4 (spectrum, absorb, photoOverview, antenna, photolysis, zscheme, thylakoid, calvinCount, starchSucrose, photoresp, hatchSlack, kranz + compares); visuals3 = O2 source, limiting factors, practicals, respiration I (o2source, limiting, bubbleCount, rateCtrl, psFactors, molls, psImportance, atpStruct, respOverview, glycolysis, linkReaction, etc, atpCalc, plantMito + compares); visuals4 = anaerobic, factors, RQ, growth/hormones/photoperiod (fermentation, respSites, respFactors, rq, anaerobicExp, growthCurve, hormones, photoperiod, vernal, b1c9map + compares).
- Colour rule: water = ramp 5, mineral ions = 2, H+ = 4, ATP = 6, chlorophyll/leaf = 10, sugar = 7, CO2 = 9, O2 = 0, NADPH/NADH = 3.
- Accuracy choices: 17 essential elements (9 macro incl. C, H, O; 8 micro incl. Ni); Arnon & Stout criteria; cohesion-tension (Dixon & Joly 1894); air water potential from Ψ = (RT/V̄) ln RH (≈ 135 ln RH MPa at 20 °C; RH 50 % → −93.6 MPa); K+ pump model of stomatal opening, ABA closes; photon energy E = hc/λ (680 nm ≈ 176 kJ/mol, 700 nm ≈ 171); PS-II P680 / PS-I P700, Mn4CaO5 cluster; Z-scheme carrier order H2O → P680 → Pheo → PQ → b6f → PC → P700 → Fe-S → Fd → FNR → NADP+; non-cyclic yields ATP + NADPH + O2 (textbook: 1 ATP per NADPH), cyclic ATP only; quantum requirement 8; Calvin 3 ATP + 2 NADPH per CO2 (18 + 12 per glucose); C4 5 ATP per CO2 (30 per glucose); RuBisCO oxygenation trend with temperature drawn qualitatively; Ruben & Kamen 18O; Blackman 1905; respiration textbook 38 ATP (8 + 6 + 24; 36 with glycerol-phosphate shuttle), modern 30–32 (NADH ≈ 2.5, FADH2 ≈ 1.5) always shown as a note; ATP hydrolysis 30.5 kJ (7.3 kcal); glucose 2870 kJ (686 kcal), efficiency ≈ 40 %; ETC H+ pumping I 4, III 4, IV 2; plant mitochondria: AOX (cyanide-resistant, thermogenic), rotenone-insensitive NAD(P)H DH, glycine decarboxylase, NAD-malic enzyme, ATP (not GTP) from succinyl-CoA; RQ: carbohydrate 1, tripalmitin 102/145 = 0.70, malic 4/3, oxalic 4, anaerobic ∞; alcoholic fermentation ≈ 235 kJ/mol, lactic ≈ 196 kJ/mol; Q10 ≈ 2–2.5. §৯.৮ (growth, hormones, photoperiodism, vernalization) is extra (not in the new textbook TOC) — flagged in its title.
- Multi-statement MCQs were rotated with a scratch script (true statements moved between i/ii/iii positions so 2-true answers spread over ক/খ/গ; items whose explanation names a statement number are skipped) before `balance.js`. Perf at CPU 8×: all checked figures 53–60 fps. `ovl360` flags only the BK.steps BUTTON rows (sw = 360, no page scroll) — same as earlier chapters.

## Chapter 10 (`b1c10`) figure notes — Nov 23, 2026
- Load order matters: `build.py` concatenates chapter folders in name order, so `b1c10` loads **before** `b1c2`…`b1c9`. Chapter 10 therefore cannot use `window.B9`; `visuals0.js` carries its own copy as `window.B10` (seg, gseg, ch/chH, axes, curve, area, along, poly, ion, dot, blob, lab, chip, mem, node). Any later chapter that sorts before its helper's owner must do the same.
- VIS keys are global across chapters: `doubleFert` already existed in `b1c7`, so chapter 10's double-fertilization steps figure is `dblFert`. Grep all `src/chapters/*/visuals*.js` for a key before adding it.
- Figures: visuals1 = flowerParts, antherTS, pollenGrain, microGameto (steps), ovule (ana/ortho/campylo), megaGameto (steps), embryoSac, cmpMaleFemale; visuals2 = pollinationTypes, pollinators, outcross, pollenTube, dblFert (steps), postFert (tap rows), embryoDev (steps), seedTypes, cmpSelfCross, cmpFertDouble, cmpAnemoEnto, cmpSeedDM; visuals3 = asexTypes, vegProp, lifeLoop (alternation of generations with apomixis shortcuts), polyEmb, cmpParthSex, cmpAsexSex, cmpAposApog; visuals4 = artProp, tissueCulture (steps), handCross (steps), domestic (Brassica / teosinte / wheat polyploidy), cmpNatArt, cmpGraftBud, b1c10map.
- Colour rule: male parts/pollen = ramp 6, female parts/ovule = 3, haploid = 2, diploid = 10, triploid endosperm = 7, embryo = 0, coats = 11, water = 5. Tap figures use a nearest-hotspot helper `hot([[key, x, y]], x, y, r)`.
- Accuracy choices: Polygonum (monosporic) embryo sac ≈ 70 % of angiosperms, chalazal megaspore functional, 7 cells / 8 nuclei; ~70 % of species shed 2-celled pollen (rice, wheat, mustard 3-celled); exine = sporopollenin, intine = cellulose-pectin; anatropous ovule most common; Amici 1824 (pollen tube), Strasburger 1884 (syngamy), Nawaschin 1898 & Guignard 1899 (double fertilization), Treub 1891 (chalazogamy, Casuarina), mesogamy Cucurbita; Owen 1849 (parthenogenesis term), Drury 1884 / Bower 1885 (apospory), Farlow 1874 / de Bary 1878 (apogamy), Winkler 1908 (apomixis), Leeuwenhoek 1719 (polyembryony, Citrus); Haberlandt 1902 (totipotency), Murashige & Skoog 1962 (MS medium), Skoog & Miller 1957 (auxin:cytokinin), autoclave 121 °C / 15 lb / 15–20 min; Karpechenko 1928 (Raphanobrassica); bread wheat AABBDD 6n = 42; Sub1 in BRRI dhan51/52; synthetic apomixis in rice (MiMe + BBM1, 2019).
- Perf at CPU 8×: 30–59 fps (megaGameto lowest at 30). `ovl360` flags only BK.steps BUTTON rows, as in earlier chapters.


## Chapter 11 (`b1c11`) figure notes — Nov 23, 2026

- **Helper copy:** `b1c11` sorts before `b1c2`–`b1c9` in `build.py`'s name order, so it cannot use B9/B10. `visuals0.js` defines its own `window.B11` (same API as B9: `seg`, `gseg`, `axes`, `curve`, `area`, `along`, `poly`, `ion`, `dot`, `blob`, `lab`, `chip`, `mem`, `node`, `hot`, `dna`, `ch`, `bn`, `cl`, `rnd`, `pol`). `visuals3.js` additionally exports `window.B11X = { nope, okm, arrow, sprout, cellN, cmp }`, which `visuals4.js` consumes — so visuals3 must stay before visuals4 in load order.
- **Slider values live in `ctx.v[key]`, not `ctx.sl`.** `anim()` only draws into the `gd` layer (cleared every frame) and must never mutate `ctx.v` or call `redraw()`. `art()` runs before `anim()` on every redraw, so anything the animation computes cannot be read back by `art()` — draw progressive content (e.g. `sangerSeq` bands, `gelElectro` highlights) inside `anim()` itself, handling `t === 0` as the resting state.
- **Figure keys** (all checked against `grep -o "V\.[A-Za-z0-9]*" src/chapters/*/visuals*.js` for collisions before adding):
  - visuals1 (§১১.১): `bioScope`, `bioTimeline`, `tcLab`, `tcMedia`, `hormoneRatio`, `tcProtocol`, `tcMultiply`, `cultureTypes`, `tcBangla`, `tcBalance`, `cmpTradModern`, `cmpTcConv`, `cmpMeriAnther`
  - visuals2 (§১১.২): `rdnaSteps`, `plasmidMap`, `reCut`, `siteFreq`, `transformSel`, `cloneGrowth`, `cdnaMake`, `vectorCap`, `pcrCycle`, `pcrCount`, `cmpTcRdna`, `cmpRdnaPcr`, `cmpPlasmidChromo`, `cmpStickyBlunt`
  - visuals3 (§১১.৩): `gmCrops`, `rDrugs`, `herbicideTol`, `dollyClone`, `transAnimal`, `btAction`, `bdGM`, `insulinMake`, `ifnAction`, `tpaAction`, `cmpTransClone`, `cmpGmConv`, `cmpInsulinSrc`
  - visuals4 (§১১.৪–৫): `futureBio`, `sangerSeq`, `genomeApply`, `dnaFp`, `gelElectro`, `paternity`, `caseMatch`, `biosafety`, `cmpSangerNgs`, `cmpFpSeq`, `b1c11map`
- **Colour conventions reused from `src/core/bk.js`:** `BK.base(b)` for A/T/G/C (A green, T red, G grey-blue, C blue) — `sangerSeq` uses it rather than a local map, so the four lanes match every other chapter's DNA figures. For yes/no outcomes, ramp 10 (green) = match, ramp 4 (red) = no match; `caseMatch` and `paternity` both follow this, and `biosafety`'s BSL bars run 10 → 0 → 2 → 4 as risk rises.
- **Accuracy choices worth keeping:**
  - Bt brinjal: approval **30 Oct 2013** by the National Committee on Biosafety, seedlings to 20 farmers **22 Jan 2014**, gene *cry1Ac* (event EE-1), four varieties BARI Bt Begun 1–4 = Uttara, Kajla, Nayantara, Ishurdi/ISD006 (verified against the PMC review and ISAAA Brief 47).
  - Recombinant drug timeline: insulin 1982, hGH 1985, interferon-α and hepatitis B vaccine 1986, tPA (alteplase) 1987, EPO 1989, factor VIII 1992.
  - Host-choice rule stated throughout: simple non-glycosylated proteins → *E. coli*; glycosylated/complex (tPA 527 aa, EPO, factor VIII) → CHO cells.
  - Interferon: Isaacs & Lindenmann 1957; gene cloned 1980 (Weissmann); first approval 1986; species-specific but **not** virus-specific.
  - DNA fingerprinting: Jeffreys 1984, first criminal investigation 1986; the MCQ says "প্রথম অপরাধ তদন্তে" explicitly because the first use of all was a 1985 immigration case.
  - Sanger 1977; HGP 1990–2003 (draft 2001), ~3.2 Gbp, ~20–25k protein-coding genes, ~2% coding.
  - Cartagena Protocol adopted 2000, in force 2003; Bangladesh Biosafety Rules 2012; approvals by the National Committee on Biosafety under the Department of Environment.
  - Interferon dose worked example uses 3 million IU ≈ 12 µg (IFN α-2b specific activity ~2.6×10^8 IU/mg), not 15 µg.
- **Forensic framing:** every forensic figure and lesson states the exclusion/inclusion asymmetry — a mismatch excludes with certainty, a match is expressed as a probability over 13–20 STR loci. Figures use neutral labels ("নমুনা ক/খ/গ") rather than naming suspects.
- **CPU 8× perf:** the eleven §১১.৪–৫ figures run 55–60 fps; `ovl360.js b1c11` reports only the known BUTTON rows from `BK.steps` chips (errs 0).

- **Post-audit (Nov 23, 2026, second pass):** the §১১.৩g–h / §১১.৪ / §১১.৫ material was re-checked. Fixed: "অবাধ্য পিতৃ-অ্যালিল" → "আবশ্যিক পিতৃ-অ্যালিল" (obligate paternal allele); `&prime;` → the project's `3′-OH` convention; 4-digit years and °C temperatures normalised to English digits (matching §১১.১–২); BSL labels are `BSL-1…4`; Chakrabarty is "first patented genetically engineered organism (1980)"; gene therapy 1990 is the first approved *trial*; paternity/fingerprint/gel figures recoloured so mother (2), child (5), match (10) and non-match (4) never share a hue.

## Chapter 12 (`b1c12`) figure notes — Nov 23, 2026

- **Helper copy:** `visuals0.js` defines `window.B12` (B11 API) plus `B12.GEO.bd` (Bangladesh outline, 300-wide, `bdH` 411.3), `B12.GEO.world` (340×150), `B12.bdXY(lon, lat)` and `B12.wXY(lon, lat)`; `B.bdMap(g, C, ox, oy, sc, {fill})` lives in visuals3. visuals1 exports `B12X = {arrow, okm, nope, cmp, org}`; `org(g, kind, x, y, s)` draws grass, shrub, tree, insect, zoo, plank, rabbit, deer, frog, snake, hawk, bird, tiger, fish, bigfish, fungus, cow.
- **Two traps found this chapter:** (1) a `types` key named `st` or `info` collides with the stage `data-k` selectors — the stage rendered inside a button; use other keys (mangroveRoots uses `pn`/`stl`/`vv`). (2) White text on a filled badge needs `st: 'stroke:none'`, because `.fk-t` has a halo stroke that turns small white text into blobs (also fixed once in `b1c8/visuals2.js`).
- **Maps:** world rings with min latitude < −55 are skipped and longitudes clamped (no Antarctica/antimeridian artefacts); Douglas–Peucker is applied per half-ring so closed rings do not collapse. Zoomed maps (`orientalMap`) are additionally clipped to a rounded 360×H rect so land does not poke past the frame; `ovl360.js` still lists `g`/`path` for §১২.৩c–d because `getBoundingClientRect` ignores clip paths — page width stays 360, so it is a known false positive, like the BUTTON rows.
- **Colour conventions:** trophic levels producer 10, primary 6, secondary 2, tertiary 4, decomposer 11, water 5; IUCN categories CR 4, EN 2, VU 6, NT 7, LC 10, RE/EW 3, EX 9.
- **Digits:** values, percentages, years and temperatures in English digits (65 Bengali-digit values in s01/visuals1/visuals4 were converted, e.g. "10% সূত্র", "1962 সালে", "95 শতাংশ"); `bn()` is kept only for numbering (months, step numbers).
- **Accuracy choices worth keeping:**
  - Sundarbans: Bangladesh part ~6,017 km² (land ~4,143, water ~1,874), ~60% of the whole; Ramsar 1992, UNESCO 1997 (three wildlife sanctuaries); tigers ~125 (2024 survey); three dolphin sanctuaries 2012 (Dhangmari, Chandpai, Dudhmukhi); salinity falls west → east (sundari east, gewa-goran west).
  - Nijhum Dwip: 14 chital released 1974–1979 (Prothom Alo) — not the often-repeated "four pairs in 1978"; national park 8 Apr 2001, ~16,352 ha.
  - Red lists: BD first list 2000; animals 2015 (390 threatened, 31 RE = 11 mammals, 19 birds, 1 reptile); first plant red list Nov 2024 (1,000 assessed, 395 threatened, talipam EW, 7 RE, 5 CR). Statuses always given as global/national pairs (nilgai LC/RE, mugger VU/RE, gharial CR/CR, red-headed vulture CR/CR, shushuk EN/EN).
  - Vultures: diclofenac cause shown 2004 (Oaks et al.); BD veterinary ban 2010; two vulture-safe zones 2014; meloxicam as safe alternative.
  - 19 national parks (first Himchari 1980, largest Nijhum Dwip, smallest Ramsagar ~28 ha, newest Dharmapur 2021); eco-parks and safari parks named by place (Sitakunda, Madhabkunda, Gazipur, Dulahazara) because institutional names changed after 2024.
  - Mangrove wave attenuation quoted as 13–66% per 100 m (McIvor et al. review), with "অবস্থাভেদে".
  - IUCN: founded 1948, Gland; Red List since 1964; v3.1 (2001) nine categories; simplified A2 (80/50/30%) and D (<50/<250/<1,000) thresholds are labelled as simplified.
- **CPU 8× perf:** all 55 figures run 55–61 fps (p90 17 ms, speciesConcept 33 ms).

## 2nd paper Chapter 1 (`b2c1`) figure notes — Nov 23, 2026

- **Helpers:** `visuals0.js` defines `window.B21` (same API as B12 minus GEO). visuals1 exports `B21X = {arrow, okm, nope, cmp, layer}` (`layer(k)` → ramp for germ layers: ec 5, me 4, en 7, coelom 10, notochord 3, nerve cord 2); visuals2 adds `B21X.ani(g, kind, x, y, s, {R})` — 28 simple animal icons (sponge … mammal) reused by vertClasses and labSpecimens.
- **Core fix found this chapter:** `BK.T` set `innerHTML` on an SVG `<text>`, so `<sub>/<sup>` inside figure text were silently dropped (e.g. "CaCl<sub>2</sub>" in `b1c11/transformSel` rendered as "CaCl"). `BK.T` now rewrites them to `<tspan baseline-shift="sub|super" font-size="75%">` — applies to every chapter.
- **Lesson `xm` balancing:** `tools/balance.js` only touches one-MCQ-per-line arrays, so lesson `xm: [...]` lines were never rebalanced. Scratch script `xmbal.js` (greedy, skips multi-statement items, escapes `\n`) brought the chapter to 67/63/63/63 — worth adding to `tools/` for later chapters.
- **Perf:** a single 52-key `perf.js` run degrades towards the end (late keys read 25–40 fps); re-running those keys alone gives 56–60 fps. All 52 figures ≥54 fps at CPU 8× when measured in batches of ≤10.
- **Accuracy choices worth keeping:**
  - Species counts: Zhang (2013, Zootaxa) extant described animals 1,525,728; Arthropoda 1,257,040 (82.4%), Mollusca 84,977, Craniata 65,458; Mora et al. (2011) estimate ~7.77 million animal species. IUCN Bangladesh 2015: 1,619 assessed (138/566/167/49/253/141/305), 390 threatened, 31 RE.
  - Earthworm named `Metaphire posthuma` (formerly `Pheretima posthuma`); clitellum 14–16. Leech `Hirudinaria manillensis`, 33 segments. Kola frog `Hoplobatrachus tigerinus`, toad `Duttaphrynus melanostictus`.
  - Classification of Chordata given as Uro-/Cephalo-/Vertebrata → Agnatha (Petromyzontida, Myxini) and Gnathostomata (Chondrichthyes, Actinopterygii, Sarcopterygii, Amphibia, Reptilia, Aves, Mammalia), with a note that textbooks differ (Osteichthyes as one class).
  - Bangladesh lymphatic filariasis elimination validated by WHO in 2023; coelacanth Dec 1938; platypus specimen 1799 (George Shaw); Hox Nobel 1995; Morgan 1898 planarian 1/279 fragment; Wilson 1907 sponge re-aggregation; Lamarck 1778 dichotomous keys.

## 2nd paper Chapter 2 (`b2c2`) figure notes — Nov 23, 2026

- **Helpers:** `visuals0.js` defines `window.B22` (copy of B21 renamed) plus `B22.arrow`, `B22.okm`, `B22.cmp` (→ `BK.compare`), `B22.ring(g,x,y,r,on,R)` and `B22.pick(ctx,H,x,y,r)`. Colour ramps used consistently: epidermis 5, gastrodermis 7, mesoglea 3, food 10, blood 4, nerve 2, air 5, hopper 10, rohu 1.
- **Reusable drawings:** `B.hydra(g,C,x,top,s,{n,sw,len,bend,green})` (visuals1), `B.hopper(g,C,ox,oy,s,{R,wing,pads,ovi,kick})` (visuals2; hind leg knee 214,70, foot 150+50k,150) and `B.fish(g,C,ox,oy,s,{R,w,mouth:'sub'|'up'|'down',scales})` (visuals3) — later zoology chapters (e.g. human physiology comparisons) can reuse them.
- **Key renames:** `hydraBody` collided with a b2c1 key → `hydraExt`. Seg type key `st` is reserved (clashes with state) → labMouth uses `pr`. Check new keys against the global VIS list before adding.
- **`tools/xmbal.js`** (greedy lesson-`xm` balancer, skips multi-statement items, escapes `\n`) is now in `tools/`; run it after `balance.js`.
- **Perf:** all 48 figures 50–61 fps at CPU 8× (batches of ≤10). `ovl360.js b2c2` → only BUTTON false positives, 0 errors.
- **Accuracy choices worth keeping (textbook-consistent, noted where sources differ):**
  - Grasshopper = `Poekilocerus pictus`, family Pyrgomorphidae (some books Acrididae); heart "7 chambers (পাঠ্যবই)"; spiracles 10 pairs (2 thoracic + 8 abdominal), inspiration through anterior 4 pairs and expiration through posterior 6 pairs (textbook model); 6 hepatic caeca, 6 rectal pads; maxillary palp 5, labial palp 3 segments; 5–6 moults; ecdysone (prothoracic gland) vs JH (corpora allata).
  - Hydra tentacles 6–10 everywhere (labHydra caption corrected from 6–8); 4 nematocyst types; glutathione feeding response (Loomis 1955); regeneration Trembley 1744; first description Leeuwenhoek 1702; `H. oligactis` given as the dioecious exception.
  - Rohu `Labeo rohita` (Hamilton, 1822), class Actinopterygii (some books Osteichthyes); 7 fins; 4 pairs holobranch gills, 5 gill slits per side; venous heart with 2 true chambers + sinus venosus and bulbus arteriosus; countercurrent ~80% vs ≤50% concurrent; physostomous 2-chambered swim bladder, 4 Weberian ossicles; matures ~2 years, eggs hatch ~15–20 h, hatchlings on yolk 2–3 days; first induced breeding of Indian major carps 1957 (Chaudhuri & Alikunhi); Halda declared fish heritage 2020; FAO desert-locust figure ~2 g food/day.

## 2nd paper Chapter 3 (`b2c3`) figure notes — Nov 23, 2026

- **User feedback driving this chapter:** "everything looks like cartoon" — figures must look like textbook/atlas plates: realistic tissue colours, gradients, fine strokes, histology detail, mm-proportional anatomy. Keep this standard for every later chapter.
- **Anatomy library `visuals0a.js` (on `window.B23`):** `B.TS(k)` tissue tones `{lt,c,dk}` (muc, stom, int, colon, eso, mus, sub, ser, liv, gb, bile, pan, fat, art, vein, port, lym, nrv, ena, den, pulp, cem, bone, gum, tng, skin, cart, cyt, nuc, muco, zym, food, feces, air); memoised per-svg defs `B.vol` (3-stop radial), `B.lin`, `B.cyl`, `B.pat`, `B.clip`, `B.mk`; geometry `B.smooth` (Catmull-Rom), `B.dense`, `B.resample` → `[x,y,nx,ny]`, `B.ribbon`, `B.offset`; drawing `B.organ`, `B.tube` (layered strokes), `B.tx` (halo text), `B.lead`, `B.carrow`, `B.scale`; histology `B.nuc`, `B.ellD`, `B.colEpi` (batched), `B.rbc`, `B.musLayer`, `B.hexU`, `B.bead`, `B.enz`, `B.vmem`, `B.carrier`. Copy this file into later chapters (rename the namespace) rather than re-inventing.
- **Perf lessons:** SVG `<pattern>` fills under animated regions are very expensive on the Redmi profile (giWall 24 → 46 fps after fixes). Batch many cells/dots into a few `<path>` elements (`B.ellD` builds ellipse path data), clip a batched dot path instead of a pattern, draw many rings as dashed circles. All b2c3 figures 45–60 fps at CPU 8×.
- **Label rule (`BK.diagram`):** never use `an:'start'` when the anchor point is to the right of the label (the leader then runs under the text) — use `'end'` or `'middle'`. Over dark organs (liver) use plain `T` text, not white-halo text.
- **Glyphs:** no superscript/subscript digits even in captions — use `<sup>`/`<sub>` (works in captions and in `T`/`B.tx`); avoid ZWNJ (`হৃদ্‌`) — write `হৃদরোগ`.
- **Accuracy choices worth keeping:** GI mucosa ~30–40 m² (Helander & Fändriks 2014; old 200–300 m² noted); water ~9 L/day enters (2 intake + 7 secretions), SI absorbs ~7.5, colon gets ~1.5 and absorbs ~1.4, faeces ~0.1 L; cholera case in waterBalance; gastric juice 2–3 L pH 1.5–3.5; bile 0.6–1 L (no enzymes), gallbladder 30–60 mL; pancreatic juice 1.2–1.5 L pH ~8; SI duodenum 25 cm / jejunum 2.5 m / ileum 3.5 m; colon 1.5 m; liver 1.4–1.5 kg, ~75% blood via portal vein; islets 1–2% (β ~60, α ~25, δ ~10%); gastric phases 30/60/10%; enteric NS ~40–60 crore neurons; bacteria 3.8×10<sup>13</sup> vs 3.0×10<sup>13</sup> human cells (Sender, Fuchs & Milo 2016); rennin given as textbook (minor role in humans noted); textbook hormones villikinin/enterocrinin/duocrinin listed but flagged as not established; WHO Asian BMI cut-offs 23/27.5 (Lancet 2004), waist ≥90/≥80 cm; WHO obesity data updated to the 2024 fact sheet (1 in 7 people; adults 45% overweight, 16% ≈ 94 crore obese); WHO 2020 activity guidelines (60 min/day 5–17 y; 150–300 min/week adults); 7700 kcal ≈ 1 kg fat (approximate); ORS story (icddr,b, Mahalanabis 1971, Lancet 1978, BRAC lobon-gur); leptin Friedman 1994; secretin 1902, "hormone" 1905; H. pylori Nobel 2005; Leuchs 1831, Payen & Persoz 1833 (diastase), Kühne 1877 ("enzyme"); AMY1 copy number (Perry 2007).

## 2nd paper Chapter 4 (`b2c4`) figure notes — Nov 23, 2026
- **Namespaces:** `visuals0.js` = B23 helper copied as `window.B24`; `visuals0a.js` = anatomy library copied (memo key `svg._b24`, gradient id prefixes `b24v/l/c/p/k/m` so they never collide with b2c3 on the same page); `visuals0b.js` = new helpers for this chapter.
- **New helpers (`visuals0b.js`):** `B.body(g,C,cx,y0,h)` full-body silhouette; `B.rbcFace(g,x,y,r,{sx,sy,rot,tone,op})` Wright-stained biconcave RBC (shared memoised gradient); `B.plt` platelet; `B.wbc(g,x,y,r,type)` neu/eos/bas/lym/mon with granule counts scaled by size; `B.ecgV(t,{p,r,tq,st,tAmp,noP})` ECG waveform; `B.kf(K,t)` cosine keyframes; `B.along(pts)` path position; `B.heartSec(g,C,{s,ox,oy,sys,asys,av,sl,mono})` frontal-section heart built from tagged contour points (connected RA+RV and LA+LV cavities with real vessel openings, papillary muscles, chordae, AV leaflets, semilunar cusps, SVC/IVC/aorta+branches/pulmonary trunk/veins) → returns `{P,paths,V}`.
- **Visual files:** `visuals1` blood/plasma/Starling; `visuals2` RBC (Evans–Fung thickness profile), WBC, diapedesis, haematopoiesis, RBC life; `visuals3` clotting, cascade, blood groups, lymph, labs; `visuals4` heart LS/exterior/wall/valves/path (`B.drawExt` + `B.extUse` caches the exterior as `<symbol>`+`<use>` for speed); `visuals5` conduction, ECG, action potential, Wiggers cardiac cycle (HR slider), autonomic HR, Purkinje; `visuals6` BP, baroreflex, volume reflex, circulation, vessels; `visuals7` CPR, atherosclerosis, angina/MI, heart failure, pacemaker, open heart, CABG, PCI; `visuals8` mind map + 9 comparison tables.
- **Perf:** `tools/qa/perf.js` does NOT press play — seg/steps figures must be measured with acts `{key:["[data-pp]","wait:200"]}`. All b2c4 figures ≥31 fps at CPU 8× (lowest baroreflex 34, heartLS 37, heartPath 38, openHeart 39).
- **Gotchas:** every `B.seg` needs `art(){}` even if empty ("o.art is not a function"); never create `<defs>` inside the art group (RBCs rendered white) — use svg-level defs; source `.replace` chains had smuggled forbidden glyphs (², ₂, ✔, ⚠, ZWNJ, U+2060) — write plain strings.
- **Accuracy choices worth keeping:** BP categories follow ISH 2020 (normal <130/85, high-normal 130–139/85–89, grade 1 ≥140/90, grade 2 ≥160/100); textbook ideal 120/80 kept; ACC/AHA 2017 130/80 mentioned only as an alternative. Bangladesh hypertension from BDHS 2017–18 (PMC8408995): ~27.4% adults, awareness 42.4%, control 33.8%. Haematocrit men 40–50%, women 36–44%; RBC 7.8 µm; Starling +13/−7 mmHg, πc 28; lymph 2–3 L/day; cardiac cycle 0.8 s = 0.1/0.3/0.4, EDV 130, ESV 55; Purkinje 1.5–4 m/s, intrinsic 15–40/min; AV delay ~0.1 s; CPR 100–120/min, 5–6 cm, 30:2 (AHA/ERC); history dates Harvey 1628, Malpighi 1661, Landsteiner 1901/1940, Einthoven 1903, Gibbon 1953, Elmqvist & Senning 1958, Favaloro 1967, Barnard 1967, Grüntzig 1977, first coronary stent 1986; filariasis eliminated in Bangladesh (WHO validation 2023).

## 2nd paper Chapter 5 (`b2c5`) figure notes
- **Namespace:** `B25`. `visuals0/0a/0b.js` are copies of b2c4's (renamed `B24`→`B25`, `_b24`→`_b25`); new respiratory library in `visuals0c.js`: `B.headSag(g,C,o)` mid-sagittal head facing left (local 0–190 × 0–212; nasal cavity with 3 conchae, palate, tongue, adenoid, Eustachian opening, epiglottis `o.swallow`, larynx, vocal folds `o.open`, oesophagus, sinuses, hyoid; returns anchor points), `B.thorax(g,C,{insp,tree,gen,heart,pleura,tint,fiss,dia})` (local 0–200; lobes via `B.FISS`, bronchial tree clipped to `'thxLung'`, domed diaphragm), `B.btree` (cached per generation), `B.alvCluster`, `B.ribSide` (spine at back, ribs slope down to sternum), `B.gas(g,x,y,'o'|'c'|'n',r)`, `B.LUNG` colours/`B.lungG`/`B.lungPat`.
- **Visual files:** `visuals1` respSystem, nasalCavity, larynx, tracheaTS, respLevels (+ `B.breath(t)` 5 s cycle, `B.flow`); `visuals2` lungLobes, bronchialTree, alveolus, respMembrane, mucociliary; `visuals3` bellJar, limeWater, spiroLab, breathMech, pressureCurve, spirogram; `visuals4` respControl, chemoDrive, gasExchange, odc (P50 model with pH/T/BPG), co2Transport (chloride shift), o2Transport; `visuals5` hbStruct, pigments, airwayDisease, inhaler; `visuals6` sinuses, sinusitis (`faceCor`), earMiddle, otitisMedia (`earCor`); `visuals7` cxr (6 states, clipped to film frame), rescueBreath (upright sagittal airway with head-tilt rotation), ventMethods; `visuals8` mind map + 10 `cmp*` tables.
- **Gotchas:** `B.along(pts)` RETURNS A FUNCTION — call `B.along(D)(u)`. White text on coloured shapes must use `B.tx(...,{halo:<bg colour>})` (the fk-t class halo turns white text into blobs). Never put numbers-as-strings (`f1()` results) into point arrays passed to `smooth()`. Subscripts/superscripts only via `<sub>/<sup>` (aria `label` uses plain "CO2"); slider unit "বর্গমিটার" not m². "ক্ষণপৃথকস্তরী" is written without ZWNJ.
- **Perf:** all 44 figures ≥31 fps at CPU 8× with play pressed (lowest respMembrane 31, respLevels 33, larynx 36).
- **Accuracy choices worth keeping:** lung volumes TV 500, IRV 3000, ERV 1100, RV 1200, VC 4600, TLC 5800, FRC 2300, IC 3500 mL, dead space 150 mL (Guyton); PO2/PCO2 — inspired 159/0.3, alveolar 104/40, expired 120/27, venous 40/45, arterial 95/40, tissue 40/46 mmHg; CO2 carriage 70/23/7%; P50 ≈ 27 (HbF 19, Mb 2–3); Eustachian tube child ≈ 18 mm/10°, adult ≈ 36 mm/45°; rescue breathing 1 per 6 s adult, 1 per 2–3 s child (AHA 2020); Bangladesh asthma prevalence 6.9% (National Asthma Prevalence Study 1999, IJE 2002).

## 2nd paper Chapter 6 (`b2c6`) figure notes
- **Namespace `B26`.** `visuals0/0a/0b.js` are b2c5 copies (B25→B26); `visuals0a` TS0 adds kid, med, pel, uri, bld, adr colours. `visuals0c.js` is the kidney library: `B.KO`/`B.kidOut()` kidney outline (local 0–100 × 0–160, hilum right), `B.kray`, `B.PYR` (8 pyramid angles), `B.kpyr`, `B.kidneySec(g,C,{x,y,s,flip,ves,hl})` (returns anchors); `B.NEPH` nephron path (segments pct, tdl, loop, tal_thin, tal, dct, cnt, cd, aff, eff; zones y 18/192/300/420; x compressed by `B.MX`), `B.SEGC`, `B.nephronDraw(g,C,{hl,dim,bands,ves,vr,cap,zx})`; `B.corpuscle`, `B.pump`/`B.chan`/`B.carr`, `B.mol` (cloned cached template), `B.arr`, `B.tubX`, `B.tubeWall`; `B.flow` with `B.alongC` WeakMap cache.
- **`B.cacheG(g,key,fn)`** — persistent static layer per slot (slot = key minus trailing digits), inserted before g; rebuilt only when key changes; a microtask hides layers not used this frame. **Never nest cacheG** (inner layers get hidden). This is what got adhAction/urineSteps/countercurrent/raas over 30 fps at CPU 8×.
- **Visual files:** `visuals1` urinarySystem, excretoryOrgans, nitroWaste, ornithineCycle (+ `B.kidExt`); `visuals2` kidneyLS, kidneyBlood, kidneyHisto, kidneyFunctions; `visuals3` nephron (labels at LX=244 'start'), renalCorpuscle, filtrationBarrier, nephronTypes, tubuleCells (+ `B.NPATH`); `visuals4` urineSteps, gfr, pctReabs, glucoseTm, secretion, soluteFate, countercurrent, vasaRecta, osmGradient (+ `B.ION`, `B.cellBase`, `B.ride`, `B.osmCol`); `visuals5` osmoregulation, adhAction, bodyWater (renamed from waterBalance — b2c3 owns that key), aki, dialysis (+ `B.urineCol`, `B.brain`); `visuals6` renalHormones, raas, aldoCell, sodiumControl, phControl, acidBase; `visuals7` kidneyDissection (goat kidney: unipyramidal, renal crest, no calyces), urineTest, urineColor; `visuals8` b2c6map + 11 cmp tables.
- **Gotchas:** seg types hold only 3 elements — a 4th prints as a note, so keep extra data in side maps (GFD, GTD, SFD, OGD, OSD, ABD, UCC, TCC). Slider presets: set `ctx.v[k]`, `[data-sl=k].value` and `[data-slo=k]` text when `ctx.last !== ty`. Clamp `B.along(...)(u)` to `Math.min(.999,u)` (u=1 wraps). osmGradient uses straight segments (a smoothed curve dipped below 300 in the PCT — physiologically wrong).
- **Perf:** all 48 figures ≥30 fps in isolation at CPU 8× (lowest adhAction 32, raas 33, urineSteps 36, countercurrent 36). Long sequential perf runs degrade — measure low ones alone.
- **Accuracy choices worth keeping:** GFR 125 mL/min, 180 L/day, NFP 60 − 32 − 18 = 10 mmHg, Kf 12.5; urine 1–1.5 L/day, SG 1.003–1.030, pH 4.5–8, urea 20–30 g/day; glucose Tm 375 mg/min, renal threshold 180–200 mg/dL (splay); ~1 million nephrons/kidney, 85% cortical/15% juxtamedullary; kidney 11×6×3 cm, 150 g, T12–L3; RBF 1.2 L/min (20–25% of CO); medulla 300–1200 mOsm/L; Na reabsorption PCT 65 / loop 25 / DCT 5 / CD 3–4%; plasma Na 135–145 mmol/L; AKI per KDIGO; Kolff 1943, Murray 1954, Krebs–Henseleit 1932, Bowman 1842, Malpighi 1666, Henle 1862, Agre aquaporin (Nobel 2003). Bangladesh CKD prevalence not verified — deliberately not stated.

## 2nd paper Chapter 7 (`b2c7`) figure notes
- **Namespace `B27`.** `visuals0/0a/0b.js` are b2c6 copies (B26→B27); `visuals0a` TS0 adds mar, ymar, spg, peri, tnd, lig, syn, fcart, ecart, tend2. `visuals0c.js` keeps only the generic helpers from b2c6 (f1, sm, hits, alongC, cacheG, flow, pump, chan, carr, mol, arr) — its header comment still mentions the kidney.
- **`visuals0d.js` — `B.skel(g,C,{x,y,s,tint,dim,gfor,only,side,ribCol,ribG})`:** anterior adult skeleton in local units (vertex y = 0, sole ≈ 442) with shoulder ×1.22 / pelvis ×0.9 proportion transforms; returns anchors (skull … toe, joints, mirrored `…L`). check.js has no DOM, so anchors needed at module load come from `B.skel({}, {}, {..., only:['-']})` or the pure `B.skullLatA` / `B.longBoneA`.
- **Visual files:** `visuals1` skeleton, boneCount, skullLat (+`B.skullLat`), skullBones; `visuals2` axialAppend, vertebralColumn, vertebraTypes, ribCage, girdles, limbBones; `visuals3` longBone (+`B.longBoneLS`), osteon, boneCells, ossification, boneTypes; `visuals4` cartilageHisto, cartilageTypes, boneID, slideBoneCart; `visuals5` muscleTypes, muscleHierarchy, sarcomere (+`B.sarc`), crossBridge, excitation, twitchTetanus; `visuals6` antagonistic, leverClasses, leverCalc, kneeJoint, kneeMove; `visuals7` synovialJoint, jointTypes, fractureTypes, fractureHeal, fractureAid, jointInjury; `visuals8` b2c7map + 14 cmp tables (`cmpFracOpenClosed`, not `cmpOpenClosed`, which b2c2 owns).
- **Gotchas:** `Math.pow` of a negative sine gives NaN (biceps vanished) — clamp with `Math.max(0, …)`. Skeleton labels must use the non-mirrored anchors or leader lines cross the body. In a seg `anim`, labels drawn into a `B.cacheG` layer sit *under* the moving bones — keep them outside bone areas (jointTypes puts the bone names below the figure).
- **Perf:** perf.js needs `[data-pp]` to press play on seg/steps. Bengali labels redrawn per frame cost most: crossBridge 25 → 34, ossification 29 → 40, jointTypes 26 → 37 after moving labels (and the actin row, translated as one layer) into `B.cacheG`. All figures ≥31 fps at CPU 8× in isolation (lowest skeleton 31–34, crossBridge 34).
- **Accuracy choices worth keeping:** 206 bones (axial 80 + appendicular 126; skull 22, vertebrae 26, 12 pairs of ribs, 30 per limb); pubic angle male 50–70°, female 80–90° or more; sarcomere ≈ 2.3 µm at rest, A band constant during contraction; power stroke ≈ 10 nm per ATP; patella's lever effect described qualitatively (no percentage); RICE (Mirkin 1978).

## 2nd paper Chapter 8 (`b2c8`) figure notes
- **Namespace `B28`.** `visuals0/0a/0b/0c.js` copied from b2c7 (B27→B28). The svg id prefixes (`b28p`, `b28k`, `b28m` …) and memo keys (`_b28`, `_b28s`, `_b28c`) were renamed too, because b2c6/b2c7 share `b26*` ids and two chapters on one page would point at each other's gradients. `visuals0a` TS0 adds gm, wm, csf, dura, myel, axn, scl, cho, ret, iris, lens, vit, cor, endo, thy, coll, adc, adm, isl, perl, nucP (pale neuron nucleus).
- **Visual files:**
  - `visuals1`: nervousSystem, neuron, neuronTypes, restingPot, actionPot (`apV(t)` gives the potential in mV over 0–5 ms), impulseCond, synapse, spinalCord, reflexArc. Helpers: `B.taper`, `B.cordTS`, and the pure `B.cordTSA` for anchors.
  - `visuals2`: brainLat, brainSag, brainParts, cortexMap, meninges. Helpers: `B.brainLatDraw` and `B.brainSagDraw`. Diagrams are drawn in a scaled inner `<g>` (`LTR`/`STR`) that sits inside each part group, with anchors mapped by `SL()`/`SS2()`; `hits()` stays on the unscaled part group.
  - `visuals3`: cranialNerves, cranialType, ans. Helper: `B.cnDraw`, the inferior view of the brain.
  - `visuals4`: eyeSection, retina, accommodation, pupil, eyeDefects. Helpers: `B.eyeH` and the pure `B.eyeA`.
    - Eye scale is 1 mm = 8 units: axial length about 24 mm, corneal radius 63.6.
    - The ray model uses v(mm) = 1336 ÷ power, principal plane x = −96, retina x = −60 + 142 × axial.
  - `visuals5`: earSection, cochleaTS, organCorti, hearing, cochleaFreq (Greenwood map `placeOf(f)`), balance.
  - `visuals6`: endocrineMap, hormoneMech, feedback, pituitary, pitHormones, thyroid, calcium. Helper: `B.endoShapes` (thyroidD, kidD, adrD).
  - `visuals7`: adrenal, islets, glucoseCtrl, gonads, hormoneDisorders (body silhouettes from `B.bodyPts`), hormoneMisuse.
  - `visuals8`: b2c8map plus 17 cmp tables. The gland table is `cmpGlandType`, because `cmpExoEndo` is already used by another chapter.
- **Gotchas:**
  - `B.nuc(g,x,y,rx,ry,angle,o)` takes the angle before the options object.
  - `tools/xmbal.js` only rebalances `xm:` arrays that sit on one line, so multi-line `xm` must be joined first. The join script is in the session log: bracket-match the array, then collapse the newlines.
  - Labels drawn into a `B.cacheG` layer sit under the art; keep them clear of filled shapes.
- **Perf:** all 59 figures ≥32 fps at CPU 8× with play pressed (lowest reflexArc 32–35, actionPot 34, synapse 34–35). Bengali stage labels are cached per stage (`apl`+s, `syl`+s, `rxl`+s, …).
- **Accuracy choices worth keeping:**
  - Neuron physiology: resting −70 mV, threshold −55, peak +30 to +40, after-hyperpolarisation −80; pump 3 Na<sup>+</sup> : 2 K<sup>+</sup>; synaptic cleft about 20 nm, delay about 0.5 ms; conduction up to about 120 m/s myelinated, 0.5–2 m/s unmyelinated.
  - Cranial nerves 3 sensory + 5 motor + 4 mixed.
  - Eye: rods about 12 crore, cones about 60 lakh; cornea about 40 D of the eye's about 60 D; near point 25 cm.
  - Ear: hearing 20–20000 Hz; ossicle gain about 20× (area 17 × lever 1.3); IHC about 3500, OHC about 12000.
  - Glucose: fasting 70–100 mg/dL; diabetes fasting ≥126 or 2 h ≥200 (7.0 / 11.1 mmol/L), HbA1c ≥6.5%; renal threshold about 180.
  - Islet cells: β 65–80%, α 15–20%, δ 5–10%.
  - Bangladesh: iodised salt law 1989 (now Iodized Salt Act 2021); Fish Feed and Animal Feed Act 2010 bans hormones in feed.

## 2nd paper Chapter 9 (`b2c9`) figure notes
- Namespace `B29` (visuals0/0a/0b/0c copied from b2c8 with ids renamed `b29*`); new TS tones in `visuals0a.js`: tes, tun, glnd, ut, endm, ova, amn, plac, fet, ecto, meso, endo3. Patterns available in `B.pat`: line, cross, dot, fat, wave, hex (no 'fib'/'dots').
- `visuals1.js` — maleRepro, testisTS, sperm, maleHormone, femaleRepro, femaleHormone (`B.rib` ribbon helper).
- `visuals2.js` — menstrualCycle (seg + day slider; curves from Gaussian sums `HF`, endometrium `ENDO(d)` in mm; all day-dependent drawing in `art`, `anim` only a pulsing ring), pubertyTimeline, spermatogenesis / oogenesis (steps; `cell()`/`chrom()` draw 2n = 4 with homolog colours), ovaryLS (diagram, clockwise follicle cycle), fertilization (steps; corona/zona/static sperm cached, only one active sperm animated — moving many sperm across the whole SVG forced full repaints and dropped to 23 fps), implantation.
- `visuals3.js` — `B.fetus(g,x,y,s,rot,{hp,cord})` curled fetus (head proportion `hp`; template memoised per svg+options and cloned — cheap to call per frame), germFate, fetalMembranes, placenta, fetalGrowth (perinatology.com length/weight table `FG`), fundalHeight (torso landmarks `LM`, `fundY(week)`), labour (scene function `LBS`; stages 0–1 cached by quantised dilation and pulse, stages 2–3 dynamic).
- `visuals4.js` — `B.femT(g,tx,ty,s,{pcos})` small frontal female tract returning a coordinate mapper `m(x,y)`; contraception (site-of-action seg), contraEffect (custom log bar chart, CDC typical-use %), ivf (steps), infertility, fetalProblems (teratogen critical-period chart, karyotype, Rh, ectopic).
- `visuals5.js` — syphilis (dark-field spirochetes + body stages), gonorrhea (Gram-stain diagram), hivStructure, hivCycle, hivCourse (CD4/viral load; ART variant). `visuals6.js` — b2c9map + 16 cmp tables; `visuals7.js` — hpgAxis (HPG axis hormone levels per disorder), stdSpread, cmpInfertMF.
- Perf at CPU 8×: all ≥ 30 fps (lowest labour 35 after caching, fetalGrowth 35, hivStructure 34, fertilization 34). Lesson ids follow the placeholder TOC exactly (s3a–s3k).


## 2nd paper Chapter 10 (`b2c10`) figure notes
- Namespace `B210` (visuals0/0a/0b/0c copied from b2c9). **Important fix in this chapter's copy:** `B.cacheG` layers created inside a `B.seg` `art()` call used to be hidden on the first animation frame (the per-microtask "unused layer" sweep). `B210.seg.redraw` now sets `svg._artU`, `cacheG` marks such layers `_keep` and the sweep never hides them; stale keep-layers from a previous redraw are hidden. Copy both edits (visuals0.js `redraw`, visuals0c.js `cacheG`) into the next chapter's helpers. Also seg `types` arrays must have ≤ 3 entries for the info box (a 4th entry is printed as a "more" line) — slice extra data off with `Object.fromEntries(Object.entries(X).map(([k, v]) => [k, v.slice(0, 3)]))`.
- `visuals1.js` — `B.bact`, `B.cocc`, `B.virus`, `B.macro` (all coerce x,y with `+`); defenceLayers, barrierMap, skinBarrier, mucusEscalator, gutDefence. `visuals2.js` — leukocytes, phagocytosis, inflammation, fever, complement, innateCells. `visuals3.js` — `B.abY`, `B.bcell`, `B.tcell`, `B.plasma`; lymphOrgans, lymphNodeImm (keys differ from b2c4's lymphSystem/lymphNode), antigenPresent, clonalSelection, humoralImmunity, cellImmunity.
- `visuals4.js` — `B.Yab` (small Y with light chains + orange V tips), `B.igG(g,x,y,s)` full domain-level IgG (arms drawn in a rotated local frame; `AW()` maps local→world for hit anchors); antibodyStructure, epitope (`abOn` places an arm tip exactly on an epitope), antibodyClasses, antibodyAction (C1q bouquet on Fc).
- `visuals5.js` — vaccineTypes, vaccineHow, herdImmunity (deterministic BFS outbreak on a 16×9 grid, quantised per step into one cached layer), epiSchedule (Bangladesh EPI, diagram rows), vaccineTimeline (ordinal, not proportional). `visuals6.js` — immuneResponse (log-scale primary/secondary, cursor quantised to 0.5 day), memoryCells, immunityKinds (2×2 matrix), allergy. `visuals7.js` — b2c10map + 11 cmp.
- Perf at CPU 8×: all ≥ 49 fps.


## 2nd paper Chapter 11 (`b2c11`) figure notes

- Helper namespace `B211` (visuals0/0a/0b/0c copied from b2c10 including the cacheG `_keep` fix; TS0 adds pea/flower/chromosome tones).
- visuals1: pea helpers `peaSeed`, `peaFlower`, `peaPod`, `peaPlant`, `chrom`, `gam`, `gt`, `punnett`; figures mendelTraits (Mendel's real F2 counts), alleleLocus, monohybrid, punnettMono, testCross.
- visuals2: dihybrid, dihybridGrid, chromTheory, incompleteDom (`B.mirabilis`), codominance (roan hairs / AB RBC).
- visuals3: lethalGene (yellow mouse, aurea), complementGene (9 : 7), epistasis (squash 12 : 3 : 1, mouse 9 : 3 : 4), polygenic (wheat).
- visuals4: karyotype (ISCN-approx lengths), sexDetermXY (SRY), sexDetermXO, colorBlindCross, colorVision (cone curves, dot plate, swatch simulation — swatches x 10 + i·38 so the right labels at x 352 do not overlap), hemophilia, dmdMuscle.
- visuals5: aboAntigen, aboCross, transfusionChart, bloodTypeSlide, rhPregnancy (anti-D at 28 weeks and within 72 h).
- visuals6/7: geoTime, lamarckGiraffe, naturalSelection, pepperedMoth, evoForces, speciation, homologousLimbs, analogousOrgans, vestigialHuman (on `B.body`), horseEvolution (scale bar vs 1.7 m human), archaeopteryx, darwinFinches.
- visuals8: b2c11map + 16 cmp figures.
- Perf at CPU 8×: all animated figures ≥ 37 fps (chromTheory slowest).

## 2nd paper Chapter 12 (`b2c12`) figure notes
- Helper namespace `B212` (visuals0/0a/0b/0c copied from b2c11). TS0 adds animal tones (fur, fthr, goose, beak, egg, silk, spdr, beeY/beeB, wing, wax, honey, fish, toad, wtr, soil, grass, wood, metal, shell, snail, tit, ttY).
- Perf fix worth reusing: `B.tx` in `visuals0a.js` no longer goes through `BK.T` — it caches `FK.P()` (invalidated by a MutationObserver on `<html>` attributes + the dark-mode media query) and uses `textContent` for plain strings. Calling `FK.P()` (→ `getComputedStyle`) for every label inside a per-frame redraw forced a style recalc per label and cost ~10 ms/frame at CPU 8×.
- BK.steps redraws the whole `g` every frame, so heavy animals and per-stage captions live in `B.cacheG` layers keyed by state (`'bltoad'+eye`, `'ergoose'+quantised head pose`, `'rxleg'+pose`, `'owdone'+stage`, `'ikcap'+stage` …). Layers stack in first-call order beneath `g`, so call them in back-to-front order. `B.spider` draws legs as one path + joints as one path and reuses the body through `<defs>` + `<use>`. Result at CPU 8×: every animated figure ≥ 30 fps (lowest eggRolling/kneeJerk/imprinting 33–34).
- visuals1 toad (+`B.toadTongue`), stickleback; visuals2 bees/comb, lovebird; visuals3 goose, gull, taxis, kinesis sim; visuals4 spinal cord, knee-jerk, withdrawal arc, weaver nest, cuckoo; visuals5 isolation test, migration cycle, flyway map (equirectangular, straight-segment land), Emlen funnel; visuals6 spider, orb web, parental care, offspring-care log bars; visuals7 imprinting, Hess curve, Köhler, snail habituation, tits, song sonograms; visuals8 Pavlov rig, conditioning steps/curve, salivary reflex, Skinner box; visuals9 pecking order, social types, bee castes (to scale, 5 mm bar), development, worker duties, waggle dance (sliders); visuals10 actogram, rhythm types, `b2c12map`, 10 cmp figures.
- Key renamed `reflexArc` → `kneeJerk` (global clash). Section ids/titles follow the placeholder TOC; `s3h` (জৈবিক ছন্দ, `no: ''`) added because the TOC lists it as a sub-topic of §১২.৬.

## 1st paper Chapter 0 (`b1c0`) figure notes
- Helper namespace `B100` (visuals0a–0d are b2c12's visuals0/0a/0b/0c copied with B212→B100 and svg id prefixes `b212*`→`b100*`). The pre-existing `visuals0.js` (`taxRank` ladder, `fiveK` tree) is kept. TS0 adds plant/microbe tones: cwall, pcyt, chlo, vac, mito, starch, bark, mstd, frond, moss, algaG, cone, rice, mango, lily, pad, mush, gill, arch, prot.
- visuals1: plant-cell traits diagram, plant groups (merged-path `B.spirogyra`, `B.moss`, `B.fern`, `B.cycas`, `B.mustard`), taxonomy pillars cycle, grouping steps; small reusable icons via `B.ICD` + `B.icon(g,k,x,y,s)` (defs + `<use>`). visuals2: rank nest, species test (horse/donkey/mule via `B.equid`), binomial anatomy (`B.mangoTwig`), common names (`B.jackTree`). visuals3: art/nat/phylo cladograms, habit forms with a person for scale. visuals4: Linnaeus classes (stamen arrangements), Linnaeus works timeline. visuals5: B&H chart, corolla types, ovary position (thalamus/disc/cup), dicot vs monocot. visuals6: kingdom timeline (steps), five-kingdom chart, kingdom cards (`B.bacterium`, `B.nostoc`, `B.chlamy`, `B.amoeba`, `B.mushroom`, `B.fishSide`), prokaryote/eukaryote cell diagram, three domains, six kingdoms. visuals7: `b1c0map` + 10 cmp figures.
- `core/bk.js`: the BK.cycle "+ সবুজ / লাল" in/out legend is now drawn only when some node has `io` entries.
- Perf lesson worth reusing: creating new `<use>` elements inside a per-frame BK.steps redraw is very slow (each new use builds a shadow tree + style recalc). Keep persistent `<use>`/text nodes in a `B.cacheG` layer and only update their attributes each frame (`groupingSteps` 13 → 33 fps at CPU 8×; `kingdomTimeline` 28 → 41 fps with cached box layers keyed by stage).
- Facts checked: B&H Genera Plantarum 1862–1883, 202 families = 165 (84 = 34 + 23 + 27; 45 = 9 + 12 + 24; 36 in 8 series) + 3 + 34 (7 series), ~7,569 genera, ~97,205 species; Species Plantarum 1 May 1753, ~1,000 genera, 5,940 species; kingdom history 1735 / 1866 / 1938 / 1969 / 1977 / 1990 / 1998 / 2015; Margulis & Schwartz 1982. Hydrilla (ঝাঁঝি) is Microspermae (Hydrocharideae) in B&H, so Apocarpae examples are Sagittaria / Potamogeton.
