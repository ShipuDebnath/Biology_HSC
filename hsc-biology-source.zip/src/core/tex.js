/* ═══════════════════════════════════════════════════════════════════
   CORE · TX — বৈজ্ঞানিক টাইপসেটিং (KaTeX + mhchem)
   লেখায় সরাসরি ব্যবহার:
     {ce|2H2 + O2 -> 2H2O}        রাসায়নিক সমীকরণ (লাইনের ভেতরে)
     {m|k = A e^{-E_a/RT}}         গাণিতিক সূত্র (TeX, লাইনের ভেতরে)
     {CE|…} / {M|…}                আলাদা লাইনে, মাঝখানে বড় করে
   <div class="eq">…</div> এর প্রতিটি লাইন (<br> দিয়ে আলাদা) স্বয়ংক্রিয়ভাবে
   TeX এ রূপান্তরিত হয় — আগে TEXMAP (হাতে যাচাই করা) দেখা হয়, না থাকলে
   নিচের রূপান্তরক। লেখার ভেতরের তীরচিহ্নসহ সমীকরণও (A + B → C) রূপান্তরিত হয়।
   ═══════════════════════════════════════════════════════════════════ */
(function () {
'use strict';
const TX = window.TX = window.TX || {};
const SUBD = '₀₁₂₃₄₅₆₇₈₉', SUPD = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const SUBX = { 'ₙ': 'n', 'ₓ': 'x', 'ₐ': 'a', 'ₑ': 'e', 'ₒ': 'o', 'ₘ': 'm', 'ₚ': 'p', 'ₖ': 'k', 'ₜ': 't', 'ᵢ': 'i', 'ⱼ': 'j', '₊': '+', '₋': '-' };
const SUPX = { '⁺': '+', '⁻': '-', 'ⁿ': 'n', 'ˣ': 'x', 'ʸ': 'y', '⁽': '(', '⁾': ')', 'ᵃ': 'a', 'ᵇ': 'b', '˙': '\\cdot' };
const BN = /[\u0980-\u09FF]/;
const BNRUN = /[\u0980-\u09FF][\u0980-\u09FF\s\-–,।:'’]*[\u0980-\u09FF:।]?/g;
const GREEK = { 'α': '\\alpha', 'β': '\\beta', 'γ': '\\gamma', 'δ': '\\delta', 'ε': '\\varepsilon', 'θ': '\\theta', 'λ': '\\lambda', 'μ': '\\mu', 'ν': '\\nu', 'π': '\\pi', 'ρ': '\\rho', 'σ': '\\sigma', 'τ': '\\tau', 'φ': '\\phi', 'χ': '\\chi', 'ψ': '\\psi', 'ω': '\\omega', 'Δ': '\\Delta', 'Σ': '\\Sigma', 'Ω': '\\Omega', 'Λ': '\\Lambda', 'Φ': '\\Phi', 'Ψ': '\\Psi' };
const SYM = { '×': '\\times ', '·': '\\cdot ', '−': '-', '–': '-', '≈': '\\approx ', '≥': '\\geq ', '≤': '\\leq ', '≠': '\\neq ', '∝': '\\propto ', '⇒': '\\Rightarrow ', '→': '\\rightarrow ', '⇌': '\\rightleftharpoons ', '∞': '\\infty ', '°': '^{\\circ}', '…': '\\ldots ', '±': '\\pm ', '∴': '\\therefore ', '≡': '\\equiv ', '⟶': '\\longrightarrow ', '∑': '\\sum ', '‰': '\\text{‰}', '%': '\\%', '&': '\\&', '#': '\\#' };
const UNITS = ['kJ', 'J', 'mol', 'L', 'mL', 's', 'min', 'h', 'atm', 'Pa', 'kPa', 'bar', 'g', 'kg', 'mg', 'K', 'M', 'pm', 'nm', 'cm', 'm', 'eV', 'D', 'Hz', 'ppm', 'ppb', 'mmHg', 'Torr', 'cal', 'kcal', 'dm'];
const SPECIAL = { 'Ea': 'E_a', 'Kc': 'K_c', 'Kp': 'K_p', 'Ka': 'K_a', 'Kb': 'K_b', 'Kw': 'K_w', 'Ksp': 'K_{sp}', 'Qc': 'Q_c', 'Kh': 'K_h', 'Kf': 'K_f', 'Kd': 'K_d', 'pH': '\\mathrm{pH}', 'pOH': '\\mathrm{pOH}', 'pKa': '\\mathrm{p}K_a', 'pKb': '\\mathrm{p}K_b', 'pKw': '\\mathrm{p}K_w', 'IE': '\\mathrm{IE}', 'EA': '\\mathrm{EA}', 'EN': '\\mathrm{EN}', 'KE': '\\mathrm{KE}', 'PE': '\\mathrm{PE}', 'AE': '\\mathrm{AE}', 'Rf': 'R_f', 'ppm': '\\mathrm{ppm}', 'ppb': '\\mathrm{ppb}', 'log': '\\log ', 'ln': '\\ln ', 'exp': '\\exp ', 'cos': '\\cos ', 'sin': '\\sin ', 'tan': '\\tan ', 'mol': '\\mathrm{mol}' };

/* HTML (sub/sup/entities) → plain text with TeX sub/sup markers */
function htmlPrep(h) {
  return String(h)
    .replace(/<sub>(.*?)<\/sub>/g, (_, x) => '_{' + x + '}').replace(/<sup>(.*?)<\/sup>/g, (_, x) => '^{' + x + '}')
    .replace(/<\/?(b|i|strong|em|span)[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/\u00a0/g, ' ');
}
const hasTags = h => /<(?!\/?(sub|sup|b|i|strong|em|span)\b)[a-z]/i.test(h);

/* unicode sub/superscript runs → _{..} / ^{..} */
function scripts(s, chem) {
  s = s.replace(/[₀-₉ₙₓₐₑₒₘₚₖₜᵢⱼ₊₋]+/g, r => { const v = [...r].map(c => SUBD.includes(c) ? SUBD.indexOf(c) : SUBX[c]).join(''); return chem && /^\d+$/.test(v) ? v : '_{' + v + '}'; });
  s = s.replace(/[⁰-⁹⁺⁻ⁿˣʸ⁽⁾ᵃᵇ¹²³]+/g, r => '^{' + [...r].map(c => SUPD.includes(c) ? SUPD.indexOf(c) : c === '¹' ? 1 : c === '²' ? 2 : c === '³' ? 3 : SUPX[c]).join('') + '}');
  return s;
}
const textWrap = s => s.replace(BNRUN, m => { const t = m.replace(/\s+$/, ''), tail = m.slice(t.length); return '\\text{' + t + '}' + (tail ? '\\ ' : ''); });

/* ---------- chemistry segment → \ce{…} ---------- */
const ARROW = /(→|⟶|⇌|⇄|←|⇋|⟵)/;
function chemSeg(s) {
  let pre = '';
  const lab = /^([^A-Za-z0-9\[(]*?[\u0980-\u09FF][^:]*:)\s*/.exec(s); if (lab) { pre = '\\text{' + lab[1].trim() + '}\\ '; s = s.slice(lab[0].length); }
  let post = '';
  const tr = /\s*\(([^()]*[\u0980-\u09FF][^()]*)\)\s*$/.exec(s); if (tr && !/\((s|l|g|aq)\b/.test(tr[0])) { post = '\\quad\\text{(' + tr[1].trim() + ')}'; s = s.slice(0, tr.index); }
  s = s.replace(/(→|⟶|⇌)\s*\(([^()]*(?:\([^()]*\)[^()]*)*)\)/g, (_, a, c) => (a === '⇌' ? '<=>' : '->') + '[' + c.replace(BNRUN, m => '\\text{' + m.trim() + '}').replace(/Δ/g, '\\Delta ').replace(/°/g, '^\\circ ') + ']');
  s = s.replace(/⇌|⇄|⇋/g, '<=>').replace(/→|⟶/g, '->').replace(/←|⟵/g, '<-');
  s = s.replace(/↑/g, ' ^').replace(/↓/g, ' v').replace(/·/g, '*').replace(/[−–]/g, '-').replace(/≡/g, '#').replace(/e⁻/g, 'e-');
  s = s.replace(/\(([slg]|aq),\s*([^()]*[\u0980-\u09FF][^()]*)\)/g, (_, st, lb) => '(' + st + ', \\text{' + lb.trim() + '})');
  s = s.replace(/Δ/g, '\\Delta ');
  s = scripts(s, true);
  s = s.replace(BNRUN, m => '\\text{' + m.trim() + '} ');
  return pre + '\\ce{' + s.trim() + '}' + post;
}
/* ---------- math segment → TeX ---------- */
function group(s, i, open, close) { let d = 0; for (let j = i; j < s.length; j++) { if (s[j] === open) d++; else if (s[j] === close) { d--; if (!d) return j; } } return -1; }
function fracs(s) {
  const G = 'alpha|beta|gamma|delta|varepsilon|theta|lambda|mu|nu|pi|rho|sigma|tau|phi|chi|psi|omega|Delta|Sigma|Omega|Lambda|Phi|Psi|infty';
  const unit = '(?:\\\\(?:' + G + ')(?![a-zA-Z])\\s?|\\\\(?:bar|ce|mathrm|tfrac)\\{[^{}]*\\}(?:\\{[^{}]*\\})?|[A-Za-z0-9.]|_\\{[^{}]*\\}|\\^\\{(?:[^{}]|\\{[^{}]*\\})*\\}|\\^\\\\circ)';
  const tok = '(?:\\\\text\\{[^{}]*\\}|' + unit + '+)';
  for (let guard = 0; guard < 16; guard++) {
    const i = s.indexOf('/'); if (i < 0) break;
    let L, R, a, b, il = i, ir = i + 1;
    while (il > 0 && s[il - 1] === ' ') il--;
    while (s[ir] === ' ') ir++;
    if (s[il - 1] === ')') { let d = 0, j = il - 1; for (; j >= 0; j--) { if (s[j] === ')') d++; else if (s[j] === '(') { d--; if (!d) break; } } if (j < 0) break; a = j; L = s.slice(j + 1, il - 1); if (/\\(log|ln|sqrt|exp|sin|cos)\s*$/.test(s.slice(0, j))) { const mm = /\\(log|ln|sqrt|exp|sin|cos)\s*$/.exec(s.slice(0, j)); a = j - mm[0].length; L = s.slice(a, il); } }
    else { const m = new RegExp('(' + tok + ')$').exec(s.slice(0, il)); if (!m) { s = s.slice(0, i) + '∕' + s.slice(i + 1); continue; } a = il - m[1].length; L = m[1]; }
    if (s[ir] === '(') { const j = group(s, ir, '(', ')'); if (j < 0) break; b = j + 1; R = s.slice(ir + 1, j); }
    else { const m = new RegExp('^(' + tok + ')').exec(s.slice(ir)); if (!m) { s = s.slice(0, i) + '∕' + s.slice(i + 1); continue; } b = ir + m[1].length; R = m[1]; }
    s = s.slice(0, a) + '\\frac{' + L.trim() + '}{' + R.trim() + '}' + s.slice(b);
  }
  return s.replace(/∕/g, '/');
}
function mathSeg(s) {
  // chemical species inside [ ] → \ce
  s = s.replace(/\[([A-Z][A-Za-z0-9₀-₉⁰-⁹⁺⁻()]*?)\]/g, (m, x) => (/^[A-Z]$/.test(x) ? '[' + x + ']' : '[\\ce{' + scripts(x, true).replace(/−/g, '-') + '}]'));
  // standalone formulas like H₂O, CaCO₃ (≥2 capitals or capital+digit subscript), not already in \ce
  s = s.replace(/(^|[^\\A-Za-z{])((?:[A-Z][a-z]?[₀-₉]*){2,}(?:[⁰-⁹]*[⁺⁻])?|[A-Z][a-z]?[₀-₉]+(?:[⁰-⁹]*[⁺⁻])?)(?![A-Za-z_{])/g, (m, p, x) => SPECIAL[x] || /^(KE|PE|IE|EA|EN|AE|LCAO|VSEPR|NMR|IR|UV|ppm|ppb|STP|NTP)$/.test(x) ? m : p + '\\ce{' + scripts(x, true) + '}');
  s = s.replace(/\^\(/g, '^{(');
  // ^( … ) with balanced parens → ^{…}
  for (let k = s.indexOf('^{('); k >= 0; k = s.indexOf('^{(', k + 1)) { const j = group(s, k + 2, '(', ')'); if (j < 0) break; s = s.slice(0, k) + '^{' + s.slice(k + 3, j) + '}' + s.slice(j + 1); }
  s = s.replace(/([A-Za-zνλα-ω])\u0304/g, (m, c) => '\\bar{' + (GREEK[c] || c) + '}').replace(/½/g, '\\tfrac{1}{2}').replace(/⅓/g, '\\tfrac{1}{3}').replace(/¼/g, '\\tfrac{1}{4}').replace(/≫/g, '\\gg ').replace(/≪/g, '\\ll ');
  s = s.replace(/√\[([^\]]*)\]/g, '\\sqrt{$1}').replace(/√\(([^()]*)\)/g, '\\sqrt{$1}').replace(/√([A-Za-zνλ0-9]+)/g, '\\sqrt{$1}');
  s = scripts(s, false);
  s = s.replace(/\b(Ksp|Kc|Kp|Ka|Kb|Kw|Kh|Qc|Ea|pKa|pKb|pKw|pOH|pH|log|ln|exp|cos|sin|tan|Rf)\b/g, (m) => SPECIAL[m]);
  s = s.replace(/[αβγδεθλμνπρστφχψωΔΣΩΛΦΨ]/g, c => GREEK[c] + ' ');
  s = s.replace(/[×·−–≈≥≤≠∝⇒→⇌∞°…±∴≡⟶∑‰%&#]/g, c => SYM[c]);
  // units after a number: 13.6 eV, 96.49 kJ mol^{-1}
  const U = UNITS.join('|');
  s = s.replace(new RegExp('(\\d)\\s+((?:(?:' + U + ')(?:\\^\\{-?\\d\\})?\\s*)+)(?![A-Za-z])', 'g'), (m, d, u) => d + '\\,\\mathrm{' + u.trim().replace(/\s+/g, '\\,') + '}');
  s = s.replace(new RegExp('([)}])\\s+((?:(?:' + U + ')(?:\\^\\{-?\\d\\})?\\s*)+)(?=$|[\\s=;,)])', 'g'), (m, d, u) => d + '\\,\\mathrm{' + u.trim().replace(/\s+/g, '\\,') + '}');
  s = s.replace(/_\{([A-Za-z]{2,})\}/g, (m, x) => '_{\\mathrm{' + x + '}}');
  s = s.replace(/(^|[^\\A-Za-z])(KE|PE|IE|EA|EN|AE|amu|STP|NTP)(?![A-Za-z])/g, (m, p, x) => p + '\\mathrm{' + x + '}');
  s = s.replace(/⟹/g, '\\Longrightarrow ').replace(/Å/g, '\\,\\text{Å}');
  s = textWrap(s);
  s = fracs(s);
  s = s.replace(/;\s*/g, ';\\quad ');
  return s;
}
TX.lineToTex = function (html) {
  if (hasTags(html)) return null;
  let s = htmlPrep(html).trim(); if (!s) return null;
  if (!/[=→⟶⇌⇄←<>≈∝≥≤]/.test(s)) return null;
  const segs = s.split(/;\s+/);
  const out = segs.map(seg => ARROW.test(seg) && /[A-Z]/.test(seg) && !/^[\u0980-\u09FF\s]*[a-zA-Zα-ωΔ]*\s*[=≥≤]/.test(seg) && !/[≥≤]/.test(seg) ? chemSeg(seg) : mathSeg(seg));
  return out.join(';\\quad ');
};
TX.chemToTex = chemSeg;
TX.mathToTex = mathSeg;

/* ---------- rendering ---------- */
const OPT = { throwOnError: true, strict: 'ignore', output: 'htmlAndMathml', trust: false };
TX.render = (tex, display) => { if (!window.katex) return null; try { return window.katex.renderToString(tex, Object.assign({ displayMode: !!display }, OPT)); } catch (e) { TX.errors = TX.errors || []; TX.errors.push([tex, e.message]); return null; } };
const MAP = () => window.TEXMAP || {};
/* split a long TeX line at top-level ";\quad" (separate formulas) and "\qquad(" (annotation) so it stacks on phones */
function splitTop(tex) {
  const out = []; let d = 0, last = 0;
  const push = (end, note) => { const t = tex.slice(last, end).trim(); if (t) out.push([t, note]); };
  let note = false;
  for (let i = 0; i < tex.length; i++) {
    const c = tex[i];
    if (c === '{') d++; else if (c === '}') d--;
    else if (d === 0 && tex.startsWith(';\\quad', i)) { push(i + 1, note); note = false; last = i + 6; i += 5; }
    else if (d === 0 && tex.startsWith('\\qquad(', i) && i > 0) { push(i, note); note = true; i += 6; last = i; }
  }
  push(tex.length, note);
  return out.length ? out : [[tex, false]];
}
function eqBlock(el) {
  if (el.dataset.tx) return; el.dataset.tx = '1';
  const parts = el.innerHTML.split(/<br\s*\/?>/i);
  let any = false;
  const out = parts.map(p => {
    const key = p.trim(); if (!key) return p;
    const whole = /^\{m\|([\s\S]*)\}$/.exec(key);
    if (whole && !/\{(ce|m|CE|M)\|/.test(whole[1])) {
      const tex = whole[1].replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
      const rs = splitTop(tex).map(([t, note]) => [TX.render(t, false), note]);
      if (!rs.some(x => !x[0])) { any = true; return rs.map(([r, note]) => `<span class="txl${note ? ' txn' : ''}">${r}</span>`).join('<br>'); }
    }
    if (/\{(ce|m|CE|M)\|/.test(key)) { any = true; return `<span class="txl">${inlineMarks(key)}</span>`; }
    const nk = window.TEXNORM ? window.TEXNORM(key) : key, tex = MAP()[nk] != null ? MAP()[nk] : TX.lineToTex(key);
    if (!tex) return p;
    const parts2 = splitTop(tex), rs = parts2.map(([t, note]) => [TX.render(t, false), note]);
    if (rs.some(x => !x[0])) return p;
    any = true; return rs.map(([r, note]) => `<span class="txl${note ? ' txn' : ''}">${r}</span>`).join('<br>');
  });
  if (any) { el.innerHTML = out.join('<br>'); el.classList.add('tx'); }
}
let NEST = '[^{}]*'; for (let i = 0; i < 5; i++) NEST = '(?:[^{}]|\\{' + NEST + '\\})*';
const MARK = new RegExp('\\{(ce|m|CE|M)\\|(' + NEST + ')\\}', 'g');
TX.MARK = MARK;
function inlineMarks(h) {
  return h.replace(MARK, (m, k, body) => {
    const raw = body.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
    const tex = k.toLowerCase() === 'ce' ? '\\ce{' + raw + '}' : raw;
    const r = TX.render(tex, k === 'CE' || k === 'M'); return r ? (k === 'CE' || k === 'M' ? `<span class="txd">${r}</span>` : r) : m;
  });
}
TX.inline = inlineMarks;
/* inline reaction in running text: "Zn + CuSO₄ → ZnSO₄ + Cu" */
const F = "(?:\\d+\\s?|n)?(?:\\[[^\\]\\s]+\\][⁰-⁹⁺⁻]*|\\([A-Za-z0-9₀-₉–\\-]+\\)[₀-₉ₙ]*[A-Za-z0-9₀-₉⁰-⁹⁺⁻()·=≡–]*|[A-Z][A-Za-z0-9₀-₉⁰-⁹⁺⁻()·=≡–]*|e⁻)(?:\\((?:s|l|g|aq)\\))?[↑↓]?(?:\\s?\\([\\u0980-\\u09FF][\\u0980-\\u09FF\\s]*\\))?";
const SIDE = F + "(?:\\s*\\+\\s*" + F + ")*";
const INL = new RegExp("(" + SIDE + ")\\s*(→|⇌|⟶)(\\([^()]{1,24}\\))?\\s*(" + SIDE + ")", 'g');
/* typeset an inline reaction term by term so it can wrap between terms on narrow screens */
function inlineChem(m) {
  const toks = m.trim().split(/(\s*\+\s*|\s*(?:→|⇌|⟶)(?:\([^()]*\))?\s*)/).filter(t => t !== '');
  const out = [];
  for (const t of toks) {
    const tt = t.trim(); let r;
    if (tt === '+') r = TX.render('+', false);
    else if (/^(→|⇌|⟶)/.test(tt)) { const c = /\(([^()]*)\)/.exec(tt); const lab = c ? c[1].replace(BNRUN, x => '\\text{' + x.trim() + '}').replace(/Δ/g, '\\Delta ') : ''; const isEq = tt[0] === '⇌'; r = TX.render(isEq ? (lab ? '\\xrightleftharpoons{' + lab + '}' : '\\rightleftharpoons') : (lab ? '\\xrightarrow{' + lab + '}' : '\\longrightarrow'), false); }
    else r = TX.render(chemSeg(tt), false);
    if (!r) return null;
    out.push('<span class="txi">' + r + '</span>');
  }
  return out.join(' ');
}
function walk(root) {
  const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, { acceptNode: n => { const p = n.parentElement; if (!p || p.closest('.katex,.fig-body,.fig-head,textarea,input,script,style,svg,canvas,.eq,.tx-skip,button.opt-x')) return NodeFilter.FILTER_REJECT; return /\{(ce|m|CE|M)\||[→⇌⟶]/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP; } });
  const list = []; while (tw.nextNode()) list.push(tw.currentNode);
  list.forEach(n => {
    let v = n.nodeValue, html = null;
    if (/\{(ce|m|CE|M)\|/.test(v)) { html = inlineMarks(v.replace(/&/g, '&amp;').replace(/</g, '&lt;')); }
    else {
      let changed = false;
      const esc = v.replace(/&/g, '&amp;').replace(/</g, '&lt;');
      const h2 = esc.replace(INL, (m) => { if (!/[A-Z]/.test(m)) return m; const r = inlineChem(m.replace(/&lt;/g, '<').replace(/&amp;/g, '&')); if (!r) return m; changed = true; return r; });
      if (changed) html = h2;
    }
    if (html != null && html !== v) { const sp = document.createElement('span'); sp.innerHTML = html; n.replaceWith(...sp.childNodes); }
  });
}
TX.process = function (root) {
  if (!root || !window.katex) return;
  root.querySelectorAll('.eq:not([data-tx])').forEach(el => { if (!el.closest('.fig-body')) eqBlock(el); });
  walk(root);
};
let pend = false;
TX.observe = function (root) {
  if (!window.MutationObserver) return;
  const mo = new MutationObserver(recs => {
    if (pend) return;
    if (!recs.some(r => r.addedNodes.length && !(r.target.closest && r.target.closest('.fig-body,.katex')))) return;
    pend = true; (window.queueMicrotask || setTimeout)(() => { pend = false; mo.disconnect(); try { TX.process(root); } finally { mo.observe(root, { childList: true, subtree: true }); } });
  });
  mo.observe(root, { childList: true, subtree: true });
  TX.process(root);
};
})();
