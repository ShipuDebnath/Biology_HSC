const APP = require('path').resolve(__dirname, '../../dist/hsc-biology.html');
const { chromium } = require('playwright');
const keys = JSON.parse(process.argv[2]), width = +(process.argv[3] || 760), skin = process.argv[4] || 'vanilla', wait = +(process.argv[5] || 4000), acts = process.argv[6] ? JSON.parse(process.argv[6]) : {};
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width, height: 1000 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(300);
  for (const k of keys) {
    await p.evaluate(([k, skin]) => { document.documentElement.setAttribute('data-skin', skin); const old = document.getElementById('fs'); if (old) old.remove(); const v = VIS[k]; const d = document.createElement('div'); d.id = 'fs'; d.style.cssText = 'position:fixed;inset:0;z-index:9999;overflow:auto;background:var(--bg);padding:12px'; d.innerHTML = `<figure class="fig"><div class="fig-body">${v.html()}</div></figure>`; document.body.appendChild(d); v.mount(d.querySelector('.fig-body')); }, [k, skin]);
    for (const a of (acts[k] || [])) { if (a.startsWith('wait:')) await p.waitForTimeout(+a.slice(5)); else await p.click('#fs ' + a); }
    await p.waitForTimeout(wait);
    const el = await p.$('#fs .fig'); await el.screenshot({ path: `fs_${k}_${width}_${skin}.png` });
  }
  console.log('errs', errs);
  await b.close();
})();
