const APP = require('path').resolve(__dirname, '../../dist/hsc-biology.html');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  await p.route(/fonts\.(googleapis|gstatic)/, r => r.abort());
  await p.goto('file://' + APP); await p.waitForTimeout(500);
  const ids = await p.evaluate(() => APP.LESSONS.map(l => l.id));
  let bad = {};
  for (const id of ids) { await p.evaluate(id => { const l = APP.LESSONS.find(x => x.id === id); APP.setCh(l.ch); APP.go('lesson', { id }); document.querySelectorAll('details').forEach(d => d.open = true); }, id); await p.waitForTimeout(120);
    const r = await p.evaluate(() => { const out = []; const w = document.createTreeWalker(document.querySelector('#view') || document.body, NodeFilter.SHOW_TEXT); let n; while ((n = w.nextNode())) { if (n.parentNode.closest('.katex,script,style,textarea,.fig')) continue; const m = n.nodeValue.match(/(?<![A-Za-z0-9_])[A-Za-zμ]_[A-Za-z0-9]+/g); if (m) out.push(...m); } return out; });
    if (r.length) bad[id] = r.slice(0, 6); }
  console.log(Object.keys(bad).length, JSON.stringify(bad).slice(0, 1500));
  await b.close();
})();
