"""docs/toc_add.txt এর অধ্যায়/অংশগুলো docs/toc.txt এ মিশিয়ে দেয় (আগের কিছুই মোছে না)।
   @ …        নতুন অধ্যায় (একই id থাকলে বাদ)
   @+ id | নোট   আগের অধ্যায়ের শেষে নতুন অংশ যোগ; অধ্যায়ের 'অসম্পূর্ণ' চিহ্ন উঠে যায়, নোট যোগ হয়
   @* id | পাঠের শিরোনাম | + উপ-বিষয় ; + উপ-বিষয়   আগের পাঠে উপ-বিষয় যোগ (পাঠ না থাকলে বাদ)
   @> id | অংশের সংক্ষিপ্ত নাম | পাঠ ; পাঠ   আগের অংশের শেষে নতুন পাঠ যোগ
   @< id | (পুরো অংশ ব্লক)        অধ্যায়ের শুরুতে নতুন অংশ যোগ (পরের লাইনগুলো ## … ব্লক)
অধ্যায়গুলো বিষয় ও ক্রম অনুযায়ী সাজানো হয়।  ব্যবহার: python3 tools/merge_toc.py && python3 tools/gen_toc.py
"""
import os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = os.path.join(ROOT, 'docs', 'toc.txt'); A = os.path.join(ROOT, 'docs', 'toc_add.txt')
lines = open(P, encoding='utf-8').read().split('\n')
head, chs, cur = [], [], None
for l in lines:
    if l.startswith('@ '):
        cur = [l]; chs.append(cur)
    elif cur is None:
        head.append(l)
    else:
        cur.append(l)
cid = lambda b: b[0][2:].split('|')[0].strip()
byid = {cid(b): b for b in chs}
add = open(A, encoding='utf-8').read().split('\n')
i = 0
while i < len(add):
    l = add[i]
    if l.startswith('@ '):
        blk = [l]; i += 1
        while i < len(add) and not add[i].startswith('@'):
            blk.append(add[i]); i += 1
        k = cid(blk)
        if k in byid: print('আগেই আছে, বাদ:', k)
        else: chs.append(blk); byid[k] = blk; print('নতুন অধ্যায়:', k)
        continue
    if l.startswith('@+ ') or l.startswith('@< '):
        f = [x.strip() for x in l[3:].split('|')]; blk = []; i += 1
        while i < len(add) and not add[i].startswith('@'):
            blk.append(add[i]); i += 1
        b = byid.get(f[0])
        if not b: print('অধ্যায় নেই:', f[0]); continue
        hf = [x.strip() for x in b[0][2:].split('|')]
        while len(hf) < 9: hf.append('')
        if l.startswith('@+ '): hf[7] = '0'
        if len(f) > 1 and f[1]: hf[8] = (hf[8] + ' · ' if hf[8] else '') + f[1]
        b[0] = '@ ' + ' | '.join(hf)
        body = [x for x in blk if x.strip()]
        if l.startswith('@+ '):
            while b and not b[-1].strip(): b.pop()
            b.extend(body); b.append('')
        else:
            b[1:1] = body
        print('অংশ যোগ:', f[0], len([x for x in body if x.startswith('##')]))
        continue
    if l.startswith('@* ') or l.startswith('@> '):
        f = [x.strip() for x in l[3:].split('|')]; b = byid.get(f[0]); i += 1
        if not b: print('অধ্যায় নেই:', f[0]); continue
        items = [x.strip() for x in f[2].split(';') if x.strip()]
        if l.startswith('@* '):
            idx = next((j for j, x in enumerate(b) if x.strip() == '- ' + f[1]), None)
            if idx is None: print('পাঠ পাওয়া যায়নি:', f[0], f[1]); continue
            j = idx + 1
            while j < len(b) and b[j].startswith('  '): j += 1
            have = {x.strip() for x in b[idx + 1:j]}
            new = ['  ' + x for x in items if x not in have]
            b[j:j] = new
        else:
            idx = next((j for j, x in enumerate(b) if x.startswith('## ') and x.split('|')[3].strip() == f[1]), None)
            if idx is None: print('অংশ পাওয়া যায়নি:', f[0], f[1]); continue
            j = idx + 1
            while j < len(b) and not b[j].startswith('##') and b[j].strip(): j += 1
            have = {x.strip() for x in b[idx + 1:j]}
            b[j:j] = ['- ' + x for x in items if '- ' + x not in have]
        continue
    i += 1
def key(b):
    f = [x.strip() for x in b[0][2:].split('|')]
    return (f[1], int(f[4]))
chs.sort(key=key)
out = '\n'.join(head).rstrip('\n') + '\n\n' + '\n'.join('\n'.join(b).rstrip('\n') + '\n' for b in chs)
open(P, 'w', encoding='utf-8').write(out)
print('মোট অধ্যায়:', len(chs))
