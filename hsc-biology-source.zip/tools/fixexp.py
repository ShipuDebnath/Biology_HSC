"""Fill empty MCQ explanations. usage: python3 tools/fixexp.py <chapter> <json file of [[question_prefix, explanation], ...]>"""
import sys, json, glob, os
ch, jf = sys.argv[1], sys.argv[2]
pairs = json.load(open(jf, encoding='utf-8'))
files = sorted(glob.glob(f'src/chapters/{ch}/content/*.js'))
src = {f: open(f, encoding='utf-8').read() for f in files}
for q, ex in pairs:
    q2 = q.replace('\\', '\\\\')
    done = False
    for f, s in src.items():
        i = s.find("['" + q2)
        if i < 0: continue
        eol = s.find('\n', i)
        line = s[i:eol]
        ex2 = ex.replace("'", "\\'")
        for pat in (", '']", ", '', '"):
            j = line.rfind(pat)
            if j >= 0:
                newline = line[:j] + ", '" + ex2 + "'" + line[j + 4:]
                src[f] = s[:i] + newline + s[eol:]
                done = True
                break
        if done: break
    if not done: print('NOT FOUND/FILLED:', q[:60])
for f, s in src.items(): open(f, 'w', encoding='utf-8').write(s)
print('ok')
