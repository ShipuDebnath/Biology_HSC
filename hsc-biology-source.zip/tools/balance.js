// Rebalance MCQ answer positions in a chapter's content files. usage: node tools/balance.js <chapter> [--dry]
const fs = require('fs'), path = require('path');
const ch = process.argv[2], dry = process.argv.includes('--dry');
const dir = path.join('src/chapters', ch, 'content');
const q = s => "'" + s.replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
const SKIP = /সবগুলো|সবকটি|কোনোটিই|কোনটিই|উপরের|^i\b|^i ও|^ii|^iii|^i,/;
let k = 0; const cnt = [0, 0, 0, 0];
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.js')).sort()) {
  const fp = path.join(dir, f), lines = fs.readFileSync(fp, 'utf8').split('\n');
  let changed = 0;
  for (let i = 0; i < lines.length; i++) {
    const ln = lines[i], m = /^(\s*)(\[.*\])(,?)\s*$/.exec(ln);
    if (!m || !/\], [0-3], '[emh]', /.test(ln)) continue;
    let a; try { a = eval(m[2]); } catch (e) { continue; }
    if (!Array.isArray(a) || !Array.isArray(a[1]) || a[1].length !== 4 || typeof a[2] !== 'number') continue;
    const tgt = k++ % 4;
    if (a[1].some(o => SKIP.test(o.trim())) || a[2] === tgt) { cnt[a[2]]++; continue; }
    const opts = a[1].slice(), ans = opts[a[2]], others = opts.filter((_, j) => j !== a[2]);
    others.splice(tgt, 0, ans); a[1] = others; a[2] = tgt; cnt[tgt]++;
    lines[i] = m[1] + '[' + a.map(v => Array.isArray(v) ? '[' + v.map(q).join(', ') + ']' : typeof v === 'number' ? v : q(v)).join(', ') + ']' + m[3];
    changed++;
  }
  if (changed && !dry) fs.writeFileSync(fp, lines.join('\n'));
  console.log(f, changed);
}
console.log('dist', cnt);
